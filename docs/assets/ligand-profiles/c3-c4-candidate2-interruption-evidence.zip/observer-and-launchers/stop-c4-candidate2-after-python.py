"""Stop only the identified owned gate after a separately reproduced candidate defect."""
import datetime,json,os,pathlib,signal,time
root=pathlib.Path.cwd().resolve();ev=root/'.issue-11-evidence/issue160-c4-candidate2-run1';pid=578291;expected_start='196546265';dest=ev/'primary-controlled-stop.json'
assert not dest.exists()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def st(p):
 try:return pathlib.Path('/proc',str(p),'stat').read_text().rsplit(')',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):return None
def write(d):dest.write_text(json.dumps(d,indent=2)+'\n')
record={'requested_utc':now(),'campaign':'c4-candidate2','disposition':'INTENTIONALLY_ABORTED / NOT PASS once controlled stop occurs','reason':'Separate unchanged native mobile hardening probe reproduces wrong inherited tab-order oracle: Profile active where Methods expected. Test-only correction must precede fresh all43 campaign.','probe':'.issue-11-evidence/issue160-profile-workflows-hardening-probe1','candidate':'b14670a03f47c6a8000bece41a2733b77a23716f','runner_pid':pid,'runner_starttime':expected_start,'runner_os_exit_status':None,'waiting_for':'Python recorded result or existing gate termination','signals':[]}
write(record)
while True:
 current=st(pid)
 if not current or current[0] in {'Z','X','x'}:
  record['action']='No signal: runner already terminated';record['finished_utc']=now();write(record);raise SystemExit(0)
 assert current[19]==expected_start
 state=json.loads((root/'docs/assets/ligand-profiles/c4-candidate2-gate.json').read_bytes())
 python=next((s for s in state['steps'] if s['label']=='python'),None)
 if python:
  if python['exit_code']!=0:
   record['action']='No signal: Python failed; runner owns failure termination';record['finished_utc']=now();write(record);raise SystemExit(0)
  break
 time.sleep(.25)
assert pathlib.Path('/proc',str(pid),'cwd').resolve()==root
assert b'ligand-profiles/qualification.py.txt' in pathlib.Path('/proc',str(pid),'cmdline').read_bytes()
os.kill(pid,signal.SIGSTOP);record['signals'].append({'pid':pid,'signal':'SIGSTOP','utc':now()});time.sleep(.02)
assert st(pid)[19]==expected_start
children=pathlib.Path('/proc',str(pid),'task',str(pid),'children').read_text().split();record['interruption_snapshot']={'recorded_steps':[(s['label'],s['exit_code']) for s in state['steps']],'children':[],'stdout_tail':(ev/'stdout.log').read_text()[-2600:]}
for child in children:
 cp=int(child);cs=st(cp)
 if not cs or cs[0] in {'Z','X','x'}:continue
 assert int(cs[1])==pid and int(cs[2])==cp and int(cs[3])==cp
 cmd=pathlib.Path('/proc',child,'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
 record['interruption_snapshot']['children'].append({'pid':cp,'pgid':int(cs[2]),'sid':int(cs[3]),'starttime':cs[19],'cmd':cmd})
 write(record)
 os.killpg(cp,signal.SIGTERM);record['signals'].append({'pgid':cp,'signal':'SIGTERM','utc':now()})
write(record)
os.kill(pid,signal.SIGTERM);record['signals'].append({'pid':pid,'signal':'SIGTERM','utc':now()})
os.kill(pid,signal.SIGCONT);record['signals'].append({'pid':pid,'signal':'SIGCONT','utc':now()})
record['action']='Primary intentionally interrupted existing runner and its exact observed active child session after Python PASS; no source edits or test-result reuse';record['finished_utc']=now();write(record)
print(json.dumps({'action':record['action'],'signals':record['signals']}),flush=True)
