"""Run the committed full gate and preserve closed raw owned stores on termination."""
from pathlib import Path
import datetime, hashlib, json, os, shutil, socket, subprocess, time
root=Path.cwd().resolve();label="c4-candidate2";run=Path("/tmp/neistra160-c4-candidate2")
ev=root/".issue-11-evidence/issue160-c4-candidate2-run1";assert not ev.exists();ev.mkdir()
assert not subprocess.check_output(["git","status","--porcelain=v1"],text=True)
recipe=root/"docs/assets/ligand-profiles/c4-candidate2-recipe.json";r=json.loads(recipe.read_bytes())
assert len(r["steps"])==43 and run.is_dir()
for port in (8340,8341,5423):
 with socket.socket() as s:s.settimeout(.3);assert s.connect_ex(("127.0.0.1",port))!=0
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data): (ev/name).write_text(json.dumps(data,indent=2)+"\n")
argv=[str(root/".venv/bin/python"),"-B",str(root/"docs/assets/ligand-profiles/qualification.py.txt"),str(recipe)]
env={k:v for k,v in os.environ.items() if not k.startswith(("NEISTRA_","MOLWEAVE_")) and k not in {"DATABASE_URL","PYTHONPATH"}}
meta={"argv":argv,"cwd":str(root),"candidate":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"started_utc":now(),"recipe_sha256":sha(recipe),"label":label,"run_root":str(run),"clean_start":True,"outer_unset_all_inherited_neistra_molweave_database_and_pythonpath":True}
write("command.json",meta)
with (ev/"stdout.log").open("wb") as out,(ev/"stderr.log").open("wb") as err:
 proc=subprocess.Popen(argv,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True)
 write("running.json",meta|{"runner_pid":proc.pid});print("RUNNING",proc.pid,str(ev),flush=True);code=proc.wait()
result=meta|{"runner_pid":proc.pid,"finished_utc":now(),"exit_code":code,"logs":{name:{"bytes":(ev/name).stat().st_size,"sha256":sha(ev/name)} for name in ("stdout.log","stderr.log")}}
write("execution.json",result)
gate=root/"docs/assets/ligand-profiles/c4-candidate2-gate.json";state=json.loads(gate.read_bytes()) if gate.exists() else {}
sessions={proc.pid}|{x["isolated_child_pid"] for x in state.get("steps",[]) if "isolated_child_pid" in x}
def owners():
 found=[]
 for p in Path("/proc").iterdir():
  if not p.name.isdigit() or int(p.name)==os.getpid():continue
  try:
   st=(p/"stat").read_text().rsplit(")",1)[1].split()
   if st[0] in {"Z","X","x"}:continue
   envs=(p/"environ").read_bytes().split(b"\0");cmd=(p/"cmdline").read_bytes()
   in_env=any(x.startswith((b"NEISTRA_DATA_DIR=",b"MOLWEAVE_DATA_DIR=",b"NEISTRA_E2E_DATA_DIR=",b"MOLWEAVE_E2E_DATA_DIR=",b"NEISTRA_DATABASE_URL=",b"MOLWEAVE_DATABASE_URL=")) and str(run).encode() in x for x in envs)
   if in_env or int(st[3]) in sessions or str(run).encode() in cmd:found.append(int(p.name))
  except (OSError,PermissionError,ProcessLookupError):pass
 return found
live=owners()
for _ in range(40):
 if not live:break
 time.sleep(.25);live=owners()
ports={}
for port in (8340,8341,5423):
 with socket.socket() as s:s.settimeout(.3);ports[str(port)]=s.connect_ex(("127.0.0.1",port))!=0
closed=not live and all(ports.values())
receipt={"recorded_utc":now(),"runner_exit_code":code,"positive_closed":closed,"live_owned_pids":live,"observed_step_session_ids":sorted(sessions),"ports_closed":ports,"primary_diagnostic_sql_before_copy":False,"files":[]}
write("cleanup.json",receipt)
if closed:
 dest=ev/"closed-raw";dest.mkdir()
 for p in sorted(run.rglob("*")):
  if p.is_file() and p.name.endswith((".db",".db-wal",".db-shm",".sqlite",".sqlite-wal",".sqlite-shm",".sqlite3",".sqlite3-wal",".sqlite3-shm")):
   assert not p.is_symlink();q=dest/p.relative_to(run);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert p.read_bytes()==q.read_bytes();receipt["files"].append({"original":str(p),"copy":str(q),"bytes":p.stat().st_size,"sha256":sha(p)})
 write("closed-raw-copy-receipt.json",receipt)
print(json.dumps({"exit_code":code,"positive_closed":closed,"raw_copies":len(receipt["files"]),"evidence":str(ev)}),flush=True)
raise SystemExit(code if code else (0 if closed else 2))
