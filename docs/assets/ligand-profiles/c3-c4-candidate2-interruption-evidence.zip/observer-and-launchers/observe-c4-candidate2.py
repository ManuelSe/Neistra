"""Observe the existing gate after loss of its enclosing wait session; never restart it."""
import datetime,hashlib,json,os,pathlib,select,shutil,socket,time
root=pathlib.Path.cwd().resolve();ev=root/'.issue-11-evidence/issue160-c4-candidate2-run1';run=pathlib.Path('/tmp/neistra160-c4-candidate2');pid=578291
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):(ev/name).write_text(json.dumps(data,indent=2)+'\n')
def stat(pid):
 try:return pathlib.Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):return None
initial=stat(pid);assert initial and initial[0] not in {'Z','X','x'}
assert b'ligand-profiles/qualification.py.txt' in pathlib.Path('/proc',str(pid),'cmdline').read_bytes()
starttime=initial[19];fd=os.pidfd_open(pid,0);poll=select.poll();poll.register(fd,select.POLLIN)
meta={'observer_started_utc':now(),'observer_pid':os.getpid(),'runner_pid':pid,'runner_proc_starttime':starttime,'lost_launcher_session':94738,'observed_launcher_exit_code':143,'runner_os_exit_status':None,'explanation':'Original enclosing launcher ended; existing isolated runner remains active. This observer cannot retrieve its OS wait status and will not invent one. Actual runner records every one of 43 command OS exit codes and frozen maps; terminal manifest and COMPLETE marker are independently retained.','no_gate_restart_or_signals':True,'no_sql':True,'run_root':str(run)}
write('independent-observer-running.json',meta)
sessions={pid}
while True:
 try:
  state=json.loads((root/'docs/assets/ligand-profiles/c4-candidate2-gate.json').read_bytes());sessions|={s['isolated_child_pid'] for s in state.get('steps',[]) if 'isolated_child_pid' in s}
 except (OSError,json.JSONDecodeError):pass
 if poll.poll(1000):break
 current=stat(pid)
 if current is None or current[19]!=starttime or current[0] in {'Z','X','x'}:break
os.close(fd)
state=json.loads((root/'docs/assets/ligand-profiles/c4-candidate2-gate.json').read_bytes());sessions|={s['isolated_child_pid'] for s in state.get('steps',[]) if 'isolated_child_pid' in s}
def owners():
 found=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name)==os.getpid():continue
  try:
   st=(p/'stat').read_text().rsplit(')',1)[1].split()
   if st[0] in {'Z','X','x'}:continue
   envs=(p/'environ').read_bytes().split(b'\0');cmd=(p/'cmdline').read_bytes()
   keys=(b'NEISTRA_DATA_DIR=',b'MOLWEAVE_DATA_DIR=',b'NEISTRA_E2E_DATA_DIR=',b'MOLWEAVE_E2E_DATA_DIR=',b'NEISTRA_DATABASE_URL=',b'MOLWEAVE_DATABASE_URL=')
   in_env=any(e.startswith(keys) and str(run).encode() in e for e in envs)
   if in_env or int(st[3]) in sessions or str(run).encode() in cmd:found.append(int(p.name))
  except (OSError,PermissionError,ProcessLookupError):pass
 return found
live=owners()
for _ in range(40):
 if not live:break
 time.sleep(.25);live=owners()
ports={}
for port in (8340,8341,5423):
 with socket.socket() as s:s.settimeout(.3);ports[str(port)]=s.connect_ex(('127.0.0.1',port))!=0
closed=not live and all(ports.values())
stdout=(ev/'stdout.log').read_bytes();complete_marker=b'COMPLETE '+str(root/'docs/assets/ligand-profiles/c4-candidate2-gate.json').encode() in stdout
terminal={**meta,'observed_termination_utc':now(),'gate_complete':state.get('complete',False),'recorded_steps':len(state.get('steps',[])),'all_43_command_exit_codes_zero':len(state.get('steps',[]))==43 and all(s['exit_code']==0 for s in state['steps']),'complete_stdout_marker':complete_marker,'source_unchanged':state.get('source_unchanged'),'qualification_data_unchanged':state.get('qualification_data_unchanged'),'preceding_source_unchanged':state.get('preceding_source_unchanged'),'manifest_sha256':sha(root/'docs/assets/ligand-profiles/c4-candidate2-gate.json'),'positive_closed':closed,'live_owned_pids':live,'observed_step_session_ids':sorted(sessions),'ports_closed':ports,'primary_diagnostic_sql_before_copy':False,'logs':{n:{'bytes':(ev/n).stat().st_size,'sha256':sha(ev/n)} for n in ('stdout.log','stderr.log')},'files':[]}
write('independent-observer-terminal.json',terminal)
if closed:
 dest=ev/'closed-raw';assert not dest.exists();dest.mkdir()
 for p in sorted(run.rglob('*')):
  if p.is_file() and p.name.endswith(('.db','.db-wal','.db-shm','.sqlite','.sqlite-wal','.sqlite-shm','.sqlite3','.sqlite3-wal','.sqlite3-shm')):
   assert not p.is_symlink();q=dest/p.relative_to(run);q.parent.mkdir(parents=True,exist_ok=True);before=sha(p);shutil.copy2(p,q);assert sha(p)==sha(q)==before;terminal['files'].append({'original':str(p),'copy':str(q),'bytes':p.stat().st_size,'sha256':before})
 write('closed-raw-copy-receipt.json',terminal)
write('independent-observer-result.json',terminal)
print(json.dumps({'positive_closed':closed,'recorded_steps':terminal['recorded_steps'],'complete':terminal['gate_complete'],'raw_copies':len(terminal['files']),'runner_os_exit_status':None}),flush=True)
