from __future__ import annotations
import ast,hashlib,json,pathlib,zipfile
ROOT=pathlib.Path.cwd();issue=160 if ROOT.name.startswith('issue-160') else 161;E=ROOT/f'.issue-11-evidence/issue{issue}-verified-source-integration';OUT=ROOT/f'.issue-11-evidence/issue{issue}-source-producer-architecture';SOURCE=pathlib.Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((E/'frozen-source-map.json').read_text());before=json.loads((E/'before-source-map.json').read_text());owned=json.loads((E/'owned-paths.json').read_text());h=json.loads((E/'handoff.json').read_text());pres=json.loads((E/'preservation-readback.json').read_text());gate=json.loads((E/'gate1-receipt.json').read_text())
checks={'issue':issue,'source_count':len(m),'map_sha256':sha(E/'frozen-source-map.json'),'handoff_sha256':sha(E/'handoff.json'),'source_mismatches':[p for p,v in m.items() if sha(ROOT/p)!=v],'App_sha256':sha(ROOT/'apps/web/src/App.tsx'),'common19_exact':[p for p in owned if p not in {'apps/api/src/neistra_api/main.py','apps/web/src/ligandProperties/useProperties.ts'} and (ROOT/p).read_bytes()==(SOURCE/p).read_bytes()],'removed_before_paths':sorted(set(before)-set(m)),'new_paths':sorted(set(m)-set(before)),'changed_paths':[p for p in before if before[p]!=m.get(p)],'old_tests_changed':[p for p in before if ('/test/' in p or p.startswith('tests/')) and before[p]!=m.get(p)],'context_exact':sha(ROOT/'apps/web/src/ligandProperties/context.ts')==before['apps/web/src/ligandProperties/context.ts'],'D196_protected_exact':all(sha(ROOT/p)==v for p,v in pres['D196_protected_files'].items()),'gate_complete':gate.get('complete'),'gate_steps':[{'name':s['name'],'exit_code':s['exit_code'],'log_hash_exact':sha(ROOT/s['log'])==s['sha256']} for s in gate['steps']]}
zip_path=E/'before-complete-sources.zip'
with zipfile.ZipFile(zip_path) as z:
 checks['before_zip_crc_error']=z.testzip();checks['before_zip_exact']=all(hashlib.sha256(z.read(p)).hexdigest()==v for p,v in before.items())
 def functions(text,cls=None):
  lines=text.splitlines(keepends=True);tree=ast.parse(text);nodes=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls).body if cls else tree.body
  return {n.name:''.join(lines[n.lineno-1:n.end_lineno]) for n in nodes if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 for p,cls,key in [('apps/api/src/neistra_api/ligand_property_service.py','LigandPropertyService','service_changed_methods'),('apps/api/src/neistra_api/main.py',None,'main_changed_functions')]:
  a=functions(z.read(p).decode(),cls);b=functions((ROOT/p).read_text(),cls);checks[key]=[n for n in a if a[n]!=b.get(n)]
# Nested route definitions remain in identical create_app body; only top-level _call changes.
assert not checks['source_mismatches'] and not checks['removed_before_paths'] and not checks['old_tests_changed']
assert len(checks['common19_exact'])==19 and checks['context_exact'] and checks['D196_protected_exact']
assert checks['main_changed_functions']==['_call'] and checks['service_changed_methods']==['_current']
assert checks['gate_complete'] and all(x['exit_code']==0 and x['log_hash_exact'] for x in checks['gate_steps'])
(OUT/'source-checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({k:v for k,v in checks.items() if k not in {'new_paths','changed_paths','gate_steps','common19_exact'}}))
