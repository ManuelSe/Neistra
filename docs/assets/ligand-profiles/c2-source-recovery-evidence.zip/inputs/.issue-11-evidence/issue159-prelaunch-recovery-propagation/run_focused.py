from pathlib import Path
import datetime,hashlib,json,os,subprocess,xml.etree.ElementTree as ET
BASE=Path('/datadisk/dev/neistra-worktrees')
ORIGINAL=BASE/'issue-159-live-ligand-properties/.issue-11-evidence/issue159-prelaunch-recovery-runtime'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['issue-160-physicochemical-profiles','issue-161-ligand-information-sidebar']:
 root=BASE/name;e=root/'.issue-11-evidence/issue159-prelaunch-recovery-propagation';expected=json.loads((e/'source-after.json').read_text())
 def guard():
  assert {p:sha(root/p) for p in expected}==expected
 for phase in (['focused2'] if name.startswith('issue-160') else ['positive1','focused2']):
  out=e/'runtime'/phase;out.mkdir(parents=True,exist_ok=False);(out/'global-data').mkdir()
  old=json.loads((ORIGINAL/('positive1' if phase=='positive1' else 'focused1')/'receipt.json').read_text());command=old['command'] if phase=='positive1' else old['steps'][0]['command']
  command=[str(root/'.venv/bin/python'),*command[1:]]
  if phase=='focused2':
   command=[*command[:3],'-p','migration_location',*command[3:]]
   command=[str(e/'borrowed-regressions/test_ligand_property_migration.py') if part=='tests/integration/test_ligand_property_migration.py' else part for part in command]
  command=[f'--junitxml={out}/junit.xml' if part.startswith('--junitxml=') else f'--basetemp={out}/stores' if part.startswith('--basetemp=') else part for part in command]
  env={k:v for k,v in os.environ.items() if k not in {'NEISTRA_DATA_DIR','NEISTRA_DATABASE_URL','MOLWEAVE_DATA_DIR','MOLWEAVE_DATABASE_URL','DATABASE_URL','PYTEST_ADDOPTS'}}
  if phase=='focused2':
   env['PYTHONPATH']=str(e/'borrowed-regressions')+os.pathsep+env.get('PYTHONPATH','')
  env.update(NEISTRA_DATA_DIR=str(out/'global-data'),NEISTRA_DATABASE_URL='sqlite:///'+str(out/'global-data/global.db'),NEISTRA_PERFORMANCE='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
  guard();receipt={'scope':'Destination focused recovery regression only; no full-feature/native/performance/release readiness','root':str(root),'phase':phase,'command':command,'source_count':len(expected),'source_map_sha256':sha(e/'source-after.json'),'environment_isolation':{'data_dir':env['NEISTRA_DATA_DIR'],'database_url':env['NEISTRA_DATABASE_URL'],'performance':'0','native_threads':'1'},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'complete':False}
  (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('START',name,phase,flush=True)
  with (out/'raw.log').open('wb') as stream:result=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
  receipt.update(actual_child_exit=result.returncode,raw_log_sha256=sha(out/'raw.log'),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
  guard();receipt['selected_source_bodies_unchanged']=True
  if (out/'junit.xml').exists():
   suites=ET.parse(out/'junit.xml').getroot();tests=list(suites.iter('testcase'));receipt['junit']={'cases':len(tests),'failures':sum(len(t.findall('failure')) for t in tests),'errors':sum(len(t.findall('error')) for t in tests),'skips':sum(len(t.findall('skipped')) for t in tests),'sha256':sha(out/'junit.xml')}
  receipt['complete']=result.returncode==0;(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('EXIT',name,phase,result.returncode,receipt.get('junit'),flush=True)
  if result.returncode:raise SystemExit(result.returncode)
  assert receipt['junit']['cases']==(33 if phase=='positive1' else 171)
  assert receipt['junit']['failures']==receipt['junit']['errors']==receipt['junit']['skips']==0
print('BOTH DESTINATION FOCUSED RECOVERY CHECKS PASS',flush=True)
