from pathlib import Path
import ast,hashlib,json,os,stat,xml.etree.ElementTree as ET
BASE=Path('/datadisk/dev/neistra-worktrees')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
for name in ['issue-160-physicochemical-profiles','issue-161-ligand-information-sidebar']:
 root=BASE/name;e=root/'.issue-11-evidence/issue159-prelaunch-recovery-propagation';expected=json.loads((e/'source-after.json').read_text())
 assert all(sha(root/p)==h for p,h in expected.items())
 static=json.loads((e/'static-receipt.json').read_text());assert static['complete'] and all(step['child_exit']==0 for step in static['steps'])
 phases={}
 for out in sorted((e/'runtime').iterdir()):
  if not out.is_dir():continue
  receipt=json.loads((out/'receipt.json').read_text());xml=ET.parse(out/'junit.xml');cases=xml.findall('.//testcase');failures=sum(case.find('failure') is not None for case in cases);errors=sum(case.find('error') is not None for case in cases);skips=sum(case.find('skipped') is not None for case in cases)
  phases[out.name]={'receipt_sha256':sha(out/'receipt.json'),'log_sha256':sha(out/'raw.log'),'junit_sha256':sha(out/'junit.xml'),'child_exit':receipt['actual_child_exit'],'cases':len(cases),'failures':failures,'errors':errors,'skips':skips}
  if out.name=='focused1':assert name.startswith('issue-160') and receipt['actual_child_exit']==4 and len(cases)==0
  else:
   assert receipt['actual_child_exit']==0 and not failures and not errors and not skips
   count=33 if out.name=='positive1' else 3 if out.name=='migration-location-supplement1' else 171
   assert len(cases)==count
  if out.name=='focused2':
   borrowed=[case for case in cases if 'test_ligand_property_migration' in case.attrib.get('file','') or 'test_ligand_property_migration' in case.attrib.get('classname','')]
   assert len(borrowed)==3
   phases[out.name]['local_existing_cases']=168;phases[out.name]['unchanged_private_borrowed_current_destination_migration_cases']=3
  proof=out/'borrowed-migration-location-before-execution.json'
  if proof.exists():
   data=json.loads(proof.read_text());assert data['actual_destination_root']==str(root) and data['actual_test_module_ROOT']==str(root) and data['all_selected_source_bodies_exact_before_execution'];phases[out.name]['before_execution_location_receipt_sha256']=sha(proof)
 assert 'positive1' in phases and 'focused2' in phases
 if name.startswith('issue-160'):assert 'migration-location-supplement1' in phases
 borrowed=e/'borrowed-regressions/test_ligand_property_migration.py';assert sha(borrowed)=='de1ae16293eecd4ce005c9c64fc06c1fd49f92053de877dbcd060071165f3416'
 observation=json.loads((e/'actual-enclosing-observations.json').read_text())
 result={'scope':'Bounded exact two-file recovery propagation and destination-focused validation only; no full feature/readiness/release claim','verdict':'PASS_SCOPED_PROPAGATION','source159_checkpoint':'8a4f5385af3a60b1d32fc706f219a064b66be26e','source_count':len(expected),'source_map_sha256':sha(e/'source-after.json'),'static':{'Ruff':'PASS','owned_format':'PASS','mypy_sources':280,'mypy':'PASS'},'runtime':phases,'unique_new_cases':33,'unique_existing_affected_cases':171,'borrowed_migration_source_sha256':sha(borrowed),'borrowed_harness':'Exact unchanged test body in private evidence; only module ROOT bound to actual destination before execution. Explicit actual destination/alembic/migration/source-map collection receipt is retained. No third selected source path added.','actual_enclosing_observations':observation,'old_guards':'ALL8 and161nativeprep4 are stale/HOLD after changed worker; no GO, guard refresh, services/native/performance/fullgate run','remaining':'Root independent review; source-bound qualification preparation; actual released prerequisite integration and all complete delivery gates','write_state':'IDLE after this handoff'}
 save(e/'handoff.json',result)
 links=[];empty=[];files=[]
 for current,dirs,names in os.walk(e,followlinks=False):
  directory=Path(current)
  if not any(directory.iterdir()):empty.append(str(directory.relative_to(e)))
  for n in dirs[:]:
   p=directory/n
   if p.is_symlink():links.append(p);dirs.remove(n)
  for n in names:
   p=directory/n
   if p.is_symlink():links.append(p)
   elif p not in {e/'manifest.json',e/'retention-metadata.json'}:assert stat.S_ISREG(p.lstat().st_mode);files.append(p)
 aliases=[]
 for link in sorted(links):
  target=link.resolve(strict=False);inside=target==e or e in target.parents
  aliases.append({'path':str(link.relative_to(e)),'original_link_text':os.readlink(link),'resolved_target':str(target),'target_exists':target.exists(),'resolved_target_inside_owned_evidence':inside})
 save(e/'retention-metadata.json',{'all_regular_payloads_retained':True,'omissions':[],'symlinks_preserved_in_original_stores_and_inventoried':aliases,'empty_directories':empty,'SQL_opened_by_finalizer':False})
 files.append(e/'retention-metadata.json');manifest={str(p.relative_to(e)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)};save(e/'manifest.json',manifest)
 assert all(sha(e/p)==h['sha256'] for p,h in manifest.items())
 print(json.dumps({'root':str(root),'handoff_sha256':sha(e/'handoff.json'),'manifest_sha256':sha(e/'manifest.json'),'regular_payloads':len(manifest),'raw_and_evidence_bytes':sum(v['bytes'] for v in manifest.values()),'symlinks':len(aliases),'empty_directories':len(empty),'source_count':len(expected)}))
