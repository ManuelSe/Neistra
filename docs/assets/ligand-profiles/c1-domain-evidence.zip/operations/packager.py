"""Retain the frozen profile domain and metadata API preparatory checkpoint."""
from pathlib import Path
import datetime
import json
import runpy
import subprocess

root=Path.cwd();private=root/'.issue-11-evidence';out=private/'issue160-domain-packet'
assert not out.exists();out.mkdir()
assets=root/'docs/assets/ligand-profiles';assets.mkdir(exist_ok=True)
h=runpy.run_path(str(root/'docs/assets/ligand-designation/release-evidence.py.txt'))
q=runpy.run_path(str(root/'docs/assets/ligand-designation/qualification.py.txt'))
author_path=private/'issue160-domain/handoff4.json';author=json.loads(author_path.read_text())
pin_path=private/'issue160-pinned-unreleased159-dependencies.json';pins=json.loads(pin_path.read_text())
api_path=private/'issue160-metadata-api1/receipt.json';api=json.loads(api_path.read_text())
domain=author['source_identities'];dependencies=pins['source_identities'];api_sources=api['source_before']
assert len(domain)==15 and len(dependencies)==13 and len(api_sources)==2
assert not domain.keys()&dependencies.keys() and not (domain.keys()|dependencies.keys())&api_sources.keys()
assert author['pinned_unreleased_dependencies']==dependencies and author['pinned_unreleased_dependencies_unchanged']
assert author['source_digest']=='799c738eb4dbf639af4c04d983f88bb9c91f7a0342196eb626311b8bf9d9916a'
digest=lambda values:h['sha'](json.dumps(values,sort_keys=True).encode())
assert digest(domain)==author['source_digest']
expected={**domain,**dependencies,**api_sources}
before={name:h['fingerprint'](root/name)['sha256'] for name in sorted(expected)};assert before==expected
selected_before=q['current_identities'](root)
checks_path=root/author['verification_receipt'];checks=json.loads(checks_path.read_text())
assert h['fingerprint'](checks_path)['sha256']==author['verification_receipt_sha256']
assert checks['complete'] and checks['source_before']==checks['source_after']==domain
assert checks['pinned_unreleased_dependencies_before']==checks['pinned_unreleased_dependencies_after']==dependencies
assert api['complete'] and api['source_before']==api['source_after']==api_sources
def verify_logs(receipt):
    for command in receipt['commands']:
        assert command['exit_code']==0
        path=Path(command['log']);path=path if path.is_absolute() else root/path
        assert path.resolve().is_relative_to(private.resolve()) and not path.is_symlink()
        assert h['fingerprint'](path)['sha256']==command.get('log_sha256',command.get('sha256'))
verify_logs(checks);verify_logs(api)
final_enclosing=json.loads((private/'issue160-domain/checks4/actual-enclosing.json').read_text())
negative=[]
for label in ['model-dependency-before3','canonical-id-before4']:
    directory=private/'issue160-domain'/label;r=json.loads((directory/'receipt.json').read_text())
    assert r['exit_code']==1 and r['source_unchanged'] and r['source_before']==r['source_after']
    assert h['fingerprint'](directory/'raw.log')['sha256']==r['log_sha256']
    negative.append(dict(label=label,receipt=h['fingerprint'](directory/'receipt.json'),exact_test_source=h['fingerprint'](directory/'source-test.ts'),actual_enclosing=json.loads((directory/'actual-enclosing.json').read_text()),qualification_complete=False))
items={}
for name in sorted(domain):h['add'](items,'domain-source/'+name,root/name)
for name in sorted(dependencies):h['add'](items,'pinned-unreleased159-source/'+name,root/name)
for name in sorted(api_sources):h['add'](items,'metadata-api-source/'+name,root/name)
domain_evidence_files=h['add_tree'](items,'domain-evidence',private/'issue160-domain')
api_evidence_files=h['add_tree'](items,'metadata-api-evidence',private/'issue160-metadata-api1')
h['add'](items,'pinned-unreleased159-dependencies.json',pin_path)
h['add'](items,'operations/packager.py',Path(__file__))
source_after={name:h['fingerprint'](root/name)['sha256'] for name in sorted(expected)}
selected_after=q['current_identities'](root)
assert source_after==before==expected and selected_after==selected_before
proof=dict(scope='Read-only frozen-source proof for a preparatory domain/API packet; no full application qualification',domain_source_count=15,domain_source_digest=digest(domain),domain_expected=domain,unreleased159_dependency_count=13,unreleased159_dependency_digest=digest(dependencies),unreleased159_expected=dependencies,metadata_api_source_count=2,metadata_api_expected=api_sources,combined_count=30,combined_digest=digest(expected),combined_before=before,combined_after=source_after,combined_unchanged=True,selected_inventory_before=selected_before,selected_inventory_after=selected_after,selected_inventory_count=len(selected_before),selected_inventory_digest=digest(selected_before),selected_inventory_unchanged=True)
h['add'](items,'source-proof.json',h['encoded'](proof))
facts=dict(scope='Coherent scientific metadata/domain preparation checkpoint for issue160; not a finished vertical workflow, release qualification, readiness to push, or delivered prerequisite',repository='ManuelSe/Neistra',issue=160,parent=11,head_plus_working_changes=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    implemented='Versioned typed profile registry and scientific metadata, shared generic frontend evaluation with qualified-input guards, independent boundary/molecular fixtures, and a read-only typed metadata registry API.',
    domain_source_count=15,domain_source_digest=digest(domain),unreleased159_dependency_count=13,unreleased159_dependency_digest=digest(dependencies),metadata_api_source_count=2,metadata_api_source_digest=digest(api_sources),combined_source_count=30,combined_source_digest=digest(expected),combined_sources_unchanged=True,
    pinned_dependency_status='Exact thirteen copied sources from unreleased159 preparation. These copies do not establish159delivery. Integrate actual verified159deliverymaster, reconcile every copied source against released identities and repeat applicable integrated gates before final160delivery.',
    focused_checks=dict(domain_python_tests=47,domain_frontend_tests=220,domain_frontend_suites=1,domain_ruff='PASS',domain_mypy='PASS8files',domain_format='PASS8files',full_web_typecheck='PASS',scoped_frontend_lint='PASS',metadata_api_and_registry_python_tests=49,metadata_api_ruff='PASS',metadata_test_format='PASS',full_api_core_demo_mypy='PASS265files'),
    actual_check_provenance=dict(author_final_handoff='domain-evidence/handoff4.json',author_final_checks='domain-evidence/checks4/receipt.json',author_observed_session=54095,author_observed_exit=0,author_retained_actual_enclosing=final_enclosing,metadata_final_checks='metadata-api-evidence/receipt.json',root_observed_metadata_session=96796,root_observed_metadata_exit=0,root_reported_prior49test_session=57719,root_reported_prior49test_exit=0,prior49test_output_scope='Earlier root observation is reported as provenance; final49case raw log and complete validation receipt are retained separately. Counts are not pooled.'),
    preserved_earlier_evidence=dict(files=domain_evidence_files,negative_controls=negative,source_archives=['first-freeze-75582c9-sources.zip','third-freeze-8360339-sources.zip'],policy='All earlier frozen source archives, handoffs, failed negative controls and checks1through4 remain distinct historical evidence. Their passing segments are not combined into a qualification gate.'),
    consequential_corrections=['Reject ready graph-dependent outcomes when the chemistry model is unavailable, while preserving independently qualified element/charge facts.','Require strictly positive canonical atom identifiers; preserve matching positive identifier controls and every threshold/method/fixture/dependency contract.'],
    specialist_scope='Scoped scientific assessments and the active metadata architecture assessment are coordinated separately by root. This packet does not claim a same-candidate all-seven completion gate.',
    explicitly_not_implemented_or_delivered=['Real159current-owner adapter and live publication authority integration','Application profile controls and complete user workflow','Actual159released-predecessor integration and compatibility qualification','Native/performance/full160candidate and exact-master release gates','Final all-seven assessment, protected merge, release, issue closeout and parent program completion'],
    retained_metadata_api_evidence_files=api_evidence_files,no_unrelated_raw_stores_or_other_issue_forensic_parts=True,no_network_services_or_source_changes=True)
h['add'](items,'checkpoint-context.json',h['encoded'](facts))
archive=h['archive'](items,assets/'c1-domain-evidence.zip')
assert {name:h['fingerprint'](root/name)['sha256'] for name in sorted(expected)}==before
assert q['current_identities'](root)==selected_before
record=dict(**facts,archive=archive['file'],archive_bytes=archive['bytes'],archive_sha256=archive['sha256'],outer_manifest_entries=archive['outer_manifest_entries'],recursive_verification=archive['verification_counts'],exact_manifest_payload_hashes_and_recursive_crcs_verified=True,selected_inventory_count=len(selected_before),selected_inventory_digest=digest(selected_before),selected_inventory_unchanged=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
target=assets/'c1-domain-checkpoint.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
(out/'packager-result.json').write_text(json.dumps(dict(archive=archive,checkpoint=h['fingerprint'](target),source_proof=dict(combined_count=30,combined_digest=digest(expected),selected_count=len(selected_before),selected_digest=digest(selected_before),unchanged=True)),indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
