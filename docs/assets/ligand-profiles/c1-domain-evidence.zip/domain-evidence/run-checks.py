import concurrent.futures
import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
output = root / '.issue-11-evidence/issue160-domain' / sys.argv[1]
assert not output.exists()
output.mkdir()
paths = [
    *sorted((root / 'packages/neistra_core/src/neistra_core/ligand_profiles').glob('*.py')),
    *sorted((root / 'packages/neistra_core/src/molweave_core/ligand_profiles').glob('*.py')),
    *sorted((root / 'apps/web/src/ligandProfiles').glob('*.ts')),
    root / 'apps/web/src/test/ligand-profiles-domain.test.ts',
    root / 'tests/unit/test_ligand_profile_registry.py',
    *sorted((root / 'tests/fixtures/profiles').glob('*')),
]
relative = [str(path.relative_to(root)) for path in paths if path.is_file()]
python_paths = [path for path in relative if path.endswith('.py')]


def hashes():
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in relative}


pins = json.loads((root / '.issue-11-evidence/issue160-pinned-unreleased159-dependencies.json')
                  .read_text())['source_identities']


def pinned_hashes():
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in pins}


assert pinned_hashes() == pins
commands = {
    'python-tests': ['.venv/bin/python', '-m', 'pytest', 'tests/unit/test_ligand_profile_registry.py', '-q'],
    'python-lint': ['.venv/bin/ruff', 'check', *python_paths],
    'python-format': ['.venv/bin/ruff', 'format', '--check', *python_paths],
    'python-types': ['.venv/bin/mypy', 'packages/neistra_core/src/neistra_core/ligand_profiles',
                     'packages/neistra_core/src/molweave_core/ligand_profiles',
                     'tests/unit/test_ligand_profile_registry.py', 'tests/fixtures/profiles/generate_boundaries.py'],
    'web-tests': ['corepack', 'pnpm', '--dir', 'apps/web', 'exec', 'vitest', 'run',
                  'src/test/ligand-profiles-domain.test.ts'],
    'web-types': ['corepack', 'pnpm', '--dir', 'apps/web', 'typecheck'],
    'web-lint': ['corepack', 'pnpm', '--dir', 'apps/web', 'exec', 'eslint', 'src/ligandProfiles',
                 'src/test/ligand-profiles-domain.test.ts', '--max-warnings', '0'],
}
state = {
    'scope': 'Focused scientific-domain preparation; not integrated application or release qualification',
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_before': hashes(), 'pinned_unreleased_dependencies_before': pinned_hashes(),
    'commands': [], 'complete': False,
}
receipt = output / 'receipt.json'
receipt.write_text(json.dumps(state, indent=2) + '\n')


def run(item):
    name, command = item
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = output / (name + '.log')
    log.write_bytes(result.stdout)
    return {'name': name, 'command': command, 'exit_code': result.returncode,
            'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'log': str(log.relative_to(root)), 'log_sha256': hashlib.sha256(result.stdout).hexdigest()}


with concurrent.futures.ThreadPoolExecutor(max_workers=7) as pool:
    for result in pool.map(run, commands.items()):
        state['commands'].append(result)
        print(result['name'], result['exit_code'], flush=True)
state.update(source_after=hashes(), source_unchanged=hashes() == state['source_before'],
             pinned_unreleased_dependencies_after=pinned_hashes(), pinned_dependencies_unchanged=pinned_hashes() == pins,
             finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), complete=True,
             all_passed=all(item['exit_code'] == 0 for item in state['commands']))
for path in relative:
    payload = (root / path).read_bytes()
    assert payload.endswith(b'\n') and all(line.rstrip() == line for line in payload.splitlines()), path
state['whitespace_check'] = 'PASS'
receipt.write_text(json.dumps(state, indent=2) + '\n')
assert state['source_unchanged'] and state['pinned_dependencies_unchanged']
raise SystemExit(0 if state['all_passed'] else 1)
