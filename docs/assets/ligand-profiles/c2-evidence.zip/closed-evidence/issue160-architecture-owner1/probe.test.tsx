import * as Tooltip from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/node_modules/@radix-ui/react-tooltip";
import { QueryClient, QueryClientProvider } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/node_modules/@tanstack/react-query";
import { act, cleanup, render, screen, waitFor, within } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/node_modules/@testing-library/react";
import userEvent from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/node_modules/@testing-library/user-event";
import { StrictMode, useLayoutEffect } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/node_modules/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/node_modules/vitest";
import metadata from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/tests/fixtures/profiles/registry.json";
import oracle from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/tests/fixtures/profiles/boundaries.json";
import { ApiError } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/api/client";
import type { Project } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/api/types";
import { LigandProperties } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/components/LigandProperties";
import { PROFILE_REGISTRY_KEY, ligandProfileApi } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProfiles/api";
import { profileInputAuthority } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProfiles/authority";
import { ProfileSelection } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProfiles/context";
import { evaluateProfile } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProfiles/evaluate";
import { parseProfileRegistry } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProfiles/validate";
import { useLigandProfiles } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProfiles/useProfiles";
import { ligandPropertyApi } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProperties/api";
import { PROPERTY_PREFERENCES_KEY, PROPERTY_REGISTRY_KEY, propertyInputKey } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProperties/context";
import { PropertyInputOwner } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProperties/ownership";
import { LigandPropertySession } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProperties/session";
import type { DescriptorRegistry, PropertyAggregate, PropertyPreferences, PropertySource } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProperties/types";
import { useLigandProperties, type PropertyPresentation } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/ligandProperties/useProperties";
import { deferredProperty, propertyAllocation, propertyEntry, propertyPreferences, propertyProject } from "/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/apps/web/src/test/ligand-properties-fixtures";

const registry = parseProfileRegistry(metadata);
const descriptorRegistry: DescriptorRegistry = { ...registry.descriptor_method, definitions: [...registry.descriptors] };
const baseValues: Record<string, number> = oracle.base_values;
const clients: QueryClient[] = [], sessions: LigandPropertySession[] = [];
function result(projectId: string, source: PropertySource, ids: string[], status: "ready" | "pending" = "ready",
  overrides: Record<string, number> = {}, coverage = ids): PropertyAggregate {
  return { project_id: projectId, entries: [{ source: structuredClone(source), binding_key: "b".repeat(64), status, reason: null,
    progress: status === "ready" ? 100 : 25, report: { schema_version: 1, input_hash: "c".repeat(64), ...registry.descriptor_method,
      created_at: "2026-11-17T00:00:00Z", model_status: "qualified", model_reason: null, contains_formally_charged_atoms: false,
      provenance: ["Qualified current source"], coverage, values: coverage.map(id => ({ descriptor_id: id, status: "ready", reason: null,
        value: overrides[id] ?? baseValues[id] })) } }] };
}
beforeEach(() => {
  vi.spyOn(ligandProfileApi, "registry").mockResolvedValue(registry);
  vi.spyOn(ligandPropertyApi, "registry").mockResolvedValue(descriptorRegistry);
  vi.spyOn(ligandPropertyApi, "preferences").mockResolvedValue({ ...propertyPreferences, enabled_categories: [] });
  vi.spyOn(ligandPropertyApi, "allocate").mockImplementation(id => Promise.resolve(propertyAllocation(id)));
  vi.spyOn(ligandPropertyApi, "release").mockResolvedValue({});
  vi.spyOn(ligandPropertyApi, "savePreferences");
  vi.spyOn(ligandPropertyApi, "read").mockImplementation((projectId, body) => Promise.resolve(result(projectId, body.entries[0], body.descriptor_ids)));
  vi.spyOn(ligandPropertyApi, "demand").mockImplementation((projectId, _id, body) => Promise.resolve(result(projectId, body.entries[0], body.descriptor_ids, "pending", {}, [])));
});
afterEach(() => {
  cleanup(); sessions.splice(0).forEach(session => session.deactivate()); clients.splice(0).forEach(client => client.clear()); vi.restoreAllMocks();
});
function setup({ categories = [], strict = false, selected = "" }: {
  categories?: PropertyPreferences["enabled_categories"]; strict?: boolean; selected?: string;
} = {}) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: Infinity } } }); clients.push(client);
  client.setQueryData(PROPERTY_PREFERENCES_KEY, { ...propertyPreferences, enabled_categories: categories });
  const selection = new ProfileSelection(client); selection.select(selected);
  const project = propertyProject(); project.entries[0].ligand_designation.atom_ids = Array.from({ length: 18 }, (_, i) => i + 1);
  type Input = { project: Project; entryId: string | null; pausedReason: string | null };
  let input: Input = { project, entryId: project.entries[0].id, pausedReason: null };
  let presentation!: PropertyPresentation;
  const owner = new PropertyInputOwner(() => {
    const definitions = client.getQueryState<DescriptorRegistry>(PROPERTY_REGISTRY_KEY);
    const preferences = client.getQueryState<PropertyPreferences>(PROPERTY_PREFERENCES_KEY);
    const currentRegistry = definitions?.status === "success" ? definitions.data : undefined;
    return { activeProjectId: input.project.id, inspectedEntryId: input.entryId, paused: !!input.pausedReason,
      inputKey: propertyInputKey(input.project.id, input.project.entries.find(entry => entry.id === input.entryId), currentRegistry,
        preferences?.status === "success" ? preferences.data : undefined, selection.dependencies(currentRegistry)) };
  });
  const session = new LigandPropertySession(target => owner.capture(target)); sessions.push(session);
  function Harness({ visible }: { visible: boolean }) {
    useLayoutEffect(() => { owner.activate(); session.activate(); owner.observe(); return () => { owner.deactivate(); session.deactivate(); }; }, []);
    const profiles = useLigandProfiles(true, selection, owner);
    presentation = useLigandProperties({ ...input, session, owner, profileSelection: selection });
    return visible ? <LigandProperties state={presentation} session={session} profiles={profiles} /> : null;
  }
  const tree = (visible: boolean) => <QueryClientProvider client={client}><Tooltip.Provider>
    {strict ? <StrictMode><Harness visible={visible} /></StrictMode> : <Harness visible={visible} />}
  </Tooltip.Provider></QueryClientProvider>;
  const rendered = render(tree(true));
  return { client, owner, session, selection, state: () => presentation,
    evaluate: () => evaluateProfile(selection.registry()!, selection.id(), profileInputAuthority(presentation, session, selection, selection.registry()!, selection.id())),
    update: (change: Partial<Input>, visible = true) => act(() => { input = { ...input, ...change }; owner.observe(); rendered.rerender(tree(visible)); }),
    visibility: (visible: boolean) => act(() => rendered.rerender(tree(visible))),
    change: (id: string) => userEvent.selectOptions(screen.getByRole("combobox", { name: "Profile" }), id),
    externalSelect: (id: string) => act(() => { selection.select(id, owner.observe); rendered.rerender(tree(true)); }),
    ...rendered,
  };
}
const waitCatalog = () => screen.findByRole("option", { name: "Ro5 — all four" });
const currentStatus = () => screen.findByText("Within profile criteria.");


it("independent held source/profile ABA cannot republish its old positive or violating binding", async () => {
 const held=deferredProperty<PropertyAggregate>();vi.mocked(ligandPropertyApi.read).mockReturnValueOnce(held.promise);
 const app=setup();await waitCatalog();await app.change("ro5");await waitFor(()=>expect(ligandPropertyApi.read).toHaveBeenCalledTimes(1));
 const old=app.state().target!, stamp=profileInputAuthority(app.state(),app.session,app.selection,registry,"ro5").capture();
 const b=propertyProject();b.entries[0]=propertyEntry("source-b");b.entries[0].ligand_designation.atom_ids=[...old.source.atom_ids];
 const a=propertyProject();a.entries[0].ligand_designation.atom_ids=[...old.source.atom_ids];
 act(()=> {app.update({project:b});app.externalSelect("ro3");app.update({project:a});app.externalSelect("ro5");});
 await currentStatus();expect(stamp.isCurrent()).toBe(false);
 await act(async()=>{held.resolve(result(old.projectId,old.source,old.descriptorIds,"ready",{molecular_weight:999}));await held.promise;});
 expect(app.evaluate().status).toBe("pass");expect(app.evaluate().criteria.find(x=>x.constraint.descriptor_id==="molecular_weight")?.value).toBe(250);
 expect(ligandPropertyApi.savePreferences).not.toHaveBeenCalled();
});
it("independent held binding may complete during metadata failure without granting stale profile authority or restarting demand on recovery",async()=>{
 const held=deferredProperty<PropertyAggregate>();
 vi.mocked(ligandPropertyApi.read).mockImplementation((id,body)=>Promise.resolve(result(id,body.entries[0],body.descriptor_ids,"pending",{},[])));
 vi.mocked(ligandPropertyApi.demand).mockReturnValueOnce(held.promise);
 const app=setup();await waitCatalog();await app.change("ro5");await waitFor(()=>expect(ligandPropertyApi.demand).toHaveBeenCalledTimes(1));
 const target=app.state().target!, epoch=app.owner.snapshot(), stamp=profileInputAuthority(app.state(),app.session,app.selection,registry,"ro5").capture();
 vi.mocked(ligandProfileApi.registry).mockRejectedValueOnce(new Error("independent offline"));
 await act(async()=>{await app.client.refetchQueries({queryKey:PROFILE_REGISTRY_KEY});});await screen.findByRole("button",{name:"Retry profiles"});
 expect(stamp.isCurrent()).toBe(false);expect(app.owner.snapshot()).toBe(epoch);
 await act(async()=>{held.resolve(result(target.projectId,target.source,target.descriptorIds));await held.promise;});
 await waitFor(()=>expect(app.session.view(app.state().target!).status).toBe("ready"));
 expect(screen.queryByText("Within profile criteria.")).not.toBeInTheDocument();
 const counts={reads:vi.mocked(ligandPropertyApi.read).mock.calls.length,allocations:vi.mocked(ligandPropertyApi.allocate).mock.calls.length,demands:vi.mocked(ligandPropertyApi.demand).mock.calls.length};
 vi.mocked(ligandProfileApi.registry).mockResolvedValueOnce(parseProfileRegistry(structuredClone(metadata)));
 await userEvent.click(screen.getByRole("button",{name:"Retry profiles"}));await currentStatus();
 expect(app.owner.snapshot()).toBe(epoch);expect(ligandPropertyApi.read).toHaveBeenCalledTimes(counts.reads);expect(ligandPropertyApi.allocate).toHaveBeenCalledTimes(counts.allocations);expect(ligandPropertyApi.demand).toHaveBeenCalledTimes(counts.demands);
 expect(stamp.isCurrent()).toBe(false);expect(ligandPropertyApi.savePreferences).not.toHaveBeenCalled();
});
it("independent true unmount permanently retires the old owner before an equivalent replacement App owner becomes current",async()=>{
 const held=deferredProperty<PropertyAggregate>();vi.mocked(ligandPropertyApi.read).mockReturnValueOnce(held.promise);
 const old=setup();await waitCatalog();await old.change("ro5");await waitFor(()=>expect(ligandPropertyApi.read).toHaveBeenCalledTimes(1));
 const target=old.state().target!, stamp=profileInputAuthority(old.state(),old.session,old.selection,registry,"ro5").capture();old.unmount();
 const next=setup();await waitCatalog();await next.change("ro5");await currentStatus();
 await act(async()=>{held.resolve(result(target.projectId,target.source,target.descriptorIds,"ready",{molecular_weight:999}));await held.promise;});
 expect(stamp.isCurrent()).toBe(false);expect(next.evaluate().status).toBe("pass");expect(next.evaluate().criteria.find(x=>x.constraint.descriptor_id==="molecular_weight")?.value).toBe(250);
});
