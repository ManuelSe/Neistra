import datetime, hashlib, json, pathlib, subprocess, sys, zipfile
root=pathlib.Path.cwd(); out=root/'.issue-11-evidence/issue160-frontend'; web=root/'apps/web'
owned=['apps/web/src/App.tsx','apps/web/src/components/LigandProperties.tsx','apps/web/src/ligandProperties/context.ts','apps/web/src/ligandProperties/useProperties.ts']+[str(p.relative_to(root)) for p in sorted((web/'src/ligandProfiles').glob('*')) if p.name not in {'types.ts','validate.ts','evaluate.ts'}]+['apps/web/src/test/ligand-profiles-integration.test.tsx','apps/web/src/test/ligand-profiles-api.test.ts']
def hashes(paths):return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=hashes(owned)
allweb=[str(p.relative_to(root)) for p in sorted((web/'src').rglob('*')) if p.is_file()]+['apps/web/package.json','apps/web/eslint.config.js','apps/web/vite.config.ts','apps/web/tsconfig.app.json','apps/web/tsconfig.node.json']
webbefore=hashes(allweb)
domain=json.loads((root/'.issue-11-evidence/issue160-domain/handoff4.json').read_text())['source_identities']
pins=json.loads((root/'.issue-11-evidence/issue160-unreleased159-runtime-snapshot1/pin-record-before.json').read_text())['source_identities']
assert hashes(domain)==domain,'Frozen domain changed';assert hashes(pins)==pins,'Pinned dependency changed'
(out/'final-source-before.json').write_text(json.dumps({'owned':before,'all_web':webbefore,'domain':domain,'pins':pins},indent=2)+'\n')
with zipfile.ZipFile(out/'final-source.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for p in owned:archive.write(root/p,p)
commands=[('lint',['npm','run','lint']),('types',['npm','run','typecheck']),('focused',['npm','run','test','--','src/test/ligand-profiles-integration.test.tsx','src/test/ligand-profiles-api.test.ts','src/test/ligand-profiles-domain.test.ts','src/test/ligand-properties.test.tsx','src/test/ligand-properties-session.test.ts','src/test/ligand-properties-api.test.ts','src/test/ligand-properties-ownership.test.ts']),('all-web-tests',['npm','run','test']),('build',['npm','run','build'])]
checks=[]
for label,cmd in commands:
 print('START',label,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 log=out/f'final-{label}.log'
 with log.open('w') as stream: completed=subprocess.run(cmd,cwd=web,stdout=stream,stderr=subprocess.STDOUT)
 check={'label':label,'command':cmd,'cwd':str(web),'exit_code':completed.returncode,'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};checks.append(check)
 print('END',label,'exit',completed.returncode,flush=True)
 if completed.returncode:break
after=hashes(owned);webafter=hashes(allweb)
receipt={'scope':'Isolated unreleased frontend integration preparation; native integration and independent review are parent-owned, prerequisite release reconciliation remains mandatory.','owned_before':before,'owned_after':after,'owned_unchanged_during_checks':before==after,'web_before_count':len(webbefore),'web_unchanged_during_checks':webbefore==webafter,'domain_frozen_unchanged':hashes(domain)==domain,'domain_count':len(domain),'pins_frozen_unchanged':hashes(pins)==pins,'pin_count':len(pins),'checks':checks,'all_checks_passed':len(checks)==len(commands) and all(c['exit_code']==0 for c in checks),'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'final-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert before==after and webbefore==webafter and hashes(domain)==domain and hashes(pins)==pins,'Source changed during qualification'
sys.exit(0 if receipt['all_checks_passed'] else 1)
