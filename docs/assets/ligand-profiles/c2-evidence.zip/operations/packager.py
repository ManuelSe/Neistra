"""Package local profile C2 evidence; no application or release-readiness mutation."""
from pathlib import Path
import ast
import base64
import datetime
import hashlib
import json
import os
import runpy
import struct
import subprocess
import zipfile

out=Path(__file__).resolve().parent;root=out.parents[1];private=root/'.issue-11-evidence';a=root/'docs/assets/ligand-profiles'
assert not (out/'packager-result.json').exists()
h=runpy.run_path(str(root/'docs/assets/ligand-designation/release-evidence.py.txt'))
q=runpy.run_path(str(root/'docs/assets/ligand-designation/qualification.py.txt'))
digest=lambda value:h['sha'](json.dumps(value,sort_keys=True).encode())
before=q['current_identities'](root)
assert len(before)==1074
assert digest(before)=='ee7581af128133f15c23856585bb75ceadad97f5669061854c58b97e6e97b52e'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='cb4a6c2119eeaceecd8f839bb8a5dccd8a37daea'
baseline=q['tagged_identities']('HEAD');changed=sorted(n for n,v in before.items() if baseline.get(n)!=v);deleted=sorted(n for n in baseline if n not in before)
assert len(changed)==80 and not deleted
def read(name):return json.loads((private/name).read_text())
def hashes(values):return {name:value['sha256'] if isinstance(value,dict) else value for name,value in values.items()}
def matches(values):return all(before.get(name)==value for name,value in hashes(values).items())
def check_steps(receipt,directory):
    for step in receipt['steps']:
        assert step['exit_code']==0
        assert h['fingerprint'](directory/(step['label']+'.log'))['sha256']==step['log_sha256']
c1=a/'c1-domain-evidence.zip';c1json=a/'c1-domain-checkpoint.json'
assert h['fingerprint'](c1)==dict(bytes=344899,sha256='2e8586613aa68e41fb6d4771a98b13c7b6cf84d6a11c15a41f7c1564cbc17d81')
c1_identity=h['fingerprint'](c1);c1_metadata_identity=h['fingerprint'](c1json)
domain=read('issue160-domain/handoff4.json')['source_identities'];pins=read('issue160-pinned-unreleased159-dependencies.json')['source_identities']
assert len(domain)==15 and len(pins)==13 and matches(domain) and matches(pins)
snapshot1=read('issue160-unreleased159-runtime-snapshot1/manifest.json');assert snapshot1['copy_count']==49
with zipfile.ZipFile(private/'issue160-unreleased159-runtime-snapshot1/unreleased159-runtime-source.zip') as archive:
    assert set(archive.namelist())==set(snapshot1['copied_runtime_source_hashes'])
    assert all(h['sha'](archive.read(name))==value for name,value in snapshot1['copied_runtime_source_hashes'].items())
snapshot2=read('issue160-unreleased159-fairness-snapshot2/manifest.json')
assert snapshot2['source_head']=='f6e847b8e25eb4d1068f8b14741fda6fb8bdd0d0'
assert snapshot2['changed_borrowed49_runtime_paths']==['apps/api/src/neistra_api/job_worker.py']
format_proof=read('issue160-fairness-format2/receipt.json')
for name,row in format_proof['files'].items():
    original=private/'issue160-fairness-format2/before'/name
    assert h['fingerprint'](original)['sha256']==row['before_sha256']
    assert before[name]==row['after_sha256'] and row['complete_python_ast_equal']
    assert ast.dump(ast.parse(original.read_bytes()),include_attributes=False)==ast.dump(ast.parse((root/name).read_bytes()),include_attributes=False)
    assert row['before_sha256']==snapshot2['copied'][name]['current_sha256']
api2=read('issue160-fairness-api2/receipt.json');assert api2['complete'] and api2['source_unchanged'] and api2['source_before']==api2['source_after'] and len(api2['source_after'])==553 and matches(api2['source_after'])
check_steps(api2,private/'issue160-fairness-api2')
api2_actual=read('issue160-fairness-api2/actual-enclosing.json');assert api2_actual['actual_session']==23929 and api2_actual['actual_exit']==0 and api2_actual['pytest_passed']==78 and api2_actual['mypy_files']==280
assert api2_actual['receipt_sha256']==h['fingerprint'](private/'issue160-fairness-api2/receipt.json')['sha256']
api1=read('issue160-fairness-api1/receipt.json');assert api1['complete'] is False and api1['steps'][-1]['label']=='format' and api1['steps'][-1]['exit_code']!=0 and all(s['label']!='mypy' for s in api1['steps'])
api_overlay=read('issue160-metadata-api-overlay2/receipt.json');assert api_overlay['complete'] and api_overlay['source_before']==api_overlay['source_after'] and matches(api_overlay['source_after'])
position_dir=private/'issue160-frontend/reading-position';position=read('issue160-frontend/reading-position/handoff3.json')
assert h['fingerprint'](position_dir/'handoff3.json')['sha256']=='80b3c81e6422e2cfc4a452dbbf310d113c13ebe7d2c494aff74f28521c6c17aa'
assert position['owned_count']==4 and matches(position['owned_source_identities'])
assert position['actual_enclosing_session']==9640 and position['actual_enclosing_exit_code']==0
assert position['tests']['focused_tests']==400 and position['tests']['focused_suites']==14 and position['tests']['full_web_tests']==1649 and position['tests']['full_web_suites']==130
assert h['fingerprint'](position_dir/position['owned_archive'])['sha256']==position['owned_archive_sha256']
with zipfile.ZipFile(position_dir/position['owned_archive']) as archive:
    assert set(archive.namelist())==set(position['owned_source_identities'])
    assert all(h['sha'](archive.read(name))==value for name,value in position['owned_source_identities'].items())
for step in position['checks']:
    assert step['exit_code']==0 and h['fingerprint'](position_dir/step['log'])['sha256']==step['log_sha256']
position_receipt=read('issue160-frontend/reading-position/'+position['verification_receipt'])
assert h['fingerprint'](position_dir/position['verification_receipt'])['sha256']==position['verification_receipt_sha256']
assert position_receipt['all_checks_passed'] and position_receipt['owned_unchanged_during_checks'] and position_receipt['web_unchanged_during_checks'] and position_receipt['domain_frozen_unchanged'] and position_receipt['pins_frozen_unchanged']
assessments=read('issue160-c2-corrective-assessments.json');assert assessments['candidate_source_count']==1074 and assessments['candidate_source_digest']==digest(before)
assert set(assessments['roles'])=={'software_architecture','ui_design','ux_design'} and all(v['verdict']=='PASS' for v in assessments['roles'].values())
oracle=read('issue160-access-oracle7/correction.json')
assert before['tests/e2e/ligand-profiles-access.spec.ts']==oracle['current_sha256']=='db41bf3f06baeca085aa043ef71c9420d07aceb868838e83ea1dd889124d0673'
assert h['fingerprint'](private/'issue160-access-oracle7/before-ligand-profiles-access.spec.ts')['sha256']==oracle['prior_sha256']
native_paths={1:private/'issue159-integration-root/native1',**{n:private/'issue160-integration-root'/('native'+str(n)) for n in range(2,8)}}
native=[];reports={}
for number,directory in native_paths.items():
    receipt=json.loads((directory/'receipt.json').read_text());report=json.loads((directory/'browser.json').read_text());reports[number]=report
    assert h['fingerprint'](directory/'raw.log')['sha256']==receipt['log_sha256']
    assert receipt['source_before']==receipt['source_after'] and receipt['source_unchanged']
    actual=json.loads((directory/'actual-enclosing.json').read_text())
    if 'receipt_sha256' in actual:assert actual['receipt_sha256']==h['fingerprint'](directory/'receipt.json')['sha256']
    expected_counts={1:(4,0,0),2:(8,0,0),3:(0,1,17),4:(4,1,11),5:(16,0,0),6:(0,1,17),7:(18,0,0)}
    assert tuple(report['stats'][k] for k in ['expected','unexpected','skipped'])==expected_counts[number]
    native.append(dict(run=number,physical_path=directory.relative_to(root).as_posix(),receipt=h['fingerprint'](directory/'receipt.json'),actual_enclosing=actual,source_count=len(receipt['source_before']),source_digest=digest(receipt['source_before']),stats=report['stats'],complete_gate=False))
final_native=json.loads((native_paths[7]/'receipt.json').read_text());final_actual=json.loads((native_paths[7]/'actual-enclosing.json').read_text())
assert final_native['source_after']==before and final_native['exit_code']==0
assert final_actual['actual_session']==69297 and final_actual['actual_exit']==0 and final_actual['receipt_sha256']==h['fingerprint'](native_paths[7]/'receipt.json')['sha256']
assert final_actual['browser_sha256']=='95fa74a7dd46c9c29da3a572f97c4eb88b878129d7db01fe4d04f36b7d414b34'==h['fingerprint'](native_paths[7]/'browser.json')['sha256']
stats=reports[7]['stats'];assert (stats['expected'],stats['unexpected'],stats['skipped'],stats['flaky'])==(18,0,0,0) and not reports[7]['errors']
items={};links=[];retained={};cache_omissions={}
def collect(directory,prefix):
    assert directory.is_dir() and not directory.is_symlink();count=0;omitted=[]
    for path in sorted(directory.rglob('*')):
        name=prefix+'/'+path.relative_to(directory).as_posix()
        if path.is_symlink():
            target=path.resolve();assert target.exists() and target.is_relative_to(directory.resolve())
            links.append(dict(member=name,raw_link_text=os.readlink(path),raw_link_bytes_base64=base64.b64encode(os.fsencode(os.readlink(path))).decode(),lstat_mode=path.lstat().st_mode,resolved_member=prefix+'/'+target.relative_to(directory.resolve()).as_posix(),target_is_directory=target.is_dir(),followed=False,within_owned_snapshot=True));continue
        if not path.is_file():continue
        if h['CACHE_PARTS'].intersection(path.parts) or path.suffix in {'.pyc','.pyo'}:omitted.append(path.relative_to(directory).as_posix());continue
        h['add'](items,name,path,reader_workspace=True);count+=1
    return count,omitted
roots=[d for d in sorted(private.iterdir()) if d.is_dir() and d.name.startswith('issue160') and d.name not in ['issue160-domain','issue160-domain-packet','issue160-c2-packet']]
roots.append(private/'issue159-integration-root')
for directory in roots:retained[directory.name],cache_omissions[directory.name]=collect(directory,'closed-evidence/'+directory.name)
for number in range(1,8):
    directory=Path('/tmp')/('neistra160-integrated-native'+str(number));retained[directory.name],cache_omissions[directory.name]=collect(directory,'owned-native-stores/'+directory.name)
for path in sorted(private.glob('issue160*.py')):h['add'](items,'operations/'+path.name,path)
for path in sorted(private.glob('issue160*.json')):h['add'](items,'root-evidence/'+path.name,path)
h['add'](items,'prior-c1/'+c1.name,c1);h['add'](items,'prior-c1/'+c1json.name,c1json)
for name in changed:h['add'](items,'current-changed-source/'+name,root/name)
h['add'](items,'operations/packager.py',Path(__file__))
capture_rows=[];scenario_rows=[]
def inspect_suites(suites):
    for suite in suites:
        for spec in suite.get('specs',[]):
            for test in spec.get('tests',[]):
                for result in test.get('results',[]):
                    assert result['retry']==0 and result['status']=='passed'
                    for attachment in result.get('attachments',[]):
                        if 'body' not in attachment:continue
                        body=base64.b64decode(attachment['body'],validate=True)
                        if attachment['contentType']=='image/png':
                            assert body[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',body[16:24])==(1440,861)
                            member='decoded-cdp/'+test['projectName']+'/'+str(len(capture_rows)+1).zfill(2)+'-'+attachment['name']+'.png'
                            h['add'](items,member,body)
                            capture_rows.append(dict(member=member,attachment_name=attachment['name'],runner_profile=test['projectName'],width=1440,height=861,**h['fingerprint'](body),source='Byte-exact base64 decoding from retained native7 browser report'))
                        elif attachment['name']=='actual-profile-access-zoom':
                            scenarios=json.loads(body)
                            for scenario in scenarios:
                                assert scenario['actualContext']=='persistent desktop Chromium'
                                assert all(value['width']==1440 and value['height']==861 for value in scenario['compositor'].values())
                                delta=scenario['inputAfter']['top']-scenario['inputBefore']['top'];assert abs(delta)<=1 and scenario['inputBefore']['hit'] and scenario['inputAfter']['hit']
                                scenario_rows.append(dict(runner_profile=test['projectName'],theme=scenario['theme'],factor=scenario['factor'],actual=scenario['actual'],actual_context=scenario['actualContext'],browser_css_viewport=scenario['size'],input_y_delta=delta,full_compositor_dimensions=scenario['compositor']))
        inspect_suites(suite.get('suites',[]))
inspect_suites(reports[7]['suites']);assert len(capture_rows)==24 and len(scenario_rows)==8
h['add'](items,'decoded-cdp-index.json',h['encoded'](dict(scope='Original24full1440x861CDPcapture bytes decoded for access; existing report also retains originals. No image editing or new browser execution.',captures=capture_rows,scenarios=scenario_rows)))
assert len(links)==60
h['add'](items,'owned-links.json',h['encoded'](dict(scope='Exact link metadata only; no active archive links or arbitrary link following. Resolved owned target bytes are retained separately.',links=links)))
original_identities={name:h['fingerprint'](body) for name,body in items.items()}
estimate=sum(h['compressed_size'](body) for body in items.values());assert estimate<76*1024*1024,('Report before strategy change',estimate)
after=q['current_identities'](root);assert after==before and q['tagged_identities']('HEAD')==baseline
proof=dict(scope='LocalC2source identities, not released-prerequisite qualification',head=head,baseline_count=len(baseline),baseline_source_identities=baseline,current_count=1074,current_digest=digest(before),current_before=before,current_after=after,current_unchanged=True,changed_or_new_count=80,changed_or_new_source_identities={name:before[name] for name in changed},deleted_sources=deleted,frozen_domain15=domain,pinned_unreleased159_dependencies13=pins,all_domain_and_pin_hashes_unchanged=True)
h['add'](items,'source-proof.json',h['encoded'](proof))
facts=dict(scope='Working local160C2profile vertical checkpoint and scoped D190correction evidence; NOTapplicationpush/readiness/fullperformance/releasequalification',repository='ManuelSe/Neistra',issue=160,parent=11,head_plus_working_changes=head,current_source_count=1074,current_source_digest=digest(before),changed_or_new_source_count=80,all_changed_code_tests_and_config_copied=True,baseline_fully_hashed=True,
    earlier_c1=dict(archive=c1.name,identity=c1_identity,metadata=c1_metadata_identity,domain_python=47,domain_typescript=220,original_metadata_api_python=49,scope='Closed earlier domain/API proof retained byte-identical; metadata API source is later replaced by an explicitly unreleased runtime overlay'),
    runtime_preparation=dict(version='0.36.0',planned160version='0.38.0',private_head='0017',project_archive_version=3,viewer_version=2,source159_local_checkpoint=snapshot2['source_head'],source159_is_released=False,original_snapshot1_borrowed_paths=49,source_snapshot2_changed_borrowed_paths=snapshot2['changed_borrowed49_runtime_paths'],root_format_only_correction=format_proof,complete_ast_equality_recomputed=True,domain15_and_pins13_unchanged=True,metadata_overlay_api49='Retained post-runtime-overlay49case proof is distinct from initial C1API49; no suite totals are summed.',fairness_api78=dict(actual_enclosing=api2_actual,passed=78,source_scope=553,ruff='PASS',owned_two_file_format='PASS',mypy=280),prior78_format_failure='Actual86376exit1:78cases andRuff pass, addedformat check fails on the two copied files; mypy did not run. Both original bodies and full Python AST equality are retained.'),
    frontend=dict(initial_and_correction2='All earlier frontend source archives, receipts and failed corrections retained. Correction2 passes329focused/1633global, actual26385; it predates D190.',d190=dict(handoff_sha256='80b3c81e6422e2cfc4a452dbbf310d113c13ebe7d2c494aff74f28521c6c17aa',four_source_identities=position['owned_source_identities'],actual_session=9640,actual_exit=0,focused=400,focused_suites=14,global_tests=1649,global_suites=130,lint='PASS',types='PASS',build='PASS',web_source_scope=359,source_archives_diff_and_logs_retained=True)),
    final_native=dict(actual_enclosing=final_actual,passed=18,failed=0,skipped=0,flaky=0,retries=0,browser_errors=0,source_count=1074,source_digest=digest(before),all_seven_runs_and_stores_retained=True,compositor_captures=24,compositor_dimensions=[1440,861],actual_theme_zoom_scenarios=8,actual_context='Two persistent desktop Chromium contexts, one under each runner profile label; four theme/zoom scenarios per context. No physical-mobile zoom claim.',input_y_deltas=sorted(set(row['input_y_delta'] for row in scenario_rows))),
    native_attempts=native,native_history='Native1 physical159label is inside this160tree, not159qualification. Native3 reproduces108pxreading-position failure. Native4 closes the real editor and legitimately cancels its draft: wrong new oracle. Native5corrected active-preview16case run passes. Native6post-D190 reaches held geometry but newly assumes unsupported cross-tab query persistence; source-identical legacy SelectionPanel local-reset is independently established. Native7changes only the test to assert default-empty and trusted requery, retaining all held READY/Y/focus/hit/async assertions.',
    native_oracle_correction=oracle,independent_scoped_assessments=assessments,scoped_three_roles_are_not_all_seven_final_approval=True,
    raw_retention=retained,link_metadata_count=60,named_cache_omissions=cache_omissions,estimated_deflate_before_metadata=estimate,no_159_37MB_packet_or_full_private_tree_included=True,
    limitations='Ad hoc native TypeScript attempts hit known helper upload/global/Vite typing issues; no wholeE2ETypeScript pass is claimed. UI/UX verdicts distinguish decoded24captures from representative visual inspection. Actual released159integration/version reconciliation, full performance/capacity, final same-candidate seven roles and full gates remain pending.',
    required_remaining=['Reconcile and integrate actual verified159deliverymaster/tag and all copied sources/versions before final160qualification','Complete scientific/UI/runtime integration and applicable performance/fullcandidate and exact-master gates','Obtain all seven final same-candidate assessments and normal protected PR/merge','Verify annotatedtag/publishedrelease/publicassets/childcloseout/ownedcleanup and parent program endpoint'])
h['add'](items,'checkpoint-context.json',h['encoded'](facts))
packet=h['archive'](items,a/'c2-evidence.zip');assert packet['bytes']<80*1024*1024
assert q['current_identities'](root)==before and q['tagged_identities']('HEAD')==baseline
assert all(h['fingerprint'](items[name])==identity for name,identity in original_identities.items())
assert h['fingerprint'](c1)==c1_identity and h['fingerprint'](c1json)==c1_metadata_identity
record=dict(**facts,archive=packet['file'],archive_bytes=packet['bytes'],archive_sha256=packet['sha256'],outer_manifest_entries=packet['outer_manifest_entries'],recursive_verification=packet['verification_counts'],all_payload_hashes_recursive_crcs_and_owned_source_stability_verified=True,original_c1_packet_and_metadata_unchanged=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
target=a/'c2-checkpoint.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
(out/'packager-result.json').write_text(json.dumps(dict(archive=packet,checkpoint=h['fingerprint'](target),current1074_unchanged=True,changed80_copied=True,c1_unchanged=True),indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
