from pathlib import Path
import subprocess,time,json,hashlib,sys
p=Path(__file__).parent
name=sys.argv[1]; cmd=sys.argv[2:]; start=time.time()
with (p/(name+".log")).open("wb") as log: code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
receipt={"command":cmd,"exit":code,"elapsed_seconds":time.time()-start,"log_sha256":hashlib.sha256((p/(name+".log")).read_bytes()).hexdigest()}
(p/(name+"-receipt.json")).write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt)); print((p/(name+".log")).read_text()[-12000:])
sys.exit(code)
