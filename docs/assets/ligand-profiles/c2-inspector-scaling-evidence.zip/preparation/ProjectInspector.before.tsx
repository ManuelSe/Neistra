import { useQueries } from "@tanstack/react-query";
import {
  AlertTriangle,
  ChevronRight,
  FilePenLine,
  LoaderCircle,
  Save,
  Ruler,
  Trash2,
  X,
} from "lucide-react";
import { useEffect, useId, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { isCompleteProjection, structureQueryOptions } from "../structures/query";
import type {
  Project,
  CoordinateTransform,
  LigandEdit,
  LigandEditResult,
  Measurement,
  MeasurementKind,
  ProteinEdit,
  ProteinEditResult,
  SavedSelection,
  Selection,
  SelectionGranularity,
  SelectionMode,
  SuperpositionRequest,
  SuperpositionResult,
} from "../api/types";
import {
  selectedEntryIds,
  selectionSummary,
  type PredicateField,
  type StructureMap,
} from "../selection/selection";
import { IconButton } from "./IconButton";
import { LigandEditorPanel } from "./LigandEditorPanel";
import { MeasurementsPanel } from "./MeasurementsPanel";
import { ProteinEditorPanel } from "./ProteinEditorPanel";
import { TransformPanel } from "./TransformPanel";
import { activateTabFromKeyboard } from "./tabKeyboard";
import type { MovementWorkflow } from "../coordinates/useMovementSession";

interface ProjectInspectorProps {
  ligandControls?: ReactNode;
  project: Project | undefined;
  selection: Selection;
  pickingGranularity: SelectionGranularity;
  busy: boolean;
  selectionBusy?: boolean;
  onApply: (name: string, description: string | null) => void;
  onApplySelection: (selection: Selection, mode: SelectionMode) => void;
  onPickingGranularity: (granularity: SelectionGranularity) => void;
  onClearSelection: () => void;
  onExpandSelection: (granularity: SelectionGranularity) => void;
  onInvertSelection: () => void;
  onPredicateSelection: (
    field: PredicateField,
    value: string,
    mode: SelectionMode,
  ) => void;
  onSpatialSelection: (
    distance: number,
    granularity: "atom" | "residue",
    mode: SelectionMode,
  ) => void;
  onSaveSelection: (name: string) => void;
  onLoadSelection: (saved: SavedSelection) => void;
  onDeleteSelection: (saved: SavedSelection) => void;
  onCreateMeasurement?: (name: string, kind: MeasurementKind) => void;
  onOpenMeasurements?: () => void;
  onUpdateMeasurement?: (
    measurement: Measurement,
    name: string,
    visible: boolean,
  ) => void;
  onDeleteMeasurement?: (measurement: Measurement) => void;
  onPreviewTransform?: (transform: CoordinateTransform) => Promise<void>;
  onClearTransformPreview?: () => void;
  onTransform?: (transform: CoordinateTransform) => Promise<void>;
  onSuperpose?: (
    payload: SuperpositionRequest,
  ) => Promise<SuperpositionResult["report"] | null>;
  onLigandEdit?: (
    entryId: string,
    edit: LigandEdit,
  ) => Promise<LigandEditResult>;
  onProteinEdit?: (
    entryId: string,
    edit: ProteinEdit,
  ) => Promise<ProteinEditResult>;
  onCollapse?: () => void;
  movement?: MovementWorkflow;
  onInspectorTaskChange?: () => void;
}

function InspectPanel({
  project,
  selection,
  structures,
}: Pick<ProjectInspectorProps, "project" | "selection"> & {
  structures: StructureMap;
}) {
  const reference = selection.atoms[0];
  const entry = project?.entries.find((item) => item.id === reference?.structure_id);
  const structure = reference ? structures.get(reference.structure_id) : undefined;
  const atom = structure?.atoms.find((item) => item.id === reference?.atom_id);
  const residue = structure?.residues.find((item) => item.id === atom?.residue_id);
  const chain = structure?.chains.find((item) => item.id === residue?.chain_id);
  if (!entry || !atom) {
    return <p className="empty-label">Select an atom to inspect molecular properties.</p>;
  }
  const residueAtoms = structure?.atoms.filter((item) => item.residue_id === residue?.id) ?? [];
  const chainResidueIds = new Set(
    structure?.residues
      .filter((item) => item.chain_id === chain?.id)
      .map((item) => item.id) ?? [],
  );
  return (
    <div className="inspect-panel">
      <section>
        <h3>Atom</h3>
        <dl className="property-list">
          <div><dt>Full name</dt><dd>{entry.name} / {atom.name}</dd></div>
          <div><dt>Element</dt><dd>{atom.element}</dd></div>
          <div><dt>Coordinates</dt><dd>{atom.coordinates.map((value) => value.toFixed(3)).join(", ")}</dd></div>
          <div><dt>Residue</dt><dd>{residue ? `${residue.name} ${residue.author_number ?? residue.label_number ?? residue.id}` : "None"}</dd></div>
          <div><dt>Chain</dt><dd>{chain?.name || "None"}</dd></div>
          <div><dt>Formal charge</dt><dd>{atom.formal_charge ?? "Unknown"}</dd></div>
          <div><dt>Atom index</dt><dd>{atom.id}</dd></div>
        </dl>
      </section>
      {residue ? (
        <section>
          <h3>Residue</h3>
          <dl className="property-list">
            <div><dt>Name</dt><dd>{residue.name}</dd></div>
            <div><dt>Number</dt><dd>{residue.author_number ?? residue.label_number ?? residue.id}</dd></div>
            <div><dt>Component</dt><dd>{residue.component_type}</dd></div>
            <div><dt>Atoms</dt><dd>{residueAtoms.length}</dd></div>
          </dl>
        </section>
      ) : null}
      {chain ? (
        <section>
          <h3>Chain</h3>
          <dl className="property-list">
            <div><dt>Name</dt><dd>{chain.name || "-"}</dd></div>
            <div><dt>Entity</dt><dd>{chain.entity_type}</dd></div>
            <div><dt>Residues</dt><dd>{chainResidueIds.size}</dd></div>
            <div><dt>Atoms</dt><dd>{structure?.atoms.filter((item) => item.residue_id && chainResidueIds.has(item.residue_id)).length ?? 0}</dd></div>
          </dl>
        </section>
      ) : null}
    </div>
  );
}

function DetailsPanel({
  project,
  busy,
  onApply,
}: Pick<ProjectInspectorProps, "project" | "busy" | "onApply">) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  useEffect(() => {
    setName(project?.name ?? "");
    setDescription(project?.description ?? "");
  }, [project?.description, project?.id, project?.name]);
  if (!project) {
    return (
      <div className="empty-panel">
        <FilePenLine size={28} />
        <p>No project selected</p>
      </div>
    );
  }
  const changed =
    name !== project.name || description !== (project.description ?? "");
  return (
    <form
      className="inspector-form"
      onSubmit={(event) => {
        event.preventDefault();
        if (name.trim() && changed) onApply(name.trim(), description.trim() || null);
      }}
    >
      <label>
        Name
        <input
          value={name}
          maxLength={120}
          onChange={(event) => setName(event.target.value)}
          required
        />
      </label>
      <label>
        Description
        <textarea
          value={description}
          maxLength={2000}
          rows={4}
          onChange={(event) => setDescription(event.target.value)}
        />
      </label>
      <dl className="project-facts">
        <div>
          <dt>Structures</dt>
          <dd>{project.entries.length}</dd>
        </div>
        <div>
          <dt>Revision</dt>
          <dd>{project.revision}</dd>
        </div>
        <div>
          <dt>Checkpoint</dt>
          <dd>{project.checkpoint_revision}</dd>
        </div>
      </dl>
      <button
        className="primary-button"
        type="submit"
        disabled={!changed || busy || !name.trim()}
      >
        Apply changes
      </button>
    </form>
  );
}

function SelectionPanel({
  project,
  selection,
  pickingGranularity,
  structures,
  busy,
  onClearSelection,
  onPickingGranularity,
  onExpandSelection,
  onInvertSelection,
  onPredicateSelection,
  onSpatialSelection,
  onSaveSelection,
  onLoadSelection,
  onDeleteSelection,
}: Pick<
  ProjectInspectorProps,
  | "project"
  | "selection"
  | "pickingGranularity"
  | "onClearSelection"
  | "onPickingGranularity"
  | "onExpandSelection"
  | "onInvertSelection"
  | "onPredicateSelection"
  | "onSpatialSelection"
  | "onSaveSelection"
  | "onLoadSelection"
  | "onDeleteSelection"
> & { structures: StructureMap; busy: boolean }) {
  const [mode, setMode] = useState<SelectionMode>("replace");
  const [field, setField] = useState<PredicateField>("atom_name");
  const [value, setValue] = useState("");
  const [distance, setDistance] = useState("4");
  const [distanceGranularity, setDistanceGranularity] =
    useState<"atom" | "residue">("atom");
  const [savedName, setSavedName] = useState("");
  const summary = selectionSummary(selection, structures);

  return (
    <div className="selection-panel">
      <dl className="selection-summary" aria-label="Current selection summary">
        <div><dt>Atoms</dt><dd>{summary.atoms}</dd></div>
        <div><dt>Residues</dt><dd>{summary.residues}</dd></div>
        <div><dt>Chains</dt><dd>{summary.chains}</dd></div>
        <div><dt>Structures</dt><dd>{summary.structures}</dd></div>
      </dl>
      <div className="selection-meta">
        <span>{selection.granularity}</span>
        <span>from {selection.source}</span>
        {busy ? <LoaderCircle size={14} aria-label="Running selection operation" /> : null}
      </div>
      <div className="selection-toolbar">
        <button type="button" onClick={onClearSelection} disabled={selection.atoms.length === 0}>
          <X size={15} /> Clear
        </button>
        <button type="button" onClick={onInvertSelection} disabled={!project?.entries.length || busy}>
          Invert
        </button>
      </div>

      <fieldset className="selection-section">
        <legend>Operation mode</legend>
        <div className="segmented-control">
          {(["replace", "add", "subtract"] as const).map((item) => (
            <button
              type="button"
              key={item}
              className={mode === item ? "active" : ""}
              aria-pressed={mode === item}
              onClick={() => setMode(item)}
            >
              {item}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset className="selection-section">
        <legend>Viewer pick</legend>
        <div className="segmented-control four">
          {(["atom", "residue", "chain", "structure"] as const).map((item) => (
            <button
              type="button"
              key={item}
              className={pickingGranularity === item ? "active" : ""}
              aria-pressed={pickingGranularity === item}
              onClick={() => onPickingGranularity(item)}
            >
              {item}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset className="selection-section">
        <legend>Expand current</legend>
        <div className="selection-toolbar three">
          {(["residue", "chain", "structure"] as const).map((granularity) => (
            <button
              type="button"
              key={granularity}
              disabled={selection.atoms.length === 0 || busy}
              onClick={() => onExpandSelection(granularity)}
            >
              {granularity}
            </button>
          ))}
        </div>
      </fieldset>

      <form
        className="selection-section selection-form"
        onSubmit={(event) => {
          event.preventDefault();
          if (value.trim()) onPredicateSelection(field, value, mode);
        }}
      >
        <label>
          Select by
          <select value={field} onChange={(event) => setField(event.target.value as PredicateField)}>
            <option value="atom_name">Atom name</option>
            <option value="atom_index">Atom index</option>
            <option value="atom_reference">Structure:atom reference</option>
            <option value="element">Element</option>
            <option value="residue_name">Residue name</option>
            <option value="residue_number">Residue number</option>
            <option value="chain">Chain</option>
            <option value="structure">Structure ID</option>
          </select>
        </label>
        <label>
          Value
          <input value={value} onChange={(event) => setValue(event.target.value)} />
        </label>
        <button className="secondary-button" type="submit" disabled={!value.trim() || busy}>
          Apply query
        </button>
      </form>

      <form
        className="selection-section selection-form"
        onSubmit={(event) => {
          event.preventDefault();
          const parsed = Number(distance);
          if (Number.isFinite(parsed) && parsed >= 0) {
            onSpatialSelection(parsed, distanceGranularity, mode);
          }
        }}
      >
        <div className="form-row">
          <label>
            Within (angstrom)
            <input
              type="number"
              min="0"
              step="0.1"
              value={distance}
              onChange={(event) => setDistance(event.target.value)}
            />
          </label>
          <label>
            Result
            <select
              value={distanceGranularity}
              onChange={(event) =>
                setDistanceGranularity(event.target.value as "atom" | "residue")
              }
            >
              <option value="atom">Atoms</option>
              <option value="residue">Residues</option>
            </select>
          </label>
        </div>
        <button
          className="secondary-button"
          type="submit"
          disabled={selection.atoms.length === 0 || busy}
        >
          Run distance selection
        </button>
      </form>

      <form
        className="selection-section save-selection"
        onSubmit={(event) => {
          event.preventDefault();
          if (savedName.trim()) {
            onSaveSelection(savedName.trim());
            setSavedName("");
          }
        }}
      >
        <label>
          Saved selections
          <span className="input-with-button">
            <input
              value={savedName}
              maxLength={120}
              placeholder="Selection name"
              onChange={(event) => setSavedName(event.target.value)}
            />
            <button
              type="submit"
              className="icon-submit"
              aria-label="Save current selection"
              disabled={!savedName.trim() || selection.atoms.length === 0 || busy}
            >
              <Save size={15} />
            </button>
          </span>
        </label>
        <div className="saved-selection-list">
          {project?.saved_selections?.length ? (
            project.saved_selections.map((saved) => (
              <div key={saved.id} className="saved-selection-row">
                <button type="button" onClick={() => onLoadSelection(saved)}>
                  <span>{saved.name}</span>
                  <small>{saved.atom_references.length} atoms</small>
                </button>
                {saved.warnings.length > 0 ? (
                  <span
                    className="saved-warning"
                    title={saved.warnings.map((warning) => warning.message).join("\n")}
                    aria-label={`${saved.warnings.length} saved selection warnings`}
                  >
                    <AlertTriangle size={14} />
                  </span>
                ) : null}
                <IconButton
                  label={`Delete saved selection ${saved.name}`}
                  onClick={() => onDeleteSelection(saved)}
                >
                  <Trash2 size={14} />
                </IconButton>
              </div>
            ))
          ) : (
            <p className="empty-label">No saved selections</p>
          )}
        </div>
      </form>
    </div>
  );
}

export function ProjectInspector(props: ProjectInspectorProps) {
  const tabId = useId();
  const { project, selection, onCollapse, ligandControls } = props;
  const [tab, setTab] = useState<
    | "selection"
    | "inspect"
    | "measurements"
    | "transform"
    | "ligand"
    | "protein"
    | "details"
  >(props.movement?.state.capture ? "transform" : "selection");
  const automaticallyOpenedDetails = useRef(false);
  const scrollOwner = useRef<HTMLDivElement>(null);
  const tabList = useRef<HTMLDivElement>(null);
  const [taskScrollRequest, requestTaskScroll] = useState(0);
  useLayoutEffect(() => {
    if (!taskScrollRequest || !scrollOwner.current || !tabList.current) return;
    const owner = scrollOwner.current;
    owner.scrollTop = Math.max(0, owner.scrollTop + tabList.current.getBoundingClientRect().top - owner.getBoundingClientRect().top);
  }, [taskScrollRequest]);
  const projectId = project?.id;
  const entryCount = project?.entries.length;
  useEffect(() => {
    if (entryCount === undefined) return;
    if (entryCount === 0) {
      automaticallyOpenedDetails.current = true;
      setTab("details");
    } else if (automaticallyOpenedDetails.current) {
      automaticallyOpenedDetails.current = false;
      setTab("selection");
    }
  }, [entryCount, projectId]);
  const relevantIds = useMemo(() => {
    const ids = new Set(
      project?.entries.filter((entry) => entry.visible).map((entry) => entry.id),
    );
    for (const entry of project?.entries ?? []) {
      if (
        entry.structure_type === "ligand" ||
        entry.structure_type === "protein" ||
        entry.structure_type === "complex"
      ) {
        ids.add(entry.id);
      }
    }
    for (const entryId of selectedEntryIds(selection)) ids.add(entryId);
    return [...ids];
  }, [project?.entries, selection]);
  const structureQueries = useQueries({
    queries: relevantIds.map((entryId) => {
      const entry = project?.entries.find((item) => item.id === entryId);
      return {
        ...structureQueryOptions(project?.id ?? "", entryId, entry?.current_artifact_id),
      };
    }),
  });
  const structures = useMemo(
    () =>
      new Map(
        structureQueries.flatMap((query, index) => {
          const entry = project?.entries.find(item => item.id === relevantIds[index]);
          return !query.isError && !query.isPlaceholderData
            && isCompleteProjection(query.data, relevantIds[index], entry?.current_artifact_id)
            ? [[query.data.entry_id, query.data.structure] as const] : [];
        }),
      ),
    [structureQueries, project?.entries, relevantIds],
  );
  return (
    <section className="panel-content project-inspector" aria-label="Project inspector">
      <div className="panel-header inspector-header">
        <div>
          <span className="panel-eyebrow">Inspector</span>
          <h2>
            {tab === "selection"
              ? "Selection"
              : tab === "inspect"
                ? "Inspect"
                : tab === "measurements"
                  ? "Measurements"
                  : tab === "transform"
                    ? "Transform"
                    : tab === "ligand"
                      ? "Ligand"
                    : tab === "protein"
                      ? "Protein"
                    : "Project"}
          </h2>
        </div>
        {onCollapse ? (
          <IconButton label="Collapse inspector" onClick={onCollapse}>
            <ChevronRight size={17} />
          </IconButton>
        ) : null}
      </div>
      <div className="inspector-scroll" ref={scrollOwner} data-inspector-visit={JSON.stringify([project?.id ?? "", tab, taskScrollRequest])}>
        {ligandControls}
        <div
          ref={tabList}
          className="inspector-tabs"
          role="tablist"
          aria-label="Inspector views"
          onKeyDown={activateTabFromKeyboard}
        >
          {(["selection", "inspect", "measurements", "transform", "ligand", "protein", "details"] as const).map((item) => (
            <button
              type="button"
              role="tab"
              id={`${tabId}-${item}`}
              aria-controls={`${tabId}-panel`}
              aria-selected={tab === item}
              tabIndex={tab === item ? 0 : -1}
              key={item}
              onClick={() => {
                if (item !== tab) props.onInspectorTaskChange?.();
                automaticallyOpenedDetails.current = false;
                setTab(item);
                requestTaskScroll(value => value + 1);
              }}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="inspector-body" id={`${tabId}-panel`} role="tabpanel"
          aria-labelledby={`${tabId}-${tab}`} tabIndex={0}>
          {tab === "selection" ? (
            <SelectionPanel
              {...props}
              structures={structures}
              busy={props.busy || !!props.selectionBusy}
            />
          ) : tab === "inspect" ? (
            <InspectPanel project={project} selection={selection} structures={structures} />
          ) : tab === "measurements" && project ? (
            props.onOpenMeasurements ? <button type="button" className="secondary-button" onClick={props.onOpenMeasurements}>
              <Ruler size={17} aria-hidden="true" />Open measurements
            </button> : <MeasurementsPanel
              project={project}
              selection={selection}
              structures={structures}
              busy={props.busy}
              onCreate={props.onCreateMeasurement ?? (() => undefined)}
              onUpdate={props.onUpdateMeasurement ?? (() => undefined)}
              onDelete={props.onDeleteMeasurement ?? (() => undefined)}
              onSelectContact={(next) => props.onApplySelection(next, "replace")}
            />
          ) : tab === "transform" && project ? (
            <TransformPanel
              project={project}
              selection={selection}
              busy={props.busy}
              movement={props.movement}
              onPreview={
                props.onPreviewTransform ?? (() => Promise.resolve())
              }
              onClearPreview={props.onClearTransformPreview ?? (() => undefined)}
              onTransform={props.onTransform ?? (() => Promise.resolve())}
              onSuperpose={props.onSuperpose ?? (() => Promise.resolve(null))}
            />
          ) : tab === "ligand" && project ? (
            <LigandEditorPanel key={project.id}
              project={project}
              selection={selection}
              structures={structures}
              busy={props.busy}
              onEdit={
                props.onLigandEdit ??
                (() => Promise.reject(new Error("Ligand editing is unavailable.")))
              }
              onMove={props.onTransform ?? (() => Promise.resolve())}
            />
          ) : tab === "protein" && project ? (
            <ProteinEditorPanel
              project={project}
              selection={selection}
              structures={structures}
              busy={props.busy}
              onEdit={
                props.onProteinEdit ??
                (() => Promise.reject(new Error("Protein editing is unavailable.")))
              }
              onMove={props.onTransform ?? (() => Promise.resolve())}
            />
          ) : (
            <DetailsPanel project={project} busy={props.busy} onApply={props.onApply} />
          )}
        </div>
      </div>
    </section>
  );
}
