import type { HydrogenPolicy, ModelPlacementAction, ModelPreview, MoleculeCreateResult } from "./types";
import type {
  ApiErrorBody,
  ArtifactSourceIdentity,
  SourceIdentityEvidence,
  AtomReference,
  CameraState,
  Contact,
  CoordinateTransform,
  SelectionTransform,
  ArchiveExportResult,
  ArchiveImportResult,
  BatchExportResult,
  ExportEntryReport,
  ExportMode,
  ExportScope,
  ExportResult,
  FormatCapability,
  ImportResult,
  LigandEdit,
  LigandEditResult,
  SelectionEditAction,
  SelectionEditResult,
  MolecularWarning,
  Project,
  ProjectListItem,
  MeasurementKind,
  ProteinEdit,
  ProteinEditResult,
  Scene,
  Selection,
  SelectionRepresentationStyle,
  SelectionRepresentationChannel,
  SelectionAppearanceChange,
  StructureProjection,
  SuperpositionRequest,
  SuperpositionResult,
  ViewerSettings,
  SurfaceCreateItem,
  SurfaceChange,
  Job,
  JobDefinition,
  JobEvent,
  JobResultImport,
  NormalizedStructure,
  EditAttemptReceipt,
  MinimizationCapabilities,
  MinimizationRequest,
  MinimizationProposal,
  MinimizationLive,
  QuickMinimizationRequest,
  QuickMinimizationProposal,
  QuickMinimizationCapabilities,
} from "./types";
import type { InteractionInput, InteractionResult } from "../interactions/types";
import type { WorkspacePresentationApi, WorkspacePresentationV1 } from "../workspacePresentation/types";

export const interactionApi = {
  analyze: (projectId: string, inputs: InteractionInput[], signal: AbortSignal) => request<InteractionResult>(`/api/v1/projects/${projectId}/interactions`, {
    method: "POST", signal, body: JSON.stringify({ inputs, profile: "interaction-v1", frame: "workspace-cartesian" }),
  }),
};

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly warnings: MolecularWarning[];
  readonly reports: ExportEntryReport[];
  readonly retryAfterMs: number | null;
  readonly sourceVerification: "current" | "original" | null;
  readonly sourceIdentity: SourceIdentityEvidence;
  readonly sourceVerificationInvalid: boolean;

  constructor(
    status: number,
    code: string,
    message: string,
    warnings: MolecularWarning[] = [],
    reports: ExportEntryReport[] = [],
    retryAfterMs: number | null = null,
    sourceVerification: "current" | "original" | null = null,
    sourceIdentity: SourceIdentityEvidence = { kind: "absent" },
    sourceVerificationInvalid = false,
  ) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.warnings = warnings;
    this.reports = reports;
    this.retryAfterMs = retryAfterMs;
    this.sourceVerification = sourceVerification;
    this.sourceIdentity = sourceIdentity;
    this.sourceVerificationInvalid = sourceVerificationInvalid;
  }
}

function sourceIdentityEvidence(detail: ApiErrorBody["detail"]): SourceIdentityEvidence {
  if (typeof detail !== "object" || detail === null || !Object.hasOwn(detail, "source_identity")) return { kind: "absent" };
  const value = detail.source_identity;
  if (typeof value !== "object" || value === null || Array.isArray(value)) return { kind: "invalid" };
  const source = value as Partial<ArtifactSourceIdentity>;
  if (typeof source.project_id !== "string" || !source.project_id || typeof source.entry_id !== "string" || !source.entry_id
    || (typeof source.current_artifact_id !== "string" && source.current_artifact_id !== null)
    || (typeof source.original_artifact_id !== "string" && source.original_artifact_id !== null)
    || source.current_artifact_id === "" || source.original_artifact_id === "") return { kind: "invalid" };
  return { kind: "valid", identity: { project_id: source.project_id, entry_id: source.entry_id,
    current_artifact_id: source.current_artifact_id, original_artifact_id: source.original_artifact_id } };
}

function apiError(status: number, body: ApiErrorBody, retryAfter: string | null = null): ApiError {
  const detail = body.detail;
  const message =
    typeof detail === "object" && detail?.message
      ? detail.message
      : typeof detail === "string"
        ? detail
        : `Request failed with status ${status}`;
  const code = typeof detail === "object" && detail?.code ? detail.code : "request_failed";
  const warnings = typeof detail === "object" ? (detail?.warnings ?? []) : [];
  const reports = typeof detail === "object" ? (detail?.reports ?? []) : [];
  const retryAfterMs = retryAfter !== null && /^\d+(?:\.\d+)?$/.test(retryAfter)
    ? Number(retryAfter) * 1000 : null;
  return new ApiError(status, code, message, warnings, reports,
    retryAfterMs !== null && Number.isFinite(retryAfterMs) ? retryAfterMs : null,
    typeof detail === "object" && (detail?.source_verification === "current" || detail?.source_verification === "original")
      ? detail.source_verification : null, sourceIdentityEvidence(detail),
    typeof detail === "object" && detail !== null && Object.hasOwn(detail, "source_verification")
      && detail.source_verification !== "current" && detail.source_verification !== "original");
}

async function request<ResponseType>(
  path: string,
  init?: RequestInit,
): Promise<ResponseType> {
  let response: globalThis.Response;
  try {
    response = await fetch(path, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...init?.headers,
      },
    });
  } catch (error) {
    if (init?.signal?.aborted) throw error;
    throw new ApiError(0, "network_error", "Neistra could not reach the local API.");
  }

  if (!response.ok) {
    const body = (await response.json().catch(() => ({}))) as ApiErrorBody;
    throw apiError(response.status, body, response.headers.get("Retry-After"));
  }
  return (await response.json()) as ResponseType;
}

export const workspacePresentationApi: WorkspacePresentationApi = {
  read: () => request<WorkspacePresentationV1>("/api/v1/workspace/presentation"),
  write: (camera, expectedRevision, options) => request<WorkspacePresentationV1>("/api/v1/workspace/presentation", {
    method: "PUT", keepalive: options?.keepalive,
    body: JSON.stringify({ expected_revision: expectedRevision, camera }),
  }),
};

export const projectApi = {
  editAttempt: (projectId: string, attemptId: string) => request<EditAttemptReceipt>(
    `/api/v1/projects/${projectId}/edit-attempts/${attemptId}`,
  ),
  list: () => request<ProjectListItem[]>("/api/v1/projects"),
  get: (projectId: string) => request<Project>(`/api/v1/projects/${projectId}`),
  create: (name: string, description: string | null) =>
    request<Project>("/api/v1/projects", {
      method: "POST",
      body: JSON.stringify({ name, description }),
    }),
  update: (project: Project, name: string, description: string | null) =>
    request<Project>(`/api/v1/projects/${project.id}`, {
      method: "PATCH",
      body: JSON.stringify({
        expected_revision: project.revision,
        name,
        description,
      }),
    }),
  save: (project: Project) =>
    request<Project>(`/api/v1/projects/${project.id}/save`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision }),
    }),
  undo: (project: Project) =>
    request<Project>(`/api/v1/projects/${project.id}/history/undo`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision }),
    }),
  redo: (project: Project) =>
    request<Project>(`/api/v1/projects/${project.id}/history/redo`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision }),
    }),
  transformSelection: (project: Project, transform: SelectionTransform) =>
    request<Project>(`/api/v1/projects/${project.id}/selection-transform`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision, ...transform }),
    }),
  transform: (project: Project, transform: CoordinateTransform) =>
    request<Project>(
      `/api/v1/projects/${project.id}/entries/${transform.entry_id}/transform`,
      {
        method: "POST",
        body: JSON.stringify({
          expected_revision: project.revision,
          ...transform,
        }),
      },
    ),
  superpose: (project: Project, payload: SuperpositionRequest) =>
    request<SuperpositionResult>(`/api/v1/projects/${project.id}/superpositions`, {
      method: "POST",
      body: JSON.stringify({
        expected_revision: project.revision,
        ...payload,
      }),
    }),
  ligandEdit: (project: Project, entryId: string, payload: LigandEdit) =>
    request<LigandEditResult>(
      `/api/v1/projects/${project.id}/entries/${entryId}/ligand-edits`,
      {
        method: "POST",
        body: JSON.stringify({
          expected_revision: project.revision,
          ...payload,
        }),
      },
    ),
  selectionEdit: (project: Project, entryId: string, artifactId: string, selection: Selection, action: SelectionEditAction, hydrogenPolicy: HydrogenPolicy = "preserve", attemptId?: string) =>
    request<SelectionEditResult>(`/api/v1/projects/${project.id}/entries/${entryId}/${["residue.mutate", "hydrogens.prepare", "fragment.replace", "atom.charge", "bond.create", "bond.order"].includes(action.operation) ? "selection-edits" : "model-edits"}`, {
      method: "POST", headers: attemptId ? { "X-Neistra-Edit-Attempt": attemptId } : undefined, body: JSON.stringify({ expected_revision: project.revision,
        expected_artifact_id: artifactId, selection, action, ...(!["residue.mutate", "hydrogens.prepare", "fragment.replace", "atom.charge", "bond.create", "bond.order"].includes(action.operation) ? { hydrogen_policy: hydrogenPolicy } : {}) }),
    }),
  modelPreview: (project: Project, entryId: string, artifactId: string, selection: Selection, action: ModelPlacementAction, hydrogenPolicy: HydrogenPolicy, signal?: AbortSignal) =>
    request<ModelPreview>(`/api/v1/projects/${project.id}/entries/${entryId}/model-edits/preview`, {
      method: "POST", signal, body: JSON.stringify({ expected_revision: project.revision,
        expected_artifact_id: artifactId, selection, action, hydrogen_policy: hydrogenPolicy }),
    }),
  createMolecule: (project: Project, payload: { name: string; element: string; charge: number | null }) =>
    request<MoleculeCreateResult>(`/api/v1/projects/${project.id}/molecules`, {
      method: "POST", body: JSON.stringify({ expected_revision: project.revision, ...payload }),
    }),
  proteinEdit: (project: Project, entryId: string, payload: ProteinEdit) =>
    request<ProteinEditResult>(
      `/api/v1/projects/${project.id}/entries/${entryId}/protein-edits`,
      {
        method: "POST",
        body: JSON.stringify({
          expected_revision: project.revision,
          ...payload,
        }),
      },
    ),
  updateEntry: (
    project: Project,
    entryId: string,
    values: {
      name: string;
      description: string | null;
      user_metadata: Record<string, unknown>;
    },
  ) =>
    request<Project>(`/api/v1/projects/${project.id}/entries/${entryId}`, {
      method: "PATCH",
      body: JSON.stringify({ expected_revision: project.revision, ...values }),
    }),
  duplicateEntry: (project: Project, entryId: string) =>
    request<Project>(`/api/v1/projects/${project.id}/entries/${entryId}/duplicate`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision }),
    }),
  setEntryVisibility: (project: Project, entryId: string, value: boolean) =>
    request<Project>(`/api/v1/projects/${project.id}/entries/${entryId}/visibility`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision, value }),
    }),
  setEntryLock: (project: Project, entryId: string, value: boolean) =>
    request<Project>(`/api/v1/projects/${project.id}/entries/${entryId}/lock`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision, value }),
    }),
  isolateEntry: (project: Project, entryId: string) =>
    request<Project>(`/api/v1/projects/${project.id}/entries/${entryId}/isolate`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision }),
    }),
  deleteEntry: (project: Project, entryId: string) =>
    request<Project>(
      `/api/v1/projects/${project.id}/entries/${entryId}?expected_revision=${project.revision}`,
      { method: "DELETE" },
    ),
  createGroup: (project: Project, name: string, entryIds: string[], selection?: Selection) =>
    request<Project>(`/api/v1/projects/${project.id}/groups`, {
      method: "POST",
      body: JSON.stringify({
        expected_revision: project.revision,
        name,
        entry_ids: entryIds,
        selection,
      }),
    }),
  updateGroupMembership: (project: Project, entryIds: string[], groupId: string | null, selection?: Selection) =>
    request<Project>(`/api/v1/projects/${project.id}/group-membership`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision, entry_ids: entryIds, group_id: groupId, selection }),
    }),
  saveSelection: (project: Project, name: string, selection: Selection) =>
    request<Project>(`/api/v1/projects/${project.id}/selections`, {
      method: "POST",
      body: JSON.stringify({
        expected_revision: project.revision,
        name,
        selection,
      }),
    }),
  deleteSelection: (project: Project, selectionId: string) =>
    request<Project>(
      `/api/v1/projects/${project.id}/selections/${selectionId}?expected_revision=${project.revision}`,
      { method: "DELETE" },
    ),
  updateViewerSettings: (
    project: Project,
    entryId: string,
    settings: ViewerSettings,
  ) =>
    request<Project>(
      `/api/v1/projects/${project.id}/entries/${entryId}/viewer-settings`,
      {
        method: "PUT",
        body: JSON.stringify({
          expected_revision: project.revision,
          settings,
        }),
      },
    ),
  updateSelectionAtomVisibility: (project: Project, selection: Selection, action: "hide" | "show") =>
    request<Project>(`/api/v1/projects/${project.id}/selection-atom-visibility`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision, selection, action }),
    }),
  createSurfaceObjects: (project: Project, surfaces: SurfaceCreateItem[]) =>
    request<Project>(`/api/v1/projects/${project.id}/surfaces`, {
      method: "POST", body: JSON.stringify({ expected_revision: project.revision, surfaces }),
    }),
  updateSurfaceObject: (project: Project, entryId: string, surfaceId: string, change: SurfaceChange) =>
    request<Project>(`/api/v1/projects/${project.id}/entries/${entryId}/surfaces/${surfaceId}`, {
      method: "PATCH", body: JSON.stringify({ expected_revision: project.revision, ...change }),
    }),
  removeSurfaceObject: (project: Project, entryId: string, surfaceId: string) =>
    request<Project>(`/api/v1/projects/${project.id}/entries/${entryId}/surfaces/${surfaceId}`, {
      method: "DELETE", body: JSON.stringify({ expected_revision: project.revision }),
    }),
  updateSelectionAppearance: (project: Project, selection: Selection, change: SelectionAppearanceChange) =>
    request<Project>(`/api/v1/projects/${project.id}/selection-appearance`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision, selection, ...change }),
    }),
  updateSelectionRepresentations: (
    project: Project,
    selection: Selection,
    action: "apply" | "reset",
    style?: SelectionRepresentationStyle,
    channel?: SelectionRepresentationChannel,
  ) =>
    request<Project>(`/api/v1/projects/${project.id}/selection-representations`, {
      method: "POST",
      body: JSON.stringify({
        expected_revision: project.revision,
        selection,
        action,
        ...(style ? { style } : {}),
        ...(channel ? { channel } : {}),
      }),
    }),
  createMeasurement: (
    project: Pick<Project, "id" | "revision">,
    name: string,
    kind: MeasurementKind,
    atomReferences: readonly AtomReference[],
  ) =>
    request<Project>(`/api/v1/projects/${project.id}/measurements`, {
      method: "POST",
      body: JSON.stringify({
        expected_revision: project.revision,
        name,
        kind,
        atom_references: atomReferences,
      }),
    }),
  updateMeasurement: (
    project: Project,
    measurementId: string,
    name: string,
    visible: boolean,
  ) =>
    request<Project>(
      `/api/v1/projects/${project.id}/measurements/${measurementId}`,
      {
        method: "PATCH",
        body: JSON.stringify({
          expected_revision: project.revision,
          name,
          visible,
        }),
      },
    ),
  deleteMeasurement: (project: Project, measurementId: string) =>
    request<Project>(
      `/api/v1/projects/${project.id}/measurements/${measurementId}?expected_revision=${project.revision}`,
      { method: "DELETE" },
    ),
  createScene: (
    project: Project,
    name: string,
    camera: CameraState,
    selection: Selection,
  ) =>
    request<Project>(`/api/v1/projects/${project.id}/scenes`, {
      method: "POST",
      body: JSON.stringify({
        expected_revision: project.revision,
        name,
        camera,
        selection,
      }),
    }),
  applyScene: (project: Project, scene: Scene) =>
    request<Project>(`/api/v1/projects/${project.id}/scenes/${scene.id}/apply`, {
      method: "POST",
      body: JSON.stringify({ expected_revision: project.revision }),
    }),
  deleteScene: (project: Project, scene: Scene) =>
    request<Project>(
      `/api/v1/projects/${project.id}/scenes/${scene.id}?expected_revision=${project.revision}`,
      { method: "DELETE" },
    ),
  contacts: (
    project: Pick<Project, "id">,
    entryId: string,
    cutoff: number,
    minimumDistance: number,
    options?: { expectedArtifactId?: string; signal?: AbortSignal },
  ) =>
    request<Contact[]>(`/api/v1/projects/${project.id}/contacts`, {
      method: "POST",
      signal: options?.signal,
      body: JSON.stringify({
        entry_id: entryId,
        cutoff,
        minimum_distance: minimumDistance,
        expected_artifact_id: options?.expectedArtifactId,
      }),
    }),
};

export const minimizationApi = {
  source: (artifactId: string) => request<NormalizedStructure>(`/api/v1/artifacts/${artifactId}`),
  capabilities: () => request<MinimizationCapabilities>("/api/v1/minimization-capabilities"),
  submit: (projectId: string, payload: MinimizationRequest) =>
    request<Job>(`/api/v1/projects/${projectId}/minimizations`, {
      method: "POST", body: JSON.stringify(payload),
    }),
  proposal: (projectId: string, jobId: string) =>
    request<MinimizationProposal>(`/api/v1/projects/${projectId}/minimizations/${jobId}/proposal`),
  live: (projectId: string, jobId: string) =>
    request<MinimizationLive>(`/api/v1/projects/${projectId}/minimizations/${jobId}/live`),
  apply: (projectId: string, jobId: string, expectedRevision: number, digest: string, acknowledge = false) =>
    request<Project>(`/api/v1/projects/${projectId}/minimizations/${jobId}/apply`, {
      method: "POST", body: JSON.stringify({ expected_revision: expectedRevision, proposal_sha256: digest, acknowledge_nonconvergence: acknowledge }),
    }),
};

export const quickMinimizationApi = {
  capabilities: () => request<QuickMinimizationCapabilities>("/api/v1/quick-minimization-capabilities"),
  submit: (projectId: string, payload: QuickMinimizationRequest) =>
    request<Job>(`/api/v1/projects/${projectId}/quick-minimizations`, { method: "POST", body: JSON.stringify(payload) }),
  proposal: (projectId: string, jobId: string) => request<QuickMinimizationProposal>(`/api/v1/projects/${projectId}/quick-minimizations/${jobId}/proposal`),
  live: (projectId: string, jobId: string) => request<MinimizationLive>(`/api/v1/projects/${projectId}/quick-minimizations/${jobId}/live`),
  apply: (projectId: string, jobId: string, revision: number, digest: string) =>
    request<Project>(`/api/v1/projects/${projectId}/quick-minimizations/${jobId}/apply`, { method: "POST", body: JSON.stringify({ expected_revision: revision, proposal_sha256: digest }) }),
};

export const jobApi = {
  definitions: () => request<JobDefinition[]>("/api/v1/jobs/definitions"),
  list: (projectId: string) =>
    request<Job[]>(`/api/v1/projects/${projectId}/jobs`),
  get: (jobId: string) => request<Job>(`/api/v1/jobs/${jobId}`),
  submit: (
    projectId: string,
    jobType: string,
    parameters: Record<string, unknown>,
    inputs: { role: string; entry_id: string }[],
  ) =>
    request<Job>(`/api/v1/projects/${projectId}/jobs`, {
      method: "POST",
      body: JSON.stringify({ job_type: jobType, parameters, inputs }),
    }),
  cancel: (jobId: string) =>
    request<Job>(`/api/v1/jobs/${jobId}/cancel`, { method: "POST" }),
  events: (jobId: string, afterSequence = 0) =>
    request<JobEvent[]>(
      `/api/v1/jobs/${jobId}/events?after_sequence=${afterSequence}`,
    ),
  importResult: (
    jobId: string,
    resultId: string,
    project: Project,
    name?: string,
  ) =>
    request<JobResultImport>(`/api/v1/jobs/${jobId}/results/${resultId}/import`, {
      method: "POST",
      body: JSON.stringify({
        expected_revision: project.revision,
        name: name?.trim() || null,
      }),
    }),
};

export interface ImportUpload {
  promise: Promise<ImportResult>;
  cancel: () => void;
}

export interface CancellableOperation<Result> {
  promise: Promise<Result>;
  cancel: () => void;
}

export interface ImportCallbacks {
  onProgress: (loaded: number, total: number) => void;
  onProcessing: () => void;
}

export const molecularApi = {
  formats: () => request<FormatCapability[]>("/api/v1/formats"),
  structure: async (projectId: string, entryId: string, artifactId: string, signal?: AbortSignal) => {
    const projection = await request<StructureProjection>(
      `/api/v1/projects/${projectId}/entries/${entryId}/structure?${new URLSearchParams({ expected_artifact_id: artifactId })}`,
      { signal },
    );
    if (!projection || projection.entry_id !== entryId || projection.artifact_id !== artifactId) {
      throw new ApiError(409, "structure_identity_mismatch", "The molecule response does not match the requested artifact. Reload the target before continuing.");
    }
    return projection;
  },
  importStructures: (
    project: Project,
    files: File[],
    options: { generate3d: boolean; inferBonds: boolean },
    callbacks: ImportCallbacks,
  ): ImportUpload => {
    const xhr = new XMLHttpRequest();
    const form = new FormData();
    const operationId = crypto.randomUUID();
    form.set("operation_id", operationId);
    form.set("expected_revision", String(project.revision));
    form.set("generate_3d", String(options.generate3d));
    form.set("infer_bonds", String(options.inferBonds));
    for (const file of files) form.append("files", file, file.name);

    const promise = new Promise<ImportResult>((resolve, reject) => {
      xhr.open("POST", `/api/v1/projects/${project.id}/imports`);
      xhr.responseType = "json";
      xhr.upload.onprogress = (event) =>
        callbacks.onProgress(event.loaded, event.lengthComputable ? event.total : 0);
      xhr.upload.onload = callbacks.onProcessing;
      xhr.onerror = () =>
        reject(new ApiError(0, "network_error", "Neistra could not reach the local API."));
      xhr.onabort = () =>
        reject(new ApiError(0, "import_cancelled", "Import cancelled before commit."));
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(xhr.response as ImportResult);
          return;
        }
        reject(apiError(xhr.status, (xhr.response ?? {}) as ApiErrorBody));
      };
      xhr.send(form);
    });
    return {
      promise,
      cancel: () => {
        void fetch(`/api/v1/imports/${operationId}/cancel`, { method: "POST" })
          .catch(() => undefined)
          .finally(() => xhr.abort());
      },
    };
  },
  exportStructure: (
    projectId: string,
    entryId: string,
    format: FormatCapability["format"],
    acknowledgeLosses: boolean,
  ) =>
    request<ExportResult>(
      `/api/v1/projects/${projectId}/entries/${entryId}/exports`,
      {
        method: "POST",
        body: JSON.stringify({
          format,
          acknowledge_losses: acknowledgeLosses,
        }),
      },
    ),
  exportProject: (
    projectId: string,
    options: {
      scope: ExportScope;
      entryIds: string[];
      format: FormatCapability["format"];
      mode: ExportMode;
      includeHydrogens: boolean;
      includeWaters: boolean;
      includeIons: boolean;
      acknowledgeLosses: boolean;
    },
  ): CancellableOperation<BatchExportResult> => {
    const operationId = crypto.randomUUID();
    const controller = new AbortController();
    const promise = request<BatchExportResult>(
      `/api/v1/projects/${projectId}/exports`,
      {
        method: "POST",
        signal: controller.signal,
        body: JSON.stringify({
          scope: options.scope,
          entry_ids: options.entryIds,
          format: options.format,
          mode: options.mode,
          include_hydrogens: options.includeHydrogens,
          include_waters: options.includeWaters,
          include_ions: options.includeIons,
          acknowledge_losses: options.acknowledgeLosses,
          operation_id: operationId,
        }),
      },
    );
    return {
      promise,
      cancel: () => {
        void fetch(`/api/v1/exports/${operationId}/cancel`, { method: "POST" })
          .catch(() => undefined)
          .finally(() => controller.abort());
      },
    };
  },
  exportArchive: (
    projectId: string,
    filenameStyle: "neistra" | "legacy" = "neistra",
  ): CancellableOperation<ArchiveExportResult> => {
    const operationId = crypto.randomUUID();
    const controller = new AbortController();
    const promise = request<ArchiveExportResult>(
      `/api/v1/projects/${projectId}/archive`,
      {
        method: "POST",
        signal: controller.signal,
        body: JSON.stringify({ operation_id: operationId, filename_style: filenameStyle }),
      },
    );
    return {
      promise,
      cancel: () => {
        void fetch(`/api/v1/exports/${operationId}/cancel`, { method: "POST" })
          .catch(() => undefined)
          .finally(() => controller.abort());
      },
    };
  },
  importArchive: (
    file: File,
    callbacks: ImportCallbacks,
  ): CancellableOperation<ArchiveImportResult> => {
    const xhr = new XMLHttpRequest();
    const operationId = crypto.randomUUID();
    const form = new FormData();
    form.set("operation_id", operationId);
    form.set("file", file, file.name);

    const promise = new Promise<ArchiveImportResult>((resolve, reject) => {
      xhr.open("POST", "/api/v1/projects/import-archive");
      xhr.responseType = "json";
      xhr.upload.onprogress = (event) =>
        callbacks.onProgress(event.loaded, event.lengthComputable ? event.total : 0);
      xhr.upload.onload = callbacks.onProcessing;
      xhr.onerror = () =>
        reject(new ApiError(0, "network_error", "Neistra could not reach the local API."));
      xhr.onabort = () =>
        reject(new ApiError(0, "archive_import_cancelled", "Archive import cancelled."));
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(xhr.response as ArchiveImportResult);
          return;
        }
        reject(apiError(xhr.status, (xhr.response ?? {}) as ApiErrorBody));
      };
      xhr.send(form);
    });
    return {
      promise,
      cancel: () => {
        void fetch(`/api/v1/imports/${operationId}/cancel`, { method: "POST" })
          .catch(() => undefined)
          .finally(() => xhr.abort());
      },
    };
  },
};

export { request as apiRequest };
