from __future__ import annotations

import asyncio
import multiprocessing
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager, suppress
from multiprocessing.connection import Connection
from typing import Any, Literal, NoReturn, cast
from urllib.parse import quote
from uuid import UUID

from fastapi import (
    APIRouter,
    Depends,
    FastAPI,
    File,
    Form,
    Header,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from neistra_core.adapters import AdapterError
from neistra_core.artifacts import LocalArtifactStore
from neistra_core.export_policy import (
    ExportFilters,
    ExportInput,
    ExportPolicyError,
    PreparedExport,
    prepare_export,
)
from neistra_core.jobs import PluginRegistry
from neistra_core.ligand_profiles import PROFILE_REGISTRY
from neistra_core.ligand_profiles.models import ProfileRegistry
from sqlalchemy import select, text
from sqlalchemy.orm import Session, sessionmaker
from uuid6 import uuid7

from neistra_api.archive_service import (
    ArchiveBuildInput,
    ArchiveLimits,
    ArchiveValidationError,
    PreparedArchive,
    ProjectArchiveService,
    build_project_archive,
    read_project_archive,
)
from neistra_api.contact_service import ContactReadCoordinator, ContactReadError
from neistra_api.coordinate_service import CoordinateService
from neistra_api.database import Base, create_database_engine, create_session_factory
from neistra_api.edit_execution import EditExecutionController, EditExecutionError
from neistra_api.import_export import (
    ArtifactIntegrityError,
    ArtifactNotFoundError,
    ArtifactService,
    ImportExportService,
    ImportLimitError,
    LossAcknowledgementRequiredError,
    PreparedFile,
    StructureArtifactConflictError,
    StructureUnavailableError,
    UploadPayload,
    prepare_uploads,
    safe_display_filename,
)
from neistra_api.interaction_service import interaction_router
from neistra_api.job_service import (
    InvalidJobOperationError,
    JobConflictError,
    JobNotFoundError,
    JobResultNotFoundError,
    JobService,
)
from neistra_api.ligand_edit_service import LigandEditService
from neistra_api.ligand_property_cache import PropertyCacheError
from neistra_api.ligand_property_schemas import (
    LigandPropertyAggregateRead,
    LigandPropertyConsumerUpdate,
    LigandPropertyPreferencesRead,
    LigandPropertyPreferencesUpdate,
    LigandPropertyReadRequest,
    LigandPropertyRegistryRead,
)
from neistra_api.ligand_property_service import (
    LigandPropertyService,
    PropertyCapacityError,
    PropertyConsumerConflict,
    PropertyConsumerExpired,
    PropertyPreferenceConflict,
    read_property_preferences,
    update_property_preferences,
)
from neistra_api.ligand_schemas import (
    LigandCandidatesRead,
    LigandDepictionRead,
    LigandDesignationCreate,
    LigandResolveCreate,
)
from neistra_api.ligand_service import LigandService, LigandSourceVerificationError
from neistra_api.minimization_schemas import (
    MinimizationApply,
    MinimizationCapabilities,
    MinimizationCreate,
    MinimizationLiveRead,
    MinimizationProposalRead,
)
from neistra_api.minimization_service import MinimizationService
from neistra_api.model_edit_service import ModelEditService
from neistra_api.models import Artifact, Job, JobEvent
from neistra_api.project_service import (
    EntryNotFoundError,
    HistoryUnavailableError,
    InvalidProjectOperationError,
    ProjectNotFoundError,
    ProjectService,
    RevisionConflictError,
)
from neistra_api.protein_edit_service import ProteinEditService
from neistra_api.schemas import (
    ArchiveExportCreate,
    ArchiveExportRead,
    ArchiveImportRead,
    ArtifactRead,
    BatchExportCreate,
    BatchExportRead,
    ContactQuery,
    ContactRead,
    CoordinateTransformCreate,
    EditAttemptRead,
    EntryRevisionRequest,
    EntryToggle,
    EntryUpdate,
    ExportCreate,
    ExportRead,
    FormatRead,
    GroupCreate,
    GroupMembershipUpdate,
    ImportRead,
    JobCreate,
    JobDefinitionRead,
    JobEventRead,
    JobInputRead,
    JobInputRoleRead,
    JobRead,
    JobResultArtifactRead,
    JobResultImportCreate,
    JobResultImportRead,
    JobResultRoleRead,
    LigandEditCreate,
    LigandEditRead,
    MeasurementCreate,
    MeasurementUpdate,
    ModelEditCreate,
    ModelEditRead,
    ModelPreviewRead,
    MoleculeCreate,
    MoleculeCreateRead,
    ProjectCreate,
    ProjectListItem,
    ProjectRead,
    ProjectUpdate,
    ProteinEditCreate,
    ProteinEditRead,
    RevisionRequest,
    SavedSelectionCreate,
    SceneCreate,
    SelectionAppearanceUpdate,
    SelectionAtomVisibilityUpdate,
    SelectionEditCreate,
    SelectionEditRead,
    SelectionRepresentationUpdate,
    SelectionTransformCreate,
    StructureRead,
    SuperpositionCreate,
    SuperpositionRead,
    SurfaceCreate,
    SurfaceUpdate,
    TestEntryCreate,
    ViewerSettingsUpdate,
)
from neistra_api.selection_style_service import SelectionStyleService
from neistra_api.settings import Settings
from neistra_api.surface_service import SurfaceService
from neistra_api.workspace_presentation import (
    PresentationRevisionConflict,
    WorkspacePresentationUpdate,
    WorkspacePresentationV1,
    read_presentation,
    update_presentation,
)


def _prepare_import_child(
    connection: Connection,
    settings: Settings,
    uploads: list[UploadPayload],
    generate_3d: bool,
    infer_bonds: bool,
) -> None:
    try:
        connection.send(
            (
                "result",
                prepare_uploads(
                    settings,
                    uploads,
                    generate_3d=generate_3d,
                    infer_bonds=infer_bonds,
                ),
            )
        )
    except AdapterError as error:
        connection.send(
            (
                "adapter_error",
                {
                    "code": error.code,
                    "message": error.message,
                    "filename": error.filename,
                    "operation": error.operation,
                    "record_index": error.record_index,
                },
            )
        )
    except ImportLimitError as error:
        connection.send(
            (
                "limit_error",
                {
                    "code": error.code,
                    "message": error.message,
                    "filename": error.filename,
                },
            )
        )
    except BaseException as error:
        connection.send(("worker_error", f"{type(error).__name__}: {error}"))
    finally:
        connection.close()


async def _prepare_cancellable(
    settings: Settings,
    uploads: list[UploadPayload],
    generate_3d: bool,
    infer_bonds: bool,
    is_cancelled: Callable[[], bool],
) -> list[PreparedFile]:
    receiver, sender = multiprocessing.Pipe(duplex=False)
    process = multiprocessing.Process(
        target=_prepare_import_child,
        args=(sender, settings, uploads, generate_3d, infer_bonds),
        daemon=True,
    )
    process.start()
    sender.close()
    try:
        while process.is_alive() and not receiver.poll():
            if is_cancelled():
                process.terminate()
                process.join(timeout=2)
                raise _error(499, "import_cancelled", "Import was cancelled before commit.")
            await asyncio.sleep(0.025)
        if not receiver.poll():
            raise _error(
                422,
                "import_worker_failed",
                "The molecular parser stopped without returning a result.",
            )
        kind, payload = receiver.recv()
        process.join(timeout=2)
        if kind == "adapter_error":
            raise AdapterError(**payload)
        if kind == "limit_error":
            raise ImportLimitError(**payload)
        if kind == "worker_error":
            raise _error(
                422,
                "import_worker_failed",
                f"The molecular parser failed: {payload}",
            )
        return cast(list[PreparedFile], payload)
    finally:
        if process.is_alive():
            process.terminate()
            process.join(timeout=2)
        receiver.close()


def _prepare_export_child(
    connection: Connection,
    inputs: list[ExportInput],
    format_name: str,
    mode: str,
    filters: ExportFilters,
    bundle_name: str,
) -> None:
    try:
        connection.send(
            (
                "result",
                prepare_export(
                    inputs,
                    format_name=format_name,
                    mode=cast(Literal["separate", "multi_record"], mode),
                    filters=filters,
                    bundle_name=bundle_name,
                ),
            )
        )
    except AdapterError as error:
        connection.send(
            (
                "adapter_error",
                {
                    "code": error.code,
                    "message": error.message,
                    "filename": error.filename,
                    "operation": error.operation,
                    "record_index": error.record_index,
                },
            )
        )
    except ExportPolicyError as error:
        connection.send(("policy_error", {"code": error.code, "message": error.message}))
    except BaseException as error:
        connection.send(("worker_error", f"{type(error).__name__}: {error}"))
    finally:
        connection.close()


async def _prepare_export_cancellable(
    inputs: list[ExportInput],
    *,
    format_name: str,
    mode: str,
    filters: ExportFilters,
    bundle_name: str,
    is_cancelled: Callable[[], bool],
) -> PreparedExport:
    receiver, sender = multiprocessing.Pipe(duplex=False)
    process = multiprocessing.Process(
        target=_prepare_export_child,
        args=(sender, inputs, format_name, mode, filters, bundle_name),
        daemon=True,
    )
    process.start()
    sender.close()
    try:
        while process.is_alive() and not receiver.poll():
            if is_cancelled():
                process.terminate()
                process.join(timeout=2)
                raise _error(499, "export_cancelled", "Export was cancelled before publication.")
            await asyncio.sleep(0.025)
        if not receiver.poll():
            raise _error(
                422,
                "export_worker_failed",
                "The export worker stopped without returning a result.",
            )
        kind, payload = receiver.recv()
        process.join(timeout=2)
        if kind == "adapter_error":
            raise _adapter_http_error(AdapterError(**payload))
        if kind == "policy_error":
            error = ExportPolicyError(**payload)
            raise _error(422, error.code, error.message)
        if kind == "worker_error":
            raise _error(422, "export_worker_failed", f"Export failed: {payload}")
        return cast(PreparedExport, payload)
    finally:
        if process.is_alive():
            process.terminate()
            process.join(timeout=2)
        receiver.close()


def _build_archive_child(
    connection: Connection,
    build: ArchiveBuildInput,
) -> None:
    try:
        connection.send(("result", build_project_archive(build)))
    except ArchiveValidationError as error:
        connection.send(
            (
                "archive_error",
                {
                    "code": error.code,
                    "message": error.message,
                    "status_code": error.status_code,
                },
            )
        )
    except BaseException as error:
        connection.send(("worker_error", f"{type(error).__name__}: {error}"))
    finally:
        connection.close()


def _read_archive_child(
    connection: Connection,
    data: bytes,
    limits: ArchiveLimits,
) -> None:
    try:
        connection.send(("result", read_project_archive(data, limits)))
    except ArchiveValidationError as error:
        connection.send(
            (
                "archive_error",
                {
                    "code": error.code,
                    "message": error.message,
                    "status_code": error.status_code,
                },
            )
        )
    except BaseException as error:
        connection.send(("worker_error", f"{type(error).__name__}: {error}"))
    finally:
        connection.close()


async def _archive_child_cancellable(
    target: Callable[..., None],
    args: tuple[object, ...],
    *,
    is_cancelled: Callable[[], bool],
    cancelled_code: str,
    cancelled_message: str,
) -> object:
    receiver, sender = multiprocessing.Pipe(duplex=False)
    process = multiprocessing.Process(
        target=target,
        args=(sender, *args),
        daemon=True,
    )
    process.start()
    sender.close()
    try:
        while process.is_alive() and not receiver.poll():
            if is_cancelled():
                process.terminate()
                process.join(timeout=2)
                raise _error(499, cancelled_code, cancelled_message)
            await asyncio.sleep(0.025)
        if not receiver.poll():
            raise _error(
                422,
                "archive_worker_failed",
                "The archive worker stopped without returning a result.",
            )
        kind, payload = receiver.recv()
        process.join(timeout=2)
        if kind == "archive_error":
            raise _archive_http_error(ArchiveValidationError(**payload))
        if kind == "worker_error":
            raise _error(422, "archive_worker_failed", f"Archive operation failed: {payload}")
        return payload
    finally:
        if process.is_alive():
            process.terminate()
            process.join(timeout=2)
        receiver.close()


def _error(status_code: int, code: str, message: str) -> HTTPException:
    return HTTPException(status_code=status_code, detail={"code": code, "message": message})


def _adapter_http_error(error: AdapterError) -> HTTPException:
    detail: dict[str, object] = {
        "code": error.code,
        "message": error.message,
        "filename": error.filename,
        "operation": error.operation,
    }
    if error.record_index is not None:
        detail["record_index"] = error.record_index
    return HTTPException(status_code=422, detail=detail)


def _limit_http_error(error: ImportLimitError) -> HTTPException:
    detail: dict[str, object] = {"code": error.code, "message": error.message}
    if error.filename is not None:
        detail["filename"] = error.filename
    return HTTPException(status_code=413, detail=detail)


def _archive_http_error(error: ArchiveValidationError) -> HTTPException:
    return _error(error.status_code, error.code, error.message)


async def _session(factory: sessionmaker[Session]) -> AsyncIterator[Session]:
    with factory() as session:
        yield session


def _service(session: Session, settings: Settings) -> ProjectService:
    artifacts = ArtifactService(session, LocalArtifactStore(settings.data_dir))
    return ProjectService(
        session,
        load_structure=artifacts.load_normalized,
        load_original_bytes=artifacts.read_verified_bytes,
    )


def _download_response(artifact: ArtifactRead, data: bytes) -> Response:
    filename = quote(artifact.filename, safe="")
    return Response(
        content=data,
        media_type=artifact.media_type,
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{filename}"},
    )


def create_app(settings: Settings | None = None) -> FastAPI:
    app_settings = settings or Settings.from_env()
    app_settings.data_dir.mkdir(parents=True, exist_ok=True)
    engine = create_database_engine(app_settings.database_url)
    factory = create_session_factory(engine)
    job_registry = PluginRegistry.load(
        allowlist=app_settings.job_plugin_allowlist,
        configured_targets=app_settings.job_plugin_targets,
        discover_installed=True,
    )

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        if app_settings.auto_create_schema:
            Base.metadata.create_all(engine)
        try:
            yield
        finally:
            try:
                await app.state.contact_reads.close()
            finally:
                engine.dispose()

    app = FastAPI(
        title="Neistra API",
        version="0.38.0",
        lifespan=lifespan,
        openapi_url="/api/v1/openapi.json",
        docs_url="/api/docs",
    )
    app.state.settings = app_settings
    app.state.engine = engine
    app.state.session_factory = factory
    app.state.job_registry = job_registry
    app.state.edit_execution = EditExecutionController(factory, app_settings)
    app.state.contact_reads = ContactReadCoordinator(factory, app_settings)
    app.state.cancelled_imports = {}
    app.state.cancelled_exports = {}
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(app_settings.cors_origins),
        allow_methods=["*"],
        allow_headers=["*"],
    )

    async def session_dependency() -> AsyncIterator[Session]:
        async for session in _session(factory):
            yield session

    router = APIRouter(prefix="/api/v1")

    @router.get("/ligand-profiles/registry", response_model=ProfileRegistry)
    async def ligand_profile_registry() -> ProfileRegistry:
        return PROFILE_REGISTRY

    @router.get("/health")
    async def health(session: Session = Depends(session_dependency)) -> dict[str, str]:
        session.execute(text("SELECT 1"))
        return {"status": "ok"}

    @router.get("/formats", response_model=list[FormatRead])
    async def formats(session: Session = Depends(session_dependency)) -> list[FormatRead]:
        return ImportExportService(session, app_settings).formats()

    @router.get("/jobs/definitions", response_model=list[JobDefinitionRead])
    async def job_definitions() -> list[JobDefinitionRead]:
        return [
            JobDefinitionRead(
                plugin_name=registered.plugin_name,
                job_type=registered.definition.job_type,
                implementation_version=registered.definition.implementation_version,
                label=registered.definition.label,
                description=registered.definition.description,
                parameter_schema=registered.definition.parameter_schema,
                input_roles=[
                    JobInputRoleRead(
                        role=role.role,
                        label=role.label,
                        minimum=role.minimum,
                        maximum=role.maximum,
                        structure_types=list(role.structure_types),
                    )
                    for role in registered.definition.input_roles
                ],
                result_roles=[
                    JobResultRoleRead(
                        role=role.role,
                        label=role.label,
                        media_types=list(role.media_types),
                        importable_structure=role.importable_structure,
                    )
                    for role in registered.definition.result_roles
                ],
            )
            for registered in job_registry.definitions()
            if registered.definition.job_type != "ligand.properties"
        ]

    @router.get("/ligand-properties/registry", response_model=LigandPropertyRegistryRead)
    def ligand_property_registry() -> LigandPropertyRegistryRead:
        from neistra_core.ligand_properties.registry import (
            DESCRIPTOR_DEFINITIONS,
            IMPLEMENTATION_VERSION,
            LIBRARY_VERSION,
            POLICY_VERSION,
        )

        return LigandPropertyRegistryRead(
            definitions=DESCRIPTOR_DEFINITIONS,
            implementation_version=IMPLEMENTATION_VERSION,
            policy_version=POLICY_VERSION,
            library_version=LIBRARY_VERSION,
        )


    @router.get(
        "/workspace/ligand-property-preferences", response_model=LigandPropertyPreferencesRead
    )
    def get_ligand_property_preferences(
        session: Session = Depends(session_dependency),
    ) -> LigandPropertyPreferencesRead:
        return read_property_preferences(session)


    @router.put(
        "/workspace/ligand-property-preferences", response_model=LigandPropertyPreferencesRead
    )
    def put_ligand_property_preferences(
        payload: LigandPropertyPreferencesUpdate,
        session: Session = Depends(session_dependency),
    ) -> LigandPropertyPreferencesRead:
        return _call(lambda: update_property_preferences(session, payload))


    @router.post(
        "/projects/{project_id}/ligand-properties/read", response_model=LigandPropertyAggregateRead
    )
    def read_ligand_properties(
        project_id: str,
        payload: LigandPropertyReadRequest,
        session: Session = Depends(session_dependency),
    ) -> LigandPropertyAggregateRead:
        return _call(lambda: LigandPropertyService(session, app_settings).read(project_id, payload))


    @router.post(
        "/projects/{project_id}/ligand-properties/consumers",
        response_model=LigandPropertyAggregateRead,
    )
    def allocate_ligand_property_consumer(
        project_id: str, session: Session = Depends(session_dependency),
    ) -> LigandPropertyAggregateRead:
        return _call(
            lambda: LigandPropertyService(session, app_settings).allocate_consumer(project_id)
        )

    @router.put(
        "/projects/{project_id}/ligand-properties/consumers/{consumer_id}",
        response_model=LigandPropertyAggregateRead,
    )
    def demand_ligand_properties(
        project_id: str,
        consumer_id: str,
        payload: LigandPropertyConsumerUpdate,
        session: Session = Depends(session_dependency),
    ) -> LigandPropertyAggregateRead:
        return _call(
            lambda: LigandPropertyService(session, app_settings).update_consumer(
                project_id, consumer_id, payload
            )
        )


    @router.delete("/projects/{project_id}/ligand-properties/consumers/{consumer_id}")
    def release_ligand_properties(
        project_id: str,
        consumer_id: str,
        sequence: int = Query(ge=1, le=9_007_199_254_740_991),
        session: Session = Depends(session_dependency),
    ) -> dict[str, Any]:
        return _call(
            lambda: LigandPropertyService(session, app_settings).release_consumer(
                project_id, consumer_id, sequence
            )
        )

    @router.get("/workspace/presentation", response_model=WorkspacePresentationV1)
    async def get_workspace_presentation(
        session: Session = Depends(session_dependency),
    ) -> WorkspacePresentationV1:
        return read_presentation(session)

    @router.put("/workspace/presentation", response_model=WorkspacePresentationV1)
    async def put_workspace_presentation(
        payload: WorkspacePresentationUpdate,
        session: Session = Depends(session_dependency),
    ) -> WorkspacePresentationV1:
        return _call(lambda: update_presentation(session, payload))

    @router.get("/projects", response_model=list[ProjectListItem])
    async def list_projects(
        session: Session = Depends(session_dependency),
    ) -> list[ProjectListItem]:
        return _service(session, app_settings).list_projects()

    @router.post("/projects", response_model=ProjectRead, status_code=status.HTTP_201_CREATED)
    async def create_project(
        payload: ProjectCreate, session: Session = Depends(session_dependency)
    ) -> ProjectRead:
        return _service(session, app_settings).create_project(payload.name, payload.description)

    @router.get("/projects/{project_id}", response_model=ProjectRead)
    async def get_project(
        project_id: str, session: Session = Depends(session_dependency)
    ) -> ProjectRead:
        return _call(lambda: _service(session, app_settings).get_project(project_id))

    @router.post(
        "/projects/{project_id}/jobs",
        response_model=JobRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def submit_job(
        project_id: str,
        payload: JobCreate,
        session: Session = Depends(session_dependency),
    ) -> JobRead:
        job = _call(
            lambda: JobService(session, app_settings, job_registry).submit(
                project_id,
                payload.job_type,
                payload.parameters,
                [item.model_dump(mode="json") for item in payload.inputs],
            )
        )
        return _job_read(session, app_settings, job)

    @router.get("/minimization-capabilities", response_model=MinimizationCapabilities)
    async def minimization_capabilities() -> MinimizationCapabilities:
        from neistra_core.minimization.contracts import JOB_TYPE, CalculationError
        from neistra_core.minimization.toolchain import AmberTools

        reason = None
        try:
            job_registry.get(JOB_TYPE)
            await asyncio.to_thread(AmberTools.discover)
        except KeyError:
            reason = "The selection minimization plugin is not enabled by the operator"
        except CalculationError as error:
            reason = str(error)
        return MinimizationCapabilities(
            available=reason is None,
            unavailable_reason=reason,
            prerequisites=[
                "Complete existing explicit H and canonical connectivity",
                "Known ligand charges/orders and ordinary isotope/radical identity",
                "Complete supported standard protein chains and termini",
                "Locked AmberTools24.8 Linux x86-64 installation; no runtime downloads",
            ],
            scientific_limits=[
                "Local minimum is not a global/native conformation or binding pose",
                "Environment: nonperiodic12Å cutoff,10Å LJ switch, reaction-field78.3",
                "No chemistry repair, automatic protonation, covalent adducts or crosslinks",
                "Only captured active conformers; non-converged results cannot Apply",
            ],
            limits={
                "assembly_atoms": 20_000,
                "movable_atoms": 2_000,
                "organic_components": 4,
                "organic_heavy_atoms": 256,
                "default_iterations": 500,
                "maximum_iterations": 2_000,
                "gradient_tolerance": 10,
                "job_seconds": 600,
                "discovery_radius_angstrom": 12,
            },
        )

    @router.post(
        "/projects/{project_id}/minimizations",
        response_model=JobRead,
        status_code=status.HTTP_201_CREATED,
    )
    def submit_minimization(
        project_id: str,
        payload: MinimizationCreate,
        session: Session = Depends(session_dependency),
    ) -> JobRead:
        job = _call(
            lambda: MinimizationService(session, app_settings, job_registry).submit(
                project_id, payload
            )
        )
        return _job_read(session, app_settings, job)

    @router.get(
        "/projects/{project_id}/minimizations/{job_id}/proposal",
        response_model=MinimizationProposalRead,
    )
    def minimization_proposal(
        project_id: str,
        job_id: str,
        session: Session = Depends(session_dependency),
    ) -> MinimizationProposalRead:
        return _call(
            lambda: MinimizationService(session, app_settings, job_registry).proposal(
                project_id, job_id
            )
        )

    @router.get(
        "/projects/{project_id}/minimizations/{job_id}/live", response_model=MinimizationLiveRead
    )
    def minimization_live(
        project_id: str,
        job_id: str,
        response: Response,
        session: Session = Depends(session_dependency),
    ) -> MinimizationLiveRead:
        response.headers["Cache-Control"] = "no-store"
        return _call(
            lambda: MinimizationService(session, app_settings, job_registry).live(
                project_id, job_id
            )
        )

    @router.post("/projects/{project_id}/minimizations/{job_id}/apply", response_model=ProjectRead)
    def apply_minimization(
        project_id: str,
        job_id: str,
        payload: MinimizationApply,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: MinimizationService(session, app_settings, job_registry).apply(
                project_id, job_id, payload
            )
        )

    @router.get("/projects/{project_id}/jobs", response_model=list[JobRead])
    async def list_jobs(
        project_id: str,
        session: Session = Depends(session_dependency),
    ) -> list[JobRead]:
        jobs = _call(
            lambda: JobService(session, app_settings, job_registry).list_project(project_id)
        )
        return [_job_read(session, app_settings, job) for job in jobs]

    @router.get("/jobs/{job_id}", response_model=JobRead)
    async def get_job(
        job_id: str,
        session: Session = Depends(session_dependency),
    ) -> JobRead:
        job = _call(lambda: JobService(session, app_settings, job_registry).get(job_id))
        return _job_read(session, app_settings, job)

    @router.post("/jobs/{job_id}/cancel", response_model=JobRead)
    async def cancel_job(
        job_id: str,
        session: Session = Depends(session_dependency),
    ) -> JobRead:
        job = _call(lambda: JobService(session, app_settings, job_registry).cancel(job_id))
        return _job_read(session, app_settings, job)

    @router.get("/jobs/{job_id}/events", response_model=list[JobEventRead])
    async def job_events(
        job_id: str,
        after_sequence: int = 0,
        session: Session = Depends(session_dependency),
    ) -> list[JobEventRead]:
        events = _call(
            lambda: JobService(session, app_settings, job_registry).events(
                job_id, max(0, after_sequence)
            )
        )
        return [JobEventRead.model_validate(event) for event in events]

    @router.post(
        "/jobs/{job_id}/results/{result_id}/import",
        response_model=JobResultImportRead,
    )
    async def import_job_result(
        job_id: str,
        result_id: str,
        payload: JobResultImportCreate,
        session: Session = Depends(session_dependency),
    ) -> JobResultImportRead:
        project, entry_id = _call(
            lambda: JobService(session, app_settings, job_registry).import_result(
                job_id,
                result_id,
                payload.expected_revision,
                payload.name,
            )
        )
        return JobResultImportRead(project=project, imported_entry_id=entry_id)

    @router.patch("/projects/{project_id}", response_model=ProjectRead)
    async def update_project(
        project_id: str,
        payload: ProjectUpdate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).update_project(
                project_id,
                payload.expected_revision,
                payload.name,
                payload.description,
            )
        )

    @router.post("/projects/{project_id}/save", response_model=ProjectRead)
    async def save_project(
        project_id: str,
        payload: RevisionRequest,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).save(project_id, payload.expected_revision)
        )

    @router.post("/projects/{project_id}/history/undo", response_model=ProjectRead)
    async def undo(
        project_id: str,
        payload: RevisionRequest,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).undo(project_id, payload.expected_revision)
        )

    @router.post("/projects/{project_id}/history/redo", response_model=ProjectRead)
    async def redo(
        project_id: str,
        payload: RevisionRequest,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).redo(project_id, payload.expected_revision)
        )

    @router.patch("/projects/{project_id}/entries/{entry_id}", response_model=ProjectRead)
    async def update_entry(
        project_id: str,
        entry_id: str,
        payload: EntryUpdate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).update_entry(
                project_id,
                entry_id,
                payload.expected_revision,
                {
                    "name": payload.name.strip(),
                    "description": payload.description,
                    "user_metadata": payload.user_metadata,
                },
            )
        )

    @router.post("/projects/{project_id}/entries/{entry_id}/duplicate", response_model=ProjectRead)
    async def duplicate_entry(
        project_id: str,
        entry_id: str,
        payload: EntryRevisionRequest,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).duplicate_entry(
                project_id, entry_id, payload.expected_revision
            )
        )

    @router.post("/projects/{project_id}/entries/{entry_id}/visibility", response_model=ProjectRead)
    async def set_visibility(
        project_id: str,
        entry_id: str,
        payload: EntryToggle,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).set_entry_value(
                project_id, entry_id, payload.expected_revision, "visible", payload.value
            )
        )

    @router.post("/projects/{project_id}/entries/{entry_id}/lock", response_model=ProjectRead)
    async def set_lock(
        project_id: str,
        entry_id: str,
        payload: EntryToggle,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).set_entry_value(
                project_id, entry_id, payload.expected_revision, "locked", payload.value
            )
        )

    @router.post("/projects/{project_id}/entries/{entry_id}/isolate", response_model=ProjectRead)
    async def isolate_entry(
        project_id: str,
        entry_id: str,
        payload: EntryRevisionRequest,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).isolate_entry(
                project_id, entry_id, payload.expected_revision
            )
        )

    @router.put(
        "/projects/{project_id}/entries/{entry_id}/viewer-settings",
        response_model=ProjectRead,
    )
    async def update_viewer_settings(
        project_id: str,
        entry_id: str,
        payload: ViewerSettingsUpdate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).update_viewer_settings(
                project_id,
                entry_id,
                payload.expected_revision,
                payload.settings,
            )
        )

    @router.post(
        "/projects/{project_id}/selection-representations",
        response_model=ProjectRead,
    )
    async def update_selection_representations(
        project_id: str,
        payload: SelectionRepresentationUpdate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: SelectionStyleService(session, app_settings).update(project_id, payload)
        )

    @router.post("/projects/{project_id}/selection-surface", deprecated=True)
    @router.post("/projects/{project_id}/selection-pocket-surface", deprecated=True)
    async def obsolete_singleton_surface(project_id: str) -> None:
        raise _error(
            410,
            "surface_api_migrated",
            "Upgrade the client to project/viewer schema 2 and use surface object actions",
        )

    @router.post("/projects/{project_id}/surfaces", response_model=ProjectRead)
    async def create_surface_objects(
        project_id: str, payload: SurfaceCreate, session: Session = Depends(session_dependency)
    ) -> ProjectRead:
        return _call(lambda: SurfaceService(session, app_settings).create(project_id, payload))

    @router.patch(
        "/projects/{project_id}/entries/{entry_id}/surfaces/{surface_id}",
        response_model=ProjectRead,
    )
    async def update_surface_object(
        project_id: str,
        entry_id: str,
        surface_id: str,
        payload: SurfaceUpdate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: SurfaceService(session, app_settings).update(
                project_id, entry_id, surface_id, payload
            )
        )

    @router.delete(
        "/projects/{project_id}/entries/{entry_id}/surfaces/{surface_id}",
        response_model=ProjectRead,
    )
    async def remove_surface_object(
        project_id: str,
        entry_id: str,
        surface_id: str,
        payload: RevisionRequest,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).remove_surface_object(
                project_id, entry_id, surface_id, payload.expected_revision
            )
        )

    @router.post("/projects/{project_id}/selection-atom-visibility", response_model=ProjectRead)
    async def update_selection_atom_visibility(
        project_id: str,
        payload: SelectionAtomVisibilityUpdate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).update_selection_atom_visibility(
                project_id, payload
            )
        )

    @router.post("/projects/{project_id}/selection-appearance", response_model=ProjectRead)
    async def update_selection_appearance(
        project_id: str,
        payload: SelectionAppearanceUpdate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: SelectionStyleService(session, app_settings).update_appearance(
                project_id, payload
            )
        )

    @router.delete("/projects/{project_id}/entries/{entry_id}", response_model=ProjectRead)
    async def delete_entry(
        project_id: str,
        entry_id: str,
        expected_revision: int,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).delete_entry(
                project_id, entry_id, expected_revision
            )
        )

    @router.post("/projects/{project_id}/groups", response_model=ProjectRead)
    async def create_group(
        project_id: str,
        payload: GroupCreate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).create_group(
                project_id,
                payload.expected_revision,
                payload.name,
                payload.entry_ids,
                payload.selection,
            )
        )

    @router.post("/projects/{project_id}/group-membership", response_model=ProjectRead)
    async def update_group_membership(
        project_id: str,
        payload: GroupMembershipUpdate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).update_group_membership(
                project_id,
                payload.expected_revision,
                payload.entry_ids,
                payload.group_id,
                payload.selection,
            )
        )

    @router.post(
        "/projects/{project_id}/selections",
        response_model=ProjectRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def create_saved_selection(
        project_id: str,
        payload: SavedSelectionCreate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).create_saved_selection(
                project_id,
                payload.expected_revision,
                payload.name,
                payload.selection,
            )
        )

    @router.delete(
        "/projects/{project_id}/selections/{selection_id}",
        response_model=ProjectRead,
    )
    async def delete_saved_selection(
        project_id: str,
        selection_id: str,
        expected_revision: int,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).delete_saved_selection(
                project_id,
                selection_id,
                expected_revision,
            )
        )

    @router.post(
        "/projects/{project_id}/measurements",
        response_model=ProjectRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def create_measurement(
        project_id: str,
        payload: MeasurementCreate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).create_measurement(
                project_id,
                payload.expected_revision,
                payload.name,
                payload.kind,
                [item.model_dump(mode="json") for item in payload.atom_references],
            )
        )

    @router.patch(
        "/projects/{project_id}/measurements/{measurement_id}",
        response_model=ProjectRead,
    )
    async def update_measurement(
        project_id: str,
        measurement_id: str,
        payload: MeasurementUpdate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).update_measurement(
                project_id,
                measurement_id,
                payload.expected_revision,
                payload.name,
                payload.visible,
            )
        )

    @router.delete(
        "/projects/{project_id}/measurements/{measurement_id}",
        response_model=ProjectRead,
    )
    async def delete_measurement(
        project_id: str,
        measurement_id: str,
        expected_revision: int,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).delete_measurement(
                project_id, measurement_id, expected_revision
            )
        )

    @router.post(
        "/projects/{project_id}/scenes",
        response_model=ProjectRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def create_scene(
        project_id: str,
        payload: SceneCreate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).create_scene(
                project_id,
                payload.expected_revision,
                payload.name,
                payload.camera.model_dump(mode="json"),
                payload.selection,
            )
        )

    @router.post(
        "/projects/{project_id}/scenes/{scene_id}/apply",
        response_model=ProjectRead,
    )
    async def apply_scene(
        project_id: str,
        scene_id: str,
        payload: RevisionRequest,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).apply_scene(
                project_id, scene_id, payload.expected_revision
            )
        )

    @router.delete(
        "/projects/{project_id}/scenes/{scene_id}",
        response_model=ProjectRead,
    )
    async def delete_scene(
        project_id: str,
        scene_id: str,
        expected_revision: int,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: _service(session, app_settings).delete_scene(
                project_id, scene_id, expected_revision
            )
        )

    @router.get(
        "/projects/{project_id}/entries/{entry_id}/ligand-candidates",
        response_model=LigandCandidatesRead,
    )
    def ligand_candidates(
        project_id: str,
        entry_id: str,
        expected_artifact_id: str | None = None,
        offset: int = 0,
        limit: int = 12,
        session: Session = Depends(session_dependency),
    ) -> LigandCandidatesRead:
        return _call(lambda: LigandService(session, app_settings).candidates(
            project_id, entry_id, expected_artifact_id, offset=offset, limit=limit,
        ))

    @router.put(
        "/projects/{project_id}/entries/{entry_id}/ligand-designation",
        response_model=ProjectRead,
    )
    def designate_ligand(
        project_id: str,
        entry_id: str,
        payload: LigandDesignationCreate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(lambda: LigandService(session, app_settings).designate(
            project_id, entry_id, payload,
        ))

    @router.post(
        "/projects/{project_id}/ligand-designations/resolve", response_model=ProjectRead,
    )
    def resolve_ligands(
        project_id: str,
        payload: LigandResolveCreate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(lambda: LigandService(session, app_settings).resolve(project_id, payload))

    @router.get(
        "/projects/{project_id}/entries/{entry_id}/ligand-candidates/{candidate_key}/depiction",
        response_model=LigandDepictionRead,
    )
    def ligand_depiction(
        project_id: str,
        entry_id: str,
        candidate_key: str,
        expected_artifact_id: str | None = None,
        session: Session = Depends(session_dependency),
    ) -> LigandDepictionRead:
        return _call(lambda: LigandService(session, app_settings).depiction(
            project_id, entry_id, candidate_key, expected_artifact_id,
        ))

    @router.post(
        "/projects/{project_id}/contacts",
        response_model=list[ContactRead],
    )
    async def contacts(
        project_id: str,
        payload: ContactQuery,
        request: Request,
    ) -> Response:
        try:
            data = await app.state.contact_reads.analyze(
                project_id, payload, request.is_disconnected
            )
        except ContactReadError as error:
            raise _error(error.status, error.code, str(error)) from error
        # The fixed child producer validates each row before bounded encoding.
        # These integrity-checked opaque bytes preserve the documented list DTO.
        return Response(content=data, media_type="application/json")

    @router.post("/projects/{project_id}/selection-transform", response_model=ProjectRead)
    async def transform_selection(
        project_id: str,
        payload: SelectionTransformCreate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        return _call(
            lambda: CoordinateService(session, app_settings).transform_selection(
                project_id, payload
            )
        )

    @router.post(
        "/projects/{project_id}/entries/{entry_id}/transform",
        response_model=ProjectRead,
    )
    async def transform_coordinates(
        project_id: str,
        entry_id: str,
        payload: CoordinateTransformCreate,
        session: Session = Depends(session_dependency),
    ) -> ProjectRead:
        if payload.entry_id != entry_id:
            raise _error(
                422,
                "invalid_project_operation",
                "Transform entry ID must match the route entry",
            )
        return _call(
            lambda: CoordinateService(session, app_settings).transform(project_id, payload)
        )

    @router.post(
        "/projects/{project_id}/molecules",
        response_model=MoleculeCreateRead,
        status_code=201,
    )
    async def create_molecule(
        project_id: str,
        payload: MoleculeCreate,
        session: Session = Depends(session_dependency),
    ) -> MoleculeCreateRead:
        return _call(
            lambda: ModelEditService(session, app_settings).create_molecule(
                project_id,
                payload,
            )
        )

    @router.get("/projects/{project_id}/edit-attempts/{attempt_id}", response_model=EditAttemptRead)
    async def read_edit_attempt(
        project_id: str, attempt_id: UUID, response: Response
    ) -> EditAttemptRead:
        response.headers["Cache-Control"] = "no-store"
        controller: EditExecutionController = app.state.edit_execution
        return controller.attempts.lookup(project_id, str(attempt_id))

    @router.post(
        "/projects/{project_id}/entries/{entry_id}/model-edits/preview",
        response_model=ModelPreviewRead,
    )
    async def preview_model(
        project_id: str,
        entry_id: str,
        payload: ModelEditCreate,
        request: Request,
    ) -> Response:
        return await _edit_response(
            app.state.edit_execution.execute(
                "preview",
                project_id,
                entry_id,
                payload,
                request,
            )
        )

    @router.post(
        "/projects/{project_id}/entries/{entry_id}/model-edits",
        response_model=ModelEditRead,
    )
    async def edit_model(
        project_id: str,
        entry_id: str,
        payload: ModelEditCreate,
        request: Request,
        edit_attempt: UUID | None = Header(default=None, alias="X-Neistra-Edit-Attempt"),
    ) -> Response:
        return await _edit_response(
            app.state.edit_execution.execute(
                "model",
                project_id,
                entry_id,
                payload,
                request,
                attempt_id=str(edit_attempt) if edit_attempt is not None else None,
            )
        )

    @router.post(
        "/projects/{project_id}/entries/{entry_id}/selection-edits",
        response_model=SelectionEditRead,
    )
    async def edit_selection(
        project_id: str,
        entry_id: str,
        payload: SelectionEditCreate,
        request: Request,
        edit_attempt: UUID | None = Header(default=None, alias="X-Neistra-Edit-Attempt"),
    ) -> Response:
        return await _edit_response(
            app.state.edit_execution.execute(
                "selection",
                project_id,
                entry_id,
                payload,
                request,
                attempt_id=str(edit_attempt) if edit_attempt is not None else None,
            )
        )

    @router.post(
        "/projects/{project_id}/entries/{entry_id}/ligand-edits",
        response_model=LigandEditRead,
    )
    async def edit_ligand(
        project_id: str,
        entry_id: str,
        payload: LigandEditCreate,
        session: Session = Depends(session_dependency),
    ) -> LigandEditRead:
        return _call(
            lambda: LigandEditService(session, app_settings).edit(project_id, entry_id, payload)
        )

    @router.post(
        "/projects/{project_id}/entries/{entry_id}/protein-edits",
        response_model=ProteinEditRead,
    )
    async def edit_protein(
        project_id: str,
        entry_id: str,
        payload: ProteinEditCreate,
        session: Session = Depends(session_dependency),
    ) -> ProteinEditRead:
        return _call(
            lambda: ProteinEditService(session, app_settings).edit(project_id, entry_id, payload)
        )

    @router.post(
        "/projects/{project_id}/superpositions",
        response_model=SuperpositionRead,
    )
    async def superpose_coordinates(
        project_id: str,
        payload: SuperpositionCreate,
        session: Session = Depends(session_dependency),
    ) -> SuperpositionRead:
        return _call(
            lambda: CoordinateService(session, app_settings).superpose(project_id, payload)
        )

    @router.post(
        "/projects/{project_id}/imports",
        response_model=ImportRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def import_structures(
        project_id: str,
        request: Request,
        files: list[UploadFile] = File(...),
        expected_revision: int = Form(..., ge=0),
        generate_3d: bool = Form(True),
        infer_bonds: bool = Form(True),
        operation_id: str | None = Form(None, max_length=64),
        session: Session = Depends(session_dependency),
    ) -> ImportRead:
        import_id = operation_id or str(uuid7())
        uploads: list[UploadPayload] = []
        aggregate_size = 0
        for upload in files:
            chunks: list[bytes] = []
            file_size = 0
            while chunk := await upload.read(1024 * 1024):
                if await request.is_disconnected():
                    raise _error(499, "import_cancelled", "Import was cancelled before commit.")
                file_size += len(chunk)
                aggregate_size += len(chunk)
                if file_size > app_settings.max_structure_file_bytes:
                    raise _error(
                        413,
                        "structure_file_too_large",
                        (
                            f"{upload.filename or 'structure'} exceeds the per-file limit "
                            f"of {app_settings.max_structure_file_bytes} bytes."
                        ),
                    )
                if aggregate_size > app_settings.max_upload_request_bytes:
                    raise _error(
                        413,
                        "aggregate_upload_too_large",
                        (
                            "The upload exceeds the aggregate limit of "
                            f"{app_settings.max_upload_request_bytes} bytes."
                        ),
                    )
                chunks.append(chunk)
            uploads.append(
                UploadPayload(
                    filename=upload.filename or "structure",
                    data=b"".join(chunks),
                    media_type=upload.content_type,
                )
            )
        service = ImportExportService(session, app_settings)
        try:
            try:
                prepared = await _prepare_cancellable(
                    app_settings,
                    uploads,
                    generate_3d,
                    infer_bonds,
                    lambda: import_id in app.state.cancelled_imports,
                )
            except AdapterError as error:
                raise _adapter_http_error(error) from error
            except ImportLimitError as error:
                raise _limit_http_error(error) from error
            if import_id in app.state.cancelled_imports or await request.is_disconnected():
                raise _error(499, "import_cancelled", "Import was cancelled before commit.")
            return _call(lambda: service.commit_import(project_id, expected_revision, prepared))
        finally:
            app.state.cancelled_imports.pop(import_id, None)

    @router.post("/imports/{operation_id}/cancel")
    async def cancel_import(operation_id: str) -> dict[str, str]:
        if not operation_id or len(operation_id) > 64:
            raise _error(422, "invalid_import_operation", "Invalid import operation ID.")
        now = time.monotonic()
        app.state.cancelled_imports = {
            key: created_at
            for key, created_at in app.state.cancelled_imports.items()
            if now - created_at < 3600
        }
        app.state.cancelled_imports[operation_id] = now
        return {"status": "cancelled"}

    @router.get(
        "/projects/{project_id}/entries/{entry_id}/structure",
        response_model=StructureRead,
    )
    async def get_structure(
        project_id: str,
        entry_id: str,
        expected_artifact_id: str | None = None,
        session: Session = Depends(session_dependency),
    ) -> StructureRead:
        return _call(
            lambda: ImportExportService(session, app_settings).structure(
                project_id, entry_id, expected_artifact_id=expected_artifact_id
            )
        )

    @router.get("/projects/{project_id}/entries/{entry_id}/original")
    async def get_original(
        project_id: str,
        entry_id: str,
        session: Session = Depends(session_dependency),
    ) -> Response:
        service = ImportExportService(session, app_settings)
        artifact, data = _call(lambda: service.original(project_id, entry_id))
        return _download_response(service.artifacts.response(artifact), data)

    @router.post(
        "/projects/{project_id}/entries/{entry_id}/exports",
        response_model=ExportRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def export_structure(
        project_id: str,
        entry_id: str,
        payload: ExportCreate,
        session: Session = Depends(session_dependency),
    ) -> ExportRead:
        return _call(
            lambda: ImportExportService(session, app_settings).export(
                project_id,
                entry_id,
                payload.format,
                acknowledge_losses=payload.acknowledge_losses,
            )
        )

    @router.post(
        "/projects/{project_id}/exports",
        response_model=BatchExportRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def export_project_entries(
        project_id: str,
        payload: BatchExportCreate,
        request: Request,
        session: Session = Depends(session_dependency),
    ) -> BatchExportRead:
        service = ImportExportService(session, app_settings)
        try:
            sources = _call(
                lambda: service.batch_sources(
                    project_id,
                    scope=payload.scope,
                    entry_ids=payload.entry_ids,
                )
            )
            prepared = await _prepare_export_cancellable(
                list(sources.inputs),
                format_name=payload.format,
                mode=payload.mode,
                filters=ExportFilters(
                    include_hydrogens=payload.include_hydrogens,
                    include_waters=payload.include_waters,
                    include_ions=payload.include_ions,
                ),
                bundle_name=sources.project_name,
                is_cancelled=lambda: payload.operation_id in app.state.cancelled_exports,
            )
            if (
                payload.operation_id in app.state.cancelled_exports
                or await request.is_disconnected()
            ):
                raise _error(
                    499,
                    "export_cancelled",
                    "Export was cancelled before publication.",
                )
            return _call(
                lambda: service.publish_batch_export(
                    prepared,
                    scope=payload.scope,
                    source_revision=sources.source_revision,
                    acknowledge_losses=payload.acknowledge_losses,
                )
            )
        finally:
            app.state.cancelled_exports.pop(payload.operation_id, None)

    @router.post("/exports/{operation_id}/cancel")
    async def cancel_export(operation_id: str) -> dict[str, str]:
        if not operation_id or len(operation_id) > 64:
            raise _error(422, "invalid_export_operation", "Invalid export operation ID.")
        now = time.monotonic()
        app.state.cancelled_exports = {
            key: created_at
            for key, created_at in app.state.cancelled_exports.items()
            if now - created_at < 3600
        }
        app.state.cancelled_exports[operation_id] = now
        return {"status": "cancelled"}

    @router.post(
        "/projects/{project_id}/archive",
        response_model=ArchiveExportRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def export_project_archive(
        project_id: str,
        payload: ArchiveExportCreate,
        request: Request,
        session: Session = Depends(session_dependency),
    ) -> ArchiveExportRead:
        service = ProjectArchiveService(session, app_settings)
        try:
            source = _call(lambda: service.export_source(project_id))
            prepared = cast(
                bytes,
                await _archive_child_cancellable(
                    _build_archive_child,
                    (source,),
                    is_cancelled=lambda: payload.operation_id in app.state.cancelled_exports,
                    cancelled_code="export_cancelled",
                    cancelled_message=("Project archive export was cancelled before publication."),
                ),
            )
            if (
                payload.operation_id in app.state.cancelled_exports
                or await request.is_disconnected()
            ):
                raise _error(
                    499,
                    "export_cancelled",
                    "Project archive export was cancelled before publication.",
                )
            return _call(
                lambda: service.publish_export(
                    source.manifest.name,
                    source.manifest.source_revision,
                    prepared,
                    payload.filename_style,
                )
            )
        finally:
            app.state.cancelled_exports.pop(payload.operation_id, None)

    @router.post(
        "/projects/import-archive",
        response_model=ArchiveImportRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def import_project_archive(
        request: Request,
        file: UploadFile = File(...),
        operation_id: str | None = Form(None, max_length=64),
        session: Session = Depends(session_dependency),
    ) -> ArchiveImportRead:
        import_id = operation_id or str(uuid7())
        filename = safe_display_filename(file.filename or "project.neistra.zip")
        if not filename.casefold().endswith((".neistra.zip", ".molweave.zip")):
            raise _error(
                422,
                "unsupported_project_archive_extension",
                "Project archives must use the .neistra.zip or .molweave.zip extension.",
            )
        chunks: list[bytes] = []
        archive_size = 0
        while chunk := await file.read(1024 * 1024):
            if await request.is_disconnected():
                raise _error(499, "import_cancelled", "Archive import was cancelled.")
            archive_size += len(chunk)
            if archive_size > app_settings.max_archive_upload_bytes:
                raise _error(
                    413,
                    "archive_upload_too_large",
                    (
                        "Archive exceeds the compressed limit of "
                        f"{app_settings.max_archive_upload_bytes} bytes."
                    ),
                )
            chunks.append(chunk)
        try:
            prepared = cast(
                PreparedArchive,
                await _archive_child_cancellable(
                    _read_archive_child,
                    (
                        b"".join(chunks),
                        ArchiveLimits.from_settings(app_settings),
                    ),
                    is_cancelled=lambda: import_id in app.state.cancelled_imports,
                    cancelled_code="import_cancelled",
                    cancelled_message="Archive import was cancelled before commit.",
                ),
            )
            if import_id in app.state.cancelled_imports or await request.is_disconnected():
                raise _error(
                    499,
                    "import_cancelled",
                    "Archive import was cancelled before commit.",
                )
            return _call(
                lambda: ProjectArchiveService(session, app_settings).import_archive(prepared)
            )
        finally:
            app.state.cancelled_imports.pop(import_id, None)

    @router.get("/artifacts/{artifact_id}")
    async def get_artifact(
        artifact_id: str,
        filename: str | None = None,
        session: Session = Depends(session_dependency),
    ) -> Response:
        service = ImportExportService(session, app_settings)
        artifact, data = _call(lambda: service.artifact(artifact_id))
        return _download_response(
            service.artifacts.response(artifact, filename=filename),
            data,
        )

    app.include_router(router)
    app.include_router(interaction_router(app_settings, session_dependency))
    from neistra_api.quick_minimization import quick_router

    app.include_router(quick_router(app_settings, job_registry, session_dependency))

    @app.websocket("/ws/jobs")
    async def jobs_websocket(
        websocket: WebSocket,
        project_id: str,
        after_event_id: int = 0,
    ) -> None:
        await websocket.accept()
        cursor = max(0, after_event_id)

        async def disconnected() -> None:
            while True:
                message = await websocket.receive()
                if message["type"] == "websocket.disconnect":
                    return

        disconnect = asyncio.create_task(disconnected())
        try:
            while not disconnect.done():
                with factory() as session:
                    events = list(
                        session.scalars(
                            select(JobEvent)
                            .join(Job, Job.id == JobEvent.job_id)
                            .where(
                                Job.project_id == project_id,
                                JobEvent.id > cursor,
                            )
                            .order_by(JobEvent.id)
                            .limit(100)
                        ).all()
                    )
                    for event in events:
                        await websocket.send_json(
                            JobEventRead.model_validate(event).model_dump(mode="json")
                        )
                        cursor = event.id
                await asyncio.wait({disconnect}, timeout=0.1)
        except (WebSocketDisconnect, OSError):
            return
        except RuntimeError as error:
            # uvloop can close its transport just before ASGI's disconnect arrives.
            if "handler is closed" not in str(error):
                raise
        finally:
            disconnect.cancel()
            with suppress(asyncio.CancelledError):
                await disconnect

    if app_settings.enable_test_routes:
        testing = APIRouter(prefix="/api/v1/testing")

        @testing.post("/projects/{project_id}/entries", status_code=status.HTTP_201_CREATED)
        async def seed_entry(
            project_id: str,
            payload: TestEntryCreate,
            session: Session = Depends(session_dependency),
        ) -> dict[str, str]:
            entry = _call(
                lambda: _service(session, app_settings).seed_entry(
                    project_id, payload.name, payload.structure_type
                )
            )
            return {"id": entry.id}

        app.include_router(testing)

    return app


async def _edit_response(operation: Awaitable[bytes]) -> Response:
    try:
        data = await operation
    except EditExecutionError as error:
        raise HTTPException(
            error.status,
            detail={"code": error.code, "message": str(error)},
            headers={"Retry-After": "1"} if error.status == 429 else None,
        ) from error
    except Exception as error:

        def rethrow(captured_error: Exception = error) -> NoReturn:
            raise captured_error

        return _call(rethrow)
    return Response(content=data, media_type="application/json")


def _call[ResultT](operation: Callable[[], ResultT]) -> ResultT:
    try:
        return operation()
    except ProjectNotFoundError as error:
        raise _error(404, "project_not_found", f"Project {error} was not found") from error
    except EntryNotFoundError as error:
        raise _error(404, "entry_not_found", f"Entry {error} was not found") from error
    except PropertyPreferenceConflict as error:
        raise _error(409, "property_preference_revision_conflict", str(error)) from error
    except PropertyConsumerExpired as error:
        raise _error(409, "property_consumer_expired", str(error)) from error
    except PropertyConsumerConflict as error:
        raise _error(409, "property_consumer_conflict", str(error)) from error
    except PropertyCacheError as error:
        raise _error(503, "property_cache_unavailable", str(error)) from error
    except PropertyCapacityError as error:
        raise _error(503, "property_capacity_unavailable", str(error)) from error
    except PresentationRevisionConflict as error:
        raise _error(
            409,
            "presentation_revision_conflict",
            f"The saved view changed; current revision is {error.current_revision}",
        ) from error
    except RevisionConflictError as error:
        raise _error(
            409,
            "revision_conflict",
            f"Project changed; current revision is {error.current_revision}",
        ) from error
    except HistoryUnavailableError as error:
        raise _error(409, "history_unavailable", str(error)) from error
    except InvalidProjectOperationError as error:
        raise _error(422, "invalid_project_operation", str(error)) from error
    except ExportPolicyError as error:
        raise _error(422, error.code, error.message) from error
    except ArchiveValidationError as error:
        raise _archive_http_error(error) from error
    except AdapterError as error:
        raise _adapter_http_error(error) from error
    except ImportLimitError as error:
        raise _limit_http_error(error) from error
    except LossAcknowledgementRequiredError as error:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "export_loss_acknowledgement_required",
                "message": str(error),
                "warnings": [warning.model_dump(mode="json") for warning in error.warnings],
                "reports": [report.model_dump(mode="json") for report in error.reports],
            },
        ) from error
    except LigandSourceVerificationError as error:
        detail: dict[str, object] = {"code": error.code, "message": str(error),
                                     "source_verification": error.source}
        if error.identity is not None:
            detail["source_identity"] = error.identity.detail()
        raise HTTPException(
            status_code=404 if error.code == "artifact_not_found" else 409, detail=detail,
        ) from error
    except ArtifactIntegrityError as error:
        raise _error(409, "artifact_integrity_error", str(error)) from error
    except ArtifactNotFoundError as error:
        raise _error(404, "artifact_not_found", f"Artifact {error} was not found") from error
    except StructureUnavailableError as error:
        raise _error(
            409,
            "structure_unavailable",
            f"Entry {error} does not have molecular data",
        ) from error
    except StructureArtifactConflictError as error:
        raise _error(409, "structure_artifact_conflict", str(error)) from error
    except JobNotFoundError as error:
        raise _error(404, "job_not_found", f"Job {error} was not found") from error
    except JobResultNotFoundError as error:
        raise _error(404, "job_result_not_found", f"Job result {error} was not found") from error
    except JobConflictError as error:
        raise _error(409, "job_conflict", str(error)) from error
    except InvalidJobOperationError as error:
        raise _error(422, "invalid_job_operation", str(error)) from error


def _job_read(session: Session, settings: Settings, job: Job) -> JobRead:
    artifact_service = ImportExportService(session, settings).artifacts
    results: list[JobResultArtifactRead] = []
    for result in sorted(job.results, key=lambda item: item.created_at):
        artifact = session.get(Artifact, result.artifact_id)
        if artifact is None:
            raise ArtifactNotFoundError(result.artifact_id)
        results.append(
            JobResultArtifactRead(
                id=result.id,
                role=result.role,
                artifact=artifact_service.response(artifact, filename=result.filename),
                filename=result.filename,
                media_type=result.media_type,
                metadata=result.metadata_json,
                importable_structure=result.importable_structure,
                imported_entry_ids=result.imported_entry_ids,
                created_at=result.created_at,
            )
        )
    return JobRead(
        id=job.id,
        project_id=job.project_id,
        plugin_name=job.plugin_name,
        job_type=job.job_type,
        implementation_version=job.implementation_version,
        status=job.status,
        parameters=job.parameters,
        progress=job.progress,
        status_message=job.status_message,
        result_values=job.result_values,
        warnings=job.warnings,
        error=job.error,
        provenance=job.provenance,
        cancellation_requested=job.cancellation_requested,
        inputs=[
            JobInputRead.model_validate(item)
            for item in sorted(job.inputs, key=lambda value: value.ordinal)
        ],
        results=results,
        created_at=job.created_at,
        started_at=job.started_at,
        completed_at=job.completed_at,
        modified_at=job.modified_at,
    )


app = create_app()
