# Structure-editing actual-source reader qualification

Frozen wrapper SHA-256: `534a22a5120b8887890d262340eb7263356bf68071024b1f02387bd2292f0acf`.

This utility changes no application code. It runs real selected API/archive readers
and writers in separate processes with explicit source roots, disposable stores,
no source bytecode writes, actual imported-module paths/hashes, five authoritative
version sources, installed dependency versions and migration head 0015. The preceding
receipt verifies all 793 extracted files from actual annotated v0.31.0 commit
`cc54cd324c5aebe86024c1b85165715691ddcbb3`; source contents and imported module hashes
are rechecked at each phase end. Current identity covers backend/package/support/
fixture sources and selected integration modules; whole-application release inventory
remains the parent's separate complete gate.

## Verified diagnostic

`diagnostic-005/summary.json`: all 3 processes exited 0. The current implementation
still declares 0.31.0. This is explicitly **diagnostic**, `release_qualification=false`;
it does not qualify final 0.32.0. Earlier failed/diagnostic attempts are retained in
separate directories and are not substituted for the frozen passing run.

- 12 current-authored projects, 13 actual API edit transitions: all 5 fragments at heavy
 attachment and H replacement, each with 3 conformers and nonfirst active 7; raw-protein
 N–CA cut then sidechain mutation with canonical exclusion/warning; analytic
 +60-degree torsion in 2 differently oriented frames/nonfirst active 25.
- Exact deep canonical graphs, every coordinate frame, stable molecular IDs, unknown
 charges/orders, protection facts, exclusions, warnings, opaque fixture metadata,
 raw current artifact hashes, immutable original-byte hashes and allocator floors.
 Torsion endpoints/fixed/spectator rows are bitwise exact; moving rows independently
 match analytic local +60-degree coordinates with absolute 1e-12 Å tolerance.
- Actual preceding reader performs all 13 retained command Undo/Redo transitions from
 a quiescent copied current DB; raw command records remain exact and Undo never
 lowers allocator floors. It imports 24 archives across both suffixes and uses its
 own archive writer to reexport 24 current-authored state seeds.
- Actual preceding existing atom.add authors a generic command on an imported seed,
 Undo then new branch consumes distinct IDs 17 and 18; no ID reuse. Current opens a
 copied actual preceding-writer DB, retains all 24 imported projects with exact live
 identities and replays that preceding-authored generic command Undo/Redo exactly.
- Current imports all 24 preceding-writer outputs under BOTH suffixes (48 reads), then
 reexports/reimports each (48 additional reads), deep state exact. Archive-imported
 command history is intentionally empty; retained live DB history is separate.
- Stale revision 409 and stale artifact 422 refuse without molecular/artifact/history
 publication. 6 corrupt archives (payload/hash/schema × both suffixes) return 422 with
 unchanged artifact/project/command counts and managed artifact hashes. 6 independent
 deep-oracle mutations (unknown charge/inactive coordinates/protection/warnings/
 allocator/exclusion) are detected; these are explicitly separate from HTTP tests.

The old writer **retains and reexports current-authored new states**; this does not
claim old software can author new fragments, corrected torsion or new mutation policy.
Existing rich/connectivity/opaque-job families remain separate and required. Opaque
fixture metadata here is not a substitute for opaque-job qualification. No migration,
new scientific method or application behavior is introduced by this utility.

## Focused tool verification

From `/datadisk/dev/neistra-worktrees/issue-147-fragments`:

```sh
.venv/bin/ruff check /tmp/neistra147-editing-reader/qualify.py --cache-dir /tmp/neistra147-editing-reader/ruff-cache
.venv/bin/mypy /tmp/neistra147-editing-reader/qualify.py --follow-imports=silent --cache-dir /tmp/neistra147-editing-reader/mypy-cache
```

Both passed for this exact wrapper. Diagnostic command and every child command vector,
source identity and lossless log hashes are in `diagnostic-005/summary.json`,
`phases.json` and the 3 phase JSON/log pairs. `frozen-manifest.json` hashes the exact
wrapper, this description, preceding source receipt and complete passing disposable
evidence, including archive bytes and retained DB/artifact stores.

## Required final-version invocation

After the primary current source declares 0.32.0 consistently, choose a NEW workspace
and use the primary frozen venv (same pinned dependencies). Do not resolve the venv
Python symlink to its underlying system executable.

```sh
/datadisk/dev/neistra-worktrees/issue-147/.venv/bin/python -B /tmp/neistra147-editing-reader/qualify.py run \
  --current-root /datadisk/dev/neistra-worktrees/issue-147 \
  --previous-root /tmp/neistra147-reader-0310 \
  --previous-receipt /tmp/neistra147-reader-0310-source.json \
  --python /datadisk/dev/neistra-worktrees/issue-147/.venv/bin/python \
  --workspace /tmp/neistra147-editing-reader/final-0320 \
  --current-version 0.32.0
```

No diagnostic flag: only successful final 0.32.0 execution sets
`release_qualification=true`. The same command may select an independently extracted
final source via `--current-root`; the imported modules are checked against that root.
