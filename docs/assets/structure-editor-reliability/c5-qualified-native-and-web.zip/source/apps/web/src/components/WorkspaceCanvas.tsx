import type { SurfaceManagerSession } from "../surfaces/surfaceManagerSession";
import type { WorkspacePresentationController } from "../workspacePresentation/controller";
import type { ResidueSelectionRequest, ViewerPick } from "../selection/gestures";
import type { MinimizationWorkflow } from "../minimization/useMinimization";
import type { SurfaceActions, ChangeSelectionAppearance, ChangeHydrogenAppearance } from "../api/types";
import type { ExpandSelection } from "../selection/expansion";
import { FolderPlus, Upload } from "lucide-react";
import type {
  CameraState,
  AtomReference,
  CoordinatePatch,
  Project,
  Scene,
  Selection,
  SelectionColorMode,
  SelectionGranularity,
  SelectionMode,
  SelectionRepresentationStyle,
  SelectionRepresentationChannel,
  StructureProjection,
  ViewerSettings,
} from "../api/types";
import type { Theme } from "../store/workspace";
import { StructureViewer } from "./StructureViewer";
import { Brand } from "./Brand";
import type { MovementWorkflow } from "../coordinates/useMovementSession";

import { EditAttemptStatus } from "./EditAttemptStatus";
import { editAttemptBlocksWrites } from "../editing/attempt";
import type { MolecularEditingBindings, MolecularEditingPorts } from "../editing/ports";

interface WorkspaceCanvasProps extends MolecularEditingPorts {
  project: Project | undefined;
  theme: Theme;
  selection: Selection;
  pickingGranularity: SelectionGranularity;
  onPickingGranularity: (granularity: SelectionGranularity) => void;
  onSelectResidue?: (request: ResidueSelectionRequest) => void;
  onViewerSelection: (selection: Selection, mode: SelectionMode, pick?: ViewerPick) => void;
  loading: boolean;
  onCreate: () => void;
  onImport: () => void;
  onNewMolecule?: () => void;
  busy?: boolean;
  coordinatePreview?: CoordinatePatch | null;
  movement?: MovementWorkflow;
  minimization?: MinimizationWorkflow;
  onRenderedMovementAtoms?: (read: () => AtomReference[]) => void;
  onUpdateSettings?: (entryId: string, settings: ViewerSettings) => Promise<void>;
  onCreateScene?: (name: string, camera: CameraState) => Promise<void>;
  onApplyScene?: (scene: Scene) => Promise<void>;
  onDeleteScene?: (scene: Scene) => Promise<void>;
  onLoadSelectionStructures?: () => Promise<Map<string, StructureProjection>>;
  onExpandDistance?: ExpandSelection;
  onAtomVisibility?: (action: "hide" | "show") => Promise<void>;
  onSurfaces?: SurfaceActions;
  surfaceSession?: SurfaceManagerSession;
  cameraPresentation?: WorkspacePresentationController;
  onLoadPocketStructures?: () => Promise<Map<string, StructureProjection>>;
  onAppearance?: ChangeSelectionAppearance;
  onHydrogenAppearance?: ChangeHydrogenAppearance;
  selectionColorMode: SelectionColorMode;
  onSelectionColorModeChange: (mode: SelectionColorMode) => void;
  onSelectionStyle?: (
    action: "apply" | "reset",
    style?: SelectionRepresentationStyle,
    channel?: SelectionRepresentationChannel,
  ) => Promise<void>;
}

export function WorkspaceCanvas({
  project,
  theme,
  selection,
  pickingGranularity,
  onPickingGranularity,
  onViewerSelection,
  onSelectResidue,
  loading,
  onCreate,
  onImport,
  onNewMolecule,
  busy,
  coordinatePreview,
  movement,
  minimization,
  onRenderedMovementAtoms,
  onUpdateSettings,
  onCreateScene,
  onApplyScene,
  onDeleteScene,
  onLoadSelectionStructures,
  onSelectionStyle,
  onExpandDistance,
  onAtomVisibility,
  onSurfaces,
  surfaceSession,
  cameraPresentation,
  onLoadPocketStructures,
  onAppearance,
  onHydrogenAppearance,
  selectionColorMode,
  onSelectionColorModeChange,
  onEdit, editAttempt, onCheckEdit, onReviewEdit, onContinueEdit, editReviewCurrent, onGeometry, onRecoverResidue,
}: WorkspaceCanvasProps) {
  const editingPorts: MolecularEditingBindings = {
    onEdit, editAttempt, onCheckEdit, onReviewEdit, onContinueEdit, editReviewCurrent, onGeometry, onRecoverResidue,
  };
  if (loading) {
    return (
      <main className="workspace-canvas" aria-busy="true">
        <div className="workspace-loading">
          <Brand variant="icon" />
          <span role="status">Loading Neistra workspace</span>
        </div>
      </main>
    );
  }

  return (
    <main className="workspace-canvas">
      <div className="canvas-grid" aria-hidden="true" />
      {!project ? (
        <div className="canvas-empty">
          <Brand variant="lockup" className="welcome-brand" />
          <p className="workspace-tagline">Shape molecular structure.</p>
          <h1>No project open</h1>
          <button type="button" className="primary-button" onClick={onCreate}>
            <FolderPlus size={17} />
            Create project
          </button>
        </div>
      ) : project.entries.length === 0 ||
        !project.entries.some((entry) => entry.current_artifact_id) ? (
        <div className={`project-stage${editAttempt && editAttemptBlocksWrites(editAttempt) ? " has-edit-recovery" : ""}`}>
          <Brand className="stage-brand" />
          <h1>{project.name}</h1>
          <p>
            {project.entries.length}{" "}
            {project.entries.length === 1 ? "structure" : "structures"}
          </p>
          <div className={`checkpoint-state ${project.has_uncheckpointed_changes ? "dirty" : ""}`}>
            {project.has_uncheckpointed_changes ? "Changes stored locally" : "Checkpoint saved"}
          </div>
          {editAttempt && editAttemptBlocksWrites(editAttempt) ? <div className="empty-edit-recovery" aria-label="Molecular edit recovery">
            <EditAttemptStatus attempt={editAttempt} onCheck={onCheckEdit} onReview={onReviewEdit} onContinue={onContinueEdit} reviewCurrent={editReviewCurrent} />
          </div> : null}
          {onNewMolecule ? <button type="button" className="primary-button" disabled={busy} onClick={onNewMolecule}>New molecule</button> : null}
          <button type="button" className="secondary-button stage-import" disabled={busy} onClick={onImport}>
            <Upload size={16} /> Import structures
          </button>
        </div>
      ) : (
        <StructureViewer
          cameraPresentation={cameraPresentation}
          {...editingPorts}
          key={project.id}
          project={project}
          theme={theme}
          selection={selection}
          pickingGranularity={pickingGranularity}
          onPickingGranularity={onPickingGranularity}
          onViewerSelection={onViewerSelection}
          onSelectResidue={onSelectResidue}
          busy={busy}
          coordinatePreview={coordinatePreview}
          movement={movement}
          minimization={minimization}
          onRenderedMovementAtoms={onRenderedMovementAtoms}
          onUpdateSettings={onUpdateSettings}
          onCreateScene={onCreateScene}
          onApplyScene={onApplyScene}
          onDeleteScene={onDeleteScene}
          onLoadSelectionStructures={onLoadSelectionStructures}
          onSelectionStyle={onSelectionStyle}
          onExpandDistance={onExpandDistance}
          onAppearance={onAppearance}
          onHydrogenAppearance={onHydrogenAppearance}
          selectionColorMode={selectionColorMode}
          onSelectionColorModeChange={onSelectionColorModeChange}
          onAtomVisibility={onAtomVisibility}
          onSurfaces={onSurfaces}
          surfaceSession={surfaceSession}
          onLoadPocketStructures={onLoadPocketStructures}
        />
      )}
    </main>
  );
}
