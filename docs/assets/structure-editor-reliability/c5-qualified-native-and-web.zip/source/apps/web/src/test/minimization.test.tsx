import { useMinimizationPreview } from "../minimization/useMinimizationPreview";
import { QueryClient, QueryClientProvider, onlineManager } from "@tanstack/react-query";
import { act, cleanup, fireEvent, render, renderHook, waitFor } from "@testing-library/react";
import type { ReactNode } from "react";
import { afterEach, expect, it, vi } from "vitest";
import { jobApi, minimizationApi, quickMinimizationApi } from "../api/client";
import type { Job, MinimizationProposal, Selection, Project, QuickMinimizationProposal } from "../api/types";
import { calculationComponents, minimizationRequest } from "../minimization/context";
import { coordinatePatches } from "../minimization/preview";
import { useMinimizationStore } from "../minimization/store";
import { useMinimization } from "../minimization/useMinimization";
import { useMinimizationShortcut } from "../minimization/useMinimizationShortcut";
import { useWorkspaceStore } from "../store/workspace";
import { molecularEntry, molecularProject, proteinStructure } from "./molecular-fixtures";
import type { QuickPublicationAttempt, QuickPublicationController, QuickPublicationState } from "../minimization/publication";
import { MinimizationPanel } from "../components/MinimizationPanel";

const selection: Selection = { schema_version: 1, granularity: "atom", source: "inspector", atoms: [{ structure_id: "protein", atom_id: 1 }] };
const project = () => molecularProject([molecularEntry("protein", "Protein", "protein"), { ...molecularEntry("ligand", "Hidden ligand", "ligand"), visible: false, locked: true }]);
function sources() {
  const protein = proteinStructure();
  protein.active_conformer_id = 7;
  // Sparse canonical bonds must not crop a polymer chain.
  protein.atoms[2].coordinates = [100, 0, 0];
  const ligand = proteinStructure();
  ligand.residues = []; ligand.chains = []; ligand.atoms = [ligand.atoms[0]];
  ligand.atoms[0].residue_id = null;
  return new Map([["protein", { artifactId: "current-protein", structure: protein }], ["ligand", { artifactId: "current-ligand", structure: ligand }]]);
}
function proposal(): MinimizationProposal {
  return { schema_version: 1, job_id: "job", proposal_sha256: "digest", applicable: true, unavailable_reason: null,
    entries: [{ entry_id: "protein", conformer_id: 7, atom_ids: [1], coordinates: [[0, 1, 0]] }],
    report: { schema_version: 1, model: "amber-local-v1", outcome: "converged", reason: "Converged", parameters: { schema_version: 1, model: "amber-local-v1", mode: "isolated", selection, captured_inputs: [], max_iterations: 500 },
      units: {}, initial_energy: 10, final_energy: 1, maximum_gradient: 1, gradient_tolerance: 10, iterations: 3, evaluations: 5, maximum_displacement: 1, rms_displacement: 1, residual_clashes: 0, movable_count: 1, fixed_count: 2, toolchain: {}, warnings: [], elapsed_seconds: 1 } };
}
afterEach(() => { cleanup(); vi.restoreAllMocks(); useMinimizationStore.getState().dismiss(); useMinimizationStore.getState().setProject(null); });
it("includes full chains independent of display and discovers hidden fixed context without choosing it", () => {
  const inputs = sources(); const p = project();
  const components = calculationComponents(p, inputs, selection);
  expect(components[0].atomIds).toEqual([1, 2, 3]);
  expect(components[1]).toMatchObject({ hidden: true, nearby: true, mandatory: false });
  const isolated = minimizationRequest(p, selection, inputs, components, new Set(), "isolated", 500);
  expect(isolated.context).toEqual([]); expect(isolated.conformers).toEqual({ protein: 7 });
  const environment = minimizationRequest(p, selection, inputs, components, new Set([components[1].key]), "environment", 500);
  expect(environment.context).toEqual([{ entry_id: "ligand", atom_ids: [1] }, { entry_id: "protein", atom_ids: [1, 2, 3] }]);
  expect(environment.conformers).toEqual({ protein: 7, ligand: 1 });
  p.entries[0].locked = true;
  expect(() => minimizationRequest(p, selection, inputs, components, new Set(), "isolated", 500)).toThrow("Unlock");
});
it("refuses stale inputs, absent atoms, invalid iterations and implicit multi-component isolation", () => {
  const p = project(), inputs = sources(), components = calculationComponents(p, inputs, selection);
  p.entries[0].current_artifact_id = "changed";
  expect(() => minimizationRequest(p, selection, inputs, components, new Set(), "isolated", 500)).toThrow("source changed");
  for (const iterations of [0, 2001, NaN, 1.5]) expect(() => minimizationRequest(project(), selection, inputs, components, new Set(), "isolated", iterations)).toThrow("iterations");
  const both = { ...selection, atoms: [...selection.atoms, { structure_id: "ligand", atom_id: 1 }] };
  expect(() => minimizationRequest(project(), both, inputs, calculationComponents(p, inputs, both), new Set(), "isolated", 500)).toThrow("environment mode");
  expect(() => minimizationRequest(project(), { ...selection, atoms: [{ structure_id: "protein", atom_id: 999 }] }, inputs, components, new Set(), "isolated", 500)).toThrow("unavailable");
});
it("builds disposable preview geometry without mutating sources and refuses malformed or incomplete proposals", () => {
  const inputs = sources(), before = JSON.stringify([...inputs]); const result = proposal();
  expect(coordinatePatches(result.report.parameters.selection, result.entries, inputs)).toEqual([{ entry_id: "protein", artifact_id: "current-protein", atom_ids: [1], coordinates: [[0, 1, 0]] }]);
  expect(JSON.stringify([...inputs])).toBe(before);
  result.entries[0].coordinates[0][0] = Infinity;
  expect(() => coordinatePatches(result.report.parameters.selection, result.entries, inputs)).toThrow("captured selection");
  result.entries = []; expect(() => coordinatePatches(result.report.parameters.selection, result.entries, inputs)).toThrow("omits");
  result.entries = [...proposal().entries, ...proposal().entries]; expect(() => coordinatePatches(result.report.parameters.selection, result.entries, inputs)).toThrow("captured selection");
  result.entries = proposal().entries; result.entries[0].conformer_id = 1; expect(() => coordinatePatches(result.report.parameters.selection, result.entries, inputs)).toThrow("conformer");
});
it("captures selection and invalidates late callbacks on discard, project switch and ABA", () => {
  const store = useMinimizationStore.getState(), mutable = structuredClone(selection);
  const generation = store.begin(project(), mutable);
  mutable.atoms[0].atom_id = 99;
  expect(useMinimizationStore.getState().draft?.selection.atoms[0].atom_id).toBe(1);
  store.dismiss(); store.patch(generation, { preview: true, open: true });
  expect(useMinimizationStore.getState().open).toBe(false);
  store.setProject("other"); store.setProject("project-1"); store.patch(generation, { open: true });
  expect(useMinimizationStore.getState().open).toBe(false);
});
it("handles Ctrl+M once while respecting typing, composition modifiers, repeated keys and modal ownership", () => {
  const run = vi.fn();
  function Shortcut() { useMinimizationShortcut(true, run); return <input aria-label="Typing" />; }
  const view = render(<Shortcut />);
  fireEvent.keyDown(window, { key: "m", ctrlKey: true }); expect(run).toHaveBeenCalledTimes(1);
  for (const extra of [{ repeat: true }, { isComposing: true }, { shiftKey: true }, { altKey: true }, { metaKey: true }]) fireEvent.keyDown(window, { key: "m", ctrlKey: true, ...extra });
  fireEvent.keyDown(view.getByRole("textbox"), { key: "m", ctrlKey: true });
  const dialog = document.createElement("div"); dialog.setAttribute("role", "dialog"); dialog.setAttribute("aria-modal", "true"); document.body.append(dialog);
  fireEvent.keyDown(window, { key: "m", ctrlKey: true }); dialog.remove();
  expect(run).toHaveBeenCalledTimes(1); view.unmount();
  fireEvent.keyDown(window, { key: "m", ctrlKey: true }); expect(run).toHaveBeenCalledTimes(1);
});
function workflow(publication?: QuickPublicationController,
  dispatch?: (operation: () => Promise<Project>, quick?: QuickPublicationAttempt) => Promise<Project>, assertWritable?: () => void) {
  const p = project(); useWorkspaceStore.setState({ activeProjectId: p.id }); useMinimizationStore.getState().setProject(p.id);
  const client = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } });
  const wrapper = ({ children }: { children: ReactNode }) => <QueryClientProvider client={client}>{children}</QueryClientProvider>;
  const commit = vi.fn((operation: () => Promise<Project>, quick?: QuickPublicationAttempt) => dispatch ? dispatch(operation, quick) : operation());
  const notice = vi.fn();
  const hook = renderHook(({ currentProject, currentSelection }) => {
    const w = useMinimization(currentProject, currentSelection, commit, undefined, notice, publication, undefined, assertWritable);
    return { ...w, ...useMinimizationPreview(currentProject, w) };
  }, { wrapper, initialProps: { currentProject: p, currentSelection: selection } });
  return { ...hook, client, commit, notice, p, wrapper };
}
it("Ctrl+M submits quick work exactly once and never applies cancelled work", async () => {
  const source = vi.spyOn(minimizationApi, "source").mockResolvedValue(sources().get("protein")!.structure);
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const submit = vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue({ id: "job", status: "cancelled" } as Job);
  const apply = vi.spyOn(quickMinimizationApi, "apply");
  const w = workflow();
  await act(async () => { const first = w.result.current.quick(); await w.result.current.quick(); await first; });
  expect(source).not.toHaveBeenCalled(); expect(submit).toHaveBeenCalledOnce();
  expect(submit.mock.calls[0][1]).toMatchObject({ mode: "automatic", selection, max_iterations: 500 });
  expect(submit.mock.calls[0][1]).not.toHaveProperty("context"); expect(submit.mock.calls[0][1]).not.toHaveProperty("conformers");
  expect(apply).not.toHaveBeenCalled(); expect(w.commit).not.toHaveBeenCalled();
  expect(w.result.current.state.jobId).toBe("job"); w.client.clear();
});
it("does not submit or resurrect the panel after capability discovery is discarded", async () => {
  let resolve!: (value: Awaited<ReturnType<typeof quickMinimizationApi.capabilities>>) => void;
  vi.spyOn(quickMinimizationApi, "capabilities").mockImplementation(() => new Promise(done => { resolve = done; }));
  const submit = vi.spyOn(quickMinimizationApi, "submit"); const w = workflow();
  let pending!: Promise<void>;
  act(() => { pending = w.result.current.quick(); });
  await waitFor(() => expect(resolve).toBeDefined());
  act(() => w.result.current.dismiss());
  await act(async () => { resolve({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} }); await pending; });
  expect(submit).not.toHaveBeenCalled(); expect(w.result.current.open).toBe(false); w.client.clear();
});
it("keeps a failed prerequisite quiet, surfaces its error and never submits it", async () => {
  vi.spyOn(minimizationApi, "source").mockResolvedValue(sources().get("protein")!.structure);
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: false, unavailable_reason: "Quick model disabled", prerequisites: [], scientific_limits: [], limits: {} });
  const submit = vi.spyOn(quickMinimizationApi, "submit"); const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  expect(submit).not.toHaveBeenCalled(); expect(w.result.current.open).toBe(false);
  expect(w.notice).toHaveBeenCalledExactlyOnceWith({ kind: "error", text: "Quick model disabled" });
  expect(w.result.current.error).toBe("Quick model disabled"); expect(w.result.current.state.draft).not.toBeNull();
  expect(w.result.current.state.loading).toBe(false); w.client.clear();
});
it("does not submit across a project switch during capability discovery", async () => {
  vi.spyOn(minimizationApi, "source").mockResolvedValue(sources().get("protein")!.structure);
  let finish!: () => void;
  vi.spyOn(quickMinimizationApi, "capabilities").mockImplementation(() => new Promise(resolve => { finish = () => resolve({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} }); }));
  const submit = vi.spyOn(quickMinimizationApi, "submit"); const w = workflow();
  let pending!: Promise<void>; act(() => { pending = w.result.current.quick(); });
  await waitFor(() => expect(finish).toBeDefined());
  act(() => { useWorkspaceStore.setState({ activeProjectId: "other" }); useMinimizationStore.getState().setProject("other"); });
  await act(async () => { finish(); await pending; });
  expect(submit).not.toHaveBeenCalled(); expect(w.result.current.open).toBe(false); w.client.clear();
});

it("cancels a submission that returns after its session was discarded", async () => {
  vi.spyOn(minimizationApi, "source").mockResolvedValue(sources().get("protein")!.structure);
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  let finish!: (job: Job) => void;
  vi.spyOn(quickMinimizationApi, "submit").mockImplementation(() => new Promise(resolve => { finish = resolve; }));
  const cancel = vi.spyOn(jobApi, "cancel").mockResolvedValue({ id: "late", status: "cancelled" } as Job);
  const w = workflow(); let pending!: Promise<void>;
  act(() => { pending = w.result.current.quick(); });
  await waitFor(() => expect(finish).toBeDefined());
  act(() => w.result.current.dismiss());
  await act(async () => { finish({ id: "late", status: "queued" } as Job); await pending; });
  expect(cancel).toHaveBeenCalledWith("late"); expect(w.result.current.open).toBe(false);
  expect(w.commit).not.toHaveBeenCalled(); w.client.clear();
});

it("shows live selected-row patches and clears immediately while cancellation is pending", async () => {
  vi.spyOn(minimizationApi, "source").mockResolvedValue(sources().get("protein")!.structure);
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const job = { id: "live", status: "running", provenance: { project_revision: project().revision } } as unknown as Job;
  vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue(job); vi.spyOn(jobApi, "get").mockResolvedValue(job);
  const frame = { schema_version: 1 as const, job_id: "live", status: "running", capture_sha256: "capture", selection,
    sources: [{ entry_id: "protein", artifact_id: "current-protein", conformer_id: 7 }],
    frame: { sequence: 1, iteration: 1, published_at: Date.now() / 1000, entries: proposal().entries }, unavailable_reason: null };
  vi.spyOn(quickMinimizationApi, "live").mockResolvedValue(frame);
  let finish!: (job: Job) => void;
  vi.spyOn(jobApi, "cancel").mockImplementation(() => new Promise(resolve => { finish = resolve; }));
  const w = workflow(); await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.result.current.patches).toHaveLength(1));
  expect(w.result.current.patches[0].atom_ids).toEqual([1]); expect(w.commit).not.toHaveBeenCalled();
  let pending!: Promise<void>; act(() => { pending = w.result.current.cancel(); });
  expect(w.result.current.patches).toEqual([]);
  await act(async () => { finish({ ...job, status: "cancelled" }); await pending; });
  expect(w.result.current.patches).toEqual([]); w.client.clear();
});

it("keeps job/frame reads and Cancel presentation out of the App command subscription", async () => {
  const p = project(); useWorkspaceStore.setState({ activeProjectId: p.id }); useMinimizationStore.getState().setProject(p.id);
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  vi.spyOn(minimizationApi, "source").mockResolvedValue(sources().get("protein")!.structure);
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const job = { id: "local-read", status: "running", provenance: { project_revision: p.revision } } as unknown as Job;
  vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue(job); vi.spyOn(jobApi, "get").mockResolvedValue(job);
  let sequence = 1;
  vi.spyOn(quickMinimizationApi, "live").mockImplementation(() => Promise.resolve({ schema_version: 1, job_id: job.id, status: "running", capture_sha256: "capture", selection,
    sources: [{ entry_id: "protein", artifact_id: "current-protein", conformer_id: 7 }], frame: { sequence, iteration: sequence, published_at: Date.now() / 1000, entries: proposal().entries }, unavailable_reason: null }));
  vi.spyOn(jobApi, "cancel").mockImplementation(() => new Promise(() => {}));
  let parentRenders = 0, commands!: ReturnType<typeof useMinimization>, view!: ReturnType<typeof useMinimizationPreview>;
  function Viewer({ workflow }: { workflow: ReturnType<typeof useMinimization> }) { view = useMinimizationPreview(p, workflow); return null; }
  function AppCommands() { parentRenders++; commands = useMinimization(p, selection, vi.fn()); return <Viewer workflow={commands} />; }
  render(<QueryClientProvider client={client}><AppCommands /></QueryClientProvider>);
  const initialRenders = parentRenders;
  await act(async () => { await commands.quick(); });
  expect(parentRenders).toBe(initialRenders);
  await waitFor(() => expect(view.patches).toHaveLength(1));
  const before = parentRenders, firstPatches = view.patches;
  await act(async () => { await client.invalidateQueries({ queryKey: ["minimization-live"] }); });
  expect(view.patches).toBe(firstPatches); // An unchanged latest snapshot does not rerender geometry.
  sequence = 2;
  await act(async () => { await client.invalidateQueries({ queryKey: ["minimization-live"] }); });
  await waitFor(() => expect(view.liveIteration).toBe(2));
  expect(parentRenders).toBe(before);
  sequence = 1;
  await act(async () => { await client.invalidateQueries({ queryKey: ["minimization-live"] }); });
  expect(view.liveIteration).toBe(2); // A delayed older response cannot revive an older pose.
  act(() => { void commands.cancel(); });
  expect(view.patches).toEqual([]); expect(parentRenders).toBe(before);
  client.clear();
});

function quickProposal(): QuickMinimizationProposal {
  const old = proposal();
  return { ...old, report: { ...old.report, schema_version: 1, model: "quick-local-v1", outcome: "improved", method: "MMFF94", coverage: "complete",
    assumptions: [], helper_count: 0, cap_count: 0, bonded_geometry_verified: true, planar_geometry_verified: true, geometry_violations: [], energy_reference: "model", geometry_step_tolerance: 0.01, settled_geometry_steps: 0, modeled_atoms: { protein: [1] }, timings: {}, termination_kind: "iteration_limit",
    parameters: { schema_version: 1, model: "quick-local-v1", requested_selection: selection, selection,
      captured_inputs: [{ entry_id: "protein", artifact_id: "current-protein", sha256: "a".repeat(64), conformer_id: 7, atom_ids: [1, 2, 3] }],
      mode: "automatic", context_entry_ids: [], expand_hydrogens: true, allow_repair: true, max_iterations: 500 } } };
}
function completedQuick() {
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const job = { id: "job", job_type: "coordinates.quick_minimize", status: "completed", provenance: { project_revision: project().revision } } as unknown as Job;
  vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue(job);
  vi.spyOn(jobApi, "get").mockResolvedValue(job);
  vi.spyOn(minimizationApi, "source").mockResolvedValue(sources().get("protein")!.structure);
  return job;
}
it("automatically applies a useful quick proposal once as an owning-session command", async () => {
  completedQuick();
  vi.spyOn(quickMinimizationApi, "proposal").mockResolvedValue(quickProposal());
  const apply = vi.spyOn(quickMinimizationApi, "apply").mockResolvedValue({ ...project(), revision: project().revision + 1 });
  const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.result.current.state.applied).toBe(true));
  expect(apply).toHaveBeenCalledExactlyOnceWith(w.p.id, "job", w.p.revision, "digest");
  expect(w.commit).toHaveBeenCalledOnce();
  expect(w.result.current.patches).toEqual([]);
  await act(async () => { await w.client.invalidateQueries({ queryKey: ["minimization-proposal"] }); });
  expect(apply).toHaveBeenCalledOnce(); w.client.clear();
});
it("Cancel disarms automatic publication even if a completed proposal returns later", async () => {
  const job = completedQuick();
  let finish!: (proposal: QuickMinimizationProposal) => void;
  vi.spyOn(quickMinimizationApi, "proposal").mockImplementation(() => new Promise(resolve => { finish = resolve; }));
  vi.spyOn(jobApi, "cancel").mockResolvedValue({ ...job, status: "completed" });
  const apply = vi.spyOn(quickMinimizationApi, "apply"); const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(finish).toBeDefined());
  await act(async () => { await w.result.current.cancel(); finish(quickProposal()); });
  await waitFor(() => expect(w.client.getQueryData(["minimization-proposal", w.p.id, "job"])).toBeDefined());
  expect(w.result.current.open).toBe(false);
  expect(apply).not.toHaveBeenCalled(); expect(w.commit).not.toHaveBeenCalled(); w.client.clear();
});
it("inspecting a retained completed quick job never arms automatic publication", async () => {
  completedQuick(); vi.spyOn(quickMinimizationApi, "proposal").mockResolvedValue(quickProposal());
  const apply = vi.spyOn(quickMinimizationApi, "apply"); const w = workflow();
  act(() => useMinimizationStore.getState().inspect(w.p.id, "job"));
  await waitFor(() => expect(w.result.current.proposal).toBeDefined());
  expect(w.result.current.isQuick).toBe(true); expect(apply).not.toHaveBeenCalled(); w.client.clear();
});
it("quick settings submit exact masks and chosen hidden context independently of AMBER", async () => {
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const submit = vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue({ id: "settings", status: "cancelled" } as Job);
  const w = workflow();
  await act(async () => { await w.result.current.configure("quick"); });
  await act(async () => { await w.result.current.mode("environment"); });
  act(() => w.result.current.include("ligand", true));
  act(() => w.result.current.expandHydrogens(false));
  act(() => w.result.current.allowRepair(false));
  await act(async () => { await w.result.current.run(); });
  expect(submit.mock.calls[0][1]).toMatchObject({ mode: "environment", context_entry_ids: ["ligand"], expand_hydrogens: false, allow_repair: false });
  w.client.clear();
});

it("preserves the quick session across viewer remounts and cancels when App command ownership ends", async () => {
  const p = project(); useWorkspaceStore.setState({ activeProjectId: p.id }); useMinimizationStore.getState().setProject(p.id);
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const job = { id: "owned", job_type: "coordinates.quick_minimize", status: "running", provenance: { project_revision: p.revision } } as unknown as Job;
  vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue(job); vi.spyOn(jobApi, "get").mockResolvedValue(job);
  vi.spyOn(quickMinimizationApi, "live").mockResolvedValue({ schema_version: 1, job_id: job.id, status: "running", capture_sha256: null, selection: null, sources: [], frame: null, unavailable_reason: null });
  const cancel = vi.spyOn(jobApi, "cancel").mockResolvedValue({ ...job, status: "cancelled" });
  let commands!: ReturnType<typeof useMinimization>;
  function Viewer() { useMinimizationPreview(p, commands); return null; }
  function AppCommands({ viewer }: { viewer: boolean }) { commands = useMinimization(p, selection, vi.fn()); return viewer ? <Viewer /> : null; }
  const view = render(<QueryClientProvider client={client}><AppCommands viewer /></QueryClientProvider>);
  await act(async () => { await commands.quick(); });
  view.rerender(<QueryClientProvider client={client}><AppCommands viewer={false} /></QueryClientProvider>);
  expect(useMinimizationStore.getState().autoApply).toBe(true);
  view.rerender(<QueryClientProvider client={client}><AppCommands viewer /></QueryClientProvider>);
  expect(useMinimizationStore.getState().jobId).toBe(job.id);
  view.unmount();
  expect(useMinimizationStore.getState().autoApply).toBe(false);
  expect(cancel).toHaveBeenCalledWith(job.id); client.clear();
});

it("refuses setup retargeting while a calculation is active without cancelling or replacing it", async () => {
  const running = { ...completedQuick(), status: "running" } as Job;
  vi.mocked(quickMinimizationApi.submit).mockResolvedValue(running);
  vi.mocked(jobApi.get).mockResolvedValue(running);
  vi.spyOn(quickMinimizationApi, "live").mockResolvedValue({ schema_version: 1, job_id: running.id, status: "running", capture_sha256: null, selection: null, sources: [], frame: null, unavailable_reason: null });
  const cancel = vi.spyOn(jobApi, "cancel");
  const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  const generation: number = useMinimizationStore.getState().generation;
  await act(async () => { expect(await w.result.current.configure("quick")).toBe(false); });
  expect(useMinimizationStore.getState()).toMatchObject({ generation, autoApply: true, live: true, jobId: String(running.id) });
  expect(cancel).not.toHaveBeenCalled();
  expect(w.notice).toHaveBeenCalledWith({ kind: "error", text: "Finish or cancel the current minimization before starting another tool." });
  w.client.clear();
});


it("opens quick setup without submitting or arming publication", async () => {
  const submit = vi.spyOn(quickMinimizationApi, "submit");
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const w = workflow();
  await act(async () => { await w.result.current.show(); });
  expect(w.result.current.open).toBe(true);
  expect(w.result.current.state.draft?.selection).toEqual(selection);
  expect(w.result.current.state.autoApply).toBe(false);
  expect(submit).not.toHaveBeenCalled(); expect(w.commit).not.toHaveBeenCalled(); w.client.clear();
});

it("applies quietly without stealing focus and retains scientific warnings without a popup", async () => {
  completedQuick();
  const result = quickProposal();
  result.report.warnings = Array.from({ length: 500 }, (_, i) => `entry-uuid: Residue ${i}: approximate repair omits electrostatics.`);
  vi.spyOn(quickMinimizationApi, "proposal").mockResolvedValue(result);
  const apply = vi.spyOn(quickMinimizationApi, "apply").mockResolvedValue(project());
  const button = document.createElement("button"); document.body.append(button); button.focus();
  const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.result.current.state.applied).toBe(true));
  expect(w.result.current.open).toBe(false); expect(document.activeElement).toBe(button);
  expect(apply).toHaveBeenCalledOnce(); expect(w.notice).not.toHaveBeenCalled();
  expect(w.client.getQueryData<QuickMinimizationProposal>(["minimization-proposal", w.p.id, result.job_id])?.report.warnings).toEqual(result.report.warnings);
  await act(async () => { await w.client.invalidateQueries({ queryKey: ["minimization-proposal"] }); });
  expect(apply).toHaveBeenCalledOnce(); expect(w.notice).not.toHaveBeenCalled();
  w.client.clear(); button.remove();
});

it("reveals a submitting shortcut without recapture, cancellation or duplicate starts", async () => {
  let resolve!: (job: Job) => void;
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const submit = vi.spyOn(quickMinimizationApi, "submit").mockImplementation(() => new Promise(done => { resolve = done; }));
  const cancel = vi.spyOn(jobApi, "cancel"); const w = workflow();
  let pending!: Promise<void>;
  act(() => { pending = w.result.current.quick(); });
  await waitFor(() => expect(resolve).toBeDefined());
  const generation = w.result.current.state.generation;
  expect(w.result.current.open).toBe(false);
  await act(async () => { await w.result.current.show(); await w.result.current.quick(); });
  expect(w.result.current.open).toBe(true); expect(w.result.current.state.generation).toBe(generation);
  expect(submit).toHaveBeenCalledOnce(); expect(cancel).not.toHaveBeenCalled();
  const job = { id: "revealed", job_type: "coordinates.quick_minimize", status: "running" } as Job;
  vi.spyOn(jobApi, "get").mockResolvedValue(job);
  vi.spyOn(quickMinimizationApi, "live").mockResolvedValue({ schema_version: 1, job_id: job.id, status: "running", capture_sha256: null, selection: null, sources: [], frame: null, unavailable_reason: null });
  await act(async () => { resolve(job); await pending; });
  await act(async () => { await w.result.current.quick(); });
  expect(w.result.current.state.jobId).toBe(job.id); expect(submit).toHaveBeenCalledOnce(); expect(cancel).not.toHaveBeenCalled();
  w.client.clear();
});

it("does not open a closed panel for failed jobs and disarms later publication", async () => {
  const job = { ...completedQuick(), status: "failed", error: { message: "Worker failed" } } as Job;
  vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue(job); vi.spyOn(jobApi, "get").mockResolvedValue(job);
  const apply = vi.spyOn(quickMinimizationApi, "apply"); const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.notice).toHaveBeenCalledExactlyOnceWith({ kind: "error", text: "Worker failed" }));
  expect(w.result.current.state.error).toBe("Worker failed");
  expect(w.result.current.open).toBe(false); expect(w.result.current.state.autoApply).toBe(false);
  expect(apply).not.toHaveBeenCalled(); w.client.clear();
});

it("keeps an explicitly open panel open when Ctrl+M starts", async () => {
  const job = { ...completedQuick(), status: "running" } as Job;
  vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue(job); vi.spyOn(jobApi, "get").mockResolvedValue(job);
  vi.spyOn(quickMinimizationApi, "live").mockResolvedValue({ schema_version: 1, job_id: job.id, status: "running", capture_sha256: null, selection: null, sources: [], frame: null, unavailable_reason: null });
  const w = workflow();
  await act(async () => { await w.result.current.show(); await w.result.current.quick(); });
  expect(w.result.current.open).toBe(true); expect(w.result.current.state.autoApply).toBe(true); w.client.clear();
});


it("keeps an ordinary unchanged quick result quiet and creates no command", async () => {
  completedQuick(); const result = quickProposal(); result.applicable = false;
  result.report.outcome = "unchanged"; result.report.warnings = [];
  vi.spyOn(quickMinimizationApi, "proposal").mockResolvedValue(result);
  const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.result.current.state.autoApply).toBe(false));
  expect(w.result.current.open).toBe(false); expect(w.commit).not.toHaveBeenCalled();
  expect(w.notice).not.toHaveBeenCalled(); w.client.clear();
});

it("disarms externally cancelled shortcut work without a new notification", async () => {
  const job = { ...completedQuick(), status: "cancelled" } as Job;
  vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue(job); vi.spyOn(jobApi, "get").mockResolvedValue(job);
  const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.result.current.state.autoApply).toBe(false));
  expect(w.result.current.open).toBe(false); expect(w.notice).not.toHaveBeenCalled();
  expect(w.commit).not.toHaveBeenCalled(); w.client.clear();
});


it.each(["blocked", "failed"] as const)("summarizes a hidden %s report without dumping diagnostics or opening a panel", async outcome => {
  completedQuick(); const result = quickProposal(); result.applicable = false;
  result.report.outcome = outcome; result.unavailable_reason = "entry-uuid: Context changed; recalculate. ".repeat(500);
  result.report.warnings = Array.from({ length: 500 }, (_, i) => `Residue ${i}: chemistry diagnostic.`);
  vi.spyOn(quickMinimizationApi, "proposal").mockResolvedValue(result);
  const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.notice).toHaveBeenCalledOnce());
  expect(w.notice).toHaveBeenCalledWith({ kind: "error", lifetime: "persistent", text: "Quick minimization needs review. See Jobs → Inspect minimization." });
  expect(w.client.getQueryData<QuickMinimizationProposal>(["minimization-proposal", w.p.id, result.job_id])?.unavailable_reason).toBe(result.unavailable_reason);
  expect(w.client.getQueryData<QuickMinimizationProposal>(["minimization-proposal", w.p.id, result.job_id])?.report.warnings).toEqual(result.report.warnings);
  expect(w.result.current.open).toBe(false); expect(w.commit).not.toHaveBeenCalled(); w.client.clear();
});

it("reports a hidden job read failure and disarms automatic publication", async () => {
  const job = { ...completedQuick(), status: "running" } as Job;
  vi.spyOn(quickMinimizationApi, "submit").mockResolvedValue(job); vi.spyOn(jobApi, "get").mockRejectedValue(new Error("Job status unavailable"));
  const cancel = vi.spyOn(jobApi, "cancel").mockResolvedValue({ ...job, status: "cancelled" });
  vi.spyOn(quickMinimizationApi, "live").mockResolvedValue({ schema_version: 1, job_id: job.id, status: "running", capture_sha256: null, selection: null, sources: [], frame: null, unavailable_reason: null });
  const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.notice).toHaveBeenCalledExactlyOnceWith({ kind: "error", text: "Job status unavailable" }));
  expect(w.result.current.state.error).toBe("Job status unavailable");
  expect(w.result.current.state.autoApply).toBe(false); expect(w.result.current.open).toBe(false);
  expect(cancel).toHaveBeenCalledExactlyOnceWith(job.id);
  expect(w.commit).not.toHaveBeenCalled(); w.client.clear();
});

it("surfaces a hidden Apply rejection without claiming success or retrying it", async () => {
  completedQuick(); vi.spyOn(quickMinimizationApi, "proposal").mockResolvedValue(quickProposal());
  const apply = vi.spyOn(quickMinimizationApi, "apply").mockRejectedValue(new Error("Revision conflict"));
  const w = workflow();
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.notice).toHaveBeenCalledExactlyOnceWith({ kind: "error", text: "Revision conflict" }));
  expect(w.result.current.state.applied).toBe(false); expect(w.result.current.open).toBe(false);
  await act(async () => { await w.client.invalidateQueries({ queryKey: ["minimization-proposal"] }); });
  expect(apply).toHaveBeenCalledOnce(); w.client.clear();
});

function publicationController(initial: QuickPublicationState) {
  let snapshot = initial;
  const listeners = new Set<() => void>();
  const controller: QuickPublicationController = {
    snapshot: () => snapshot,
    subscribe: listener => { listeners.add(listener); return () => { listeners.delete(listener); }; },
    start: vi.fn(() => Promise.resolve(project())), refresh: vi.fn(() => Promise.resolve(project())), retry: vi.fn(() => Promise.resolve(project())),
    attachProject: vi.fn(() => Promise.resolve()), assertWritable: vi.fn(),
  };
  return { controller, emit: (next: QuickPublicationState) => { snapshot = next; listeners.forEach(listener => listener()); } };
}
const publicationAttempt = (): QuickPublicationAttempt => ({ projectId: project().id, jobId: "job", proposalSha256: "digest", expectedRevision: project().revision, origin: "automatic" });

it("passes captured automatic and manual quick publication descriptors through the shared commit seam", async () => {
  completedQuick(); vi.spyOn(quickMinimizationApi, "proposal").mockResolvedValue(quickProposal());
  vi.spyOn(quickMinimizationApi, "apply").mockResolvedValue({ ...project(), revision: project().revision + 1 });
  const automatic = workflow();
  await act(async () => { await automatic.result.current.quick(); });
  await waitFor(() => expect(automatic.result.current.state.applied).toBe(true));
  expect(automatic.commit.mock.calls[0][1]).toEqual(publicationAttempt());
  automatic.unmount(); automatic.client.clear();
  useMinimizationStore.getState().setProject(project().id);
  const manual = workflow();
  act(() => useMinimizationStore.getState().inspect(manual.p.id, "job"));
  await waitFor(() => expect(manual.result.current.proposal).toBeDefined());
  await act(async () => { await manual.result.current.apply(); });
  expect(manual.commit.mock.calls[0][1]).toEqual({ ...publicationAttempt(), origin: "manual" });
  manual.client.clear();
});

it("reveals application recovery after the preview session closes and keeps refresh and retry explicit", async () => {
  const initial: QuickPublicationState = { phase: "uncertain", attempt: publicationAttempt(), receipt: null, error: "Response was lost" };
  const recovery = publicationController(initial);
  const w = workflow(recovery.controller);
  act(() => useMinimizationStore.getState().dismiss());
  await act(async () => { await w.result.current.show(); });
  expect(w.result.current.state.recovery).toBe(true);
  const view = render(<MinimizationPanel workflow={w.result.current} unavailable="Finish the current change" onOpen={() => {}} />, { wrapper: w.wrapper });
  expect(view.getByRole("region", { name: "Coordinate application recovery" })).toBeVisible();
  expect(view.getByRole("button", { name: "Retry application" })).toBeEnabled();
  act(() => { fireEvent.click(view.getByRole("button", { name: "Refresh result" })); });
  expect(recovery.controller.refresh).toHaveBeenCalledExactlyOnceWith(w.p.id);
  expect(recovery.controller.retry).not.toHaveBeenCalled();
  act(() => { fireEvent.click(view.getByRole("button", { name: "Retry application" })); });
  expect(recovery.controller.retry).toHaveBeenCalledExactlyOnceWith(w.p.id);
  act(() => { fireEvent.click(view.getByRole("button", { name: "Close minimization" })); });
  expect(w.result.current.open).toBe(false);
  expect(recovery.controller.snapshot(w.p.id)).toEqual(initial);
  await act(async () => { await w.result.current.show(); });
  expect(w.result.current.open).toBe(true);
  expect(w.result.current.state.recovery).toBe(true);
  expect(w.result.current.state.autoApply).toBe(false);
  w.client.clear();
});

it("renders invalid recovery as refresh-only and distinguishes a previously recorded application from current coordinates", async () => {
  const recovery = publicationController({ phase: "uncertain", attempt: null, receipt: null, error: "Invalid recovery information" });
  const w = workflow(recovery.controller);
  await act(async () => { await w.result.current.show(); });
  const panel = () => <MinimizationPanel workflow={w.result.current} unavailable={null} onOpen={() => {}} />;
  const view = render(panel(), { wrapper: w.wrapper });
  expect(view.getByRole("button", { name: "Retry application" })).toBeDisabled();
  act(() => recovery.emit({ phase: "reconciling", attempt: null, receipt: null, error: null }));
  view.rerender(panel());
  expect(view.getByRole("button", { name: "Refresh result" })).toBeDisabled();
  expect(view.getByRole("status")).toHaveTextContent("Checking whether coordinates were applied");
  act(() => recovery.emit({ phase: "idle", attempt: null, receipt: { jobId: "job", revision: w.p.revision - 1, proposalSha256: "digest" }, error: null }));
  view.rerender(panel());
  expect(view.getByRole("status")).toHaveTextContent("recorded previously");
  expect(view.queryByText("Quick coordinates applied. Undo restores the previous coordinates.")).toBeNull();
  expect(view.queryByRole("button", { name: "Retry application" })).toBeNull();
  w.client.clear();
});

it("does not mark reconciled coordinates currently applied after a later Undo or edit", async () => {
  completedQuick(); vi.spyOn(quickMinimizationApi, "proposal").mockResolvedValue(quickProposal());
  const recovery = publicationController({ phase: "idle", attempt: null, receipt: null, error: null });
  const w = workflow(recovery.controller, (_operation, descriptor) => {
    expect(descriptor).toEqual(publicationAttempt());
    recovery.emit({ phase: "idle", attempt: null, receipt: { jobId: "job", revision: project().revision + 1, proposalSha256: "digest" }, error: null });
    return Promise.resolve({ ...project(), revision: project().revision + 2 });
  });
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.commit).toHaveBeenCalledOnce());
  expect(w.result.current.state.applied).toBe(false);
  expect(w.result.current.state.recovery).toBe(true);
  expect(w.result.current.open).toBe(false);
  expect(w.notice).not.toHaveBeenCalled();
  w.client.clear();
});

it("retains the application-owned recovery diagnostic instead of replacing it with a raw transport error", async () => {
  completedQuick(); vi.spyOn(quickMinimizationApi, "proposal").mockResolvedValue(quickProposal());
  const recovery = publicationController({ phase: "idle", attempt: null, receipt: null, error: null });
  const w = workflow(recovery.controller, () => {
    recovery.emit({ phase: "uncertain", attempt: publicationAttempt(), receipt: null, error: "Read unavailable" });
    return Promise.reject(new Error("Read unavailable"));
  });
  await act(async () => { await w.result.current.quick(); });
  await waitFor(() => expect(w.result.current.state.error).toBe("Read unavailable"));
  expect(w.result.current.publicationPending).toBe(true);
  expect(w.result.current.open).toBe(false);
  expect(w.notice).not.toHaveBeenCalled();
  w.client.clear();
});

it("rechecks capabilities without changing the draft or submitting and rejects retained Run after a failed refresh", async () => {
  const caps = { model: "quick-local-v1" as const, available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} };
  const check = vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue(caps);
  const submit = vi.spyOn(quickMinimizationApi, "submit");
  const w = workflow();
  await act(async () => { await w.result.current.show(); });
  await waitFor(() => expect(w.result.current.capabilitiesReady).toBe(true));
  act(() => { w.result.current.expandHydrogens(false); w.result.current.allowRepair(false); w.result.current.iterations(37); });
  const draft = w.result.current.state.draft;
  const retainedRun = w.result.current.run;
  let reject!: (error: Error) => void;
  check.mockImplementationOnce(() => new Promise((_resolve, fail) => { reject = fail; }));
  let checking!: Promise<void>;
  act(() => { checking = w.result.current.recheckCapabilities(); });
  await waitFor(() => expect(w.result.current.capabilitiesLoading).toBe(true));
  await act(async () => { await retainedRun(); });
  expect(submit).not.toHaveBeenCalled();
  await act(async () => { reject(new Error("Availability transport failed")); await checking; });
  await waitFor(() => expect(w.result.current.capabilitiesError).toContain("Availability transport failed"));
  expect(w.result.current.capabilities?.available).toBe(true);
  expect(w.result.current.capabilitiesReady).toBe(false);
  expect(w.result.current.capabilitiesError).toContain("Availability transport failed");
  expect(w.result.current.state.draft).toBe(draft);
  await act(async () => { await w.result.current.quick(); });
  expect(submit).not.toHaveBeenCalled();
  expect(w.result.current.state.draft).toBe(draft);
  await act(async () => { await retainedRun(); });
  expect(submit).not.toHaveBeenCalled();
  check.mockResolvedValueOnce({ ...caps, available: false, unavailable_reason: "Quick plugin disabled" });
  await act(async () => { await w.result.current.recheckCapabilities(); await retainedRun(); });
  expect(submit).not.toHaveBeenCalled();
  expect(w.result.current.error).toBe("Quick plugin disabled");
  check.mockResolvedValueOnce(caps);
  await act(async () => { await w.result.current.recheckCapabilities(); });
  await waitFor(() => expect(w.result.current.capabilitiesReady).toBe(true));
  expect(w.result.current.state.draft).toBe(draft);
  expect(submit).not.toHaveBeenCalled();
  w.client.clear();
});

it("explicitly recaptures current targets while retaining settings and surviving manual choices without submitting", async () => {
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const submit = vi.spyOn(quickMinimizationApi, "submit");
  const w = workflow();
  const first = { ...w.p, entries: [...w.p.entries, molecularEntry("removed", "Removed context", "ligand")] };
  w.rerender({ currentProject: first, currentSelection: selection });
  await act(async () => { await w.result.current.show(); await w.result.current.mode("environment"); });
  act(() => { w.result.current.include("ligand", true); w.result.current.include("removed", true);
    w.result.current.expandHydrogens(false); w.result.current.allowRepair(false); w.result.current.iterations(37); });
  const before = w.result.current.state;
  const latest = { ...w.p, revision: w.p.revision + 1, entries: w.p.entries.map(entry => ({ ...entry, locked: false })) };
  const selected: Selection = { ...selection, atoms: [{ structure_id: "ligand", atom_id: 1 }] };
  w.rerender({ currentProject: latest, currentSelection: selected });
  expect(w.result.current.state.draft?.selection).toEqual(selection);
  expect(w.result.current.state.draft?.project.revision).toBe(first.revision);
  expect(w.result.current.requestError).toBe("Project changed. Use current selection to refresh this setup.");
  await act(async () => { await w.result.current.run(); });
  expect(submit).not.toHaveBeenCalled();
  expect(w.result.current.state.draft).toBe(before.draft);
  expect(w.result.current.state.autoApply).toBe(false);
  act(() => { w.result.current.recapture(); });
  const next = w.result.current.state;
  expect(next.generation).toBe(before.generation + 1);
  expect(next.draft).toMatchObject({ project: latest, selection: selected, mode: "environment", expandHydrogens: false, allowRepair: false, iterations: 37 });
  expect([...next.draft!.included]).toEqual(["ligand"]);
  expect(next.jobId).toBeNull(); expect(next.autoApply).toBe(false);
  expect(w.result.current.quickSummary).toMatchObject({ requested: 1, movable: null, fixed: null });
  selected.atoms[0].atom_id = 99;
  expect(next.draft?.selection.atoms[0].atom_id).toBe(1);
  expect(submit).not.toHaveBeenCalled();
  w.client.clear();
});

it("shows quick capability reasons beside Run and keeps scientific controls under More settings", async () => {
  vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: false, unavailable_reason: "Quick plugin disabled", prerequisites: [], scientific_limits: [], limits: {} });
  const w = workflow();
  await act(async () => { await w.result.current.show(); });
  await waitFor(() => expect(w.result.current.capabilitiesLoading).toBe(false));
  const panel = () => <MinimizationPanel workflow={w.result.current} unavailable={null} onOpen={() => {}} />;
  const view = render(panel(), { wrapper: w.wrapper });
  expect(view.getByRole("status")).toHaveTextContent("Quick plugin disabled");
  expect(view.getByRole("button", { name: "Run quick minimization" })).toBeDisabled();
  expect(view.getByRole("button", { name: "Check again" })).toBeEnabled();
  expect(view.getByText("More settings").closest("details")).not.toHaveAttribute("open");
  expect(view.getByLabelText("Move attached terminal hydrogens").closest("details")).toBeNull();
  act(() => { w.result.current.expandHydrogens(false); }); view.rerender(panel());
  expect(view.getByRole("dialog")).toHaveAccessibleDescription("Only captured selected atoms move. Unselected atoms stay fixed.");
  w.client.clear();
});

it("does not authorize stale availability while an offline recheck is paused", async () => {
  const check = vi.spyOn(quickMinimizationApi, "capabilities").mockResolvedValue({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} });
  const submit = vi.spyOn(quickMinimizationApi, "submit");
  const w = workflow();
  await act(async () => { await w.result.current.show(); });
  await waitFor(() => expect(w.result.current.capabilitiesReady).toBe(true));
  const retainedRun = w.result.current.run;
  let checking!: Promise<void>;
  try {
    act(() => { onlineManager.setOnline(false); checking = w.result.current.recheckCapabilities(); });
    await waitFor(() => expect(w.result.current.capabilitiesPaused).toBe(true));
    expect(w.result.current.capabilitiesLoading).toBe(false);
    expect(w.result.current.capabilitiesReady).toBe(false);
    await act(async () => { await retainedRun(); await w.result.current.quick(); });
    expect(submit).not.toHaveBeenCalled();
    expect(check).toHaveBeenCalledOnce();
    await act(async () => { onlineManager.setOnline(true); await checking; });
    await waitFor(() => expect(w.result.current.capabilitiesReady).toBe(true));
    expect(submit).not.toHaveBeenCalled();
  } finally { onlineManager.setOnline(true); w.client.clear(); }
});

it("does not recapture a different selection into an existing setup", async () => {
  const w = workflow();
  await act(async () => { await w.result.current.configure("quick"); });
  const captured = useMinimizationStore.getState().draft, generation = useMinimizationStore.getState().generation;
  w.rerender({ currentProject: w.p, currentSelection: { ...selection, atoms: [{ structure_id: "protein", atom_id: 2 }] } });
  await act(async () => { expect(await w.result.current.configure("quick")).toBe(false); });
  expect(useMinimizationStore.getState().generation).toBe(generation);
  expect(useMinimizationStore.getState().draft).toBe(captured);
  w.client.clear();
});
it("rejects a selection change while advanced setup sources are loading without submitting", async () => {
  let release!: (value: ReturnType<typeof proteinStructure>) => void;
  vi.spyOn(minimizationApi, "source").mockImplementation(() => new Promise(resolve => { release = resolve; }));
  const submit = vi.spyOn(minimizationApi, "submit"); const w = workflow();
  let opening!: Promise<boolean>;
  act(() => { opening = w.result.current.configure("amber"); });
  await waitFor(() => expect(minimizationApi.source).toHaveBeenCalledOnce());
  w.rerender({ currentProject: w.p, currentSelection: { ...selection, atoms: [{ structure_id: "protein", atom_id: 2 }] } });
  await act(async () => { release(proteinStructure()); expect(await opening).toBe(false); });
  expect(useMinimizationStore.getState().error).toContain("selection changed"); expect(submit).not.toHaveBeenCalled(); w.client.clear();
});
it("refuses an unresolved or completed unapplied calculation when another setup is requested", async () => {
  const cancel = vi.spyOn(jobApi, "cancel"), w = workflow();
  for (const status of ["missing", "completed"] as const) {
    if (status === "completed") w.client.setQueryData(["job", "retained"], { id: "retained", status: "completed" } as Job);
    act(() => { const state = useMinimizationStore.getState(); state.patch(state.generation, { jobId: "retained", draft: null, applied: false }); });
    await act(async () => { expect(await w.result.current.configure("quick")).toBe(false); });
    expect(useMinimizationStore.getState().jobId).toBe("retained");
  }
  expect(cancel).not.toHaveBeenCalled(); w.client.clear();
});


it("rechecks the combined edit guard after held capabilities without dispatch or a repeated start side effect", async () => {
  let release!: (value: Awaited<ReturnType<typeof quickMinimizationApi.capabilities>>) => void;
  vi.spyOn(quickMinimizationApi, "capabilities").mockImplementation(() => new Promise(resolve => { release = resolve; }));
  const submit = vi.spyOn(quickMinimizationApi, "submit"); let writable = true;
  const guard = vi.fn(() => { if (!writable) throw new Error("An edit is now unresolved"); });
  const w = workflow(undefined, undefined, guard); let pending!: Promise<void>;
  act(() => { pending = w.result.current.quick(); });
  await waitFor(() => expect(quickMinimizationApi.capabilities).toHaveBeenCalledOnce()); writable = false;
  await act(async () => { release({ model: "quick-local-v1", available: true, unavailable_reason: null, prerequisites: [], scientific_limits: [], limits: {} }); await pending; });
  expect(submit).not.toHaveBeenCalled(); expect(useMinimizationStore.getState().error).toContain("An edit is now unresolved"); w.client.clear();
});
