import { useLayoutEffect, type RefObject } from "react";
import { useEditingStore } from "../store/editing";

/** Viewport-owned tool placement; notification geometry never becomes domain state. */
export function useEditPanelPosition(
  open: boolean, projectId: string, launcher: RefObject<HTMLButtonElement | null>,
  content: RefObject<HTMLElement | null>, inspecting = false,
) {
  useLayoutEffect(() => {
    const button = launcher.current;
    const state = useEditingStore.getState();
    const generation = state.generation;
    if (state.projectId === projectId && state.launcherFocusRequested) {
      if (document.activeElement === document.body || !document.activeElement?.isConnected) button?.focus();
      state.setLauncherFocusRequested(false);
    }
    return () => {
      const current = useEditingStore.getState();
      if (current.projectId === projectId && current.generation === generation && !current.open && button === document.activeElement) current.setLauncherFocusRequested(true);
    };
  }, [projectId, launcher]);
  useLayoutEffect(() => {
    if (!open || !content.current) return;
    const panel = content.current;
    let frame: number | null = null;
    let observedNotice: Element | null = null;
    const position = () => {
      const anchor = launcher.current?.getBoundingClientRect();
      const workspace = launcher.current?.closest(".structure-viewer")?.getBoundingClientRect();
      const viewport = window.visualViewport;
      const viewportLeft = viewport?.offsetLeft ?? 0, viewportTop = viewport?.offsetTop ?? 0;
      const viewportRight = viewportLeft + (viewport?.width ?? window.innerWidth);
      const viewportBottom = viewportTop + (viewport?.height ?? window.innerHeight);
      let leftBound = Math.max(viewportLeft + 8, workspace?.left ?? viewportLeft + 8);
      let rightBound = Math.min(viewportRight - 8, workspace?.right || viewportRight - 8);
      if (rightBound - leftBound < 120) { leftBound = viewportLeft + 8; rightBound = viewportRight - 8; }
      const width = Math.max(80, Math.min(300, rightBound - leftBound));
      const left = Math.max(leftBound, Math.min(anchor?.left ?? leftBound, rightBound - width));
      if (inspecting) {
        const bottom = Math.min(viewportBottom - 8, (workspace?.bottom ?? viewportBottom) - 8);
        // Measure after the new width/height constraints, including visual zoom.
        panel.style.width = `${width}px`;
        panel.style.maxHeight = `${Math.max(44, bottom - Math.max(viewportTop, workspace?.top ?? viewportTop) - 8)}px`;
        const height = panel.getBoundingClientRect().height;
        Object.assign(panel.style, { left: `${left}px`, top: `${Math.max(viewportTop + 8, bottom - height)}px`, width: `${width}px`, maxHeight: `${Math.max(44, bottom - Math.max(viewportTop, workspace?.top ?? viewportTop) - 8)}px` });
        return;
      }
      let top = (anchor?.bottom ?? 60) + 6;
      const notice = document.querySelector(".notice");
      if (notice !== observedNotice) {
        if (observedNotice) resize?.unobserve(observedNotice);
        if (notice) resize?.observe(notice);
        observedNotice = notice;
      }
      const noticeBox = notice?.getBoundingClientRect();
      if (noticeBox && left < noticeBox.right && left + width > noticeBox.left && top < noticeBox.bottom + 8) {
        top = noticeBox.bottom + 8;
      }
      top = Math.max(viewportTop + 8, Math.min(top, viewportBottom - 100));
      Object.assign(panel.style, { left: `${left}px`, top: `${top}px`, width: `${width}px`,
        maxHeight: `${Math.max(44, Math.min(520, viewportBottom - top - 12))}px` });
    };
    const schedule = () => {
      if (frame !== null) return;
      frame = requestAnimationFrame(() => { frame = null; position(); });
    };
    const resize = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(schedule);
    const workspace = launcher.current?.closest(".structure-viewer");
    if (workspace) resize?.observe(workspace);
    const mutation = new MutationObserver(schedule);
    mutation.observe(document.body, { childList: true, subtree: true, characterData: true });
    window.addEventListener("resize", schedule);
    window.visualViewport?.addEventListener("resize", schedule);
    window.visualViewport?.addEventListener("scroll", schedule);
    position();
    if (useEditingStore.getState().focusRequested) {
      panel.focus(); useEditingStore.getState().setFocusRequested(false);
    }
    return () => {
      if (frame !== null) cancelAnimationFrame(frame);
      resize?.disconnect(); mutation.disconnect(); window.removeEventListener("resize", schedule);
      window.visualViewport?.removeEventListener("resize", schedule);
      window.visualViewport?.removeEventListener("scroll", schedule);
      const state = useEditingStore.getState();
      if (state.projectId === projectId && state.open && panel.contains(document.activeElement)) state.setFocusRequested(true);
    };
  }, [open, projectId, launcher, content, inspecting]);
}
