from neistra_api.main import create_app
from neistra_api import edit_execution
from tests.support.edit_execution_workers import waiting_child
edit_execution.run_edit_child = waiting_child
app = create_app()
