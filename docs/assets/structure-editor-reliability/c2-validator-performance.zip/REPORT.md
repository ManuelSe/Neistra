# C2 validator performance qualification

Verdict: PASS for the bounded validator correction at the source identities below. This is not full application completion, mutation-latency qualification, or reference-host certification.

Candidate: /datadisk/dev/neistra-worktrees/issue-147-science. Canonical protein.py SHA-256 `33245193d262cb0dcaf2090dca937905e61a5d55d62aa3ade07887a179ad8be7`; model.py `5ced90a8353ccde20d5e49fb5793097eac11cbf84c0bc7a0734b5f0f65160ff1`. Source hashes before/after every workload and across all workloads are identical.

## Correctness and actual work

24 small-cloud oracles use the original dense NumPy axis=2 expression, diagonal infinity, and strict minimum <0.4. They include coincident/tied/collinear inputs, adjacent floating-point thresholds, diagonal geometry, seeded random clouds, and both supplied reduction-drift vectors with both signs. All pass. Three nonfinite inputs reject before queries; two active-conformer checks confirm the nonfirst active frame controls the decision.

19 profiled workloads, three validations each (57 calls), all pass. Instrumentation wraps the real pinned cKDTree without replacing its search. Every validation starts with exactly one queried row; subsequent batches have exactly32 rows except the final remainder. Search uses exact Euclidean k=2, eps=0, workers=1. Pair/radius enumeration is forbidden by the harness. All-coincident cases through1,000,000 atoms query exactly one row. An isolated first atom followed by a coincident cluster queries33 rows, then exits.

## Measurements

Elapsed values are medians of three actual-validator calls. Whole-process RSS includes scientific/native imports and fixture construction. Linux /proc sampling every25ms additionally covers native allocations in the process RSS; it is not allocation-source attribution or a hard memory guarantee.

| Workload | Atoms | Median validator ms | Whole-process peak MiB | Queried rows per call |
|---|---:|---:|---:|---:|
| grid-500 | 500 | 1.97 | 145.15 | 500 |
| grid-1000 | 1,000 | 3.96 | 146.25 | 1,000 |
| grid-2000 | 2,000 | 7.92 | 148.11 | 2,000 |
| grid-3000 | 3,000 | 12.42 | 149.75 | 3,000 |
| grid-5000 | 5,000 | 20.16 | 153.65 | 5,000 |
| grid-10000 | 10,000 | 40.90 | 162.72 | 10,000 |
| grid-30000 | 30,000 | 137.90 | 199.82 | 30,000 |
| grid-100000 | 100,000 | 459.66 | 326.81 | 100,000 |
| coincident-1000 | 1,000 | 0.43 | 145.96 | 1 |
| coincident-10000 | 10,000 | 4.38 | 162.47 | 1 |
| coincident-100000 | 100,000 | 58.44 | 325.46 | 1 |
| coincident-1000000 | 1,000,000 | 623.60 | 1924.00 | 1 |
| isolated-cluster-1000 | 1,000 | 0.50 | 146.28 | 33 |
| isolated-cluster-10000 | 10,000 | 4.67 | 162.15 | 33 |
| isolated-cluster-100000 | 100,000 | 62.69 | 325.38 | 33 |
| late-pair-100000 | 100,000 | 454.16 | 326.29 | 100,000 |
| tied-nonclash-100000 | 100,000 | 414.49 | 325.62 | 100,000 |
| real-0 | 1,001 | 4.13 | 150.84 | 1,001 |
| real-large-0 | 58,870 | 272.63 | 515.63 | 58,870 |

The million-atom coincident fixture takes4656.65ms to construct; its historical process peak before validation is1846.95MiB, and the final peak is1924.00MiB. It completes within the isolated diagnostic4GiB resident/300-second guard; no production settings were installed or modified. For real58,870-atom input, parsing/preparation takes1641.51ms and creates the515.63MiB historical peak; validation-phase sampled peak is463.68MiB.

## Reused baseline and interpretation

baseline-reuse.json verifies66 canonical source/dependency identities against both before/after snapshots in the qualified cc54cd32 release gate. The previous quadratic-validator measurements remain valid and were not rerun. The3,000-atom baseline observed190.81ms and670.35MiB; the new3,000-atom workload observed12.42ms and149.75MiB. The old5,000-atom profile failed under its explicitly diagnostic1GiB address-space ceiling; new5,000-atom validation completes at20.16ms/153.65MiB.

These are separate observations: grid layout, harness/import footprint and concurrent host load differ. No controlled speedup ratio is claimed. The algorithmic bound, actual query counts, source equivalence and elimination of the prior allocation failure support this correction. There is no universal linear-time or arbitrary-capacity claim; million-atom nonclashing chemistry/mutation was not qualified.

## Reproduction

Run from an external directory, after freezing the intended candidate. Write into a fresh output directory:

```bash
PYTHONDONTWRITEBYTECODE=1 /datadisk/dev/neistra-worktrees/issue-147-science/.venv/bin/python \
  /datadisk/dev/neistra-audits/structure-editing-2026-11-14/issue147-c2-performance/qualify_validator.py run \
  --repo /datadisk/dev/neistra-worktrees/issue-147-science \
  --python /datadisk/dev/neistra-worktrees/issue-147-science/.venv/bin/python \
  --output /datadisk/dev/neistra-audits/structure-editing-2026-11-14/issue147-c2-performance/candidate-reproduction \
  --max-batch 32 --include-real
```

The parent runner forces PYTHONDONTWRITEBYTECODE=1, single-thread numerical-library settings, candidate-only PYTHONPATH, separate subprocesses and external working/output directories. It records commands, output hashes and process-RSS samples.

## Evidence and remaining scope

candidate-final1/summary.json contains process commands, exits, resource samples and output hashes; individual stdout JSON contains immutable source identities, package versions, each timing/query trace and pinned fixture hashes. candidate-final1-analysis.json verifies every output hash, all source identities and batch bounds. No workload failed, timed out or exceeded the sampled resident-memory guard.

No source/docs edits, Git actions, new agents, servers, production policy changes or publications were performed. These calls exercise the actual validator, not complete mutation/template construction or publication. C3 cancellation, serviceability, transport and atomic publication need their own qualification. Strict timing was not enabled; preserve existing production and performance policies.
