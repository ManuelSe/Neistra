import json, os, resource, statistics, sys, time
from pathlib import Path
from neistra_core.adapters.macromolecular import PdbAdapter
from neistra_core.editing.protein import ProteinStructureValidator
from neistra_core.molecular import Conformer, NormalizedStructureV1
n=int(sys.argv[1])
base=PdbAdapter().parse(Path('tests/fixtures/formats/protein_editing.pdb').read_bytes(),'protein.pdb').structures[0]
r=base.residues[0]; chain=base.chains[0]; seed=base.atoms[0]
coords=[(float(i%32)*2.,float((i//32)%32)*2.,float(i//1024)*2.) for i in range(n)]
atoms=[seed.model_copy(update={'id':i+1,'source_index':i,'name':f'X{i}','residue_id':r.id,'coordinates':coords[i]}) for i in range(n)]
s=NormalizedStructureV1(title='Validator scaling fixture',structure_type='protein',source=base.source,atoms=atoms,bonds=[],chains=[chain],residues=[r],conformers=[Conformer(id=1,name='Model',coordinates=coords)])
# Keep this diagnostic subprocess bounded; no application or host limit is modified.
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
before=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
samples=[]
try:
 for _ in range(3):
  start=time.perf_counter(); warnings=ProteinStructureValidator().validate(s,'profile'); samples.append((time.perf_counter()-start)*1000)
 print(json.dumps({'n':n,'samples_ms':samples,'median_ms':statistics.median(samples),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'baseline_peak_rss_kib':before,'warnings':[w.code for w in warnings],'status':'ok'}))
except MemoryError as error:
 print(json.dumps({'n':n,'samples_ms':samples,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'baseline_peak_rss_kib':before,'status':'MemoryError','error':str(error)}))
