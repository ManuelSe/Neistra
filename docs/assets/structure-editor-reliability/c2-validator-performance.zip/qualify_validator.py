#!/usr/bin/env python3
"""External-only source-bound qualification; do not run candidate mode before readiness."""
from __future__ import annotations
import argparse, hashlib, importlib.metadata, json, os, platform, resource
from pathlib import Path
import statistics, subprocess, sys, time
CORE='packages/neistra_core/src/neistra_core'
PROTEIN=CORE+'/editing/protein.py'
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identities(root):
    files=[*sorted((root/CORE).rglob('*.py')),root/'uv.lock',root/'pyproject.toml']
    return {str(p.relative_to(root)):digest(p) for p in files}
def prepare(a):
    root=Path(a.repo).resolve(); ids=identities(root)
    path=root/'docs/assets/surface-selection-hydrogen-toggle/c4-master1-gate.json'
    gate=json.loads(path.read_text())
    bad=[p for p,h in ids.items() if h!=gate['source_before'].get(p) or h!=gate['source_after'].get(p)]
    report={'status':'baseline-reuse-verified' if not bad else 'mismatch','mismatches':bad,
      'source_sha256':ids,'qualified_baseline_commit':gate['commit'],'qualified_gate_sha256':digest(path),
      'harness_sha256':digest(__file__),'baseline_script_sha256':digest(Path(__file__).parent.parent/'neistra-editing-validator-profile.py'),
      'baseline_measurements':[{'n':500,'median_ms':8.373062999453396,'peak_rss_kib':135312},
        {'n':1000,'median_ms':26.75860101589933,'peak_rss_kib':183040},
        {'n':2000,'median_ms':87.95837999787182,'peak_rss_kib':372720},
        {'n':3000,'median_ms':190.80640602624044,'peak_rss_kib':686436},
        {'n':5000,'status':'diagnostic-MemoryError','peak_rss_kib':714308}],
      'baseline_scope':'Previously measured validator, diagnostic1GiB AS ceiling, no new execution',
      'platform':platform.platform(),'python':sys.version,
      'versions':{p:importlib.metadata.version(p) for p in ('numpy','scipy','pydantic','openmm')}}
    Path(a.output).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'matched_sources':len(ids)-len(bad),'mismatches':bad}))
    return bool(bad)
def worker(a):
    root=Path(a.repo).resolve(); before=identities(root)
    import numpy as np
    import scipy.spatial as spatial
    trace={'active':False,'builds':0,'batches':[]}; real=spatial.cKDTree
    class TracingTree:
        def __init__(self,*args,**kw):
            if trace['active']:trace['builds']+=1
            self.native=real(*args,**kw)
        def query(self,points,*args,**kw):
            if trace['active']:
                trace['batches'].append(1 if np.asarray(points).ndim==1 else len(points))
                assert kw.get('k',args[0] if args else 1)==2
                assert kw.get('eps',0)==0 and kw.get('p',2)==2 and kw.get('workers',1)==1
            return self.native.query(points,*args,**kw)
        def query_pairs(self,*args,**kw):raise AssertionError('Forbidden pair enumeration')
        def query_ball_point(self,*args,**kw):raise AssertionError('Forbidden radius enumeration')
        def __getattr__(self,name):return getattr(self.native,name)
    spatial.cKDTree=TracingTree
    from neistra_core.adapters.macromolecular import PdbAdapter
    from neistra_core.editing.protein import ProteinStructureValidator,InvalidProteinEditError
    from neistra_core.molecular import Conformer,NormalizedStructureV1
    base=PdbAdapter().parse((root/'tests/fixtures/formats/protein_editing.pdb').read_bytes(),'protein.pdb').structures[0]
    seed,residue,chain=base.atoms[0],base.residues[0],base.chains[0]
    def make(points):
        pts=[tuple(map(float,p)) for p in points]
        atoms=[seed.model_copy(update={'id':i+1,'source_index':i,'name':f'X{i}',
          'residue_id':residue.id,'coordinates':p}) for i,p in enumerate(pts)]
        return NormalizedStructureV1(title='Validator qualification',structure_type='protein',source=base.source,
          atoms=atoms,bonds=[],chains=[chain],residues=[residue],conformers=[Conformer(id=1,name='Active',coordinates=pts)])
    def oracle(points):
        pts=np.asarray(points,dtype=np.float64).reshape((-1,3))
        if len(pts)<2:return False
        d=np.linalg.norm(pts[:,None,:]-pts[None,:,:],axis=2);np.fill_diagonal(d,np.inf)
        return bool(np.min(d)<.4)
    def call(s):
        trace.update(active=True,builds=0,batches=[]);start=time.perf_counter()
        try:warnings=ProteinStructureValidator().validate(s,'qualification')
        finally:trace['active']=False
        batches=list(trace['batches'])
        if len(s.atoms)>1:
            assert batches and batches[0]==1,'Expected first row alone'
            assert max(batches)<=a.max_batch,'Query batch bound exceeded'
            assert sum(batches)<=len(s.atoms),'Excess queried rows'
        return {'start_monotonic':start,'end_monotonic':time.perf_counter(),'elapsed_ms':(time.perf_counter()-start)*1000,'codes':[w.code for w in warnings],
          'clash':any(w.code=='severe_atomic_clash' for w in warnings),'tree_builds':trace['builds'],
          'batches':batches,'queried_rows':sum(batches)}
    if a.shape=='oracle':
        cases=[]
        def add(name,pts):cases.append((name,np.asarray(pts,dtype=float).reshape((-1,3))))
        add('empty',[]);add('single',[[0,0,0]])
        for v,name in [(np.nextafter(.4,0),'below'),(.4,'equal'),(np.nextafter(.4,np.inf),'above')]:
            add('threshold-'+name,[[0,0,0],[v,0,0]])
            add('translated-'+name,[[8,0,0],[8+v,0,0]])
        add('coincident',np.zeros((67,3)))
        add('isolated-first-cluster',np.r_[[[100,100,100]],np.zeros((67,3))])
        add('collinear-ties',[[i*.5,0,0] for i in range(129)])
        add('boundary-square',[[0,0,0],[.4,0,0],[0,.4,0],[.4,.4,0]])
        add('diagonal-boundary',[[0,0,0],[.24,.32,0]])
        drift_vectors=[[-.007012883902680816,-.378476683284495,.12925254221614194],
                       [-.012801681141727094,-.14073765995054316,.37420452700574164]]
        for i,v in enumerate(drift_vectors):
            for sign in (-1,1):add(f'axis-reduction-{i}-{sign}',[[0,0,0],np.asarray(v)*sign])
        rng=np.random.default_rng(147)
        for n in (2,3,7,31,65,129,257):add('seeded-'+str(n),rng.uniform(-5,5,(n,3)))
        results=[]
        for name,pts in cases:
            result=call(make(pts));expected=oracle(pts)
            assert result['clash']==expected,(name,result,expected)
            results.append(dict(result,name=name,n=len(pts),expected=expected))
        for value in (float('nan'),float('inf'),float('-inf')):
            s=make([[0,0,0],[0,0,0],[value,1,1]])
            trace.update(active=True,builds=0,batches=[])
            try:ProteinStructureValidator().validate(s,'qualification')
            except InvalidProteinEditError:pass
            else:raise AssertionError('Nonfinite coordinates accepted')
            finally:trace['active']=False
            assert not trace['batches'],'Nonfinite input reached spatial queries'
        # A nonfirst active conformer controls this predicate; inactive overlap is irrelevant.
        frames=make([[0,0,0],[0,0,0]])
        frames=frames.model_copy(update={'active_conformer_id':2,'conformers':[
            frames.conformers[0],Conformer(id=2,name='Active second',coordinates=[(0.,0.,0.),(2.,0.,0.)])]})
        second_clear=call(frames); assert not second_clear['clash']
        frames=frames.model_copy(update={'active_conformer_id':1})
        first_overlap=call(frames); assert first_overlap['clash']
        report={'kind':'oracle','cases':results,'nonfinite_rejections':3,
                'active_frame_checks':[second_clear,first_overlap]}
    else:
        start=time.perf_counter(); fixture=None
        if a.shape=='real':
            path=root/a.fixture
            if path.suffix.lower()=='.cif':
                from neistra_core.adapters.macromolecular import MmcifAdapter
                adapter=MmcifAdapter()
            else:adapter=PdbAdapter()
            s=adapter.parse(path.read_bytes(),path.name).structures[0]
            fixture={'path':a.fixture,'sha256':digest(path)}
        else:
            n=a.n;idx=np.arange(n,dtype=np.int64)
            pts=np.column_stack(((idx%128)*2.,((idx//128)%128)*2.,(idx//16384)*2.))
            if a.shape=='coincident':pts.fill(0.)
            elif a.shape=='isolated-cluster':pts.fill(0.);pts[0]=[100,100,100]
            elif a.shape=='late-pair':pts[-1]=pts[-2]+[.25,0,0]
            elif a.shape=='tied-nonclash':pts=np.column_stack((idx*.5,np.zeros(n),np.zeros(n)))
            s=make(pts)
        prep=(time.perf_counter()-start)*1000;fixture_ready_monotonic=time.perf_counter();baseline=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        samples=[call(s) for _ in range(a.repeats)]
        if a.shape=='coincident':assert all(x['clash'] and x['queried_rows']==1 for x in samples)
        if a.shape in ('grid','tied-nonclash'):assert all(not x['clash'] and x['queried_rows']==len(s.atoms) for x in samples)
        if a.shape in ('isolated-cluster','late-pair'):assert all(x['clash'] for x in samples)
        report={'kind':'profile','shape':a.shape,'n':len(s.atoms),'preparation_ms':prep,
          'fixture_ready_monotonic':fixture_ready_monotonic,'baseline_peak_rss_kib':baseline,'samples':samples,'median_ms':statistics.median(x['elapsed_ms'] for x in samples),'fixture':fixture}
    assert identities(root)==before,'Candidate changed; discard run'
    report.update(status='pass',source_sha256=before,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
      platform=platform.platform(),python=sys.version,harness_sha256=digest(__file__),strict_timing_qualified=False,
      versions={p:importlib.metadata.version(p) for p in ('numpy','scipy','pydantic','openmm')})
    print(json.dumps(report),flush=True);return 0
def run(a):
    out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True);root=Path(a.repo).resolve()
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',
      PYTHONPATH=str(root/'apps/api/src')+':'+str(root/'packages/neistra_core/src'))
    workloads=[('oracle',0)]+[('grid',n) for n in (500,1000,2000,3000,5000,10000,30000,100000)]
    workloads += [('coincident',n) for n in (1000,10000,100000,1000000)]
    workloads += [('isolated-cluster',n) for n in (1000,10000,100000)]+[('late-pair',100000),('tied-nonclash',100000)]
    if a.include_real:workloads += [('real',0),('real-large',0)]
    summary=[]
    for shape,n in workloads:
        case=f'{shape}-{n}';raw=out/(case+'.stdout.json');err=out/(case+'.stderr.log')
        cmd=[a.python,str(Path(__file__).resolve()),'worker','--repo',str(root),'--shape',
          'real' if shape=='real-large' else shape,'--n',str(n),'--repeats',str(a.repeats),'--max-batch',str(a.max_batch)]
        if shape.startswith('real'):cmd += ['--fixture','tests/fixtures/surfaces/1aon.cif' if shape=='real-large' else 'tests/fixtures/complex/1stp.pdb']
        print(json.dumps({'event':'starting','case':case}),flush=True)
        start=time.monotonic();peak=0;stopped=None;rss_samples=[]
        with raw.open('w') as stdout,err.open('w') as stderr:
            process=subprocess.Popen(cmd,cwd=out,env=env,stdout=stdout,stderr=stderr)
            while process.poll() is None:
                try:
                    status=Path(f'/proc/{process.pid}/status').read_text()
                    rss=int(next(x for x in status.splitlines() if x.startswith('VmRSS:')).split()[1])*1024;peak=max(peak,rss);rss_samples.append([time.monotonic(),rss])
                except (OSError,StopIteration):pass
                if peak>4*1024**3:stopped='diagnostic-existing-4GiB-resident-budget';process.kill()
                elif time.monotonic()-start>300:stopped='diagnostic-existing-300s-wall-budget';process.kill()
                time.sleep(.025)
            process.wait()
        item={'case':case,'returncode':process.returncode,'elapsed_s':time.monotonic()-start,
          'rss_samples':rss_samples,'sampled_peak_rss_bytes':peak,'stopped':stopped,'stdout_sha256':digest(raw),'stderr_sha256':digest(err),'command':cmd}
        summary.append(item);(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(item),flush=True)
        if process.returncode or stopped:return 1
    return 0
def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','worker','run']);p.add_argument('--repo',required=True)
    p.add_argument('--output',default='preparation.json');p.add_argument('--python',default='/datadisk/dev/neistra/.venv/bin/python')
    p.add_argument('--shape',default='oracle');p.add_argument('--n',type=int,default=1000);p.add_argument('--repeats',type=int,default=3)
    p.add_argument('--max-batch',type=int,default=256);p.add_argument('--fixture',default='tests/fixtures/complex/1stp.pdb');p.add_argument('--include-real',action='store_true')
    a=p.parse_args();return {'prepare':prepare,'worker':worker,'run':run}[a.mode](a)
if __name__=='__main__':raise SystemExit(main())
