Neistra 0.32.0 c6r-candidate2 qualification

Exact qualified commit: 1dfab40136d54a1f7d08348c045f4617a7d12e56
All 35 commands run freshly and sequentially, with unchanged complete source inventories. All native observations and lossless logs are retained. Reader reports cover actual tagged 0.31.0 in both directions and both suffixes, including current-authored new editing states retained and reexported by the preceding writer. The preceding writer does not author the new fragment operations.

No partial command reuse, new exclusion, retry or scientific acceptance relaxation. This archive records this gate only; merge, release and closeout are separately verified. Manifest entries cover every other archived file by SHA-256; nested native traces receive CRC checks. Disposable data stores are not included; source-bound producer/reader tools reproduce the states.
