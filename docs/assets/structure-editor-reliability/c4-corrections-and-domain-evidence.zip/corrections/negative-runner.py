import gzip,hashlib,json,subprocess
from pathlib import Path
out=Path('/tmp/neistra147-c4-corrections-v1')
records=[]
for label,command in json.loads(Path('/tmp/neistra147-c4-negative-commands.json').read_text()):
 print('START expected-failure',label,flush=True)
 with (out/(label+'.log')).open('wb') as log:
  p=subprocess.run(command,cwd='/datadisk/dev/neistra-worktrees/issue-147',stdout=log,stderr=subprocess.STDOUT)
 raw=(out/(label+'.log')).read_bytes()
 (out/(label+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
 records.append({'label':label,'command':command,'exit_code':p.returncode,'lossless_sha256':hashlib.sha256(raw).hexdigest(),'expected_failure':True})
 print('END expected-failure',label,p.returncode,flush=True)
 assert p.returncode==1,raw.decode()
(out/'negative-receipt.json').write_text(json.dumps(records,indent=2)+'\n')
