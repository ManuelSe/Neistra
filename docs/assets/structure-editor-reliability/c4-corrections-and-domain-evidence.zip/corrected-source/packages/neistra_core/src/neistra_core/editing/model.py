"""Authored molecular graph edits; chemistry libraries do not gate draft state."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, field, replace
from math import dist, isfinite
from typing import Annotated, Literal

import numpy as np
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    FiniteFloat,
    StrictFloat,
    StrictInt,
    field_validator,
)
from rdkit import Chem
from scipy.spatial import cKDTree  # type: ignore[import-untyped]

from neistra_core.editing.fragments import (
    PRESERVED_TEMPLATE_FRAGMENTS,
    FragmentName,
    qualified_template_atom_ids,
)
from neistra_core.editing.hydrogen import (
    Geometry,
    HydrogenBuilder,
    HydrogenReport,
    apply_hydrogen_proposal,
)
from neistra_core.editing.ligand import (
    BondRotationPlan,
    EditResult,
    InvalidLigandEditError,
    RdkitLigandEditor,
)
from neistra_core.editing.placement import place_atom, place_fragment
from neistra_core.editing.reconciliation import ReconciliationReport, reconcile_hydrogens
from neistra_core.editing.selection import SelectionEditResult
from neistra_core.editing.single_hydrogen import add_one_hydrogen
from neistra_core.hydrogen_protection import authored_protection
from neistra_core.modeling_metadata import (
    MODELING_METADATA as MODELING_METADATA,
)
from neistra_core.modeling_metadata import (
    InvalidModelingMetadata,
)
from neistra_core.modeling_metadata import (
    ModelingMetadata as ModelingMetadata,
)
from neistra_core.modeling_metadata import (
    modeling_metadata as _modeling_metadata,
)
from neistra_core.molecular import Bond, MolecularWarning, NormalizedStructureV1

HydrogenPolicy = Literal["preserve", "complete_if_possible", "reconcile_if_possible", "automatic"]
_MAX_BOND_GEOMETRY_DETAILS = 100


class InvalidModelEdit(ValueError):
    pass


class ModelActionBase(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ModelElement(ModelActionBase):
    operation: Literal["atom.element"]
    element: str = Field(min_length=1, max_length=3)

    @field_validator("element")
    @classmethod
    def recognized_element(cls, value: str) -> str:
        try:
            if Chem.GetPeriodicTable().GetAtomicNumber(value) < 1:
                raise ValueError("Choose a recognized chemical element.")
        except RuntimeError as error:
            raise ValueError("Choose a recognized chemical element.") from error
        return value


class ModelCharge(ModelActionBase):
    operation: Literal["atom.charge.set"]
    charge: StrictInt | None


class ModelDelete(ModelActionBase):
    operation: Literal["atom.delete"]


class ModelBondSet(ModelActionBase):
    operation: Literal["bond.set"]
    order: StrictFloat | None = Field(
        default=1.0, json_schema_extra={"enum": [None, 1.0, 1.5, 2.0, 3.0]}
    )

    @field_validator("order")
    @classmethod
    def represented_order(cls, value: float | None) -> float | None:
        if value not in {None, 1.0, 1.5, 2.0, 3.0}:
            raise ValueError("Choose unknown, single, double, triple or aromatic bond order.")
        return value


class ModelBondDelete(ModelActionBase):
    operation: Literal["bond.delete"]


class ModelBondRotate(ModelActionBase):
    operation: Literal["bond.rotate"]
    moving_endpoint_id: StrictInt = Field(ge=1)
    angle_degrees: FiniteFloat


class ModelAtomAdd(ModelActionBase):
    operation: Literal["atom.add"]
    element: str = Field(min_length=1, max_length=3)
    charge: StrictInt | None = 0
    direction: int = Field(default=0, ge=0, le=5, strict=True)
    coordinates: tuple[FiniteFloat, FiniteFloat, FiniteFloat] | None = None

    @field_validator("element")
    @classmethod
    def recognized_element(cls, value: str) -> str:
        return ModelElement.recognized_element(value)


class ModelFragmentAdd(ModelActionBase):
    operation: Literal["fragment.attach"]
    fragment: FragmentName
    direction: int = Field(default=0, ge=0, le=5, strict=True)
    rotation: int = Field(default=0, ge=0, le=5, strict=True)


class ModelHydrogenComplete(ModelActionBase):
    operation: Literal["hydrogens.complete"]
    scope: Literal["selection", "entry"] = "selection"


class ModelHydrogenAdd(ModelActionBase):
    operation: Literal["hydrogens.add"]
    count: int = Field(default=1, ge=1, le=4, strict=True)
    geometry: Geometry = "tetrahedral"
    orientation: int = Field(default=0, ge=0, le=5, strict=True)


class ModelHydrogenAddOne(ModelActionBase):
    operation: Literal["hydrogens.add_one"]


ModelAction = Annotated[
    ModelElement
    | ModelCharge
    | ModelDelete
    | ModelBondSet
    | ModelBondDelete
    | ModelBondRotate
    | ModelAtomAdd
    | ModelFragmentAdd
    | ModelHydrogenComplete
    | ModelHydrogenAdd
    | ModelHydrogenAddOne,
    Field(discriminator="operation"),
]


def modeling_metadata(structure: NormalizedStructureV1) -> ModelingMetadata:
    """Compatibility boundary retaining the direct editor's error type."""
    try:
        return _modeling_metadata(structure)
    except InvalidModelingMetadata as error:
        raise InvalidModelEdit(str(error)) from error


def model_warning(
    code: str, message: str, operation: str, field: str = "chemistry"
) -> MolecularWarning:
    return MolecularWarning(
        code=code,
        message=message,
        operation=f"model.{operation}",
        field=field,
    )


def _adjacency(structure: NormalizedStructureV1) -> dict[int, set[int]]:
    result: dict[int, set[int]] = {a.id: set() for a in structure.atoms}
    for bond in structure.bonds:
        result[bond.atom_1_id].add(bond.atom_2_id)
        result[bond.atom_2_id].add(bond.atom_1_id)
    return result


def _automatic_targets(
    before: NormalizedStructureV1,
    draft: NormalizedStructureV1,
    selected: list[int],
    action: ModelAction,
) -> tuple[list[int], set[int]]:
    """One-hop canonical edit operands; explicit H intent is operation-local."""
    old = {a.id: a for a in before.atoms}
    current = {a.id: a for a in draft.atoms}
    previous, following = _adjacency(before), _adjacency(draft)
    seeds = set(selected) | (current.keys() - old.keys())
    targets = seeds | {j for i in seeds for j in previous.get(i, set()) | following.get(i, set())}
    suppressed: set[int] = set()
    if isinstance(action, ModelDelete):
        suppressed = {j for i in selected if old[i].element in {"H", "D", "T"} for j in previous[i]}
    elif isinstance(action, (ModelBondSet, ModelBondDelete)) and any(
        old[i].element in {"H", "D", "T"} for i in selected
    ):
        suppressed = set(selected) | {
            j for i in selected if old[i].element in {"H", "D", "T"} for j in previous[i]
        }
    elif isinstance(action, ModelAtomAdd) and action.element == "H":
        suppressed = set(selected)
    return sorted(
        i for i in targets if i in current and current[i].element not in {"H", "D", "T"}
    ), suppressed


def _appearance_sources(
    before: NormalizedStructureV1,
    after: NormalizedStructureV1,
    selected: list[int],
    action: ModelAction,
) -> dict[int, int]:
    """Creation ancestry only; durable appearance is owned by the application."""
    old = {a.id: a for a in before.atoms}
    created = {a.id for a in after.atoms} - old.keys()
    sources: dict[int, int] = {}
    if isinstance(action, (ModelAtomAdd, ModelFragmentAdd)) and len(selected) == 1:
        anchor = selected[0]
        if old[anchor].element in {"H", "D", "T"}:
            neighbors = _adjacency(before)[anchor]
            anchor = next(iter(neighbors)) if len(neighbors) == 1 else anchor
        if old[anchor].element not in {"H", "D", "T"}:
            sources = {i: anchor for i in created}
    atoms = {a.id: a for a in after.atoms}
    for bond in after.bonds:
        for child, parent in [(bond.atom_1_id, bond.atom_2_id), (bond.atom_2_id, bond.atom_1_id)]:
            if (
                child in created
                and atoms[child].element == "H"
                and atoms[parent].element not in {"H", "D", "T"}
            ):
                sources[child] = parent
    return sources


@dataclass(frozen=True)
class ModelEditResult(SelectionEditResult):
    hydrogen_report: HydrogenReport | None = None
    hydrogen_reconciliation_report: ReconciliationReport | None = None
    appearance_sources: dict[int, int] = field(default_factory=dict)
    rotation: BondRotationPlan | None = None
    no_op: bool = False


class DirectMolecularEditor:
    def edit(
        self,
        before: NormalizedStructureV1,
        selected: list[int],
        action: ModelAction,
        *,
        next_atom_id: int,
        next_bond_id: int,
        hydrogen_policy: HydrogenPolicy = "preserve",
        atom_limit: int = 1_000_000,
    ) -> ModelEditResult:
        if hydrogen_policy == "reconcile_if_possible" and not isinstance(
            action, (ModelBondSet, ModelBondDelete)
        ):
            raise InvalidModelEdit("Reconciliation requires a direct bond action.")
        atoms = {a.id: a for a in before.atoms}
        chosen = set(selected)
        if (
            (
                not selected
                and not (
                    isinstance(action, ModelAtomAdd)
                    or (isinstance(action, ModelHydrogenComplete) and action.scope == "entry")
                )
            )
            or len(chosen) != len(selected)
            or not chosen <= atoms.keys()
        ):
            raise InvalidModelEdit("Select current, unique atoms in this entry.")
        if next_atom_id <= max(atoms, default=0) or next_bond_id <= max(
            (b.id for b in before.bonds),
            default=0,
        ):
            raise InvalidModelEdit("New identities must exceed retained entry identities.")
        pairs = {tuple(sorted((b.atom_1_id, b.atom_2_id))): b for b in before.bonds}
        if len(pairs) != len(before.bonds):
            raise InvalidModelEdit("Duplicate bond endpoints require an explicit repair.")
        exclusions = set(modeling_metadata(before).excluded_bonds)
        if exclusions & pairs.keys():
            raise InvalidModelEdit("Authored bonds contradict recorded bond exclusions.")
        if isinstance(action, ModelBondRotate):
            if len(before.atoms) > atom_limit:
                raise InvalidModelEdit(f"The result exceeds the entry limit of {atom_limit} atoms.")
            if len(selected) != 2 or action.moving_endpoint_id not in chosen:
                raise InvalidModelEdit(
                    "Select the two current bond endpoints and choose one endpoint's moving side."
                )
            bond = pairs.get(tuple(sorted(selected)))
            if bond is None:
                raise InvalidModelEdit("Bond rotation requires two endpoints of a current bond.")
            editor = RdkitLigandEditor()
            try:
                plan = editor.describe_bond_rotation(
                    before, bond_id=bond.id, moving_endpoint_id=action.moving_endpoint_id,
                    angle_degrees=action.angle_degrees,
                )
                diagnostic_targets = set(plan.axis_atom_ids) | set(plan.rotating_atom_ids)
                for _ in self._affected_bond_lengths(before, diagnostic_targets):
                    pass
                no_op = action.angle_degrees % 360 == 0
                if no_op:
                    result = EditResult(
                        before, warnings=editor.validator.validate(before, "bond.rotate")
                    )
                else:
                    result = editor.rotate_bond(
                        before, bond_id=bond.id,
                        movable_atom_ids=sorted([plan.moving_endpoint_id, *plan.rotating_atom_ids]),
                        angle_degrees=action.angle_degrees,
                    )
                    no_op = result.structure.conformers == before.conformers
                    if no_op:
                        result = EditResult(before, warnings=result.warnings)
            except InvalidLigandEditError as error:
                raise InvalidModelEdit(str(error)) from error
            geometry_warnings = self._bond_geometry_warnings(
                result.structure, diagnostic_targets, action.operation,
            )
            if geometry_warnings:
                with_geometry = {
                    (w.code, w.field, w.message): w
                    for w in [*result.structure.warnings, *geometry_warnings]
                }
                result = replace(
                    result,
                    structure=before if no_op else result.structure.model_copy(
                        update={"warnings": list(with_geometry.values())},
                    ),
                    warnings=(*result.warnings, *geometry_warnings),
                )
            # This is the existing coordinate-only method.  The endpoint names
            # a graph side; both axis endpoints stay fixed, and no H/stereo or
            # appearance authoring policy is applied to the coordinate change.
            return ModelEditResult(result, {}, rotation=plan, no_op=no_op)
        if isinstance(action, (ModelHydrogenComplete, ModelHydrogenAdd, ModelHydrogenAddOne)):
            if hydrogen_policy != "preserve":
                raise InvalidModelEdit(
                    "Explicit hydrogen actions require hydrogen_policy preserve."
                )
            if isinstance(action, (ModelHydrogenAdd, ModelHydrogenAddOne)) and (
                len(selected) != 1 or atoms[selected[0]].element == "H"
            ):
                raise InvalidModelEdit(
                    "Hydrogen addition requires exactly one selected heavy atom."
                )
            if isinstance(action, ModelHydrogenAddOne):
                try:
                    completed, report, completion_warnings = add_one_hydrogen(
                        before,
                        selected[0],
                        next_atom_id=next_atom_id,
                        next_bond_id=next_bond_id,
                        atom_limit=atom_limit,
                    )
                except (ValueError, RuntimeError, OverflowError) as error:
                    raise InvalidModelEdit(str(error)) from error
                return ModelEditResult(
                    EditResult(
                        structure=completed,
                        warnings=completion_warnings,
                        created_atom_ids=(next_atom_id,),
                        created_bond_ids=(next_bond_id,),
                        changed_atom_ids=tuple(
                            a.id for a in completed.atoms if a.id in atoms and a != atoms[a.id]
                        ),
                    ),
                    {},
                    report,
                    appearance_sources={next_atom_id: selected[0]},
                )
            try:
                builder = HydrogenBuilder(before)
                targets = builder.targets(
                    selected,
                    entry=isinstance(action, ModelHydrogenComplete) and action.scope == "entry",
                )
                proposal = builder.propose(
                    targets,
                    count=action.count if isinstance(action, ModelHydrogenAdd) else None,
                    geometry=action.geometry
                    if isinstance(action, ModelHydrogenAdd)
                    else "tetrahedral",
                    orientation=action.orientation if isinstance(action, ModelHydrogenAdd) else 0,
                    atom_limit=atom_limit,
                )
                completed, completion_warnings = apply_hydrogen_proposal(
                    before,
                    proposal,
                    next_atom_id=next_atom_id,
                    next_bond_id=next_bond_id,
                    operation=action.operation,
                )
            except ValueError as error:
                raise InvalidModelEdit(str(error)) from error
            old_atom_ids = set(atoms)
            old_bond_ids = {b.id for b in before.bonds}
            return ModelEditResult(
                EditResult(
                    structure=completed,
                    warnings=completion_warnings,
                    created_atom_ids=tuple(
                        a.id for a in completed.atoms if a.id not in old_atom_ids
                    ),
                    created_bond_ids=tuple(
                        b.id for b in completed.bonds if b.id not in old_bond_ids
                    ),
                    changed_atom_ids=tuple(
                        a.id for a in completed.atoms if a.id in old_atom_ids and a != atoms[a.id]
                    ),
                ),
                {},
                proposal.report,
                appearance_sources=_appearance_sources(before, completed, selected, action),
            )
        after = before
        touched = set(chosen)
        warnings: list[MolecularWarning] = []
        replacements: dict[int, int] = {}
        qualified_fragment_ids: frozenset[int] = frozenset()
        if isinstance(action, (ModelAtomAdd, ModelFragmentAdd)):
            for _ in self._affected_bond_lengths(before, chosen):
                pass
            try:
                placement = (
                    place_atom(
                        before,
                        selected,
                        element=action.element,
                        charge=action.charge,
                        direction=action.direction,
                        coordinates=action.coordinates,
                        next_atom_id=next_atom_id,
                        next_bond_id=next_bond_id,
                    )
                    if isinstance(action, ModelAtomAdd)
                    else place_fragment(
                        before,
                        selected,
                        fragment=action.fragment,
                        direction=action.direction,
                        rotation=action.rotation,
                        next_atom_id=next_atom_id,
                        next_bond_id=next_bond_id,
                    )
                )
            except ValueError as error:
                raise InvalidModelEdit(str(error)) from error
            after, replacements, touched = (
                placement.structure,
                placement.replacements,
                placement.touched,
            )
            warnings.extend(placement.warnings)
            if (
                isinstance(action, ModelFragmentAdd)
                and action.fragment in PRESERVED_TEMPLATE_FRAGMENTS
            ):
                try:
                    qualified_fragment_ids = qualified_template_atom_ids(
                        before, after, action.fragment, placement.template_evidence,
                    )
                except ValueError as error:
                    raise InvalidModelEdit(str(error)) from error
        elif isinstance(action, ModelDelete):
            if hydrogen_policy == "automatic":
                deletion_adjacency = _adjacency(before)
                cascade = {
                    i
                    for i, atom in atoms.items()
                    if atom.element in {"H", "D", "T"}
                    and len(deletion_adjacency[i]) == 1
                    and any(
                        j in chosen and atoms[j].element not in {"H", "D", "T"}
                        for j in deletion_adjacency[i]
                    )
                }
                ambiguous = {
                    i
                    for i, atom in atoms.items()
                    if atom.element in {"H", "D", "T"}
                    and i not in chosen | cascade
                    and deletion_adjacency[i] & chosen
                }
                if ambiguous:
                    warnings.append(
                        model_warning(
                            "model_hydrogen_deletion_ambiguous",
                            "Nonterminal H ownership is ambiguous; only explicitly selected or "
                            "terminal attached H were deleted.",
                            action.operation,
                        )
                    )
                chosen |= cascade
            retained = [i for i, a in enumerate(before.atoms) if a.id not in chosen]
            for bond in before.bonds:
                if chosen & {bond.atom_1_id, bond.atom_2_id}:
                    touched.update((bond.atom_1_id, bond.atom_2_id))
            after = before.model_copy(
                update={
                    "atoms": [before.atoms[i] for i in retained],
                    "bonds": [b for b in before.bonds if not chosen & {b.atom_1_id, b.atom_2_id}],
                    "conformers": [
                        c.model_copy(
                            update={
                                "coordinates": [c.coordinates[i] for i in retained],
                            }
                        )
                        for c in before.conformers
                    ],
                }
            )
            exclusions = {p for p in exclusions if not chosen & set(p)}
        elif isinstance(action, (ModelElement, ModelCharge)):
            if len(selected) != 1:
                raise InvalidModelEdit("Select exactly one atom for element or charge assignment.")
            target = atoms[selected[0]]
            change = (
                {"element": action.element}
                if isinstance(action, ModelElement)
                else {
                    "formal_charge": action.charge,
                }
            )
            if all(getattr(target, key) == value for key, value in change.items()):
                raise InvalidModelEdit("The atom already has the requested value.")
            after = before.model_copy(
                update={
                    "atoms": [
                        a.model_copy(
                            update={
                                **change,
                                "inferred_fields": [
                                    field
                                    for field in a.inferred_fields
                                    if field not in change and field != "chemistry"
                                ],
                            }
                        )
                        if a.id == target.id
                        else a
                        for a in before.atoms
                    ]
                }
            )
        else:
            if len(selected) != 2:
                raise InvalidModelEdit("Select exactly two distinct bond endpoints.")
            pair = tuple(sorted(selected))
            # The arity check gives a concrete tuple for the metadata contract.
            endpoints = (pair[0], pair[1])
            old = pairs.get(endpoints)
            if isinstance(action, ModelBondDelete):
                if old is None and endpoints in exclusions:
                    raise InvalidModelEdit("The selected bond is already removed.")
                exclusions.add(endpoints)
                after = before.model_copy(
                    update={
                        "bonds": [b for b in before.bonds if old is None or b.id != old.id],
                    }
                )
            else:
                aromatic = action.order == 1.5
                if old and old.order == action.order and old.aromatic == aromatic:
                    raise InvalidModelEdit("The bond already has the requested order.")
                exclusions.discard(endpoints)
                if old:
                    after = before.model_copy(
                        update={
                            "bonds": [
                                b.model_copy(
                                    update={
                                        "order": action.order,
                                        "aromatic": aromatic,
                                        "inferred": False,
                                        "stereo": None,
                                    }
                                )
                                if b.id == old.id
                                else b
                                for b in before.bonds
                            ]
                        }
                    )
                else:
                    after = before.model_copy(
                        update={
                            "bonds": [
                                *before.bonds,
                                Bond(
                                    id=next_bond_id,
                                    atom_1_id=endpoints[0],
                                    atom_2_id=endpoints[1],
                                    order=action.order,
                                    aromatic=aromatic,
                                    inferred=False,
                                ),
                            ]
                        }
                    )
        # Local stereo labels cannot certify a changed neighborhood. Keep geometry
        # and every unaffected annotation; never invent unspecified stereo.
        stereo_scope = set(touched)
        for bond in before.bonds:
            if touched & {bond.atom_1_id, bond.atom_2_id}:
                stereo_scope.update((bond.atom_1_id, bond.atom_2_id))
        # E/Z labels depend on substituent priorities beyond the immediate edit.
        # Preserve disconnected annotations; conservatively unassign dependent
        # bond labels without converting/sanitizing the complete parent.
        bond_stereo_scope: set[int] = set()
        if any(b.stereo not in {None, "NONE"} for b in [*before.bonds, *after.bonds]):
            adjacency: dict[int, set[int]] = {}
            for bond in [*before.bonds, *after.bonds]:
                adjacency.setdefault(bond.atom_1_id, set()).add(bond.atom_2_id)
                adjacency.setdefault(bond.atom_2_id, set()).add(bond.atom_1_id)
            stack = list(touched)
            while stack:
                node = stack.pop()
                if node in bond_stereo_scope:
                    continue
                bond_stereo_scope.add(node)
                stack.extend(adjacency.get(node, set()) - bond_stereo_scope)
        if any(a.stereo not in {None, "NONE"} and a.id in stereo_scope for a in after.atoms) or any(
            b.stereo not in {None, "NONE"} and bond_stereo_scope & {b.atom_1_id, b.atom_2_id}
            for b in [*before.bonds, *after.bonds]
        ):
            warnings.append(
                model_warning(
                    "model_stereo_unassigned",
                    "Stereo annotations affected by the edit or connected substituent priorities "
                    "were cleared; retained coordinates do not establish a new stereo assignment.",
                    action.operation,
                    "stereo",
                )
            )
        after = after.model_copy(
            update={
                "atoms": [
                    a.model_copy(
                        update={
                            "stereo": None,
                            "inferred_fields": [
                                field for field in a.inferred_fields if field != "stereo"
                            ],
                        }
                    )
                    if a.stereo not in {None, "NONE"} and a.id in stereo_scope
                    else a
                    for a in after.atoms
                ],
                "bonds": [
                    b.model_copy(update={"stereo": None})
                    if b.stereo not in {None, "NONE"}
                    and bond_stereo_scope & {b.atom_1_id, b.atom_2_id}
                    else b
                    for b in after.bonds
                ],
            }
        )
        metadata = dict(after.metadata)
        for key in ("canonical_smiles", "formula", "molecular_weight", "descriptors"):
            metadata.pop(key, None)
        retained_ids = {a.id for a in after.atoms}
        exclusions = {pair for pair in exclusions if set(pair) <= retained_ids}
        metadata[MODELING_METADATA] = ModelingMetadata(
            excluded_bonds=sorted(exclusions),
        ).model_dump(mode="json")
        after = after.model_copy(update={"metadata": metadata})
        if isinstance(action, ModelElement):
            after = after.model_copy(
                update={"annotations": authored_protection(before, after.atoms, set())}
            )
        # Refuse affected nonfinite input before optional chemistry or spatial
        # libraries can turn it into an unrelated error.  Final generated/moved
        # geometry is inspected again below with the operation's diagnostics.
        for _ in self._affected_bond_lengths(after, touched):
            pass
        hydrogen_report = None
        if hydrogen_policy == "complete_if_possible":
            if isinstance(action, ModelDelete) and any(atoms[i].element == "H" for i in chosen):
                warnings.append(
                    model_warning(
                        "model_hydrogen_completion_skipped",
                        "Explicit hydrogen deletion was preserved; "
                        "automatic completion was skipped.",
                        action.operation,
                    )
                )
            else:
                try:
                    builder = HydrogenBuilder(after)
                    operands = touched & builder.atoms.keys()
                    neighbors = {i for target in operands for i, _ in builder.adjacency[target]}
                    targets = sorted(
                        i for i in operands | neighbors if builder.atoms[i].element != "H"
                    )
                    proposal = builder.propose(targets, atom_limit=atom_limit)
                    hydrogen_report = proposal.report
                    after, hydrogen_warnings = apply_hydrogen_proposal(
                        after,
                        proposal,
                        next_atom_id=max(
                            next_atom_id, max((a.id for a in after.atoms), default=0) + 1
                        ),
                        next_bond_id=max(
                            next_bond_id, max((b.id for b in after.bonds), default=0) + 1
                        ),
                        operation=action.operation,
                    )
                    warnings.extend(hydrogen_warnings)
                    skipped = proposal.report.skipped_count + proposal.report.unprocessed_count
                    if skipped:
                        warnings.append(
                            model_warning(
                                "model_hydrogen_completion_skipped",
                                f"Direct edit saved; hydrogen completion {proposal.report.status}: "
                                f"{proposal.report.added_hydrogen_count} H added, "
                                f"{skipped} sites skipped. "
                                "Inspect the hydrogen report for reasons.",
                                action.operation,
                            )
                        )
                except (ValueError, RuntimeError, OverflowError) as error:
                    warnings.append(
                        model_warning(
                            "model_hydrogen_completion_skipped",
                            f"Direct edit saved; hydrogen completion unavailable: {error}",
                            action.operation,
                        )
                    )
        reconciliation_report = None
        if hydrogen_policy in {"reconcile_if_possible", "automatic"}:
            targets, suppressed = (
                _automatic_targets(before, after, selected, action)
                if hydrogen_policy == "automatic"
                else (selected, set())
            )
            outcome = reconcile_hydrogens(
                before,
                after,
                targets,
                next_atom_id=max(next_atom_id, max((a.id for a in after.atoms), default=0) + 1),
                next_bond_id=max(next_bond_id, max((b.id for b in after.bonds), default=0) + 1),
                operation=action.operation,
                atom_limit=atom_limit,
                inferred_deletion=isinstance(action, ModelBondDelete) and old is None,
                policy="automatic" if hydrogen_policy == "automatic" else "reconcile_if_possible",
                suppressed_targets=suppressed,
                qualified_fragment_atom_ids=qualified_fragment_ids,
            )
            after, reconciliation_report = outcome.structure, outcome.report
            warnings.extend(outcome.warnings)
            retained_ids = {a.id for a in after.atoms}
            metadata = dict(after.metadata)
            metadata[MODELING_METADATA] = ModelingMetadata(
                excluded_bonds=[pair for pair in exclusions if set(pair) <= retained_ids]
            ).model_dump(mode="json")
            after = after.model_copy(update={"metadata": metadata})
        if len(after.atoms) > atom_limit:
            raise InvalidModelEdit(f"The result exceeds the entry limit of {atom_limit} atoms.")
        if isinstance(action, (ModelAtomAdd, ModelFragmentAdd)):
            old_ids = {a.id for a in before.atoms}
            created_indices = [i for i, a in enumerate(after.atoms) if a.id not in old_ids]
            retained_indices = [i for i, a in enumerate(after.atoms) if a.id in old_ids]
            closest = float("inf")
            if created_indices and retained_indices:
                for conformer in after.conformers:
                    retained_points = np.asarray(
                        [conformer.coordinates[i] for i in retained_indices]
                    )
                    new_points = np.asarray([conformer.coordinates[i] for i in created_indices])
                    for checked_indices, points in (
                        (retained_indices, retained_points), (created_indices, new_points),
                    ):
                        finite = np.isfinite(points).all(axis=1)
                        if not finite.all():
                            invalid_index = checked_indices[int(np.flatnonzero(~finite)[0])]
                            raise InvalidModelEdit(
                                f"Conformer {conformer.id}, atom {after.atoms[invalid_index].id} "
                                "has nonfinite placement clash-check coordinates; "
                                "the molecular edit was not saved."
                            )
                    closest = min(
                        closest, float(np.min(cKDTree(retained_points).query(new_points)[0]))
                    )
            if closest < 0.6:
                warnings.append(
                    model_warning(
                        "model_placement_clash",
                        f"A generated atom is {closest:.3f} angstrom from retained "
                        "material in a conformer; "
                        "review this unoptimized placement. The requested draft was retained.",
                        action.operation,
                        "coordinates",
                    )
                )
        old_atoms = {a.id: a for a in before.atoms}
        new_atoms = {a.id: a for a in after.atoms}
        moved_hydrogens = (
            {i for site in reconciliation_report.sites for i in site.moved_hydrogen_ids}
            if reconciliation_report is not None
            else set()
        )
        diagnostic_targets = touched | moved_hydrogens | {
            i for i, atom in new_atoms.items() if i not in old_atoms or atom != old_atoms[i]
        }
        warnings.extend(self._local_warnings(after, diagnostic_targets, action.operation))
        # Retain previous scientific/source warnings, replacing exact duplicates.
        unique = {(w.code, w.field, w.message): w for w in [*after.warnings, *warnings]}
        after = after.model_copy(update={"warnings": list(unique.values())})
        old_bonds = {b.id for b in before.bonds}
        new_bonds = {b.id for b in after.bonds}
        return ModelEditResult(
            EditResult(
                structure=after,
                warnings=tuple(warnings),
                created_atom_ids=tuple(sorted(new_atoms.keys() - old_atoms.keys())),
                deleted_atom_ids=tuple(sorted(old_atoms.keys() - new_atoms.keys())),
                created_bond_ids=tuple(sorted(new_bonds - old_bonds)),
                deleted_bond_ids=tuple(sorted(old_bonds - new_bonds)),
                changed_atom_ids=tuple(
                    sorted(
                        i
                        for i in new_atoms.keys() & old_atoms.keys()
                        if new_atoms[i] != old_atoms[i] or i in touched or i in moved_hydrogens
                    )
                ),
            ),
            replacements,
            hydrogen_report,
            reconciliation_report,
            _appearance_sources(before, after, selected, action),
        )

    @staticmethod
    def _affected_bond_lengths(
        structure: NormalizedStructureV1,
        touched: set[int],
    ) -> Iterator[tuple[int, Bond, float]]:
        indices = {a.id: i for i, a in enumerate(structure.atoms)}
        affected = [b for b in structure.bonds if touched & {b.atom_1_id, b.atom_2_id}]
        checked_atoms = (touched & indices.keys()) | {
            i for b in affected for i in (b.atom_1_id, b.atom_2_id)
        }
        checked_atom_ids = sorted(checked_atoms)
        for atom_id in checked_atom_ids:
            if not all(isfinite(v) for v in structure.atoms[indices[atom_id]].coordinates):
                raise InvalidModelEdit(
                    f"Atom {atom_id} has nonfinite affected coordinates; "
                    "the molecular edit was not saved."
                )
        for conformer in structure.conformers:
            for atom_id in checked_atom_ids:
                if not all(isfinite(v) for v in conformer.coordinates[indices[atom_id]]):
                    raise InvalidModelEdit(
                        f"Conformer {conformer.id}, atom {atom_id} has nonfinite affected "
                        "coordinates; the molecular edit was not saved."
                    )
            for bond in affected:
                length = dist(
                    conformer.coordinates[indices[bond.atom_1_id]],
                    conformer.coordinates[indices[bond.atom_2_id]],
                )
                if not isfinite(length):
                    raise InvalidModelEdit(
                        f"Conformer {conformer.id}, bond {bond.id} "
                        f"(atoms {bond.atom_1_id}, {bond.atom_2_id}) has nonfinite "
                        "derived length; the molecular edit was not saved."
                    )
                yield conformer.id, bond, length

    @staticmethod
    def _bond_geometry_warnings(
        structure: NormalizedStructureV1,
        touched: set[int],
        operation: str,
    ) -> list[MolecularWarning]:
        warnings: list[MolecularWarning] = []
        total = measurements = 0
        affected_bonds: set[int] = set()
        for conformer_id, bond, length in DirectMolecularEditor._affected_bond_lengths(
            structure, touched
        ):
            measurements += 1
            if length < 0.4 or length > 3.0:
                total += 1
                affected_bonds.add(bond.id)
                if len(warnings) < _MAX_BOND_GEOMETRY_DETAILS:
                    warnings.append(
                        model_warning(
                            "model_bond_geometry",
                            f"Conformer {conformer_id}, bond {bond.id} "
                            f"(atoms {bond.atom_1_id}, {bond.atom_2_id}) is "
                            f"{length:.3f} angstrom; review the unoptimized geometry.",
                            operation,
                            f"bonds.{bond.id}",
                        )
                    )
        if total:
            shown = len(warnings)
            warnings.append(
                model_warning(
                    "model_bond_geometry_summary",
                    f"Checked {measurements} affected bond/"
                    f"conformer measurements across all {len(structure.conformers)} "
                    f"conformers: {total} outside the geometry thresholds on "
                    f"{len(affected_bonds)} bonds. Showing {shown} details; "
                    f"{total - shown} details omitted"
                    f"{' (detail limit reached)' if total > shown else ''}.",
                    operation,
                    "coordinates",
                )
            )
        return warnings

    @staticmethod
    def _local_warnings(
        structure: NormalizedStructureV1,
        touched: set[int],
        operation: str,
    ) -> list[MolecularWarning]:
        result = [
            model_warning(
                "model_chemistry_unvalidated",
                "Direct edit saved. Chemistry is incomplete or "
                "unvalidated; no protonation, optimized geometry or preparation is implied.",
                operation,
            ),
            model_warning(
                "model_source_labels",
                "Retained source labels and properties describe the original "
                "structure; modified chemistry requires review.",
                operation,
                "metadata",
            ),
        ]
        if structure.source.format == "generated":
            result = [w for w in result if w.code != "model_source_labels"]
        atoms = {a.id: a for a in structure.atoms}
        neighbors: dict[int, list[Bond]] = {i: [] for i in touched & atoms.keys()}
        for bond in structure.bonds:
            for i in (bond.atom_1_id, bond.atom_2_id):
                if i in neighbors:
                    neighbors[i].append(bond)
        result.extend(DirectMolecularEditor._bond_geometry_warnings(structure, touched, operation))
        if any(b.aromatic and touched & {b.atom_1_id, b.atom_2_id} for b in structure.bonds):
            result.append(
                model_warning(
                    "model_aromaticity_unvalidated",
                    "Aromatic labels near the edit were retained without validating rings; "
                    "the draft may contain unresolved aromaticity.",
                    operation,
                    "bonds",
                )
            )
        typical = {"H": 1, "C": 4, "N": 3, "O": 2, "F": 1, "Cl": 1, "Br": 1, "I": 1}
        for i, bonds in neighbors.items():
            atom = atoms[i]
            if atom.formal_charge is not None and abs(atom.formal_charge) > 8:
                result.append(
                    model_warning(
                        "model_unusual_charge",
                        f"Atom {i} has formal charge {atom.formal_charge}; chemistry and "
                        "chemical-format representability need review. "
                        "Canonical charge was retained.",
                        operation,
                        f"atoms.{i}.formal_charge",
                    )
                )
            if atom.formal_charge is None or any(b.order is None for b in bonds):
                result.append(
                    model_warning(
                        "model_chemistry_unknown",
                        f"Atom {i} has unknown charge or incident bond "
                        "order; these values were preserved.",
                        operation,
                        f"atoms.{i}",
                    )
                )
            if (
                atom.formal_charge == 0
                and not any(b.aromatic for b in bonds)
                and (
                    all(b.order is not None for b in bonds)
                    and sum(b.order or 0 for b in bonds) > typical.get(atom.element, 1000)
                )
            ):
                result.append(
                    model_warning(
                        "model_unusual_valence",
                        f"Atom {i} has bond valence above the typical "
                        f"neutral {atom.element} value; the requested draft was retained.",
                        operation,
                        f"atoms.{i}",
                    )
                )
        return result
