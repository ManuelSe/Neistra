// Optional Apply-only header: X-Neistra-Edit-Attempt: <UUID>.
// GET /api/v1/projects/{project_id}/edit-attempts/{attempt_id}; Cache-Control: no-store.
export type EditAttemptRead = {
  server_instance_id: string;
  attempt_id: string;
  project_id: string;
  entry_id: string | null;
  kind: "model" | "selection" | null;
  expected_revision: number | null;
  expected_artifact_id: string | null;
  phase: "pending" | "finishing" | "finished" | "unknown";
  outcome: "saved" | "not_applied" | "unknown" | null;
  committed_revision: number | null;
  committed_artifact_id: string | null;
  reason: string | null;
};
