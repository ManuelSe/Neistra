const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const root = process.cwd(), out = path.join(root, '.issue-11-evidence/issue161-profile-access-coverage-correction1');
const ts = require(path.join(root, 'apps/web/node_modules/typescript'));
const { expect } = require(path.join(root, 'node_modules/@playwright/test'));
const file = 'tests/e2e/ligand-profiles-access.spec.ts';
const old = fs.readFileSync(path.join(out, 'before.spec.ts.txt'), 'utf8'), current = fs.readFileSync(file, 'utf8');
const hash = body => crypto.createHash('sha256').update(body).digest('hex');
const first = '        expect(delivered.request.descriptor_ids).toEqual(', last = '        expect(await focusedInput!';
function parts(text) { const start = text.indexOf(first), end = text.indexOf(last, start); if (start < 0 || end < 0) throw Error('Oracle boundaries missing'); return [text.slice(0, start), text.slice(start, end), text.slice(end)]; }
const before = parts(old), after = parts(current);
expect(before[0]).toBe(after[0]); expect(before[2]).toBe(after[2]);
function oracle(block) { const compiled = ts.transpileModule(block, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText; return new Function('expect', 'delivered', 'ready', compiled).bind(null, expect); }
const originalOracle = oracle(before[1]), correctedOracle = oracle(after[1]);
const ids = ['molecular_weight', 'hbd', 'hba', 'calculated_logp'];
const actual = JSON.parse(fs.readFileSync(path.join(out, 'actual-superset-report.json')));
expect(actual.coverage.length).toBe(8); expect(actual.values.find(v => v.descriptor_id === 'molecular_weight').value).toBe(46.069);
const controls = [];
function run(name, change, accepted) {
  const report = structuredClone(actual), delivered = { request: { descriptor_ids: [...ids] } }, ready = { report };
  change(report, delivered, ready);
  let error = null; try { correctedOracle(delivered, ready); } catch (failure) { error = String(failure); }
  expect(!error, name).toBe(accepted); controls.push({ name, expected_acceptance: accepted, observed_acceptance: !error, rejection: error });
}
let red = null; try { originalOracle({ request: { descriptor_ids: [...ids] } }, { report: actual }); } catch (error) { red = String(error); }
expect(red).not.toBeNull(); fs.writeFileSync(path.join(out, 'original-oracle-red.log'), red + '\n');
run('Original actual cached8 satisfies requested4', () => {}, true);
run('Synthetic exact4 remains accepted', r => { r.coverage = [...ids]; r.values = r.values.filter(v => ids.includes(v.descriptor_id)); }, true);
run('Unrequested optional unavailable row does not invalidate requested ready rows', r => { const v = r.values.find(v => !ids.includes(v.descriptor_id)); v.status = 'unavailable'; v.value = null; v.reason = 'synthetic_optional_unavailable'; }, true);
run('Unrequested optional error row does not invalidate requested ready rows', r => { const v = r.values.find(v => !ids.includes(v.descriptor_id)); v.status = 'error'; v.value = null; v.reason = 'synthetic_optional_error'; }, true);
run('Request remains exact4', (_r, d) => d.request.descriptor_ids.pop(), false);
run('Missing requested coverage refused', r => r.coverage.splice(r.coverage.indexOf('hbd'), 1), false);
run('Missing requested row refused', r => { r.values = r.values.filter(v => v.descriptor_id !== 'hbd'); }, false);
run('Duplicate requested row refused', r => r.values.push({ ...r.values.find(v => v.descriptor_id === 'hbd') }), false);
run('Duplicate optional row refused', r => r.values.push({ ...r.values.find(v => !ids.includes(v.descriptor_id)) }), false);
for (const [name, value] of [['null', null], ['NaN', NaN], ['Infinity', Infinity], ['numeric string', '46.069']]) run(`Requested ${name} refused`, r => { r.values.find(v => v.descriptor_id === 'molecular_weight').value = value; }, false);
run('Requested unavailable refused', r => { const v = r.values.find(v => v.descriptor_id === 'hbd'); v.status = 'unavailable'; v.value = null; v.reason = 'synthetic_missing'; }, false);
run('Requested error refused', r => { r.values.find(v => v.descriptor_id === 'hbd').status = 'error'; }, false);
run('Requested stale reason refused', r => { r.values.find(v => v.descriptor_id === 'hbd').reason = 'synthetic_stale'; }, false);
run('Null report refused', (_r, _d, ready) => { ready.report = null; }, false);
const options = { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, moduleResolution: ts.ModuleResolutionKind.Bundler,
  lib: ['lib.es2022.d.ts', 'lib.dom.d.ts', 'lib.dom.iterable.d.ts'], strict: true, noEmit: true, skipLibCheck: true,
  esModuleInterop: true, allowSyntheticDefaultImports: true, jsx: ts.JsxEmit.ReactJSX, allowImportingTsExtensions: true,
  baseUrl: root, paths: { '/src/*': ['apps/web/src/*'] }, types: ['node'],
  typeRoots: [path.join(root, 'apps/web/node_modules/@types'), path.join(root, 'node_modules/@types')], resolveJsonModule: true };
function diagnostics(baseline) { const host = ts.createCompilerHost(options), read = host.readFile;
  if (baseline) host.readFile = f => path.resolve(f) === path.resolve(file) ? old : read.call(host, f);
  const program = ts.createProgram([path.resolve(file), path.join(root, 'apps/web/node_modules/vite/client.d.ts')], options, host);
  return ts.getPreEmitDiagnostics(program).map(d => ({ file: d.file ? path.relative(root, d.file.fileName) : null, code: d.code, message: ts.flattenDiagnosticMessageText(d.messageText, '\n') })); }
const candidateDiagnostics = diagnostics(false), baselineDiagnostics = diagnostics(true);
expect(candidateDiagnostics).toEqual([]); expect(baselineDiagnostics).toEqual([]);
expect(fs.readFileSync(file, 'utf8')).toBe(current);
const result = { recorded_utc: new Date().toISOString(), candidate_base: 'ae1a14fa6abfe2eccae4dfd3ac702acad7bf6a8d',
  source_before_sha256: hash(old), source_after_sha256: hash(current), source_frozen: true,
  exact_source_outside_oracle_block: true, original_actual_superset_coverage: 8, requested_coverage: 4,
  meaningful_original_oracle_refusal: red, controls, passed_controls: controls.length,
  candidateDiagnostics, baselineDiagnostics, native_or_scientific_execution: false, verdict: 'PASS' };
fs.writeFileSync(path.join(out, 'controls-and-types.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ verdict: result.verdict, passed_controls: controls.length, candidateDiagnostics, baselineDiagnostics, source_after_sha256: result.source_after_sha256 }));
