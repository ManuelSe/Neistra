import { ESLint } from '../../apps/web/node_modules/eslint/lib/api.js';
import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const root = process.cwd(), out = resolve(root, '.issue-11-evidence/issue161-profile-access-coverage-correction1');
const lint = new ESLint({ cwd: root, overrideConfigFile: resolve(root, 'apps/web/eslint.config.js'), overrideConfig: [{ files: ['**/*.{ts,tsx}'], languageOptions: { parserOptions: { project: [resolve(out, 'tsconfig.scope.json')], tsconfigRootDir: root } } }] });
const results = await lint.lintFiles(['tests/e2e/ligand-profiles-access.spec.ts']), formatter = await lint.loadFormatter('stylish');
await writeFile(resolve(out, 'lint-result.json'), JSON.stringify(results, null, 2) + '\n');
const text = formatter.format(results); await writeFile(resolve(out, 'lint-result.log'), text); process.stdout.write(text);
process.exitCode = results.some(r => r.errorCount || r.warningCount) ? 1 : 0;
