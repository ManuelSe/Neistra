"""Run the committed issue161 gate and retain positively closed raw owned stores."""
from pathlib import Path
import argparse,ast,copy,datetime,hashlib,json,os,runpy,shutil,socket,subprocess,time,zipfile
parser=argparse.ArgumentParser();parser.add_argument('--candidate',required=True);a=parser.parse_args()
root=Path.cwd().resolve();label='c4-candidate3';run=Path('/tmp/neistra161-c4-candidate3');ev=root/'.issue-11-evidence/issue161-c4-candidate3-run1';recipe=root/'docs/assets/ligand-information/c4-candidate3-recipe.json'
assert not ev.exists();assert not subprocess.check_output(['git','status','--porcelain=v1'],text=True);assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==a.candidate;assert run.is_dir() and not any(run.iterdir())
r=json.loads(recipe.read_bytes());assert len(r['steps'])==43 and r['label']==label
for key in ('NEISTRA_E2E_API_PORT','NEISTRA_E2E_WORKER_PORT','NEISTRA_E2E_WEB_PORT'):
 with socket.socket() as s:s.settimeout(.3);assert s.connect_ex(('127.0.0.1',int(r['environment'][key])))!=0
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
collector=root/'.issue-11-evidence/issue161-postgate-retention-preparation1/postgate-retention.py';assert sha(collector)=='cd40b342710e60934dfbef3f15cd5ab50edf85c59781b8c0ac603bafb9415bc5'
namespace=runpy.run_path(str(collector));function=next(n for n in ast.parse(collector.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='verify_closure');assert isinstance(function.body[0],ast.For) and isinstance(function.body[4],ast.For);assert isinstance(function.body[5],ast.Assign) and function.body[5].targets[0].id=='live'
# Reuse the exact assessed process/port scanner for raw retention after either exit.
# Successful-gate/receipt prerequisites remain enforced by the unmodified collector.
scanner=copy.deepcopy(function);scanner.name='inspect_closed_campaign';scanner.body=[*scanner.body[1:4],*scanner.body[5:]];tree=ast.fix_missing_locations(ast.Module(body=[scanner],type_ignores=[]));exec(compile(tree,str(collector),'exec'),namespace);scan=namespace['inspect_closed_campaign'];scanner_sha=hashlib.sha256(ast.dump(scanner,include_attributes=False).encode()).hexdigest()
ev.mkdir()
def write(name,value):(ev/name).write_text(json.dumps(value,indent=2)+'\n')
# Emit the original frozen source bodies before the gate, rather than derive them afterward.
helpers=runpy.run_path(str(root/'docs/assets/ligand-information/qualification.py.txt'))
source_before=helpers['current_identities'](root);assert len(source_before)==1222
write('source-before.json',source_before)
with zipfile.ZipFile(ev/'source-before.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,digest in source_before.items():
  data=(root/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest;z.writestr(name,data)
def capture_after_sources():
 try:
  captured=helpers['current_identities'](root)
  write('source-after.json',captured)
  return captured==source_before,None
 except Exception as error:
  return False,f'{type(error).__name__}: {error}'
def load_gate(path):
 try:
  captured=json.loads(path.read_bytes())
  if not isinstance(captured,dict) or not isinstance(captured.get('steps'),list):
   raise ValueError('Gate manifest must contain a steps array.')
  for step in captured['steps']:
   if not isinstance(step,dict):raise ValueError('Gate step must be an object.')
   if 'isolated_child_pid' in step and (type(step['isolated_child_pid']) is not int or step['isolated_child_pid']<=0):
    raise ValueError('Gate child PID must be a positive integer.')
  return captured,None
 except Exception as error:
  return {'steps':[]},f'{type(error).__name__}: {error}'
argv=[str(root/'.venv/bin/python'),'-B',str(root/'docs/assets/ligand-information/qualification.py.txt'),str(recipe)]
env={k:v for k,v in os.environ.items() if not k.startswith(('NEISTRA_','MOLWEAVE_')) and k not in {'DATABASE_URL','PYTHONPATH','VIRTUAL_ENV','UV_PROJECT_ENVIRONMENT'}};env['PATH']=str(root/'.venv/bin')+os.pathsep+'/usr/local/lib/node_modules/corepack/shims'+os.pathsep+env.get('PATH','');env['UV_PROJECT_ENVIRONMENT']=str(root/'.venv')
meta={'argv':argv,'cwd':str(root),'candidate':a.candidate,'started_utc':now(),'recipe_sha256':sha(recipe),'label':label,'run_root':str(run),'clean_start':True,'outer_unset_all_inherited_neistra_molweave_database_and_pythonpath':True,'launcher_sha256':sha(Path(__file__)),'closure_collector_sha256':sha(collector),'closure_scanner_AST_sha256':scanner_sha}
assert scanner_sha=='f543029483d1d74f4f7756a9eaf29ba39ab52c7ab9e0add0dc9909816b1b7a50'
prelaunch_proof=scan(run,ev,meta|{'runner_pid':0},{'steps':[]},{},{},r,[]);write('pre-launch-strict-process-proof.json',prelaunch_proof)
write('command.json',meta);snapshot={'recorded_utc':now(),'candidate':a.candidate,'scope':'Prelaunch external namespace snapshot; not a completed qualification','namespaces':{}}
for name in ('issue161-primary-performance','issue160-profile-performance','issue159-performance'):
 p=root/'.issue-11-evidence'/name;snapshot['namespaces'][name]=[{'name':q.name,'is_dir':q.is_dir(),'inode':q.stat().st_ino,'mtime_ns':q.stat().st_mtime_ns} for q in sorted(p.iterdir())] if p.exists() else []
snapshot['publication_requirement']='Retain complete actual candidate and merged performance companion trees and stores after positive closure/raw copies; publish bodies, not only inventories.';write('pre-launch-external-case-directories.json',snapshot)
with (ev/'stdout.log').open('wb') as out,(ev/'stderr.log').open('wb') as err:
 proc=subprocess.Popen(argv,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True);running=meta|{'runner_pid':proc.pid};write('running.json',running);print('RUNNING',proc.pid,str(ev),flush=True);code=proc.wait()
fixed,source_capture_error=capture_after_sources()
f=root/'docs/assets/ligand-information/c4-candidate3-gate.json';gate,gate_readback_error=load_gate(f)
gate_complete=gate_readback_error is None and gate.get('complete') is True and len(gate['steps'])==43 and all(step.get('exit_code')==0 and type(step.get('isolated_child_pid')) is int and step['isolated_child_pid']>0 and step.get('isolated_session_requested') is True for step in gate['steps'])
execution=running|{'finished_utc':now(),'exit_code':code,'source_unchanged':fixed,'source_capture_error':source_capture_error,'gate_readback_error':gate_readback_error,'gate_complete':gate_complete,'logs':{n:{'bytes':(ev/n).stat().st_size,'sha256':sha(ev/n)} for n in ('stdout.log','stderr.log')}};write('execution.json',execution)
sessions={proc.pid}|{s['isolated_child_pid'] for s in gate.get('steps',[]) if 'isolated_child_pid' in s};cases=[]
for name,before in snapshot['namespaces'].items():
 p=root/'.issue-11-evidence'/name
 if p.exists():cases.extend(q for q in p.iterdir() if q.name not in {x['name'] for x in before})
closure=None;failure=None
for attempt in range(40):
 try:closure=scan(run,ev,running,gate,{}, {},r,cases);break
 except namespace['Refusal'] as error:
  failure=str(error)
  if not failure.startswith(('Active campaign','Campaign port is open')):break
  time.sleep(.25)
receipt={'recorded_utc':now(),'runner_exit_code':code,'positive_closed':closure is not None,'live_owned_pids':[] if closure else None,'observed_step_session_ids':sorted(sessions),'ports_closed':{str(int(r['environment'][key])):bool(closure) for key in ('NEISTRA_E2E_API_PORT','NEISTRA_E2E_WORKER_PORT','NEISTRA_E2E_WEB_PORT')},'primary_diagnostic_sql_before_copy':False,'source_capture_error':source_capture_error,'gate_readback_error':gate_readback_error,'complete_gate_session_manifest_available':gate_complete,'strict_process_proof':closure,'closure_refusal':failure if closure is None else None,'files':[]};write('cleanup.json',receipt)
if closure:
 dest=ev/'closed-raw';dest.mkdir()
 for p in sorted(run.rglob('*')):
  if p.is_file() and p.name.endswith(('.db','.db-wal','.db-shm','.sqlite','.sqlite-wal','.sqlite-shm','.sqlite3','.sqlite3-wal','.sqlite3-shm')):
   assert not p.is_symlink();q=dest/p.relative_to(run);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert p.read_bytes()==q.read_bytes();receipt['files'].append({'original':str(p),'copy':str(q),'bytes':p.stat().st_size,'sha256':sha(p)})
 after=scan(run,ev,running,gate,{}, {},r,cases);assert after['unrelated_process_proof']==closure['unrelated_process_proof'];receipt['post_copy_strict_process_proof']=after;write('closed-raw-copy-receipt.json',receipt)
wrapper_exit=code if code else (0 if closure and fixed and gate_complete else 2)
print(json.dumps({'exit_code':code,'wrapper_exit_code':wrapper_exit,'source_unchanged':fixed,'source_capture_error':source_capture_error,'gate_readback_error':gate_readback_error,'gate_complete':gate_complete,'positive_closed':bool(closure),'raw_copies':len(receipt['files']),'evidence':str(ev),'closure_refusal':failure if not closure else None}),flush=True)
raise SystemExit(wrapper_exit)
