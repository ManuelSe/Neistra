"""Pure fault injection of wrapper metadata failure paths; no gate/services/SQL."""
from pathlib import Path
import ast, copy, hashlib, json, datetime
base=Path(__file__).resolve().parent
source=(base/'run-full-c4-candidate3.py').read_text()
tree=ast.parse(source)
functions=[copy.deepcopy(n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'capture_after_sources','load_gate'}]
assert len(functions)==2
assignments={n.targets[0].id:copy.deepcopy(n) for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in {'gate_complete','wrapper_exit'}}
assert set(assignments)=={'gate_complete','wrapper_exit'}
ns={'json':json,'root':Path('/not-a-real-workspace'),'source_before':{'source':'original'},'helpers':{},'write':lambda *_:None}
exec(compile(ast.fix_missing_locations(ast.Module(body=functions,type_ignores=[])),str(base/'run-full-c4-candidate3.py'),'exec'),ns)
records=[]
def checked(name,condition,**evidence):
 assert condition,name
 records.append({'name':name,**evidence})
def broken(error):
 def fail(*_):raise error
 return fail
for name,value,error in [('equal',{'source':'original'},None),('changed',{'source':'changed'},None),('missing',None,FileNotFoundError('required helper absent')),('symlink',None,ValueError('source symlink refused')),('unreadable',None,PermissionError('source unreadable')),('git',None,RuntimeError('Git failed'))]:
 ns['helpers']={'current_identities':broken(error) if error else lambda _,value=value:value}
 ns['write']=lambda *_:None
 fixed,failure=ns['capture_after_sources']()
 continued_to_retention=True
 checked('source-'+name,continued_to_retention and fixed==(name=='equal') and (failure is not None)==(error is not None),fixed=fixed,error=failure,retention_continues=continued_to_retention)
ns['helpers']={'current_identities':lambda _:dict(ns['source_before'])};ns['write']=broken(OSError('source-after receipt unavailable'))
fixed,failure=ns['capture_after_sources']();checked('source-write-error',not fixed and failure.startswith('OSError:'),error=failure,retention_continues=True)
class FakePath:
 def __init__(self,payload=None,error=None):self.payload=payload;self.error=error
 def exists(self):return True
 def read_bytes(self):
  if self.error:raise self.error
  return self.payload
valid={'complete':True,'steps':[{'label':str(i),'exit_code':0,'isolated_child_pid':1000+i,'isolated_session_requested':True} for i in range(43)]}
cases=[('valid',FakePath(json.dumps(valid).encode()),True,False),('malformed',FakePath(b'{'),False,True),('missing',FakePath(error=FileNotFoundError('gate missing')),False,True),('wrong-shape',FakePath(b'{"steps":{}}'),False,True),('partial',FakePath(json.dumps({'complete':False,'steps':valid['steps'][:15]}).encode()),False,False)]
for name,change in [('bad-pid',{'isolated_child_pid':'1000'}),('bool-pid',{'isolated_child_pid':True}),('missing-pid',{'isolated_child_pid':None}),('missing-session',{'isolated_session_requested':None})]:
 value=copy.deepcopy(valid)
 for key,item in change.items():
  if item is None:value['steps'][0].pop(key)
  else:value['steps'][0][key]=item
 cases.append((name,FakePath(json.dumps(value).encode()),False,name in {'bad-pid','bool-pid'}))
for name,path,expected_complete,expected_error in cases:
 gate,error=ns['load_gate'](path);ns.update(gate=gate,gate_readback_error=error)
 exec(compile(ast.fix_missing_locations(ast.Module(body=[assignments['gate_complete']],type_ignores=[])),str(base/'run-full-c4-candidate3.py'),'exec'),ns)
 checked('gate-'+name,ns['gate_complete']==expected_complete and (error is not None)==expected_error,complete=ns['gate_complete'],error=error,known_session_claims=len(gate['steps']),retention_continues=True)
for name,code,closed,fixed,complete,expected in [('success',0,True,True,True,0),('source-failure',0,True,False,True,2),('manifest-failure',0,True,True,False,2),('closure-refusal',0,False,True,True,2),('inner-failure',1,True,True,True,1)]:
 ns.update(code=code,closure=closed,fixed=fixed,gate_complete=complete)
 exec(compile(ast.fix_missing_locations(ast.Module(body=[assignments['wrapper_exit']],type_ignores=[])),str(base/'run-full-c4-candidate3.py'),'exec'),ns)
 checked('exit-'+name,ns['wrapper_exit']==expected,wrapper_exit=ns['wrapper_exit'])
old=ast.parse((base.parent/'issue161-c4-candidate3-preparation1/run-full-c4-candidate3.py').read_text())
for target,fake in [('after_sources',{'helpers':{'current_identities':broken(FileNotFoundError('required helper absent'))},'root':Path('/not-a-real-workspace')}),('gate',{'json':json,'f':FakePath(b'{')})]:
 statement=next(n for n in old.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id==target)
 retained=False;failure=None
 try:
  exec(compile(ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(statement)],type_ignores=[])),'old-wrapper','exec'),fake)
  retained=True
 except Exception as error:failure=type(error).__name__
 checked('old-negative-control-'+target,not retained and failure is not None,retention_reached=retained,error=failure)
result={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Pure extracted production helper/control expressions with fake source/gate inputs; no application, native gate, process scanner, database or filesystem source mutation executed','wrapper_sha256':hashlib.sha256(source.encode()).hexdigest(),'verdict':'PASS','checks':records,'counts':len(records),'negative_controls':2}
out=base/'failure-retention-check1';out.mkdir(exist_ok=False);(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
