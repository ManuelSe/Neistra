"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createObserverSnapshotReader = createObserverSnapshotReader;
// A missing first publication is a startup state. Once publication has begun,
// every read must provide current, valid evidence; failures are never cached.
function createObserverSnapshotReader(readText) {
    let published = false;
    return async () => {
        let text;
        try {
            text = await readText();
        }
        catch (error) {
            if (!published && typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT")
                return null;
            throw error;
        }
        const value = JSON.parse(text);
        if (typeof value !== "object" || value === null || Array.isArray(value)
            || !("complete" in value) || typeof value.complete !== "boolean"
            || !("samples" in value) || !Number.isSafeInteger(value.samples) || value.samples < 0
            || !("jobs" in value) || typeof value.jobs !== "object" || value.jobs === null || Array.isArray(value.jobs)) {
            throw new Error("Invalid descriptor observer snapshot envelope");
        }
        published = true;
        return value;
    };
}
