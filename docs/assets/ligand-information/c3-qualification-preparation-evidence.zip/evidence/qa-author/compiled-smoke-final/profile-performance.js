"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.digest = exports.fixtureSizes = exports.COMPOSITE_DESCRIPTORS = exports.PROFILE_DESCRIPTORS = void 0;
exports.check = check;
exports.distribution = distribution;
exports.source = source;
exports.sameSource = sameSource;
exports.cacheBasis = cacheBasis;
exports.coldRequirement = coldRequirement;
exports.classifyFirstSelection = classifyFirstSelection;
exports.constraints = constraints;
exports.expectedCriteria = expectedCriteria;
exports.assertReport = assertReport;
exports.installObservation = installObservation;
exports.arm = arm;
exports.evidence = evidence;
exports.durations = durations;
exports.requestCounts = requestCounts;
exports.observedReady = observedReady;
exports.matchingReady = matchingReady;
exports.fixture = fixture;
exports.store = store;
exports.preflight = preflight;
exports.publishedContext = publishedContext;
exports.consumerState = consumerState;
exports.observer = observer;
exports.sourceIdentities = sourceIdentities;
exports.sourceMap = sourceMap;
const node_child_process_1 = require("node:child_process");
const node_crypto_1 = require("node:crypto");
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
const observer_snapshot_1 = require("./observer-snapshot");
exports.PROFILE_DESCRIPTORS = ["molecular_weight", "hbd", "hba", "calculated_logp"];
exports.COMPOSITE_DESCRIPTORS = [...exports.PROFILE_DESCRIPTORS.slice(0, 3), "tpsa", "calculated_logp", "rotatable_bond_count"];
exports.fixtureSizes = [10, 26, 46, 66, 86];
const digest = (body) => (0, node_crypto_1.createHash)("sha256").update(body).digest("hex");
exports.digest = digest;
function check(condition, message) {
    if (!condition)
        throw new Error(message);
}
function distribution(samples, target) {
    check(samples.length > 0 && samples.every(n => Number.isFinite(n) && n >= 0), "Every timing sample must be observed, finite and nonnegative");
    const ordered = [...samples].sort((a, b) => a - b), middle = Math.floor(ordered.length / 2);
    return { n: ordered.length, median: ordered.length % 2 ? ordered[middle] : (ordered[middle - 1] + ordered[middle]) / 2,
        p95_nearest_rank: ordered[Math.ceil(ordered.length * .95) - 1], max: ordered.at(-1), target,
        misses: ordered.filter(n => n > target).length };
}
function source(entry) {
    const d = entry.ligand_designation;
    check(d.status === "resolved" && d.instance_id && entry.current_artifact_id, "An exact resolved current ligand is required");
    return { entry_id: entry.id, source_artifact_id: entry.current_artifact_id, instance_id: d.instance_id, atom_ids: [...d.atom_ids] };
}
function sameSource(a, b) {
    return a.entry_id === b.entry_id && a.source_artifact_id === b.source_artifact_id && a.instance_id === b.instance_id
        && a.atom_ids.length === b.atom_ids.length && a.atom_ids.every((id, i) => id === b.atom_ids[i]);
}
function cacheBasis(body, wanted, ids) {
    check(body.entries.length === 1 && sameSource(body.entries[0].source, wanted), "Read-only cache baseline must match the complete exact source");
    const row = body.entries[0];
    const ready = ids.filter(id => row.report?.values.some(v => v.descriptor_id === id && v.status === "ready" && typeof v.value === "number" && Number.isFinite(v.value)));
    return { status: row.status, binding_key: row.binding_key, input_hash: row.report?.input_hash ?? null,
        ready_descriptor_ids: ready, missing_descriptor_ids: ids.filter(id => !ready.includes(id)),
        numerical_cache: ready.length === ids.length && row.status === "ready" ? "matching-ready"
            : ready.length === 0 ? "missing-required-coverage" : "partial-required-coverage" };
}
function coldRequirement(raw) {
    check(raw === undefined || raw === "0" || raw === "1", "NEISTRA_PROFILE_REQUIRE_COLD must be 0 or 1");
    return raw === "1";
}
function classifyFirstSelection(basis, requireCold) {
    const classification = basis.numerical_cache === "matching-ready" ? "shared-cache-ready"
        : basis.ready_descriptor_ids.length === 0 && basis.missing_descriptor_ids.length > 0 ? "numerical-cold-missing"
            : "shared-cache-partial";
    check(!requireCold || classification === "numerical-cold-missing", "Focused cold qualification requires genuinely missing numerical coverage; fresh context is insufficient");
    return classification;
}
function constraints(registry, id) {
    const found = new Map(), visited = new Set();
    const visit = (key) => {
        check(!visited.has(key), "Profile component cycle or duplicate traversal");
        visited.add(key);
        const p = registry.profiles.find(p => p.id === key);
        check(p, "Missing profile definition");
        for (const cid of p.constraint_ids) {
            const c = registry.constraints.find(c => c.id === cid);
            check(c, "Missing constraint");
            found.set(cid, c);
        }
        for (const child of p.component_ids)
            visit(child);
    };
    visit(id);
    return [...found.values()];
}
function expectedCriteria(registry, profileId, report) {
    check(report.model_status === "qualified", "Performance specimen requires independently qualified chemistry");
    check(Object.entries(registry.descriptor_method).every(([key, value]) => report[key] === value), "Descriptor method mismatch");
    const operators = { lt: "<", le: "≤", gt: ">", ge: "≥" };
    return constraints(registry, profileId).map(c => {
        const definition = registry.descriptors.find(d => d.id === c.descriptor_id);
        const value = report.values.find(v => v.descriptor_id === c.descriptor_id);
        check(definition && value?.status === "ready" && typeof value.value === "number" && Number.isFinite(value.value), "A missing or failed value cannot become a criterion number");
        const n = value.value, met = c.operator === "lt" ? n < c.limit : c.operator === "le" ? n <= c.limit : c.operator === "gt" ? n > c.limit : n >= c.limit;
        const unit = definition.unit ? ` ${definition.unit}` : "";
        return { name: definition.name, value: `Value: ${n}${unit}`, criterion: `Criterion: ${operators[c.operator]} ${c.limit}${unit}`, outcome: met ? "Met" : "Not met" };
    });
}
function assertReport(actual, independent, ids, context = independent) {
    check(actual.model_status === "qualified" && independent.model_status === "qualified" && context.model_status === "qualified"
        && /^[a-f0-9]{64}$/.test(actual.input_hash) && /^[a-f0-9]{64}$/.test(independent.input_hash), "Current and independent reports must be qualified");
    check(actual.input_hash === context.input_hash, "Current input hash differs from independently qualified source context");
    check(JSON.stringify(actual.provenance) === JSON.stringify(context.provenance), "Current qualification provenance differs from source context");
    check(actual.contains_formally_charged_atoms === context.contains_formally_charged_atoms
        && actual.contains_formally_charged_atoms === independent.contains_formally_charged_atoms, "Current charge-presence fact differs from independent preflight");
    for (const key of ["implementation_version", "library_version", "policy_version"]) {
        check(actual[key] === independent[key] && actual[key] === context[key], `Changed ${key}`);
    }
    const integerIds = new Set(["heavy_atom_count", "heteroatom_count", "carbon_count", "formal_charge", "hbd", "hba",
        "rotatable_bond_count", "ring_count", "aromatic_ring_count"]);
    for (const id of ids) {
        const a = actual.values.find(v => v.descriptor_id === id), b = independent.values.find(v => v.descriptor_id === id);
        check(a?.status === "ready" && b?.status === "ready" && typeof a.value === "number" && typeof b.value === "number"
            && Number.isFinite(a.value) && Number.isFinite(b.value)
            && (integerIds.has(id) ? Number.isInteger(a.value) && Number.isInteger(b.value) && a.value === b.value
                : Math.abs(a.value - b.value) <= 1e-10), `Current value differs from independent preflight: ${id}`);
    }
}
/** Observation has overhead; it does not modify application state or add network reads. */
async function installObservation(page) {
    await page.addInitScript(() => {
        const clock = () => {
            const dateBeforeMs = Date.now(), performanceNowMs = performance.now(), dateAfterMs = Date.now();
            return { timeOrigin: performance.timeOrigin, dateBeforeMs, performanceNowMs, dateAfterMs };
        };
        const visibleElement = (node) => {
            const bounds = node?.getBoundingClientRect();
            return !!node && !!bounds && bounds.width > 0 && bounds.height > 0 && bounds.top < innerHeight && bounds.bottom > 0
                && bounds.left < innerWidth && bounds.right > 0 && getComputedStyle(node).visibility !== "hidden"
                && !node.closest('[aria-hidden="true"], [inert]');
        };
        const snapshot = () => {
            const root = document.querySelector(".ligand-profile"), criteria = root?.querySelector(".ligand-profile-criteria"), status = root?.querySelector('[role="status"]');
            return { profileId: root?.querySelector("select")?.value ?? null, status: root?.querySelector('[role="status"]')?.textContent ?? null,
                visible: visibleElement(criteria), statusVisible: visibleElement(status), profileControlVisible: visibleElement(root?.querySelector("select")),
                rows: [...(root?.querySelectorAll(".ligand-profile-criteria > div") ?? [])].map(row => {
                    const spans = row.querySelectorAll("dd > span");
                    return { name: row.querySelector("dt")?.textContent ?? "", value: spans[0]?.textContent ?? "", criterion: spans[1]?.textContent ?? "", outcome: spans[2]?.textContent ?? "" };
                }) };
        };
        const state = { clock: clock(), requests: [], samples: [], snapshots: [], readSnapshot: snapshot };
        const equal = (a, b) => a.length === b.length && a.every((x, i) => JSON.stringify(x) === JSON.stringify(b[i]));
        const observe = () => {
            const now = performance.now(), current = snapshot();
            if (JSON.stringify(state.snapshots.at(-1)?.snapshot) !== JSON.stringify(current))
                state.snapshots.push({ at: now, snapshot: current });
            const s = state.sample;
            if (!s || s.startedAt === undefined || s.eventTrusted !== true)
                return;
            if (s.feedbackAt === undefined) {
                if (current.statusVisible && /Updating|Loading|unavailable|cancelled/i.test(current.status ?? "")) {
                    s.feedbackAt = now;
                    s.feedbackBasis = "visible-status";
                }
                else if (s.event === "change" && current.profileId === s.targetProfile && current.profileControlVisible) {
                    s.feedbackAt = now;
                    s.feedbackBasis = "native-selected-value";
                }
                else if (state.control?.matches(":disabled") && visibleElement(state.control)) {
                    s.feedbackAt = now;
                    s.feedbackBasis = "disabled-command";
                }
            }
            if (s.initial?.visible && s.oldRows.length && s.retiredAt === undefined && !equal(current.rows, s.oldRows))
                s.retiredAt = now;
            if (current.profileId === s.targetProfile && equal(current.rows, s.expectedRows)
                && (s.completionStatus ? current.status?.includes(s.completionStatus)
                    : /Within profile criteria\.|Outside profile criteria\.|No profile selected\./.test(current.status ?? ""))) {
                if (s.currentAt === undefined) {
                    s.currentAt = now;
                    s.currentVisible = current.visible;
                }
                if (current.visible && s.visibleCurrentAt === undefined)
                    s.visibleCurrentAt = now;
            }
        };
        state.observer = new MutationObserver(observe);
        state.observer.observe(document, { subtree: true, childList: true, characterData: true, attributes: true });
        window.profilePerformance = state;
        const original = window.fetch.bind(window);
        window.fetch = async (...args) => {
            const [input, init] = args, url = new URL(typeof input === "string" ? input : input instanceof URL ? input.href : input.url, location.href);
            const selected = url.pathname.includes("/ligand-properties") || url.pathname === "/api/v1/ligand-profiles/registry"
                || /\/(model-edits|history\/undo|history\/redo)$/.test(url.pathname);
            const method = init?.method ?? (input instanceof Request ? input.method : "GET");
            let body = null;
            if (typeof init?.body === "string") {
                try {
                    body = JSON.parse(init.body);
                }
                catch {
                    body = "non-JSON";
                }
            }
            const record = { at: performance.now(), timeOrigin: state.clock.timeOrigin, method, path: url.pathname, body, snapshot: snapshot() };
            if (selected)
                state.requests.push(record);
            try {
                const response = await original(...args);
                record.responseAt = performance.now();
                record.status = response.status;
                if (selected && /\/ligand-properties\/(read|consumers\/[^/]+)$/.test(url.pathname) && ["POST", "PUT"].includes(method)) {
                    void response.clone().json().then((body) => { record.response = body; record.observedAt = performance.now(); }, error => { record.error = String(error); });
                }
                return response;
            }
            catch (error) {
                record.error = String(error);
                throw error;
            }
        };
        document.addEventListener("change", observe, true);
    });
}
async function arm(page, control, label, targetProfile, expectedRows, event = "change", completionStatus) {
    await control.evaluate((node, arg) => {
        const state = window.profilePerformance;
        state.control = node;
        const sample = { ...arg, armedAt: performance.now(), oldRows: state.readSnapshot().rows };
        state.sample = sample;
        state.samples.push(sample);
        node.addEventListener(arg.event, e => {
            sample.startedAt = performance.now();
            sample.eventTrusted = e.isTrusted;
            sample.initial = state.readSnapshot();
            if (!sample.initial.visible)
                sample.retirementUnavailable = "Profile criteria hidden at trigger; no visible retirement latency";
            else if (!sample.oldRows.length)
                sample.retirementUnavailable = "No old criteria at trigger";
            const bounds = node.getBoundingClientRect();
            if (arg.event === "change" && e.isTrusted && node instanceof HTMLSelectElement && node.value === arg.targetProfile
                && bounds.width > 0 && bounds.height > 0 && bounds.top < innerHeight && bounds.bottom > 0
                && bounds.left < innerWidth && bounds.right > 0 && getComputedStyle(node).visibility !== "hidden"
                && !node.closest('[aria-hidden="true"], [inert]')) {
                sample.feedbackAt = performance.now();
                sample.feedbackBasis = "native-selected-value";
            }
        }, { capture: true, once: true });
    }, { label, targetProfile, expectedRows, event, completionStatus });
}
async function evidence(page) {
    return page.evaluate(() => {
        const state = window.profilePerformance, dateBeforeMs = Date.now(), performanceNowMs = performance.now(), dateAfterMs = Date.now();
        return { clock: state.clock, observedClock: { timeOrigin: performance.timeOrigin, dateBeforeMs, performanceNowMs, dateAfterMs },
            requests: state.requests, samples: state.samples, snapshots: state.snapshots };
    });
}
function durations(sample, ackAt) {
    check(sample.startedAt !== undefined && sample.eventTrusted === true, "A trusted browser trigger is mandatory");
    const elapsed = (at) => {
        if (at === undefined)
            return null;
        check(Number.isFinite(at) && at >= sample.startedAt, "Observation precedes browser trigger");
        return at - sample.startedAt;
    };
    return { feedback_ms: elapsed(sample.feedbackAt), feedback_basis: sample.feedbackBasis ?? null, current_criteria_ms: elapsed(sample.currentAt),
        visible_current_criteria_ms: elapsed(sample.visibleCurrentAt), retirement_ms: elapsed(sample.retiredAt),
        retirement_relative_to_ack_ms: sample.retiredAt !== undefined && ackAt !== undefined ? sample.retiredAt - ackAt : null,
        retirement_unavailable_reason: sample.retiredAt === undefined
            ? sample.retirementUnavailable ?? "No changed old criteria observation" : null,
        feedback_unavailable_reason: sample.feedbackAt === undefined ? "No feedback DOM observation" : null,
        current_criteria_unavailable_reason: sample.currentAt === undefined ? "No matching completed criteria DOM observation" : null,
        visible_current_unavailable_reason: sample.visibleCurrentAt === undefined ? "Current criteria not observed in visible viewport" : null };
}
function requestCounts(requests) {
    return { requests: requests.length,
        metadata: requests.filter(r => r.path === "/api/v1/ligand-profiles/registry").length,
        allocations: requests.filter(r => r.method === "POST" && /\/ligand-properties\/consumers$/.test(r.path)).length,
        demands: requests.filter(r => r.method === "PUT" && /\/ligand-properties\/consumers\/[^/]+$/.test(r.path)).length,
        reads: requests.filter(r => r.method === "POST" && /\/ligand-properties\/read$/.test(r.path)).length,
        releases: requests.filter(r => r.method === "DELETE" && /\/ligand-properties\/consumers\/[^/]+$/.test(r.path)).length };
}
/** Timing observation only; independent scientific qualification is still mandatory. */
function observedReady(requests, wanted) {
    for (const request of requests) {
        if (request.status !== 200 || request.observedAt === undefined || request.responseAt === undefined)
            continue;
        const current = request.response?.entries?.find(row => sameSource(row.source, wanted) && row.status === "ready" && row.report);
        if (!current?.report)
            continue;
        return { timeOrigin: request.timeOrigin, request_at: request.at, response_at: request.responseAt, observed_at: request.observedAt,
            source: current.source, binding_key: current.binding_key, input_hash: current.report.input_hash, report: current.report,
            consumer_id: request.response?.consumer_id ?? null, sequence: request.response?.sequence ?? null };
    }
    return null;
}
function matchingReady(requests, wanted, independent, ids, context = independent) {
    const observed = observedReady(requests, wanted);
    if (observed)
        assertReport(observed.report, independent, ids, context);
    return observed;
}
async function fixture(profile, size) {
    const dir = (0, node_path_1.resolve)("tests/fixtures/ligand-properties-performance/editable"), bytes = await (0, promises_1.readFile)((0, node_path_1.resolve)(dir, "manifest.json"));
    const manifest = JSON.parse(bytes.toString());
    const id = `paired-${profile}-${size}`, rows = manifest.fixtures.filter(row => row.id === id);
    check(rows.length === 1, "One frozen specimen required");
    const row = rows[0];
    check(row.filename === `${id}.sdf`, "Unsafe fixture filename");
    const data = await (0, promises_1.readFile)((0, node_path_1.resolve)(dir, row.filename));
    check(data.length === row.bytes && (0, exports.digest)(data) === row.sha256, "Frozen original changed");
    return { ...row, data, manifest_sha256: (0, exports.digest)(bytes) };
}
function store() {
    const legacy = process.env.NEISTRA_E2E_DATA_DIR === undefined && process.env.MOLWEAVE_E2E_DATA_DIR !== undefined;
    const data = (0, node_path_1.resolve)(process.env.NEISTRA_E2E_DATA_DIR ?? process.env.MOLWEAVE_E2E_DATA_DIR ?? ".neistra-e2e");
    return { data, database: (0, node_path_1.resolve)(data, legacy ? "molweave.db" : "neistra.db") };
}
async function runSetupActor(args, directory, label) {
    const started = performance.now(), interpreter = (0, node_path_1.resolve)(".venv/bin/python");
    const child = (0, node_child_process_1.spawn)(interpreter, args, { env: process.env, stdio: ["ignore", "pipe", "pipe"], timeout: 30_000 });
    let stdout = "", stderr = "";
    child.stdout.on("data", x => { stdout += String(x); });
    child.stderr.on("data", x => { stderr += String(x); });
    const completion = await new Promise((done, fail) => { child.once("error", fail); child.once("close", (code, signal) => done({ code, signal })); });
    await (0, promises_1.writeFile)((0, node_path_1.resolve)(directory, "stdout.log"), stdout);
    await (0, promises_1.writeFile)((0, node_path_1.resolve)(directory, "stderr.log"), stderr);
    await (0, promises_1.writeFile)((0, node_path_1.resolve)(directory, "execution.json"), JSON.stringify({ argv: [interpreter, ...args], ...completion, setup_ms_excluded: performance.now() - started }, null, 2));
    check(completion.code === 0 && completion.signal === null, `${label} failed: ${stderr}`);
}
async function preflight(project, row, directory) {
    const out = (0, node_path_1.resolve)(directory, `preflight-${row.id}`);
    await (0, promises_1.mkdir)(out);
    const entry = project.entries[0], requirements = (0, node_path_1.resolve)(out, "requirements.json");
    await (0, promises_1.writeFile)(requirements, JSON.stringify({ project_id: project.id, source: source(entry), original_artifact_id: entry.original_artifact_id,
        smiles: row.intended_smiles, fixture_id: row.id }, null, 2));
    const owned = store(), args = ["-m", "tests.support.ligand_profiles_performance_preflight", "preflight", "--database", owned.database,
        "--data-dir", owned.data, "--requirements", requirements, "--output-dir", (0, node_path_1.resolve)(out, "qualification")];
    await runSetupActor(args, out, "Independent paired preflight");
    const resultBytes = await (0, promises_1.readFile)((0, node_path_1.resolve)(out, "qualification/result.json"));
    const paired = JSON.parse(resultBytes.toString());
    const result = paired.independent_no_original, context = paired.source_context;
    check(paired.schema === "profile-performance-paired-preflight-v1", "Paired independent/source-context preflight required");
    check(sameSource(result.source, source(entry)) && result.original_sha256 === row.sha256 && /^[a-f0-9]{64}$/.test(result.source_sha256)
        && result.original_recovery_disabled && result.no_shared_cache_or_API_descriptor_work, "Preflight source/setup authority mismatch");
    for (const report of [result.before_report, result.after_report])
        check(report.model_status === "qualified" && report.values.length === 14
            && report.values.every(v => v.status === "ready" && typeof v.value === "number" && Number.isFinite(v.value)), "Preflight must independently qualify both complete vectors");
    check(sameSource(context.source, result.source) && context.original_sha256 === result.original_sha256 && context.source_sha256 === result.source_sha256
        && context.independent_no_original_vectors_reproduced && context.context_vectors_match_independent_numerical_oracle
        && context.no_shared_cache_or_API_descriptor_work, "Source-context proof differs from retained independent source");
    for (const phase of ["before_report", "after_report"]) {
        const contextual = phase === "before_report" ? context.before_report : context.disposable_after_report;
        assertReport(contextual, result[phase], result[phase].coverage, contextual);
    }
    check((0, exports.digest)(await (0, promises_1.readFile)((0, node_path_1.resolve)(out, "qualification/independent-result.json"))) === paired.independent_result_sha256
        && (0, exports.digest)(await (0, promises_1.readFile)((0, node_path_1.resolve)(out, "qualification/source-context.json"))) === paired.source_context_sha256, "Paired preflight artifact hashes changed");
    return { directory: out, result, context, result_sha256: (0, exports.digest)(resultBytes) };
}
async function publishedContext(project, entry, qualified, phase, directory, label, expectedCanonicalSha256) {
    const out = (0, node_path_1.resolve)(directory, `published-${label}`);
    await (0, promises_1.mkdir)(out);
    const requirements = (0, node_path_1.resolve)(out, "requirements.json"), owned = store();
    await (0, promises_1.writeFile)(requirements, JSON.stringify({ project_id: project.id, source: source(entry), original_artifact_id: entry.original_artifact_id,
        preflight_directory: qualified.directory, preflight_sha256: qualified.result_sha256, phase,
        ...(expectedCanonicalSha256 ? { expected_canonical_sha256: expectedCanonicalSha256 } : {}) }, null, 2));
    const args = ["-m", "tests.support.ligand_profiles_performance_preflight", "current-context", "--database", owned.database,
        "--data-dir", owned.data, "--requirements", requirements, "--output-dir", (0, node_path_1.resolve)(out, "qualification")];
    await runSetupActor(args, out, "Published source-context proof");
    const bytes = await (0, promises_1.readFile)((0, node_path_1.resolve)(out, "qualification/result.json"));
    const result = JSON.parse(bytes.toString());
    check(result.schema === "profile-performance-published-context-v1" && sameSource(result.source, source(entry))
        && result.preflight_sha256 === qualified.result_sha256 && result.original_sha256 === qualified.result.original_sha256
        && result.no_shared_cache_or_API_descriptor_work && result.actual_published_graph_ids_coordinates_match_independent_trial, "Published context does not qualify the exact accepted source");
    check((0, exports.digest)(await (0, promises_1.readFile)((0, node_path_1.resolve)(out, "qualification/actual-source.json"))) === result.source_sha256
        && (0, exports.digest)(await (0, promises_1.readFile)((0, node_path_1.resolve)(out, "qualification/actual-original.sdf"))) === result.original_sha256, "Published retained bodies changed");
    if (expectedCanonicalSha256)
        check(result.source_sha256 === expectedCanonicalSha256, "Redo did not restore edited canonical bytes");
    return { directory: out, result, result_sha256: (0, exports.digest)(bytes) };
}
async function consumerState(directory, projectIds) {
    const out = (0, node_path_1.resolve)(directory, "consumer-state");
    await (0, promises_1.mkdir)(out);
    const projects = (0, node_path_1.resolve)(out, "projects.json"), output = (0, node_path_1.resolve)(out, "result.json"), owned = store();
    await (0, promises_1.writeFile)(projects, JSON.stringify(projectIds));
    const args = ["-m", "tests.support.ligand_profiles_performance_preflight", "consumer-state", "--database", owned.database,
        "--data-dir", owned.data, "--projects", projects, "--output", output];
    await runSetupActor(args, out, "Read-only consumer proof");
    const body = await (0, promises_1.readFile)(output), result = JSON.parse(body.toString());
    check(result.schema === "profile-performance-consumer-state-v1" && JSON.stringify(result.project_ids) === JSON.stringify(projectIds), "Consumer proof scope differs");
    check(Number.isSafeInteger(result.retained_total) && result.retained_total >= 0 && result.retained_total <= 256, "Retained consumer record bound exceeded");
    check(result.owned_live_count === 0 && result.owned_records.every(row => projectIds.includes(row.project_id) && !row.live
        && (row.released === 1 || row.expired)), "Owned property consumer demand remains live");
    return { directory: out, result_sha256: (0, exports.digest)(body), ...result };
}
function observer(directory) {
    const owned = store(), output = (0, node_path_1.resolve)(directory, "worker-observation.json"), stop = (0, node_path_1.resolve)(directory, "observer.stop");
    const trace = process.env.NEISTRA_PROPERTY_WORKER_TRACE;
    if (trace)
        check((0, node_path_1.resolve)(trace) === (0, node_path_1.resolve)(owned.data, "qualification/worker-turns.jsonl"), "Unowned worker trace");
    const args = ["-m", "tests.support.ligand_property_performance_qualification", "observe", "--database", owned.database,
        "--output", output, "--stop-file", stop, ...(trace ? ["--turn-trace", (0, node_path_1.resolve)(trace)] : [])];
    const child = (0, node_child_process_1.spawn)((0, node_path_1.resolve)(".venv/bin/python"), args, { env: process.env, stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "", stderr = "";
    child.stdout.on("data", b => { stdout += String(b); });
    child.stderr.on("data", b => { stderr += String(b); });
    const completion = new Promise((done, fail) => { child.once("error", fail); child.once("close", (code, signal) => done({ code, signal })); });
    const read = (0, observer_snapshot_1.createObserverSnapshotReader)(() => (0, promises_1.readFile)(output, "utf8"));
    return { read, output, async finish() {
            await (0, promises_1.writeFile)(stop, "stop\n");
            const timeout = Symbol("timeout");
            let timer;
            const result = await Promise.race([completion, new Promise(done => { timer = setTimeout(() => done(timeout), 15_000); })]);
            if (timer)
                clearTimeout(timer);
            if (result === timeout) {
                child.kill("SIGTERM");
                await completion;
            }
            await (0, promises_1.writeFile)((0, node_path_1.resolve)(directory, "observer.stdout"), stdout);
            await (0, promises_1.writeFile)((0, node_path_1.resolve)(directory, "observer.stderr"), stderr);
            await (0, promises_1.writeFile)((0, node_path_1.resolve)(directory, "observer-execution.json"), JSON.stringify({ argv: [(0, node_path_1.resolve)(".venv/bin/python"), ...args], completion: result === timeout ? "timeout" : result }, null, 2));
            check(result !== timeout && result.code === 0 && result.signal === null, "Observer must close positively");
            const final = await read();
            check(final?.complete, "Closed observer proof required");
            return final;
        } };
}
function sourceIdentities() {
    const paths = (0, node_child_process_1.execFileSync)("git", ["ls-files", "--cached", "--others", "--exclude-standard", "-z", "--", "apps", "packages", "tests/support", "tests/e2e", "tests/fixtures", "scripts", "pyproject.toml", "uv.lock", "pnpm-lock.yaml", "playwright.config.ts"], { encoding: "utf8" }).split("\0").filter(Boolean);
    return { candidate: (0, node_child_process_1.execFileSync)("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(), paths: [...new Set(paths)].sort() };
}
async function sourceMap(paths) {
    return Object.fromEntries(await Promise.all(paths.map(async (path) => [path, (0, exports.digest)(await (0, promises_1.readFile)((0, node_path_1.resolve)(path)))])));
}
