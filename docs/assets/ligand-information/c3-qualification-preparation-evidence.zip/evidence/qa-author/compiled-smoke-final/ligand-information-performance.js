"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.comparisonOracle = comparisonOracle;
exports.positiveHeaderOracle = positiveHeaderOracle;
exports.headerTrial = headerTrial;
exports.installPrimaryObservation = installPrimaryObservation;
exports.armPrimary = armPrimary;
exports.primaryEvidence = primaryEvidence;
exports.comparisonMatches = comparisonMatches;
exports.elapsedFrom = elapsedFrom;
exports.passiveTraffic = passiveTraffic;
exports.trafficCounts = trafficCounts;
exports.currentInventory = currentInventory;
exports.currentDrawing = currentDrawing;
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
const profile_performance_1 = require("./profile-performance");
const operators = { lt: "<", le: "≤", gt: ">", ge: "≥" };
/** Independent manual operator and display-coordinate oracle; never calls the application evaluator. */
function comparisonOracle(registry, profileId, report) {
    (0, profile_performance_1.check)(report.model_status === "qualified" && report.model_reason === null, "Only qualified positive specimens use this oracle");
    (0, profile_performance_1.check)(Object.entries(registry.descriptor_method).every(([key, value]) => report[key] === value), "Scientific method changed");
    const profile = registry.profiles.find(p => p.id === profileId);
    (0, profile_performance_1.check)(profile?.availability === "available", "Available profile required");
    (0, profile_performance_1.check)(report.contains_formally_charged_atoms === false, "Only uncharged independently qualified positive specimens use this comparison oracle");
    const rules = (0, profile_performance_1.constraints)(registry, profileId), required = new Set(profile.required_descriptor_ids);
    const axes = registry.axes.filter(a => profile.axis_ids.includes(a.id) && required.has(a.descriptor_id));
    (0, profile_performance_1.check)(axes.length === required.size && [...required].every(id => axes.filter(a => a.descriptor_id === id).length === 1), "Unique complete axes required");
    const rows = axes.map((axis, index) => {
        const definition = registry.descriptors.find(d => d.id === axis.descriptor_id);
        const value = report.values.find(v => v.descriptor_id === axis.descriptor_id);
        (0, profile_performance_1.check)(definition && value?.status === "ready" && typeof value.value === "number" && Number.isFinite(value.value), "Missing values cannot be plotted as zero");
        const n = value.value, [low, high] = axis.domain;
        (0, profile_performance_1.check)(axis.normalization === "linear" && Number.isFinite(low) && Number.isFinite(high) && high > low, "Finite increasing linear domain required");
        (0, profile_performance_1.check)(axis.clipping === "mark_and_clip" && axis.missing === "leave_missing", "Unsupported display policy");
        (0, profile_performance_1.check)(axis.numeric_rule === "finite" || axis.numeric_rule === "nonnegative_integer" && Number.isSafeInteger(n) && n >= 0
            || axis.numeric_rule === "safe_integer" && Number.isSafeInteger(n) || axis.numeric_rule === "fraction_0_1" && n >= 0 && n <= 1, "Invalid scientific axis value");
        const unit = definition.unit ? ` ${definition.unit}` : "";
        const clipped = n < low ? "low" : n > high ? "high" : null;
        const spans = [`${n}${unit}`, `Scale ${low}–${high}${unit}`];
        if (clipped)
            spans.push(`Outside display scale (${clipped === "low" ? "below" : "above"}); actual value retained`);
        const rowRules = rules.filter(c => c.descriptor_id === axis.descriptor_id).map(rule => ({ ...rule,
            met: rule.operator === "lt" ? n < rule.limit : rule.operator === "le" ? n <= rule.limit : rule.operator === "gt" ? n > rule.limit : n >= rule.limit }));
        for (const rule of rowRules) {
            const met = rule.operator === "lt" ? n < rule.limit : rule.operator === "le" ? n <= rule.limit : rule.operator === "gt" ? n > rule.limit : n >= rule.limit;
            spans.push(`${operators[rule.operator]} ${rule.limit}${unit} · ${met ? "Met" : "Not met"}`);
        }
        const scaled = Math.max(0, Math.min(1, (n - low) / (high - low))), angle = -Math.PI / 2 + 2 * Math.PI * index / axes.length;
        return { descriptor: axis.descriptor_id, name: definition.name, value: n, integer: definition.value_type === "integer", unit, rules: rowRules, spans, clipped,
            x: 120 + 78 * Math.cos(angle) * scaled, y: 120 + 78 * Math.sin(angle) * scaled };
    });
    return { profileId, rows, constraints: rules.length };
}
const formulas = {
    "paired-chromium-10": ["C10H22", "C9H21N"], "paired-chromium-86": ["C86H174", "C85H173N"],
    "paired-mobile-chromium-10": ["C9H20O", "C8H19NO"], "paired-mobile-chromium-86": ["C85H172O", "C84H171NO"],
};
function positiveHeaderOracle(id, phase, structure, report, facts, reconciliation) {
    const pair = formulas[id];
    (0, profile_performance_1.check)(pair, "Only the four frozen positive specimens have analytical formula expectations");
    (0, profile_performance_1.check)(report.model_status === "qualified" && report.model_reason === null && report.contains_formally_charged_atoms === false, "Terminal READY does not establish qualified chemistry");
    (0, profile_performance_1.check)(reconciliation.policy === "automatic" && reconciliation.status === "complete" && reconciliation.skipped_count === 0 && reconciliation.unprocessed_count === 0, "The independent automatic hydrogen trial must complete");
    (0, profile_performance_1.check)(facts.atoms.length > 0 && facts.atoms.every(a => ["C", "H", "O"].includes(String(a[0])) && a[1] === 0 && a[2] === 0 && a[3] === 0 && a[4] === 0
        && Number.isSafeInteger(a[5]) && Number(a[5]) >= 0), "Frozen positive chemistry must have ordinary neutral nonradical nonisotopic facts");
    const atoms = structure.atoms;
    (0, profile_performance_1.check)(atoms.length > 0 && new Set(atoms.map(a => a.id)).size === atoms.length
        && atoms.every(a => ["C", "H", "N", "O"].includes(a.element) && a.formal_charge === 0), "Explicit ordinary neutral atom membership required");
    const counts = Object.fromEntries(["C", "H", "N", "O"].map(element => [element, atoms.filter(a => a.element === element).length]));
    const formula = ["C", "H", "N", "O"].filter(e => counts[e]).map(e => `${e}${counts[e] === 1 ? "" : counts[e]}`).join("");
    const expected = pair[phase === "before" ? 0 : 1];
    (0, profile_performance_1.check)(formula === expected, "Explicit source formula differs from the analytical frozen specimen");
    const originalC = facts.atoms.filter(a => a[0] === "C").length, originalO = facts.atoms.filter(a => a[0] === "O").length;
    const originalH = facts.atoms.filter(a => a[0] === "H").length;
    (0, profile_performance_1.check)(facts.atoms.reduce((n, a) => n + Number(a[5]), 0) === originalH, "Frozen explicit hydrogen membership differs from heavy-atom neighbor counts");
    (0, profile_performance_1.check)(counts.C === originalC - (phase === "after" ? 1 : 0) && counts.O === originalO
        && counts.N === (phase === "after" ? 1 : 0) && counts.H === originalH - (phase === "after" ? 1 : 0), "Formula changed relative to frozen chemistry facts");
    const charge = report.values.find(v => v.descriptor_id === "formal_charge");
    (0, profile_performance_1.check)(charge?.status === "ready" && charge.value === 0, "Independent qualified charge must agree with explicit neutral membership");
    return { formula, charge: "0", atomIds: atoms.map(a => a.id).sort((a, b) => a - b), structure_value_sha256: (0, profile_performance_1.digest)(JSON.stringify(structure)) };
}
async function headerTrial(qualified, fixtureId) {
    const directory = (0, node_path_1.resolve)(qualified.directory, "qualification");
    const manifest = JSON.parse(await (0, promises_1.readFile)((0, node_path_1.resolve)("tests/fixtures/ligand-properties-performance/editable/manifest.json"), "utf8"));
    const facts = manifest.fixtures.find(f => f.id === fixtureId)?.chemistry_facts;
    (0, profile_performance_1.check)(facts, "Frozen chemistry facts missing");
    const independent = JSON.parse(await (0, promises_1.readFile)((0, node_path_1.resolve)(directory, "independent-result.json"), "utf8"));
    const beforeBytes = await (0, promises_1.readFile)((0, node_path_1.resolve)(directory, "actual-source.json")), afterBytes = await (0, promises_1.readFile)((0, node_path_1.resolve)(directory, "disposable-edited-source.json"));
    const context = JSON.parse(await (0, promises_1.readFile)((0, node_path_1.resolve)(directory, "source-context.json"), "utf8"));
    (0, profile_performance_1.check)((0, profile_performance_1.digest)(beforeBytes) === qualified.result.source_sha256 && (0, profile_performance_1.digest)(afterBytes) === context.disposable_edited_source_sha256, "Independent retained source bodies changed");
    const before = JSON.parse(beforeBytes.toString()), after = JSON.parse(afterBytes.toString());
    return { before: positiveHeaderOracle(fixtureId, "before", before, qualified.result.before_report, facts, independent.reconciliation),
        after: positiveHeaderOracle(fixtureId, "after", after, qualified.result.after_report, facts, independent.reconciliation) };
}
async function installPrimaryObservation(page) {
    await page.addInitScript(() => {
        const visible = (node) => {
            const b = node?.getBoundingClientRect();
            return !!node && !!b && b.width > 0 && b.height > 0 && b.bottom > 0 && b.top < innerHeight
                && b.right > 0 && b.left < innerWidth && getComputedStyle(node).visibility !== "hidden" && !node.closest('[aria-hidden="true"], [inert]');
        };
        const read = () => {
            const root = document.querySelector(".ligand-information"), header = root?.querySelector(".ligand-designated-information");
            const fieldNode = (label) => [...(header?.querySelectorAll("dl > div") ?? [])].find(n => n.querySelector("dt")?.textContent === label)?.querySelector("dd") ?? null;
            const field = (label) => fieldNode(label)?.textContent ?? null;
            const image = header?.querySelector("img"), comparison = root?.querySelector(".profile-comparison");
            return { at: performance.now(), entry: root?.querySelector(".ligand-entry-choice select")?.value ?? null,
                instance: field("Instance"), formula: field("Formula"), charge: field("Formal charge"),
                image: image ? { src: image.currentSrc || image.src, complete: image.complete, width: image.naturalWidth } : null,
                profile: root?.querySelector(".ligand-profile-choice select")?.value ?? null,
                primaryVisible: visible(root), headerVisible: ["Instance", "Formula", "Formal charge"].every(label => visible(fieldNode(label))),
                imageVisible: visible(image ?? null), svgVisible: visible(comparison?.querySelector("svg") ?? null),
                tableVisible: visible(comparison?.querySelector(".comparison-table[open] table") ?? null),
                spokes: comparison?.querySelectorAll("svg > g").length ?? 0,
                points: [...(comparison?.querySelectorAll(".comparison-point") ?? [])].map(n => ({ x: Number(n.getAttribute("cx")), y: Number(n.getAttribute("cy")), clipped: n.getAttribute("data-clipped") })),
                polygons: [...(comparison?.querySelectorAll("polygon.comparison-shape") ?? [])].map(n => n.getAttribute("points") ?? ""),
                legend: [...(comparison?.querySelectorAll(".comparison-legend li") ?? [])].map(n => n.textContent ?? ""),
                rows: [...(comparison?.querySelectorAll("tbody tr") ?? [])].map(n => ({ descriptor: n.dataset.descriptor ?? "", spans: [...n.querySelectorAll("td > span")].map(s => s.textContent ?? "") })),
                criteria: [...(comparison?.querySelectorAll("tbody tr td > span") ?? [])].filter(n => / · (Met|Not met)$/.test(n.textContent ?? "")).length };
        };
        const state = { timeOrigin: performance.timeOrigin, snapshots: [], triggers: [], read, observe: () => undefined };
        state.observe = () => {
            const snapshot = read(), previous = state.snapshots.at(-1);
            if (!previous || JSON.stringify({ ...previous, at: 0 }) !== JSON.stringify({ ...snapshot, at: 0 }))
                state.snapshots.push(snapshot);
        };
        window.ligandInformationPerformance = state;
        new MutationObserver(state.observe).observe(document, { subtree: true, childList: true, characterData: true, attributes: true });
        for (const event of ["load", "scroll", "resize", "change"])
            document.addEventListener(event, state.observe, true);
    });
}
async function armPrimary(page, control, label, event) {
    await control.evaluate((node, args) => node.addEventListener(args.event, e => {
        const state = window.ligandInformationPerformance;
        state.triggers.push({ label: args.label, at: performance.now(), trusted: e.isTrusted, event: args.event, initial: state.read() });
        state.observe();
    }, { capture: true, once: true }), { label, event });
}
async function primaryEvidence(page) {
    return page.evaluate(() => {
        const state = window.ligandInformationPerformance;
        state.observe();
        return { timeOrigin: state.timeOrigin, snapshots: state.snapshots, triggers: state.triggers,
            imageResources: performance.getEntriesByType("resource").filter(r => r.initiatorType === "img").map(r => {
                const p = r;
                return { name: p.name, startTime: p.startTime, responseEnd: p.responseEnd,
                    transferSize: p.transferSize, encodedBodySize: p.encodedBodySize, decodedBodySize: p.decodedBodySize };
            }) };
    });
}
function comparisonMatches(snapshot, expected) {
    if (snapshot.profile !== expected.profileId || snapshot.spokes !== expected.rows.length || snapshot.points.length !== expected.rows.length
        || snapshot.polygons.length !== (expected.rows.length >= 3 ? 1 : 0) || snapshot.criteria !== expected.constraints
        || JSON.stringify(snapshot.legend) !== JSON.stringify(expected.rows.map(r => r.name)) || snapshot.rows.length !== expected.rows.length)
        return false;
    if (!snapshot.rows.every((row, i) => {
        const wanted = expected.rows[i], displayed = row.spans[0];
        if (row.descriptor !== wanted.descriptor || !displayed || wanted.unit && !displayed.endsWith(wanted.unit)
            || JSON.stringify(row.spans.slice(1)) !== JSON.stringify(wanted.spans.slice(1)))
            return false;
        const value = Number(wanted.unit ? displayed.slice(0, -wanted.unit.length) : displayed);
        const decisionsMatch = wanted.rules.every(rule => (rule.operator === "lt" ? value < rule.limit : rule.operator === "le" ? value <= rule.limit
            : rule.operator === "gt" ? value > rule.limit : value >= rule.limit) === rule.met);
        return Number.isFinite(value) && decisionsMatch && (wanted.integer ? Number.isSafeInteger(value) && value === wanted.value : Math.abs(value - wanted.value) <= 1e-10);
    }))
        return false;
    const samePoint = (a, b) => Number.isFinite(a.x) && Number.isFinite(a.y)
        && Math.abs(a.x - b.x) <= 1e-6 && Math.abs(a.y - b.y) <= 1e-6;
    if (!snapshot.points.every((p, i) => samePoint(p, expected.rows[i]) && p.clipped === expected.rows[i].clipped))
        return false;
    if (snapshot.polygons.length) {
        const polygon = snapshot.polygons[0].trim().split(/\s+/).map(p => { const [x, y] = p.split(",").map(Number); return { x, y }; });
        if (polygon.length !== expected.rows.length || !polygon.every((p, i) => samePoint(p, expected.rows[i])))
            return false;
    }
    return true;
}
function elapsedFrom(trigger, snapshot) {
    (0, profile_performance_1.check)(trigger.trusted, "Trusted browser activation required");
    if (!snapshot)
        return null;
    (0, profile_performance_1.check)(Number.isFinite(snapshot.at) && snapshot.at >= trigger.at, "Readiness observation precedes its trigger");
    return snapshot.at - trigger.at;
}
function passiveTraffic(page, directory) {
    const records = [], pending = new Set(), byRequest = new Map();
    const request = (r) => {
        const url = new URL(r.url());
        const kind = r.resourceType() === "image" ? "image" : url.pathname.includes("/ligand-properties") ? "properties"
            : url.pathname.endsWith("/depiction") ? "depiction" : url.pathname.includes("/ligand-candidates") ? "inventory"
                : url.pathname.endsWith("/model-edits") ? "edit" : /^\/api\/v1\/projects(?:\/[^/]+)?$/.test(url.pathname) ? "project" : null;
        if (!kind)
            return;
        let body = null;
        try {
            body = r.postDataJSON();
        }
        catch {
            body = r.postData();
        }
        const record = { kind, method: r.method(), url: r.url(), path: url.pathname, at_utc_ms: Date.now(), body };
        records.push(record);
        byRequest.set(r, record);
    };
    page.on("request", request);
    page.on("requestfailed", r => { const record = byRequest.get(r); if (record)
        record.error = r.failure()?.errorText ?? "Request failed"; });
    page.on("response", response => {
        const record = byRequest.get(response.request());
        if (!record)
            return;
        const capture = async () => {
            record.status = response.status();
            record.response_utc_ms = Date.now();
            try {
                if (record.kind === "image") {
                    const body = await response.body();
                    record.bytes = body.length;
                    record.sha256 = (0, profile_performance_1.digest)(body);
                    record.companion = `image-${record.sha256}.body`;
                    await (0, promises_1.writeFile)((0, node_path_1.resolve)(directory, record.companion), body);
                }
                else if ((response.headers()["content-type"] ?? "").includes("json"))
                    record.response = await response.json();
            }
            catch (error) {
                record.error = String(error);
            }
        };
        const task = capture();
        pending.add(task);
        void task.finally(() => pending.delete(task));
    });
    return { records, async settle() { while (pending.size)
            await Promise.all([...pending]); },
        async save(filename) { while (pending.size)
            await Promise.all([...pending]); await (0, promises_1.writeFile)((0, node_path_1.resolve)(directory, filename), JSON.stringify(records, null, 2)); } };
}
function trafficCounts(records) {
    return { project: records.filter(r => r.kind === "project").length, inventory: records.filter(r => r.kind === "inventory").length,
        depiction: records.filter(r => r.kind === "depiction").length, images: records.filter(r => r.kind === "image").length,
        propertyReads: records.filter(r => r.kind === "properties" && r.method === "POST" && r.path.endsWith("/read")).length,
        allocations: records.filter(r => r.kind === "properties" && r.method === "POST" && r.path.endsWith("/consumers")).length,
        demands: records.filter(r => r.kind === "properties" && r.method === "PUT").length,
        releases: records.filter(r => r.kind === "properties" && r.method === "DELETE").length };
}
function currentInventory(records, entry, artifact) {
    return records.filter(r => r.kind === "inventory" && r.status === 200).map(r => r.response)
        .find(r => r?.entry_id === entry && r.artifact_id === artifact && r.designated_candidate?.chemistry_status === "qualified");
}
function currentDrawing(records, entry, artifact) {
    return records.filter(r => r.kind === "depiction" && r.status === 200).map(r => r.response)
        .find(r => r?.entry_id === entry && r.artifact_id === artifact && r.status === "ready" && r.artifact);
}
