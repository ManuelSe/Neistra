const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cp = require('child_process');
const root = process.cwd();
const ts = require(path.join(root, 'apps/web/node_modules/typescript'));
const out = path.join(root, '.issue-11-evidence/issue161-primary-performance-qa1');
const files = ['tests/e2e/ligand-sidebar-performance.spec.ts', 'tests/e2e/support/ligand-information-performance.ts', 'apps/web/src/test/ligand-information-performance.test.ts', 'tests/e2e/ligand-profiles-performance.spec.ts'];
const hash = text => crypto.createHash('sha256').update(text).digest('hex');
const before = Object.fromEntries(files.map(file => [file, hash(fs.readFileSync(file))]));
const originals = new Map(files.map(file => [path.resolve(root,file), file === 'tests/e2e/ligand-profiles-performance.spec.ts' ? fs.readFileSync(path.join(out,'inherited-before.ts.txt'),'utf8') : fs.readFileSync(file,'utf8')]));
function nodes(text, filename) {
  const source = ts.createSourceFile(filename, text, ts.ScriptTarget.Latest, true);
  const assertions = [], cases = [], deadlines = [], exclusions = [];
  const normalize = node => node.getText(source).replace(/\s+/g, ' ');
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const expression = node.expression;
      if (ts.isIdentifier(expression) && expression.text === 'test') cases.push(normalize(node.arguments[0]));
      if (ts.isPropertyAccessExpression(expression)) {
        if (/^to[A-Z]/.test(expression.name.text) && expression.expression.getText(source).startsWith('expect')) assertions.push(normalize(node));
        if (expression.expression.getText(source) === 'test' && expression.name.text === 'setTimeout') deadlines.push(normalize(node));
        if (expression.expression.getText(source) === 'test' && ['skip', 'fixme'].includes(expression.name.text)) exclusions.push(normalize(node));
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(source);
  return { assertions, cases, deadlines, exclusions, syntax: source.parseDiagnostics.map(d => ts.flattenDiagnosticMessageText(d.messageText, '\n')) };
}
function missing(old, current) {
  const counts = new Map();
  for (const value of current) counts.set(value, (counts.get(value) ?? 0) + 1);
  const absent = [];
  for (const value of old) { const count = counts.get(value) ?? 0; if (!count) absent.push(value); else counts.set(value, count - 1); }
  return absent;
}
const retention = files.map(file => {
  const old = nodes(originals.get(path.resolve(root, file)), file), candidate = nodes(fs.readFileSync(file, 'utf8'), file);
  return { file, originalAssertions: old.assertions.length, candidateAssertions: candidate.assertions.length,
    missingAssertions: missing(old.assertions, candidate.assertions), missingCases: missing(old.cases, candidate.cases),
    missingDeadlines: missing(old.deadlines, candidate.deadlines), oldExclusions: old.exclusions, currentExclusions: candidate.exclusions,
    originalTemplateCases: old.cases.length, currentTemplateCases: candidate.cases.length, syntax: candidate.syntax };
});
const options = { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, moduleResolution: ts.ModuleResolutionKind.Bundler,
  lib: ['lib.es2022.d.ts', 'lib.dom.d.ts', 'lib.dom.iterable.d.ts'], strict: true, noEmit: true, skipLibCheck: true,
  esModuleInterop: true, allowSyntheticDefaultImports: true, jsx: ts.JsxEmit.ReactJSX, allowImportingTsExtensions: true,
  baseUrl: root, paths: { '/src/*': ['apps/web/src/*'] }, types: ['node'],
  typeRoots: [path.join(root, 'apps/web/node_modules/@types'), path.join(root, 'node_modules/@types')], resolveJsonModule: true };
const vite = path.join(root, 'apps/web/node_modules/vite/client.d.ts');
function check(baseline) {
  const host = ts.createCompilerHost(options), read = host.readFile;
  if (baseline) host.readFile = file => originals.get(path.resolve(file)) ?? read.call(host, file);
  const program = ts.createProgram([...files.map(file => path.resolve(root, file)), vite], options, host);
  return ts.getPreEmitDiagnostics(program).map(d => {
    const point = d.file && d.start !== undefined ? d.file.getLineAndCharacterOfPosition(d.start) : null;
    return { file: d.file ? path.relative(root, d.file.fileName) : null, line: point ? point.line + 1 : null,
      code: d.code, message: ts.flattenDiagnosticMessageText(d.messageText, '\n') };
  });
}
const candidate = check(false), baseline = check(true);
// No Git execution in this bounded correction; source whitespace is checked by the receipt runner.
const after = Object.fromEntries(files.map(file => [file, hash(fs.readFileSync(file))]));
const fail = candidate.length || baseline.length || retention.some(x => x.syntax.length || x.missingAssertions.length || x.missingCases.length || x.missingDeadlines.length || JSON.stringify(x.oldExclusions) !== JSON.stringify(x.currentExclusions)) || JSON.stringify(before) !== JSON.stringify(after);
const result = { recorded_utc: new Date().toISOString(), candidateCommit: JSON.parse(fs.readFileSync(path.join(out, 'closed-interval-correction/original-handoff.json'))).candidate_commit,
  subject: 'Four owned QA sources; strict static check, no browser/service/scientific execution',
  files: before, sourceBeforeAfterExact: JSON.stringify(before) === JSON.stringify(after), retention, candidateDiagnostics: candidate,
  baselineDiagnostics: baseline, compilerOptions: options, explicitViteClientDeclaration: path.relative(root, vite), diffCheck: 'Not rerun; no Git allowed in correction',
  verdict: fail ? 'NOT_PASS' : 'PASS', originalConfigurationFailure: 'strict-types.json retains unresolved vite/client types-package configuration; this run supplies the installed declaration as explicit root.' };
fs.writeFileSync(path.join(out, 'closed-interval-correction/final-static-result.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
if (fail) process.exit(1);
