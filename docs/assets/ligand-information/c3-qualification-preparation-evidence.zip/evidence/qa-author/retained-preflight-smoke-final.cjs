const fs = require('fs'), path = require('path'), crypto = require('crypto');
const root = process.cwd(), out = path.join(root, '.issue-11-evidence/issue161-primary-performance-qa1');
const ts = require(path.join(root, 'apps/web/node_modules/typescript'));
const compiled = path.join(out, 'compiled-smoke-final'); fs.mkdirSync(compiled);
fs.writeFileSync(path.join(compiled, 'package.json'), '{"type":"commonjs"}\n');
const inputs = {};
for (const name of ['ligand-information-performance', 'profile-performance', 'observer-snapshot']) {
 const source = path.join(root, 'tests/e2e/support', name + '.ts'), body = fs.readFileSync(source, 'utf8');
 inputs[path.relative(root, source)] = crypto.createHash('sha256').update(body).digest('hex');
 fs.writeFileSync(path.join(compiled, name + '.js'), ts.transpileModule(body, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true } }).outputText);
}
const helper = require(path.join(compiled, 'ligand-information-performance.js'));
const retained = '/datadisk/dev/neistra-worktrees/issue-160-physicochemical-profiles/.issue-11-evidence/issue160-profile-performance';
const sha = body => crypto.createHash('sha256').update(body).digest('hex');
(async () => {
 const records = [];
 for (const project of ['chromium', 'mobile-chromium']) for (const size of [10,86]) {
  const id = `paired-${project}-${size}`;
  const options = fs.readdirSync(retained).map(name => path.join(retained,name)).filter(p => fs.existsSync(path.join(p, `preflight-${id}`, 'qualification/source-context.json')) && fs.existsSync(path.join(p,'registry.json')));
  if (!options.length) throw Error('No retained completed JSON preflight for '+id);
  const caseDir=options[0], directory=path.join(caseDir, `preflight-${id}`), resultPath=path.join(directory,'qualification/result.json');
  const bytes=fs.readFileSync(resultPath), pair=JSON.parse(bytes), registry=JSON.parse(fs.readFileSync(path.join(caseDir,'registry.json')));
  const qualified={directory,result:pair.independent_no_original,context:pair.source_context,result_sha256:sha(bytes)};
  const headers=await helper.headerTrial(qualified,id), before=helper.comparisonOracle(registry,size===10?'ro5':'ro5-veber',qualified.result.before_report);
  const after=helper.comparisonOracle(registry,size===10?'ro5':'ro5-veber',qualified.result.after_report);
  records.push({id,retained_preflight:directory,result_sha256:sha(bytes),before_formula:headers.before.formula,after_formula:headers.after.formula,
   original_atoms:headers.before.atomIds.length,edited_atoms:headers.after.atomIds.length,axes:before.rows.length,criteria:before.constraints,
   before_clipped:before.rows.map(r=>r.clipped),after_clipped:after.rows.map(r=>r.clipped)});
 }
 const after=Object.fromEntries(Object.keys(inputs).map(name=>[name,sha(fs.readFileSync(path.join(root,name)))]));
 if(JSON.stringify(inputs)!==JSON.stringify(after))throw Error('Source changed during smoke');
 const result={recorded_utc:new Date().toISOString(),scope:'READ_ONLY_RETAINED_PREFLIGHT_JSON_SMOKE_ONLY; no new scientific/native/API/SQL execution',inputs,records,complete:true};
 fs.writeFileSync(path.join(out,'retained-preflight-smoke-final.json'),JSON.stringify(result,null,2)+'\n'); console.log(JSON.stringify(result));
})().catch(error=>{console.error(error);process.exitCode=1;});
