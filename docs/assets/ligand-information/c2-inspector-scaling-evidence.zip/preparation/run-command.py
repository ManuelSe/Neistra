from pathlib import Path
import hashlib,json,subprocess,sys,time
root=Path.cwd();p=root/'.issue-11-evidence/issue161-inspector-scaling-preparation1'
name=sys.argv[1];cmd=sys.argv[2:];log=p/(name+'.log');receipt=p/(name+'-receipt.json')
assert not log.exists() and not receipt.exists()
started=time.monotonic()
with log.open('wb') as out:
 result=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT,check=False)
v={'command':cmd,'exit':result.returncode,'elapsed_seconds':time.monotonic()-started,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
receipt.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v));print(log.read_text(errors='replace')[-10000:]);sys.exit(result.returncode)
