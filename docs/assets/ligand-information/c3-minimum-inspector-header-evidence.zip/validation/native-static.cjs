const fs = require('fs'), path = require('path'), cp = require('child_process'), crypto = require('crypto');
const root = process.cwd(), out = path.join(root, '.issue-11-evidence/issue161-min-inspector-correction-validation1');
const ts = require(path.join(root, 'apps/web/node_modules/typescript'));
const files = ['tests/e2e/ligand-information-access.spec.ts', 'tests/e2e/ligand-profiles-access.spec.ts'];
const originals = Object.fromEntries(files.map(f => [f, cp.execFileSync('git', ['show', `HEAD:${f}`], { encoding: 'utf8' })]));
const current = Object.fromEntries(files.map(f => [f, fs.readFileSync(f, 'utf8')]));
const expectedPrefix = originals[files[0]].replace('payload!.descriptor_ids', 'payload.descriptor_ids').replace('request: payload!, response: body', 'request: payload, response: body');
if (!current[files[0]].startsWith(expectedPrefix)) throw Error('Existing native acceptance changed beyond the two type-only cleanups');
const emit = text => ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, jsx: ts.JsxEmit.ReactJSX } }).outputText;
if (emit(expectedPrefix) !== emit(originals[files[0]])) throw Error('Type-only cleanup changed emitted runtime');
const beforeCleanup = fs.readFileSync(path.join(out, 'native-access-before-type-cleanup.ts.txt'), 'utf8');
if (emit(beforeCleanup) !== emit(current[files[0]])) throw Error('Native source cleanup changed compiled runtime');
if (current[files[1]] !== originals[files[1]]) throw Error('Reviewed cached-superset oracle changed');
const options = { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, moduleResolution: ts.ModuleResolutionKind.Bundler,
  lib: ['lib.es2022.d.ts', 'lib.dom.d.ts', 'lib.dom.iterable.d.ts'], strict: true, noEmit: true, skipLibCheck: true,
  esModuleInterop: true, allowSyntheticDefaultImports: true, jsx: ts.JsxEmit.ReactJSX, allowImportingTsExtensions: true,
  baseUrl: root, paths: { '/src/*': ['apps/web/src/*'] }, types: ['node'],
  typeRoots: [path.join(root, 'apps/web/node_modules/@types'), path.join(root, 'node_modules/@types')], resolveJsonModule: true };
function diagnostics(baseline) {
  const host = ts.createCompilerHost(options), read = host.readFile;
  if (baseline) host.readFile = f => originals[path.relative(root, f)] ?? read.call(host, f);
  const program = ts.createProgram([...files.map(f => path.resolve(f)), path.join(root, 'apps/web/node_modules/vite/client.d.ts')], options, host);
  return ts.getPreEmitDiagnostics(program).map(d => ({ file: d.file ? path.relative(root, d.file.fileName) : null, code: d.code, message: ts.flattenDiagnosticMessageText(d.messageText, '\n') }));
}
const candidate = diagnostics(false), baseline = diagnostics(true);
const result = { recorded_utc: new Date().toISOString(), candidate_base: cp.execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  files: Object.fromEntries(files.map(f => [f, crypto.createHash('sha256').update(current[f]).digest('hex')])),
  original_acceptance_unchanged_except_two_type_assertions: true, complete_native_emitted_runtime_identical_before_after_type_cleanup: true, original_deadlines_and_exclusions_retained: true,
  cached_superset_source_unchanged: true, candidate_diagnostics: candidate, baseline_diagnostics: baseline,
  new_native_case_executed: false, verdict: candidate.length || baseline.length ? 'NOT_PASS' : 'PASS' };
fs.writeFileSync(path.join(out, 'native-static.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result)); if (candidate.length || baseline.length) process.exit(1);
