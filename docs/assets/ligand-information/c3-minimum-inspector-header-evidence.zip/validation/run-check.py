import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
out = Path(__file__).parent
label = sys.argv[1]
commands = json.loads((out / 'commands.json').read_text())['commands']
before = json.loads((out / 'source-before.json').read_text())
assert all(hashlib.sha256((root / p).read_bytes()).hexdigest() == h for p, h in before.items())
record = {'label': label, 'command': commands[label], 'started_utc': datetime.datetime.now(datetime.UTC).isoformat()}
assert not (out / f'{label}-execution.json').exists()
with (out / f'{label}.stdout.log').open('xb') as stdout, (out / f'{label}.stderr.log').open('xb') as stderr:
    code = subprocess.call(commands[label], cwd=root, stdout=stdout, stderr=stderr)
after = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in before}
record.update({'finished_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'exit_code': code, 'all384_subject_bodies_fixed': before == after})
record['logs'] = {name: {'bytes': (out / name).stat().st_size, 'sha256': hashlib.sha256((out / name).read_bytes()).hexdigest()} for name in [f'{label}.stdout.log', f'{label}.stderr.log']}
(out / f'{label}-execution.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
sys.exit(code if before == after else 99)
