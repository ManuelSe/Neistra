import { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import * as Tooltip from '@radix-ui/react-tooltip';
import { ProjectInspector, type InspectorView } from '../../apps/web/src/components/ProjectInspector';
import { themeStyles } from '../../apps/web/src/theme';

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
const noop = () => undefined;
function Harness() {
  const [view, setView] = useState<InspectorView>('ligand');
  return <QueryClientProvider client={queryClient}><Tooltip.Provider>
    <style>{themeStyles()}</style>
    <div id="probe-container" style={{ position: 'absolute', right: 0, top: 0, width: '17vw', height: 650 }}>
      <ProjectInspector project={undefined} selection={{ schema_version: 1, atoms: [], granularity: 'atom', source: 'inspector' }}
        pickingGranularity="atom" busy={false} view={view} onViewChange={next => {
          document.documentElement.dataset.viewChanges = String(Number(document.documentElement.dataset.viewChanges ?? 0) + 1);
          setView(next);
        }}
        ligandControls={<p className="empty-label">Open a project to inspect a ligand.</p>}
        onApply={noop} onApplySelection={noop} onPickingGranularity={noop} onClearSelection={noop}
        onExpandSelection={noop} onInvertSelection={noop} onPredicateSelection={noop} onSpatialSelection={noop}
        onSaveSelection={noop} onLoadSelection={noop} onDeleteSelection={noop} onCollapse={() => {
          document.documentElement.dataset.collapseInvocations = String(Number(document.documentElement.dataset.collapseInvocations ?? 0) + 1);
        }} />
    </div>
  </Tooltip.Provider></QueryClientProvider>;
}
createRoot(document.getElementById('root')!).render(<Harness />);
