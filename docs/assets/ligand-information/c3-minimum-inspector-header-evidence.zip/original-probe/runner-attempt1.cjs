const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createRequire } = require('module');
const root = process.cwd();
const out = path.join(root, '.issue-11-evidence/issue161-min-inspector-probe1');
const viteRequire = createRequire(path.join(root, 'apps/web/node_modules/vite/package.json'));
const esbuild = viteRequire('esbuild');
const { chromium } = require(path.join(root, 'node_modules/@playwright/test'));
const digest = body => crypto.createHash('sha256').update(body).digest('hex');
function sourceMap() {
  const result = {};
  function walk(directory) {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const p = path.join(directory, entry.name);
      if (entry.isDirectory()) walk(p);
      else if (entry.isFile()) result[path.relative(root, p)] = digest(fs.readFileSync(p));
    }
  }
  walk(path.join(root, 'apps/web/src'));
  return result;
}
function descendants() {
  const all = {};
  for (const name of fs.readdirSync('/proc')) {
    if (!/^\d+$/.test(name)) continue;
    try {
      const raw = fs.readFileSync(`/proc/${name}/stat`, 'utf8'), fields = raw.slice(raw.lastIndexOf(')') + 2).split(' ');
      all[Number(name)] = { parent: Number(fields[1]), cmdline: fs.readFileSync(`/proc/${name}/cmdline`, 'utf8').replaceAll('\0', ' ') };
    } catch {}
  }
  const owned = new Set([process.pid]);
  let changed = true;
  while (changed) { changed = false; for (const [pid, value] of Object.entries(all)) if (owned.has(value.parent) && !owned.has(Number(pid))) { owned.add(Number(pid)); changed = true; } }
  return [...owned].filter(pid => pid !== process.pid && /headless_shell|chrome-linux\/chrome/.test(all[pid]?.cmdline ?? '')).map(pid => ({ pid, ...all[pid] }));
}
async function geometry(page, phase) {
  return page.evaluate(phase => {
    const box = node => { const b = node.getBoundingClientRect(); return { left: b.left, top: b.top, right: b.right, bottom: b.bottom, width: b.width, height: b.height }; };
    const container = document.getElementById('probe-container'), section = document.querySelector('.project-inspector'), header = section.querySelector('.inspector-header');
    const sectionBox = box(section);
    return { phase, viewport: { width: innerWidth, height: innerHeight, dpr: devicePixelRatio }, container: box(container), section: sectionBox,
      header: box(header), title: { text: header.querySelector('h2').textContent.trim(), bounds: box(header.querySelector('h2')), font: getComputedStyle(header.querySelector('h2')).font },
      section_overflow: getComputedStyle(section).overflow, header_client_width: header.clientWidth, header_scroll_width: header.scrollWidth,
      controls: [...header.querySelectorAll('button')].map(node => { const b = box(node), hit = document.elementFromPoint(b.left + b.width / 2, b.top + b.height / 2); return { label: node.getAttribute('aria-label'), bounds: b,
        fully_inside_section: b.left >= sectionBox.left && b.right <= sectionBox.right && b.top >= sectionBox.top && b.bottom <= sectionBox.bottom,
        center_hit: hit === node || node.contains(hit), hit_element: hit?.tagName ?? null, focused: document.activeElement === node }; }),
      active_element: { tag: document.activeElement?.tagName, label: document.activeElement?.getAttribute('aria-label') } };
  }, phase);
}

(async () => {
  const started = new Date().toISOString(), before = sourceMap(), records = [], errors = [], network = [], closure = {};
  fs.writeFileSync(path.join(out, 'source-before.json'), JSON.stringify(before, null, 2) + '\n');
  let browser;
  try {
    const build = await esbuild.build({ entryPoints: [path.join(out, 'harness.tsx')], outdir: path.join(out, 'bundle'), bundle: true, platform: 'browser', format: 'iife', jsx: 'automatic',
      nodePaths: [path.join(root, 'apps/web/node_modules'), path.join(root, 'node_modules')], define: { 'process.env.NODE_ENV': '"production"' }, metafile: true, write: true });
    fs.writeFileSync(path.join(out, 'bundle-metafile.json'), JSON.stringify(build.metafile, null, 2) + '\n');
    browser = await chromium.launch({ executablePath: '/datadisk/dev/neistra/.playwright/chromium_headless_shell-1187/chrome-linux/headless_shell', headless: true });
    for (const width of [841, 900, 1000, 1440]) for (const theme of ['light', 'dark']) {
      const context = await browser.newContext({ viewport: { width, height: 750 }, deviceScaleFactor: 1, isMobile: false, hasTouch: false });
      const page = await context.newPage();
      page.on('pageerror', error => errors.push(String(error)));
      page.on('request', request => network.push({ url: request.url(), method: request.method() }));
      await page.setContent('<!doctype html><html data-theme="' + theme + '"><head><meta charset="utf-8"></head><body><div id="root"></div></body></html>');
      await page.addStyleTag({ path: path.join(root, 'apps/web/src/styles.css') });
      if (fs.existsSync(path.join(out, 'bundle/harness.css'))) await page.addStyleTag({ path: path.join(out, 'bundle/harness.css') });
      await page.addScriptTag({ path: path.join(out, 'bundle/harness.js') });
      await page.getByRole('heading', { name: 'Ligand information', exact: true }).waitFor();
      await page.evaluate(() => document.fonts.ready);
      for (const view of ['ligand', 'tools']) {
        if (view === 'tools') {
          await page.getByRole('button', { name: 'Inspector tools', exact: true }).focus();
          await page.keyboard.press('Enter');
          await page.getByRole('heading', { name: 'Selection', exact: true }).waitFor();
        }
        const measured = await geometry(page, 'before-keyboard');
        await page.locator('body').click({ position: { x: 10, y: 700 } });
        await page.keyboard.press('Tab');
        const firstTab = await geometry(page, 'first-Tab');
        await page.keyboard.press('Tab');
        const secondTab = await geometry(page, 'second-Tab');
        const screenshot = `${width}-${theme}-${view}.png`;
        await page.screenshot({ path: path.join(out, screenshot), fullPage: true });
        records.push({ width, theme, view, assumed_panel_ratio: 0.17, measured, keyboard: [firstTab, secondTab], screenshot });
      }
      await context.close();
    }
    closure.browser_processes_before_close = descendants();
  } catch (error) { errors.push(error.stack ?? String(error)); }
  finally {
    if (browser) { await browser.close(); closure.is_connected_after_close = browser.isConnected(); }
    closure.remaining_owned_browser_processes = descendants();
    const after = sourceMap();
    fs.writeFileSync(path.join(out, 'source-after.json'), JSON.stringify(after, null, 2) + '\n');
    const same = JSON.stringify(before) === JSON.stringify(after);
    const result = { started_utc: started, finished_utc: new Date().toISOString(), argv: process.argv, runner_pid: process.pid,
      scope: 'Actual isolated ProjectInspector component plus production styles/theme and real providers, undefined project, manually controlled17vw parent; not actual App/Panel resizing or final acceptance',
      source_count: Object.keys(before).length, sources_unchanged: same, records, errors, network_requests: network, closure,
      reproduced_clipped_controls: records.flatMap(r => r.measured.controls.filter(c => !c.fully_inside_section || !c.center_hit).map(c => ({ width: r.width, theme: r.theme, view: r.view, ...c }))),
      limitations: ['Undefined project avoids all API/scientific work; header is real production component.', 'Parent17vw emulates documented minimum ratio but does not execute App/resizable-panel behavior.', 'No controlled performance, physical device or full feature qualification claim.'] };
    fs.writeFileSync(path.join(out, 'result.json'), JSON.stringify(result, null, 2) + '\n');
    console.log(JSON.stringify({ sources_unchanged: same, record_count: records.length, clipped_controls: result.reproduced_clipped_controls.length, errors, network_requests: network.length, closure }));
    if (!same || errors.length || network.length || closure.is_connected_after_close || closure.remaining_owned_browser_processes.length) process.exitCode = 1;
  }
})();
