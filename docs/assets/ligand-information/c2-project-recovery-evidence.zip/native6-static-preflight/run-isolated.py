"""Run current profile correctness/access workflows; retain terminal facts and raw stores."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, runpy, shutil, socket, subprocess, time, zipfile

parser=argparse.ArgumentParser()
parser.add_argument("label")
parser.add_argument("--api-port",type=int,required=True)
parser.add_argument("--worker-port",type=int,required=True)
parser.add_argument("--web-port",type=int,required=True)
a=parser.parse_args()
assert a.label.startswith("issue161-profile-workflows") and a.label.replace("-","").isalnum()
root=Path.cwd().resolve()
ev=root/".issue-11-evidence"/a.label
run=Path("/tmp")/("neistra161-"+a.label.removeprefix("issue161-"))
assert not ev.exists() and not run.exists(),"Fresh label required; earlier attempts remain intact"
initial_status=subprocess.check_output(["git","status","--porcelain=v1"],text=True)
expected_files=json.loads((root/".issue-11-evidence/issue161-movement-native6-preflight/current-files.json").read_bytes())
assert set(initial_status.splitlines())=={" M "+name for name in expected_files},"Only the reviewed project-return correction and three acceptance specs may differ"
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()=="7fef1a14b9eaef5735961199d011a843f5fb48c2"
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected for name,expected in expected_files.items()),"Reviewed candidate bodies changed"
for port in (a.api_port,a.worker_port,a.web_port):
 with socket.socket() as s:
  s.settimeout(.3); assert s.connect_ex(("127.0.0.1",port))!=0,"Port occupied"
ev.mkdir();run.mkdir()
helpers=runpy.run_path(str(root/"docs/assets/ligand-profiles/qualification.py.txt"))
source_before=helpers["current_identities"](root)
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,value):
 (ev/name).write_text(json.dumps(value,indent=2)+"\n")
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
write("source-before.json",source_before)
with zipfile.ZipFile(ev/"source-before.zip","x",zipfile.ZIP_DEFLATED) as z:
 for name,expected in source_before.items():
  body=(root/name).read_bytes();assert sha(body)==expected;z.writestr(name,body)
existing=set((root/".issue-11-evidence/issue161-profile-performance").glob("*"))
argv=["corepack","pnpm","exec","playwright","test","tests/e2e/ligand-information-lifecycle.spec.ts","--grep","keeps coordinate and movement proposals","--reporter=list,json","--max-failures=1","--output",str(ev/"playwright")]
env={k:v for k,v in os.environ.items() if not k.startswith(("NEISTRA_","MOLWEAVE_")) and k not in {"DATABASE_URL","PYTHONPATH"}}
data=run/"data"
env.update({"PYTHONPATH":":".join(str(root/x) for x in ("apps/api/src","packages/neistra_core/src","packages/neistra_demo_plugin/src",".")),"NEISTRA_E2E_DATA_DIR":str(data),"NEISTRA_E2E_API_PORT":str(a.api_port),"NEISTRA_E2E_WORKER_PORT":str(a.worker_port),"NEISTRA_E2E_WEB_PORT":str(a.web_port),"NEISTRA_PROPERTY_WORKER_TRACE":str(data/"qualification/worker-turns.jsonl"),"NEISTRA_MINIMIZATION_EVIDENCE_DIR":str(run/"native"),"NEISTRA_AMBERTOOLS_PREFIX":"/datadisk/dev/.neistra-tools/ambertools-24.8","NEISTRA_PERFORMANCE":"0","NEISTRA_QUALIFICATION_VERSION":"0.38.0","NEISTRA_QUALIFICATION_BASE":"9f77410389c4e8738fdf94d3e69e7c8550fbc70c","PLAYWRIGHT_BROWSERS_PATH":"/datadisk/dev/neistra/.playwright","PLAYWRIGHT_JSON_OUTPUT_FILE":str(ev/"browser.json"),"OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1"})
command={"argv":argv,"cwd":str(root),"candidate":head,"clean_start":False,"initial_status":initial_status,"subject":"161 reviewedprojectreturncorrectionon7fef;workingtreebodiesfrozen;notfinalfeaturequalification","started_utc":now(),"ports":{"api":a.api_port,"worker":a.worker_port,"web":a.web_port},"run_root":str(run),"data_dir":str(data),"qualification_scope":"Fourcoordinate/movement/archivecases bothprojects/themes withbefore-helperfocus/ordinaryEscape proof; notwhole36/finalfeature","performance_profile":"portable correctness; no strict-host timing claim","source_count":len(source_before)}
write("command.json",command)
with (ev/"stdout.log").open("wb") as stdout,(ev/"stderr.log").open("wb") as stderr:
 proc=subprocess.Popen(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 write("running.json",command|{"runner_pid":proc.pid});print("RUNNING",proc.pid,str(ev),flush=True)
 code=proc.wait()
after=helpers["current_identities"](root);write("source-after.json",after)
current_head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
cases=sorted(set((root/".issue-11-evidence/issue161-profile-performance").glob("*"))-existing)
reviewed_bodies_unchanged=all(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected for name,expected in expected_files.items())
result=command|{"runner_pid":proc.pid,"finished_utc":now(),"exit_code":code,"selected_source_bodies_unchanged":source_before==after and current_head==head,"reviewed_working_bodies_unchanged":reviewed_bodies_unchanged,"case_dirs":[str(x) for x in cases],"logs":{n:{"bytes":(ev/n).stat().st_size,"sha256":sha((ev/n).read_bytes())} for n in ("stdout.log","stderr.log")}}
write("execution.json",result)
# Cleanup proof must precede every raw copy; do not infer it from runner exit alone.
def owners():
 live=[]
 for p in Path("/proc").iterdir():
  if not p.name.isdigit(): continue
  try:
   stat=(p/"stat").read_text().rsplit(")",1)[1].split()
   if stat[0] in {"Z","X","x"}: continue
   values=(p/"environ").read_bytes().split(b"\0")
   if any(v in values for v in (b"NEISTRA_E2E_DATA_DIR="+str(data).encode(),b"NEISTRA_DATA_DIR="+str(data).encode(),b"MOLWEAVE_DATA_DIR="+str(data).encode())):
    live.append(int(p.name))
  except (OSError,PermissionError,ProcessLookupError):pass
 return live
live=owners()
for _ in range(40):
 if not live:break
 time.sleep(.25);live=owners()
ports={}
for port in (a.api_port,a.worker_port,a.web_port):
 with socket.socket() as s:s.settimeout(.3);ports[str(port)]=s.connect_ex(("127.0.0.1",port))!=0
observers=[]
for case in cases:
 f=case/"observer-execution.json"
 observers.append({"case":str(case),"execution":json.loads(f.read_bytes()) if f.exists() else None})
closed=not live and all(ports.values()) and all(x["execution"] and x["execution"].get("completion")=={"code":0,"signal":None} for x in observers)
cleanup={"recorded_utc":now(),"runner_exit_code":code,"live_owned_pids":live,"ports_closed":ports,"observer_executions":observers,"positive_closed":closed,"primary_diagnostic_sql_before_copy":False,"files":[]}
write("cleanup.json",cleanup)
if closed:
 raw=ev/"closed-raw";raw.mkdir()
 for f in sorted(run.rglob("*")):
  if f.is_file() and f.name.endswith((".db",".db-wal",".db-shm",".sqlite",".sqlite-wal",".sqlite-shm")):
   q=raw/f.relative_to(run);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,q)
   b=f.read_bytes();assert q.read_bytes()==b;cleanup["files"].append({"original":str(f),"copy":str(q),"bytes":len(b),"sha256":sha(b)})
 write("closed-raw-copy-receipt.json",cleanup)
print(json.dumps({"exit_code":code,"source_unchanged":result["selected_source_bodies_unchanged"],"positive_closed":closed,"raw_copies":len(cleanup["files"]),"evidence":str(ev)}),flush=True)
raise SystemExit(code if code else (0 if closed and result["selected_source_bodies_unchanged"] and result["reviewed_working_bodies_unchanged"] else 2))
