# Neistra Progress

## Current milestone

Parent #11 remains active through verified delivery of required #156–#163.
#156–#159 are released and closed. #160 remains in complete qualification;
no v0.38.0 publication is claimed.
This checkout is #161's reversible local prerequisite integration, combining
prepared `a6f48892` with explicitly unreleased #160 `b14670a0`. Actual released
#160 integration remains required before final #161 gates or publication.
#162/#163 remain planned and unimplemented.

## Completed work

The prepared #161 sidebar composes deliberate exact-entry/ligand identity,
qualified depiction, live properties and shared profile/radar/table definitions.
The legacy Inspector tools remain accessible until #163. Existing browser filters
and the all-entry chooser preserve inspection context, including an explanation
when the inspected entry is outside current filters. Source failure retires
incompatible authority; original uploads, durable designation and history remain.

The preparatory merge preserves both decision histories and all earlier evidence.
Architecture intake confirms the runtime composition boundaries, incoming terminal
Jobs ordering, tools-only inspector query activation and retained native navigation.
Incoming scientific producers, qualification helpers and consistent 0.38.0 version
sources are integration inputs, not evidence of a delivered #160 prerequisite.

## Verification performed

Historical #161 evidence remains bound to its original subjects: 1,910 frontend
cases, the 16-case sidebar workflow checkpoint, inspector query-scaling controls,
and 28 retained-navigation native passes with six unchanged authored exclusions.
Their original source maps, failed attempts, lossless packets, raw stores and
limitations remain preserved under the child plan and `assets/ligand-information`.
These results do not qualify the current combined source.

#160's separate frozen candidate has 1,875 passing frontend cases and 18 current
native workflow cases, including both themes, actual desktop zoom and 26 trusted
emulated-touch activations (six explicitly hybrid native selectors). Its full
campaign3 failed on an inherited exact-status assertion; earlier interrupted and
failed attempts remain preserved without a complete-gate pass claim.

Current #161 integration passes lint, types, 326 focused frontend cases, production
build, all 52 archive cases and five native hardening cases with one unchanged
authored mobile performance exclusion. Selected 1,198-source maps remain fixed;
positive owned cleanup and all 55 raw pairs verify before primary diagnostic SQL.
The [integration checkpoint](assets/ligand-information/c2-prerequisite-integration-checkpoint.json)
binds the 25,304,524-byte, 414-payload portable packet. All original attempts remain,
including the initial missing nested pnpm launcher and corrected direct invocation.
The package verifies 59 ZIP CRCs, 633 manifest entries and 214 project files.
This is scoped checkpoint evidence, not final feature qualification.

Current acceptance testing passes the new coordinate/movement/archive flow. Its
first run stops at an overstrict minimization DTO comparison; the corrected test
separately validates actual operational job records and passes real minimization.
The targeted rerun then exposes a cached-project return gap before releasing the
held old READY response. An actual edit while away advances the artifact, but
fresh cached A skips its project read. The property producer safely rejects the
old artifact. A bounded App query correction now revalidates on project return
and preserves higher cached revisions at the synchronous query-cache write.
The final correction passes 60 focused App cases, web lint, type checks and
production build. The controlled final-write race fails the earlier query-function
check and passes the cache-boundary guard. Actual native requalification remains
required and separate from complete feature acceptance.

A later complete 36-case sidebar campaign stops after 23 passes when the modal
helper cannot route Escape from body focus; 12 cases remain unrun. A focused
functional pass separately records that both pointer and ordinary keyboard
movement activation lose launcher focus before helper intervention. The bounded
product correction keeps this unavailable launcher focusable with guarded
aria-disabled behavior and a scoped visual state. The actual TransformPanel,
real movement hook and modal regressions pass held loading/active, repeated
activation, busy refusal and the original Escape priorities. Current focused
verification passes 49 cases in six files, web lint and types. Production build
passes on identical production/style bodies; its subsequent test-only synchronous
act correction is covered by the final focused/type/lint checks. Browser focus
before helper intervention and the complete sidebar rerun remain required.

## Known limitations

No current #161 readiness, implementation push, PR, release or closeout is claimed.
Actual released #160 history, v0.39.0 preparation, current measured bounds,
preceding-reader/archive qualification, all seven final same-candidate assessments
and complete candidate/exact-merged gates remain outstanding. Remaining sidebar
acceptance requires the complete current coordinate/movement/minimization preview,
archive reconstruction and held project A→B→A campaign after the return correction. #153 diagram delivery and all other
parent exclusions remain outside scope.

## Blockers

No external blocker. Respect serial release order and preserve prior evidence.

## Next action

Verify native movement activation focus before helper intervention and rerun the
complete sidebar acceptance. Finish #160 delivery, integrate its actual released commit,
then qualify #161 and continue #162/#163 through verified parent closeout under
the same active Goal.
