:root {
  --font-ui: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  --font-editorial: Georgia, "Times New Roman", serif;
  --font-data: ui-monospace, SFMono-Regular, Menlo, monospace;
  --text-tiny: 10px;
  --text-xs: 11px;
  --text-sm: 12px;
  --text-md: 13px;
  --text-lg: 14px;
  --text-title: 16px;
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-5: 24px;
  --space-6: 32px;
  --radius-sm: 4px;
  --radius-md: 6px;
  font-family: var(--font-ui);
  font-synthesis: none;
}

* {
  box-sizing: border-box;
}

html,
body,
#root {
  width: 100%;
  height: 100%;
  margin: 0;
  overflow: hidden;
}

body {
  background: var(--bg);
  color: var(--text);
}

button,
input,
textarea,
select {
  font: inherit;
  letter-spacing: 0;
}

button {
  color: inherit;
}

button:focus-visible,
input:focus-visible,
textarea:focus-visible,
select:focus-visible,
[data-radix-menu-content]:focus-visible {
  outline: 2px solid var(--focus);
  outline-offset: 2px;
}

[role="tabpanel"]:focus-visible,
[role="region"][tabindex="0"]:focus-visible {
  outline: 2px solid var(--focus);
  outline-offset: -2px;
}

.app-shell {
  display: grid;
  grid-template-rows: 52px minmax(0, 1fr);
  width: 100%;
  height: 100%;
  background: var(--bg);
}

.topbar {
  z-index: 20;
  display: flex;
  align-items: center;
  min-width: 0;
  height: 52px;
  padding: 0 10px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
}

.brand {
  display: flex;
  align-items: center;
  gap: 9px;
  height: 40px;
  padding: 0 11px 0 4px;
  background: transparent;
  border: 0;
  cursor: pointer;
}

.brand-art {
  display: inline-block;
  flex: 0 0 auto;
  line-height: 0;
}

.brand-art img {
  display: block;
  width: 100%;
  height: 100%;
}

.brand-art .brand-art-dark,
:root[data-theme="dark"] .brand-art .brand-art-light {
  display: none;
}

:root[data-theme="dark"] .brand-art .brand-art-dark {
  display: block;
}

.brand-art-lockup {
  width: 113px;
  aspect-ratio: 402 / 114;
}

.brand-art-icon {
  width: 32px;
  height: 32px;
}

.brand-compact {
  display: none;
}

.project-switcher {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  min-width: 0;
  max-width: min(380px, 38vw);
  height: 34px;
  margin-left: 5px;
  padding: 0 12px;
  overflow: hidden;
  background: var(--surface-muted);
  border: 1px solid transparent;
  border-radius: var(--radius-md);
  cursor: pointer;
}

.project-switcher:hover {
  border-color: var(--border-strong);
}

.project-switcher-label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--text-md);
  font-weight: 650;
}

.dirty-indicator,
.entry-dirty {
  flex: 0 0 auto;
  width: 7px;
  height: 7px;
  background: var(--dirty);
  border-radius: 50%;
}

.topbar-actions {
  display: flex;
  align-items: center;
  gap: 3px;
  margin-left: auto;
}

.toolbar-separator {
  width: 1px;
  height: 22px;
  margin: 0 5px;
  background: var(--border);
}

.icon-button {
  display: inline-grid;
  flex: 0 0 auto;
  place-items: center;
  width: 32px;
  height: 32px;
  padding: 0;
  background: transparent;
  border: 0;
  border-radius: var(--radius-sm);
  cursor: pointer;
}

.icon-button:hover:not(:disabled) {
  background: var(--surface-hover);
}

.icon-button:disabled {
  opacity: 0.35;
  cursor: default;
}

.workspace-root {
  position: relative;
  min-width: 0;
  min-height: 0;
}

.horizontal-panels,
.vertical-panels {
  height: 100%;
}

.panel-content {
  width: 100%;
  height: 100%;
  overflow: hidden;
  background: var(--surface);
}

.panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 58px;
  padding: 9px 10px 8px 14px;
  border-bottom: 1px solid var(--border);
}

.panel-header h2 {
  margin: 1px 0 0;
  font-size: var(--text-lg);
  font-weight: 720;
}

.panel-eyebrow {
  color: var(--text-soft);
  font-size: var(--text-xs);
  font-weight: 700;
  text-transform: uppercase;
}

.panel-scroll {
  height: calc(100% - 58px);
  padding: 8px;
  overflow: auto;
}

.resize-handle {
  position: relative;
  z-index: 8;
  flex: 0 0 5px;
  background: var(--border);
  transition: background 120ms ease;
}

.resize-handle:hover,
.resize-handle[data-resize-handle-active] {
  background: var(--accent);
}

.resize-handle.horizontal {
  width: 5px;
}

.resize-handle.vertical {
  height: 5px;
}

.collapsed-rail {
  display: flex;
  justify-content: center;
  width: 100%;
  height: 100%;
  padding-top: 10px;
  background: var(--surface);
}

.workspace-canvas {
  position: relative;
  display: grid;
  place-items: center;
  width: 100%;
  height: 100%;
  min-height: 0;
  overflow: hidden;
  background: var(--bg);
}

.canvas-grid {
  position: absolute;
  inset: 0;
  opacity: 0.32;
  background-image:
    linear-gradient(var(--border) 1px, transparent 1px),
    linear-gradient(90deg, var(--border) 1px, transparent 1px);
  background-size: 32px 32px;
  mask-image: radial-gradient(circle at center, black, transparent 78%);
  pointer-events: none;
}

.canvas-empty,
.project-stage {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  flex-direction: column;
  text-align: center;
}

.welcome-brand {
  width: min(220px, 58vw);
  margin: 56px;
}

.workspace-tagline {
  margin: 0 20px 26px;
  color: var(--text);
  font-family: var(--font-editorial);
  font-size: clamp(22px, 3vw, 30px);
  line-height: 1.25;
}

.workspace-loading {
  display: grid;
  justify-items: center;
  gap: var(--space-4);
  color: var(--text-soft);
  font-size: var(--text-md);
}

.canvas-empty h1,
.project-stage h1 {
  max-width: min(560px, 75vw);
  margin: 0 0 16px;
  overflow-wrap: anywhere;
  font-size: 25px;
  font-weight: 720;
}

.project-stage h1 {
  margin-bottom: 3px;
}

.project-stage p {
  margin: 0 0 19px;
  color: var(--text-soft);
  font-size: var(--text-md);
}

.stage-brand {
  width: 40px;
  aspect-ratio: 100 / 114;
  margin: 46px;
}

.checkpoint-state {
  padding: 5px 9px;
  color: var(--text-soft);
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  font-size: var(--text-sm);
  font-weight: 650;
}

.checkpoint-state.dirty {
  color: var(--brand-strong);
  background: var(--accent-soft);
  border-color: var(--accent);
}

.stage-import {
  margin-top: 14px;
}

.structure-viewer {
  position: relative;
  container-type: size;
  z-index: 1;
  width: 100%;
  height: 100%;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: var(--viewer-background);
}

.molstar-host,
.molstar-host > .msp-plugin {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}

.movement-pointer-surface {
  position: absolute;
  inset: 0;
  z-index: 2;
  touch-action: none;
  cursor: grab;
}
.molstar-host { z-index: 0; }
.movement-translate { cursor: move; }
.movement-depth { cursor: ns-resize; }
.movement-camera { pointer-events: none; }
.movement-pointer-surface:focus-visible { outline: 2px solid var(--accent); outline-offset: -3px; }
.viewer-header {
  position: absolute;
  z-index: 8;
  top: 10px;
  left: 10px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 6px;
  width: min(620px, calc(100% - 62px));
  max-height: calc(100% - 20px);
  pointer-events: none;
}
.viewer-header > * { pointer-events: auto; max-width: 100%; flex-shrink: 0; }
.viewer-header .viewer-status { position: static; flex-wrap: wrap; pointer-events: none; }
.viewer-header .viewer-toolbar { position: static; max-width: 100%; }
.molecular-edit-tools { position: relative; }
.viewer-edit-transform-actions { display: flex; flex-wrap: wrap; align-items: flex-start; gap: 6px; max-width: 100%; }
.viewer-edit-transform-actions[data-transform-active="false"] {
  align-items: center; gap: 3px; padding: 3px; width: fit-content;
  border: 1px solid var(--border); border-radius: var(--radius-md);
  background: var(--surface); box-shadow: var(--shadow-small);
}
.viewer-edit-transform-actions .transform-launcher {
  padding: 0; border: 0; border-radius: 0; background: transparent; box-shadow: none;
}
.viewer-edit-transform-actions .viewer-modeling-action {
  display: grid; place-items: center; flex-shrink: 0; padding: 0;
  width: 32px; height: 32px; min-width: 32px; min-height: 32px;
  border: 0; border-radius: 6px; background: transparent; color: var(--text);
}
.viewer-edit-transform-actions .viewer-modeling-action:is(:hover, [aria-expanded="true"]):not([aria-disabled="true"]):not(:disabled) {
  background: var(--accent-soft); color: var(--accent-strong);
}
.viewer-edit-transform-actions .viewer-modeling-action:is([aria-disabled="true"], :disabled) { opacity: .6; cursor: not-allowed; }
.viewer-edit-transform-actions .viewer-modeling-action:focus-visible { outline: 2px solid var(--focus); outline-offset: 2px; }
@media (any-pointer: coarse), (max-width: 840px) {
  .viewer-edit-transform-actions .viewer-modeling-action { width: 44px; height: 44px; min-width: 44px; min-height: 44px; }
}

.molecular-edit-panel {
  position: fixed; z-index: 40; top: 100px; left: 8px;
  width: min(300px, calc(100vw - 84px)); max-height: min(65vh, 520px);
  overflow: auto; overscroll-behavior: contain; scroll-padding-top: 64px; padding: 10px;
  border: 1px solid var(--border); border-radius: 10px;
  background: var(--surface); color: var(--text); box-shadow: var(--shadow);
  pointer-events: auto; font-size: 12px; container-type: inline-size;
}
.molecular-edit-panel fieldset { border: 0; padding: 0; margin: 8px 0; min-width: 0; }
.molecular-edit-panel button { min-height: 32px; border: 1px solid var(--border); border-radius: 6px; background: var(--surface); color: var(--text); padding: 5px 8px; }
.molecular-edit-panel button:disabled { opacity: .55; }
.molecular-edit-panel button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.molecular-edit-panel .dialog-heading { display: flex; justify-content: space-between; align-items: center; }
.molecular-edit-panel .dialog-heading { position: sticky; top: -10px; background: var(--surface); z-index: 1; padding: 4px 0; }
.molecular-edit-panel.is-inspecting { padding: 6px; overflow: auto; }
.edit-placement-inspection { display: flex; align-items: center; flex-wrap: wrap; gap: 4px; }
.edit-placement-inspection > :is(.edit-preview-status, .edit-preview-error, .edit-attempt-status, .edit-rotation-scope) { flex-basis: 100%; margin: 2px 0; }
.edit-preview-status, .edit-preview-error { overflow-wrap: anywhere; }
.edit-rotation-scope p { margin: 2px 0; overflow-wrap: anywhere; }
.edit-preview-status { font-weight: 600; }
.edit-preview-error, .edit-attempt-status[data-phase="unknown"] { color: var(--danger); }
.edit-target > span { display: block; margin-top: 3px; color: var(--text-soft); }
.edit-geometry { margin: 8px 0; }
.edit-geometry summary { display: flex; align-items: center; gap: 5px; }
.edit-geometry-actions { display: grid; gap: 5px; }
.edit-prerequisite { color: var(--text-soft); margin: 6px 0; line-height: 1.4; }
.edit-attempt-status { overflow-wrap: anywhere; margin: 6px 0; }
.edit-attempt-status p { margin: 4px 0; }
.edit-attempt-status p:first-child { display: flex; align-items: center; flex-wrap: wrap; gap: 3px; }
.molecular-edit-panel .selection-hydrogens .icon-button { display: inline-flex; align-items: center; justify-content: center; flex: none; width: 44px; height: 44px; min-width: 44px; min-height: 44px; padding: 5px; }
.edit-progress-icon { animation: edit-progress 1.1s linear infinite; }
@keyframes edit-progress { to { transform: rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { .edit-progress-icon { animation: none; } }
.molecular-edit-panel .edit-placement-inspection button { min-width: 44px; min-height: 44px; padding: 4px 6px; }
.molecular-edit-panel .modeling-check, .new-molecule-form .modeling-check { display: flex; align-items: center; gap: 6px; min-height: 44px; }
.molecular-edit-panel .modeling-check input, .new-molecule-form .modeling-check input { width: 18px; height: 18px; min-height: 18px; padding: 0; margin: 0; flex: none; }
.edit-target, .edit-scientific-note { overflow-wrap: anywhere; margin: 8px 0; }
.edit-scientific-note { color: var(--text-soft); line-height: 1.5; }
.molecular-edit-panel summary { cursor: pointer; padding: 6px 0; min-height: 32px; }
.molecular-edit-panel summary:focus-visible { outline: 2px solid var(--focus); outline-offset: 2px; }
.edit-element-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; margin: 6px 0; }
@container (max-width: 190px) { .edit-element-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
.edit-element-grid button { font-size: 16px; font-weight: 600; }
.edit-sections { display: flex; flex-wrap: wrap; gap: 4px; }
.edit-sections [aria-pressed="true"] { border-color: var(--accent); background: var(--accent-soft); }
.edit-fragment-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; }
.edit-fragment-grid button { display: flex; flex-direction: column; align-items: center; overflow-wrap: anywhere; }
.edit-fragment-grid svg { max-width: 100%; }
.molecular-edit-panel .edit-compact-actions { flex-wrap: wrap; }
.edit-compact-actions { display: flex; gap: 5px; margin: 6px 0; }
.edit-bond-order { display: block; margin: 8px 0; }
.molecular-edit-panel .edit-compact-actions .icon-button { min-width: 44px; min-height: 44px; justify-content: center; }
.edit-compact-actions button { display: inline-flex; align-items: center; gap: 3px; }
@media (pointer: coarse) {
  .molecular-edit-panel button { min-height: 44px; min-width: 44px; }
  .molecular-edit-panel :is(input:not([type="checkbox"]), select) { min-height: 44px; min-width: 0; max-width: 100%; }
}
@media (any-pointer: coarse), (max-width: 840px) { .molecular-edit-panel summary { min-height: 44px; } }
.viewer-header .viewer-error { position: static; align-self: stretch; width: 100%; min-width: 0; transform: none; overflow-wrap: anywhere; }
.transform-launcher, .movement-banner {
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  background: var(--surface);
  color: var(--text);
  box-shadow: var(--shadow-small);
  font-size: var(--text-xs);
}
.transform-launcher, .movement-banner { padding: 3px; width: fit-content; }
.movement-banner { min-width: 0; max-width: 100%; }
.movement-actions { display: flex; align-items: center; gap: 3px; }
.movement-action.icon-button { width: 32px; height: 32px; min-width: 32px; min-height: 32px; flex-shrink: 0; }
.movement-action[aria-disabled="true"] { opacity: 0.6; cursor: not-allowed; }
.movement-action-active, .movement-action[aria-expanded="true"] { background: var(--accent-soft); color: var(--accent-strong); }
.movement-help-action { color: var(--warning); }
.movement-apply { color: var(--accent-strong); }
.movement-count { padding: 0 6px; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-variant-numeric: tabular-nums; }
.movement-warning { color: var(--text); font-weight: 600; }
.movement-banner > .movement-warning { margin: 6px; max-width: 300px; }
.movement-spinner { animation: movement-spin 1s linear infinite; }
@keyframes movement-spin { to { transform: rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { .movement-spinner { animation: none; } }
.movement-panel.dialog-content {
  --movement-panel-top: 120px; --movement-panel-left: 10px;
  z-index: 40; top: var(--movement-panel-top, 120px); left: var(--movement-panel-left, 10px);
  width: min(320px, calc(100vw - 16px)); max-height: calc(100dvh - var(--movement-panel-top, 120px) - 8px);
  transform: none; animation: fade-in 120ms ease-out; display: flex; flex-direction: column; overflow: hidden;
}
.movement-panel .dialog-heading { padding: 6px 8px; align-items: center; flex-shrink: 0; }
.movement-panel .dialog-heading h2 { font-size: 14px; }
.movement-panel-body { padding: 0 10px 10px; min-height: 0; overflow: auto; }
.movement-panel p { margin: 8px 0; line-height: 1.4; font-size: var(--text-xs); }
.movement-panel fieldset { margin: 4px 0; padding: 0; border: 0; min-width: 0; }
.movement-panel legend { margin-bottom: 6px; font-weight: 600; font-size: var(--text-xs); }
.movement-panel .segmented-control { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.movement-panel .segmented-control button { min-height: 44px; }
.movement-sensitivity { display: flex; align-items: center; gap: 8px; margin: 8px 0; font-size: var(--text-xs); }
.movement-sensitivity input { min-width: 0; flex: 1; min-height: 44px; }
.movement-step-controls { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; }
.movement-step-controls button { min-height: 44px; border: 1px solid var(--border); border-radius: 5px; background: var(--surface); color: var(--text); }
@media (any-pointer: coarse), (max-width: 840px) { .movement-action.icon-button { width: 44px; height: 44px; min-width: 44px; min-height: 44px; } }
@media (max-width: 520px) { .movement-count { display: none; } }
.numerical-transform-controls { display: contents; }
.measurement-preview-notice { position: absolute; z-index: 3; right: 12px; bottom: 40px; background: var(--surface); color: var(--text); padding: 6px; border-radius: 6px; font-size: 12px; }

.molstar-host .msp-plugin,
.molstar-host .msp-viewport {
  background: transparent;
}


progress,
input[type="range"],
input[type="checkbox"],
input[type="radio"] {
  accent-color: var(--action);
}

.viewer-status {
  position: absolute;
  z-index: 5;
  top: 10px;
  left: 10px;
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 28px;
  padding: 0 9px;
  color: var(--text);
  background: color-mix(in srgb, var(--surface) 90%, transparent);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  box-shadow: var(--shadow-small);
  font-size: var(--text-xs);
  font-weight: 680;
  pointer-events: none;
}

.viewer-warning {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  color: var(--warning);
}

.viewer-warning-anchor { display: inline-flex; min-width: 0; }
.viewer-warning-anchor:empty { display: none; }
.viewer-warning-trigger {
  pointer-events: auto;
  min-height: 28px;
  padding: 3px 4px;
  margin: 0 -4px;
  font: inherit;
  background: transparent;
  border: 0;
  border-radius: var(--radius-sm);
  cursor: pointer;
}
.viewer-warning-trigger:hover,
.viewer-warning-trigger[data-state="open"] { background: var(--surface-muted); }
.viewer-warning-trigger:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.viewer-warning-details.dialog-content {
  --warning-details-left: 8px;
  --warning-details-top: 48px;
  position: fixed;
  left: var(--warning-details-left, 8px);
  top: var(--warning-details-top, 48px);
  width: min(400px, calc(100vw - 16px));
  max-height: min(420px, calc(100dvh - 16px));
  padding: 0;
  display: flex;
  flex-direction: column;
  transform: none;
  animation: none;
  overflow: hidden;
}
.viewer-warning-details .dialog-heading {
  flex: 0 0 auto;
  align-items: center;
  gap: 12px;
  margin: 0;
  padding: 9px 12px;
  border-bottom: 1px solid var(--border);
}
.viewer-warning-details .dialog-heading h2 { font-size: 14px; }
.viewer-warning-details-body { min-height: 0; overflow-y: auto; overscroll-behavior: contain; padding: 12px; }
.viewer-warning-group + .viewer-warning-group { margin-top: 16px; }
.viewer-warning-group h3 { margin: 0 0 8px; font-size: 13px; overflow-wrap: anywhere; }
.viewer-warning-group ul { display: grid; gap: 10px; margin: 0; padding: 0; list-style: none; }
.viewer-warning-group li { display: grid; gap: 3px; font-size: 13px; line-height: 1.5; }
.viewer-warning-severity { display: inline-flex; align-items: center; gap: 5px; font-size: 11px; font-weight: 650; }
.viewer-warning-severity.severity-info { color: var(--text-soft); }
.viewer-warning-severity.severity-warning { color: var(--warning); }
.viewer-warning-severity.severity-error { color: var(--danger); }
.viewer-warning-message { color: var(--text); overflow-wrap: anywhere; user-select: text; }
.viewer-warning-empty { margin: 0; color: var(--text-soft); font-size: 13px; line-height: 1.5; }
@media (any-pointer: coarse), (max-width: 840px) {
  .viewer-warning-trigger { min-height: 44px; min-width: 44px; }
  .viewer-warning-details .icon-button { min-height: 44px; min-width: 44px; }
}

.viewer-loading,
.viewer-empty,
.viewer-error {
  position: absolute;
  z-index: 6;
  top: 50%;
  left: 50%;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 10px 13px;
  color: var(--text-soft);
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow);
  transform: translate(-50%, -50%);
  font-size: var(--text-sm);
}

.viewer-loading svg {
  animation: spin 800ms linear infinite;
}

.viewer-error {
  flex-wrap: wrap;
  justify-content: center;
  width: min(360px, calc(100% - 30px));
  color: var(--danger);
  border-color: var(--danger);
}

.primary-button,
.secondary-button,
.danger-button,
.api-failure button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  min-height: 34px;
  padding: 0 13px;
  border-radius: var(--radius-sm);
  font-size: var(--text-md);
  font-weight: 680;
  cursor: pointer;
}

.primary-button {
  color: var(--on-action);
  background: var(--action);
  border: 1px solid var(--action);
}

.primary-button:hover:not(:disabled) {
  background: var(--action-hover);
}

.secondary-button {
  color: var(--text);
  background: var(--surface);
  border: 1px solid var(--border-strong);
}

.secondary-button:hover:not(:disabled) {
  background: var(--surface-hover);
}

.danger-button {
  color: var(--on-danger);
  background: var(--danger);
  border: 1px solid var(--danger);
}

.primary-button:disabled,
.secondary-button:disabled,
.danger-button:disabled {
  opacity: 0.45;
  cursor: default;
}

.empty-panel {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  min-height: 150px;
  color: var(--text-soft);
}

.empty-panel p,
.empty-label {
  margin: 8px 0;
  color: var(--text-soft);
  font-size: var(--text-sm);
}

.entry-group {
  min-height: 32px;
  margin-bottom: 10px;
}

.browser-controls {
  display: grid;
  gap: 6px;
  padding: 8px;
  border-bottom: 1px solid var(--border);
}

.browser-search {
  display: grid;
  grid-template-columns: 22px minmax(0, 1fr);
  align-items: center;
  height: 32px;
  padding-left: 7px;
  color: var(--text-soft);
  background: var(--bg);
  border: 1px solid var(--border-strong);
  border-radius: var(--radius-sm);
}

.browser-search input {
  height: 30px;
  padding-left: 2px;
  background: transparent;
  border: 0;
}

.browser-selects {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(110px, 1fr));
  gap: 6px;
}

.browser-selects select {
  height: 30px;
  font-size: var(--text-xs);
}

.browser-results {
  height: calc(100% - 152px);
}

.group-heading {
  display: flex;
  align-items: center;
  height: 26px;
  color: var(--text-soft);
  font-size: var(--text-sm);
  font-weight: 700;
  text-transform: uppercase;
}

.group-heading button {
  height: 26px;
  padding: 0;
  color: inherit;
  background: transparent;
  border: 0;
  cursor: pointer;
}

.group-toggle {
  display: grid;
  flex: 0 0 24px;
  place-items: center;
}

.group-select {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex: 1;
  min-width: 0;
  padding-right: 6px !important;
  text-align: left;
}

.group-heading small {
  font-size: var(--text-xs);
}

.entry-row {
  display: flex;
  align-items: center;
  min-height: 43px;
  margin-bottom: 2px;
  padding: 2px;
  border: 1px solid transparent;
  border-radius: var(--radius-sm);
}

.entry-row:hover {
  background: var(--surface-muted);
}

.entry-row.selected {
  background: var(--accent-soft);
  border-color: color-mix(in srgb, var(--accent) 70%, var(--border));
}

.entry-row .icon-button {
  width: 28px;
  height: 28px;
}

.entry-node {
  margin-bottom: 3px;
}

.entry-select {
  display: grid;
  grid-template-columns: 20px minmax(0, 1fr) 9px;
  align-items: center;
  flex: 1;
  align-self: stretch;
  min-width: 0;
  padding: 0 3px 0 5px;
  color: inherit;
  text-align: left;
  background: transparent;
  border: 0;
  cursor: pointer;
}

.entry-actions {
  display: flex;
  align-items: center;
}

.entry-hidden {
  color: var(--text-soft);
}

.entry-type-icon {
  color: var(--brand);
}

.entry-copy {
  min-width: 0;
}

.entry-copy span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.entry-copy span {
  font-size: var(--text-sm);
  font-weight: 650;
}



.inspector-form,
.dialog-form {
  display: flex;
  flex-direction: column;
  gap: 15px;
  padding: 16px;
}

.inspector-tabs {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(92px, 1fr));
  grid-auto-rows: minmax(32px, auto);
  flex-shrink: 0;
  border-bottom: 1px solid var(--border);
}

.inspector-tabs button {
  min-width: 0;
  padding: 0 4px;
  color: var(--text-soft);
  background: transparent;
  border: 0;
  border-bottom: 2px solid transparent;
  font-size: var(--text-xs);
  font-weight: 700;
  text-transform: capitalize;
  cursor: pointer;
}

.inspector-tabs button[aria-selected="true"] {
  color: var(--text);
  border-bottom-color: var(--accent);
}

.inspector-tabs button:focus-visible {
  outline-offset: -3px;
}

.selection-panel {
  padding: 10px;
}

.selection-summary {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  margin: 0;
  border: 1px solid var(--border);
}

.selection-summary div {
  min-width: 0;
  padding: 8px 5px;
  text-align: center;
  border-right: 1px solid var(--border);
}

.selection-summary div:last-child {
  border-right: 0;
}

.selection-summary dt {
  color: var(--text-soft);
  font-size: var(--text-tiny);
  text-transform: uppercase;
}

.selection-summary dd {
  margin: 3px 0 0;
  font-size: var(--text-md);
  font-weight: 750;
}

.selection-meta {
  display: flex;
  align-items: center;
  gap: 7px;
  min-height: 26px;
  color: var(--text-soft);
  font-size: var(--text-xs);
  text-transform: capitalize;
}

.selection-meta svg {
  margin-left: auto;
  animation: spin 800ms linear infinite;
}

.selection-toolbar {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 5px;
}

.selection-toolbar.three {
  grid-template-columns: repeat(3, 1fr);
}

.selection-toolbar button,
.segmented-control button {
  min-width: 0;
  height: 30px;
  padding: 0 5px;
  overflow: hidden;
  color: var(--text);
  background: var(--surface);
  border: 1px solid var(--border-strong);
  text-overflow: ellipsis;
  text-transform: capitalize;
  white-space: nowrap;
  font-size: var(--text-xs);
  font-weight: 650;
  cursor: pointer;
}

.selection-toolbar button:disabled {
  opacity: 0.4;
  cursor: default;
}

.selection-section {
  min-width: 0;
  margin: 12px 0 0;
  padding: 9px;
  border: 1px solid var(--border);
}

.selection-section legend {
  padding: 0 4px;
  color: var(--text-soft);
  font-size: var(--text-xs);
  font-weight: 700;
  text-transform: uppercase;
}

.segmented-control {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
}

.segmented-control.four {
  grid-template-columns: repeat(2, 1fr);
  gap: 1px;
}

.segmented-control.four button {
  border: 1px solid var(--border-strong);
}

.segmented-control button + button {
  border-left: 0;
}

.segmented-control button.active {
  color: var(--brand);
  background: var(--accent-soft);
  border-color: var(--accent);
}

.selection-form {
  display: grid;
  gap: 7px;
}

.selection-form label,
.save-selection > label {
  display: grid;
  gap: var(--space-1);
  color: var(--text-soft);
  font-size: var(--text-xs);
  font-weight: 650;
}

.selection-form input,
.selection-form select,
.save-selection input {
  height: 30px;
  font-size: var(--text-sm);
}

.selection-form .secondary-button {
  min-height: 30px;
  font-size: var(--text-xs);
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}

.input-with-button {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 30px;
}

.input-with-button input {
  border-radius: 4px 0 0 4px;
}

.icon-submit {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  padding: 0;
  color: var(--on-action);
  background: var(--action);
  border: 1px solid var(--action);
  border-radius: 0 4px 4px 0;
  cursor: pointer;
}

.icon-submit:disabled {
  opacity: 0.4;
  cursor: default;
}

.saved-selection-list {
  margin-top: 8px;
}

.saved-selection-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 24px 28px;
  align-items: center;
  min-height: 35px;
  border-top: 1px solid var(--border);
}

.saved-selection-row > button:first-child {
  min-width: 0;
  padding: 4px 2px;
  text-align: left;
  background: transparent;
  border: 0;
  cursor: pointer;
}

.saved-selection-row span,
.saved-selection-row small {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.saved-selection-row span {
  font-size: var(--text-xs);
  font-weight: 650;
}

.saved-selection-row small {
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.saved-warning {
  color: var(--warning);
}

.sequence-workspace { display: flex; flex-direction: column; width: 100%; height: 100%; min-width: 0; min-height: 0; }
.sequence-workspace > .structure-viewer { flex: 1 1 0; }
.sequence-viewer { flex: 0 1 auto; display: flex; flex-direction: column; min-width: 0; min-height: 32px; max-height: 33.3333%; border-top: 1px solid var(--border); background: var(--surface); }
.sequence-header { display: flex; align-items: center; flex: 0 0 32px; gap: 6px; min-width: 0; padding: 0 4px; }
.sequence-header .icon-button { width: 32px; height: 32px; flex: 0 0 32px; }
.sequence-heading { font-size: var(--text-xs); font-weight: 700; }
.sequence-header > small { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; color: var(--text-soft); font-size: var(--text-tiny); }
.sequence-header .icon-button:last-child { margin-left: auto; }
.sequence-content { display: flex; flex-direction: column; flex: 1 1 auto; min-height: 0; overflow: hidden; }
.sequence-content[hidden] { display: none; }
.sequence-chain-scroll { position: relative; overflow: auto; flex: 0 1 auto; min-height: 0; overscroll-behavior: contain; }
.sequence-chain-window, .sequence-residues { position: relative; min-width: 0; }
.sequence-chain-item { position: absolute; top: 0; left: 0; width: 100%; }
.sequence-chain-row { display: flex; height: 100%; min-width: 0; border-bottom: 1px solid var(--border); }
.sequence-chain-name { display: flex; flex-direction: column; justify-content: center; flex: 0 0 110px; max-width: 35%; padding: 0 8px; min-width: 0; border-right: 1px solid var(--border); }
.sequence-chain-name > * { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: var(--text-xs); }
.sequence-chain-name small { color: var(--text-soft); font-size: var(--text-tiny); }
.sequence-residue-scroll { flex: 1 1 auto; min-width: 0; overflow-x: auto; overflow-y: hidden; overscroll-behavior-x: contain; }
.sequence-residues { height: 34px; margin: 1px 0; }
.sequence-residue-item { position: absolute; top: 0; left: 0; height: 100%; padding: 0 2px; }
.sequence-residue { display: flex; flex-direction: column; align-items: center; justify-content: center; width: 100%; height: 100%; min-height: 32px; padding: 1px 2px; color: var(--text); background: var(--surface-muted); border: 1px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; }
.sequence-residue > * { max-width: 100%; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.sequence-residue span { font-size: var(--text-xs); font-weight: 750; }
.sequence-residue small { color: var(--text-soft); font-size: var(--text-tiny); }
.sequence-residue:hover { border-color: var(--accent); }
.sequence-residue[aria-pressed="true"], .sequence-residue[aria-pressed="mixed"] { color: var(--brand-strong); background: var(--accent-soft); border-color: var(--accent); }
.sequence-residue[aria-pressed="mixed"] { border-width: 2px; border-style: dashed; }
.sequence-residue[aria-disabled="true"] { opacity: .6; cursor: default; }
.sequence-residue:focus-visible { outline: 2px solid var(--focus); outline-offset: -2px; }
@media (any-pointer: coarse), (max-width: 840px) {
  .sequence-viewer { min-height: 44px; }
  .sequence-header { flex-basis: 44px; }
  .sequence-header .icon-button { width: 44px; height: 44px; flex-basis: 44px; }
  .sequence-chain-name { flex-basis: 94px; padding: 0 5px; }
  .sequence-residues { height: 46px; }
  .sequence-residue { min-height: 44px; }
}

.inspector-form label,
.dialog-form label {
  display: flex;
  flex-direction: column;
  gap: 6px;
  color: var(--text-soft);
  font-size: var(--text-sm);
  font-weight: 680;
}

input,
textarea,
select {
  width: 100%;
  color: var(--text);
  background: var(--bg);
  border: 1px solid var(--border-strong);
  border-radius: var(--radius-sm);
}

input {
  height: 34px;
  padding: 0 9px;
}

textarea {
  padding: 8px 9px;
  resize: vertical;
}

select {
  height: 34px;
  padding: 0 28px 0 9px;
}

.project-facts {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  margin: 4px 0;
  border: 1px solid var(--border);
}

.project-facts div {
  min-width: 0;
  padding: 9px;
  border-right: 1px solid var(--border);
}

.project-facts div:last-child {
  border-right: 0;
}

.project-facts dt {
  color: var(--text-soft);
  font-size: var(--text-xs);
  text-transform: uppercase;
}

.project-facts dd {
  margin: 4px 0 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: var(--text-md);
  font-weight: 720;
}

.compact-header {
  min-height: 38px;
  padding: 3px 8px 3px 13px;
}

.history-title {
  display: flex;
  align-items: center;
  gap: 7px;
}

.history-title h2 {
  margin: 0;
}

.history-content {
  display: grid;
  grid-template-columns: repeat(2, minmax(90px, 135px)) repeat(2, minmax(150px, 1fr)) auto;
  align-items: stretch;
  gap: 1px;
  height: calc(100% - 38px);
  padding: 8px;
  overflow: auto;
  background: var(--border);
}

.history-stat,
.history-capacity {
  display: flex;
  justify-content: center;
  flex-direction: column;
  min-width: 0;
  padding: 9px 11px;
  background: var(--surface);
}

.history-stat span {
  color: var(--text-soft);
  font-size: var(--text-xs);
  text-transform: uppercase;
}

.history-stat strong {
  margin-top: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--text-sm);
}

.history-capacity {
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.collapsed-history {
  display: flex;
  align-items: center;
  gap: 7px;
  height: 100%;
  padding: 0 8px 0 13px;
  background: var(--surface);
  font-size: var(--text-sm);
  font-weight: 700;
}

.collapsed-history .icon-button {
  margin-left: auto;
  transform: rotate(90deg);
}

.notice {
  --notice-top: 60px;
  position: fixed;
  z-index: 45;
  top: var(--notice-top);
  left: 50%;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  grid-template-rows: minmax(0, 1fr);
  align-items: start;
  gap: var(--space-4);
  width: max-content;
  max-width: min(560px, calc(100vw - 24px));
  max-height: min(240px, calc(100dvh - var(--notice-top) - 12px));
  min-height: 38px;
  padding: 7px 9px 7px 13px;
  background: var(--surface);
  border: 1px solid var(--border-strong);
  border-left: 3px solid var(--accent);
  border-radius: var(--radius-sm);
  box-shadow: var(--shadow);
  transform: translateX(-50%);
  font-size: var(--text-sm);
  pointer-events: none;
}

.notice-message {
  align-self: stretch;
  min-width: 0;
  min-height: 0;
  overflow: auto;
  overflow-wrap: anywhere;
  white-space: pre-wrap;
  overscroll-behavior: contain;
  pointer-events: none;
}

.notice-message.is-scrollable {
  pointer-events: auto;
}

.notice.error {
  border-left-color: var(--danger);
}

.notice.success {
  border-left-color: var(--success);
}

.notice button {
  padding: 5px 7px;
  color: var(--text-soft);
  background: transparent;
  border: 0;
  cursor: pointer;
  pointer-events: auto;
}

@media (any-pointer: coarse), (max-width: 840px) {
  .notice button {
    min-width: 44px;
    min-height: 44px;
  }
}

@media (max-height: 360px) {
  .notice { --notice-top: 8px; }
}

.api-failure {
  position: fixed;
  z-index: 44;
  right: 12px;
  bottom: 12px;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 3px 14px;
  max-width: 420px;
  padding: 12px;
  background: var(--danger-soft);
  border: 1px solid var(--danger);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow);
}

.api-failure strong,
.api-failure span {
  grid-column: 1;
}

.api-failure strong {
  font-size: var(--text-sm);
}

.api-failure span {
  color: var(--text-soft);
  font-size: var(--text-sm);
}

.api-failure button {
  grid-row: 1 / span 2;
  grid-column: 2;
  background: var(--surface);
  border: 1px solid var(--border-strong);
}

.dialog-overlay {
  position: fixed;
  z-index: 90;
  inset: 0;
  background: var(--overlay);
  animation: fade-in 120ms ease-out;
}

.dialog-content {
  position: fixed;
  z-index: 91;
  top: 50%;
  left: 50%;
  width: min(460px, calc(100vw - 24px));
  max-height: min(680px, calc(100vh - 40px));
  overflow: auto;
  background: var(--surface);
  border: 1px solid var(--border-strong);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow);
  transform: translate(-50%, -50%);
  animation: dialog-in 140ms ease-out;
}

.dialog-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  padding: 15px 13px 12px 17px;
  border-bottom: 1px solid var(--border);
}

.dialog-heading h2 {
  margin: 0;
  font-size: var(--text-title);
}

.dialog-heading p {
  margin: 4px 0 0;
  color: var(--text-soft);
  font-size: var(--text-sm);
}

.dialog-actions {
  display: flex;
  justify-content: flex-end;
  gap: var(--space-2);
  margin-top: 4px;
}

.import-dialog,
.export-dialog {
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 16px;
}

/* Selection styling: primary choices first, help on demand. */
.selection-style-dialog { display: flex; flex-direction: column; gap: 4px; padding: 10px; }
.selection-palette .dialog-heading { position: sticky; top: 0; z-index: 1; background: var(--surface); align-items: center; padding: 8px 10px; }
.selection-palette .dialog-heading > div { display: flex; align-items: baseline; gap: 8px; }
.selection-palette .dialog-heading h2 { font-size: 14px; }
.selection-style-summary { color: var(--text-soft); font-size: 12px; }
.selection-style-group .selection-section-heading { align-items: flex-start; margin-bottom: 4px; }
.selection-channel-summary { min-width: 0; font-weight: 400; overflow-wrap: anywhere; color: var(--text-soft); font-size: 12px; }
.selection-style-group .selection-channel-legend { width: 100%; }
.selection-channel-heading { display: flex; align-items: center; gap: 8px; }
.selection-channel-heading > span:first-child { flex-shrink: 0; }
.selection-channel-heading .selection-channel-summary { flex: 1; font-size: 11px; }
.selection-style-group .selection-reset { flex-shrink: 0; }
.selection-residue-recovery { margin-top: 6px; }
.selection-residue-recovery p { margin: 4px 0; }
.selection-section-heading { display: flex; align-items: center; justify-content: space-between; gap: 8px; font-size: 12px; font-weight: 700; }
.selection-style-group { min-width: 0; margin: 0; padding: 0; border: 0; }
.selection-style-group legend { padding: 0; margin-bottom: 4px; color: var(--text-soft); font-size: 12px; }
.selection-style-grid { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 4px; }
.selection-style-grid.polymer { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.selection-style-option { position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 3px; min-width: 0; min-height: 64px; padding: 4px 2px; color: var(--text); background: var(--surface); border: 1px solid var(--border-strong); border-radius: var(--radius-sm); font-size: 11px; font-weight: 650; cursor: pointer; }
.selection-style-grid.polymer .selection-style-option { flex-direction: row; min-height: 36px; gap: 8px; }
.representation-glyph { width: 38px; height: 25px; flex-shrink: 0; }
.selection-style-option[aria-pressed="true"], .selection-color-mode button[aria-pressed="true"] { color: var(--accent-strong); background: var(--accent-soft); border-color: var(--accent); }
.selection-style-option[aria-pressed="mixed"], .selection-style-option[data-mixed="true"] { border-style: dashed; }
.selection-mixed-mark { position: absolute; top: 0; right: 3px; font-size: 15px; }
.selection-palette button:disabled, .selection-palette select:disabled { opacity: 0.48; cursor: default; }
.selection-reset { display: inline-flex; align-items: center; justify-content: center; gap: 4px; min-height: 24px; padding: 2px 4px; border: 0; border-radius: var(--radius-sm); color: var(--text-soft); background: transparent; font-size: 12px; cursor: pointer; }
.selection-style-help, .selection-help p, .selection-feedback p { margin: 4px 0 0; font-size: 12px; line-height: 1.4; color: var(--text-soft); }
.selection-help summary, .selection-disclosure summary { width: fit-content; min-height: 24px; padding: 3px 0; font-size: 12px; cursor: pointer; color: var(--text-soft); }
.selection-disclosure { border-top: 1px solid var(--border); padding-top: 4px; }
.selection-disclosure > summary { font-weight: 650; color: var(--text); }
.selection-colors { border-top: 1px solid var(--border); padding-top: 4px; }
.selection-color-mode { display: flex; gap: 4px; margin: 4px 0; }
.selection-color-mode button { flex: 1; min-height: 28px; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); color: var(--text); background: var(--surface); font-size: 12px; cursor: pointer; }
.selection-swatches { display: grid; grid-template-columns: repeat(8, minmax(0, 1fr)); gap: 3px; }
.selection-swatches button { display: grid; place-items: center; padding: 3px; min-height: 30px; background: transparent; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); cursor: pointer; }
.selection-swatches button span { width: 100%; height: 20px; border-radius: 2px; box-shadow: inset 0 0 0 1px #0003; }
.selection-custom-color { display: flex; align-items: end; gap: 8px; padding: 4px 0; }
.selection-custom-color label { display: flex; flex: 1; flex-direction: column; gap: 4px; font-size: 12px; }
.selection-custom-color input { width: 100%; height: 34px; }
.selection-hydrogens { padding: 4px 0; }
.selection-hydrogen-row { display: flex; align-items: center; gap: 6px; min-width: 0; font-size: 12px; }
.selection-hydrogen-label { font-weight: 650; margin-right: 2px; }
.selection-hydrogen-toggle.icon-button { position: relative; width: 36px; height: 32px; min-width: 36px; border: 1px solid var(--border-strong); background: var(--surface); }
.selection-hydrogen-toggle[aria-pressed="true"] { color: var(--accent-strong); border-color: var(--accent); background: var(--accent-soft); }
.selection-hydrogen-toggle[aria-pressed="mixed"] { border-style: dashed; }
.selection-hydrogen-state { position: absolute; right: 1px; bottom: 1px; font-size: 12px; line-height: 10px; }
.selection-hydrogen-reset.icon-button { color: var(--text-soft); width: 28px; min-width: 28px; height: 28px; }
.selection-hydrogens button[aria-disabled="true"] { opacity: 0.48; cursor: default; }
@media (any-pointer: coarse), (max-width: 840px) {
  .selection-hydrogens .icon-button { min-height: 44px; min-width: 44px; height: 44px; }
}
.selection-feedback { min-height: 0; }
.selection-feedback [role="alert"], .selection-palette [role="alert"] { color: var(--danger); font-size: 12px; }
.selection-palette :is(button, select, input, summary):focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
@media (pointer: coarse) {
  .selection-palette :is(button, select, input, summary) { min-height: 44px; min-width: 44px; }
  .selection-palette .selection-style-grid .selection-style-option { min-height: 44px; }
  .selection-swatches { grid-template-columns: repeat(4, minmax(0, 1fr)); }
}

.file-picker {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 7px;
  min-height: 92px;
  color: var(--brand);
  background: var(--bg);
  border: 1px dashed var(--border-strong);
  border-radius: var(--radius-md);
  font-size: var(--text-sm);
  font-weight: 680;
  cursor: pointer;
}

.file-picker:hover {
  background: var(--surface-muted);
  border-color: var(--brand);
}

.file-picker:focus-within {
  outline: 2px solid var(--focus);
  outline-offset: 2px;
}

.file-picker input {
  position: absolute;
  width: 1px;
  height: 1px;
  opacity: 0;
}

.selected-files {
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
}

.selected-files > div {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto 28px;
  align-items: center;
  min-height: 34px;
  padding-left: 9px;
  border-bottom: 1px solid var(--border);
}

.selected-files > div span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--text-sm);
  font-weight: 650;
}

.selected-files > div small,
.selected-files > p {
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.selected-files > div button {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  padding: 0;
  background: transparent;
  border: 0;
  cursor: pointer;
}

.selected-files > p {
  margin: 0;
  padding: 7px 9px;
  text-align: right;
}

.import-options {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--space-2);
}

.import-options label,
.acknowledge-losses {
  display: flex;
  align-items: flex-start;
  gap: var(--space-2);
  min-width: 0;
  padding: 9px;
  background: var(--surface-muted);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  cursor: pointer;
}

.import-options input,
.acknowledge-losses input {
  flex: 0 0 auto;
  width: 15px;
  height: 15px;
  margin: 1px 0 0;
}

.import-options span,
.acknowledge-losses span {
  color: var(--text);
  font-size: var(--text-sm);
  font-weight: 650;
}

.import-options small {
  display: block;
  margin-top: 3px;
  color: var(--text-soft);
  font-size: var(--text-xs);
  font-weight: 450;
}

.import-progress {
  padding: 10px;
  background: var(--surface-muted);
  border-radius: var(--radius-sm);
}

.import-progress > div {
  display: flex;
  justify-content: space-between;
  margin-bottom: 7px;
  font-size: var(--text-xs);
}

.import-progress progress {
  width: 100%;
  height: 7px;
  accent-color: var(--brand);
}

.import-progress small {
  display: block;
  margin-top: 7px;
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.dialog-error {
  display: flex;
  align-items: flex-start;
  gap: var(--space-2);
  padding: 9px;
  color: var(--danger);
  background: var(--danger-soft);
  border: 1px solid var(--danger);
  border-radius: var(--radius-sm);
  font-size: var(--text-sm);
}

.warning-list {
  max-height: 150px;
  overflow: auto;
  border: 1px solid var(--warning-border);
  border-radius: var(--radius-sm);
}

.warning-list > div {
  display: grid;
  grid-template-columns: 18px minmax(0, 1fr);
  gap: var(--space-1);
  padding: 8px;
  color: var(--text);
  background: var(--warning-soft);
  border-bottom: 1px solid color-mix(in srgb, var(--warning-border) 55%, transparent);
  font-size: var(--text-xs);
}

.warning-list > div:last-child {
  border-bottom: 0;
}

.export-dialog > label:not(.acknowledge-losses) {
  display: flex;
  flex-direction: column;
  gap: 6px;
  color: var(--text-soft);
  font-size: var(--text-sm);
  font-weight: 680;
}

.segmented-control {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 2px;
  padding: 2px;
  background: var(--surface-muted);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
}

.segmented-control.three-up {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.segmented-control button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  min-width: 0;
  min-height: 31px;
  padding: 5px 8px;
  color: var(--text-soft);
  background: transparent;
  border: 0;
  border-radius: var(--radius-sm);
  font-size: var(--text-xs);
  font-weight: 680;
  cursor: pointer;
}

.segmented-control button[aria-selected="true"],
.segmented-control button[aria-pressed="true"] {
  color: var(--text);
  background: var(--surface);
  box-shadow: var(--shadow-inset);
}

.segmented-control button span {
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.segmented-control button:disabled {
  opacity: 0.45;
  cursor: default;
}

.export-fieldset {
  min-width: 0;
  margin: 0;
  padding: 0;
  border: 0;
}

.export-fieldset legend {
  margin-bottom: 6px;
  color: var(--text-soft);
  font-size: var(--text-xs);
  font-weight: 680;
}

.export-row {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}

.export-row label {
  display: flex;
  flex-direction: column;
  gap: 6px;
  color: var(--text-soft);
  font-size: var(--text-xs);
  font-weight: 680;
}

.export-filters {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 7px;
}

.export-filters legend {
  grid-column: 1 / -1;
}

.export-filters label {
  display: flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
  padding: 8px;
  background: var(--surface-muted);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text);
  font-size: var(--text-xs);
  font-weight: 650;
  cursor: pointer;
}

.export-filters input {
  width: 14px;
  height: 14px;
  margin: 0;
}

.export-reports {
  max-height: 165px;
  overflow: auto;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
}

.export-reports > div {
  padding: 8px 9px;
  border-bottom: 1px solid var(--border);
}

.export-reports > div:last-child {
  border-bottom: 0;
}

.export-reports strong,
.export-reports small {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.export-reports strong {
  font-size: var(--text-xs);
}

.export-reports small {
  margin-top: 2px;
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.export-reports p {
  display: grid;
  grid-template-columns: 16px minmax(0, 1fr);
  gap: var(--space-1);
  margin: 7px 0 0;
  color: var(--warning);
  font-size: var(--text-xs);
}

.archive-summary {
  display: grid;
  grid-template-columns: 24px minmax(0, 1fr) auto;
  align-items: center;
  gap: var(--space-2);
  min-height: 47px;
  padding: 9px;
  background: var(--surface-muted);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
}

.archive-format-help {
  margin: 0 0 var(--space-3);
  color: var(--text-soft);
  font-size: var(--text-sm);
  line-height: 1.5;
}

.archive-summary strong,
.archive-summary small {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.archive-summary strong {
  font-size: var(--text-sm);
}

.archive-summary small {
  margin-top: 3px;
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.export-ready {
  display: grid;
  grid-template-columns: 24px minmax(0, 1fr) auto;
  align-items: center;
  gap: var(--space-2);
  padding: 10px;
  background: var(--surface-muted);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
}

.export-ready strong,
.export-ready small {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.export-ready strong {
  font-size: var(--text-sm);
}

.export-ready small {
  margin-top: 2px;
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.export-ready a {
  text-decoration: none;
}

.project-list-dialog {
  padding: 12px;
}

.project-list {
  display: flex;
  flex-direction: column;
  gap: 3px;
  max-height: 340px;
  margin-bottom: 12px;
  overflow: auto;
}

.project-list > button {
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  min-height: 50px;
  padding: 8px 10px;
  text-align: left;
  background: transparent;
  border: 1px solid transparent;
  border-radius: var(--radius-sm);
  cursor: pointer;
}

.project-list > button:hover,
.project-list > button.active {
  background: var(--surface-muted);
  border-color: var(--border);
}

.project-list > button span {
  font-size: var(--text-md);
  font-weight: 680;
}

.project-list > button small {
  margin-top: 3px;
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.project-list-actions {
  display: flex;
  justify-content: space-between;
  gap: var(--space-2);
}

.confirm-dialog {
  padding: 17px;
}

.confirm-dialog p {
  margin: 0 0 18px;
  font-size: var(--text-md);
}

.dropdown-content {
  max-height: min(calc(100dvh - 16px), var(--radix-dropdown-menu-content-available-height, calc(100dvh - 16px)));
  max-width: calc(100vw - 16px);
  overflow-y: auto;
  z-index: 110;
  min-width: 178px;
  padding: 5px;
  background: var(--surface);
  border: 1px solid var(--border-strong);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow);
}

.dropdown-item {
  display: flex;
  align-items: center;
  gap: 9px;
  min-height: 31px;
  padding: 0 8px;
  color: var(--text);
  border-radius: var(--radius-sm);
  outline: 0;
  font-size: var(--text-sm);
  cursor: pointer;
  text-decoration: none;
}

.dropdown-item[data-highlighted] {
  background: var(--surface-hover);
  box-shadow: inset 2px 0 var(--focus);
}

.dropdown-item.danger {
  color: var(--danger);
}

.dropdown-separator {
  height: 1px;
  margin: 4px 0;
  background: var(--border);
}

.tooltip {
  z-index: 120;
  max-width: 280px;
  padding: 6px 8px;
  color: var(--surface);
  background: var(--text);
  border-radius: var(--radius-sm);
  font-size: var(--text-xs);
  box-shadow: var(--shadow);
  pointer-events: none;
}

.tooltip-arrow {
  fill: var(--text);
}

div[data-radix-popper-content-wrapper]:has(.tooltip) {
  pointer-events: none !important;
}

.mobile-scrim {
  position: fixed;
  z-index: 50;
  inset: 52px 0 0;
  background: var(--overlay);
  border: 0;
}

.mobile-panel {
  position: fixed;
  z-index: 51;
  top: 52px;
  bottom: 0;
  width: min(360px, calc(100vw - 36px));
  box-shadow: var(--shadow);
}

.mobile-panel.projects {
  left: 0;
}

.mobile-panel.inspector,
.mobile-panel.history {
  right: 0;
}

.viewer-toolbar {
  position: absolute;
  z-index: 8;
  top: 10px;
  left: 10px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  max-width: calc(100% - 62px);
  min-height: 32px;
  padding: 3px;
  color: var(--text);
  background: color-mix(in srgb, var(--surface) 92%, transparent);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-small);
}

.viewer-toolbar-label {
  padding: 0 7px 0 5px;
  color: var(--text-soft);
  font-size: var(--text-xs);
  font-weight: 750;
  letter-spacing: 0.07em;
  text-transform: uppercase;
}

.viewer-picking-buttons {
  display: flex;
  min-width: 0;
}

.viewer-picking-buttons button {
  min-width: 0;
  height: 26px;
  padding: 0 8px;
  overflow: hidden;
  color: var(--text);
  background: transparent;
  border: 0;
  border-left: 1px solid var(--border);
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--text-xs);
  font-weight: 650;
  cursor: pointer;
}

.viewer-picking-buttons button.active {
  color: var(--accent-strong);
  background: var(--accent-soft);
}

.viewer-picking-select {
  display: none;
}

.viewer-picking-select select {
  width: 112px;
  height: 26px;
  padding: 0 24px 0 7px;
  font-size: var(--text-sm);
}

.viewer-focus-actions {
  display: flex;
  align-items: center;
  margin-left: 3px;
  padding-left: 3px;
  border-left: 1px solid var(--border);
}

.viewer-action-button {
  display: grid;
  place-items: center;
  width: 28px;
  height: 26px;
  padding: 0;
  color: var(--text);
  background: transparent;
  border: 0;
  cursor: pointer;
}

.viewer-action-button.viewer-measurements-action {
  width: 44px;
  min-width: 44px;
  height: 44px;
  min-height: 44px;
}

.viewer-action-button:hover:not([aria-disabled="true"]) {
  color: var(--accent-strong);
  background: var(--accent-soft);
}

.viewer-action-button[aria-disabled="true"] {
  opacity: 0.42;
  cursor: not-allowed;
}

.viewer-controls {
  position: absolute;
  z-index: 8;
  top: 10px;
  right: 10px;
  display: flex;
  align-items: flex-start;
  justify-content: flex-end;
  max-width: calc(100% - 20px);
}

.viewer-controls > .icon-button {
  flex: 0 0 auto;
  background: color-mix(in srgb, var(--surface) 92%, transparent);
  border: 1px solid var(--border);
  box-shadow: var(--shadow-small);
}

.viewer-controls-panel {
  width: min(410px, calc(100vw - 48px));
  max-height: calc(100vh - 130px);
  margin-right: 6px;
  padding: 10px;
  overflow: auto;
  color: var(--text);
  background: color-mix(in srgb, var(--surface) 96%, transparent);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow);
  font-size: var(--text-xs);
}

.viewer-control-heading,
.representation-row,
.camera-controls,
.scene-list > div {
  display: flex;
  align-items: center;
  gap: 6px;
}

.viewer-control-heading {
  justify-content: space-between;
  margin-bottom: 8px;
}

.viewer-control-heading select {
  width: 58%;
  height: 28px;
}

.representation-list {
  display: grid;
  gap: 6px;
  margin-bottom: 7px;
}

.representation-row {
  display: grid;
  grid-template-columns: minmax(82px, 1fr) minmax(76px, 1fr) 30px;
  padding: 6px;
  background: var(--surface-muted);
  border: 1px solid var(--border);
}

.representation-row select,
.viewer-controls-panel > label select,
.scene-form input {
  height: 28px;
  font-size: var(--text-xs);
}

.representation-row input[type="color"] {
  width: 30px;
  height: 28px;
  padding: 2px;
}

.opacity-control {
  display: grid;
  grid-column: 1 / 3;
  grid-template-columns: 48px 1fr;
  align-items: center;
  gap: 5px;
}

.opacity-control input {
  height: 22px;
  padding: 0;
}

.representation-row .icon-button {
  grid-row: 1;
  grid-column: 3;
  width: 28px;
  height: 28px;
}

.viewer-controls-panel fieldset {
  display: flex;
  flex-wrap: wrap;
  gap: 7px 12px;
  margin: 9px 0 0;
  padding: 7px;
  border: 1px solid var(--border);
}

.viewer-controls-panel legend {
  padding: 0 4px;
  color: var(--text-soft);
  font-size: var(--text-xs);
  text-transform: uppercase;
}

.check-label {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  text-transform: capitalize;
}

.check-label input {
  width: 14px;
  height: 14px;
}

.dependent-component-control {
  display: grid;
  flex: 1 0 100%;
  gap: 3px;
}

.viewer-control-help {
  padding-left: 18px;
  color: var(--text-soft);
  line-height: 1.35;
}

.camera-controls {
  flex-wrap: wrap;
  margin-top: 9px;
}

.camera-controls .segmented-control {
  grid-template-columns: repeat(2, 1fr);
  width: 188px;
}

.camera-controls .segmented-control button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-1);
}

.camera-controls > button:last-child {
  height: 30px;
  padding: 0 8px;
  color: var(--text);
  background: var(--surface);
  border: 1px solid var(--border-strong);
  font-size: var(--text-xs);
}

.camera-controls > button.active {
  color: var(--brand);
  background: var(--accent-soft);
  border-color: var(--accent);
}

.scene-form {
  margin-top: 9px;
  padding-top: 8px;
  border-top: 1px solid var(--border);
}

.scene-form > label {
  display: grid;
  gap: var(--space-1);
}

.scene-list {
  margin-top: 6px;
}

.scene-list > div {
  min-height: 31px;
  border-top: 1px solid var(--border);
}

.scene-list > div > button:first-child {
  flex: 1;
  min-width: 0;
  padding: 0;
  overflow: hidden;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
  background: transparent;
  border: 0;
  cursor: pointer;
}

.project-inspector {
  display: flex;
  flex-direction: column;
  container-type: inline-size;
  min-height: 0;
  overflow: clip;
}

.project-inspector .panel-header {
  flex-shrink: 0;
}

.project-inspector .inspector-scroll {
  flex: 1 1 0;
  min-height: 0;
  min-width: 0;
  overflow: auto;
  overscroll-behavior: contain;
}

.project-inspector .inspector-body {
  min-width: 0;
  height: auto;
  overflow: visible;
}

.inspector-header-actions { display: flex; align-items: center; gap: 4px; }
.inspector-header-actions .icon-button { min-width: 44px; min-height: 44px; }
.inspector-tools[hidden] { display: none; }
.ligand-information-body { padding: 0; }
.ligand-information { min-width: 0; }
.ligand-information .ligand-entry-choice select,
.ligand-information .ligand-designation-summary .secondary-button,
.ligand-information .ligand-designation-clear { min-height: 44px; }
.ligand-interaction-unavailable { padding: 0 10px 10px; font-size: var(--text-xs); line-height: 1.45; overflow-wrap: anywhere; }
.ligand-interaction-unavailable summary { min-height: 44px; align-content: center; cursor: pointer; }
.ligand-interaction-unavailable summary:focus-visible { outline: 2px solid var(--focus); outline-offset: 2px; }

.project-browser {
  display: flex;
  flex-direction: column;
}

.project-browser .panel-header,
.project-browser .browser-controls {
  flex-shrink: 0;
}

.project-browser .browser-results {
  flex: 1;
  min-height: 0;
  height: auto;
}

@container (max-width: 320px) {
  .selection-summary {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .project-facts {
    grid-template-columns: 1fr;
  }

  .project-facts > div {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: var(--space-2);
    border-right: 0;
    border-bottom: 1px solid var(--border);
  }

  .project-facts > div:last-child {
    border-bottom: 0;
  }

  .project-facts dd {
    margin: 0;
  }
}

.inspect-panel,
.measurements-panel {
  padding: 10px;
}

.transform-panel {
  padding: 0 10px 14px;
}

.ligand-editor,
.protein-editor {
  display: grid;
  gap: 10px;
  padding: 10px 10px 16px;
}

.ligand-editor > label,
.protein-editor > label,
.edit-section label {
  display: grid;
  gap: var(--space-1);
  min-width: 0;
  color: var(--text-soft);
  font-size: var(--text-xs);
  font-weight: 650;
}

.ligand-editor input,
.ligand-editor select,
.protein-editor input,
.protein-editor select {
  height: 30px;
  font-size: var(--text-xs);
}

.ligand-status {
  display: flex;
  justify-content: space-between;
  gap: 5px;
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.ligand-status strong {
  color: var(--danger);
}

.edit-section {
  display: grid;
  gap: var(--space-2);
  min-width: 0;
  margin: 0;
  padding: 9px;
  border: 1px solid var(--border);
}

.edit-section legend {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 0 4px;
  color: var(--text-soft);
  font-size: var(--text-xs);
  font-weight: 700;
  text-transform: uppercase;
}

.edit-section .form-row.three,
.coordinate-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px;
}

.edit-section button,
.edit-actions button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  min-height: 30px;
  padding: 4px 7px;
  color: var(--text);
  background: var(--surface);
  border: 1px solid var(--border-strong);
  border-radius: var(--radius-sm);
  font-size: var(--text-xs);
  font-weight: 650;
  cursor: pointer;
}

.edit-section button:disabled {
  opacity: 0.42;
  cursor: default;
}

.edit-actions {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px;
}

.edit-actions .danger-button {
  color: var(--danger);
  border-color: color-mix(in srgb, var(--danger) 45%, var(--border));
}

.edit-report {
  padding: 9px;
  background: var(--surface-muted);
  border-left: 3px solid var(--accent);
}

.edit-report h3,
.edit-report p {
  margin: 0;
}

.edit-report h3 {
  font-size: var(--text-xs);
}

.edit-report p,
.edit-report small,
.edit-warning {
  margin-top: 4px;
  font-size: var(--text-xs);
}

.edit-warning {
  color: var(--danger);
}

.scientific-note {
  display: grid;
  grid-template-columns: 15px minmax(0, 1fr);
  gap: 7px;
  padding: 8px;
  color: var(--text-soft);
  background: var(--surface-muted);
  border-left: 3px solid var(--warning);
  font-size: var(--text-xs);
  line-height: 1.4;
}

.coordinate-section {
  display: grid;
  gap: 9px;
  padding: 12px 0;
  border-bottom: 1px solid var(--border);
}

.coordinate-section:last-of-type {
  border-bottom: 0;
}

.coordinate-section > label,
.coordinate-section > fieldset {
  display: grid;
  gap: 5px;
  min-width: 0;
  margin: 0;
  color: var(--text-soft);
  border: 0;
  font-size: var(--text-xs);
  font-weight: 680;
}

.coordinate-section > fieldset > legend,
.vector-input legend {
  margin-bottom: 5px;
  padding: 0;
}

.section-title {
  display: flex;
  align-items: center;
  gap: 7px;
  color: var(--text);
}

.section-title h3 {
  margin: 0;
  font-size: var(--text-sm);
}

.coordinate-section .segmented-control {
  grid-template-columns: repeat(2, 1fr);
}

.coordinate-section .segmented-control.three {
  grid-template-columns: repeat(3, 1fr);
}

.vector-input {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.vector-input legend {
  grid-column: 1 / -1;
}

.vector-input label {
  display: grid;
  grid-template-columns: 13px minmax(0, 1fr);
  align-items: center;
  gap: 3px;
}

.vector-input input {
  min-width: 0;
  height: 30px;
  padding: 0 5px;
}

.coordinate-context {
  margin: -3px 0 0;
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.gesture-slider > span {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.gesture-slider output {
  color: var(--text);
  font-variant-numeric: tabular-nums;
}

.gesture-slider input {
  height: 26px;
  padding: 0;
}

.fit-report {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  margin: 0;
  border: 1px solid var(--border);
}

.fit-report div {
  min-width: 0;
  padding: 8px;
}

.fit-report div + div {
  border-left: 1px solid var(--border);
}

.fit-report dt {
  color: var(--text-soft);
  font-size: var(--text-tiny);
  text-transform: uppercase;
}

.fit-report dd {
  margin: 3px 0 0;
  font-size: var(--text-sm);
  font-weight: 720;
}

.inspect-panel section {
  margin-bottom: 12px;
}

.inspect-panel h3,
.contacts-panel h3 {
  margin: 0 0 6px;
  font-size: var(--text-xs);
}

.property-list {
  margin: 0;
  border-top: 1px solid var(--border);
}

.property-list div {
  display: grid;
  grid-template-columns: 44% 56%;
  padding: 5px 0;
  border-bottom: 1px solid var(--border);
  font-size: var(--text-xs);
}

.property-list dt {
  color: var(--text-soft);
}

.property-list dd {
  margin: 0;
  overflow-wrap: anywhere;
}

.measurement-create,
.measurement-list,
.contacts-panel {
  padding-bottom: 11px;
  border-bottom: 1px solid var(--border);
}

.measurement-create > label,
.contacts-panel label {
  display: grid;
  gap: var(--space-1);
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.measurement-create input,
.contacts-panel input,
.contacts-panel select,
.measurement-row input {
  height: 29px;
  font-size: var(--text-xs);
}

.measurement-kind-buttons {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--space-1);
  margin-top: 6px;
}

.measurement-kind-buttons button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-1);
  height: 30px;
  color: var(--text);
  background: var(--surface);
  border: 1px solid var(--border-strong);
  font-size: var(--text-xs);
  text-transform: capitalize;
}

.measurement-kind-buttons button:disabled {
  opacity: 0.4;
}

.measurement-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) repeat(3, 28px);
  align-items: center;
  gap: 3px;
  min-height: 47px;
  border-bottom: 1px solid var(--border);
}

.measurement-row small {
  display: block;
  margin-top: 2px;
  color: var(--text-soft);
  font-size: var(--text-tiny);
}

.contacts-panel {
  padding-top: 11px;
  border-bottom: 0;
}

.contacts-panel .secondary-button {
  width: 100%;
  min-height: 30px;
  margin-top: 6px;
  font-size: var(--text-xs);
}

.contact-results {
  max-height: 170px;
  margin-top: 7px;
  overflow: auto;
}

.contact-results button {
  display: flex;
  justify-content: space-between;
  width: 100%;
  min-height: 29px;
  padding: 0 4px;
  color: var(--text);
  background: transparent;
  border: 0;
  border-top: 1px solid var(--border);
  font-size: var(--text-xs);
  cursor: pointer;
}

.inline-error {
  color: var(--danger);
  font-size: var(--text-xs);
}

.lower-panel {
  min-height: 0;
}

.lower-panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 34px;
  padding-right: 5px;
  border-bottom: 1px solid var(--border);
}

.lower-tabs {
  display: flex;
  height: 100%;
}

.lower-tabs button {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 0 12px;
  color: var(--text-soft);
  background: transparent;
  border: 0;
  border-bottom: 2px solid transparent;
  font-size: var(--text-xs);
  cursor: pointer;
}

.lower-tabs button[aria-selected="true"] {
  color: var(--text);
  border-bottom-color: var(--accent);
}

.property-table-wrap {
  height: calc(100% - 34px);
  overflow: auto;
}

.property-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--text-xs);
  white-space: nowrap;
}

.property-table th,
.property-table td {
  padding: 5px 8px;
  text-align: left;
  border-right: 1px solid var(--border);
  border-bottom: 1px solid var(--border);
}

.property-table th {
  position: sticky;
  top: 0;
  z-index: 1;
  color: var(--text-soft);
  background: var(--surface-muted);
  font-size: var(--text-tiny);
  text-transform: uppercase;
}

.property-table tbody tr {
  cursor: pointer;
}

.property-table tbody tr:hover {
  background: var(--accent-soft);
}

.lower-panel > .history-panel {
  height: calc(100% - 34px);
}

.lower-panel > .jobs-workspace {
  height: calc(100% - 34px);
}

.compact-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  min-height: 26px;
  padding: 4px 8px;
  font-size: var(--text-xs);
  text-decoration: none;
  white-space: nowrap;
}

.job-submit-form {
  max-height: min(70vh, 650px);
  overflow: auto;
}

.job-definition-description {
  margin: -3px 0 3px;
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.job-input-role,
.vector-parameter {
  min-width: 0;
  margin: 0;
  padding: 8px;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
}

.job-input-role legend,
.vector-parameter legend {
  padding: 0 4px;
  color: var(--text-soft);
  font-size: var(--text-xs);
  text-transform: uppercase;
}

.job-input-role legend span {
  color: var(--text-faint);
}

.job-input-role > label {
  display: grid;
  grid-template-columns: 18px minmax(0, 1fr) auto;
  align-items: center;
  gap: 6px;
  min-height: 27px;
  font-size: var(--text-xs);
  text-transform: none;
}

.job-input-role > label span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.job-input-role > label small {
  color: var(--text-faint);
  font-size: var(--text-tiny);
}

.job-parameter-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--space-2);
}

.vector-parameter {
  grid-column: 1 / -1;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 6px;
}

.vector-parameter label {
  min-width: 0;
}

.jobs-workspace {
  display: grid;
  grid-template-columns: minmax(190px, 28%) minmax(0, 1fr);
  min-width: 0;
  min-height: 0;
  overflow: hidden;
}

.jobs-list-pane,
.job-detail-pane {
  min-width: 0;
  min-height: 0;
  overflow: hidden;
}

.jobs-list-pane {
  border-right: 1px solid var(--border);
}

.jobs-toolbar,
.job-detail-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 36px;
  padding: 0 8px;
  border-bottom: 1px solid var(--border);
}

.jobs-toolbar strong,
.job-detail-header strong {
  font-size: var(--text-xs);
  font-weight: 650;
}

.job-list {
  height: calc(100% - 36px);
  overflow: auto;
}

.job-list > button {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 3px 7px;
  width: 100%;
  min-height: 58px;
  padding: 7px 8px;
  color: var(--text);
  text-align: left;
  background: transparent;
  border: 0;
  border-bottom: 1px solid var(--border);
  cursor: pointer;
}

.job-list > button:hover,
.job-list > button.active {
  background: var(--accent-soft);
}

.job-list-title {
  overflow: hidden;
  font-size: var(--text-xs);
  font-weight: 600;
  text-overflow: ellipsis;
  text-transform: capitalize;
  white-space: nowrap;
}

.job-list > button small {
  grid-column: 1 / -1;
  overflow: hidden;
  color: var(--text-soft);
  font-size: var(--text-tiny);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.job-list progress {
  grid-column: 1 / -1;
  width: 100%;
  height: 4px;
}

.job-status {
  display: inline-flex;
  align-items: center;
  width: fit-content;
  min-height: 17px;
  padding: 1px 5px;
  color: var(--text-soft);
  background: var(--surface-muted);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  font-size: var(--text-tiny);
  font-weight: 650;
  text-transform: uppercase;
}

.job-status.completed {
  color: var(--success);
  background: var(--success-soft);
}

.job-status.failed {
  color: var(--danger);
  background: var(--danger-soft);
}

.job-status.cancelled {
  color: var(--text-soft);
}

.job-status.running {
  color: var(--info);
  background: var(--info-soft);
}

.job-detail-pane {
  display: grid;
  grid-template-rows: 36px 29px minmax(0, 1fr);
}

.job-detail-header > div {
  display: flex;
  min-width: 0;
  flex-direction: column;
}

.job-detail-header > div strong {
  overflow: hidden;
  text-overflow: ellipsis;
  text-transform: capitalize;
  white-space: nowrap;
}

.job-detail-header > div span {
  color: var(--text-faint);
  font-family: var(--font-data);
  font-size: var(--text-tiny);
}

.job-detail-tabs {
  display: flex;
  border-bottom: 1px solid var(--border);
}

.job-detail-tabs button {
  padding: 0 10px;
  color: var(--text-soft);
  background: transparent;
  border: 0;
  border-bottom: 2px solid transparent;
  font-size: var(--text-xs);
  cursor: pointer;
}

.job-detail-tabs button[aria-selected="true"] {
  color: var(--text);
  border-bottom-color: var(--accent);
}

.job-overview,
.job-log,
.job-results {
  min-height: 0;
  padding: 9px;
  overflow: auto;
}

.job-progress-row {
  display: grid;
  grid-template-columns: auto minmax(80px, 1fr) 34px;
  align-items: center;
  gap: var(--space-2);
}

.job-progress-row progress {
  width: 100%;
}

.job-overview > p {
  margin: 7px 0;
  color: var(--text-soft);
  font-size: var(--text-xs);
}

.job-overview dl {
  display: grid;
  grid-template-columns: 70px minmax(0, 1fr);
  gap: 3px 8px;
  margin: 8px 0;
  font-size: var(--text-xs);
}

.job-overview dt {
  color: var(--text-faint);
}

.job-overview dd {
  min-width: 0;
  margin: 0;
  overflow-wrap: anywhere;
}

.job-overview details {
  margin-top: 5px;
  font-size: var(--text-xs);
}

.job-overview pre {
  overflow: auto;
  max-height: 120px;
  padding: 7px;
  background: var(--surface-muted);
  font-size: var(--text-tiny);
}

.job-error {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 6px;
  color: var(--danger);
  background: color-mix(in srgb, var(--danger) 8%, transparent);
  border-left: 2px solid var(--danger);
  font-size: var(--text-xs);
}

.job-log {
  padding: 0;
  font-family: var(--font-data);
  font-size: var(--text-tiny);
}

.job-log > div {
  display: grid;
  grid-template-columns: 58px 48px minmax(0, 1fr);
  gap: 6px;
  padding: 4px 8px;
  border-bottom: 1px solid var(--border);
}

.job-log time,
.job-log > div > span {
  color: var(--text-faint);
}

.job-log p {
  margin: 0;
  overflow-wrap: anywhere;
}

.job-log .stderr p {
  color: var(--danger);
}

.job-results > div {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto auto;
  align-items: center;
  gap: 6px;
  min-height: 42px;
  padding: 6px;
  border-bottom: 1px solid var(--border);
}

.job-results > div > div {
  display: flex;
  min-width: 0;
  flex-direction: column;
}

.job-results strong {
  overflow: hidden;
  font-size: var(--text-xs);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.job-results span {
  color: var(--text-faint);
  font-size: var(--text-tiny);
}

.job-query-error {
  display: flex;
  flex-direction: column;
  gap: 5px;
  padding: 8px;
  color: var(--danger);
  font-size: var(--text-xs);
}

.job-query-error button {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  width: fit-content;
  color: var(--text);
  background: transparent;
  border: 0;
}

.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

@keyframes fade-in {
  from {
    opacity: 0;
  }
}

@keyframes dialog-in {
  from {
    opacity: 0;
    transform: translate(-50%, -48%);
  }
}

@media (max-width: 840px) {
  .brand-desktop {
    display: none;
  }

  .brand-compact {
    display: inline-block;
  }

  .brand {
    padding-right: 3px;
  }

  .project-switcher {
    max-width: calc(100vw - 292px);
  }

  .workspace-root {
    height: 100%;
  }

  .history-content {
    grid-template-columns: repeat(2, 1fr);
    height: calc(100% - 38px);
  }

  .lower-panel > .jobs-workspace {
    height: calc(100% - 34px);
  }

  .jobs-workspace {
    grid-template-columns: 145px minmax(0, 1fr);
  }
}

@media (max-width: 520px) {
  .tooltip {
    display: none;
  }

  .topbar {
    padding: 0 5px;
  }

  .project-switcher {
    max-width: calc(100vw - 315px);
    padding: 0 7px;
  }

  .topbar-actions {
    gap: 0;
  }

  .toolbar-separator {
    display: none;
  }

  .icon-button {
    width: 30px;
  }

  .viewer-picking-buttons {
    display: none;
  }

  .viewer-picking-select {
    display: block;
  }

  .tooltip.viewer-toolbar-tooltip {
    display: block;
  }

  .canvas-empty h1,
  .project-stage h1 {
    max-width: calc(100vw - 40px);
    font-size: 21px;
  }

  .import-options {
    grid-template-columns: 1fr;
  }

  .job-parameter-grid {
    grid-template-columns: 1fr;
  }

  .jobs-workspace {
    grid-template-columns: 116px minmax(0, 1fr);
  }

  .job-results > div {
    grid-template-columns: minmax(0, 1fr) auto;
  }

  .job-results > div > .primary-button {
    grid-column: 2;
  }

  .job-detail-header > div span {
    display: none;
  }
}

@media (max-width: 400px) {
  .topbar-actions {
    min-width: 0;
    overflow-x: auto;
    scrollbar-width: none;
    padding-block: 4px;
  }

  /* The logo still opens Projects; avoid a duplicate cramped name control. */
  .project-switcher {
    display: none;
  }

  .topbar .brand {
    padding: 0;
  }
}

@media (max-width: 260px) {
  .viewer-toolbar-label {
    display: none;
  }

  .viewer-picking-select select {
    width: 96px;
  }

  .viewer-focus-actions {
    margin-left: 0;
    padding-left: 0;
    border-left: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    scroll-behavior: auto !important;
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
  }
}

.selection-expansion-form {
  display: flex;
  flex-wrap: wrap;
  align-items: end;
  gap: 0.6rem;
}
.selection-expansion-form label {
  display: grid;
  gap: 0.3rem;
  flex: 1 1 8rem;
  min-width: 0;
}
.selection-expansion-form input,
.selection-expansion-form select { width: 100%; min-width: 0; }

/* A workspace tool, below modal dialogs and above the molecular canvas. */
.selection-palette {
  --palette-top: 58px;
  --palette-left: 10px;
  position: fixed;
  z-index: 40;
  top: var(--palette-top, 58px);
  left: var(--palette-left, 10px);
  width: min(340px, calc(100vw - 24px));
  max-height: calc(100dvh - var(--palette-top, 58px) - 12px);
  transform: none;
  animation: fade-in 120ms ease-out;
  scroll-padding-top: 58px;
}

@media (max-width: 840px) {
  .selection-palette {
    position: fixed;
    top: auto;
    bottom: 8px;
    left: 8px;
    width: min(340px, calc(100vw - 16px));
    max-height: 60dvh;
  }
}

.selection-surface-controls { border: 0; padding: 0; margin: 0; display: flex; flex-wrap: wrap; align-items: center; gap: 4px; }
.selection-surface-controls strong { font-size: 12px; font-weight: 600; }
.selection-surface-controls > span { font-size: 11px; margin-right: auto; }
.selection-surface-controls button, .surface-runtime-status button { min-height: 44px; min-width: 44px; }
.selection-surface-controls .surface-help summary { display: flex; align-items: center; justify-content: center; min-width: 44px; min-height: 44px; padding: 0; }
.selection-surface-controls .surface-help[open] { flex-basis: 100%; }
.surface-runtime-status { position: absolute; bottom: 34px; left: 12px; max-width: min(420px, calc(100% - 24px)); max-height: 25%; overflow: auto; padding: 4px 8px; border: 1px solid var(--border); border-radius: 6px; background: var(--surface); font-size: 12px; z-index: 2; }
.surface-runtime-status > div { display: flex; align-items: center; gap: 8px; }
.surface-runtime-status span { flex: 1; }

/* On-demand surface tools keep the primary selection palette at its existing size. */
.pocket-popover { width: min(340px, calc(100vw - 16px)); max-height: calc(100dvh - 24px); overflow-y: auto; z-index: 80; }
.pocket-draft { display: grid; gap: 10px; }
.pocket-draft label { display: grid; gap: 4px; }
.pocket-draft select, .pocket-draft input { width: 100%; min-width: 0; min-height: 44px; }
.pocket-seeds { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.pocket-draft button, .pocket-draft summary { min-height: 44px; }
.pocket-draft p, .surface-explanation p { font-size: 0.8125rem; line-height: 1.45; }
.pocket-popover { z-index: 115; }
.pocket-draft, .pocket-popover > .surface-explanation { padding: 12px; }
.surface-options-menu .dropdown-item { min-height: 44px; }
.pocket-popover .icon-button { min-width: 44px; min-height: 44px; }

.group-scope-label { max-width: 260px; padding: 6px 10px; font-size: 0.75rem; color: var(--text-soft); }

.entry-drag-handle { align-self: stretch; display: flex; align-items: center; padding: 0 2px; color: var(--text-soft); cursor: grab; }
.entry-drag-handle:active { cursor: grabbing; }
.group-drop-target { outline: 1px dashed var(--border-strong); outline-offset: -1px; }
.group-drop-hover { outline: 2px solid var(--focus); background: var(--accent-soft); }
.project-browser { position: relative; }
.group-drag-status { position: absolute; bottom: 8px; left: 8px; right: 8px; z-index: 2; margin: 0; padding: 8px; font-size: var(--text-sm); color: var(--text-soft); background: var(--surface); border: 1px solid var(--border); pointer-events: none; }
@media (pointer: coarse), (max-width: 840px) { .entry-drag-handle { display: none; } }

/* On-demand surface objects; molecular browser/navigation retain their owners. */
.surface-manager {
  animation: fade-in 120ms ease-out;
  position: fixed;
  top: 72px;
  right: 12px;
  left: auto;
  bottom: auto;
  transform: none;
  width: min(400px, calc(100vw - 24px));
  height: min(720px, calc(100dvh - 88px));
  max-height: calc(100dvh - 88px);
  display: grid;
  grid-template-rows: auto minmax(72px, min(28dvh, 190px)) minmax(0, 1fr);
  overflow: hidden;
}
.surface-manager-header { align-items: center; padding: 8px 10px; }
.surface-manager-header > div { display: flex; gap: 4px; }
.surface-object-list { min-height: 0; overflow: auto; padding: 0 8px 6px; border-bottom: 1px solid var(--border); }
.surface-parent-name { position: sticky; top: 0; z-index: 1; background: var(--surface); margin: 0; padding: 6px 0 4px; overflow-wrap: anywhere; font-size: 12px; }
.surface-parent-name span { font-weight: normal; }
.surface-object { padding: 4px; border: 1px solid var(--border); border-radius: 6px; margin-block: 4px; }
.surface-object[data-active] { border-color: var(--accent); }
.surface-object[data-created] { background: var(--accent-soft); }
.surface-object-row { display: flex; align-items: center; gap: 4px; }
.surface-object-label { flex: 1; min-width: 0; text-align: left; display: grid; gap: 2px; background: transparent; border: 0; color: inherit; }
.surface-object-label span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.surface-object-label .surface-row-name { display: flex; align-items: center; gap: 4px; }
.surface-row-name svg { flex-shrink: 0; }
.surface-object-label small { font-size: 11px; }
.surface-object-status { font-size: 11px; margin: 2px 4px; overflow-wrap: anywhere; }
.surface-manager-details { min-height: 0; overflow: auto; padding: 8px; }
.surface-details-heading { display: flex; align-items: center; gap: 8px; }
.surface-details-heading h3 { min-width: 0; flex: 1; margin: 0; overflow-wrap: anywhere; font-size: 13px; }
.surface-manager-feedback { margin: 6px 0; font-size: 12px; overflow-wrap: anywhere; }
.surface-manager-feedback p { margin: 4px 0; }
.surface-manager button:where(:not(.icon-button):not(.surface-object-label)) { min-height: 30px; padding: 4px 7px; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); color: var(--text); background: var(--surface); font-size: 12px; }
.surface-manager [aria-disabled="true"] { cursor: default; opacity: 0.6; }
.surface-manager .surface-source-choices button[aria-pressed="true"] { color: var(--accent-strong); background: var(--accent-soft); border-color: var(--accent); }
.surface-object-editor { display: flex; gap: 6px; align-items: end; margin-block: 8px; }
.surface-object-editor label { display: grid; gap: 4px; flex: 1; min-width: 0; }
.surface-object-editor input { min-width: 0; width: 100%; }
@media (pointer: coarse) {
  .surface-manager button, .surface-manager input { min-height: 44px; }
  .surface-manager .icon-button { min-width: 44px; }
}

.surface-object-editor fieldset { margin: 4px 0; padding: 8px; border: 1px solid var(--border); min-width: 0; }
.surface-object-editor legend { font-size: 12px; font-weight: 600; }
.surface-object-editor form { min-width: 0; }
.surface-object-editor label { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: 6px 0; font-size: 12px; }
.surface-object-editor select { min-width: 0; max-width: 62%; }
.surface-object-editor input[type="number"] { width: 80px; }
.surface-object-editor input[type="color"] { width: 64px; }
.surface-opacity-controls { display: flex; align-items: center; gap: 6px; width: 70%; min-width: 0; }
.surface-object-editor .surface-opacity-controls input[type="number"] { width: 65px; flex-shrink: 0; padding-inline: 4px; }
.surface-object-editor .surface-opacity-controls input[type="range"] { min-width: 0; flex: 1; padding: 0; }
.surface-object-editor p { overflow-wrap: anywhere; font-size: 12px; }
.surface-object-editor .checkbox-row { justify-content: flex-start; }
.surface-details-editor { display: block; }
.surface-object-editor input[type="checkbox"] { width: 18px; height: 18px; min-height: 0; flex: none; }
.surface-source-details > summary { padding: 6px 0; cursor: pointer; font-size: 12px; font-weight: 600; }
.surface-unapplied { color: var(--accent-strong); }
.surface-source-actions, .surface-create-actions { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 8px; }
.surface-name-form { flex-wrap: wrap; }
.surface-name-form label { flex-basis: 100%; }
.surface-create-form { display: grid; gap: 8px; font-size: 12px; }
.surface-create-form h3 { margin: 0; font-size: 13px; }
.surface-create-form label { display: grid; gap: 4px; }
.surface-source-choices { display: flex; gap: 4px; }
.surface-source-choices button { flex: 1; min-width: 0; }
.surface-captured-selection { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; justify-content: space-between; }
.surface-create-form .surface-source-summary { margin: 0; color: var(--text-soft); }
.surface-manager .surface-create-form button { min-height: 44px; }
@media (pointer: coarse) {
  .surface-manager select, .surface-manager .checkbox-row { min-height: 44px; }
  .surface-manager button:not(.icon-button):not(.surface-object-label), .surface-object-label, .surface-manager summary { min-height: 44px; }
}

/* Application-owned entry/component navigation (issue #59). */
.project-browser > [data-panel-group] { flex: 1; min-height: 0; }
.entry-pane, .component-pane, .browser-tab-panel {
  height: 100%; min-height: 0; min-width: 0; display: flex; flex-direction: column; overflow: hidden;
}
.entry-pane .browser-results, .component-scroll { flex: 1; min-height: 0; overflow: auto; }
.component-pane-header { display: flex; align-items: center; justify-content: space-between; padding: 3px 8px; flex-shrink: 0; }
.component-pane-header h3 { margin: 0; font-size: var(--text-sm); }
.component-pane-header .icon-button { width: 28px; height: 28px; }
.component-parent { display: flex; flex-direction: column; padding: 0 8px 4px; flex-shrink: 0; font-size: var(--text-xs); }
.component-parent > span { font-weight: 650; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.component-parent small { color: var(--text-soft); }
.component-restore { display: flex; align-items: center; justify-content: center; gap: 4px; width: 100%; height: 100%; border: 0; color: var(--text); background: var(--surface); }
.browser-filter-details { font-size: var(--text-xs); }
.browser-filter-details summary { cursor: pointer; min-height: 24px; }
.browser-filter-details .browser-selects { margin-top: 4px; }
.project-browser .entry-row { height: 32px; min-height: 32px; margin-bottom: 0; padding: 1px; }
.project-browser .entry-node { margin-bottom: 0; }
.project-browser .entry-select { display: flex; min-width: 0; min-height: 0; height: 28px; gap: 4px; }
.project-browser .entry-row[data-inspected] { box-shadow: inset 2px 0 var(--accent); }
.project-browser .entry-row .icon-button { width: 28px; height: 28px; min-width: 28px; flex-shrink: 0; }
.project-browser .entry-copy { flex: 1; overflow: hidden; text-align: left; }
.project-browser .entry-type-icon { flex-shrink: 0; width: 14px; }
.entry-warning { color: var(--warning); flex-shrink: 0; }
.entry-details { display: flex; flex-direction: column; max-height: calc(100dvh - 32px); }
.entry-details-body { padding: 0 16px 16px; overflow: auto; min-height: 0; overflow-wrap: anywhere; }
.entry-details-body dl { display: grid; grid-template-columns: minmax(80px, 1fr) minmax(0, 2fr); gap: 6px 12px; }
.entry-details-body dt { color: var(--text-soft); }
.entry-details-body dd { margin: 0; }
.browser-tabs { display: flex; flex-shrink: 0; gap: 4px; padding: 0 8px 4px; }
.browser-tabs button { flex: 1; min-height: 44px; border: 1px solid var(--border); border-radius: var(--radius-sm); background: var(--surface); color: var(--text); }
.browser-tabs button[aria-selected="true"] { background: var(--accent-soft); }
.browser-tab-panel { flex: 1; }
@media (any-pointer: coarse), (max-width: 840px) {
  .project-browser .entry-row { height: 44px; min-height: 44px; }
  .project-browser .entry-select { height: 44px; }
  .project-browser .entry-row .icon-button, .component-pane-header .icon-button { width: 44px; height: 44px; min-width: 44px; }
  .browser-filter-details summary { min-height: 44px; display: flex; align-items: center; }
}
.browser-tab-panel[hidden] { display: none; }

.hierarchy-loading, .hierarchy-error { display: flex; align-items: center; gap: 6px; padding: 8px; font-size: var(--text-xs); }
.hierarchy-loading svg { animation: movement-spin 1s linear infinite; }
.hierarchy-error { color: var(--warning); flex-wrap: wrap; }
.hierarchy-warning-summary { display: flex; align-items: center; gap: 4px; flex-shrink: 0; min-height: 28px; margin: 0 8px 4px; border: 0; background: var(--surface-muted); color: var(--text); font-size: var(--text-xs); }
.hierarchy-virtual-list { position: relative; width: 100%; }
.hierarchy-row { position: absolute; left: 0; right: 0; top: 0; display: flex; align-items: center; min-width: 0; padding: 0 4px; font-size: var(--text-xs); }
.hierarchy-row .hierarchy-select, .hierarchy-row .hierarchy-component { display: flex; align-items: center; flex: 1; min-width: 0; height: 28px; gap: 4px; padding: 0 4px; border: 1px solid transparent; border-radius: var(--radius-sm); background: transparent; color: var(--text); text-align: left; }
.hierarchy-row .hierarchy-select > span, .hierarchy-row .hierarchy-component > span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; }
.hierarchy-row small { flex-shrink: 0; color: var(--text-soft); }
.hierarchy-row button[aria-pressed="true"], .hierarchy-row button[aria-pressed="mixed"] { background: var(--accent-soft); border-color: var(--accent); }
.hierarchy-row button:hover { background: var(--surface-muted); }
.hierarchy-row .icon-button, .hierarchy-disclosure { display: grid; place-items: center; width: 28px; height: 28px; min-width: 28px; flex-shrink: 0; border: 0; background: transparent; color: var(--text); }
.hierarchy-row button[aria-pressed="mixed"] { border-style: dashed; }
.hierarchy-indent { width: 28px; flex-shrink: 0; }
.component-details { display: flex; flex-direction: column; max-height: calc(100dvh - 32px); }
@media (any-pointer: coarse), (max-width: 840px) {
  .project-browser .entry-row { border-width: 0; padding: 0; }
  .hierarchy-row { padding: 0 4px; }
  .hierarchy-row .icon-button, .hierarchy-disclosure { width: 44px; height: 44px; min-width: 44px; }
  .hierarchy-row .hierarchy-select, .hierarchy-row .hierarchy-component { height: 44px; }
  .hierarchy-indent { width: 44px; }
  .hierarchy-warning-summary { min-height: 44px; }
}

.hierarchy-shell { display: flex; flex-direction: column; flex: 1; min-height: 0; overflow: hidden; }

.minimization-tools { display: flex; }
.minimization-panel { position: fixed; z-index: 70; box-sizing: border-box; overflow: auto; overscroll-behavior: contain; padding: 12px; border: 1px solid var(--border); border-radius: 10px; background: var(--surface); color: var(--text); box-shadow: 0 8px 30px #0003; font-size: 12px; line-height: 1.5; overflow-wrap: anywhere; }
.minimization-heading { position: sticky; top: -12px; z-index: 1; display: flex; align-items: center; justify-content: space-between; gap: 8px; background: var(--surface); }
.minimization-heading h2 { font-size: 15px; margin: 0; }
.minimization-panel button, .minimization-panel select, .minimization-panel input[type="number"] { min-height: 44px; min-width: 44px; max-width: 100%; border: 1px solid var(--border); border-radius: 6px; padding: 6px 8px; background: var(--surface); color: var(--text); font: inherit; }
.minimization-panel button:disabled { opacity: .55; }
.minimization-panel :focus-visible { outline: 2px solid var(--focus); outline-offset: 2px; }
.minimization-panel fieldset { border: 1px solid var(--border); padding: 8px; margin: 10px 0; min-width: 0; }
.minimization-panel fieldset > label:not(.minimization-check) { display: grid; gap: 4px; }
.minimization-check { display: flex; gap: 8px; align-items: center; min-height: 44px; cursor: pointer; }
.minimization-check input { flex: none; width: 18px; height: 18px; }
.minimization-check span { min-width: 0; }
.minimization-check small { display: block; color: var(--text-soft); }
.minimization-context { max-height: 230px; overflow: auto; }
.minimization-metrics { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 5px 8px; }
.minimization-metrics dd { margin: 0; }
.minimization-actions { display: flex; flex-wrap: wrap; gap: 6px; margin: 10px 0; }
.minimization-panel progress { display: block; width: 100%; margin: 8px 0; }
.minimization-panel .primary-button { background: var(--action); color: var(--on-action); }


.archive-compatibility summary {
  min-height: 32px;
  padding: 8px 0;
  font-size: 12px;
  line-height: 16px;
  cursor: pointer;
}
.archive-compatibility summary:focus-visible {
  outline: 2px solid var(--focus);
  outline-offset: 2px;
}
.archive-compatibility label {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 32px;
  font-size: 12px;
}
.archive-compatibility input { width: 16px; height: 16px; }
@media (any-pointer: coarse), (max-width: 840px) {
  .archive-compatibility summary { min-height: 44px; padding: 14px 0; }
  .archive-compatibility label { min-height: 44px; }
}
.app-shell:has(> .camera-recovery) { grid-template-rows: 52px auto minmax(0, 1fr); }
.camera-recovery {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  min-height: 44px;
  padding: 4px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface-muted);
  color: var(--text);
  font-size: 12px;
}
:root { --camera-recovery-height: 0px; }
.camera-recovery > svg { flex-shrink: 0; color: var(--warning); }
.camera-recovery-message { flex: 1; min-width: 0; overflow-wrap: anywhere; }
.camera-recovery button {
  flex-shrink: 0;
  min-width: 44px;
  min-height: 44px;
  padding: 5px 10px;
  border: 1px solid var(--border-strong);
  border-radius: var(--radius-sm);
  color: var(--text);
  background: var(--surface);
  font: inherit;
}
.camera-recovery button[aria-disabled="true"] { opacity: 0.6; cursor: default; }
.camera-recovery-spinner { animation: spin 800ms linear infinite; }
@media (prefers-reduced-motion: reduce) { .camera-recovery-spinner { animation: none; } }
.surface-manager {
  top: calc(72px + var(--camera-recovery-height, 0px));
  height: min(720px, calc(100dvh - 88px - var(--camera-recovery-height, 0px)));
  max-height: calc(100dvh - 88px - var(--camera-recovery-height, 0px));
}

.empty-edit-recovery { width: min(360px, 100%); max-height: 45vh; overflow: auto; text-align: left; padding: 10px; border: 1px solid var(--border); border-radius: 8px; background: var(--surface); }
.empty-edit-recovery button {
  min-height: 44px; max-width: 100%; white-space: normal;
  padding: var(--space-2) var(--space-3); color: var(--text); background: var(--surface);
  border: 1px solid var(--border); border-radius: var(--radius-sm); cursor: pointer;
}
.project-stage.has-edit-recovery {
  max-block-size: 100%; max-inline-size: 100%; min-block-size: 0;
  overflow: auto; overscroll-behavior: contain; padding: var(--space-4);
}
.project-stage.has-edit-recovery > * { flex-shrink: 0; }
.project-stage.has-edit-recovery h1 { max-inline-size: 100%; }
.project-stage.has-edit-recovery .empty-edit-recovery { max-height: none; overflow: visible; }
