import { expect, test, type Page } from "@playwright/test";
import type { Project } from "../../apps/web/src/api/types";
import { prepare } from "../../tests/e2e/support/interactions";
import { openInspectorTools, openLigandInformation } from "../../tests/e2e/support/navigation";

// Observation collection for the existing collapse/remount acceptance requirement.
// A passing collection proves basic keyboard reachability, not a particular
// autofocus destination, satisfactory navigation length or reading-position policy.
async function focusSnapshot(page: Page) {
  return page.evaluate(() => {
    const active = document.activeElement;
    if (!(active instanceof HTMLElement)) return null;
    return {
      tag: active.tagName, id: active.id, role: active.getAttribute("role"),
      label: active.getAttribute("aria-label"), title: active.getAttribute("title"),
      text: active.matches("button, a, summary") ? active.textContent?.trim().slice(0, 120) : null,
      tabIndex: active.tabIndex,
    };
  });
}

async function scrollSnapshot(page: Page) {
  return page.locator(".project-inspector .inspector-scroll").evaluate(node => ({
    top: node.scrollTop, height: node.scrollHeight, viewport: node.clientHeight,
    openDisclosures: [...node.querySelectorAll("details[open] summary")].map(summary => summary.textContent?.trim()),
  }));
}

async function focusableCount(page: Page) {
  return page.evaluate(() => [...document.querySelectorAll(
    "a[href], area[href], button, input, select, textarea, iframe, summary, [tabindex], [contenteditable=true]",
  )].filter(node => node instanceof HTMLElement && node.tabIndex >= 0
    && !("disabled" in node && node.disabled) && !node.closest("[inert]")
    && node.getClientRects().length > 0 && getComputedStyle(node).visibility !== "hidden").length);
}

test("observes ordinary desktop keyboard recovery and reading position through Inspector collapse", async ({ page, request }, info) => {
  test.setTimeout(120_000);
  const records: object[] = [];
  info.annotations.push({ type: "scope", description: "Desktop observation collection only; independent UX interpretation and final native qualification remain required." });
  try {
    const project = await prepare(page, request, [{ name: "collapse-focus.smi", mimeType: "chemical/x-daylight-smiles",
      buffer: Buffer.from("CCO ethanol\n") }], "Inspector keyboard recovery observation");
    const endpoint = `/api/v1/projects/${project.id}`;
    const before = await (await request.get(endpoint)).json() as Project;
    const entry = before.entries[0];
    const original = await (await request.get(`${endpoint}/entries/${entry.id}/original`)).body();
    const frame = page.getByRole("region", { name: "Project inspector", exact: true });
    const panel = page.locator('[data-panel-id="inspector-panel"]');
    const separator = page.getByRole("separator", { name: "Resize inspector", exact: true });
    await expect(panel).toHaveAttribute("data-panel-size", "22.0");
    await separator.focus(); await page.keyboard.press("ArrowRight");
    await expect(panel).toHaveAttribute("data-panel-size", "17.0");
    await openLigandInformation(page);
    await frame.getByRole("combobox", { name: "Entry", exact: true }).selectOption(entry.id);

    for (const theme of ["light", "dark"] as const) {
      const themeControl = page.getByRole("button", { name: `Use ${theme} theme`, exact: true });
      if (await themeControl.isVisible()) await themeControl.click();
      await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
      for (const view of ["ligand", "tools"] as const) {
        if (view === "ligand") await openLigandInformation(page); else await openInspectorTools(page);
        const heading = view === "ligand" ? "Ligand information" : "Selection";
        await expect(frame.getByRole("heading", { name: heading, exact: true })).toBeVisible();
        await frame.locator(".inspector-scroll").hover();
        await page.mouse.wheel(0, 300);
        await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
        const collapse = frame.getByRole("button", { name: "Collapse inspector", exact: true });
        await collapse.focus(); await expect(collapse).toBeFocused();
        const preCollapse = { focus: await focusSnapshot(page), scroll: await scrollSnapshot(page) };
        await page.keyboard.press("Enter");
        await expect(frame).toBeHidden();
        // Do not call focus, click, navigation helpers or scroll helpers between
        // Collapse and these observations. Only ordinary Tab/Enter may reopen it.
        const postCollapse = await focusSnapshot(page);
        const expand = page.getByRole("button", { name: "Expand inspector", exact: true });
        await expect(expand).toBeVisible();
        const budget = await focusableCount(page) + 1;
        const sequence = [postCollapse];
        let reached = await expand.evaluate(node => node === document.activeElement);
        for (let step = 0; !reached && step < budget; step++) {
          await page.keyboard.press("Tab");
          sequence.push(await focusSnapshot(page));
          reached = await expand.evaluate(node => node === document.activeElement);
        }
        const record = { theme, view, preCollapse, postCollapse, budget, sequence, reachedExpand: reached,
          tabsToExpand: sequence.length - 1, postReopen: null as object | null, nextNavigation: null as object | null };
        records.push(record);
        await info.attach(`collapsed-${theme}-${view}`, { body: await page.screenshot(), contentType: "image/png" });
        expect(reached, "Expand is reachable within one observed document focus cycle").toBe(true);
        await page.keyboard.press("Enter");
        await expect(frame).toBeVisible();
        await expect(frame.getByRole("heading", { name: heading, exact: true })).toBeVisible();
        await expect(panel).toHaveAttribute("data-panel-size", "17.0");
        record.postReopen = { focus: await focusSnapshot(page), scroll: await scrollSnapshot(page),
          size: await panel.getAttribute("data-panel-size") };
        await info.attach(`reopened-${theme}-${view}`, { body: await page.screenshot(), contentType: "image/png" });
        await page.keyboard.press("Tab");
        record.nextNavigation = { focus: await focusSnapshot(page), scroll: await scrollSnapshot(page) };
        // Context inspection helpers resume only after all focus observations.
        await openLigandInformation(page);
        await expect(frame.getByRole("combobox", { name: "Entry", exact: true })).toHaveValue(entry.id);
      }
    }
    expect(records).toHaveLength(4);
    const after = await (await request.get(endpoint)).json() as Project;
    expect(after.revision).toBe(before.revision);
    expect(after.entries.map(item => ({ id: item.id, current: item.current_artifact_id, designation: item.ligand_designation })))
      .toEqual(before.entries.map(item => ({ id: item.id, current: item.current_artifact_id, designation: item.ligand_designation })));
    expect(await (await request.get(`${endpoint}/entries/${entry.id}/original`)).body()).toEqual(original);
  } finally {
    await info.attach("ordinary-keyboard-collapse-observations", { body: JSON.stringify(records), contentType: "application/json" });
  }
});
