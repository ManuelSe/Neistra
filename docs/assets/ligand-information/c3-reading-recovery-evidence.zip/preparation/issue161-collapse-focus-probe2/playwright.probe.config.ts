import { defineConfig, devices } from "@playwright/test";
import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import base from "../../playwright.config";

const root = process.cwd();
const servers = base.webServer ? Array.isArray(base.webServer) ? base.webServer : [base.webServer] : [];
const listing = process.argv.includes("--list");
const output = resolve(process.env.NEISTRA_FOCUS_PROBE_OUTPUT ?? ".issue-11-evidence/issue161-collapse-focus-probe-output");

if (!listing) {
  if (process.env.NEISTRA_FOCUS_PROBE_ALLOW_RUN !== "1"
    || !process.env.NEISTRA_E2E_DATA_DIR?.startsWith("/tmp/neistra161-collapse-focus-")
    || existsSync(process.env.NEISTRA_E2E_DATA_DIR)
    || !output.startsWith(resolve(root, ".issue-11-evidence/issue161-collapse-focus-") )
    || existsSync(output)
    || ["NEISTRA_E2E_API_PORT", "NEISTRA_E2E_WORKER_PORT", "NEISTRA_E2E_WEB_PORT"]
      .some(key => !process.env[key])) {
    throw new Error("Observation requires an explicit run flag, fresh owned store/output and three isolated ports.");
  }
  const gateRoot = "/datadisk/dev/neistra-worktrees/issue-160-merged-qualification2";
  const gate = JSON.parse(readFileSync(resolve(gateRoot, "docs/assets/ligand-profiles/c4-master2-gate.json"), "utf8"));
  if (!gate.complete || gate.steps.length !== 43 || gate.steps.some((step: { exit_code: number }) => step.exit_code !== 0)) {
    throw new Error("The actual merged #160 campaign must complete first.");
  }
  const cleanup = JSON.parse(readFileSync(resolve(gateRoot, ".issue-11-evidence/issue160-c4-master2-run1/closed-raw-copy-receipt.json"), "utf8"));
  if (!cleanup.positive_closed || cleanup.runner_exit_code !== 0) {
    throw new Error("Positive owned cleanup and raw copies must complete first.");
  }
  const helper = readFileSync(resolve(root, "docs/assets/ligand-information/qualification.py.txt"), "utf8");
  const pin = helper.match(/^BASELINE_PROVENANCE_SHA256(?:\s*:[^=\n]+)?\s*=\s*["']([a-f0-9]{64})["']/m)?.[1];
  const provenanceBody = readFileSync(resolve(root, "docs/assets/ligand-information/preceding-v0.38.0/provenance.json"));
  const provenance = JSON.parse(provenanceBody.toString("utf8"));
  const published = provenance.publication_verification;
  if (!pin || createHash("sha256").update(provenanceBody).digest("hex") !== pin
    || provenance.predecessor.tag !== "v0.38.0" || provenance.predecessor.commit !== gate.commit
    || !published.published || published.draft || published.prerelease
    || !published.download.anonymous_request_without_authorization_header || published.download.http_status !== 200
    || published.download.qualified_master !== gate.commit) {
    throw new Error("Use the independently verified published #160 predecessor before this observation.");
  }
}

export default defineConfig({
  ...base,
  testDir: resolve(root, ".issue-11-evidence/issue161-collapse-focus-probe2"),
  testMatch: "collapse-focus.probe.spec.ts",
  fullyParallel: false,
  workers: 1,
  outputDir: output,
  projects: [{ name: "desktop-collapse-observation", use: { ...devices["Desktop Chrome"],
    viewport: { width: 900, height: 600 }, deviceScaleFactor: 1, isMobile: false, hasTouch: false } }],
  webServer: servers.map(server => ({ ...server, cwd: root, reuseExistingServer: false })),
});
