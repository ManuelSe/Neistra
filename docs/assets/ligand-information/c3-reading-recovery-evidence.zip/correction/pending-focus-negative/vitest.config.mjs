import base from "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/vite.config.ts";
import { mergeConfig } from "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/node_modules/vitest/dist/config.js";
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
const target="/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/App.tsx";
const hash = value => createHash("sha256").update(value).digest("hex");
const plugin={name:"pending-resume-negative",enforce:"pre",load(id){
 if(id.split("?")[0]!==target)return null;
 const original=readFileSync(target,"utf8");
 if(hash(original)!=="0aa171321354fba3dead9e87a395400fc14043f90444185470ded2645e75b16d")throw Error("Actual App changed");
 const code=original.replace(".inspector-scroll[data-inspector-reading-resume=\"true\"]",".inspector-scroll[data-inspector-reading-resumed=\"true\"]");
 if(code===original)throw Error("Negative seam not found");
 writeFileSync("/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-reading-recovery-correction1/pending-focus-negative/virtual-source.json",JSON.stringify({actual_sha256:hash(original),virtual_sha256:hash(code),only_resume_selector_reverted:true}));
 return code;
}};
export default mergeConfig(base,{root:"/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web",plugins:[plugin],test:{include:["src/test/ligand-information-opening-focus.test.tsx"],reporters:["json"],outputFile:"/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-reading-recovery-correction1/pending-focus-negative/results.json"}});
