import base from "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/vite.config.ts";
import { mergeConfig } from "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/node_modules/vitest/dist/config.js";
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
const target="/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/components/inspectorReadingPosition.ts";const hash=value=>createHash("sha256").update(value).digest("hex");
const plugin={name:"focusin-yield-negative",enforce:"pre",load(id){
 if(id.split("?")[0]!==target)return null;
 const original=readFileSync(target,"utf8");if(hash(original)!=="52965b5cda965db9dd36509cffd11e53fdc926ee3908fd652c6b1d62f55e2bd0")throw Error("Actual hook changed");
 const code=original.replace("    owner.addEventListener(\"focusin\", userIntent);\n","").replace("      owner.removeEventListener(\"focusin\", userIntent);\n","");
 writeFileSync("/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-reading-recovery-correction1/pending-entry-focus-negative/virtual-source.json",JSON.stringify({actual_sha256:hash(original),virtual_sha256:hash(code),only_focusin_yield_removed:true}));return code;
}};
export default mergeConfig(base,{root:"/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web",plugins:[plugin],test:{include:["src/test/ligand-information-opening-focus.test.tsx"],reporters:["json"],outputFile:"/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-reading-recovery-correction1/pending-entry-focus-negative/results.json"}});
