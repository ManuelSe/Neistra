"""Journal lossless relocation of audited, owned, untracked C4 label assets."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import runpy
import stat
import subprocess

INDEX_SHA = "12a7ff25ea2cd9e2357635e72c1cf4ce1e4543be99f75a07eba194320d1b2b54"
CAPTURE_SHA = "80b32897269d1386a3e09438ec074ffb51c6187471431902c3b639de1bc82120"


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def save(path, value):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def inventory(path):
    result = {}
    for body in ([path] if path.is_file() else [path, *sorted(path.rglob("*"))]):
        assert not body.is_symlink()
        value = body.stat()
        assert stat.S_ISREG(value.st_mode) or stat.S_ISDIR(value.st_mode)
        identity = {"device": value.st_dev, "inode": value.st_ino,
                    "mode": value.st_mode, "mtime_ns": value.st_mtime_ns,
                    "kind": "file" if body.is_file() else "directory"}
        if body.is_file():
            identity.update(bytes=value.st_size, sha256=sha(body))
        result["." if body == path else body.relative_to(path).as_posix()] = identity
    return result


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--assessment", type=Path, required=True)
parser.add_argument("--assessment-sha256", required=True)
args = parser.parse_args()
root = Path.cwd().resolve()
assets = root / "docs/assets/ligand-information"
index = assets / "c4-candidate4-forensics-index.json"
capture_path = root / ".issue-11-evidence/issue161-c4-candidate4-retention1/capture.json"
assert sha(index) == INDEX_SHA and sha(capture_path) == CAPTURE_SHA
assert sha(assets / "release-evidence.py.txt") == "b37ed00d0a217eed1de6aa98ab919efb7a2c18ada18a850d26fb18e4d67642f2"
assessment_path = args.assessment
assert assessment_path.is_absolute() and assessment_path.resolve() == assessment_path
assert not assessment_path.is_symlink() and sha(assessment_path) == args.assessment_sha256
assessment = json.loads(assessment_path.read_bytes())
assert assessment["verdict"] == "PASS" and assessment["candidate"]["index_sha256"] == INDEX_SHA
assert assessment["scope"] == "Six failed-C4 parts, retained original trees, recursive ZIPs/manifests, source/authority locators and finite sealer-completion deliverable."
assert subprocess.check_output(["git", "--no-optional-locks", "rev-parse", "HEAD"], text=True).strip() == "1ced4b0018222e06c814bdc8a0ed9b16de8eb9d9"
capture = json.loads(capture_path.read_bytes())
assert len(capture["files"]) == 9058 and len(capture["empty_directories"]) == 259
assert isinstance(capture["trees"], dict) and all(isinstance(value, str) for value in capture["trees"].values())
tracked = set(subprocess.check_output(["git", "--no-optional-locks", "ls-files"], text=True).splitlines())
entries = [assets / name for name in capture["original_asset_files"]
           if (assets / name).relative_to(root).as_posix() not in tracked]
entries.append(assets / "c4-candidate4-native")
assert len(entries) == len(set(entries)) == 62
assert sum(path.is_dir() for path in entries) == 1
assert index not in entries and (assets / "c4-candidate4-recipe.json") not in entries
assert all(path.exists() and not path.is_symlink() for path in entries)
out = root / ".issue-11-evidence/issue161-failed-c4-candidate4-original-relocation1"
assert not out.exists()
assert subprocess.run(["git", "check-ignore", "--quiet", str(out)]).returncode == 0
before = {path.name: inventory(path) for path in entries}
assert all(path.stat().st_dev == out.parent.stat().st_dev for path in entries)
out.mkdir()
dest = out / "retained-original-label-assets"
dest.mkdir()
planned = [{"old": str(path), "new": str(dest / path.name), "rows": before[path.name]} for path in entries]
save(out / "preflight.json", {"index_sha256": INDEX_SHA, "capture_sha256": CAPTURE_SHA,
     "assessment": str(assessment_path), "assessment_sha256": args.assessment_sha256,
     "moves": planned, "source_script_sha256": sha(Path(__file__))})
journal = out / "moves.jsonl"
with journal.open("x", encoding="utf-8") as log:
    for row in planned:
        old, new = Path(row["old"]), Path(row["new"])
        assert inventory(old) == row["rows"] and not new.exists()
        os.rename(old, new)
        assert inventory(new) == row["rows"] and not old.exists()
        log.write(json.dumps({"old": str(old), "new": str(new), "verified": True}) + "\n")
        log.flush()
        os.fsync(log.fileno())


def resolve(path):
    matches = [row for row in planned if path == Path(row["old"]) or path.is_relative_to(Path(row["old"]))]
    assert len(matches) <= 1
    if not matches:
        return path
    row = matches[0]
    return Path(row["new"]) / path.relative_to(Path(row["old"]))


for row in capture["files"]:
    path = resolve(Path(row["original"]))
    value = path.stat()
    assert path.is_file() and not path.is_symlink()
    assert (value.st_size, value.st_mode, value.st_mtime_ns, sha(path)) == (row["bytes"], row["mode"], row["mtime_ns"], row["sha256"])
for row in capture["empty_directories"]:
    path = resolve(Path(capture["trees"][row["kind"]]) / row["path"])
    assert path.is_dir() and not any(path.iterdir())
    assert (path.stat().st_mode, path.stat().st_mtime_ns) == (row["mode"], row["mtime_ns"])
assert sha(index) == INDEX_SHA and sha(capture_path) == CAPTURE_SHA
readback = {"recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "operation": "Same-filesystem rename after independent forensic package audit PASS",
    "map": planned, "top_level_entries": len(planned),
    "relocated_files": sum(row["kind"] == "file" for rows in before.values() for row in rows.values()),
    "relocated_bytes": sum(row.get("bytes", 0) for rows in before.values() for row in rows.values()),
    "all_before_after_device_inode_mode_mtime_bytes_SHA_equal": True,
    "capture_original_files_resolved": len(capture["files"]),
    "capture_empty_directories_resolved": len(capture["empty_directories"]),
    "index_sha256": INDEX_SHA, "capture_sha256": CAPTURE_SHA,
    "immutable_capture_and_index_unchanged": True,
    "do_not_rerun_old_path_readers": True, "originals_retained": True,
    "scientific_qualification_passed": False}
save(out / "readback.json", readback)
helper = runpy.run_path(str(assets / "release-evidence.py.txt"))
packet = helper["archive"]({"relocate.py": Path(__file__),
    "preflight.json": out / "preflight.json", "moves.jsonl": journal,
    "readback.json": out / "readback.json", "architecture-assessment.json": assessment_path},
    assets / "c4-candidate4-relocation-evidence.zip")
assert packet["bytes"] < 83_886_080
save(assets / "c4-candidate4-relocation-readback.json", {
    "scope": "Lossless relocation mapping after complete failed C4 package audit; not qualification",
    "packet": packet, "index_sha256": INDEX_SHA, "capture_sha256": CAPTURE_SHA,
    "top_level_entries": len(planned), "relocated_files": readback["relocated_files"],
    "relocated_bytes": readback["relocated_bytes"], "originals_preserved": True,
    "warning": "Resolve original paths through this mapping. Do not rerun old-path readers. The forensic index describes its original pre-relocation capture state. Separate forensic-part publication remains required."})
print(json.dumps({"complete": True, "packet": packet, "readback": str(out / "readback.json"),
                  "resolved_originals": len(capture["files"])}))
