import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { act, cleanup, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import App from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/App';
import { ApiError, workspacePresentationApi } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/api/client';
import { getLigandInventoryOwner, inventorySourceKey, captureArtifactSource } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/ligands/inventoryQualification';
import { ligandApi } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/ligands/api';
import { ligandPropertyApi } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/ligandProperties/api';
import { PROPERTY_PREFERENCES_KEY, PROPERTY_REGISTRY_KEY } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/ligandProperties/context';
import { PROFILE_REGISTRY_KEY, ligandProfileApi } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/ligandProfiles/api';
import { profileInputAuthority } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/ligandProfiles/authority';
import { evaluateProfile } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/ligandProfiles/evaluate';
import { parseProfileRegistry } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/ligandProfiles/validate';
import { propertyProject, propertyPreferences, propertyAllocation, deferredProperty } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/test/ligand-properties-fixtures';
import { proteinProjection } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/test/molecular-fixtures';
import { structureQueryKey } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/structures/query';
import { useWorkspaceStore } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/store/workspace';
import { useNavigationStore } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/store/navigation';
import { useSelectionStore } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/store/selection';
import { useEditingStore } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/store/editing';
import { useMinimizationStore } from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/minimization/store';
import metadata from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/tests/fixtures/profiles/registry.json';
import oracle from '/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/tests/fixtures/profiles/boundaries.json';
const seen = vi.hoisted(() => ({ properties: null as any, controls: null as any }));
vi.mock('/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/components/WorkspaceCanvas', () => ({ WorkspaceCanvas: () => null }));
vi.mock('/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/components/LowerPanel', () => ({ LowerPanel: () => null }));
vi.mock('/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/components/ProjectInspector', () => ({ ProjectInspector: (props: any) => props.ligandControls }));
vi.mock('/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/components/LigandProperties', async original => {
 const actual = await original<any>(); return { ...actual, LigandProperties: (props: any) => { seen.properties = props; return <actual.LigandProperties {...props} />; } };
});
vi.mock('/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/components/LigandDesignationControls', async original => {
 const actual = await original<any>(); return { ...actual, LigandDesignationControls: (props: any) => { seen.controls = props; return <actual.LigandDesignationControls {...props} />; } };
});
const registry = parseProfileRegistry(metadata), definitions = { ...registry.descriptor_method, definitions: [...registry.descriptors] };
let client: QueryClient;
const settle = async () => { await act(async () => { for (let i=0;i<30;i++) await Promise.resolve(); }); };
function result(id: string, body: any, status = 'ready') {
 return { project_id: id, entries: [{ source: structuredClone(body.entries[0]), binding_key: 'b'.repeat(64), status, reason: null, progress: status === 'ready' ? 100 : 0,
 report: status === 'ready' ? { schema_version: 1, input_hash: 'c'.repeat(64), ...registry.descriptor_method, created_at: '2026-11-17T00:00:00Z', model_status: 'qualified', model_reason: null,
 contains_formally_charged_atoms: false, provenance: ['Controlled source-qualified transport'], coverage: body.descriptor_ids,
 values: body.descriptor_ids.map((id: string) => ({ descriptor_id: id, status: 'ready', reason: null, value: (oracle.base_values as any)[id] })) } : null }] };
}
beforeEach(() => {
 localStorage.clear(); vi.restoreAllMocks(); seen.properties=null;seen.controls=null;
 useSelectionStore.getState().setProject(null);useNavigationStore.getState().setProject(null);useEditingStore.getState().setProject(null);useMinimizationStore.getState().setProject(null);
 vi.spyOn(workspacePresentationApi,'read').mockResolvedValue({schema_version:1,revision:0,camera:null,updated_at:null});
 vi.spyOn(ligandProfileApi,'registry').mockResolvedValue(registry);vi.spyOn(ligandPropertyApi,'registry').mockResolvedValue(definitions);
 vi.spyOn(ligandPropertyApi,'preferences').mockResolvedValue(propertyPreferences);vi.spyOn(ligandPropertyApi,'allocate').mockImplementation(id=>Promise.resolve(propertyAllocation(id)));
 vi.spyOn(ligandPropertyApi,'release').mockResolvedValue({});vi.spyOn(ligandPropertyApi,'read').mockImplementation((id,body)=>Promise.resolve(result(id,body) as any));
 vi.spyOn(ligandPropertyApi,'demand').mockImplementation((id,_consumer,body)=>Promise.resolve(result(id,body,'pending') as any));
});
afterEach(()=>{cleanup();seen.properties?.session.deactivate(); if(client){getLigandInventoryOwner(client).deactivate();client.clear();}vi.restoreAllMocks();});
async function setup() {
 const project=propertyProject(), entry=project.entries[0];project.has_uncheckpointed_changes=false;
 client=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity},mutations:{retry:false}}});
 client.setQueryData(['project',project.id],project);client.setQueryData(PROFILE_REGISTRY_KEY,registry);client.setQueryData(PROPERTY_REGISTRY_KEY,definitions);
 client.setQueryData(PROPERTY_PREFERENCES_KEY,{...propertyPreferences,enabled_categories:['composition']});client.setQueryData(structureQueryKey(project.id,entry.id,entry.current_artifact_id),proteinProjection());
 vi.spyOn(globalThis,'fetch').mockImplementation(input=>{const url=typeof input==='string'?input:input instanceof URL?input.toString():input.url;
  return Promise.resolve(Response.json(url.endsWith(`/projects/${project.id}`)?project:url==='/api/v1/projects'?[{...project,entry_count:1}]:[]));});
 const candidate={candidate_key:'candidate',atom_ids:[...entry.ligand_designation.atom_ids],residue_ids:[1],component_ids:['LIG'],label:'Exact ligand',locations:[],boundary_status:'qualified',potential_ligand:true,reason_codes:[],provenance:[],heavy_atom_count:3,formal_charge:0,formula:'C2H6O',molecular_weight:46.069,chemistry_status:'qualified',chemistry_reason:null,chemical_input_hash:'chemical',occurrence_count:null,occurrence_basis:null,occurrence_reason:'occurrence_count_not_qualified'};
 const inventory={project_id:project.id,entry_id:entry.id,artifact_id:entry.current_artifact_id,designation:entry.ligand_designation,input_hash:'inventory',resolver_version:'ligand-instance-v3',total:1,offset:0,limit:12,designated_candidate:candidate,warnings:[],selectable_candidate_keys:['candidate'],candidates:[candidate]};
 vi.spyOn(ligandApi,'candidates').mockResolvedValue(inventory as any);vi.spyOn(ligandApi,'depiction').mockResolvedValue({entry_id:entry.id,artifact_id:entry.current_artifact_id,candidate_key:'candidate',status:'ready',reason:null,input_hash:'chemical',cache_key:'draw',artifact:{id:'drawing',filename:'ligand.svg',media_type:'image/svg+xml',sha256:'digest',size:1,download_url:'/drawing'},implementation:'ligand-2d-v1',library_version:'pinned'} as any);
 useWorkspaceStore.setState({activeProjectId:project.id,mobilePanel:null});const rendered=render(<QueryClientProvider client={client}><App /></QueryClientProvider>);
 await waitFor(()=>expect(useSelectionStore.getState().projectId).toBe(project.id));act(()=>useNavigationStore.getState().inspect(project.id,entry.id));
 await waitFor(()=>expect(seen.properties?.state.target).toBeTruthy());await userEvent.selectOptions(screen.getByRole('combobox',{name:'Profile',exact:true}),'ro5');await screen.findByText('Within profile criteria.');
 if ('/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar'.includes('issue-161')) expect(document.querySelector('.comparison-shape')).not.toBeNull();
 const owner=getLigandInventoryOwner(client), source=captureArtifactSource(project.id,entry),key=inventorySourceKey(project,entry);
 const capture=()=>profileInputAuthority(seen.properties.state,seen.properties.session,seen.properties.profiles.selection,registry,'ro5').capture();
 const evaluate=()=>evaluateProfile(registry,'ro5',profileInputAuthority(seen.properties.state,seen.properties.session,seen.properties.profiles.selection,registry,'ro5'));
 return {project,entry,owner,source,key,capture,evaluate,...rendered};
}
describe('Independent actual App source authority propagation',()=>{
 it('retires profile capture before notification; actual Use promise publishes and returns without automatic retry',async()=>{
  const state=await setup(),captured=state.capture(),session=seen.properties.session,target=seen.properties.state.target;
  const beforeReads=vi.mocked(ligandPropertyApi.read).mock.calls.length;expect(state.evaluate().status).toBe('pass');expect(captured.isCurrent()).toBe(true);
  let observed=false;const unsubscribe=state.owner.subscribe(()=>{observed=true;expect(captured.isCurrent()).toBe(false);expect(session.view(target).current).toBeUndefined();});
  vi.spyOn(ligandApi,'designate').mockRejectedValueOnce(new ApiError(409,'artifact_integrity_error','Controlled captured Use physical failure'));
  await act(async()=>{await seen.controls.onDesignate(state.entry,'candidate','inventory').catch(()=>undefined)});unsubscribe();
  expect(observed).toBe(true);expect(state.owner.qualification(state.key).blocked).toBe(true);expect(state.evaluate().status).toBe('unavailable');
  expect(screen.queryByText('Within profile criteria.')).toBeNull();expect(document.querySelector('.comparison-shape')).toBeNull();await settle();
  expect(ligandPropertyApi.read).toHaveBeenCalledTimes(beforeReads);expect(ligandPropertyApi.allocate).not.toHaveBeenCalled();expect(ligandPropertyApi.demand).not.toHaveBeenCalled();
  await act(async()=>{await client.refetchQueries({queryKey:['ligand-candidates']})});expect(state.owner.qualification(state.key).blocked).toBe(false);expect(session.view(target).current).toBeUndefined();expect(captured.isCurrent()).toBe(false);
  await act(async()=>session.retry(target));await screen.findByText('Within profile criteria.');expect(state.evaluate().status).toBe('pass');expect(captured.isCurrent()).toBe(false);
 });
 it('forwards physical property result once; fresh numeric recovery keeps candidate blocked and rejects malformed provenance',async()=>{
  const state=await setup(),session=seen.properties.session,target=seen.properties.state.target,captured=state.capture();let events=0;const stop=state.owner.subscribeVerificationFailures(()=>events++);
  const body={entries:[target.source],descriptor_ids:target.descriptorIds},failure=result(target.projectId,body,'failed') as any;
  failure.entries[0].source_failure={source_identity:{project_id:state.source.projectId,entry_id:state.source.entryId,current_artifact_id:state.source.currentArtifactId,original_artifact_id:state.source.originalArtifactId},source_verification:'original',reason:'artifact_unavailable'};
  vi.mocked(ligandPropertyApi.read).mockResolvedValueOnce(failure);await act(async()=>session.retry(target));await settle();
  expect(events).toBe(1);expect(captured.isCurrent()).toBe(false);expect(state.owner.qualification(state.key).blocked).toBe(true);expect(state.evaluate().status).toBe('unavailable');
  await act(async()=>session.retry(target));await screen.findByText('Within profile criteria.');expect(state.owner.qualification(state.key).blocked).toBe(true);expect(events).toBe(1);
  const bad=structuredClone(failure);bad.entries[0].source_failure.source_identity.original_artifact_id='other';vi.mocked(ligandPropertyApi.read).mockResolvedValueOnce(bad);
  await act(async()=>session.retry(target));await settle();expect(events).toBe(1);stop();
 });
 it('keeps replacement B qualified when captured A promise fails and preserves explicit Cancel across hidden presentation',async()=>{
  const state=await setup(),oldCapture=state.capture(),pending=deferredProperty<any>();vi.spyOn(ligandApi,'designate').mockReturnValueOnce(pending.promise);
  let operation:Promise<any>;act(()=>{operation=seen.controls.onDesignate(state.entry,'candidate','inventory').catch(()=>undefined)});
  await waitFor(()=>expect(ligandApi.designate).toHaveBeenCalledTimes(1));
  const b={...state.entry,current_artifact_id:'replacement-B',ligand_designation:{...state.entry.ligand_designation,source_artifact_id:'replacement-B'}},project={...state.project,revision:state.project.revision+1,entries:[b]};
  act(()=>client.setQueryData(['project',project.id],project));await settle();
  await act(async()=>{pending.reject(new ApiError(409,'artifact_integrity_error','Delayed physical A'));await operation});
  await waitFor(()=>expect(seen.properties.state.target.source.source_artifact_id).toBe('replacement-B'));await screen.findByText('Within profile criteria.');
  expect(oldCapture.isCurrent()).toBe(false);expect(state.owner.qualification(state.key).blocked).toBe(true);expect(state.owner.qualification(inventorySourceKey(project,b)).blocked).toBe(false);expect(state.evaluate().status).toBe('pass');
  const target=seen.properties.state.target,session=seen.properties.session;act(()=>session.cancel(target));expect(session.view(target).status).toBe('cancelled');
  act(()=>useWorkspaceStore.setState({rightCollapsed:true,mobilePanel:null}));act(()=>state.owner.recordSourceFailure({source:captureArtifactSource(project.id,b),reason:'artifact_unavailable'}));await settle();
  expect(session.view(target).status).toBe('cancelled');act(()=>useWorkspaceStore.setState({rightCollapsed:false}));expect(session.view(target).status).toBe('cancelled');
  await act(async()=>session.retry(target));await screen.findByText('Within profile criteria.');expect(state.owner.qualification(inventorySourceKey(project,b)).blocked).toBe(true);
 });
});
