import { defineConfig } from '@playwright/test';
import base from '../../playwright.config';
const cwd = "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar";
export default defineConfig({ ...base, testDir: cwd + '/tests/e2e', webServer: (Array.isArray(base.webServer) ? base.webServer : [base.webServer]).filter(Boolean).map(server => ({ ...server, cwd, reuseExistingServer: false })) });
