"""Current frozen source discovery and receipt-chain audit; import starts nothing."""
from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path, PurePosixPath
from typing import Any

PREFIXES = ("apps", "packages", "tests", "tools", "scripts", "patches")
CONFIGS = {"pyproject.toml", "uv.lock", "package.json", "pnpm-lock.yaml", "pnpm-workspace.yaml",
           "playwright.config.ts", "alembic.ini", ".gitattributes", ".gitignore"}
IGNORED_DIRS = {".venv", ".molweave", ".neistra", ".neistra-e2e", ".molweave-e2e",
                ".pytest_cache", ".mypy_cache", ".ruff_cache", "__pycache__", "htmlcov",
                "node_modules", ".playwright", "playwright-report", "test-results", ".rebranding"}
IGNORED_FILES = {".coverage", ".env", ".goal_prompt.txt", ".DS_Store"}


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def map_digest(value: dict[str, str]) -> str:
    return digest(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def relative(name: str) -> PurePosixPath:
    value = PurePosixPath(name)
    assert name and not value.is_absolute() and ".." not in value.parts and str(value) == name
    return value


def regular(path: Path) -> None:
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode) and not path.is_symlink(), f"Nonregular/symlink source: {path}"


def checked_hash(root: Path, name: str) -> str:
    parts = relative(name).parts
    for index in range(1, len(parts)):
        directory = root.joinpath(*parts[:index])
        assert stat.S_ISDIR(directory.lstat().st_mode), f"Nonregular source ancestor: {directory}"
    path = root / name
    regular(path)
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        before = os.fstat(descriptor)
        assert stat.S_ISREG(before.st_mode)
        hasher = hashlib.sha256()
        while block := os.read(descriptor, 1024 * 1024):
            hasher.update(block)
        after = os.fstat(descriptor)
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), f"Source changed while hashing: {name}"
        return hasher.hexdigest()
    finally:
        os.close(descriptor)


def discover(root: Path) -> set[str]:
    """Mirror the existing selected prefixes/config/tools and pinned ignore policy."""
    assert root.resolve() == root and not root.is_symlink()
    names: set[str] = set()

    def visit(directory: Path) -> None:
        assert stat.S_ISDIR(directory.lstat().st_mode)
        for entry in os.scandir(directory):
            path = Path(entry.path)
            name = str(path.relative_to(root))
            metadata = entry.stat(follow_symlinks=False)
            is_directory = stat.S_ISDIR(metadata.st_mode)
            if is_directory and (entry.name in IGNORED_DIRS or entry.name.endswith(".egg-info")
                                 or name in {"apps/web/dist", "apps/web/coverage"}):
                continue
            if entry.name in IGNORED_FILES or entry.name.endswith((".pyc", ".pyo", ".pyd", ".tsbuildinfo")):
                continue
            if is_directory:
                visit(path)
            else:
                assert stat.S_ISREG(metadata.st_mode) and not entry.is_symlink(), f"Nonregular selected source: {name}"
                names.add(name)

    for prefix in PREFIXES:
        directory = root / prefix
        if directory.exists() or directory.is_symlink():
            visit(directory)
    for name in CONFIGS:
        path = root / name
        if path.exists() or path.is_symlink():
            regular(path)
            names.add(name)
    assets = root / "docs/assets"
    if assets.exists():
        for path in assets.rglob("*.py.txt"):
            regular(path)
            names.add(str(path.relative_to(root)))
    return names


def audit_selected(root: Path, expected: dict[str, str], methods: dict[str, str]) -> dict[str, Any]:
    names = discover(root)
    assert names == set(expected), {"added_selected": sorted(names - set(expected)),
                                    "missing_selected": sorted(set(expected) - names)}
    assert set(methods) <= names
    actual = {name: checked_hash(root, name) for name in sorted(names)}
    changed = {name: {"expected": expected[name], "actual": actual[name]}
               for name in actual if actual[name] != expected[name]}
    assert not changed, {"changed_selected_sources": changed}
    observed_methods = {name: actual[name] for name in methods}
    assert observed_methods == methods, "Frozen method source drift"
    return {"source_count": len(actual), "source_digest": map_digest(actual), "sources": actual,
            "method_count": len(methods), "method_digest": map_digest(observed_methods),
            "methods": observed_methods, "no_source_exclusions": True,
            "added_selected_detection": True, "all_selected_regular_no_symlinks": True}


SOURCE_MAP = '.issue-11-evidence/issue161-native-c2-source-integration-preparation9/frozen-source-map.json'
SOURCE_MAP_SHA256 = 'c17f1b7cff1ca5d6be8c6b0a7dbd9632eb7c97126bf97ac80d7f4f158938947f'
SOURCE_DIGEST = '874685e8c151512672bc679c6ca154ab124b6de985f9b5b6e81ea252d7000c8c'
SOURCE_COUNT = 1214
EXPECTED_HEAD = "afe38ec1bdbc8c94159668664abf7684306b9c04"
EXPECTED_REF = "refs/heads/feat/issue-161-ligand-information-sidebar"
RECEIPT_PINS = {'.issue-11-evidence/issue161-verified-source-integration/handoff.json': '5290f74437765972ebfe10bb9c5aa8c41850e034005d0a15e943d718fdf47dd4', '.issue-11-evidence/issue161-verified-source-integration/gate1-actual-enclosing.json': '79d0f76c227fd593c0b9bad9aa56bd9c476b09f00fed71a9897ee92ef93e29ed', '.issue-11-evidence/issue161-source-producer-primary-readback/readback.json': 'a70a228d09126faff9d38b61bffde07f847e684cf300f37ac13840061927458a', '.issue-11-evidence/issue161-source-producer-primary-readback/zip-source-map-readback.json': '14a5a9f141c3063d8a7a104b472e165750849d1fc86e22f577dd2b598a1e3e2d', '.issue-11-evidence/issue161-source-producer-architecture/assessment.json': '6461dfbbf424e951416b9666c947ba92d1e2f747dc8e22c02fa0a6ba99e2f28f', '.issue-11-evidence/issue161-source-producer-science/assessment.json': '21d8157996024a50a0c663b23d80528bb268cc984ceaadf34bdb4f0b93f78158', '.issue-11-evidence/issue161-native-c2/depiction-source-channel/author-handoff.json': 'e24cd97e743a43f3a962040f2d376c0343d077ebec9cc5246dcdd15029f92e2f', '.issue-11-evidence/issue161-native-root/native2/runner.py': '67ffea561d2455b6ece82183aff89d82720b499fd076b04fefe6f64d8593d2bc', '.issue-11-evidence/issue161-native-root/native2/source_guard.py': '1ba570c55c9534418bffde99b618dd711d67effb62ed27847c7fd38c01070eee', '.issue-11-evidence/issue161-native-root/native2/root-actual-enclosing-readback.json': 'ca2bb641cb35f951f15cdd263f2026d6fc690d449ec263bc692ce00dfd6ebd7a', '.issue-11-evidence/issue159-prelaunch-recovery-propagation/handoff.json': '93da9f5eb9513ad5caf467d156e79524330ef195501a09833da4bec87b86644a', '.issue-11-evidence/issue161-c2-prep5-project-visit-diagnosis/assessment.json': 'a59a6e4581688aad9fd306056983f397870bf3ed18a7aef3f5b76844340bd669', '.issue-11-evidence/issue161-native-c2-source-integration-preparation6/statement-move-byte-proof.json': '62bad4db140eee9ccb9f16b177e6f852523f60cfdf3a31e277f8a373080de90f', '.issue-11-evidence/issue161-native-c2-source-integration-preparation6/statement-move-AST-proof.json': '97a60bb9674ad61198335fc603ededadfd6e8b65a04cf643b993c79b4b6e8486', '.issue-11-evidence/issue161-c2-prep6-source-retirement-diagnosis/assessment.json': '49b12bb8e854f7a96bed28da1c00429e91edfae6a44f08e39dcad6b24eccd74c', '.issue-11-evidence/issue161-native-c2-source-integration-preparation7/recovery-wait-byte-proof.json': '3ca385238fb1e10682a157efe82a3846e68c375754643214cdd999d111d1dbf5', '.issue-11-evidence/issue161-native-c2-source-integration-preparation7/recovery-wait-AST-proof.json': 'd2ae17c0de133818497d58433af97cded336ad7061170c92c8ecbb9764b44e00', '.issue-11-evidence/issue161-c2-prep7-numeric-recovery-diagnosis/assessment.json': 'b5c246767864372777a87ff7f00c6472c4127830f6ee8e9a2991afdbde47b358', '.issue-11-evidence/issue161-c2-prep7-numeric-recovery-architecture/assessment.json': '8450ed16b91870fc3ea63b236f00ca0a88930ebddb178a4f045ea733e16be942', '.issue-11-evidence/issue161-native-c2-source-integration-preparation8/phase-plan.json': '1ba5d98fa2f790765588c7f0d245ca6c9c578d3676cbcd416e15358b4119e77d', '.issue-11-evidence/issue161-native-c2-source-integration-preparation8/phase-accounting-byte-proof.json': '47b7629c5a34d9dab2a9e45eceb9aa71390fb0310a0957a8282aee5357d18c80', '.issue-11-evidence/issue161-native-c2-source-integration-preparation8/phase-accounting-AST-proof.json': '4d8b4a0da15c569440426fc935011c1f3cb0bbf8073deda109bef2947cfc2cae', '.issue-11-evidence/issue161-c2-prep8-mobile-complex-diagnosis/assessment.json': '3b5c8d6adb0c0a4df845ad9ab3d804f61d38cb0e5d4f052f3bce1f49c89c4bca', '.issue-11-evidence/issue161-native-c2-source-integration-preparation9/summary-locator-byte-proof.json': '074a5b17f47d54125dad614e2b17855ba612c880ee9155c566dc98263f044958', '.issue-11-evidence/issue161-native-c2-source-integration-preparation9/summary-locator-AST-proof.json': '779d74312787c4943cf991aceef571e40b15ac3a2b193d8563c6047b67b7feca', '.issue-11-evidence/issue161-native-c2-source-integration-preparation9/in-place-retention-contract.json': 'e7ce051e8aaec6be029d72d970f3e592b78b6b82ef6cdd9bb0a5651150e17d94', '.issue-11-evidence/issue161-native-c2-source-integration-preparation9/latest-failed-owned-store.zip': '8a38cc2865bd56fb1452f9b3bd109d5b2aa5dd76e874d8794e83599cc28eba3b'}


def verify_map_bytes(payload: bytes) -> dict[str, str]:
    assert digest(payload) == SOURCE_MAP_SHA256, "Literal root source-map bytes changed"
    expected = json.loads(payload)
    assert len(expected) == SOURCE_COUNT and map_digest(expected) == SOURCE_DIGEST
    return expected


def authoritative_head(root: Path) -> dict[str, str]:
    pointer = (root / ".git").read_text().strip()
    assert pointer.startswith("gitdir: ")
    gitdir = Path(pointer.removeprefix("gitdir: ")).resolve()
    head = (gitdir / "HEAD").read_text().strip()
    assert head == "ref: " + EXPECTED_REF, "Worktree ref changed"
    common = (gitdir / (gitdir / "commondir").read_text().strip()).resolve()
    loose = common / EXPECTED_REF
    if loose.is_file():
        commit = loose.read_text().strip()
    else:
        matches = [line.split()[0] for line in (common / "packed-refs").read_text().splitlines()
                   if line and not line.startswith(("#", "^")) and line.split()[1] == EXPECTED_REF]
        assert len(matches) == 1
        commit = matches[0]
    assert commit == EXPECTED_HEAD, "Exact HEAD changed"
    return {"commit": commit, "ref": EXPECTED_REF, "HEAD_text": head}


SOURCE_DELTA = '.issue-11-evidence/issue161-native-c2-source-integration-preparation9/source-delta.json'
SOURCE_DELTA_SHA256 = '9dcb2137b6c7f7fff61c2634a6b1a70e16b31f0ede8f3a5915b62cc03fc590a2'
PRESERVATION_MANIFEST = '.issue-11-evidence/issue161-native-c2-source-integration-preparation9/prior-preparations-preservation-before.json'
PRESERVATION_MANIFEST_SHA256 = '2276755ce6f6407a30fe11e55380edabd351565e026ccdf817def980b644cfe9'
ORIGINAL_SOURCE_MAP = ".issue-11-evidence/issue161-verified-source-integration/frozen-source-map.json"
ORIGINAL_SOURCE_MAP_SHA256 = "860df2a3ff80ac82d2b7c0492c12407295d5a2add6e74be334e42c15e18a51de"
ORIGINAL_SOURCE_DIGEST = "7d1e9677650c70b07bbbc8a955bc7414fd1683410cba9432fbd0f25d4cfca900"
PREVIOUS_SOURCE_MAP = '.issue-11-evidence/issue161-native-c2-source-integration-preparation8/frozen-source-map.json'
PREVIOUS_SOURCE_MAP_SHA256 = 'fdc400234cd7f80650e290968972ef6c44abf4901a75cf44e707e6bf210fb266'
PREVIOUS_SOURCE_DIGEST = 'c8f08143b6ddd4535e9922eb40e8c929a2f169b66c8d52645a75fcb325740984'
CORRECTED_PATH = "tests/e2e/ligand-information-access.spec.ts"
LIFECYCLE_PATH = "tests/e2e/ligand-information-lifecycle.spec.ts"
APPROVED_CHANGES = {'apps/api/src/neistra_api/job_worker.py': {'after': 'ecb0426cce55490ae740586c0cf95a302a8588f9c2d505c21cf3ca7990711f05', 'before': 'b7972af2864dc83ee111a70d0b432bc9ef3428edd8fe9776f5ee846b572a0c43'}, 'tests/e2e/ligand-information-access.spec.ts': {'after': '5972e4fddedaec6ead1feff4a3e8a3cdad19feeecbc9bef68c0820ad4b39cea4', 'before': '6b05a1b431e4ac160742599c23fa87703216cb1917c159f453f8c0d8c90c166c'}, 'tests/e2e/ligand-information-lifecycle.spec.ts': {'after': '1e8c69852bbad44cb406a7f91f7f5ee2226e74b78ec4d3969370d5bb7c2b405e', 'before': '9a07967d077dbc53eaaff927c4efe75355829987c76a368dd6482c841aa91211'}}

APPROVED_ADDITIONS = {'tests/integration/test_ligand_property_preload_ownership.py': '22bbcb57f3fe5d45dfeb9f814ffcf5cf7bf43568302bc162118d4302cdd8cf16'}
ORIGINAL_SOURCE_COUNT = 1213


def verify_delta_bytes(payload: bytes, expected: dict[str, str], original: dict[str, str]) -> dict[str, Any]:
    assert digest(payload) == SOURCE_DELTA_SHA256, "Literal approved source delta changed"
    change = json.loads(payload)
    assert change["source_count"] == SOURCE_COUNT and change["original_source_count"] == ORIGINAL_SOURCE_COUNT
    assert change["original_source_map_sha256"] == ORIGINAL_SOURCE_MAP_SHA256
    assert change["original_source_digest"] == ORIGINAL_SOURCE_DIGEST
    assert change["previous_preparation8_source_map_sha256"] == PREVIOUS_SOURCE_MAP_SHA256
    assert change["previous_preparation8_source_digest"] == PREVIOUS_SOURCE_DIGEST
    assert change["new_source_map_sha256"] == SOURCE_MAP_SHA256
    assert change["new_source_digest"] == SOURCE_DIGEST
    assert change["added_paths"] == APPROVED_ADDITIONS and change["removed_paths"] == []
    assert change["changed_paths"] == APPROVED_CHANGES
    assert change["lifecycle_line_count_before"] == 473 and change["lifecycle_line_count_after"] == 509
    assert change["previous_lifecycle_line_count"] == 509
    assert change["access_line_count_unchanged"] == 233
    assert change["single_unchanged_statement_moved_before_browser_setup"] is True
    assert change["genuine_current_candidate_response_wait_added"] is True
    assert change["prior_prep7_transient_retry_probe_fix_preserved"] is True
    assert change["candidate_only_noREAD_phase_preserved"] is True
    assert change["automatic_or_explicit_fresh_READ_gate_preinstalled"] is True
    assert change["one_invalid_cross_profile_noREAD_assertion_rephased"] is True
    assert change["monotonic_browser_READ_counter_before_any_hold"] is True
    assert change["only_two_native_summary_locator_targets_changed"] is True
    assert change["all187_assertions_unchanged"] is True
    assert change["in_place_full_retention_no_recursive_rebundle"] is True
    assert change["immediate_previous_changed_paths"] == {LIFECYCLE_PATH: {"before": "386bb41a166441a52858851998530f499dd5885a2ca2fa9248eb0914a6d41484", "after": expected[LIFECYCLE_PATH]}}
    assert len(original) == ORIGINAL_SOURCE_COUNT and len(expected) == SOURCE_COUNT
    assert set(expected) == set(original) | set(APPROVED_ADDITIONS)
    assert not set(original) & set(APPROVED_ADDITIONS)
    assert sorted(name for name in original if original[name] != expected[name]) == sorted(APPROVED_CHANGES)
    for name, meta in APPROVED_CHANGES.items():
        assert original[name] == meta["before"] and expected[name] == meta["after"]
    for name, pinned in APPROVED_ADDITIONS.items():
        assert expected[name] == pinned
    return change


def audit(root: Path) -> dict[str, Any]:
    expected = verify_map_bytes((root / SOURCE_MAP).read_bytes())
    for name, pinned in RECEIPT_PINS.items():
        assert checked_hash(root, name) == pinned, "Frozen receipt-chain drift: " + name
    original_payload = (root / ORIGINAL_SOURCE_MAP).read_bytes()
    assert digest(original_payload) == ORIGINAL_SOURCE_MAP_SHA256
    original = json.loads(original_payload)
    assert map_digest(original) == ORIGINAL_SOURCE_DIGEST
    change = verify_delta_bytes((root / SOURCE_DELTA).read_bytes(), expected, original)
    previous_payload = (root / PREVIOUS_SOURCE_MAP).read_bytes()
    assert digest(previous_payload) == PREVIOUS_SOURCE_MAP_SHA256
    previous = json.loads(previous_payload)
    assert map_digest(previous) == PREVIOUS_SOURCE_DIGEST and len(previous) == SOURCE_COUNT
    assert set(expected) == set(previous)
    assert [name for name in previous if previous[name] != expected[name]] == [LIFECYCLE_PATH]
    assert previous[LIFECYCLE_PATH] == "386bb41a166441a52858851998530f499dd5885a2ca2fa9248eb0914a6d41484"
    assert previous[CORRECTED_PATH] == expected[CORRECTED_PATH]
    assert previous["apps/api/src/neistra_api/job_worker.py"] == expected["apps/api/src/neistra_api/job_worker.py"]
    assert all(previous[name] == pinned for name, pinned in APPROVED_ADDITIONS.items())
    hand = json.loads((root / ".issue-11-evidence/issue161-verified-source-integration/handoff.json").read_text())
    assert hand["source_map_sha256"] == ORIGINAL_SOURCE_MAP_SHA256
    assert hand["source_digest"] == ORIGINAL_SOURCE_DIGEST and hand["source_count"] == ORIGINAL_SOURCE_COUNT
    preservation_payload = (root / PRESERVATION_MANIFEST).read_bytes()
    assert digest(preservation_payload) == PRESERVATION_MANIFEST_SHA256
    preservation = json.loads(preservation_payload)
    assert len(preservation) == 8
    preserved_count = 0
    for prior, files in preservation.items():
        relative(prior)
        for name, meta in files.items():
            assert checked_hash(root, prior + "/" + name) == meta["sha256"], "Preserved attempt changed: " + prior + "/" + name
            assert (root / prior / name).stat().st_size == meta["bytes"]
            preserved_count += 1
    prior3 = root / ".issue-11-evidence/issue161-native-c2-source-integration-preparation3"
    failed = json.loads((prior3 / "actual-receipt.json").read_text())
    outer = json.loads((prior3 / "root-actual-enclosing.json").read_text())
    assert failed["complete"] and failed["actual_child_exit_code"] == 1
    assert failed["cleanup"]["remaining"] == [] and all(failed["cleanup"]["ports_unused"].values())
    assert outer["actual_session"] == 31452 and outer["actual_exit"] == 1
    assert outer["receipt_sha256"] == digest((prior3 / "actual-receipt.json").read_bytes())
    prior5 = root / ".issue-11-evidence/issue161-native-c2-source-integration-preparation5"
    failed5 = json.loads((prior5 / "actual-receipt.json").read_text())
    outer5 = json.loads((prior5 / "actual-enclosing-root.json").read_text())
    assert failed5["complete"] and failed5["actual_child_exit_code"] == 1
    assert failed5["cleanup"]["remaining"] == [] and all(failed5["cleanup"]["ports_unused"].values())
    assert outer5["session_id"] == 7025 and outer5["actual_exit_code"] == 1
    assert failed5["owned_store_snapshot"]["sha256"] == "6ad6cd1b658215a0f717511d04ebf02de4d090b20b45dc270e9ac0f54e3170fd"
    prior6 = root / ".issue-11-evidence/issue161-native-c2-source-integration-preparation6"
    failed6 = json.loads((prior6 / "actual-receipt.json").read_text())
    outer6 = json.loads((prior6 / "actual-enclosing-root.json").read_text())
    assert failed6["complete"] and failed6["actual_child_exit_code"] == 1
    assert failed6["cleanup"]["remaining"] == [] and all(failed6["cleanup"]["ports_unused"].values())
    assert outer6["session_id"] == 52353 and outer6["actual_exit_code"] == 1
    assert outer6["passed_cases"] == 4 and outer6["failed_cases"] == 1 and outer6["unrun_cases"] == 11
    assert failed6["owned_store_snapshot"]["sha256"] == "84b2f5edc43adc54a45e23f32433ea17d9ceed31015cf6f9a95e6bd315a6dd23"
    prior7 = root / ".issue-11-evidence/issue161-native-c2-source-integration-preparation7"
    failed7 = json.loads((prior7 / "actual-receipt.json").read_text())
    outer7 = json.loads((prior7 / "actual-enclosing-root.json").read_text())
    assert failed7["complete"] and failed7["actual_child_exit_code"] == 1
    assert failed7["cleanup"]["remaining"] == [] and all(failed7["cleanup"]["ports_unused"].values())
    assert outer7["session_id"] == 18492 and outer7["actual_exit_code"] == 1
    assert outer7["passed_cases"] == 4 and outer7["failed_cases"] == 1 and outer7["unrun_cases"] == 11
    assert failed7["owned_store_snapshot"]["sha256"] == "334271ad4c9fb4791d54c8f6018786318324883e2a6b086f5cccae44a43275cc"
    prior8 = root / ".issue-11-evidence/issue161-native-c2-source-integration-preparation8"
    failed8 = json.loads((prior8 / "actual-receipt.json").read_text())
    outer8 = json.loads((prior8 / "actual-enclosing-root.json").read_text())
    assert failed8["complete"] and failed8["actual_child_exit_code"] == 1
    assert failed8["cleanup"]["remaining"] == [] and all(failed8["cleanup"]["ports_unused"].values())
    assert outer8["session_id"] == 26077 and outer8["exit_code"] == 1
    assert outer8["native_passed"] == 10 and outer8["failed"] == 1 and outer8["did_not_run"] == 5
    assert failed8["owned_store_snapshot"]["sha256"] == "8a38cc2865bd56fb1452f9b3bd109d5b2aa5dd76e874d8794e83599cc28eba3b"
    result = audit_selected(root, expected, {})
    result["authoritative_HEAD"] = authoritative_head(root)
    result["source_map_sha256"] = SOURCE_MAP_SHA256
    result["receipt_pins"] = RECEIPT_PINS
    result["source_delta_sha256"] = SOURCE_DELTA_SHA256
    result["two_test_oracle_corrections"] = {name: change["changed_paths"][name] for name in (CORRECTED_PATH, LIFECYCLE_PATH)}
    result["verified_worker_correction"] = change["changed_paths"]["apps/api/src/neistra_api/job_worker.py"]
    result["verified_regression_addition"] = change["added_paths"]
    result["prior_attempt_files_preserved"] = preserved_count
    result["prior_attempt_directory_count"] = len(preservation)
    result["no_source_exclusions"] = "All selected runtime/test/config paths and docs/assets/**/*.py.txt; normal documentation excluded by existing policy"
    return result
