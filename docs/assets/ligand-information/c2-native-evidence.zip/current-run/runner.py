"""Bounded C2 runner. Import and offline mode start no services or browser."""
from __future__ import annotations

import argparse
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import signal
import stat
import subprocess
import threading
import time
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
WORKSPACE = Path('/tmp/neistra161-c2-source-integration-native9')
DATA = WORKSPACE / 'e2e'
PORTS = (8470, 8471, 5470)
TESTS = ('tests/e2e/ligand-information-lifecycle.spec.ts', 'tests/e2e/ligand-information-access.spec.ts')
GUARD_SHA = '77eab7aa0a0a02426567737faffb53a156ebd2642bbefa18c0a7dbbe279ed813'
CONFIG = OUT / 'playwright.config.ts'
NATIVE = OUT / 'native'


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def guard_functions():
    path = OUT / 'source_guard.py'
    assert sha(path.read_bytes()) == GUARD_SHA, 'Source discovery/receipt guard changed'
    return runpy.run_path(str(path), run_name='frozen_c2_guard')


def audit():
    return guard_functions()['audit'](ROOT)


def ports_unused():
    listening = set()
    for family in ('tcp', 'tcp6'):
        for line in (Path('/proc/net') / family).read_text().splitlines()[1:]:
            fields = line.split()
            if fields[3] == '0A':
                listening.add(int(fields[1].rsplit(':', 1)[1], 16))
    return {str(port): port not in listening for port in PORTS}


def environment():
    forbidden = {'DATABASE_URL', 'VITE_API_TARGET', 'PW_TEST_CONNECT_WS_ENDPOINT',
                 'PLAYWRIGHT_JSON_OUTPUT_FILE', 'PLAYWRIGHT_JSON_OUTPUT_NAME',
                 'PLAYWRIGHT_JSON_OUTPUT_DIR', 'PLAYWRIGHT_HTML_OUTPUT_DIR', 'CI'}
    removed = sorted(key for key in os.environ if key.startswith(('NEISTRA_', 'MOLWEAVE_')) or key in forbidden)
    env = {key: value for key, value in os.environ.items() if key not in removed}
    override = {'NEISTRA_E2E_DATA_DIR': str(DATA), 'NEISTRA_E2E_API_PORT': '8470',
                'NEISTRA_E2E_WORKER_PORT': '8471', 'NEISTRA_E2E_WEB_PORT': '5470',
                'NEISTRA_PERFORMANCE': '0', 'PLAYWRIGHT_BROWSERS_PATH': '/datadisk/dev/neistra/.playwright',
                'PLAYWRIGHT_JSON_OUTPUT_FILE': str(OUT / 'browser.json')}
    env.update(override)
    assert 'NEISTRA_PROPERTY_WORKER_TRACE' not in env
    return env, override, removed


def command():
    return ['corepack', 'pnpm', 'exec', 'playwright', 'test', *TESTS, '--config', str(CONFIG),
            '--workers=1', '--retries=0', '--max-failures=1', '--reporter=list,json', '--output', str(NATIVE)]


def process_row(pid):
    directory = Path('/proc') / str(pid)
    try:
        markers = {('NEISTRA_E2E_DATA_DIR=' + str(DATA)).encode(), ('NEISTRA_DATA_DIR=' + str(DATA)).encode()}
        if not markers.intersection((directory / 'environ').read_bytes().split(b'\0')):
            return None
        raw = (directory / 'stat').read_text()
        fields = raw[raw.rindex(')') + 2:].split()
        if fields[0] == 'Z':
            return None
        return {'pid': int(pid), 'ppid': int(fields[1]), 'process_group': int(fields[2]),
                'session': int(fields[3]), 'start_token': fields[19], 'utime_ticks': int(fields[11]),
                'stime_ticks': int(fields[12]), 'rss_pages': int(fields[21]),
                'command': [item.decode(errors='replace') for item in (directory / 'cmdline').read_bytes().split(b'\0') if item]}
    except (OSError, ValueError, IndexError):
        return None


def owned_processes():
    return sorted([row for directory in Path('/proc').iterdir() if directory.name.isdigit()
                   if (row := process_row(directory.name)) is not None], key=lambda row: row['pid'])


def positive_signal(row, sig):
    current = process_row(row['pid'])
    if current is None or current['start_token'] != row['start_token']:
        return {'pid': row['pid'], 'start_token': row['start_token'], 'signal': sig, 'sent': False,
                'reason': 'Positive exact-store environment/start-token ownership no longer exists'}
    os.kill(row['pid'], sig)
    return {'pid': row['pid'], 'start_token': row['start_token'], 'signal': sig, 'sent': True,
            'ownership_before_signal': current}


def cleanup_owned():
    observations = []
    for _ in range(50):
        if not owned_processes() and all(ports_unused().values()):
            break
        time.sleep(.1)
    for sig in (signal.SIGTERM, signal.SIGKILL):
        rows = owned_processes()
        if not rows:
            break
        for row in rows:
            try:
                observations.append(positive_signal(row, sig))
            except ProcessLookupError:
                observations.append({'pid': row['pid'], 'signal': sig, 'sent': False, 'reason': 'Exited before signal'})
        for _ in range(50):
            if not owned_processes():
                break
            time.sleep(.1)
    return {'signals': observations, 'remaining': owned_processes(), 'ports_unused': ports_unused(),
            'scope': 'Only processes bearing exact fresh-store environment marker and verified PID/start token; no process-group or port-owner signals'}


def inventory(root):
    result = {}
    if not root.exists():
        return result
    assert root.is_dir() and not root.is_symlink()
    for current, directories, files in os.walk(root, followlinks=False):
        for name in directories:
            path = Path(current) / name
            assert not path.is_symlink() and stat.S_ISDIR(path.lstat().st_mode), str(path)
        for name in files:
            path = Path(current) / name
            assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode), str(path)
            payload = path.read_bytes()
            result[str(path.relative_to(root))] = {'bytes': len(payload), 'sha256': sha(payload)}
    return result


def snapshot_raw_store():
    """First post-cleanup store operation; never opens SQLite or checkpoints WAL."""
    assert not owned_processes() and all(ports_unused().values()), 'Cannot preserve a store still owned by live services'
    before = inventory(WORKSPACE)
    target = OUT / 'owned-store-postcleanup.zip'
    assert not target.exists()
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for relative, meta in before.items():
            payload = (WORKSPACE / relative).read_bytes()
            assert sha(payload) == meta['sha256'] and len(payload) == meta['bytes']
            archive.writestr(relative, payload)
    after = inventory(WORKSPACE)
    assert after == before, 'Raw store changed while preserving bytes'
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(before)
        for relative, meta in before.items():
            assert sha(archive.read(relative)) == meta['sha256']
    database_names = {name: before.get('e2e/' + name) for name in ('neistra.db', 'neistra.db-wal', 'neistra.db-shm', 'molweave.db', 'molweave.db-wal', 'molweave.db-shm')}
    return {'utc': utc(), 'path': str(target), 'sha256': sha(target.read_bytes()), 'files': before,
            'raw_DB_WAL_SHM': database_names, 'copy_before_any_SQLite_connection': True,
            'all_original_store_files_retained': True, 'byte_verification': 'PASS', 'crc': 'PASS'}


def collect_cases(report):
    result = []
    def walk(suite):
        for spec in suite.get('specs', []):
            for test in spec.get('tests', []):
                result.append({'file': spec.get('file'), 'title': spec.get('title'), 'id': spec.get('id'),
                               'line': spec.get('line'), 'column': spec.get('column'), 'tags': spec.get('tags'),
                               'project': test.get('projectName'), 'projectId': test.get('projectId'),
                               'timeout': test.get('timeout'), 'annotations': test.get('annotations'),
                               'expectedStatus': test.get('expectedStatus'), 'status': test.get('status'),
                               'results': test.get('results', [])})
        for nested in suite.get('suites', []):
            walk(nested)
    for suite in report.get('suites', []):
        walk(suite)
    return result


def identity_inventory(report):
    identities = [{key: value for key, value in case.items() if key not in {'results', 'status'}} for case in collect_cases(report)]
    projects = [{key: project.get(key) for key in ('name', 'id', 'retries', 'timeout', 'repeatEach')} for project in report['config']['projects']]
    return {'cases': identities, 'projects': projects}


def extract_attachments(report_path, destination):
    """Losslessly decode every inline body and preserve path-based attachments."""
    original = report_path.read_bytes()
    report_hash = sha(original)
    cases = collect_cases(json.loads(original))
    destination.mkdir(exist_ok=False)
    rows = []
    for case_index, case in enumerate(cases, 1):
        for result_index, result in enumerate(case['results']):
            for attachment_index, attachment in enumerate(result.get('attachments', [])):
                content_type = attachment.get('contentType')
                row = {'case': case_index, 'result': result_index, 'attachment': attachment_index,
                       'project': case['project'], 'title': case['title'], 'metadata': attachment,
                       'original_report_sha256': report_hash}
                if 'body' in attachment:
                    assert isinstance(attachment['body'], str), 'Inline body must be base64 text'
                    payload = base64.b64decode(attachment['body'], validate=True)
                    assert base64.b64encode(payload).decode() == attachment['body'], 'Noncanonical/lossy inline body'
                    row['inline_body_text_sha256'] = sha(attachment['body'].encode())
                elif attachment.get('path'):
                    path = Path(attachment['path'])
                    assert path.is_file() and not path.is_symlink()
                    assert path.resolve().is_relative_to(NATIVE.resolve()), 'Attachment path outside owned output'
                    payload = path.read_bytes()
                else:
                    raise AssertionError('Attachment missing body/path; no zero-attachment substitution')
                suffix = '.png' if content_type == 'image/png' else '.json' if content_type == 'application/json' else '.bin'
                if suffix == '.png':
                    assert payload.startswith(b'\x89PNG\r\n\x1a\n')
                elif suffix == '.json':
                    json.loads(payload)
                path = destination / f'{case_index:02}-{result_index:02}-{attachment_index:03}{suffix}'
                path.write_bytes(payload)
                assert path.read_bytes() == payload
                row.update(path=str(path), bytes=len(payload), body_sha256=sha(payload), lossless=True)
                rows.append(row)
    assert sha(report_path.read_bytes()) == report_hash
    required = sum(1 for case in cases for result in case['results'] for attachment in result.get('attachments', [])
                   if attachment.get('contentType') in {'image/png', 'application/json'})
    assert sum(row['metadata'].get('contentType') in {'image/png', 'application/json'} for row in rows) == required
    return {'original_report_sha256': report_hash, 'attachments': rows, 'count': len(rows),
            'PNG_JSON_count': required, 'all_reported_attachments_preserved': True}


def script_pins():
    return {name: sha((OUT / name).read_bytes()) for name in
            ('runner.py', 'source_guard.py', 'playwright.config.ts', 'tsconfig.json', 'offline_checks.py')}


def check_go(go, prepared, readback, clearance, prepared_hash):
    """Validate root-owned documents; never manufactures authorization."""
    guard = guard_functions()
    assert go['go'] == 'RUN_ONCE' and go['authorized_by'] == '/root'
    assert go['prepared_sha256'] == prepared_hash
    assert go['source_map_sha256'] == guard['SOURCE_MAP_SHA256']
    assert go['source_digest'] == guard['SOURCE_DIGEST'] and go['source_count'] == 1214
    assert go['HEAD'] == guard['EXPECTED_HEAD']
    assert go['script_pins'] == prepared['script_pins']
    assert readback['reviewer'] not in ('/root/issue161_c2_runner_preparation', '/root/issue161_c2_oracle_correction', '/root/issue161_c2_prep5', '/root/issue161_c2_prep6')
    assert readback['independent_readback'] == 'PASS' and readback['prepared_sha256'] == prepared_hash
    assert readback['script_pins'] == prepared['script_pins'] and readback['source_map_sha256'] == guard['SOURCE_MAP_SHA256']
    assert clearance['issued_by'] == '/root' and clearance['clearance'] == 'CLEAR_FOR_SINGLE_C2_RUN'
    assert clearance['prepared_sha256'] == prepared_hash and clearance['ports'] == list(PORTS)
    assert clearance['foreign_services_untouched'] is True
    assert go['independent_readback_sha256'] == sha(json.dumps(readback, sort_keys=True, separators=(',', ':')).encode())
    assert go['coactivity_clearance_sha256'] == sha(json.dumps(clearance, sort_keys=True, separators=(',', ':')).encode())
    assert not WORKSPACE.exists() and not WORKSPACE.is_symlink(), 'Fresh store path already exists'
    assert not owned_processes() and all(ports_unused().values())


def offline():
    assert not (OUT / 'prepared.json').exists(), 'Preserve previous preparation'
    before = audit()
    env, overrides, removed = environment()
    # Collection uses the exact private native config, but --list does not start services.
    steps = [('strict-types', ['corepack', 'pnpm', '--filter', '@neistra/web', 'exec', 'tsc', '--project', str(OUT / 'tsconfig.json'), '--pretty', 'false']),
             ('new-collection', ['corepack', 'pnpm', 'exec', 'playwright', 'test', *TESTS, '--config', str(CONFIG), '--list', '--reporter=json']),
             ('complete-collection', ['corepack', 'pnpm', 'exec', 'playwright', 'test', '--list', '--reporter=json'])]
    # Reporter JSON output must go to the captured stdout log during list-only checks.
    env.pop('PLAYWRIGHT_JSON_OUTPUT_FILE')
    receipt = {'scope': 'Offline strict types, list collection and source/guard controls only; no native/services/browser/performance',
               'started_utc': utc(), 'source_before': before, 'steps': [], 'complete': False}
    write('offline-receipt.json', receipt)
    for label, cmd in steps:
        audit()
        with (OUT / (label + '.log')).open('xb') as stream:
            child = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
            code = child.wait()
        receipt['steps'].append({'phase': label, 'command': cmd, 'actual_child_pid': child.pid, 'exit_code': code,
                                 'log_sha256': sha((OUT / (label + '.log')).read_bytes()), 'finished_utc': utc()})
        write('offline-receipt.json', receipt)
        print(label, 'exit', code, flush=True)
        assert code == 0, 'Offline check failed; prior evidence preserved'
    new = json.loads((OUT / 'new-collection.log').read_text())
    complete = json.loads((OUT / 'complete-collection.log').read_text())
    old = ROOT / '.issue-11-evidence/issue161-native-c2/depiction-source-channel'
    old_new = json.loads((old / 'new-collection.log').read_text())
    old_complete = json.loads((old / 'complete-collection.log').read_text())
    assert identity_inventory(new) == identity_inventory(old_new), 'C2 case identity/project/line/annotations/collection timeout/retries changed'
    assert identity_inventory(complete) == identity_inventory(old_complete), 'Complete644 collection changed'
    assert len(collect_cases(new)) == 16 and len(collect_cases(complete)) == 644
    assert all('test.setTimeout(120_000)' in (ROOT / name).read_text() for name in TESTS)
    write('case-inventory.json', {'new': identity_inventory(new), 'complete': identity_inventory(complete),
                                'all_644_exact_vs_authored': True, 'C2_runtime_timeout': 120000,
                                'note': 'List collection reports inherited60000; each authored C2 body sets120000 unchanged',
                                'new_cases': 16, 'complete_cases': 644})
    control_cmd = [str(ROOT / '.venv/bin/python'), str(OUT / 'offline_checks.py')]
    with (OUT / 'offline-controls.log').open('xb') as stream:
        controlled = subprocess.run(control_cmd, cwd=ROOT, env={key: value for key, value in env.items() if key != 'NEISTRA_E2E_DATA_DIR'}, stdout=stream, stderr=subprocess.STDOUT)
    receipt['steps'].append({'phase': 'offline-controls', 'command': control_cmd, 'exit_code': controlled.returncode, 'log_sha256': sha((OUT / 'offline-controls.log').read_bytes())})
    write('offline-receipt.json', receipt)
    assert controlled.returncode == 0, 'Offline controls failed'
    after = audit()
    assert before == after
    ready = {'status': 'PREPARED_HOLD', 'scope': receipt['scope'], 'script_pins': script_pins(),
             'source_map_sha256': before['source_map_sha256'], 'source_digest': before['source_digest'], 'source_count': 1214,
             'HEAD': before['authoritative_HEAD'], 'receipt_pins': before['receipt_pins'], 'command': command(),
             'cwd': str(ROOT), 'workspace': str(WORKSPACE), 'canonical_database': str(DATA / 'neistra.db'),
             'environment_overrides': overrides, 'removed_inherited_names': removed, 'worker_trace': 'OFF',
             'ports_unused_at_preparation': ports_unused(), 'owned_processes_at_preparation': owned_processes(),
             'workspace_absent': not WORKSPACE.exists(), 'native_executed': False, 'browser_started': False,
             'expected_cases': 16, 'authored_case_identity_unchanged': True,
             'offline_evidence_pins': {name: sha((OUT / name).read_bytes()) for name in ('strict-types.log', 'new-collection.log', 'complete-collection.log', 'case-inventory.json', 'offline-controls.json', 'offline-controls.log')},
             'pending': ['Root explicit GO', 'Independent runner/readback assessment', 'Root fresh coactivity clearance'],
             'created_utc': utc()}
    receipt.update(complete=True, source_after=after, source_unchanged=True, finished_utc=utc())
    write('offline-receipt.json', receipt)
    write('prepared.json', ready)
    write('root-execution-go.template.json', {'go': 'HOLD_TEMPLATE_ONLY', 'authorized_by': '/root',
        'prepared_sha256': sha((OUT / 'prepared.json').read_bytes()), 'source_map_sha256': before['source_map_sha256'],
        'source_digest': before['source_digest'], 'source_count': 1214, 'HEAD': before['authoritative_HEAD']['commit'],
        'script_pins': ready['script_pins'], 'independent_readback_sha256': 'REQUIRED_CANONICAL_JSON_DIGEST',
        'coactivity_clearance_sha256': 'REQUIRED_CANONICAL_JSON_DIGEST',
        'scope': 'Single16 C2 native cases only; no full feature/release readiness'})
    print('PREPARED_HOLD: no native execution', flush=True)


def execute():
    prepared_file = OUT / 'prepared.json'
    prepared = json.loads(prepared_file.read_text())
    assert prepared['script_pins'] == script_pins(), 'Prepared executable changed'
    for name, pinned in prepared['offline_evidence_pins'].items():
        assert sha((OUT / name).read_bytes()) == pinned, 'Offline evidence drift: ' + name
    assert not (OUT / 'actual-receipt.json').exists(), 'Never rerun/overwrite an attempt'
    # Only root supplies these documents after separate readback and clearance. No template fallback.
    go = json.loads((OUT / 'root-execution-go.json').read_text())
    readback = json.loads((OUT / 'independent-readback.json').read_text())
    clearance = json.loads((OUT / 'coactivity-clearance.json').read_text())
    check_go(go, prepared, readback, clearance, sha(prepared_file.read_bytes()))
    before = audit()
    env, overrides, removed = environment()
    assert overrides == prepared['environment_overrides'] and command() == prepared['command']
    WORKSPACE.mkdir(exist_ok=False)
    state = {'scope': 'Single16 C2 native attempt only; all prior failures/receipts preserved; no full release/readiness',
             'started_utc': utc(), 'command': command(), 'cwd': str(ROOT), 'source_before': before,
             'environment_overrides': overrides, 'removed_inherited_names': removed,
             'worker_trace': 'OFF', 'prepared_sha256': sha(prepared_file.read_bytes()),
             'script_pins': script_pins(), 'ports_unused_before': ports_unused(),
             'root_go_sha256': sha((OUT / 'root-execution-go.json').read_bytes()), 'complete': False}
    write('actual-receipt.json', state)
    assert audit() == before and all(ports_unused().values()) and not owned_processes()
    child = None
    stop = threading.Event()
    observer = None
    observed = {}
    observer_errors = []
    errors = []
    def sample():
        try:
            with (OUT / 'owned-process-observations.jsonl').open('x') as stream:
                while not stop.is_set():
                    rows = owned_processes()
                    for row in rows:
                        observed[(row['pid'], row['start_token'])] = row
                    stream.write(json.dumps({'utc': utc(), 'owned': rows}) + '\n')
                    stream.flush()
                    stop.wait(1)
        except Exception as error:
            observer_errors.append(repr(error))
    try:
        child = subprocess.Popen(command(), cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
        registration_started = time.monotonic()
        initial = process_row(child.pid)
        while initial is None and child.poll() is None and time.monotonic() - registration_started < 2.0:
            time.sleep(0.005)
            initial = process_row(child.pid)
        assert initial is not None, 'Launched child must have positive fresh-store ownership'
        state['actual_child_identity'] = initial
        observer = threading.Thread(target=sample, daemon=True)
        observer.start()
        write('actual-receipt.json', state)
        assert child.stdout is not None
        with (OUT / 'raw.log').open('xb') as stream:
            for line in child.stdout:
                stream.write(line)
                stream.flush()
                print(line.decode(errors='replace').rstrip(), flush=True)
        state['actual_child_exit_code'] = child.wait()
    except BaseException as error:
        errors.append({'phase': 'execution', 'error': repr(error)})
    finally:
        # No cleanup signal can target another service: every signal rechecks exact env and start token.
        state['cleanup'] = cleanup_owned()
        if child is not None:
            try:
                state['actual_child_exit_code'] = child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                errors.append({'phase': 'child_reap', 'error': 'Owned child still alive'})
        stop.set()
        if observer is not None:
            observer.join(timeout=3)
        state['owned_processes_seen'] = list(observed.values())
        state['observer_errors'] = observer_errors
        state['observer_stopped'] = observer is None or not observer.is_alive()
        try:
            # Must precede diagnostics, report decoding, source audit, or any SQLite access.
            state['owned_store_snapshot'] = snapshot_raw_store()
        except Exception as error:
            errors.append({'phase': 'raw_store_preservation', 'error': repr(error)})
        try:
            state['source_after'] = audit()
            assert state['source_after'] == before
        except Exception as error:
            errors.append({'phase': 'source_HEAD_after', 'error': repr(error)})
        try:
            report_path = OUT / 'browser.json'
            state['attachment_extraction'] = extract_attachments(report_path, OUT / 'extracted-attachments')
            report = json.loads(report_path.read_bytes())
            cases = collect_cases(report)
            state.update(browser_stats=report.get('stats'), browser_errors=report.get('errors'), case_results=cases)
            expected = json.loads((OUT / 'case-inventory.json').read_text())['new']['cases']
            observed_ids = [(case['id'], case['project']) for case in cases]
            assert observed_ids == [(case['id'], case['project']) for case in expected]
            if state.get('actual_child_exit_code') == 0:
                assert len(cases) == 16 and not report.get('errors')
                assert all(case['status'] == 'expected' and len(case['results']) == 1
                           and case['results'][0]['status'] == 'passed' and case['results'][0]['retry'] == 0 for case in cases)
        except Exception as error:
            errors.append({'phase': 'browser_report_or_attachments', 'error': repr(error)})
        traces = []
        for path in NATIVE.rglob('*.zip'):
            try:
                with zipfile.ZipFile(path) as archive:
                    assert archive.testzip() is None
                traces.append({'path': str(path), 'sha256': sha(path.read_bytes()), 'crc': 'PASS'})
            except Exception as error:
                errors.append({'phase': 'trace_crc', 'error': repr(error), 'path': str(path)})
        state['trace_crc'] = traces
        state['native_inventory'] = inventory(NATIVE)
        state['raw_log_sha256'] = sha((OUT / 'raw.log').read_bytes()) if (OUT / 'raw.log').exists() else None
        state['canonical_database_exists'] = (DATA / 'neistra.db').is_file()
        state['legacy_database_exists'] = any((DATA / name).exists() for name in ('molweave.db', 'molweave.db-wal', 'molweave.db-shm'))
        state.update(qualification_guard_errors=errors, complete=True, finished_utc=utc(),
                     actual_enclosing_status='Caller must independently observe outer tool completion; child receipt is not outer success',
                     no_case_retry_or_assertion_repair=True)
        write('actual-receipt.json', state)
    assert not errors and not observer_errors and state['observer_stopped'], 'Inspect retained failed attempt'
    assert not state['cleanup']['remaining'] and all(state['cleanup']['ports_unused'].values()), 'Owned cleanup incomplete'
    assert state['canonical_database_exists'] and not state['legacy_database_exists'], 'Unexpected database alias'
    return state['actual_child_exit_code']


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('offline', 'execute'))
    args = parser.parse_args()
    if args.mode == 'offline':
        offline()
    else:
        raise SystemExit(execute())


if __name__ == '__main__':
    main()
