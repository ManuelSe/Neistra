"""Read-only prep9 self-proof with complete in-place retention; no runtime or SQL."""
from pathlib import Path
import ast,datetime,hashlib,json,runpy,sys,zipfile
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
OLD=OUT.with_name("issue161-native-c2-source-integration-preparation8")
sha=lambda b:hashlib.sha256(b).hexdigest();fp=lambda b:{"bytes":len(b),"sha256":sha(b)};read=lambda p:json.loads(p.read_text())
r=runpy.run_path(str(OUT/"runner.py"),run_name="prep9_readonly_proof")
audit=r["audit"]();prepared=read(OUT/"prepared.json");offline=read(OUT/"offline-receipt.json");controls=read(OUT/"offline-controls.json")
assert audit["source_count"]==1214 and audit["prior_attempt_files_preserved"]==910
assert prepared["script_pins"]==r["script_pins"]()
assert offline["complete"] and offline["source_before"]==offline["source_after"]==audit
assert all(s["exit_code"]==0 for s in offline["steps"])
assert len(controls["checks"])==49 and controls["all_pass"]
assert not r["WORKSPACE"].exists() and not r["WORKSPACE"].is_symlink()
assert not (OUT/"root-execution-go.json").exists() and not (OUT/"actual-receipt.json").exists()
assert not r["owned_processes"]() and all(r["ports_unused"]().values())
source=read(OUT/"frozen-source-map.json");before_map=read(OUT/"source-before-correction.json");life="tests/e2e/ligand-information-lifecycle.spec.ts"
assert len(source)==len(before_map)==1214 and set(source)==set(before_map)
assert [n for n in source if source[n]!=before_map[n]]==[life]
assert before_map[life]=="386bb41a166441a52858851998530f499dd5885a2ca2fa9248eb0914a6d41484"
assert source[life]=="1e8c69852bbad44cb406a7f91f7f5ee2226e74b78ec4d3969370d5bb7c2b405e"
for archive,map_expected in [("complete-source-before-correction.zip",before_map),("complete-selected-source.zip",source)]:
 with zipfile.ZipFile(OUT/archive) as z:
  assert z.testzip() is None and len(z.namelist())==1215 and set(z.namelist())==set(map_expected)|{"manifest.json"}
  manifest=json.loads(z.read("manifest.json"))
  for n,h in map_expected.items():
   body=z.read(n);assert sha(body)==h and fp(body)==manifest[n]
   if archive=="complete-selected-source.zip":assert body==(ROOT/n).read_bytes()
byteproof=read(OUT/"summary-locator-byte-proof.json");astproof=read(OUT/"summary-locator-AST-proof.json")
before=(OUT/"ligand-information-lifecycle.before.ts.txt").read_text();after=(ROOT/life).read_text()
assert before.count(byteproof["old_action"])==after.count(byteproof["new_action"])==2
assert after.replace(byteproof["new_action"],byteproof["old_action"])==before
assert before.count("\n")==after.count("\n")==509
assert astproof["parse_diagnostics"]==0 and astproof["normalized_call_count"]==2
assert astproof["whole_file_AST_equal_after_only_two_locator_normalizations"] and astproof["all187_expectation_statements_exact_order_and_text"]
assert astproof["open_attribute_guards_and_normal_native_click_preserved"]

def functions(path):return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
oldfn=functions(OLD/"runner.py");newfn=functions(OUT/"runner.py");assert len(oldfn)==len(newfn)==22
assert all(ast.dump(oldfn[n],include_attributes=False)==ast.dump(newfn[n],include_attributes=False) for n in oldfn)
oldguard=functions(OLD/"source_guard.py");newguard=functions(OUT/"source_guard.py");changed_guard=[n for n in oldguard if ast.dump(oldguard[n],include_attributes=False)!=ast.dump(newguard[n],include_attributes=False)]
assert sorted(changed_guard)==["audit","verify_delta_bytes"]
for n in ("playwright.config.ts","tsconfig.json"):assert (OUT/n).read_bytes()==(OLD/n).read_bytes()
preserved=read(OUT/"prior-preparations-preservation-before.json");assert len(preserved)==8
for n,files in preserved.items():assert r["inventory"](ROOT/n)==files
retention=read(OUT/"in-place-retention-contract.json");assert retention["all_regular_originals_preserved_in_place"] and retention["no_prior_artifact_deleted_modified_or_omitted"]
assert retention["old_preparation8_not_rebundled"] and retention["SQL_opened"] is False
assert retention["prior_manifest_sha256"]==sha((OUT/"prior-preparations-preservation-before.json").read_bytes())
assert not (OUT/"preparation8-preserved.zip").exists()
raw=[]
for row in read(OUT/"prior-store-byte-preservation.json"):
 path=Path(row["snapshot_path"]);assert sha(path.read_bytes())==row["sha256"]
 snap=read(ROOT/row["preparation"]/"actual-receipt.json")["owned_store_snapshot"]
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and set(z.namelist())==set(snap["files"])
  for n,v in snap["files"].items():assert fp(z.read(n))==v
  assert len(z.namelist())==row["files"]
 raw.append({"path":str(path),"sha256":row["sha256"],"files":row["files"],"CRC_and_member_hashes":"PASS","SQL_opened":False})
assert [v["files"] for v in raw]==[10,3,14,15,20,20,20]
latest=Path(raw[-1]["path"]);assert (OUT/"latest-failed-owned-store.zip").read_bytes()==latest.read_bytes()
assert fp(latest.read_bytes())==retention["new_narrow_copies"]["latest_failed_raw_store_zip"]
cases=read(OUT/"case-inventory.json");oldcases=read(OLD/"case-inventory.json")
assert cases["new"]==oldcases["new"] and cases["complete"]==oldcases["complete"]
assert len(cases["new"]["cases"])==16 and len(cases["complete"]["cases"])==644
record={"scope":"Author self-readback of bounded prep9 only. HOLD; no current native pass or independent approval","actual_author_agent":"/root/issue161_c2_prep5","preparation_label":"prep9","verdict":"PASS","checked_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source_count":1214,"source_map_sha256":audit["source_map_sha256"],"source_digest":audit["source_digest"],"prepared_sha256":sha((OUT/"prepared.json").read_bytes()),"script_pins":prepared["script_pins"],"offline_controls":49,"actual_offline_enclosing":{"session_id":31241,"actual_exit":0,"tool_chunk":"06611a"},"only_source_body_changed":life,"only_two_native_summary_action_locators_changed":True,"all187_assertions_exact":True,"whole_file_AST_exact_after_two_locator_normalizations":True,"open_guards_normal_click_and_no_bypass_preserved":True,"509_lines_unchanged":True,"case_identities_exact":[16,644],"all22_runtime_function_ASTs_exact":True,"guard_functions_changed":changed_guard,"retention_policy":"All910 prior regular files retained in place with complete literal hash inventory; no redundant recursive prep8 archive. Runtime/source/ownership/cleanup guards unchanged.","all910_prior_regular_files_exact":True,"prior_counts":{n:len(v) for n,v in preserved.items()},"all207_prep8_original_files_exact_in_place":True,"prep8_recursively_rebundled":False,"all102_raw_store_members_exact":True,"latest_failed20member_raw_zip_narrow_copy_exact":True,"raw_store_checks":raw,"all1214_current_and_before_source_archive_bodies_exact":True,"root_GO_created":False,"workspace_absent":True,"ports_observed_unused":r["ports_unused"](),"no_app_services_browser_native_performance_SQL_Git_remote_changes_or_execution":True,"remaining":["Independent architecture assessment and root primary readback","Root fresh coactivity/ports clearance and exact RUN_ONCE authorization","Actual new16case attempt with same deadlines and complete retention","Final prerequisites/fullfeature/releasegates/allseven remain separate"]}
if "--check-only" not in sys.argv:(OUT/"current-contract-readback.json").write_text(json.dumps(record,indent=2,sort_keys=True)+"\n")
print(json.dumps({"verdict":"PASS","source_count":1214,"controls":49,"runtime_ASTs_exact":22,"assertions_exact":187,"prior_files_in_place":910,"raw_members":102,"no_recursive_prep8_rebundle":True,"case_counts":[16,644],"HOLD":True}))
