Preparation9 remains HOLD. Actual reused author:/root/issue161_c2_prep5, already
excluded by unchanged self-review gate. No new native/browser/services/performance
execution or GO. No app/scientific/runtime/schema/counter contract changes.

Native8 remains failed:root26077exit1/efeeda,10passes/1failure/5unrun. Raw20-member
snapshot8a38cc28... was frozen before diagnostics. The mobile browser panel remount
closes native details while retaining type=ligand. Its summary correctly reads
Filter and sort · filtered. The test waits for the exact unfiltered base text and
times out at the second closed-disclosure action; the first unfiltered click worked.

Only the two closed-disclosure action locators change to the actual unique native
list.locator(".browser-filter-details > summary").click(). Existing getAttribute(open)
guards, real native click, selectOption ligand/all, identity/outside-filter/A->B->A/
reload/original checks and all scientific assertions remain exact. No force/open
attribute/store bypass is introduced. All187 assertions,509lines,case definitions
and all16/644 collection identities are unchanged. Timeout/retry limits unchanged.

Offline strict types,list16,list644 and49 controls pass. All22 runtime function ASTs
are exactlyprep8; only fresh workspace9 and guard-hash globals change. Source guard
changes only explicit current lifecycle/map/retention bindings and the latest failed
attempt checks. Discovery/hash/HEAD/ownership/cleanup/isolation/attachment gates stay.

Retention deliberately avoids recursive evidence growth. All910 regular files across
eight prior preparations remain IN PLACE with a complete literal hash inventory and
fresh exact-byte readback. No prior artifact is deleted, pruned or omitted from that
inventory. There is NO preparation8-preserved.zip. New narrow copies contain only
before/current complete1214-source ZIPs and the latest failed20-member raw snapshot.
All102 member bodies across seven original raw-store ZIPs pass SHA/CRC, noSQL. The
latest narrow copy is byte-identical to its retained original. No original location
or expected source scope is changed to obtain a pass.

Read-only self-check (does not rewrite sealed evidence):
.venv/bin/python -B .issue-11-evidence/issue161-native-c2-source-integration-preparation9/verify_preparation9.py --check-only

Future actual command (ROOT ONLY after independent architecture assessment,primary
readback,fresh coactivity/ports clearance and exact RUN_ONCE documents):
.venv/bin/python -B .issue-11-evidence/issue161-native-c2-source-integration-preparation9/runner.py execute

Root supplies independent-readback.json,coactivity-clearance.json and exact
root-execution-go.json. Fresh workspace:/tmp/neistra161-c2-source-integration-native9;
ports8470/8471/5470;traceOFF;workers1/retries0/max-failures1/120seconds per case.
Each actual attempt retains all raw logs/reports/attachments/traces and DB/WAL/SHM
after owned cleanup before diagnostics. Earlier10partial passes are never pooled
into a new current pass. Final prerequisites/fullfeature/releasegates/allseven remain
separate and unqualified by this preparation.
