"""Offline negative controls; no subprocess/service/browser/native execution."""
from __future__ import annotations
import base64
import json
from pathlib import Path
import runpy
import shutil

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
runner = runpy.run_path(str(OUT / 'runner.py'), run_name='offline_runner_import')
guard = runner['guard_functions']()
checks = []

def check(name, operation):
    operation()
    checks.append({'control': name, 'outcome': 'PASS'})

def reject(name, operation):
    try:
        operation()
    except (AssertionError, ValueError, KeyError, FileNotFoundError):
        checks.append({'control': name, 'outcome': 'REJECTED_AS_REQUIRED'})
    else:
        raise AssertionError('Guard accepted negative control: ' + name)

fixture = OUT / 'offline-control-fixtures'
fixture.mkdir(exist_ok=False)
root = fixture / 'selected-tree'
(root / 'apps').mkdir(parents=True)
(root / 'apps/control.ts').write_text('export const control = true;\n')
(root / 'docs/assets/neutral').mkdir(parents=True)
(root / 'docs/assets/neutral/qualification.py.txt').write_text('pass\n')
expected = {name: guard['checked_hash'](root, name) for name in guard['discover'](root)}
check('Small control source baseline/discovery', lambda: guard['audit_selected'](root, expected, {}))
(root / 'apps/added.ts').write_text('added\n')
reject('Added selected runtime source', lambda: guard['audit_selected'](root, expected, {}))
(root / 'apps/added.ts').unlink()
(root / 'apps/control.ts').write_text('changed\n')
reject('Changed selected runtime source', lambda: guard['audit_selected'](root, expected, {}))
(root / 'apps/control.ts').unlink()
reject('Missing selected runtime source', lambda: guard['audit_selected'](root, expected, {}))
(root / 'apps/control.ts').symlink_to(fixture / 'outside.ts')
reject('Symlink selected source', lambda: guard['audit_selected'](root, expected, {}))
(root / 'apps/control.ts').unlink()
(root / 'apps/control.ts').write_text('export const control = true;\n')
(root / 'docs/assets/neutral/new-check.py.txt').write_text('pass\n')
reject('Added qualification text source', lambda: guard['audit_selected'](root, expected, {}))
(root / 'docs/assets/neutral/new-check.py.txt').unlink()
check('Restored fixture baseline', lambda: guard['audit_selected'](root, expected, {}))
actual_map = (ROOT / guard['SOURCE_MAP']).read_bytes()
check('Literal root current map accepted', lambda: guard['verify_map_bytes'](actual_map))
mutated = json.loads(actual_map)
mutated['apps/web/src/App.tsx'] = '0' * 64
reject('Mutated expected map with recomputed digest cannot self-approve', lambda: guard['verify_map_bytes'](json.dumps(mutated, sort_keys=True).encode()))
reject('Byte-reformatted same map cannot replace literal root map', lambda: guard['verify_map_bytes'](json.dumps(json.loads(actual_map)).encode()))
check('Actual current1214 source/receipt/HEAD audit', lambda: guard['audit'](ROOT))
# New map may differ only in the exact retained two-test and verified worker/addition delta.
original_map = json.loads((ROOT / guard['ORIGINAL_SOURCE_MAP']).read_bytes())
new_map = json.loads(actual_map)
actual_delta = (ROOT / guard['SOURCE_DELTA']).read_bytes()
check('Exact retained two-test plus verified worker/addition delta', lambda: guard['verify_delta_bytes'](actual_delta, new_map, original_map))
changed_delta = json.loads(actual_delta)
changed_delta['changed_paths']['apps/web/src/App.tsx'] = {'before': '0' * 64, 'after': '1' * 64}
reject('Recomputed delta cannot authorize an application-source change', lambda: guard['verify_delta_bytes'](json.dumps(changed_delta, sort_keys=True).encode(), new_map, original_map))
wrong_map = {**new_map, 'apps/web/src/App.tsx': '0' * 64}
reject('Two-test delta refuses extra app-source drift', lambda: guard['verify_delta_bytes'](actual_delta, wrong_map, original_map))
wrong_original = {**original_map, guard['CORRECTED_PATH']: '0' * 64}
reject('Two-test delta refuses forged original test body', lambda: guard['verify_delta_bytes'](actual_delta, new_map, wrong_original))
wrong_lifecycle_original = {**original_map, guard['LIFECYCLE_PATH']: '0' * 64}
reject('Two-test delta refuses forged original lifecycle body', lambda: guard['verify_delta_bytes'](actual_delta, new_map, wrong_lifecycle_original))
missing_lifecycle_delta = {**new_map, guard['LIFECYCLE_PATH']: original_map[guard['LIFECYCLE_PATH']]}
reject('Two-test delta refuses omitted lifecycle correction', lambda: guard['verify_delta_bytes'](actual_delta, missing_lifecycle_delta, original_map))
for path in ("apps/api/src/neistra_api/job_worker.py", "tests/integration/test_ligand_property_preload_ownership.py"):
    altered = {**new_map, path: "0" * 64}
    reject("Delta refuses unapproved body: " + path, lambda altered=altered: guard["verify_delta_bytes"](actual_delta, altered, original_map))
missing_new = {name: value for name, value in new_map.items() if name != "tests/integration/test_ligand_property_preload_ownership.py"}
reject("Delta refuses missing new regression path", lambda: guard["verify_delta_bytes"](actual_delta, missing_new, original_map))
extra_new = {**new_map, "tests/unapproved.py": "0" * 64}
reject("Delta refuses any additional selected path", lambda: guard["verify_delta_bytes"](actual_delta, extra_new, original_map))
wrong_worker_original = {**original_map, "apps/api/src/neistra_api/job_worker.py": "0" * 64}
reject("Delta refuses forged original worker", lambda: guard["verify_delta_bytes"](actual_delta, new_map, wrong_worker_original))
reject("Previous prep8 map cannot replace current prep9 literal", lambda: guard["verify_map_bytes"]((ROOT / guard["PREVIOUS_SOURCE_MAP"]).read_bytes()))
# check_go is a pure document validator until its final read-only port/path probes.
# Positive document control is independently synthetic; never persisted as GO.
prepared = {'script_pins': runner['script_pins']()}
prepared_hash = 'offline-synthetic-prepared'
readback = {'reviewer': '/root/offline-independent-control', 'independent_readback': 'PASS',
            'prepared_sha256': prepared_hash, 'script_pins': prepared['script_pins'], 'source_map_sha256': guard['SOURCE_MAP_SHA256']}
clearance = {'issued_by': '/root', 'clearance': 'CLEAR_FOR_SINGLE_C2_RUN', 'prepared_sha256': prepared_hash,
             'ports': list(runner['PORTS']), 'foreign_services_untouched': True}
digest = lambda value: runner['sha'](json.dumps(value, sort_keys=True, separators=(',', ':')).encode())
go = {'go': 'RUN_ONCE', 'authorized_by': '/root', 'prepared_sha256': prepared_hash,
      'source_map_sha256': guard['SOURCE_MAP_SHA256'], 'source_digest': guard['SOURCE_DIGEST'], 'source_count': 1214,
      'HEAD': guard['EXPECTED_HEAD'], 'script_pins': prepared['script_pins'],
      'independent_readback_sha256': digest(readback), 'coactivity_clearance_sha256': digest(clearance)}
check('Synthetic GO document contract plus actual read-only free-path/port observations', lambda: runner['check_go'](go, prepared, readback, clearance, prepared_hash))
for field, value in [('go', 'HOLD_TEMPLATE_ONLY'), ('source_count', 1213), ('HEAD', '0' * 40), ('source_digest', '0' * 64),
                     ('source_map_sha256', '0' * 64), ('authorized_by', '/other'), ('prepared_sha256', 'wrong'),
                     ('independent_readback_sha256', '0' * 64), ('coactivity_clearance_sha256', '0' * 64)]:
    changed = {**go, field: value}
    reject('GO rejects altered ' + field, lambda changed=changed: runner['check_go'](changed, prepared, readback, clearance, prepared_hash))
reject('GO requires independent readback', lambda: runner['check_go'](go, prepared, {}, clearance, prepared_hash))
reject('GO requires coactivity clearance', lambda: runner['check_go'](go, prepared, readback, {}, prepared_hash))
wrong_readback = {**readback, 'reviewer': '/root/issue161_c2_oracle_correction'}
wrong_go = {**go, 'independent_readback_sha256': digest(wrong_readback)}
reject('Runner author cannot self-approve independent readback', lambda: runner['check_go'](wrong_go, prepared, wrong_readback, clearance, prepared_hash))
self_readback = {**readback, 'reviewer': '/root/issue161_c2_prep5'}
self_go = {**go, 'independent_readback_sha256': digest(self_readback)}
reject('Current prep5 author cannot self-approve', lambda: runner['check_go'](self_go, prepared, self_readback, clearance, prepared_hash))
old_map_go = {**go, 'source_map_sha256': guard['PREVIOUS_SOURCE_MAP_SHA256']}
reject('Previous prep8 source GO cannot authorize prep9', lambda: runner['check_go'](old_map_go, prepared, readback, clearance, prepared_hash))
previous_lifecycle = {**new_map, guard['LIFECYCLE_PATH']: '586bb163a66bd0c37d1840c401d6df76c7f61bac05064f89b790b366372f0184'}
reject('Delta refuses old prep5 late-project fixture body', lambda: guard['verify_delta_bytes'](actual_delta, previous_lifecycle, original_map))
new_self_readback = {**readback, 'reviewer': '/root/issue161_c2_prep6'}
new_self_go = {**go, 'independent_readback_sha256': digest(new_self_readback)}
reject('Current prep6 author cannot self-approve', lambda: runner['check_go'](new_self_go, prepared, new_self_readback, clearance, prepared_hash))
spent_go = json.loads((ROOT / guard['PREVIOUS_SOURCE_MAP']).with_name('root-execution-go.json').read_text())
reject('Actual already-spent prep8 authorization cannot replay', lambda: runner['check_go'](spent_go, prepared, readback, clearance, prepared_hash))
previous_retry_probe = {**new_map, guard['LIFECYCLE_PATH']: 'b6b43424732eb8c495c0a6d03b1c562febb417d2ac146e7fb123e5a84af28e4e'}
reject('Delta refuses old prep6 transient Retry probe body', lambda: guard['verify_delta_bytes'](actual_delta, previous_retry_probe, original_map))
previous_ungated_profile = {**new_map, guard['LIFECYCLE_PATH']: 'd28d1fb63943000a9826440d042bac2a66704161ac6eaa57ec21734eec762fc7'}
reject('Delta refuses old prep7 ungated profile recovery body', lambda: guard['verify_delta_bytes'](actual_delta, previous_ungated_profile, original_map))
previous_fixed_summary = {**new_map, guard['LIFECYCLE_PATH']: '386bb41a166441a52858851998530f499dd5885a2ca2fa9248eb0914a6d41484'}
reject('Delta refuses old prep8 fixed disclosure text body', lambda: guard['verify_delta_bytes'](actual_delta, previous_fixed_summary, original_map))
# Positive PID/start-token signal gate control uses nonexistent PID and SIG0: no actual signal is sent.
row = runner['positive_signal']({'pid': 999999999, 'start_token': 'unowned'}, 0)
assert row['sent'] is False
checks.append({'control': 'Cleanup refuses unowned/nonexistent PID without signaling', 'outcome': 'PASS'})
# Exercise exact inline report decoding and immutable original report/body hashes.
png = b'\x89PNG\r\n\x1a\nneutral-control-payload'
json_body = b'{"control":"neutral","value":0}\n'
attachments = [{'name': 'control-image', 'contentType': 'image/png', 'body': base64.b64encode(png).decode()},
               {'name': 'control-json', 'contentType': 'application/json', 'body': base64.b64encode(json_body).decode()}]
report = {'suites': [{'specs': [{'title': 'Neutral extraction control', 'id': 'neutral', 'tests': [
    {'projectName': 'offline', 'results': [{'attachments': attachments}]}]}]}]}
report_file = fixture / 'inline-report.json'
report_file.write_text(json.dumps(report))
extracted = runner['extract_attachments'](report_file, fixture / 'inline-extracted')
assert extracted['count'] == 2 and extracted['PNG_JSON_count'] == 2
for item, payload in zip(extracted['attachments'], [png, json_body]):
    assert Path(item['path']).read_bytes() == payload and item['body_sha256'] == runner['sha'](payload)
checks.append({'control': 'Lossless PNG/JSON base64 extraction with report/body hashes', 'outcome': 'PASS'})
bad = json.loads(json.dumps(report))
bad['suites'][0]['specs'][0]['tests'][0]['results'][0]['attachments'][0]['body'] = 'not base64!'
bad_file = fixture / 'invalid-inline-report.json'
bad_file.write_text(json.dumps(bad))
reject('Malformed base64 fails rather than reporting zero attachments', lambda: runner['extract_attachments'](bad_file, fixture / 'bad-inline-extracted'))
# Old native2 actual report is read only: extract every old inline attachment into this new private control directory.
old_report = ROOT / '.issue-11-evidence/issue161-native-root/native2/browser.json'
old_sha = runner['sha'](old_report.read_bytes())
old = runner['extract_attachments'](old_report, fixture / 'historical-actual-extracted')
assert old['count'] == 16 and old['PNG_JSON_count'] == 16 and runner['sha'](old_report.read_bytes()) == old_sha
checks.append({'control': 'All16 historical actual report PNG/JSON attachments losslessly extracted; originals untouched', 'outcome': 'PASS'})
# Source text/order control proves no SQLite library, CLI or diagnostic SQL is called by this runner.
source = (OUT / 'runner.py').read_text()
assert 'import sqlite3' not in source and 'sqlite3.connect' not in source
assert source.index("state['owned_store_snapshot'] = snapshot_raw_store()") < source.index("state['source_after'] = audit()")
checks.append({'control': 'Post-cleanup raw DB/WAL/SHM snapshot precedes diagnostic processing; runner opens no SQLite connection', 'outcome': 'PASS'})
assert not runner['WORKSPACE'].exists() and not (OUT / 'root-execution-go.json').exists() and not (OUT / 'actual-receipt.json').exists()
runner['write']('offline-controls.json', {'scope': 'Offline-only guard controls; synthetic authorizations were in-memory test data, no GO file/native/service/browser',
    'checks': checks, 'all_pass': True, 'historical_actual_extraction': old, 'fresh_store_absent': True,
    'ports_unused': runner['ports_unused'](), 'root_GO_created': False})
print('OFFLINE CONTROLS PASS', len(checks), flush=True)
