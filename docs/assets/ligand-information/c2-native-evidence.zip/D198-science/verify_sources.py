from pathlib import Path
import ast,difflib,hashlib,json,zipfile
root=Path.cwd();issue=160 if 'issue-160-' in root.name else 161
out=root/f'.issue-11-evidence/issue{issue}-source-producer-science';out.mkdir(exist_ok=True)
author=root/f'.issue-11-evidence/issue{issue}-verified-source-integration'
source159=Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
sha=lambda b:hashlib.sha256(b).hexdigest()
expected_sha={160:'eb95833014539ae1ed077bf8daf189c792e68607d4b41e74ee68e5e912544e86',161:'5290f74437765972ebfe10bb9c5aa8c41850e034005d0a15e943d718fdf47dd4'}
assert sha((author/'handoff.json').read_bytes())==expected_sha[issue]
hand=json.loads((author/'handoff.json').read_text());before=json.loads((author/'before-source-map.json').read_text());after=json.loads((author/'frozen-source-map.json').read_text())
assert sha((author/'frozen-source-map.json').read_bytes())==hand['source_map_sha256']
assert all(sha((root/p).read_bytes())==h for p,h in after.items())
assert not set(before)-set(after)
changes=[p for p,h in after.items() if before.get(p)!=h]
owned=hand['owned_paths_sha256'];assert set(changes)==set(owned)|{'apps/web/src/App.tsx'}
exact159=[p for p,h in owned.items() if sha((source159/p).read_bytes())==h]
assert len(exact159)==19
assert sha((root/'apps/web/src/App.tsx').read_bytes())==hand['root_owned_App_sha256']
archives=[]
for name,entries in [('before-complete-sources.zip',before),('frozen-complete-sources.zip',after),('frozen-owned-sources.zip',owned)]:
    with zipfile.ZipFile(author/name) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(entries)
        assert all(sha(z.read(p))==h for p,h in entries.items())
    archives.append({'path':name,'sha256':sha((author/name).read_bytes()),'payload_count':len(entries)})
with zipfile.ZipFile(author/'before-complete-sources.zip') as z:
    for p in ['apps/web/src/App.tsx','apps/api/src/neistra_api/main.py','apps/web/src/ligandProperties/useProperties.ts']:
        a=z.read(p).decode();b=(root/p).read_text();diff=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='before/'+p,tofile='current/'+p))
        (out/(Path(p).name+'.diff')).write_text(diff)
    p='apps/api/src/neistra_api/ligand_property_service.py'
    def methods(s):
        return {m.name:ast.get_source_segment(s,m) for c in ast.walk(ast.parse(s)) if isinstance(c,ast.ClassDef) and c.name=='LigandPropertyService' for m in c.body if isinstance(m,(ast.FunctionDef,ast.AsyncFunctionDef))}
    old,new=methods(z.read(p).decode()),methods((root/p).read_text());changed_methods=[n for n in old if old[n]!=new[n]]
    assert changed_methods==['_current']
    profile_paths=[p for p in before if 'ligandProfile' in p or 'ligand_profile' in p or 'ligand-information' in p or 'ligandInformation' in p or 'browserFilter' in p]
    assert all(before[p]==after[p] for p in profile_paths)
absence=json.loads((author/'D194-preserved-absence.json').read_text())
report={'issue':issue,'source_count':len(after),'source_map_sha256':hand['source_map_sha256'],'source_digest':sha(json.dumps(after,sort_keys=True,separators=(',',':')).encode()),'handoff_sha256':sha((author/'handoff.json').read_bytes()),'App_sha256':hand['root_owned_App_sha256'],'changed_paths':changes,'exact159_paths':exact159,'no_preceding_source_omission':True,'archives':archives,'property_service_changed_methods':changed_methods,'property_service_unchanged_methods':len(old)-1,'unchanged_profile_sidebar_paths':profile_paths,'D194_scope':'All 49 D194 paths absent in destination before and after; no destination qualification inferred','source_fixed':True}
(out/'source-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'issue':issue,'source_count':len(after),'changed_paths':len(changes),'exact159_paths':len(exact159),'unchanged_profile_sidebar_paths':len(profile_paths),'fixed':True}))
