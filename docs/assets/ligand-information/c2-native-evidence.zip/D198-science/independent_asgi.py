from pathlib import Path
import hashlib, json, sqlite3, sys, tempfile
from contextlib import contextmanager
sys.path.insert(0,str(Path.cwd()))
from neistra_api.main import create_app
from neistra_api.database import Base
from neistra_api.models import Artifact
from neistra_api.settings import Settings
from tests.support.api_client import ApiClient
from tests.integration.test_ligand_designation import imported, candidates
from tests.integration.test_ligand_property_lifecycle import source
folder=Path(__file__).resolve().parent
store=Path(tempfile.mkdtemp(prefix='independent-store-',dir=folder))
app=create_app(Settings(data_dir=store,database_url=f'sqlite:///{store / "test.db"}',auto_create_schema=True,enable_test_routes=True))
Base.metadata.create_all(app.state.engine)
client=ApiClient(app)
@contextmanager
def broken(artifact_id,kind):
    with app.state.session_factory() as session:
        artifact=session.get(Artifact,artifact_id); p=store/artifact.relative_path
    data=p.read_bytes(); row=None
    if kind=='corrupt':p.write_bytes(data+b'corruption')
    elif kind=='missing_file':p.unlink()
    else:
        with sqlite3.connect(store/'test.db') as con:
            con.row_factory=sqlite3.Row;row=dict(con.execute('select * from artifacts where id=?',(artifact_id,)).fetchone());con.execute('delete from artifacts where id=?',(artifact_id,))
    try:yield
    finally:
        p.write_bytes(data)
        if row:
            with sqlite3.connect(store/'test.db') as con:
                con.execute('insert into artifacts ('+','.join(row)+') values ('+','.join('?' for _ in row)+')',list(row.values()))
results=[]
for role in ('current','original'):
    for kind in ('corrupt','missing_file','missing_metadata'):
        project=imported(client);entry=project['entries'][0];inventory=candidates(client,project)
        endpoint=f"/api/v1/projects/{project['id']}/ligand-properties/read"
        body={'entries':[source(project)],'descriptor_ids':['molecular_weight']}
        with broken(entry[f'{role}_artifact_id'],kind):
            reply=client.post(endpoint,json=body)
            assert reply.status_code==200,reply.text
            row=reply.json()['entries'][0]
            expected={'project_id':project['id'],'entry_id':entry['id'],'current_artifact_id':entry['current_artifact_id'],'original_artifact_id':entry['original_artifact_id']}
            assert row['source_failure']=={'source_identity':expected,'source_verification':role,'reason':'artifact_unavailable'}
            assert row['status']=='failed' and row['report'] is None
        recovered=candidates(client,project)
        assert client.get(f"/api/v1/projects/{project['id']}").json()==project
        results.append({'role':role,'kind':kind,'project':project,'inventory':inventory,'recovered_inventory':recovered,'response':reply.json()})
# Valid physical bytes with unusable molecular metadata do not report physical failure.
project=imported(client);entry=project['entries'][0];artifact_id=entry['current_artifact_id']
with app.state.session_factory() as session:
    artifact=session.get(Artifact,artifact_id);p=store/artifact.relative_path;original=p.read_bytes();oldsha,oldsize=artifact.sha256,artifact.size
    data=b'{"atoms": "unsupported molecular payload"}'
    p.write_bytes(data);artifact.sha256=hashlib.sha256(data).hexdigest();artifact.size=len(data);session.commit()
try:
    reply=client.post(f"/api/v1/projects/{project['id']}/ligand-properties/read",json={'entries':[source(project)],'descriptor_ids':['molecular_weight']})
    assert reply.status_code==200,reply.text
    row=reply.json()['entries'][0]
    assert row['status']=='unavailable' and row['report'] is None and row['source_failure'] is None,row
    unsupported=reply.json()
finally:
    p.write_bytes(original)
    with app.state.session_factory() as session:
        artifact=session.get(Artifact,artifact_id);artifact.sha256=oldsha;artifact.size=oldsize;session.commit()
app.state.engine.dispose()
(folder/'independent-asgi-results.json').write_text(json.dumps({'scope':'Actual in-process ASGI; no services, workers, browser or numerical calculation','physical_cases':results,'physically_valid_unsupported_control':unsupported},indent=2)+'\n')
print('PASS: six exact physical identities/roles, no report, unchanged projects; physically verified unsupported metadata has no physical-source fact')
