from pathlib import Path
import hashlib,json,subprocess
from datetime import UTC,datetime
root=Path.cwd();issue=160 if 'issue-160-' in root.name else 161
folder=root/f'.issue-11-evidence/issue{issue}-source-producer-science'
author=root/f'.issue-11-evidence/issue{issue}-verified-source-integration'
expected=json.loads((author/'frozen-source-map.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def guard():
    assert all(sha(root/p)==h for p,h in expected.items())
    return {'source_count':len(expected),'source_map_sha256':sha(author/'frozen-source-map.json'),'all_exact':True}
frontend=['corepack','pnpm','--filter','@neistra/web','exec','vitest','run','src/test/ligand-properties-source-verification.test.tsx','src/test/ligand-profiles-integration.test.tsx','src/test/ligand-source-producer-app.test.tsx']
if issue==161:frontend+=['src/test/ligand-profile-comparison.test.tsx','src/test/ligand-information-sidebar.test.tsx']
backend=['.venv/bin/python','-m','pytest','-q','tests/integration/test_ligand_profile_registry.py','tests/unit/test_ligand_profile_registry.py','--basetemp',str(folder/'focused-profile-stores')]
report={'scope':'Fresh independent bounded existing consumer and profile API/domain regression checks; no native or milestone-wide validation','started':datetime.now(UTC).isoformat(),'before':guard(),'steps':[]}
try:
    for name,cmd in [('frontend',frontend),('backend',backend)]:
        log=folder/f'focused-final-{name}.log'
        with log.open('w') as output:result=subprocess.run(cmd,cwd=root,stdout=output,stderr=subprocess.STDOUT)
        report['steps'].append({'name':name,'command':cmd,'exit_code':result.returncode,'log':log.name,'log_sha256':sha(log)})
        print(name,result.returncode,flush=True)
        assert result.returncode==0
finally:
    report['after']=guard();report['finished']=datetime.now(UTC).isoformat()
    (folder/'focused-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
