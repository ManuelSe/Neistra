import * as Tooltip from '@radix-ui/react-tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { act, cleanup, render, screen, waitFor } from '@testing-library/react';
import { StrictMode, useLayoutEffect } from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import metadata from '../../tests/fixtures/profiles/registry.json';
import proof from './independent-asgi-results.json';
import { ApiError } from '../../apps/web/src/api/client';
import { LigandProperties } from '../../apps/web/src/components/LigandProperties';
import { PROFILE_REGISTRY_KEY, ligandProfileApi } from '../../apps/web/src/ligandProfiles/api';
import { profileInputAuthority } from '../../apps/web/src/ligandProfiles/authority';
import { ProfileSelection } from '../../apps/web/src/ligandProfiles/context';
import { evaluateProfile, profileAxisValues } from '../../apps/web/src/ligandProfiles/evaluate';
import { parseProfileRegistry } from '../../apps/web/src/ligandProfiles/validate';
import { useLigandProfiles } from '../../apps/web/src/ligandProfiles/useProfiles';
import { ligandPropertyApi } from '../../apps/web/src/ligandProperties/api';
import { PROPERTY_PREFERENCES_KEY, PROPERTY_REGISTRY_KEY, propertyInputKey } from '../../apps/web/src/ligandProperties/context';
import { PropertyInputOwner } from '../../apps/web/src/ligandProperties/ownership';
import { LigandPropertySession, propertySourceIdentity } from '../../apps/web/src/ligandProperties/session';
import { useLigandProperties, usePropertySourceVerification } from '../../apps/web/src/ligandProperties/useProperties';
import { getLigandInventoryOwner, inventorySourceKey } from '../../apps/web/src/ligands/inventoryQualification';
import { propertyPreferences, deferredProperty } from '../../apps/web/src/test/ligand-properties-fixtures';

const registry = parseProfileRegistry(metadata);
const descriptors = {...registry.descriptor_method, definitions:[...registry.descriptors]};
const sidebar = process.cwd().includes('issue-161-');
const disposals: (()=>void)[]=[];
// Controlled numerical transport for authority checks; no descriptor calculation is claimed.
const numbers: Record<string,number>={molecular_weight:46.069,hbd:1,hba:1,calculated_logp:-0.0014};
function ready(projectId:string, source:any, ids:string[]) {
 return {project_id:projectId,entries:[{source:structuredClone(source),binding_key:'b'.repeat(64),status:'ready',reason:null,progress:100,
 report:{schema_version:1,input_hash:'c'.repeat(64),...registry.descriptor_method,created_at:'2026-11-17T00:00:00Z',model_status:'qualified',model_reason:null,
 contains_formally_charged_atoms:false,provenance:['Controlled authority transport'],coverage:ids,
 values:ids.map(id=>({descriptor_id:id,status:'ready',reason:null,value:numbers[id]}))}}]};
}
beforeEach(()=>{
 vi.spyOn(ligandProfileApi,'registry').mockResolvedValue(registry);
 vi.spyOn(ligandPropertyApi,'registry').mockResolvedValue(descriptors);
 vi.spyOn(ligandPropertyApi,'preferences').mockResolvedValue({...propertyPreferences,enabled_categories:[]});
 vi.spyOn(ligandPropertyApi,'read').mockImplementation(async(id,body)=>ready(id,body.entries[0],body.descriptor_ids) as any);
 vi.spyOn(ligandPropertyApi,'allocate').mockRejectedValue(Error('Unexpected allocation'));
 vi.spyOn(ligandPropertyApi,'demand').mockRejectedValue(Error('Unexpected demand'));
 vi.spyOn(ligandPropertyApi,'release').mockResolvedValue({});
});
afterEach(()=>{cleanup();disposals.splice(0).reverse().forEach(f=>f());vi.restoreAllMocks()});
function setup(item=proof.physical_cases[0]) {
 const client=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity}}});
 client.setQueryData(PROPERTY_PREFERENCES_KEY,{...propertyPreferences,enabled_categories:[]});
 const selection=new ProfileSelection(client); selection.select('ro5');
 let project:any=structuredClone(item.project), entryId=project.entries[0].id, pausedReason:string|null=null, state:any;
 const inventory=getLigandInventoryOwner(client);
 const owner=new PropertyInputOwner(()=>{const entry=project.entries.find((e:any)=>e.id===entryId);const r=client.getQueryData<any>(PROPERTY_REGISTRY_KEY),p=client.getQueryData<any>(PROPERTY_PREFERENCES_KEY);
 return {activeProjectId:project.id,inspectedEntryId:entryId,paused:!!pausedReason,
 sourceIdentity:entry?{projectId:project.id,entryId:entry.id,currentArtifactId:entry.current_artifact_id,originalArtifactId:entry.original_artifact_id}:null,
 inputKey:propertyInputKey(project.id,entry,r,p,selection.dependencies(r))}});
 const session=new LigandPropertySession(t=>owner.capture(t));
 const events=vi.fn(); const stop=inventory.subscribeVerificationFailures(events);
 function Harness({visible}:{visible:boolean}) {
  useLayoutEffect(()=>{owner.activate();session.activate();owner.observe();return()=>{owner.deactivate();session.deactivate()}},[]);
  usePropertySourceVerification(inventory,session,owner);
  const profiles=useLigandProfiles(true,selection,owner);
  state=useLigandProperties({project,entryId,pausedReason,session,owner,profileSelection:selection});
  return visible?<LigandProperties state={state} session={session} profiles={profiles} {...({showComparison:true} as {})}/>:null;
 }
 const tree=(visible=true)=><QueryClientProvider client={client}><Tooltip.Provider><StrictMode><Harness visible={visible}/></StrictMode></Tooltip.Provider></QueryClientProvider>;
 const rendered=render(tree());
 const identity=()=>propertySourceIdentity(state.target);
 const key=(s=identity())=>['ligand-candidates','ligand-instance-v3',s.projectId,s.entryId,s.currentArtifactId,s.originalArtifactId,'ligand-exact-representation-v2','ligand-occurrence-v1','designation',0,12];
 const qualify=async()=>{await act(async()=>{await client.fetchQuery({queryKey:key(),queryFn:async()=>item.recovered_inventory,staleTime:0})})};
 const captured=()=>profileInputAuthority(state,session,selection,registry,'ro5').capture();
 const evaluate=()=>evaluateProfile(registry,'ro5',profileInputAuthority(state,session,selection,registry,'ro5'));
 const axes=()=>profileAxisValues(registry,'ro5',profileInputAuthority(state,session,selection,registry,'ro5'));
 const blocked=()=>inventory.qualification(inventorySourceKey({id:project.id},project.entries.find((e:any)=>e.id===entryId))).blocked;
 disposals.push(()=>{stop();session.deactivate();inventory.deactivate();client.clear()});
 return {client,owner,session,events,rendered,state:()=>state,identity,key,qualify,captured,evaluate,axes,blocked,
 hide:()=>act(()=>rendered.rerender(tree(false))),show:()=>act(()=>rendered.rerender(tree(true))),
 switchSource:()=>act(()=>{project=structuredClone(project);project.entries[0].current_artifact_id='different-current';owner.observe();rendered.rerender(tree())}),
 retry:()=>act(()=>session.retry(state.target))};
}
async function current(app:ReturnType<typeof setup>){await waitFor(()=>expect(app.evaluate().status).toBe('pass'));expect(app.state().target.descriptorIds).toEqual(expect.arrayContaining(['molecular_weight','hbd','hba','calculated_logp']));expect(app.client.getQueryData<any>(PROPERTY_PREFERENCES_KEY).enabled_categories).toEqual([])}
function retired(app:ReturnType<typeof setup>,captured:any){expect(captured.isCurrent()).toBe(false);expect(app.session.view(app.state().target).current).toBeUndefined();expect(app.evaluate().criteria.every((r:any)=>r.value===null)).toBe(true);expect(app.axes().every((r:any)=>r.value===null&&r.normalized===null)).toBe(true);expect(screen.queryByText('Within profile criteria.')).not.toBeInTheDocument();if(sidebar){expect(app.rendered.container.querySelector('.comparison-shape')).toBeNull();expect(app.rendered.container.querySelectorAll('.comparison-point')).toHaveLength(0);expect(app.rendered.container.querySelectorAll('.comparison-table [data-descriptor]')).toHaveLength(4);for(const cell of app.rendered.container.querySelectorAll('.comparison-table td>span:first-child'))expect(cell.textContent).toBe('Unavailable')}}

describe('Independent propagated source retirement in actual profile consumers',()=>{
 for(const producer of ['candidate-conflict','candidate-integrity','candidate-missing','depiction-current','depiction-original'])it(`${producer} retires captured profile authority synchronously`,async()=>{
  const app=setup();await current(app);const captured=app.captured(),source=app.identity();
  const depiction=producer.startsWith('depiction');
  const queryKey=depiction?['ligand-depiction','ligand-instance-v3','ligand-2d-v1','committed',source.projectId,source.entryId,source.currentArtifactId,source.originalArtifactId,'ligand-exact-representation-v2','inventory-hash','candidate',240,180]:app.key();
  const code=producer==='candidate-conflict'?'structure_artifact_conflict':producer==='candidate-missing'?'artifact_not_found':'artifact_integrity_error';
  const error=new ApiError(code==='artifact_not_found'?404:409,code,'Controlled exact-source query',[],[],null,producer==='depiction-current'?'current':producer==='depiction-original'?'original':null);
  await act(async()=>{await app.client.fetchQuery({queryKey,queryFn:async()=>{throw error},staleTime:0}).catch(()=>{});expect(captured.isCurrent()).toBe(false);expect(app.session.view(app.state().target).current).toBeUndefined()});
  retired(app,captured);expect(app.events).toHaveBeenCalledTimes(1);expect(app.blocked()).toBe(true);expect(ligandPropertyApi.allocate).not.toHaveBeenCalled();expect(ligandPropertyApi.demand).not.toHaveBeenCalled();
 });
 for(const item of proof.physical_cases) for(const order of ['candidate-first','numeric-first']) it(`${item.role}/${item.kind}/${order}: no profile, axis, radar or table authority survives`,async()=>{
  const app=setup(item);await current(app);await app.qualify();const captured=app.captured();
  const calls=vi.mocked(ligandPropertyApi.read).mock.calls.length;
  let synchronous=false;const stop=app.session.subscribe(()=>{if(app.events.mock.calls.length)synchronous=!captured.isCurrent()&&app.session.view(app.state().target).current===undefined});
  vi.mocked(ligandPropertyApi.read).mockResolvedValueOnce(item.response as any);app.retry();
  await waitFor(()=>expect(app.events).toHaveBeenCalledTimes(1));retired(app,captured);expect(synchronous).toBe(true);stop();expect(app.blocked()).toBe(true);
  if(order==='candidate-first'){await app.qualify();expect(app.blocked()).toBe(false);retired(app,captured);expect(ligandPropertyApi.read).toHaveBeenCalledTimes(calls+1);app.retry();await current(app)}
  else{app.retry();await current(app);expect(app.blocked()).toBe(true);await app.qualify();expect(app.blocked()).toBe(false)}
  expect(captured.isCurrent()).toBe(false);expect(ligandPropertyApi.read).toHaveBeenCalledTimes(calls+2);expect(app.events).toHaveBeenCalledTimes(1);expect(ligandPropertyApi.allocate).not.toHaveBeenCalled();expect(ligandPropertyApi.demand).not.toHaveBeenCalled();
 });
 it('keeps the bridge during hidden presentation and remount without automatic requalification',async()=>{
  const app=setup();await current(app);const captured=app.captured();app.hide();vi.mocked(ligandPropertyApi.read).mockResolvedValueOnce(proof.physical_cases[0].response as any);app.retry();await waitFor(()=>expect(app.events).toHaveBeenCalledTimes(1));const reads=vi.mocked(ligandPropertyApi.read).mock.calls.length;app.show();retired(app,captured);expect(ligandPropertyApi.read).toHaveBeenCalledTimes(reads);
 });
 for(const kind of ['worker','capacity','chemistry','derived_report','transport','semantic'])it(`${kind} has no canonical physical source authority`,async()=>{
  const app=setup();await current(app);await app.qualify();
  if(kind==='transport'||kind==='semantic')vi.mocked(ligandPropertyApi.read).mockRejectedValueOnce(new ApiError(kind==='transport'?0:409,kind==='transport'?'network_error':'structure_artifact_conflict','Controlled failure'));
  else{const row=structuredClone(proof.physical_cases[0].response) as any;row.entries[0].source_failure=null;row.entries[0].reason='Source failed integrity verification or is missing';row.entries[0].status=['capacity','chemistry'].includes(kind)?'unavailable':'failed';vi.mocked(ligandPropertyApi.read).mockResolvedValueOnce(row)}
  app.retry();await waitFor(()=>expect(app.session.view(app.state().target).current).toBeUndefined());expect(app.events).not.toHaveBeenCalled();expect(app.blocked()).toBe(false);
 });
 it('preserves current profile values for unrelated-source and untagged derived SVG query failures',async()=>{
  const app=setup();await current(app);const captured=app.captured();
  const source=app.identity();await act(async()=>{await app.client.fetchQuery({queryKey:app.key({...source,currentArtifactId:'other-current'}),queryFn:async()=>{throw new ApiError(409,'artifact_integrity_error','Other source')}}).catch(()=>{})});
  expect(captured.isCurrent()).toBe(true);expect(app.evaluate().status).toBe('pass');
  const depiction=['ligand-depiction','ligand-instance-v3','ligand-2d-v1','committed',source.projectId,source.entryId,source.currentArtifactId,source.originalArtifactId,'ligand-exact-representation-v2','inventory-hash','candidate',240,180];
  await act(async()=>{await app.client.fetchQuery({queryKey:depiction,queryFn:async()=>{throw new ApiError(409,'artifact_integrity_error','Derived SVG')}}).catch(()=>{})});
  expect(captured.isCurrent()).toBe(true);expect(app.evaluate().status).toBe('pass');expect(app.blocked()).toBe(false);
 });
 it('rejects a held physical A response after switching to B',async()=>{
  const app=setup();await current(app);const held=deferredProperty<any>();vi.mocked(ligandPropertyApi.read).mockReturnValueOnce(held.promise);app.retry();app.switchSource();await current(app);const b=app.captured();
  await act(async()=>{held.resolve(proof.physical_cases[0].response);await held.promise});expect(app.events).not.toHaveBeenCalled();expect(b.isCurrent()).toBe(true);expect(app.evaluate().status).toBe('pass');
 });
});
