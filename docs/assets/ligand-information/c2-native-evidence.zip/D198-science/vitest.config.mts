import base from '../../apps/web/vite.config.ts';
export default { ...base, test: { ...base.test, include: [new URL('./profile-source.test.tsx', import.meta.url).pathname] } };
