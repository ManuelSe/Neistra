"""Bind the exact borrowed migration tests to their actual destination checkout."""
from pathlib import Path
import hashlib
import json
import configparser

def pytest_collection_modifyitems(session, config, items):
    root = Path.cwd().resolve()
    assert root.name in {"issue-160-physicochemical-profiles", "issue-161-ligand-information-sidebar"}
    expected = root / ".issue-11-evidence/issue159-prelaunch-recovery-propagation/borrowed-regressions/test_ligand_property_migration.py"
    matched = []
    for item in items:
        module = item.module
        if Path(module.__file__).resolve() == expected:
            assert hashlib.sha256(expected.read_bytes()).hexdigest() == "de1ae16293eecd4ce005c9c64fc06c1fd49f92053de877dbcd060071165f3416"
            module.ROOT = root
            matched.append(item)
    assert len(matched) == 3, "All three unchanged migration cases must be collected"
    source_map_path = root / ".issue-11-evidence/issue159-prelaunch-recovery-propagation/source-after.json"
    expected_sources = json.loads(source_map_path.read_text())
    observed_sources = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in expected_sources}
    assert observed_sources == expected_sources
    configuration = configparser.ConfigParser()
    configuration.read(root / "alembic.ini")
    migration_root = root / configuration["alembic"]["script_location"]
    assert migration_root.resolve() == root / "apps/api/migrations"
    assert (migration_root / "env.py").is_file()
    version = migration_root / "versions/0017_ligand_properties.py"
    assert hashlib.sha256(version.read_bytes()).hexdigest() == expected_sources[str(version.relative_to(root))]
    receipt = {"scope": "Exact borrowed migration tests, collection-time actual destination binding before execution", "actual_destination_root": str(root), "actual_test_module_ROOT": str(matched[0].module.ROOT), "borrowed_test_sha256": hashlib.sha256(expected.read_bytes()).hexdigest(), "only_test_module_change": "ROOT bound to actual destination; assertions and source body unchanged", "actual_alembic_ini": str(root / "alembic.ini"), "actual_alembic_ini_sha256": hashlib.sha256((root / "alembic.ini").read_bytes()).hexdigest(), "actual_migration_script_location": str(migration_root.resolve()), "actual_migration0017_sha256": hashlib.sha256(version.read_bytes()).hexdigest(), "selected_source_count": len(expected_sources), "selected_source_map_sha256": hashlib.sha256(source_map_path.read_bytes()).hexdigest(), "all_selected_source_bodies_exact_before_execution": True, "collected_borrowed_case_ids": [item.nodeid for item in matched], "collected_borrowed_cases": len(matched), "before_execution": True}
    output = Path(config.option.basetemp).parent / "borrowed-migration-location-before-execution.json"
    assert not output.exists()
    output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
