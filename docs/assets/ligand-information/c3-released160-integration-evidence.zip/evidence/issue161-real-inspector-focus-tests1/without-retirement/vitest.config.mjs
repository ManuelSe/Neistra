import base from "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/vite.config.ts";
import { mergeConfig } from "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/node_modules/vitest/dist/config.js";
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
const target="/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web/src/App.tsx";
const mode="without-retirement";
const expected="7be24c8112c979d88d9b0d96309eeef9bb46e51f7084eb25e8707d09a55e205f";
const plugin = { name: "controlled-opening-focus-history", enforce: "pre", load(id) {
  if (id.split("?")[0] !== target) return null;
  const original = readFileSync(target, "utf8");
  const hash = value => createHash("sha256").update(value).digest("hex");
  if (hash(original) !== expected) throw new Error("Current App source changed during isolated control");
  const end = original.indexOf("  const projectsQuery = useQuery({");
  const start = original.lastIndexOf("  useEffect(() => {", end);
  if (start < 0 || end < start) throw new Error("Opening effect not found");
  let replacement = original.slice(start, end);
  if (mode === "without-retirement") {
    for (const [before, after] of [["    let retired = false;\n", ""], ["if (retired || ", "if ("], ["      retired = true;\n", ""]]) {
      if (!replacement.includes(before)) throw new Error("Retirement control did not match expected source");
      replacement = replacement.replace(before, after);
    }
  } else replacement = readFileSync("/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-real-inspector-focus-tests1/released038-opening-effect.txt", "utf8");
  const code = original.slice(0, start) + replacement + original.slice(end);
  writeFileSync("/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-real-inspector-focus-tests1/without-retirement/virtual-source.json", JSON.stringify({mode, actual_app_sha256: hash(original), virtual_app_sha256: hash(code), original_file_changed: false}, null, 2)+"\n");
  return code;
} };
export default mergeConfig(base, { root: "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/apps/web", plugins: [plugin], test: {
  include: ["src/test/ligand-information-opening-focus.test.tsx"], reporters: ["json"], outputFile: "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-real-inspector-focus-tests1/without-retirement/results.json"
} });
