from pathlib import Path
import datetime,hashlib,json,runpy,zipfile
r=Path.cwd();e=r/'.issue-11-evidence';out=e/'issue161-sidebar50-retention1';out.mkdir();parts=out/'parts';parts.mkdir();h=runpy.run_path(str(r/'docs/assets/ligand-information/release-evidence.py.txt'));limit=80*1024*1024
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labels=['issue161-current-sidebar-acceptance50-run1']
allparts=[];campaigns=[]
for label in labels:
 p=e/label;execution=json.loads((p/'execution.json').read_bytes());closure=json.loads((p/'closed-raw-copy-receipt.json').read_bytes());assert closure['positive_closed'] and not closure['live_owned_pids'] and all(closure['ports_closed'].values());assert execution['selected_source_bodies_unchanged'];assert execution.get('reviewed_working_bodies_unchanged',True)
 for pair in closure['files']:
  a,b=Path(pair['original']),Path(pair['copy']);assert a.read_bytes()==b.read_bytes() and sha(a)==pair['sha256'] and a.stat().st_size==pair['bytes']
 trees={'evidence':p,'store':Path(execution['run_root'])};items={};rows=[];empties=[]
 for kind,tree in trees.items():
  assert tree.is_dir() and not tree.is_symlink()
  for f in sorted(tree.rglob('*')):
   assert not f.is_symlink(),f
   rel=f.relative_to(tree).as_posix();name=f'{label}/{kind}/{rel}'
   if f.is_dir():
    if not any(f.iterdir()):empties.append({'kind':kind,'path':rel})
   else:
    assert f.is_file();s=f.stat();row={'member':name,'original':str(f),'bytes':s.st_size,'sha256':sha(f),'mtime_ns':s.st_mtime_ns,'mode':s.st_mode};rows.append(row);items[name]=f
 source=json.loads((p/'source-before.json').read_bytes());assert source==json.loads((p/'source-after.json').read_bytes())
 with zipfile.ZipFile(p/'source-before.zip') as z:
  assert set(z.namelist())==set(source) and z.testzip() is None
  assert all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in source.items())
 record={'campaign':label,'runner_exit_code':execution['exit_code'],'source_count':len(source),'trees':{k:str(v) for k,v in trees.items()},'files':rows,'empty_directories':empties,'positive_closed_before_raw_copy':True,'raw_pairs':len(closure['files']),'primary_diagnostic_SQL':False,'originals_retained':True}
 items[f'{label}/capture.json']=h['encoded'](record);groups=[];group={};used=0
 for name,member in sorted(items.items()):
  estimate=h['compressed_size'](member)+len(name.encode())*2+512
  assert estimate<limit-1024*1024,(name,estimate)
  if group and used+estimate>=limit-1024*1024:groups.append(group);group={};used=0
  group[name]=member;used+=estimate
 if group:groups.append(group)
 for g in groups:
  n=len(allparts)+1;target=parts/f'c3-sidebar50-forensics-{n:02}.zip';rec=h['archive'](g,target);assert rec['bytes']<limit
  check=target.with_name(target.name+'.sha256');check.write_text(f'{rec["sha256"]}  {target.name}\n');rec.update(campaign=label,runner_exit_code=execution['exit_code'],checksum_file=check.name,checksum_sha256=sha(check));allparts.append(rec)
 assert all(Path(row['original']).stat().st_size==row['bytes'] and sha(Path(row['original']))==row['sha256'] and Path(row['original']).stat().st_mtime_ns==row['mtime_ns'] for row in rows)
 campaigns.append({'campaign':label,'runner_exit_code':execution['exit_code'],'physical_files':len(rows),'physical_bytes':sum(x['bytes'] for x in rows),'empty_directories':len(empties),'raw_pairs':len(closure['files']),'source_count':len(source),'capture_member':f'{label}/capture.json','parts':[x['file'] for x in allparts if x['campaign']==label]})
 (out/'progress.json').write_text(json.dumps({'completed_campaigns':campaigns,'parts':allparts},indent=2)+'\n');print(label,'retained',len(rows),'parts',len(groups),flush=True)
index={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Complete original terminal50case sidebar acceptance after all compact, reading and screenshot corrections; this is focused native acceptance, not full release/performance qualification.','packager_sha256':sha(e/'retain-sidebar50-history1.py'),'part_limit_bytes_exclusive':limit,'parts':allparts,'part_count':len(allparts),'part_bytes':sum(x['bytes'] for x in allparts),'campaigns':campaigns,'all_originals_preserved_and_rehashed':True,'exact_source_zip_maps_verified':True,'all_ZIP_CRC_manifest_and_nested_layers_verified':True,'no_primary_SQL_used':True,'separate_publication_required':True,'publication_verified':False,'not_full_feature_or_performance_qualification':True}
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n');(r/'docs/assets/ligand-information/c3-sidebar50-forensics-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({'parts':len(allparts),'bytes':index['part_bytes'],'index_sha256':sha(out/'index.json')}),flush=True)
