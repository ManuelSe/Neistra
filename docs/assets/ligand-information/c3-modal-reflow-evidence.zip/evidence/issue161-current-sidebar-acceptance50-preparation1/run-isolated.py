"""Run current profile correctness/access workflows; retain terminal facts and raw stores."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, runpy, shutil, socket, subprocess, time, zipfile

parser=argparse.ArgumentParser()
parser.add_argument("label")
parser.add_argument("--api-port",type=int,required=True)
parser.add_argument("--worker-port",type=int,required=True)
parser.add_argument("--web-port",type=int,required=True)
a=parser.parse_args()
assert a.label.startswith("issue161-current-sidebar-acceptance50-") and a.label.replace("-","").isalnum()
root=Path.cwd().resolve()
ev=root/".issue-11-evidence"/a.label
run=Path("/tmp")/("neistra161-"+a.label.removeprefix("issue161-"))
assert not ev.exists() and not run.exists(),"Fresh label required; earlier attempts remain intact"
initial_status=subprocess.check_output(["git","status","--porcelain=v1"],text=True)
expected_files={'apps/web/src/App.tsx': 'a296a3825a57b2f56814b071e7030e6208fdb596c322ccd02eab5c411554711f', 'apps/web/src/components/ProjectInspector.tsx': 'e3790726679554b887d31d2360af22fd5cee7b29ed8a259e9b710295b9fde109', 'apps/web/src/components/inspectorReadingPosition.ts': '90bebffff8c1a617d32ea6ef5af3f522d744a07dfb38fc1c94b92a9cf9fbb599', 'apps/web/src/styles.css': 'd0ca10c3e3d79a38ad11820e1d97f32d75f5a7604792dd7b72ebc8c72b844152', 'tests/e2e/ligand-information-access.spec.ts': 'fea0920d68796a38be6e883c5a54a2fd3fb7cab03ebaa740112b9573aaac4c52', 'apps/web/src/test/inspector-reading-position.test.tsx': 'a2a38fae3fc4fe1aac8c5f89f2ab73427d1802d32f6b0eb9be7e8706d5e9e967', 'apps/web/src/test/ligand-information-opening-focus.test.tsx': 'ec19852c26b5be66153444712a278977bde2b6c59c22117958239bf732ae4fe6', 'apps/web/src/components/compactPanelKeyboard.ts': '790a5ca90368e026796225653a186297caf4ea950d6e370c9bc4dc8229936e33', 'apps/web/src/test/compact-panel-keyboard.test.tsx': '1f97823fd9846fb5c7da0d730ba8fb192a97a2d71a0f7b9865db4bd496904cab', 'tests/e2e/ligand-information.spec.ts': 'b840cf14c198d9d27de1189ee6ff2445b7fd36c099afb6906718f1caabac111d', 'tests/e2e/ligand-information-lifecycle.spec.ts': 'abcb16f82f8fa216d1e3d5a6df028678710d9d57fc0baf3869a9e45e49d5011d', 'tests/e2e/ligand-information-compact.spec.ts': '6573a73e16930472a2e9ae4095f7e3ea7ccdd3da4ae7e3bc73376de0dbe363df', 'tests/e2e/ligand-information-reading.spec.ts': '4a4216c44e5fa373b8968165b882bc9cb686141e3a6fe97a44f82771640b7af4', 'tests/e2e/ligand-information-zoom.spec.ts': '8e1a56fe94f24bc3a1ba065526d0672314c573f0f2f810d93309a4e9c1394de8'}
assert initial_status, "This bounded campaign must record the frozen corrective working candidate"
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()=='9c09856171e9780721361b58f93ccca7d5ff23ad'
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected for name,expected in expected_files.items()),"Frozen corrective source changed"
for port in (a.api_port,a.worker_port,a.web_port):
 with socket.socket() as s:
  s.settimeout(.3); assert s.connect_ex(("127.0.0.1",port))!=0,"Port occupied"
ev.mkdir();run.mkdir()
helpers=runpy.run_path(str(root/"docs/assets/ligand-information/qualification.py.txt"))
def current_sources():
 observed=helpers["current_identities"](root)
 for name in ("qualification.py.txt","release-recipe.py.txt","versions.py.txt","production-audit.py.txt","qualification-summary.py.txt","release-evidence.py.txt"):
  path=root/"docs/assets/ligand-information"/name;assert path.is_file() and not path.is_symlink();observed[path.relative_to(root).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
 return dict(sorted(observed.items()))
preceding={"tag":"v0.38.0","version":"0.38.0","commit":"c6f3e283ef3f6bed4a00c6dfe3fef36bf5bc3f82"}
helpers["preceding_browser_baseline"](root,preceding)
assert len(helpers["qualification_data_inventory"](root))==6
source_before=current_sources()
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,value):
 (ev/name).write_text(json.dumps(value,indent=2)+"\n")
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
write("source-before.json",source_before)
with zipfile.ZipFile(ev/"source-before.zip","x",zipfile.ZIP_DEFLATED) as z:
 for name,expected in source_before.items():
  body=(root/name).read_bytes();assert sha(body)==expected;z.writestr(name,body)
existing=set((root/".issue-11-evidence/issue161-profile-performance").glob("*"))
argv=["corepack","pnpm","exec","playwright","test","tests/e2e/ligand-information.spec.ts","tests/e2e/ligand-information-access.spec.ts","tests/e2e/ligand-information-lifecycle.spec.ts","tests/e2e/ligand-information-compact.spec.ts","tests/e2e/ligand-information-reading.spec.ts","tests/e2e/ligand-information-zoom.spec.ts","--reporter=list,json","--max-failures=1","--output",str(ev/"playwright")]

env={k:v for k,v in os.environ.items() if not k.startswith(("NEISTRA_","MOLWEAVE_")) and k not in {"DATABASE_URL","PYTHONPATH"}}
data=run/"data"
env.update({"PYTHONPATH":":".join(str(root/x) for x in ("apps/api/src","packages/neistra_core/src","packages/neistra_demo_plugin/src",".")),"NEISTRA_E2E_DATA_DIR":str(data),"NEISTRA_E2E_API_PORT":str(a.api_port),"NEISTRA_E2E_WORKER_PORT":str(a.worker_port),"NEISTRA_E2E_WEB_PORT":str(a.web_port),"NEISTRA_PROPERTY_WORKER_TRACE":str(data/"qualification/worker-turns.jsonl"),"NEISTRA_MINIMIZATION_EVIDENCE_DIR":str(run/"native"),"NEISTRA_AMBERTOOLS_PREFIX":"/datadisk/dev/.neistra-tools/ambertools-24.8","NEISTRA_PERFORMANCE":"0","NEISTRA_QUALIFICATION_VERSION":"0.39.0","NEISTRA_QUALIFICATION_BASE":"c6f3e283ef3f6bed4a00c6dfe3fef36bf5bc3f82","PLAYWRIGHT_BROWSERS_PATH":"/datadisk/dev/neistra/.playwright","PLAYWRIGHT_JSON_OUTPUT_FILE":str(ev/"browser.json"),"OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1"})
command={"argv":argv,"cwd":str(root),"candidate":head,"clean_start":not bool(initial_status),"initial_status":initial_status,"subject":"161 frozen9c098561 plus current bounded correction and permanent regression drivers; complete current50sidebar acceptance; not complete feature/release qualification","started_utc":now(),"ports":{"api":a.api_port,"worker":a.worker_port,"web":a.web_port},"run_root":str(run),"data_dir":str(data),"qualification_scope":"Complete50sidebar cases across6files/bothactualrunnercontexts; all40existing cases preserved plus10permanent keyboard/reflow/actualzoom guards; unchanged scientific/reading assertions and deadlines; settledOptions/fullsurface200capture; correctnessonly, performance/finalfeature/full43 gates separate","performance_profile":"portable correctness; no strict-host timing claim","source_count":len(source_before),"published038_baseline_present":True,"no_performance_claim":True}
write("command.json",command)
with (ev/"stdout.log").open("wb") as stdout,(ev/"stderr.log").open("wb") as stderr:
 proc=subprocess.Popen(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 write("running.json",command|{"runner_pid":proc.pid});print("RUNNING",proc.pid,str(ev),flush=True)
 code=proc.wait()
after=current_sources();write("source-after.json",after)
current_head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
cases=sorted(set((root/".issue-11-evidence/issue161-profile-performance").glob("*"))-existing)
reviewed_bodies_unchanged=all(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected for name,expected in expected_files.items())
result=command|{"runner_pid":proc.pid,"finished_utc":now(),"exit_code":code,"selected_source_bodies_unchanged":source_before==after and current_head==head,"reviewed_working_bodies_unchanged":reviewed_bodies_unchanged,"case_dirs":[str(x) for x in cases],"logs":{n:{"bytes":(ev/n).stat().st_size,"sha256":sha((ev/n).read_bytes())} for n in ("stdout.log","stderr.log")}}
write("execution.json",result)
# Cleanup proof must precede every raw copy; do not infer it from runner exit alone.
def owners():
 live=[]
 for p in Path("/proc").iterdir():
  if not p.name.isdigit(): continue
  try:
   stat=(p/"stat").read_text().rsplit(")",1)[1].split()
   if stat[0] in {"Z","X","x"}: continue
   values=(p/"environ").read_bytes().split(b"\0")
   if any(v in values for v in (b"NEISTRA_E2E_DATA_DIR="+str(data).encode(),b"NEISTRA_DATA_DIR="+str(data).encode(),b"MOLWEAVE_DATA_DIR="+str(data).encode())):
    live.append(int(p.name))
  except (OSError,PermissionError,ProcessLookupError):pass
 return live
live=owners()
for _ in range(40):
 if not live:break
 time.sleep(.25);live=owners()
ports={}
for port in (a.api_port,a.worker_port,a.web_port):
 with socket.socket() as s:s.settimeout(.3);ports[str(port)]=s.connect_ex(("127.0.0.1",port))!=0
observers=[]
for case in cases:
 f=case/"observer-execution.json"
 observers.append({"case":str(case),"execution":json.loads(f.read_bytes()) if f.exists() else None})
closed=not live and all(ports.values()) and all(x["execution"] and x["execution"].get("completion")=={"code":0,"signal":None} for x in observers)
cleanup={"recorded_utc":now(),"runner_exit_code":code,"live_owned_pids":live,"ports_closed":ports,"observer_executions":observers,"positive_closed":closed,"primary_diagnostic_sql_before_copy":False,"files":[]}
write("cleanup.json",cleanup)
if closed:
 raw=ev/"closed-raw";raw.mkdir()
 for f in sorted(run.rglob("*")):
  if f.is_file() and f.name.endswith((".db",".db-wal",".db-shm",".sqlite",".sqlite-wal",".sqlite-shm")):
   q=raw/f.relative_to(run);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,q)
   b=f.read_bytes();assert q.read_bytes()==b;cleanup["files"].append({"original":str(f),"copy":str(q),"bytes":len(b),"sha256":sha(b)})
 write("closed-raw-copy-receipt.json",cleanup)
print(json.dumps({"exit_code":code,"source_unchanged":result["selected_source_bodies_unchanged"],"positive_closed":closed,"raw_copies":len(cleanup["files"]),"evidence":str(ev)}),flush=True)
raise SystemExit(code if code else (0 if closed and result["selected_source_bodies_unchanged"] and result["reviewed_working_bodies_unchanged"] else 2))
