import { defineConfig } from "@playwright/test";
import { resolve } from "node:path";
import base from "../../playwright.config";
const root = process.cwd();
const servers = base.webServer ? Array.isArray(base.webServer) ? base.webServer : [base.webServer] : [];
export default defineConfig({ ...base,
  testDir: resolve(root, ".issue-11-evidence/issue161-compact-modal-boundaries-preparation1"),
  testMatch: "compact-modal-boundaries.spec.ts", workers: 1, fullyParallel: false,
  webServer: servers.map(server => ({ ...server, cwd: root, reuseExistingServer: false })),
});
