import { ESLint } from '../../apps/web/node_modules/eslint/lib/api.js';
import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const root = process.cwd(), out = resolve(root, '.issue-11-evidence/issue161-reading-boundaries-preparation3/static1');
const lint = new ESLint({ cwd: root, overrideConfigFile: resolve(root, 'apps/web/eslint.config.js'), overrideConfig: [{ files: ['**/*.{ts,tsx}'], languageOptions: { parserOptions: { project: [resolve(out, 'tsconfig.native.json')], tsconfigRootDir: root } } }] });
const results = await lint.lintFiles(["tests/e2e/ligand-properties-access.spec.ts", "tests/e2e/ligand-properties.spec.ts", "tests/e2e/ligand-properties-performance.spec.ts", "tests/e2e/ligand-profiles-access.spec.ts", "tests/e2e/ligand-profiles-performance.spec.ts", "tests/e2e/ligand-information-access.spec.ts", "tests/e2e/release-hardening.spec.ts", ".issue-11-evidence/issue161-reading-boundaries-preparation3/reading-boundaries.spec.ts"]), formatter = await lint.loadFormatter('stylish');
await writeFile(resolve(out, 'native-lint-result.json'), JSON.stringify(results, null, 2) + '\n');
const text = formatter.format(results); await writeFile(resolve(out, 'native-lint-result.log'), text); process.stdout.write(text);
process.exitCode = results.some(r => r.errorCount || r.warningCount) ? 1 : 0;
