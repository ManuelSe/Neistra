from pathlib import Path
import ast
import copy
import hashlib
import json
import runpy

root = Path('/datadisk/dev/neistra-worktrees/issue-160-mobile-panel-focus')
prep = Path(__file__).parent
controls = prep/'final-negative-controls'
controls.mkdir()
execution = root/'.issue-11-evidence/issue160-c4-candidate5-run1'
load = lambda path: json.loads(path.read_bytes())
gate = load(root/'docs/assets/ligand-profiles/c4-candidate5-gate.json')
recipe = load(root/'docs/assets/ligand-profiles/c4-candidate5-recipe.json')
running = load(execution/'running.json')
cleanup = load(execution/'cleanup.json')
raw = load(execution/'closed-raw-copy-receipt.json')
original = load(prep/'unrelated-desktop-processes.json')
source = (prep/'postgate-retention.py').read_bytes()
rows = []
for name in ('wrong-boot','unknown-denied-instance','pinned-command-drift','does-not-predate-program','owned-session-cannot-be-exempted','proof-changes-between-passes'):
    directory = controls/name
    directory.mkdir()
    proof = copy.deepcopy(original)
    r,c,w = copy.deepcopy(running),copy.deepcopy(cleanup),copy.deepcopy(raw)
    if name == 'wrong-boot':
        proof['boot_id'] = 'wrong-boot'
        expected = 'boot identity differs'
    elif name == 'unknown-denied-instance':
        proof['processes'][0]['pid'] = 444444
        expected = 'Unknown process denies'
    elif name == 'pinned-command-drift':
        proof['processes'][0]['cmdline_sha256'] = '0'*64
        expected = 'identity drifted'
    elif name == 'does-not-predate-program':
        proof['program_start_upper_bound_utc'] = '2020-01-01T00:00:00+00:00'
        expected = 'does not predate program'
    elif name == 'owned-session-cannot-be-exempted':
        r['runner_pid'] = 2381
        sessions = {2381}|{s['isolated_child_pid'] for s in gate['steps'] if 'isolated_child_pid' in s}
        c['observed_step_session_ids'] = w['observed_step_session_ids'] = sorted(sessions)
        expected = 'Active campaign'
    else:
        expected = 'Unrelated process proof changed during capture'
    script = directory/'postgate-retention.py'
    script.write_bytes(source)
    proof_path = directory/'unrelated-desktop-processes.json'
    proof_path.write_text(json.dumps(proof,indent=2)+'\n')
    module = runpy.run_path(str(script))
    def invoke():
        return module['verify_closure'](Path('/tmp/neistra160-c4-candidate5'),execution,r,gate,c,w,recipe)
    try:
        before = invoke()
        if name == 'proof-changes-between-passes':
            proof_path.write_bytes(proof_path.read_bytes()+b'\n')
            after = invoke()
            # Execute the actual source call used by main, against two real guard results.
            calls = [node for node in ast.walk(ast.parse(source)) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='require' and len(node.args)==2 and isinstance(node.args[1],ast.Constant) and node.args[1].value==expected]
            assert len(calls)==1
            code = compile(ast.Expression(calls[0]),str(script),'eval')
            eval(code,{'require':module['require'],'closure':before,'closure_after':after})
    except module['Refusal'] as exc:
        assert expected in str(exc),(name,str(exc))
        rows.append({'control':name,'expected':expected,'actual':str(exc),'passed':True})
    else:
        raise AssertionError('Negative closure control accepted: '+name)
(prep/'final-negative-controls.json').write_text(json.dumps({'collector_sha256':hashlib.sha256(source).hexdigest(),'controls':rows,'actual_campaign_inputs_modified':False,'capture_or_SQL_performed':False},indent=2)+'\n')
print(json.dumps({'final_guard_negative_controls_passed':len(rows),'collector_sha256':hashlib.sha256(source).hexdigest()}))
