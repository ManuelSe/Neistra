"""Retain finite completed metadata without reopening the qualified campaign."""

from pathlib import Path
import hashlib
import json
import runpy
import subprocess


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ASSETS = ROOT / "docs/assets/ligand-information"
PACKET = ROOT / ".issue-11-evidence/issue161-c4-candidate5-postgate-retention1"
SUBJECT = "f83347b3c2d59a2a913a9198f99a5276992015b4"


def main() -> None:
    assert subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip() == SUBJECT
    gate = json.loads((ASSETS / "c4-candidate5-summary.json").read_bytes())
    assert gate["commit"] == SUBJECT and gate["complete_steps"] == 43
    for filename in ("architecture-assessment.json", "scientific-implementation-assessment.json", "ui-assessment.json"):
        report = json.loads((ROOT / ".issue-11-evidence/issue161-c5-final-retention-readback1" / filename).read_bytes())
        assert report["candidate"] == SUBJECT and report["verdict"] == "PASS", filename

    helpers = runpy.run_path(str(ASSETS / "release-evidence.py.txt"))
    items: dict[str, Path] = {}

    def add_file(name: str, path: Path) -> None:
        assert name not in items and path.is_file() and not path.is_symlink()
        helpers["safe_name"](name)
        items[name] = path

    def add_tree(name: str, relative: str) -> None:
        directory = ROOT / relative
        assert directory.is_dir() and not directory.is_symlink()
        for path in sorted(directory.rglob("*")):
            assert not path.is_symlink(), path
            if path.is_file():
                assert path.suffix not in {".pyc", ".pyo"}
                add_file(f"{name}/{path.relative_to(directory).as_posix()}", path)

    for name in ("result.json", "authority-index.json", "asset-plan.json", "input-verification.json", "post-capture-closure.json", "unchanged-package-gate.stdout.log"):
        add_file(f"retention/{name}", PACKET / name)
    for directory in ("gate-parts", "retained-state", "case-companions", "retained-state-authority"):
        for path in sorted((PACKET / directory).iterdir()):
            if path.is_file() and path.suffix in {".json", ".sha256"}:
                add_file(f"retention/{directory}/{path.name}", path)

    for prefix, relative in (
        ("postterminal", ".issue-11-evidence/issue161-c4-candidate5-postterminal-execution1"),
        ("readbacks", ".issue-11-evidence/issue161-c5-final-retention-readback1"),
        ("deployment/preparation1", ".issue-11-evidence/issue161-master-deployment-source-preparation1"),
        ("deployment/preparation2", ".issue-11-evidence/issue161-master-deployment-source-preparation2"),
        ("deployment/actual-controls", ".issue-11-evidence/issue161-master-deployment-validation1"),
        ("deployment/recipe-preparation", ".issue-11-evidence/issue161-merged-qualification-preparation1"),
    ):
        add_tree(prefix, relative)

    for filename in ("before-checkpoint-source-readback.json", "qualifying-selected-source-map.json", "master-recipe-builder-equality.json", "build-completion.py"):
        add_file(f"checkpoint/{filename}", HERE / filename)
    add_file("actual-attachments/index.json", ROOT / ".issue-11-evidence/issue161-c5-serialized-attachments2/index.json")
    add_file("publication/required-assets-before-completion.json", ROOT / ".issue-11-evidence/issue161-release-asset-preflight2/required-assets.json")

    before = {name: helpers["fingerprint"](path) for name, path in items.items()}
    target = ASSETS / "c3-candidate5-qualified-evidence.zip"
    receipt = helpers["archive"](items, target)
    assert receipt["bytes"] < 80 * 1024 * 1024
    assert before == {name: helpers["fingerprint"](path) for name, path in items.items()}
    record = {
        "schema": "issue161-candidate5-finite-completion-v1",
        "qualifying_candidate": SUBJECT,
        "scope": "Finite source/control/actual tool completion and independent readback metadata; original seven retained parts stay separate and unchanged",
        "archive": receipt,
        "inputs": before,
        "publication_performed": False,
        "no_future_receipt_or_part_hash_embedded_upstream": True,
        "derived_images": "Attachment index maps lossless derivatives; original PNG/JSON bodies remain in the separately retained serialized browser report, not duplicated here",
    }
    with (HERE / "completion-build-receipt.json").open("x") as output:
        json.dump(record, output, indent=2)
        output.write("\n")
    print(json.dumps({"receipt": str(HERE / "completion-build-receipt.json"), "archive": receipt}))


if __name__ == "__main__":
    main()
