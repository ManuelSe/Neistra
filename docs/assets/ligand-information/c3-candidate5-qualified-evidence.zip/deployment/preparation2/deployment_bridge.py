"""Validate a narrowly derived master deployment against immutable C5 evidence.

Post-launch metadata/source proof only. This is not a prelaunch, scientific,
terminal-completion, cleanup or publication certificate. No deployment is written.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import stat
import sys
from typing import Any

Json = dict[str, Any]
OLD_ROOT = "/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar"
NEW_ROOT = "/datadisk/dev/neistra-worktrees/issue-161-merged-qualification1"
OLD_LABEL, LABEL = "c4-candidate5", "c4-master1"
BASE_LAUNCHER = "514d781bf23a7b34301888351626afd5b225b47803cc5a1107cd745ec74ac896"
BASE_RECIPE = "41d142d85a93b41b2c4f93813d728bae36249ea43bf559c5d588b68694a0ff25"
MASTER_RECIPE = "4eed9acc9199334aae7284805f803fc3936af1a372a757c7ce57ffa303d6519e"
BASE_CONSUMER = "5493ef9937616f48ff1b3ad29551092c4b70572a35008ae17daee73e83a020d4"
BASE_CAPSULE = "c7ad98a8325ba384b2d89ea685a43ac32e63f62a1afa1b8de1307dec4669ba5a"
BASE_ASSESSMENTS = {
    "architecture-source-assessment.json": "cc8cd49100f96b542a836be2e4691f0c35d5feff97188c8db1327d00d2fb34df",
    "architecture-relocation-assessment.json": "51df992d7b3ea976fdfc36fe7a0504e2275b0ad5331c5187590392b39d36181f",
}
BASE_DIRECTORY = ".issue-11-evidence/issue161-c4-candidate5-preparation3"
ASSESSMENT_DIRECTORY = ".issue-11-evidence/issue161-c4-candidate5-preparation-readback1"
TOOLING = ".issue-11-evidence/issue161-master1-binding1"
SCANNER_STORAGE = ".issue-11-evidence/issue161-c4-master1-preparation2"
LEGACY = ".issue-11-evidence/issue161-postgate-retention-preparation1"
RECEIPT = ".issue-11-evidence/issue161-actual038-source1/receipt.json"
EXECUTION = ".issue-11-evidence/issue161-c4-master1-run1"
SUPERVISION = ".issue-11-evidence/issue161-c4-master1-outer-supervisor1"
TRANSFORMS = ((OLD_ROOT, NEW_ROOT), (OLD_LABEL, LABEL),
              ("issue161-actual038-source2", "issue161-actual038-source1"))
HEX = re.compile(r"[0-9a-f]{64}\Z")
COMMIT = re.compile(r"[0-9a-f]{40}\Z")
MAX_BYTES = 8 * 1024 * 1024

# Exact, additional adapter only. Every pre-existing authority function remains
# byte-exact. The manifest hash arrives externally; it is never embedded here.
ADAPTER = '''

DEPLOYMENT_BRIDGE_SHA256 = {bridge_sha!r}


def deployment_bridge_module():
    path = safe(Path(__file__).with_name('deployment_bridge.py'))
    require(identity(path)['sha256'] == DEPLOYMENT_BRIDGE_SHA256, 'Reviewed deployment bridge differs')
    spec = importlib.util.spec_from_file_location('issue161_master_deployment_bridge', path)
    require(spec is not None and spec.loader is not None, 'Cannot load deployment bridge')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def validate_deployment_preparation(preparation, assessments, expected_launcher, expected_recipe,
                                    *, deployment_path, expected_deployment_sha256, expected_merged_commit):
    return deployment_bridge_module().validate_deployment(deployment_path, expected_deployment_sha256,
        preparation=preparation, assessments=assessments, expected_launcher=expected_launcher,
        expected_recipe=expected_recipe, expected_merged_commit=expected_merged_commit,
        expected_bridge_sha256=DEPLOYMENT_BRIDGE_SHA256)
'''
OLD_CALL = '''        preparation_proof = authority_module().validate_launch_preparation(preparation, assessments,
            args.expected_launcher_sha256, args.expected_recipe_sha256)'''
NEW_CALL = '''        preparation_proof = authority_module().validate_deployment_preparation(preparation, assessments,
            args.expected_launcher_sha256, args.expected_recipe_sha256,
            deployment_path=safe_path(args.deployment_manifest),
            expected_deployment_sha256=args.expected_deployment_sha256, expected_merged_commit=gate['commit'])'''
OLD_ARGUMENT = '''                 "outer-wrapper-supervision-dir"):'''
NEW_ARGUMENT = '''                 "outer-wrapper-supervision-dir", "deployment-manifest", "expected-deployment-sha256"):'''
OLD_SELECTION = '''        authority["launch_preparation"] = preparation_proof'''
NEW_SELECTION = '''        authority["launch_preparation"] = preparation_proof
        deployment_bridge = authority_module().deployment_bridge_module()
        deployment_items, deployment_context = deployment_bridge.deployment_items(preparation_proof, root)
        deployment_original_items = dict(deployment_items)
        deployment_original_context = json.loads(json.dumps(deployment_context, sort_keys=True))'''
OLD_SUPPLEMENT = '''        case_result = supplemental(package, output, args.label, "case-companions", case_items, case_context)'''
NEW_SUPPLEMENT = '''        case_result = supplemental(package, output, args.label, "case-companions", case_items, case_context)
        deployment_result = supplemental(package, output, args.label, "deployment-preparation", deployment_items, deployment_context)'''
OLD_RECHECK = '''        proof_items = {"before-capture.json": output / "input-verification.json",'''
NEW_RECHECK = '''        require(authority_module().validate_deployment_preparation(preparation, assessments,
            args.expected_launcher_sha256, args.expected_recipe_sha256,
            deployment_path=safe_path(args.deployment_manifest),
            expected_deployment_sha256=args.expected_deployment_sha256, expected_merged_commit=gate['commit'])
            == preparation_proof, "Full deployment preparation changed during capture")
        deployment_bridge.verify_deployment_capture(preparation_proof, root,
            deployment_original_items, deployment_original_context)
        authority_module().verify_bindings(authority["input_bindings"])
        proof_items = {"before-capture.json": output / "input-verification.json",'''
OLD_CERTIFICATION = '''        certified_preparation = {}
        for original, expected in preparation_proof["input_bindings"].items():
            path = Path(original)
            member = ("launch-preparation/" + path.relative_to(preparation).as_posix()) if path.is_relative_to(preparation) else ("launch-preparation-assessments/" + path.relative_to(assessments).as_posix())
            require(state_locations[member]["payload"] == expected, "Packaged certified preparation body differs")
            certified_preparation[member] = state_locations[member]
        authority_index["launch_preparation"] = {
            "certified_inputs": certified_preparation,
            "retained_tree_members": {name: locator for name, locator in state_locations.items()
                if name.startswith(("launch-preparation/", "launch-preparation-assessments/"))},
            "scope": "Only certified_inputs are the current source/control certificate; other retained historical bodies preserve their original status"}'''
NEW_CERTIFICATION = '''        deployment_locations = strong.member_locations(load(Path(deployment_result["receipt"])),
            {name: package["fingerprint"](member) for name, member in deployment_items.items()})
        authority_index.update(deployment_bridge.certify_preparations(preparation_proof, root,
            preparation, assessments, state_locations, deployment_locations))'''
OLD_RESULT = '''"external_cases": case_result, "external_case_count":'''
NEW_RESULT = '''"deployment_preparation": deployment_result, "external_cases": case_result, "external_case_count":'''
COLLECTOR_EDITS = ((OLD_CALL, NEW_CALL), (OLD_ARGUMENT, NEW_ARGUMENT), (OLD_SELECTION, NEW_SELECTION),
                   (OLD_SUPPLEMENT, NEW_SUPPLEMENT), (OLD_RECHECK, NEW_RECHECK),
                   (OLD_CERTIFICATION, NEW_CERTIFICATION), (OLD_RESULT, NEW_RESULT))


def require(condition: object, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def identity(body: bytes) -> Json:
    return {"bytes": len(body), "sha256": sha(body)}


def safe(value: str | Path) -> Path:
    path = Path(value)
    require(path.is_absolute() and ".." not in path.parts and path == path.resolve(), "Noncanonical deployment path")
    require(not any(item.is_symlink() for item in (path, *path.parents)), "Symlink deployment path")
    return path


def read(path: Path) -> bytes:
    safe(path)
    before = path.stat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= MAX_BYTES,
            "Deployment input is aliased, nonregular or oversized")
    body = path.read_bytes()
    after = path.stat()
    fields = ("st_dev", "st_ino", "st_size", "st_mode", "st_mtime_ns", "st_nlink")
    require(tuple(getattr(before, field) for field in fields) == tuple(getattr(after, field) for field in fields)
            and len(body) == before.st_size, "Deployment input changed during read")
    return body


def no_duplicates(pairs: list[tuple[str, Any]]) -> Json:
    result: Json = {}
    for key, value in pairs:
        require(key not in result, "Duplicate deployment JSON field")
        result[key] = value
    return result


def decode(body: bytes) -> Json:
    value = json.loads(body, object_pairs_hook=no_duplicates)
    require(isinstance(value, dict), "Deployment metadata must be an object")
    return value


def fixed_transform(body: bytes) -> bytes:
    for old, new in TRANSFORMS:
        body = body.replace(old.encode(), new.encode())
    return body


def constants(body: bytes, replacements: Json) -> bytes:
    """Replace only existing module-level assignment values, preserving all else."""
    tree = ast.parse(body)
    lines = body.splitlines(keepends=True)
    offsets, total = [], 0
    for line in lines:
        offsets.append(total)
        total += len(line)
    changes = []
    for name, value in replacements.items():
        found = [node for node in tree.body if isinstance(node, ast.Assign) and len(node.targets) == 1
                 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == name]
        require(len(found) == 1, f"Declared module constant is absent/ambiguous: {name}")
        node = found[0].value
        require(node.end_lineno is not None and node.end_col_offset is not None, "Missing AST value extent")
        changes.append((offsets[node.lineno - 1] + node.col_offset,
                        offsets[node.end_lineno - 1] + node.end_col_offset, repr(value).encode()))
    for start, end, replacement in sorted(changes, reverse=True):
        body = body[:start] + replacement + body[end:]
    return body


def exact_replace(body: bytes, old: str, new: str) -> bytes:
    require(body.count(old.encode()) == 1, "Declared collector integration site is not unique")
    return body.replace(old.encode(), new.encode())


def validate_manifest(manifest: Json, expected_commit: str) -> None:
    require(set(manifest) == {"schema", "root", "label", "candidate", "bindings", "sources"},
            "Missing/extra deployment fields")
    require(manifest["schema"] == "issue161-master1-deployment-v1" and manifest["root"] == NEW_ROOT
            and manifest["label"] == LABEL, "Wrong deployment scope/root/label")
    require(isinstance(expected_commit, str) and COMMIT.fullmatch(expected_commit)
            and manifest["candidate"] == expected_commit, "Unbound or wrong actual merged commit")
    bound = manifest["bindings"]
    require(isinstance(bound, dict) and set(bound) == {"preceding_receipt_sha256", "tool_session_id", "wrapper_pid", "attachment"},
            "Missing/extra actual deployment bindings")
    require(isinstance(bound["preceding_receipt_sha256"], str) and HEX.fullmatch(bound["preceding_receipt_sha256"]),
            "Actual owned preceding receipt is unbound")
    for name in ("tool_session_id", "wrapper_pid"):
        require(type(bound[name]) is int and bound[name] > 0, f"Actual {name} is unbound")
    attachment = bound["attachment"]
    require(isinstance(attachment, dict) and set(attachment) == {"path", "sha256"}
            and isinstance(attachment["sha256"], str) and HEX.fullmatch(attachment["sha256"]),
            "Actual attachment reference is unbound")
    path = Path(attachment["path"])
    require(path == Path(NEW_ROOT) / SUPERVISION / "attachment.json", "Wrong actual attachment path")
    require(not path.parent.is_relative_to(Path(NEW_ROOT) / EXECUTION), "Attachment overlaps execution")
    require(isinstance(manifest["sources"], dict), "Require complete deployed source map")


def expected_bodies(original: dict[str, bytes], manifest: Json, bridge: bytes) -> dict[str, bytes]:
    """Pure allowlist: no writes, imports or qualification; synthetic controls use it."""
    bound = manifest["bindings"]
    result = {}
    launcher = constants(fixed_transform(original["run-full-c4-candidate5.py"]), {
        "RECIPE_SHA256": MASTER_RECIPE, "PREVIOUS_RECEIPT_SHA256": bound["preceding_receipt_sha256"],
    })
    result[f".issue-11-evidence/run-full-{LABEL}.py"] = launcher
    recipe = fixed_transform(original["c4-candidate5-recipe.json"])
    require(sha(recipe) == MASTER_RECIPE and len(decode(recipe)["steps"]) == 43, "Master recipe/workload differs")
    result[f"docs/assets/ligand-information/{LABEL}-recipe.json"] = recipe
    capture = constants(fixed_transform(original["capture-attachment.py"]), {
        "CANDIDATE": manifest["candidate"], "SESSION": bound["tool_session_id"], "WRAPPER_PID": bound["wrapper_pid"],
        "LABEL": LABEL, "LAUNCHER_SHA": sha(launcher), "RECIPE_SHA": MASTER_RECIPE,
    })
    result[f"{TOOLING}/capture-attachment.py"] = capture
    finalizer = constants(original["finalize-tool-supervision.py"], {
        "ATTACHMENT_SHA256": bound["attachment"]["sha256"], "CAPTURE_SOURCE_SHA256": sha(capture),
        "CAPTURE_SOURCE_PATH": f"{NEW_ROOT}/{TOOLING}/capture-attachment.py", "SESSION_ID": bound["tool_session_id"],
    })
    result[f"{TOOLING}/finalize-tool-supervision.py"] = finalizer
    authority = constants(original["strong_authority.py"], {"FINALIZER_SHA256": sha(finalizer)})
    authority += ADAPTER.format(bridge_sha=sha(bridge)).encode()
    result[f"{TOOLING}/strong_authority.py"] = authority
    collector = constants(original["postgate-retention.py"], {"AUTHORITY_SHA256": sha(authority)})
    for old, new in COLLECTOR_EDITS:
        collector = exact_replace(collector, old, new)
    result[f"{TOOLING}/postgate-retention.py"] = collector
    result[f"{TOOLING}/deployment_bridge.py"] = bridge
    for name in ("strong_process_scan.py", "strong_process_scan.original.py.txt",
                 "strong_process_scan.parent.py.txt", "scanner-provenance.json"):
        result[f"{TOOLING}/{name}"] = original[name]
        result[f"{SCANNER_STORAGE}/{name}"] = original[name]
    result[f"{TOOLING}/postgate-retention.original.py.txt"] = original["postgate-retention.original.py.txt"]
    result[f"{TOOLING}/unrelated-desktop-processes.json"] = original["unrelated-desktop-processes.json"]
    result[f"{LEGACY}/postgate-retention.py"] = original["postgate-retention.original.py.txt"]
    result[f"{LEGACY}/unrelated-desktop-processes.json"] = original["unrelated-desktop-processes.json"]
    return result


def check_source_map(manifest: Json, bodies: dict[str, bytes], expected: dict[str, bytes]) -> None:
    require(set(manifest["sources"]) == set(bodies) == set(expected), "Missing/extra deployed source roles")
    for name, wanted in expected.items():
        declared = manifest["sources"][name]
        require(isinstance(declared, dict) and set(declared) == {"bytes", "sha256"}
                and type(declared["bytes"]) is int and declared["bytes"] >= 0
                and isinstance(declared["sha256"], str) and HEX.fullmatch(declared["sha256"]),
                "Malformed source identity")
        require(bodies[name] == wanted, f"Undeclared body/method/contract delta: {name}")
        require(manifest["sources"][name] == identity(wanted), f"Stale source identity: {name}")


def check_deployment_directories(root: Path, expected: dict[str, bytes]) -> None:
    for directory in (TOOLING, SCANNER_STORAGE, LEGACY):
        wanted = {Path(name).name for name in expected if Path(name).parent == Path(directory)}
        if directory == TOOLING:
            wanted.add("deployment.json")
        entries = list(safe(root / directory).iterdir())
        require(all(entry.is_file() and not entry.is_symlink() for entry in entries)
                and {entry.name for entry in entries} == wanted, "Undeclared or aliased deployment directory entry")


def canonical_bytes(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()


def validate_identity(value: Any) -> None:
    require(isinstance(value, dict) and set(value) == {"bytes", "sha256"}
            and type(value["bytes"]) is int and value["bytes"] >= 0
            and isinstance(value["sha256"], str) and HEX.fullmatch(value["sha256"]), "Invalid certified body identity")


def binding_groups(historical: Json, deployment: Json) -> Json:
    require(isinstance(historical, dict) and historical and isinstance(deployment, dict) and deployment,
            "Require nonempty explicit historical/deployment binding groups")
    require(not (set(historical) & set(deployment)), "Duplicate or ambiguous binding group membership")
    for group in (historical, deployment):
        for original, expected in group.items():
            require(isinstance(original, str) and str(safe(original)) == original, "Noncanonical certified original path")
            validate_identity(expected)
    return {"historical_input_bindings": dict(historical), "deployment_input_bindings": dict(deployment),
            "input_bindings": {**historical, **deployment}}


def reconciled_groups(proof: Json) -> tuple[Json, Json]:
    require(isinstance(proof, dict) and {"historical_input_bindings", "deployment_input_bindings", "input_bindings"} <= set(proof),
            "Missing explicit preparation binding group")
    grouped = binding_groups(proof["historical_input_bindings"], proof["deployment_input_bindings"])
    require(isinstance(proof.get("input_bindings"), dict) and grouped["input_bindings"] == proof["input_bindings"],
            "Explicit binding groups do not reconcile exactly to combined authority")
    return grouped["historical_input_bindings"], grouped["deployment_input_bindings"]


def deployment_members(bindings: Json, root: Path) -> dict[str, str]:
    root = safe(root)
    result = {}
    for original in bindings:
        path = safe(original)
        require(path.is_relative_to(root), "Certified deployment original lies outside deployment root")
        member = "deployment-preparation/" + path.relative_to(root).as_posix()
        require(member not in {"inventory.json", "context.json"} and member not in result.values(),
                "Reserved or ambiguous deployment member")
        result[original] = member
    return result


def make_preparation_proof(historical: Json, added: Json, root: Path, candidate: str,
                           wanted: dict[str, bytes]) -> Json:
    groups = binding_groups(historical["input_bindings"], added)
    return {"scope": "Original actual C5 component certificate plus complete exact post-launch deployment; no gate/readiness/publication approval",
            "historical_component_controls": historical["controls"], "deployment_root": str(root),
            "deployment_label": LABEL, "candidate": candidate, "source_roles": sorted(wanted),
            "deployment_body_members": deployment_members(added, root),
            "collector_exceptions": ["preparation adapter and two CLI arguments", "complete deployment input selection",
                "unchanged generic deployment supplement", "full post-capture deployment revalidation",
                "explicit historical/deployment archive certification", "deployment result reference"],
            "limitations": ["Normal merged commit verification is external", "Actual owned environment qualification remains in unchanged full gate",
                            "New bridge/integration controls and independent assessment are separate prerequisites",
                            "Actual tool terminal/finalizer/closure/raw/science/reader/packet proofs remain independently required"],
            **groups}


def deployment_items(proof: Json, root: Path) -> tuple[dict[str, Path], Json]:
    _, bindings = reconciled_groups(proof)
    require(proof["deployment_root"] == str(safe(root)), "Deployment proof root differs")
    members = deployment_members(bindings, root)
    require(proof["deployment_body_members"] == members, "Declared deployment original/member mapping differs")
    items = {}
    for original, member in members.items():
        path = safe(original)
        require(identity(read(path)) == bindings[original], "Certified deployment original changed")
        require(member not in items, "Duplicate certified deployment member")
        items[member] = path
    context = {"schema": "issue161-certified-deployment-payloads-v1", "candidate": proof["candidate"],
               "root": str(root), "canonical_members": {original: {"member": member, "payload": dict(bindings[original])}
                   for original, member in members.items()},
               "scope": "Complete certified original deployment bodies; generated inventory/context are supplemental metadata"}
    return items, context


def verify_deployment_capture(proof: Json, root: Path, originals: dict[str, Path], context: Json) -> None:
    current_items, current_context = deployment_items(proof, root)
    require(current_items == originals and current_context == context,
            "Original deployment member map/context changed during capture")


def verify_locator(locator: Json, member: str, expected: Json, parts: Json) -> None:
    require(isinstance(locator, dict) and set(locator) == {"member", "payload", "part"}
            and locator["member"] == member and locator["payload"] == expected, "Certified packaged body/member differs")
    validate_identity(locator["payload"])
    part = locator["part"]
    require(isinstance(part, dict) and set(part) == {"asset_name", "bytes", "sha256"}
            and isinstance(part["asset_name"], str) and part["asset_name"]
            and part["asset_name"].endswith(".zip") and "\\" not in part["asset_name"]
            and Path(part["asset_name"]).name == part["asset_name"], "Invalid actual part locator")
    validate_identity({key: part[key] for key in ("bytes", "sha256")})
    require(0 < part["bytes"] < 80 * 1024 * 1024, "Actual certified part violates strict80MiB limit")
    pin = {key: part[key] for key in ("bytes", "sha256")}
    require(part["asset_name"] not in parts or parts[part["asset_name"]] == pin, "Conflicting part alias")
    parts[part["asset_name"]] = pin


def certify_preparations(proof: Json, root: Path, preparation: Path, assessments: Path,
                         state_locations: Json, deployment_locations: Json) -> Json:
    """Use only locators already verified by unchanged strong.member_locations."""
    historical, deployment = reconciled_groups(proof)
    originals, context = deployment_items(proof, root)
    members = deployment_members(deployment, root)
    inventory = {member: dict(deployment[original]) for original, member in members.items()}
    inventory_blob = canonical_bytes(dict(sorted(inventory.items())))
    generated_context = {**context, "body_files": len(inventory),
        "body_raw_bytes": sum(value["bytes"] for value in inventory.values()),
        "canonical_body_inventory_sha256": sha(inventory_blob)}
    metadata = {"inventory.json": identity(inventory_blob), "context.json": identity(canonical_bytes(generated_context))}
    require(set(deployment_locations) == set(originals) | set(metadata), "Unpackaged, omitted or extra deployment members")
    certified_historical, certified_deployment, parts = {}, {}, {}
    for original, expected in historical.items():
        path = safe(original)
        if path.is_relative_to(preparation):
            member = "launch-preparation/" + path.relative_to(preparation).as_posix()
        elif path.is_relative_to(assessments):
            member = "launch-preparation-assessments/" + path.relative_to(assessments).as_posix()
        else:
            raise ValueError("Historical certified body is outside explicit certificate groups")
        require(member in state_locations, "Historical certified body is not packaged")
        verify_locator(state_locations[member], member, expected, parts)
        require(member not in certified_historical, "Duplicate historical locator")
        certified_historical[member] = state_locations[member]
    for original, member in members.items():
        verify_locator(deployment_locations[member], member, deployment[original], parts)
        certified_deployment[original] = deployment_locations[member]
    for member, expected in metadata.items():
        verify_locator(deployment_locations[member], member, expected, parts)
    require(set(certified_deployment) == set(deployment), "Not every certified deployment original resolves")
    return {"launch_preparation": {"certified_inputs": certified_historical,
                "retained_tree_members": {name: locator for name, locator in state_locations.items()
                    if name.startswith(("launch-preparation/", "launch-preparation-assessments/"))},
                "scope": "Certified historical C5 component inputs only; other retained bodies preserve original status"},
            "deployment_preparation": {"schema": "issue161-packaged-deployment-authority-v1",
                "candidate": proof["candidate"], "root": str(root), "certified_inputs": certified_deployment,
                "canonical_member_mapping": members, "generated_metadata": {name: deployment_locations[name] for name in metadata},
                "actual_parts": parts, "all_certified_originals_resolve": True,
                "scope": "All certified deployment body/actual-part locators; no scientific/readiness/publication approval"}}


def immutable_certificate(preparation: Path, assessments: Path) -> tuple[Any, Json, dict[str, bytes]]:
    """Consume original C5 source/control evidence with its unchanged validator."""
    body = read(preparation / "strong_authority.py")
    require(sha(body) == BASE_CONSUMER, "Immutable original consumer differs")
    require(sha(read(preparation / "source-review.zip")) == BASE_CAPSULE, "Original reviewed capsule differs")
    for name, expected in BASE_ASSESSMENTS.items():
        require(sha(read(assessments / name)) == expected, "Immutable original assessment differs")
    specification = importlib.util.spec_from_file_location("issue161_immutable_c5_consumer", preparation / "strong_authority.py")
    require(specification is not None and specification.loader is not None, "Cannot load original C5 consumer")
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    proof = module.validate_launch_preparation(preparation, assessments, BASE_LAUNCHER, BASE_RECIPE)
    # That unchanged function checks exact True completion flags and independently
    # parses all retained canonical unittest outcomes. Exit0/count claims do not replace it.
    original = {name: read(preparation / name) for name in (
        "run-full-c4-candidate5.py", "c4-candidate5-recipe.json", "capture-attachment.py",
        "finalize-tool-supervision.py", "strong_authority.py", "postgate-retention.py",
        "strong_process_scan.py", "strong_process_scan.original.py.txt", "strong_process_scan.parent.py.txt",
        "scanner-provenance.json", "postgate-retention.original.py.txt", "unrelated-desktop-processes.json",
    )}
    return module, proof, original


def validate_deployment(path: str | Path, expected_sha256: str, *, preparation: Path, assessments: Path,
                        expected_launcher: str, expected_recipe: str, expected_merged_commit: str,
                        expected_bridge_sha256: str) -> Json:
    path, preparation, assessments = safe(path), safe(preparation), safe(assessments)
    require(preparation == Path(NEW_ROOT) / BASE_DIRECTORY and assessments == Path(NEW_ROOT) / ASSESSMENT_DIRECTORY,
            "Original copied certificate/assessment location differs")
    manifest_body = read(path)
    require(isinstance(expected_sha256, str) and HEX.fullmatch(expected_sha256)
            and sha(manifest_body) == expected_sha256, "Caller deployment pin differs")
    manifest = decode(manifest_body)
    validate_manifest(manifest, expected_merged_commit)
    require(path == Path(NEW_ROOT) / TOOLING / "deployment.json", "Wrong deployment manifest path")
    bridge_path = safe(Path(__file__).absolute())
    require(bridge_path == Path(NEW_ROOT) / TOOLING / "deployment_bridge.py", "Bridge is not in collected deployment tooling")
    bridge = read(bridge_path)
    require(HEX.fullmatch(expected_bridge_sha256) and sha(bridge) == expected_bridge_sha256,
            "Caller-pinned deployment bridge differs")
    base, historical, original = immutable_certificate(preparation, assessments)
    wanted = expected_bodies(original, manifest, bridge)
    bodies = {name: read(Path(NEW_ROOT) / name) for name in wanted}
    check_source_map(manifest, bodies, wanted)
    check_deployment_directories(Path(NEW_ROOT), wanted)
    launcher_rel = f".issue-11-evidence/run-full-{LABEL}.py"
    require(expected_launcher == sha(wanted[launcher_rel]) and expected_recipe == MASTER_RECIPE,
            "Actual collector launcher/recipe arguments differ")
    bound = manifest["bindings"]
    old_receipt_path = safe(Path(NEW_ROOT) / RECEIPT)
    old_receipt_body = read(old_receipt_path)
    old_receipt = decode(old_receipt_body)
    old_root = Path(NEW_ROOT) / ".issue-11-evidence/issue161-actual038-source1/source"
    require(sha(old_receipt_body) == bound["preceding_receipt_sha256"] and old_receipt.get("root") == str(old_root)
            and old_receipt.get("tag") == "v0.38.0"
            and old_receipt.get("commit") == "c6f3e283ef3f6bed4a00c6dfe3fef36bf5bc3f82", "Actual owned038 receipt differs")
    require(safe(old_root).is_dir() and safe(old_root / ".venv").is_dir(), "Owned038 source/environment directory missing or aliased")
    attachment_path = safe(bound["attachment"]["path"])
    attachment_body = read(attachment_path)
    require(sha(attachment_body) == bound["attachment"]["sha256"], "Actual attachment body differs")
    attachment = decode(attachment_body)
    launcher_path = str(Path(NEW_ROOT) / launcher_rel)
    require(attachment.get("schema") == "issue161-tool-supervisor-attachment-v1"
            and attachment.get("mode") == "late_observation" and attachment.get("scientific_qualification_passed") is False,
            "Wrong live attachment contract")
    for name, value in {"root": NEW_ROOT, "candidate": manifest["candidate"], "label": LABEL,
                        "execution_dir": f"{NEW_ROOT}/{EXECUTION}", "launcher": launcher_path,
                        "launcher_sha256": expected_launcher, "recipe_sha256": MASTER_RECIPE,
                        "tool_session_id": bound["tool_session_id"]}.items():
        require(attachment.get(name) == value and type(attachment.get(name)) is type(value), f"Stale actual attachment binding: {name}")
    require(attachment["wrapper_identity"]["pid"] == bound["wrapper_pid"]
            and type(attachment["wrapper_identity"]["pid"]) is int, "Actual wrapper PID differs")
    require(attachment.get("wrapper_argv") == [f"{NEW_ROOT}/.venv/bin/python", "-B", launcher_path,
            "--candidate", manifest["candidate"]], "Actual wrapper command differs")
    running_path = safe(Path(NEW_ROOT) / EXECUTION / "running.json")
    running_body = read(running_path)
    running = decode(running_body)
    require(running.get("candidate") == manifest["candidate"] and running.get("label") == LABEL
            and running.get("cwd") == NEW_ROOT and running.get("launcher_sha256") == expected_launcher
            and running.get("recipe_sha256") == MASTER_RECIPE
            and running.get("preceding_receipt_sha256") == bound["preceding_receipt_sha256"], "Actual running deployment differs")
    added = {str(path): identity(manifest_body), str(bridge_path): identity(bridge),
             str(old_receipt_path): identity(old_receipt_body), str(attachment_path): identity(attachment_body),
             str(running_path): identity(running_body),
             **{str(Path(NEW_ROOT) / name): identity(body) for name, body in bodies.items()}}
    merged = dict(historical["input_bindings"])
    for name, wanted_identity in added.items():
        require(name not in merged or merged[name] == wanted_identity, "Conflicting deployment/base binding")
        merged[name] = wanted_identity
    base.verify_bindings(merged)
    proof = make_preparation_proof(historical, added, Path(NEW_ROOT), manifest["candidate"], wanted)
    require(proof["input_bindings"] == merged, "Explicit preparation groups lost combined input authority")
    return proof


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("manifest", "expected-manifest-sha256", "expected-bridge-sha256", "expected-merged-commit",
                 "expected-launcher-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    result = validate_deployment(args.manifest, args.expected_manifest_sha256,
        preparation=Path(NEW_ROOT) / BASE_DIRECTORY, assessments=Path(NEW_ROOT) / ASSESSMENT_DIRECTORY,
        expected_launcher=args.expected_launcher_sha256, expected_recipe=MASTER_RECIPE,
        expected_merged_commit=args.expected_merged_commit, expected_bridge_sha256=args.expected_bridge_sha256)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
