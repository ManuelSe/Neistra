Preparation2 is SOURCE ONLY. All imports, compilation, controls, static checks,
actual fully bound consumption, deployment and packing remain NOT_RUN. Preparation1
and its CHANGES_REQUIRED assessment remain preserved unchanged.

## Corrected boundary

Independent source review found that the original collector certification loop
assumes every preparation binding is under the historical preparation or assessment
directory. Preparation1 returned a combined map containing deployment bodies outside
both directories. The old loop would reach its `relative_to(assessments)` fallback
after archive creation and raise. The authored regression now carries the actual
mixed proof shape through the exact old and replacement certification fragments.
No old RED or new GREEN execution is claimed before those controls run.

Preparation2 retains the complete combined `input_bindings` for before/after
verification and adds explicit `historical_input_bindings` and
`deployment_input_bindings`. Their disjoint union must equal the combined map
exactly. No binding is dropped to make the old loop fit. Canonical original paths
are identities: equal bodies at distinct paths remain separate inputs.

## Immutable contract and deployment scope

The byte-exact certified C5 consumer `5493ef99…` first validates the immutable
`c7ad98a8…` capsule and both actual assessment bodies with original launcher
`514d781b…` and recipe `41d142d8…` pins. Its exact True completion checks and
independent canonical outcome parser for the 67 historical controls are unchanged.
Historical C5 evidence is not relabelled as new deployment or campaign success.

The fixed new root is `/datadisk/dev/neistra-worktrees/issue-161-merged-qualification1`
and label is `c4-master1`. The recipe is exactly `4eed9acc…`, obtained through the
three previously recorded literal root/label/source2-to-source1 substitutions.
All 43 responsibilities, deadlines, exclusions, workload and limits remain fixed.
Actual merge, owned038 receipt, session, wrapper and live attachment are UNBOUND.
The template intentionally refuses. Numeric PID/session reuse alone is not a veto;
full actual candidate/path/identity/tool/time joins must distinguish observations.

This remains a post-launch source/preparation proof. It can run after the actual
live attachment while the new campaign is running, and again after closure. It
requires neither current `/proc` liveness nor terminal0. Existing independent outer
supervision, full-gate, source, closure/raw, science/readers/resource and retention
checks still govern campaign success and publication. The actual owned environment
must be independently qualified; no C5 environment sharing or alias is allowed.

## Exact permitted source changes

There are still exactly 19 operational source roles: launcher, canonical recipe,
five binding tools, two sets of four scanner/ancestry/provenance bodies, and two
sets of the immutable legacy collector plus exception proof. `expected_bodies`
defines every body. The three operational directories have exact membership.

Launcher/capture/finalizer permit only their listed fixed literals and named
actual-metadata module constants. All scanner generations, provenance, legacy
collector and exception-proof bodies remain byte-exact. If the actual new run
cannot use that exception proof, stop for bounded reassessment rather than silently
refreshing or broadening it.

All existing authority functions remain byte-exact. The only addition is the exact
pinned bridge loader and preparation adapter. The collector authority constant
changes, and `main` has these seven exact replacement sites in `COLLECTOR_EDITS`:

1. Call the deployment preparation adapter with the caller-pinned manifest.
2. Add the two required manifest/hash CLI arguments.
3. Select all certified deployment originals before output creation. Snapshot the
   original item map and deep-copy its JSON context before generic packing.
4. Call the unchanged generic `supplemental` function for `deployment-preparation`.
5. Re-run the full bridge after capture and compare the entire proof, groups and
   bindings. This rechecks exact operational directory membership. Recheck original
   deployment item/context snapshots and all combined authority bindings.
6. Replace the historical-only certification block with the complete grouped
   certification/locator helper described below.
7. Add the deployment supplement result reference to the existing result metadata.

Do not claim all collector function bodies are unchanged: `main` has these exact
changes. Every other collector function, including preflight, state/case traversal,
closure, raw copying, source proof, supplement, archive and union methods, stays
byte-exact. The source-render control compares all those function bodies directly.

## Complete packaging and locators

The bridge returns an explicit original-path-to-member mapping for every certified
new input. Members are `deployment-preparation/<path relative to new root>`;
basenames and content hashes never deduplicate distinct original paths. This covers
all 19 source roles plus manifest, actual owned038 receipt, attachment and running
record: 23 current certified deployment originals, including bodies outside the
binding directory. Historical certificate inputs retain their existing state-tree
members and are certified only through the explicit historical group.

The original generic supplement mutates its item/context arguments by adding
`inventory.json`, `context.json` and accounting fields. The collector therefore
retains a separate original item map and a deep JSON context snapshot. Those two
reserved generated members are explicitly separate metadata, not additional
scientific or source authority. The original-member map cannot overwrite them.

The new supplement uses the unchanged archive/splitting/strict80MiB/union/checksum
functions. Its complete member set is all certified originals plus exactly those
two generated metadata members. Existing `strong.member_locations` verifies actual
part bytes/SHA, literal checksum, CRC, manifest and complete member hashes before
the new certification helper consumes its locators. The helper verifies exact
original/member identities, all original and generated payload hashes, no missing
or extra locators and no conflicting part alias. The authority index contains:

- `launch_preparation`: certified historical inputs and retained historical tree
  members, with their original scope.
- `deployment_preparation`: every canonical original path, exact member/payload,
  actual asset basename/size/SHA locator, complete original-member mapping and the
  separately verified generated metadata locators.

Existing asset-plan ZIP discovery automatically registers every new supplement
part and its literal checksum. Actual publication and anonymous full-download
verification remain later requirements. No future part or completion hash is
embedded into sources or the manifest. Later collector tool completion is a
separate finite receipt, with no receipt-rebuild or repacking recursion.

## Authoring and future validation

All preparation1 assertions and 24 existing test functions remain. New cross-component
controls use explicit synthetic runtime data, the actual returned grouped-proof
constructor, the unchanged generic supplement function, exact old/new collector
certification fragments and the unchanged real member/part verifier. A small
fixture ZIP writer supplies ordinary test archive bytes; it is not a replacement
production packager or recursive scientific verification claim.

Controls cover the meaningful old fallback ValueError, complete corrected body/
part resolution, equal-body distinct paths, exact union of explicit binding groups,
missing/changed/unpackaged bodies, wrong actual part SHA, duplicate archive records,
conflicting/extra locators, aliases/reserved names, mutation-safe snapshots and
postcapture original drift. All are authored, NOT_RUN. No actual positive new
manifest, native result, source approval or deployment is claimed.

After the current quiet window ends, run:

```text
/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.venv/bin/python -B /datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-master-deployment-source-preparation2/test_deployment_bridge.py
```

Run appropriate focused static checks and independent source/control reassessment.
Actual fully bound consumption still uses the same bridge CLI and externally pinned
manifest/bridge/merged-commit/launcher hashes. The finite dependency graph remains
immutable certificate → bridge → actual attachment → finalizer → authority →
collector → caller-pinned manifest; archive/index and terminal receipts follow.

Normal tracked recipe/evidence checkpoint, complete 1,222-source and DATA equivalence,
all seven same-candidate final reviews, normal PR/merge, fresh exact-merged full43,
independent retention readback and verified immutable publication remain required.
Invocation/control/collector logs stay outside every captured tree. New control
source/results are separate explicit finite evidence assets; nothing automatically
makes them successful or published.
