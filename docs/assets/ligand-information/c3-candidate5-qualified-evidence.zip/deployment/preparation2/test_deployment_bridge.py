"""Prepared NOT_RUN controls; synthetic deployment data is never real authority.

Pure transformations use the immutable original source bodies but fake new-runtime
bindings. Historical-certificate controls use fresh temporary metadata copies only.
No application/service, process experiment, Git, SQL or qualification is launched.
"""

from __future__ import annotations

from copy import deepcopy
import ast
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import textwrap
import unittest
import zipfile

HERE = Path(__file__).parent.resolve()
SPEC = importlib.util.spec_from_file_location("deployment_bridge_control_subject", HERE / "deployment_bridge.py")
assert SPEC is not None and SPEC.loader is not None
bridge = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(bridge)
ORIGINAL = Path(bridge.OLD_ROOT) / bridge.BASE_DIRECTORY
ASSESSMENTS = Path(bridge.OLD_ROOT) / bridge.ASSESSMENT_DIRECTORY
CANDIDATE = "1" * 40


class SyntheticDeploymentControls(unittest.TestCase):
    def setUp(self) -> None:
        self.original = {name: (ORIGINAL / name).read_bytes() for name in (
            "run-full-c4-candidate5.py", "c4-candidate5-recipe.json", "capture-attachment.py",
            "finalize-tool-supervision.py", "strong_authority.py", "postgate-retention.py",
            "strong_process_scan.py", "strong_process_scan.original.py.txt", "strong_process_scan.parent.py.txt",
            "scanner-provenance.json", "postgate-retention.original.py.txt", "unrelated-desktop-processes.json",
        )}
        self.bridge_body = (HERE / "deployment_bridge.py").read_bytes()
        self.manifest = {
            "schema": "issue161-master1-deployment-v1", "root": bridge.NEW_ROOT, "label": bridge.LABEL,
            "candidate": CANDIDATE,
            "bindings": {"preceding_receipt_sha256": "2" * 64, "tool_session_id": 12345,
                         "wrapper_pid": 23456, "attachment": {
                             "path": f"{bridge.NEW_ROOT}/{bridge.SUPERVISION}/attachment.json", "sha256": "3" * 64}},
            "sources": {},
        }
        self.expected = bridge.expected_bodies(self.original, self.manifest, self.bridge_body)
        self.manifest["sources"] = {name: bridge.identity(body) for name, body in self.expected.items()}

    def test_positive_is_only_synthetic_exact_declared_transformation(self) -> None:
        bridge.validate_manifest(self.manifest, CANDIDATE)
        bridge.check_source_map(self.manifest, dict(self.expected), self.expected)
        self.assertEqual(bridge.sha(self.expected[f"docs/assets/ligand-information/{bridge.LABEL}-recipe.json"]),
                         bridge.MASTER_RECIPE)
        self.assertEqual(len(bridge.decode(self.expected[f"docs/assets/ligand-information/{bridge.LABEL}-recipe.json"])["steps"]), 43)
        self.assertNotIn("pass", self.manifest)
        self.assertNotIn("ready", self.manifest)

    def test_numeric_reuse_alone_is_not_blacklisted(self) -> None:
        self.manifest["bindings"]["tool_session_id"] = 72411
        self.manifest["bindings"]["wrapper_pid"] = 1358462
        bridge.validate_manifest(self.manifest, CANDIDATE)
        # Still explicitly synthetic: full new path/candidate/observations and
        # actual external tool provenance are mandatory in a real deployment.

    def test_unbound_actual_bindings_refuse(self) -> None:
        for name, value in [("preceding_receipt_sha256", "UNBOUND"), ("tool_session_id", "UNBOUND"),
                            ("wrapper_pid", "UNBOUND"), ("tool_session_id", True), ("wrapper_pid", 0)]:
            with self.subTest(binding=name, value=value):
                candidate = deepcopy(self.manifest)
                candidate["bindings"][name] = value
                with self.assertRaises(ValueError):
                    bridge.validate_manifest(candidate, CANDIDATE)

    def test_unbound_or_wrong_expected_actual_commit_refuses(self) -> None:
        for expected in ["UNBOUND", "f" * 40]:
            with self.subTest(expected=expected), self.assertRaises(ValueError):
                bridge.validate_manifest(self.manifest, expected)

    def test_stale_c5_root_label_or_attachment_refuse_coherently(self) -> None:
        for field, value in [("root", bridge.OLD_ROOT), ("label", bridge.OLD_LABEL)]:
            with self.subTest(field=field):
                candidate = {**self.manifest, field: value}
                with self.assertRaises(ValueError):
                    bridge.validate_manifest(candidate, CANDIDATE)
        candidate = deepcopy(self.manifest)
        candidate["bindings"]["attachment"]["path"] = f"{bridge.OLD_ROOT}/.issue-11-evidence/issue161-c4-candidate5-outer-supervisor1/attachment.json"
        with self.assertRaises(ValueError):
            bridge.validate_manifest(candidate, CANDIDATE)

    def test_omitted_or_extra_contract_fields_refuse(self) -> None:
        for field in self.manifest:
            candidate = deepcopy(self.manifest)
            del candidate[field]
            with self.subTest(missing=field), self.assertRaises(ValueError):
                bridge.validate_manifest(candidate, CANDIDATE)
        with self.assertRaises(ValueError):
            bridge.validate_manifest({**self.manifest, "extra": True}, CANDIDATE)

    def test_extra_binding_and_missing_attachment_hash_refuse(self) -> None:
        candidate = deepcopy(self.manifest)
        candidate["bindings"]["extra"] = True
        with self.assertRaises(ValueError):
            bridge.validate_manifest(candidate, CANDIDATE)
        candidate = deepcopy(self.manifest)
        del candidate["bindings"]["attachment"]["sha256"]
        with self.assertRaises(ValueError):
            bridge.validate_manifest(candidate, CANDIDATE)

    def test_added_removed_or_extra_source_identity_fields_refuse(self) -> None:
        name = next(iter(self.expected))
        for mode in ["extra", "missing", "extra-identity"]:
            with self.subTest(mode=mode):
                candidate = deepcopy(self.manifest)
                if mode == "extra":
                    candidate["sources"]["undeclared-source.py"] = bridge.identity(b"x")
                elif mode == "missing":
                    del candidate["sources"][name]
                else:
                    candidate["sources"][name]["extra"] = True
                with self.assertRaises(ValueError):
                    bridge.check_source_map(candidate, self.expected, self.expected)

    def test_even_rehashed_new_logic_is_undeclared(self) -> None:
        for suffix in ["run-full-c4-master1.py", "strong_process_scan.py", "strong_authority.py", "postgate-retention.py"]:
            name = next(name for name in self.expected if name.endswith(suffix))
            bodies = {**self.expected, name: self.expected[name] + b"\nraise RuntimeError('synthetic new logic')\n"}
            candidate = deepcopy(self.manifest)
            candidate["sources"][name] = bridge.identity(bodies[name])
            with self.subTest(source=name), self.assertRaises(ValueError):
                bridge.check_source_map(candidate, bodies, self.expected)

    def test_stale_declared_source_hash_refuses(self) -> None:
        candidate = deepcopy(self.manifest)
        candidate["sources"][next(iter(self.expected))]["sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            bridge.check_source_map(candidate, self.expected, self.expected)

    def test_changed_recipe_bounds_deadline_or_workload_refuse(self) -> None:
        name = f"docs/assets/ligand-information/{bridge.LABEL}-recipe.json"
        for replacement in [b'"steps": []', b'"changed_workload": true', b'"timeout_seconds": 1']:
            changed = self.expected[name] + b"\n" + replacement
            candidate = deepcopy(self.manifest)
            candidate["sources"][name] = bridge.identity(changed)
            with self.subTest(change=replacement), self.assertRaises(ValueError):
                bridge.check_source_map(candidate, {**self.expected, name: changed}, self.expected)

    def test_fixed_recipe_transform_is_reversible_and_all_other_bytes_stay(self) -> None:
        original = self.original["c4-candidate5-recipe.json"]
        transformed = bridge.fixed_transform(original)
        for old, new in reversed(bridge.TRANSFORMS):
            transformed = transformed.replace(new.encode(), old.encode())
        self.assertEqual(transformed, original)

    def test_constants_only_changes_the_named_module_value(self) -> None:
        source = b"TOKEN = 'old'\n\ndef method():\n    return 'old'\n"
        self.assertEqual(bridge.constants(source, {"TOKEN": "new"}),
                         b"TOKEN = 'new'\n\ndef method():\n    return 'old'\n")

    def test_missing_or_duplicate_constant_assignment_refuses(self) -> None:
        for body in [b"OTHER = 1\n", b"TOKEN = 1\nTOKEN = 2\n"]:
            with self.subTest(body=body), self.assertRaises(ValueError):
                bridge.constants(body, {"TOKEN": 3})

    def test_collector_adapter_exceptions_are_unique_and_exact(self) -> None:
        original = self.original["postgate-retention.py"]
        self.assertEqual(original.count(bridge.OLD_CALL.encode()), 1)
        self.assertEqual(original.count(bridge.OLD_ARGUMENT.encode()), 1)
        for body in [b"", original + original]:
            with self.subTest(size=len(body)), self.assertRaises(ValueError):
                bridge.exact_replace(body, bridge.OLD_CALL, bridge.NEW_CALL)

    def test_duplicate_json_metadata_refuses(self) -> None:
        with self.assertRaises(ValueError):
            bridge.decode(b'{"schema":"one","schema":"two"}')


class TemporaryHistoricalCertificateControls(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory(prefix="neistra161-bridge-historical-control-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.preparation = self.root / "preparation"
        self.assessments = self.root / "assessments"
        self.preparation.mkdir()
        self.assessments.mkdir()
        capsule = (ORIGINAL / "source-review.zip").read_bytes()
        self.assertEqual(bridge.sha(capsule), bridge.BASE_CAPSULE)
        (self.preparation / "source-review.zip").write_bytes(capsule)
        with zipfile.ZipFile(ORIGINAL / "source-review.zip") as archive:
            for name in archive.namelist():
                relative = Path(name)
                self.assertFalse(relative.is_absolute() or ".." in relative.parts)
                destination = self.preparation / relative
                if name.endswith("/"):
                    destination.mkdir(parents=True, exist_ok=True)
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(archive.read(name))
        for name in bridge.BASE_ASSESSMENTS:
            (self.assessments / name).write_bytes((ASSESSMENTS / name).read_bytes())

    def test_original_actual_component_certificate_is_consumed_unchanged(self) -> None:
        module, proof, originals = bridge.immutable_certificate(self.preparation, self.assessments)
        self.assertEqual(sum(proof["controls"]["current_cases"].values()), 67)
        self.assertEqual(bridge.sha(originals["strong_authority.py"]), bridge.BASE_CONSUMER)
        self.assertEqual(module.validate_launch_preparation.__name__, "validate_launch_preparation")
        # This consumes historical actual controls only, not a new deployment.

    def test_wrong_original_consumer_capsule_or_assessment_refuses(self) -> None:
        for path in [self.preparation / "strong_authority.py", self.preparation / "source-review.zip",
                     self.assessments / "architecture-source-assessment.json"]:
            with self.subTest(path=path.name):
                original = path.read_bytes()
                path.write_bytes(original + b"\n")
                with self.assertRaises(ValueError):
                    bridge.immutable_certificate(self.preparation, self.assessments)
                path.write_bytes(original)

    def test_wrong_retained_completion_or_log_body_refuses(self) -> None:
        receipt_path = self.preparation / "source-controls1/receipt.json"
        original = receipt_path.read_bytes()
        receipt = json.loads(original)
        receipt["complete"] = False
        receipt_path.write_text(json.dumps(receipt))
        with self.assertRaises(ValueError):
            bridge.immutable_certificate(self.preparation, self.assessments)
        receipt_path.write_bytes(original)
        log = self.preparation / "source-controls1/test_candidate5.py.stderr.log"
        log.write_bytes(b"Ran 11 tests in 0.001s\nFAILED (failures=1)\n")
        with self.assertRaises(ValueError):
            bridge.immutable_certificate(self.preparation, self.assessments)

    def test_reused_existing_parser_rejects_incomplete_or_contradictory_outcomes(self) -> None:
        module, _, _ = bridge.immutable_certificate(self.preparation, self.assessments)
        module.validate_unittest_stderr("Ran 11 tests in 0.001s\n\nOK\n", 11)
        for text in ["Ran 11 tests in 0.001s\n", "Ran 11 tests in 0.001s\nOK\nFAILED\n",
                     "Ran 10 tests in 0.001s\nOK\n", "Ran 11 tests in 0.001s\nOK (skipped=1)\n"]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                module.validate_unittest_stderr(text, 11)

    def test_unsafe_symlink_and_hardlinked_metadata_refuse(self) -> None:
        target = self.root / "real.json"
        target.write_bytes(b"{}")
        alias = self.root / "alias.json"
        alias.symlink_to(target)
        with self.assertRaises(ValueError):
            bridge.read(alias)
        os.link(target, self.root / "hardlink.json")
        with self.assertRaises(ValueError):
            bridge.read(target)


class TemporaryDeploymentDirectoryControls(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory(prefix="neistra161-bridge-directory-control-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.expected = {}
        for directory in (bridge.TOOLING, bridge.SCANNER_STORAGE, bridge.LEGACY):
            target = self.root / directory
            target.mkdir(parents=True)
            relative = f"{directory}/synthetic.py"
            self.expected[relative] = b"# synthetic directory membership only\n"
            (self.root / relative).write_bytes(self.expected[relative])
        (self.root / bridge.TOOLING / "deployment.json").write_bytes(b"{}")

    def test_exact_synthetic_directory_membership_passes_only_that_check(self) -> None:
        bridge.check_deployment_directories(self.root, self.expected)

    def test_undeclared_module_is_not_hidden_by_omitting_it_from_source_map(self) -> None:
        (self.root / bridge.TOOLING / "undeclared.py").write_bytes(b"# synthetic extra source\n")
        with self.assertRaises(ValueError):
            bridge.check_deployment_directories(self.root, self.expected)

    def test_unlisted_directory_or_alias_refuses(self) -> None:
        extra = self.root / bridge.TOOLING / "unlisted"
        extra.mkdir()
        with self.assertRaises(ValueError):
            bridge.check_deployment_directories(self.root, self.expected)
        extra.rmdir()
        extra.symlink_to(self.root / bridge.LEGACY / "synthetic.py")
        with self.assertRaises(ValueError):
            bridge.check_deployment_directories(self.root, self.expected)


class CrossComponentPackagingControls(unittest.TestCase):
    """Execute exact old/new certification fragments over real fixture ZIP bodies."""

    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory(prefix="neistra161-bridge-cross-component-")
        self.addCleanup(temporary.cleanup)
        self.fixture = Path(temporary.name).resolve()
        self.root = self.fixture / "synthetic-root"
        self.root.mkdir()
        self.output = self.fixture / "parts"
        self.output.mkdir()
        original = {name: (ORIGINAL / name).read_bytes() for name in (
            "run-full-c4-candidate5.py", "c4-candidate5-recipe.json", "capture-attachment.py",
            "finalize-tool-supervision.py", "strong_authority.py", "postgate-retention.py",
            "strong_process_scan.py", "strong_process_scan.original.py.txt", "strong_process_scan.parent.py.txt",
            "scanner-provenance.json", "postgate-retention.original.py.txt", "unrelated-desktop-processes.json",
        )}
        synthetic = {"candidate": CANDIDATE, "bindings": {"preceding_receipt_sha256": "2" * 64,
            "tool_session_id": 12345, "wrapper_pid": 23456, "attachment": {"sha256": "3" * 64}}}
        self.wanted = bridge.expected_bodies(original, synthetic, (HERE / "deployment_bridge.py").read_bytes())
        added = {}
        for name, body in self.wanted.items():
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(body)
            added[str(path)] = bridge.identity(body)
        for name in [f"{bridge.TOOLING}/deployment.json", bridge.RECEIPT,
                     f"{bridge.SUPERVISION}/attachment.json", f"{bridge.EXECUTION}/running.json"]:
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            body = bridge.canonical_bytes({"explicitly_synthetic_fixture": name})
            path.write_bytes(body)
            added[str(path)] = bridge.identity(body)
        self.preparation = self.root / bridge.BASE_DIRECTORY
        self.assessments = self.root / bridge.ASSESSMENT_DIRECTORY
        historical = {}
        for path in [self.preparation / "preparation.json", self.assessments / "architecture-source-assessment.json"]:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b'{"explicitly_synthetic_historical_group":true}\n')
            historical[str(path)] = bridge.identity(path.read_bytes())
        self.proof = bridge.make_preparation_proof({"input_bindings": historical, "controls": {"synthetic": True}},
            added, self.root, CANDIDATE, self.wanted)
        self.strong = self.load_component("strong_authority.py", "cross_component_original_authority", bridge.BASE_CONSUMER)
        self.collector_body = original["postgate-retention.py"]
        self.collector = self.load_component("postgate-retention.py", "cross_component_original_collector",
                                            "82f47c5257e1250459bdc2e2f3ae1950935997bddf7c07ca674f2e49333e8a87")
        self.package = {"__file__": str(HERE / "deployment_bridge.py"), "fingerprint": self.fingerprint,
            "encoded": bridge.canonical_bytes, "compressed_size": lambda member: len(self.bytes_of(member)),
            "add": self.add, "archive": self.archive, "verify_package_receipt": self.verify_receipt,
            "verify_layers": lambda _body, _name: {}, "_verify_wrapped_layers": lambda _body, _name, _package: {}}
        state_items = {}
        for original_path in historical:
            path = Path(original_path)
            member = ("launch-preparation/" + path.relative_to(self.preparation).as_posix()) if path.is_relative_to(self.preparation) else (
                "launch-preparation-assessments/" + path.relative_to(self.assessments).as_posix())
            state_items[member] = path
        state_part = self.archive(state_items, self.output / "synthetic-historical.zip")
        self.write_sidecar(state_part)
        self.state_locations = self.strong.member_locations({"archives": [state_part]},
            {name: self.fingerprint(member) for name, member in state_items.items()})
        self.items, self.context = bridge.deployment_items(self.proof, self.root)
        self.original_items = dict(self.items)
        self.original_context = json.loads(json.dumps(self.context, sort_keys=True))
        # The ORIGINAL generic function runs, including its actual mutation of
        # items/context, union verification, checksum writing and result contract.
        self.deployment_result = self.collector.supplemental(self.package, self.output, "synthetic-master",
            "deployment-preparation", self.items, self.context)

    def load_component(self, name: str, module_name: str, expected: str):
        path = ORIGINAL / name
        self.assertEqual(bridge.sha(path.read_bytes()), expected)
        spec = importlib.util.spec_from_file_location(module_name, path)
        assert spec is not None and spec.loader is not None
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    @staticmethod
    def bytes_of(member) -> bytes:
        return member if isinstance(member, bytes) else member.read_bytes()

    def fingerprint(self, member) -> dict:
        return bridge.identity(self.bytes_of(member))

    @staticmethod
    def add(items: dict, name: str, member, **_options) -> None:
        if name in items:
            raise ValueError("Explicit fixture duplicate member")
        items[name] = member

    def archive(self, items: dict, path: Path) -> dict:
        manifest = {name: self.fingerprint(member) for name, member in items.items()}
        self.assertNotIn("manifest.json", manifest)
        with zipfile.ZipFile(path, "x", zipfile.ZIP_DEFLATED) as archive:
            for name, member in items.items():
                archive.writestr(name, self.bytes_of(member))
            archive.writestr("manifest.json", bridge.canonical_bytes(manifest))
        return {"path": str(path), **self.fingerprint(path)}

    @staticmethod
    def write_sidecar(part: dict) -> None:
        path = Path(part["path"])
        path.with_name(path.name + ".sha256").write_text(f"{part['sha256']}  {path.name}\n")

    def verify_receipt(self, path: Path) -> dict:
        receipt = json.loads(path.read_bytes())
        expected = {}
        for part in receipt["archives"]:
            with zipfile.ZipFile(part["path"]) as archive:
                for name, value in json.loads(archive.read("manifest.json")).items():
                    self.assertNotIn(name, expected)
                    expected[name] = value
        self.strong.member_locations(receipt, expected)
        return receipt

    def fragment_context(self) -> dict:
        return {"Path": Path, "require": bridge.require, "preparation_proof": self.proof,
            "preparation": self.preparation, "assessments": self.assessments,
            "state_locations": self.state_locations, "authority_index": {}, "strong": self.strong,
            "load": lambda path: json.loads(path.read_bytes()), "deployment_result": self.deployment_result,
            "deployment_items": self.items, "package": self.package, "deployment_bridge": bridge, "root": self.root}

    def locations(self) -> dict:
        return self.strong.member_locations(json.loads(Path(self.deployment_result["receipt"]).read_bytes()),
            {name: self.fingerprint(member) for name, member in self.items.items()})

    def test_actual_old_fragment_refuses_mixed_shape_and_corrected_fragment_resolves_every_body(self) -> None:
        self.assertEqual(self.collector_body.count(bridge.OLD_CERTIFICATION.encode()), 1)
        old = self.fragment_context()
        with self.assertRaises(ValueError):
            exec(textwrap.dedent(bridge.OLD_CERTIFICATION), old)
        corrected = self.fragment_context()
        exec(textwrap.dedent(bridge.NEW_CERTIFICATION), corrected)
        index = corrected["authority_index"]["deployment_preparation"]
        self.assertEqual(set(index["certified_inputs"]), set(self.proof["deployment_input_bindings"]))
        self.assertEqual(len(index["certified_inputs"]), 23)
        self.assertEqual(len(self.proof["source_roles"]), 19)
        for original, locator in index["certified_inputs"].items():
            part = self.output / "deployment-preparation" / locator["part"]["asset_name"]
            self.assertEqual(self.fingerprint(part), {key: locator["part"][key] for key in ("bytes", "sha256")})
            with zipfile.ZipFile(part) as archive:
                self.assertEqual(archive.read(locator["member"]), Path(original).read_bytes())
        self.assertEqual(set(index["generated_metadata"]), {"inventory.json", "context.json"})

    def test_generic_mutations_do_not_alias_original_snapshot(self) -> None:
        self.assertEqual(set(self.items) - set(self.original_items), {"inventory.json", "context.json"})
        self.assertNotIn("body_files", self.original_context)
        bridge.verify_deployment_capture(self.proof, self.root, self.original_items, self.original_context)
        original = next(iter(self.context["canonical_members"]))
        self.context["canonical_members"][original]["payload"]["sha256"] = "0" * 64
        self.assertNotEqual(self.context["canonical_members"], self.original_context["canonical_members"])
        bridge.verify_deployment_capture(self.proof, self.root, self.original_items, self.original_context)

    def test_missing_mismatched_extra_or_conflicting_locators_refuse(self) -> None:
        baseline = self.locations()
        member = next(name for name in baseline if name.startswith("deployment-preparation/"))
        for mode in ["missing", "payload", "extra", "part"]:
            locations = deepcopy(baseline)
            if mode == "missing":
                del locations[member]
            elif mode == "payload":
                locations[member]["payload"]["sha256"] = "0" * 64
            elif mode == "extra":
                locations["unpackaged-member"] = locations[member]
            else:
                locations[member]["part"]["sha256"] = "0" * 64
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                bridge.certify_preparations(self.proof, self.root, self.preparation, self.assessments,
                    self.state_locations, locations)

    def test_unpacked_or_mismatched_archive_body_refuses_actual_fragment(self) -> None:
        member = next(name for name in self.items if name.startswith("deployment-preparation/"))
        for mode in ["missing", "changed"]:
            items = dict(self.items)
            if mode == "missing":
                del items[member]
            else:
                items[member] = b"Explicitly synthetic mismatched payload\n"
            part = self.archive(items, self.output / f"synthetic-{mode}.zip")
            self.write_sidecar(part)
            receipt_path = self.output / f"synthetic-{mode}-receipt.json"
            receipt_path.write_bytes(bridge.canonical_bytes({"archives": [part]}))
            context = self.fragment_context()
            context["deployment_result"] = {"receipt": str(receipt_path)}
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                exec(textwrap.dedent(bridge.NEW_CERTIFICATION), context)

    def test_wrong_actual_part_sha_refuses_before_index_certification(self) -> None:
        receipt = json.loads(Path(self.deployment_result["receipt"]).read_bytes())
        receipt["archives"][0]["sha256"] = "0" * 64
        path = self.output / "synthetic-wrong-part-receipt.json"
        path.write_bytes(bridge.canonical_bytes(receipt))
        context = self.fragment_context()
        context["deployment_result"] = {"receipt": str(path)}
        with self.assertRaises(ValueError):
            exec(textwrap.dedent(bridge.NEW_CERTIFICATION), context)

    def test_duplicate_archive_receipt_refuses_ambiguous_packaged_members(self) -> None:
        receipt = json.loads(Path(self.deployment_result["receipt"]).read_bytes())
        receipt["archives"].append(deepcopy(receipt["archives"][0]))
        path = self.output / "synthetic-duplicate-part-receipt.json"
        path.write_bytes(bridge.canonical_bytes(receipt))
        context = self.fragment_context()
        context["deployment_result"] = {"receipt": str(path)}
        with self.assertRaises(ValueError):
            exec(textwrap.dedent(bridge.NEW_CERTIFICATION), context)

    def test_equal_bytes_at_distinct_scanner_paths_keep_distinct_members(self) -> None:
        paths = [name for name in self.proof["deployment_input_bindings"] if name.endswith("/strong_process_scan.py")]
        self.assertEqual(len(paths), 2)
        self.assertEqual(Path(paths[0]).read_bytes(), Path(paths[1]).read_bytes())
        self.assertNotEqual(self.proof["deployment_body_members"][paths[0]], self.proof["deployment_body_members"][paths[1]])
        context = self.fragment_context()
        exec(textwrap.dedent(bridge.NEW_CERTIFICATION), context)
        certified = context["authority_index"]["deployment_preparation"]["certified_inputs"]
        self.assertTrue(all(path in certified for path in paths))

    def test_combined_map_cannot_drop_add_or_ambiguously_regroup_inputs(self) -> None:
        for mode in ["missing", "extra", "ambiguous"]:
            proof = deepcopy(self.proof)
            if mode == "missing":
                del proof["input_bindings"][next(iter(proof["deployment_input_bindings"]))]
            elif mode == "extra":
                proof["input_bindings"][str(self.root / "unexplained.json")] = bridge.identity(b"{}")
            else:
                original = next(iter(proof["historical_input_bindings"]))
                proof["deployment_input_bindings"][original] = proof["historical_input_bindings"][original]
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                bridge.deployment_items(proof, self.root)

    def test_omitting_either_explicit_group_refuses(self) -> None:
        for name in ["historical_input_bindings", "deployment_input_bindings", "input_bindings"]:
            proof = deepcopy(self.proof)
            del proof[name]
            with self.subTest(group=name), self.assertRaises(ValueError):
                bridge.reconciled_groups(proof)

    def test_reserved_or_aliased_original_member_mapping_refuses(self) -> None:
        original = next(iter(self.proof["deployment_body_members"]))
        for value in ["inventory.json", "context.json", "deployment-preparation/../alias"]:
            proof = deepcopy(self.proof)
            proof["deployment_body_members"][original] = value
            with self.subTest(member=value), self.assertRaises(ValueError):
                bridge.deployment_items(proof, self.root)
        aliased = str(Path(original).parent) + "/./" + Path(original).name
        with self.assertRaises(ValueError):
            bridge.binding_groups(self.proof["historical_input_bindings"], {aliased: self.proof["deployment_input_bindings"][original]})

    def test_postcapture_original_change_and_bad_snapshot_refuse(self) -> None:
        with self.assertRaises(ValueError):
            bridge.verify_deployment_capture(self.proof, self.root, {}, self.original_context)
        path = next(iter(self.original_items.values()))
        path.write_bytes(path.read_bytes() + b"\nExplicit synthetic input change\n")
        with self.assertRaises(ValueError):
            bridge.verify_deployment_capture(self.proof, self.root, self.original_items, self.original_context)

    def test_collector_render_has_full_revalidation_and_preserves_other_functions(self) -> None:
        for old, _new in bridge.COLLECTOR_EDITS:
            self.assertEqual(self.collector_body.count(old.encode()), 1)
        model = {"candidate": CANDIDATE, "bindings": {"preceding_receipt_sha256": "2" * 64,
            "tool_session_id": 12345, "wrapper_pid": 23456, "attachment": {"sha256": "3" * 64}}}
        original = {name: (ORIGINAL / name).read_bytes() for name in (
            "run-full-c4-candidate5.py", "c4-candidate5-recipe.json", "capture-attachment.py",
            "finalize-tool-supervision.py", "strong_authority.py", "postgate-retention.py",
            "strong_process_scan.py", "strong_process_scan.original.py.txt", "strong_process_scan.parent.py.txt",
            "scanner-provenance.json", "postgate-retention.original.py.txt", "unrelated-desktop-processes.json")}
        rendered = bridge.expected_bodies(original, model, (HERE / "deployment_bridge.py").read_bytes())[
            f"{bridge.TOOLING}/postgate-retention.py"]
        self.assertIn(bridge.NEW_RECHECK.encode(), rendered)
        self.assertIn(bridge.NEW_CERTIFICATION.encode(), rendered)
        old_text, new_text = self.collector_body.decode(), rendered.decode()
        old_functions = {node.name: ast.get_source_segment(old_text, node) for node in ast.parse(old_text).body if isinstance(node, ast.FunctionDef)}
        new_functions = {node.name: ast.get_source_segment(new_text, node) for node in ast.parse(new_text).body if isinstance(node, ast.FunctionDef)}
        self.assertEqual(set(old_functions), set(new_functions))
        self.assertEqual({key: value for key, value in old_functions.items() if key != "main"},
                         {key: value for key, value in new_functions.items() if key != "main"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
