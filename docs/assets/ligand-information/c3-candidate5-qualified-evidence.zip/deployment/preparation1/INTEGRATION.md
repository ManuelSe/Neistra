Source preparation only. No import, compile, control, static check, deployment,
new environment, runtime binding or master qualification has run through this work.
The current candidate's source and evidence remain frozen.

## Scope and immutable input

The bridge consumes original C5 component evidence using the byte-exact certified
`strong_authority.py` template (`5493ef99…`). It pins the original `c7ad98a8…`
source/control capsule and both actual source/relocation assessment bodies, then
calls its unchanged `validate_launch_preparation` with original `514d781b…`
launcher and `41d142d8…` recipe identities. The existing parser independently
requires exact True receipt/result completion and canonical successful unittest
outcomes for all 67 actual historical controls. Neither exit0 nor counts alone
replace those checks. The copied certificate remains C5 evidence with its original
scope; it is never relabelled as a new deployment or successful master campaign.

This is a post-launch source/binding bridge only. Prelaunch source/control review,
normal merge verification, full selected-source/DATA equivalence, the fresh owned
reader environment, full 43-command campaign, real terminal tool return, closure,
raw copies, scientific/readers/resource results and independent retention readback
remain separate requirements. No scientific or closure algorithm is added here.

## Exact permitted source changes

`expected_bodies` defines the entire allowlist; a caller cannot supply replacement
rules. Its resulting source map currently has 19 explicit path roles:

- The launcher and canonical master recipe.
- Five binding tools: capture, finalizer, authority, collector and this bridge.
- Four byte-exact scanner/ancestry/provenance files in each of the launcher scanner
  storage and binding-tool directories.
- The immutable original collector and exception-proof JSON in each of the legacy
  supplier and binding-tool directories.

The recipe permits only the three recorded fixed literal changes: old owned root
to the planned new root, `c4-candidate5` to `c4-master1`, and preceding source2 to
source1. The complete result must have SHA256 `4eed9acc…` and 43 ordered steps.
Its deadlines, exclusions, responsibilities, limits and workload bytes cannot vary.

The launcher permits those same fixed literal changes and only the recipe and
actual preceding-receipt module constants. Capture permits the fixed literal
changes and its explicitly listed actual candidate/session/PID/launcher/recipe
constants. Finalizer permits exactly its four actual attachment/source/path/session
constants. AST extents replace existing module-level assignment values only;
all other bytes are preserved.

The authority permits only its finalizer constant plus the exact appended adapter
in `ADAPTER`. Every existing authority function, including the original C5
preparation validator and outcome parser, stays byte-exact. The collector permits
only its authority constant and **two declared changes to `main`**: its one
preparation call becomes the new adapter call, and two required manifest/hash CLI
arguments are added. Do not claim every collector function body is unchanged:
`main` has those precise changes. `preflight`, closure, copying, source validation
and packaging methods remain byte-exact.

All scanner generations, provenance, the immutable original collector and the
existing exception-proof JSON remain byte-exact. If that exact exception proof
cannot support the actual new run, stop for a bounded reassessment; this bridge
does not silently accept a refreshed or broader exception policy.

The binding, scanner-storage and legacy directories have exact membership. Put
all invocation/collector stdout/stderr, assessments and source-control outputs in
separate owned directories. No extra modules, directories, caches or aliases are
accepted in operational tooling. This prevents an omitted source-map row from
hiding additional code. The manifest itself is the only additional binding-tool
file and must be named `deployment.json`.

## Finite binding and deployment sequence

1. After actual successful C5 terminal/custody/readbacks, persist the normal tracked
   canonical master recipe and evidence checkpoint. Preserve the C5 qualifying
   subject. Verify all 1,222 selected bodies, helpers/configuration/fixtures and
   qualification DATA remain equivalent. All seven final assessments cover the
   same later review candidate and its metadata delta.
2. Use the normal PR/review/merge route. Verify the actual resulting commit, then
   create the isolated exact-merge root. Extract and qualify a genuinely owned
   preceding source1 environment; never share or symlink the C5 environment.
3. Copy the immutable C5 preparation and assessment trees byte-exact into their
   unchanged named evidence locations in the new root. Stage only the explicit
   static source roles. Derive the launcher with the actual fresh receipt hash.
   Do not manufacture placeholder hashes, PIDs, sessions or candidate identities.
4. Launch the reviewed source-bound master campaign. Preserve its real tool return,
   then derive the capture source with the actual new session/PID and observed
   candidate. Capture the live attachment while the same real tool session runs.
5. Derive finalizer from that actual attachment; derive authority from finalizer
   and bridge hashes; derive collector from authority. The module-constant changes
   and appended adapter/callsite require their independent bound-source review.
6. Only now construct the complete `deployment.json`, including the actual
   attachment and all 19 source identities. Pin its hash externally in the
   collector CLI. No source embeds this manifest hash. The template is deliberately
   invalid and UNBOUND; it is not an executable deployment description.
7. After actual integer outer0 with no continuing session, use the separately
   reviewed finalizer, strict summary and strong collector under their original
   gates. New `--deployment-manifest` and `--expected-deployment-sha256` arguments
   pass the externally pinned post-launch manifest to the exact adapter.

The graph is finite: immutable certificate → bridge source → actual capture →
finalizer → authority → collector → caller-pinned manifest. Actual terminal and
collector-completion receipts are later separate evidence. They do not require
rebuilding sources or repacking their own completion recursively.

Numeric PID/session reuse alone is not blacklisted. Actual new candidate/root/
label/source/command/birth/tool/timestamp joins must distinguish a real observation
from stale C5 evidence. The existing finalizer and strong authority retain their
independent actual-tool, process and terminal gates.

## Future checks and invocation

After the quiet window, run the controls from the current source-preparation root:

```text
/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.venv/bin/python -B /datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-master-deployment-source-preparation1/test_deployment_bridge.py
```

The pure deployment positives use explicitly synthetic new-runtime bindings and
never create the planned new root. Historical-certificate controls create fresh
temporary metadata copies, consume the actual immutable old component certificate,
and mutate only those copies. They do not establish a real new deployment.

Actual validation after binding uses:

```text
<new-root>/.venv/bin/python -B <new-root>/.issue-11-evidence/issue161-master1-binding1/deployment_bridge.py --manifest <new-root>/.issue-11-evidence/issue161-master1-binding1/deployment.json --expected-manifest-sha256 <actual-M> --expected-bridge-sha256 <reviewed-B> --expected-merged-commit <verified-actual-merge> --expected-launcher-sha256 <reviewed-L>
```

Run appropriate focused static checks and retain their full actual results after
the quiet window. All controls/static checks and this validation remain NOT_RUN.
Obtain independent complete source/control assessment before use. New control
bodies/results live outside the operational binding tree and are not automatically
packaged by existing retention; preserve them as explicit finite evidence assets.
No release, push, merge or feature readiness is granted by this preparation.
