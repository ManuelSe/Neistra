"""Prepared NOT_RUN controls; synthetic deployment data is never real authority.

Pure transformations use the immutable original source bodies but fake new-runtime
bindings. Historical-certificate controls use fresh temporary metadata copies only.
No application/service, process experiment, Git, SQL or qualification is launched.
"""

from __future__ import annotations

from copy import deepcopy
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
import zipfile

HERE = Path(__file__).parent.resolve()
SPEC = importlib.util.spec_from_file_location("deployment_bridge_control_subject", HERE / "deployment_bridge.py")
assert SPEC is not None and SPEC.loader is not None
bridge = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(bridge)
ORIGINAL = Path(bridge.OLD_ROOT) / bridge.BASE_DIRECTORY
ASSESSMENTS = Path(bridge.OLD_ROOT) / bridge.ASSESSMENT_DIRECTORY
CANDIDATE = "1" * 40


class SyntheticDeploymentControls(unittest.TestCase):
    def setUp(self) -> None:
        self.original = {name: (ORIGINAL / name).read_bytes() for name in (
            "run-full-c4-candidate5.py", "c4-candidate5-recipe.json", "capture-attachment.py",
            "finalize-tool-supervision.py", "strong_authority.py", "postgate-retention.py",
            "strong_process_scan.py", "strong_process_scan.original.py.txt", "strong_process_scan.parent.py.txt",
            "scanner-provenance.json", "postgate-retention.original.py.txt", "unrelated-desktop-processes.json",
        )}
        self.bridge_body = (HERE / "deployment_bridge.py").read_bytes()
        self.manifest = {
            "schema": "issue161-master1-deployment-v1", "root": bridge.NEW_ROOT, "label": bridge.LABEL,
            "candidate": CANDIDATE,
            "bindings": {"preceding_receipt_sha256": "2" * 64, "tool_session_id": 12345,
                         "wrapper_pid": 23456, "attachment": {
                             "path": f"{bridge.NEW_ROOT}/{bridge.SUPERVISION}/attachment.json", "sha256": "3" * 64}},
            "sources": {},
        }
        self.expected = bridge.expected_bodies(self.original, self.manifest, self.bridge_body)
        self.manifest["sources"] = {name: bridge.identity(body) for name, body in self.expected.items()}

    def test_positive_is_only_synthetic_exact_declared_transformation(self) -> None:
        bridge.validate_manifest(self.manifest, CANDIDATE)
        bridge.check_source_map(self.manifest, dict(self.expected), self.expected)
        self.assertEqual(bridge.sha(self.expected[f"docs/assets/ligand-information/{bridge.LABEL}-recipe.json"]),
                         bridge.MASTER_RECIPE)
        self.assertEqual(len(bridge.decode(self.expected[f"docs/assets/ligand-information/{bridge.LABEL}-recipe.json"])["steps"]), 43)
        self.assertNotIn("pass", self.manifest)
        self.assertNotIn("ready", self.manifest)

    def test_numeric_reuse_alone_is_not_blacklisted(self) -> None:
        self.manifest["bindings"]["tool_session_id"] = 72411
        self.manifest["bindings"]["wrapper_pid"] = 1358462
        bridge.validate_manifest(self.manifest, CANDIDATE)
        # Still explicitly synthetic: full new path/candidate/observations and
        # actual external tool provenance are mandatory in a real deployment.

    def test_unbound_actual_bindings_refuse(self) -> None:
        for name, value in [("preceding_receipt_sha256", "UNBOUND"), ("tool_session_id", "UNBOUND"),
                            ("wrapper_pid", "UNBOUND"), ("tool_session_id", True), ("wrapper_pid", 0)]:
            with self.subTest(binding=name, value=value):
                candidate = deepcopy(self.manifest)
                candidate["bindings"][name] = value
                with self.assertRaises(ValueError):
                    bridge.validate_manifest(candidate, CANDIDATE)

    def test_unbound_or_wrong_expected_actual_commit_refuses(self) -> None:
        for expected in ["UNBOUND", "f" * 40]:
            with self.subTest(expected=expected), self.assertRaises(ValueError):
                bridge.validate_manifest(self.manifest, expected)

    def test_stale_c5_root_label_or_attachment_refuse_coherently(self) -> None:
        for field, value in [("root", bridge.OLD_ROOT), ("label", bridge.OLD_LABEL)]:
            with self.subTest(field=field):
                candidate = {**self.manifest, field: value}
                with self.assertRaises(ValueError):
                    bridge.validate_manifest(candidate, CANDIDATE)
        candidate = deepcopy(self.manifest)
        candidate["bindings"]["attachment"]["path"] = f"{bridge.OLD_ROOT}/.issue-11-evidence/issue161-c4-candidate5-outer-supervisor1/attachment.json"
        with self.assertRaises(ValueError):
            bridge.validate_manifest(candidate, CANDIDATE)

    def test_omitted_or_extra_contract_fields_refuse(self) -> None:
        for field in self.manifest:
            candidate = deepcopy(self.manifest)
            del candidate[field]
            with self.subTest(missing=field), self.assertRaises(ValueError):
                bridge.validate_manifest(candidate, CANDIDATE)
        with self.assertRaises(ValueError):
            bridge.validate_manifest({**self.manifest, "extra": True}, CANDIDATE)

    def test_extra_binding_and_missing_attachment_hash_refuse(self) -> None:
        candidate = deepcopy(self.manifest)
        candidate["bindings"]["extra"] = True
        with self.assertRaises(ValueError):
            bridge.validate_manifest(candidate, CANDIDATE)
        candidate = deepcopy(self.manifest)
        del candidate["bindings"]["attachment"]["sha256"]
        with self.assertRaises(ValueError):
            bridge.validate_manifest(candidate, CANDIDATE)

    def test_added_removed_or_extra_source_identity_fields_refuse(self) -> None:
        name = next(iter(self.expected))
        for mode in ["extra", "missing", "extra-identity"]:
            with self.subTest(mode=mode):
                candidate = deepcopy(self.manifest)
                if mode == "extra":
                    candidate["sources"]["undeclared-source.py"] = bridge.identity(b"x")
                elif mode == "missing":
                    del candidate["sources"][name]
                else:
                    candidate["sources"][name]["extra"] = True
                with self.assertRaises(ValueError):
                    bridge.check_source_map(candidate, self.expected, self.expected)

    def test_even_rehashed_new_logic_is_undeclared(self) -> None:
        for suffix in ["run-full-c4-master1.py", "strong_process_scan.py", "strong_authority.py", "postgate-retention.py"]:
            name = next(name for name in self.expected if name.endswith(suffix))
            bodies = {**self.expected, name: self.expected[name] + b"\nraise RuntimeError('synthetic new logic')\n"}
            candidate = deepcopy(self.manifest)
            candidate["sources"][name] = bridge.identity(bodies[name])
            with self.subTest(source=name), self.assertRaises(ValueError):
                bridge.check_source_map(candidate, bodies, self.expected)

    def test_stale_declared_source_hash_refuses(self) -> None:
        candidate = deepcopy(self.manifest)
        candidate["sources"][next(iter(self.expected))]["sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            bridge.check_source_map(candidate, self.expected, self.expected)

    def test_changed_recipe_bounds_deadline_or_workload_refuse(self) -> None:
        name = f"docs/assets/ligand-information/{bridge.LABEL}-recipe.json"
        for replacement in [b'"steps": []', b'"changed_workload": true', b'"timeout_seconds": 1']:
            changed = self.expected[name] + b"\n" + replacement
            candidate = deepcopy(self.manifest)
            candidate["sources"][name] = bridge.identity(changed)
            with self.subTest(change=replacement), self.assertRaises(ValueError):
                bridge.check_source_map(candidate, {**self.expected, name: changed}, self.expected)

    def test_fixed_recipe_transform_is_reversible_and_all_other_bytes_stay(self) -> None:
        original = self.original["c4-candidate5-recipe.json"]
        transformed = bridge.fixed_transform(original)
        for old, new in reversed(bridge.TRANSFORMS):
            transformed = transformed.replace(new.encode(), old.encode())
        self.assertEqual(transformed, original)

    def test_constants_only_changes_the_named_module_value(self) -> None:
        source = b"TOKEN = 'old'\n\ndef method():\n    return 'old'\n"
        self.assertEqual(bridge.constants(source, {"TOKEN": "new"}),
                         b"TOKEN = 'new'\n\ndef method():\n    return 'old'\n")

    def test_missing_or_duplicate_constant_assignment_refuses(self) -> None:
        for body in [b"OTHER = 1\n", b"TOKEN = 1\nTOKEN = 2\n"]:
            with self.subTest(body=body), self.assertRaises(ValueError):
                bridge.constants(body, {"TOKEN": 3})

    def test_collector_adapter_exceptions_are_unique_and_exact(self) -> None:
        original = self.original["postgate-retention.py"]
        self.assertEqual(original.count(bridge.OLD_CALL.encode()), 1)
        self.assertEqual(original.count(bridge.OLD_ARGUMENT.encode()), 1)
        for body in [b"", original + original]:
            with self.subTest(size=len(body)), self.assertRaises(ValueError):
                bridge.exact_replace(body, bridge.OLD_CALL, bridge.NEW_CALL)

    def test_duplicate_json_metadata_refuses(self) -> None:
        with self.assertRaises(ValueError):
            bridge.decode(b'{"schema":"one","schema":"two"}')


class TemporaryHistoricalCertificateControls(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory(prefix="neistra161-bridge-historical-control-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.preparation = self.root / "preparation"
        self.assessments = self.root / "assessments"
        self.preparation.mkdir()
        self.assessments.mkdir()
        capsule = (ORIGINAL / "source-review.zip").read_bytes()
        self.assertEqual(bridge.sha(capsule), bridge.BASE_CAPSULE)
        (self.preparation / "source-review.zip").write_bytes(capsule)
        with zipfile.ZipFile(ORIGINAL / "source-review.zip") as archive:
            for name in archive.namelist():
                relative = Path(name)
                self.assertFalse(relative.is_absolute() or ".." in relative.parts)
                destination = self.preparation / relative
                if name.endswith("/"):
                    destination.mkdir(parents=True, exist_ok=True)
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(archive.read(name))
        for name in bridge.BASE_ASSESSMENTS:
            (self.assessments / name).write_bytes((ASSESSMENTS / name).read_bytes())

    def test_original_actual_component_certificate_is_consumed_unchanged(self) -> None:
        module, proof, originals = bridge.immutable_certificate(self.preparation, self.assessments)
        self.assertEqual(sum(proof["controls"]["current_cases"].values()), 67)
        self.assertEqual(bridge.sha(originals["strong_authority.py"]), bridge.BASE_CONSUMER)
        self.assertEqual(module.validate_launch_preparation.__name__, "validate_launch_preparation")
        # This consumes historical actual controls only, not a new deployment.

    def test_wrong_original_consumer_capsule_or_assessment_refuses(self) -> None:
        for path in [self.preparation / "strong_authority.py", self.preparation / "source-review.zip",
                     self.assessments / "architecture-source-assessment.json"]:
            with self.subTest(path=path.name):
                original = path.read_bytes()
                path.write_bytes(original + b"\n")
                with self.assertRaises(ValueError):
                    bridge.immutable_certificate(self.preparation, self.assessments)
                path.write_bytes(original)

    def test_wrong_retained_completion_or_log_body_refuses(self) -> None:
        receipt_path = self.preparation / "source-controls1/receipt.json"
        original = receipt_path.read_bytes()
        receipt = json.loads(original)
        receipt["complete"] = False
        receipt_path.write_text(json.dumps(receipt))
        with self.assertRaises(ValueError):
            bridge.immutable_certificate(self.preparation, self.assessments)
        receipt_path.write_bytes(original)
        log = self.preparation / "source-controls1/test_candidate5.py.stderr.log"
        log.write_bytes(b"Ran 11 tests in 0.001s\nFAILED (failures=1)\n")
        with self.assertRaises(ValueError):
            bridge.immutable_certificate(self.preparation, self.assessments)

    def test_reused_existing_parser_rejects_incomplete_or_contradictory_outcomes(self) -> None:
        module, _, _ = bridge.immutable_certificate(self.preparation, self.assessments)
        module.validate_unittest_stderr("Ran 11 tests in 0.001s\n\nOK\n", 11)
        for text in ["Ran 11 tests in 0.001s\n", "Ran 11 tests in 0.001s\nOK\nFAILED\n",
                     "Ran 10 tests in 0.001s\nOK\n", "Ran 11 tests in 0.001s\nOK (skipped=1)\n"]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                module.validate_unittest_stderr(text, 11)

    def test_unsafe_symlink_and_hardlinked_metadata_refuse(self) -> None:
        target = self.root / "real.json"
        target.write_bytes(b"{}")
        alias = self.root / "alias.json"
        alias.symlink_to(target)
        with self.assertRaises(ValueError):
            bridge.read(alias)
        os.link(target, self.root / "hardlink.json")
        with self.assertRaises(ValueError):
            bridge.read(target)


class TemporaryDeploymentDirectoryControls(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory(prefix="neistra161-bridge-directory-control-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.expected = {}
        for directory in (bridge.TOOLING, bridge.SCANNER_STORAGE, bridge.LEGACY):
            target = self.root / directory
            target.mkdir(parents=True)
            relative = f"{directory}/synthetic.py"
            self.expected[relative] = b"# synthetic directory membership only\n"
            (self.root / relative).write_bytes(self.expected[relative])
        (self.root / bridge.TOOLING / "deployment.json").write_bytes(b"{}")

    def test_exact_synthetic_directory_membership_passes_only_that_check(self) -> None:
        bridge.check_deployment_directories(self.root, self.expected)

    def test_undeclared_module_is_not_hidden_by_omitting_it_from_source_map(self) -> None:
        (self.root / bridge.TOOLING / "undeclared.py").write_bytes(b"# synthetic extra source\n")
        with self.assertRaises(ValueError):
            bridge.check_deployment_directories(self.root, self.expected)

    def test_unlisted_directory_or_alias_refuses(self) -> None:
        extra = self.root / bridge.TOOLING / "unlisted"
        extra.mkdir()
        with self.assertRaises(ValueError):
            bridge.check_deployment_directories(self.root, self.expected)
        extra.rmdir()
        extra.symlink_to(self.root / bridge.LEGACY / "synthetic.py")
        with self.assertRaises(ValueError):
            bridge.check_deployment_directories(self.root, self.expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)
