DRAFT — append to D-193 only after actual successful C5 completion, strong custody
and independent readbacks. No tracked source is changed while C5 runs.

Prepare the canonical tracked `c4-master1-recipe.json` for the planned isolated
merged checkout as part of the normal evidence checkpoint. Preserve the actual C5
qualifying identity `f83347b3c2d59a2a913a9198f99a5276992015b4`; the later evidence
commit is a separate review candidate. Reuse C5 evidence only after demonstrating
complete equivalence of the selected source catalogue, qualifying helpers,
fixtures, configuration, methods and qualification DATA. Inspect the entire
intervening diff. Do not relabel the original gate or receipts.

The D-201 qualification-continuation paragraph and the #160 tracked master-recipe
checkpoint provide scoped precedents for this route. They do not waive a gate for
changed runtime or qualification inputs. All seven final assessments must cover
one common evidence candidate. The actual normal merge then receives a fresh full
43-command qualification, including its own literal predecessor extraction and
real owned environment, original lineage, actual tool completion and complete
closure/raw/source/scientific/resource/reader/package readbacks before publication.

The master recipe retains every responsibility and changes only the run label and
owned paths. Verify exact equality with the unchanged tracked builder before
committing it. Commit it before the merged qualification; no recipe-ignore exception
is required. Unknown merged SHA, predecessor receipt, process and tool-session
bindings remain unbound until observed.

Keep the original C5 source/control certificate immutable. A separately reviewed
deployment bridge must validate that original certificate with its original pins,
then prove the explicit master-deployment transformation. Its new validation logic
requires affected controls and actual binding checks. Historical 67-control and
82-input consumer results do not claim that the new deployment ran or passed.

Keep the evidence graph finite: immutable certificate, deployment proof, live
attachment, actual terminal/finalizer receipt and retention package. Collector logs
stay outside captured trees; retain its later tool completion separately rather
than rebuilding a package to contain its own completion receipt.
