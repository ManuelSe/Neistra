from pathlib import Path
import os,subprocess,gzip,json,hashlib,time
root=Path.cwd().resolve();old=Path('/tmp/neistra-110-reader-0221');task=Path('/tmp/neistra-110-compat-preflight');assert not task.exists();task.mkdir();output=root/'docs/assets/quick-minimization'
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MOLWEAVE_AMBERTOOLS_PREFIX':'/datadisk/dev/.neistra-tools/ambertools-24.8','MOLWEAVE_MINIMIZATION_MAX_RSS_BYTES':str(4*1024**3)};env.pop('MOLWEAVE_DATABASE_URL',None)
current_path=':'.join(str(root/p) for p in ('apps/api/src','packages/molweave_core/src','packages/molweave_demo_plugin/src'));old_path=':'.join(str(old/p) for p in ('apps/api/src','packages/molweave_core/src','packages/molweave_demo_plugin/src'));venv=str(root/'.venv/bin/python');uv=str(root/'.venv/bin/uv')
commands = [
    ('uv', [uv, 'sync', '--frozen'], {}),
    ('pnpm', ['corepack', 'pnpm', 'install', '--frozen-lockfile'], {}),
    ('migration', [uv, 'run', 'alembic', 'upgrade', 'head'], {'MOLWEAVE_DATA_DIR': str(task / 'migration-data')}),
    ('ruff', [uv, 'run', 'ruff', 'check', '.'], {}),
    ('mypy', [uv, 'run', 'mypy', 'apps/api', 'packages/molweave_core'], {}),
    ('python', [uv, 'run', 'pytest'], {}),
    ('lint', ['corepack', 'pnpm', '--dir', 'apps/web', 'lint'], {}),
    ('types', ['corepack', 'pnpm', '--dir', 'apps/web', 'typecheck'], {}),
    ('web-tests', ['corepack', 'pnpm', '--dir', 'apps/web', 'test'], {}),
    ('supervisor', ['corepack', 'pnpm', 'test:dev'], {}),
    ('build', ['corepack', 'pnpm', '--dir', 'apps/web', 'build'], {}),
    ('browser', ['corepack', 'pnpm', 'exec', 'playwright', 'test', '--reporter=list,json'], {}),
    ('forward-migration', [uv, 'run', 'alembic', 'upgrade', 'head'], {'MOLWEAVE_DATA_DIR': str(task / 'forward')}),
    ('quick-producer', [venv, '-m', 'tests.support.quick_minimization_reader_qualification', 'produce', '--data-dir', str(task / 'forward'), '--evidence', str(task / 'quick-producer.json')], {'PYTHONPATH': current_path}),
    ('old-reader', [venv, '-m', 'tests.support.quick_minimization_reader_qualification', 'read', '--data-dir', str(task / 'forward'), '--reader-root', str(old), '--expected-reader', '0.22.1', '--evidence', str(task / 'old-reader.json')], {'PYTHONPATH': old_path}),
    ('reverse-migration', [uv, 'run', 'alembic', 'upgrade', 'head'], {'MOLWEAVE_DATA_DIR': str(task / 'reverse')}),
    ('old-producer', [venv, '-m', 'tests.support.minimization_reader_qualification', 'produce', '--data-dir', str(task / 'reverse'), '--evidence', str(task / 'old-producer.json')], {'PYTHONPATH': old_path}),
    ('current-reader', [venv, '-m', 'tests.support.minimization_reader_qualification', 'read', '--data-dir', str(task / 'reverse'), '--reader-root', str(root), '--expected-reader', '0.23.0', '--evidence', str(task / 'current-reader.json')], {'PYTHONPATH': current_path}),
    ('versions', [venv, '/tmp/neistra-110-versions.py'], {}),
    ('diff', ['git', 'diff', '--check'], {}),
]
records=[]
for label,cmd,overrides in commands[12:]:
 print('START',label,flush=True);begun=time.time()
 with (task/(label+'.log')).open('wb') as stream:r=subprocess.run(cmd,env={**env,**overrides},stdout=stream,stderr=subprocess.STDOUT)
 data=(task/(label+'.log')).read_bytes();(output/('c5-compat-preflight-'+label+'.log.gz')).write_bytes(gzip.compress(data,mtime=0));records.append({'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-begun,'log_sha256':hashlib.sha256(data).hexdigest()})
 if r.returncode:print(data.decode()[-6000:]);raise SystemExit(r.returncode)
 evidence=task/(label+'.json')
 if evidence.exists():(output/('c5-compat-preflight-'+label+'.json')).write_bytes(evidence.read_bytes())
 print('END',label,flush=True)
(output/'c5-compat-preflight.json').write_text(json.dumps({'passed':True,'note':'Independent compatibility preflight; not a complete release gate','steps':records},indent=2)+'\n')
