from pathlib import Path
import os,subprocess,sys
p=Path('/tmp/neistra-110-pocket-native-settled');assert not p.exists();p.mkdir()
e={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','PLAYWRIGHT_BROWSERS_PATH':'.playwright','MOLWEAVE_E2E_API_PORT':'17110','MOLWEAVE_E2E_WORKER_PORT':'17111','MOLWEAVE_E2E_WEB_PORT':'17173','MOLWEAVE_E2E_DATA_DIR':str(p/'data'),'PLAYWRIGHT_JSON_OUTPUT_NAME':str(p/'browser.json'),'MOLWEAVE_MINIMIZATION_MAX_RSS_BYTES':str(4*1024**3),'MOLWEAVE_AMBERTOOLS_PREFIX':'/datadisk/dev/.neistra-tools/ambertools-24.8'}
c=['corepack','pnpm','exec','playwright','test','tests/e2e/quick-minimization-performance.spec.ts','tests/e2e/quick-minimization.spec.ts','--repeat-each=2','--reporter=list,json']
(p/'ac-before.txt').write_text(Path('/sys/class/power_supply/AC0/online').read_text())
with (p/'browser.log').open('wb') as f:r=subprocess.run(c,env=e,stdout=f,stderr=subprocess.STDOUT)
(p/'ac-after.txt').write_text(Path('/sys/class/power_supply/AC0/online').read_text())
print((p/'browser.log').read_text()[-10000:]);sys.exit(r.returncode)
