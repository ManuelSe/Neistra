from pathlib import Path
import os,subprocess,sys
phase=sys.argv[1];assert phase in {'original','fixed'}
task=Path('/tmp')/f'neistra-110-surface-{phase}';assert not task.exists();task.mkdir()
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','PLAYWRIGHT_BROWSERS_PATH':'.playwright','MOLWEAVE_E2E_API_PORT':'13110','MOLWEAVE_E2E_WORKER_PORT':'13111','MOLWEAVE_E2E_WEB_PORT':'13173','MOLWEAVE_E2E_DATA_DIR':str(task/'data'),'PLAYWRIGHT_JSON_OUTPUT_NAME':str(task/'browser.json')}
cmd=['corepack','pnpm','exec','playwright','test','tests/e2e/surface-objects.spec.ts','--grep','manages production','--reporter=list,json']
cmd+=['--repeat-each=2'] if phase=='fixed' else ['--project=chromium']
with (task/'browser.log').open('wb') as stream:r=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
print((task/'browser.log').read_text()[-7500:]);sys.exit(r.returncode)
