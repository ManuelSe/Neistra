from pathlib import Path
import hashlib,json,subprocess,zipfile
bundle=json.loads(Path('/tmp/neistra-110-bundle.json').read_text())
release=json.loads(subprocess.check_output(['gh','api','repos/ManuelSe/Neistra/releases/tags/v0.23.0'],text=True))
assert not release['draft'] and not release['prerelease'] and release['target_commitish']=='6536e2a3140d0b8b112562ffec580d37830bc217'
asset=next(a for a in release['assets'] if a['name']==bundle['filename']);assert asset['digest']=='sha256:'+bundle['sha256']
dest=Path('/datadisk/dev/.neistra-tools/issue110-public-download');dest.mkdir(exist_ok=True);download=dest/bundle['filename'];assert not download.exists()
subprocess.run(['curl','--silent','--show-error','--fail','--location','--retry','2','--output',str(download),asset['browser_download_url']],check=True)
assert hashlib.sha256(download.read_bytes()).hexdigest()==bundle['sha256']
with zipfile.ZipFile(download) as z:
 assert z.testzip() is None
 manifest=json.loads(z.read('SHA256.json'));assert len(manifest)==bundle['internal_hashes'];assert len(z.namelist())==bundle['members']
 assert all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in manifest.items())
receipt={'url':asset['browser_download_url'],'asset_id':asset['id'],'sha256':bundle['sha256'],'public_download_verified':True,'crc_verified':True,'internal_hashes':len(manifest)}
Path('/tmp/neistra-110-public-download-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
