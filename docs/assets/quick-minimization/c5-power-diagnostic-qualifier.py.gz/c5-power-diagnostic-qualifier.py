from pathlib import Path
import os,subprocess,sys
task=Path('/tmp/neistra-110-power-diagnostic');assert not task.exists();task.mkdir()
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','PLAYWRIGHT_BROWSERS_PATH':'.playwright','MOLWEAVE_E2E_API_PORT':'15110','MOLWEAVE_E2E_WORKER_PORT':'15111','MOLWEAVE_E2E_WEB_PORT':'15173','MOLWEAVE_E2E_DATA_DIR':str(task/'data'),'PLAYWRIGHT_JSON_OUTPUT_NAME':str(task/'browser.json'),'MOLWEAVE_MINIMIZATION_MAX_RSS_BYTES':str(4*1024**3),'MOLWEAVE_AMBERTOOLS_PREFIX':'/datadisk/dev/.neistra-tools/ambertools-24.8'}
cmd=['corepack','pnpm','exec','playwright','test','tests/e2e/quick-minimization-performance.spec.ts','--project=chromium','--grep','supplied small molecule|genuine quick steps','--reporter=list,json']
(task/'ac-online-before.txt').write_text(Path('/sys/class/power_supply/AC0/online').read_text())
(task/'profile-before.txt').write_text(subprocess.check_output(['powerprofilesctl','get'],text=True))
with (task/'browser.log').open('wb') as stream:r=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
(task/'ac-online-after.txt').write_text(Path('/sys/class/power_supply/AC0/online').read_text())
print((task/'browser.log').read_text()[-9000:]);sys.exit(r.returncode)
