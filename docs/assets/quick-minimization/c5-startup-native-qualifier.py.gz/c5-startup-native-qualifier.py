from pathlib import Path
import os,subprocess,sys
task=Path('/tmp/neistra-110-startup-native');assert not task.exists();task.mkdir()
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','PLAYWRIGHT_BROWSERS_PATH':'.playwright','MOLWEAVE_E2E_API_PORT':'14110','MOLWEAVE_E2E_WORKER_PORT':'14111','MOLWEAVE_E2E_WEB_PORT':'14173','MOLWEAVE_E2E_DATA_DIR':str(task/'data'),'PLAYWRIGHT_JSON_OUTPUT_NAME':str(task/'browser.json'),'MOLWEAVE_MINIMIZATION_MAX_RSS_BYTES':str(4*1024**3),'MOLWEAVE_AMBERTOOLS_PREFIX':'/datadisk/dev/.neistra-tools/ambertools-24.8'}
cmd=['corepack','pnpm','exec','playwright','test','tests/e2e/quick-minimization-performance.spec.ts','--project=chromium','--repeat-each=2','--reporter=list,json']
with (task/'browser.log').open('wb') as stream:r=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
print((task/'browser.log').read_text()[-9000:]);sys.exit(r.returncode)
