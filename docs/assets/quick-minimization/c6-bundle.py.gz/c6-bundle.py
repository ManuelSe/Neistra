from pathlib import Path
import hashlib, io, json, sqlite3, subprocess, zipfile
root=Path.cwd(); out=root/'docs/assets/quick-minimization'
candidate=json.loads((out/'c5-candidate-10-gate.json').read_text())
merged=json.loads((out/'c5-merged-2-gate.json').read_text())
assert candidate['passed'] and merged['passed']
assert len(candidate['steps'])==len(merged['steps'])==20
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert sha==merged['commit']
cs=json.loads((out/'c5-candidate-10-source.json').read_text())['files']
ms=json.loads((out/'c5-merged-2-source.json').read_text())['files']
assert cs==ms
summary=json.loads(Path('/tmp/neistra-110-merged-2-summary.json').read_text())
assert summary['passed']
qualification={'issue':110,'runtime_commit':sha,'candidate_commit':candidate['commit'],'source_identity_count':len(ms),'source_sha256':hashlib.sha256(json.dumps(ms,sort_keys=True).encode()).hexdigest(),'all_20_commands_pass_both_phases':True,'previous_reader':'actual tagged 0.22.1','dependency_upgrade':False,'migration_head':'0014','python':summary['python'],'frontend':summary['frontend'],'supervisor':summary['supervisor'],'browser':summary['browser']['expected'],'browser_exclusions':summary['browser']['skipped'],'failures':0,'flakes':0,'retries':0,'native_scientific_skips':0}
files={}
source=subprocess.check_output(['git','archive','--format=zip',sha])
with zipfile.ZipFile(io.BytesIO(source)) as archive:
 for name in archive.namelist():
  if not name.endswith('/'):files['source/'+name]=archive.read(name)
for name,digest in ms.items():assert hashlib.sha256(files['source/'+name]).hexdigest()==digest
for path in out.iterdir():
 if path.is_file():files['evidence/'+path.name]=path.read_bytes()
for phase,task in [('candidate',Path('/tmp/neistra-110-candidate-10')),('merged',Path('/tmp/neistra-110-merged-2'))]:
 for folder in ['forward','reverse']:
  for p in (task/folder).rglob('*'):
   if p.is_file() and not p.name.endswith(('-wal','-shm')):
    content=p.read_bytes()
    if p.name=='molweave.db':
     with sqlite3.connect(f'file:{p}?mode=ro',uri=True) as src,sqlite3.connect(':memory:') as dst:
      src.backup(dst);content=dst.serialize()
    files[f'compatibility/{phase}/{folder}/'+str(p.relative_to(task/folder))]=content
files['qualification/bundle.py']=Path(__file__).read_bytes()
files['qualification/report.py']=Path('/tmp/neistra-110-report.py').read_bytes()
files['qualification.json']=(json.dumps(qualification,indent=2)+'\n').encode()
files['release-notes.md']=Path('/tmp/neistra-110-release.md').read_bytes()
manifest={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
files['SHA256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=Path('/datadisk/dev/.neistra-tools/neistra-v0.23.0-verification.zip')
assert not target.exists()
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,data in sorted(files.items()):archive.writestr(name,data)
with zipfile.ZipFile(target) as archive:
 assert archive.testzip() is None
 for name,digest in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest
result={'filename':target.name,'path':str(target),'size':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'members':len(files),'internal_hashes':len(manifest),'crc_verified':True,'qualification':qualification}
Path('/tmp/neistra-110-bundle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
