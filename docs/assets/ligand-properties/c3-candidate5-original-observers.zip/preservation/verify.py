"""Standalone supplement verification, including whole original unions and mirrored traces."""
from pathlib import Path
import argparse
import json
import zipfile
from support import H, HELPER, TERMINAL, CAPTURE_SEAL, helpers, fingerprint, inventory, selected, sha, verify_trace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--archive', required=True, type=Path)
parser.add_argument('--originals', action='store_true')
parser.add_argument('--retained-workspace', type=Path)
args = parser.parse_args()
counts = helpers()['verify_layers'](args.archive, args.archive.name)
with zipfile.ZipFile(args.archive) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    inv = json.loads(archive.read('preservation/input-inventory.json'))
    context = json.loads(archive.read('preservation/context.json'))
    provenance = json.loads(archive.read('preservation/provenance.json'))
    seal = json.loads(archive.read('preservation/input-seal.json'))
    expected = set(inv['files']) | {'preservation/' + name for name in context['metadata_members']}
    assert len(archive.namelist()) == len(set(archive.namelist()))
    assert set(archive.namelist()) == expected | {'manifest.json'} and set(manifest) == expected
    assert context['candidate'] == provenance['candidate'] == seal['candidate'] == H
    assert context['retention_only'] and not context['new_qualification_or_timing_claim']
    assert context['not_a_tenth_failed_forensic_asset'] and not context['release_or_publication_complete']
    assert context['original_observer_roots'] == len(provenance['observer_bindings']) == 8
    assert not context['observer_root_DB_WAL_SHM_files'] and not inv['body_exclusions']
    assert manifest['preservation/release-evidence-used.py.txt']['sha256'] == HELPER
    for name, field in [('input-inventory.json', 'input_inventory'), ('provenance.json', 'provenance'), ('context.json', 'context')]:
        assert manifest['preservation/' + name] == seal[field]
    for name, row in inv['files'].items():
        assert manifest[name] == {key: row[key] for key in ('bytes', 'sha256')}
    def member_for_original(path):
        matches = [name for name, row in inv['files'].items() if row['original_path'] == path]
        assert len(matches) == 1
        return matches[0]
    terminal_member = member_for_original(provenance['terminal_proof']['path'])
    assert manifest[terminal_member]['sha256'] == TERMINAL
    terminal = json.loads(archive.read(terminal_member))
    assert terminal['candidate'] == H and terminal['actual_runner_wait_exit'] == 0 and terminal['recorded_steps'] == 43
    capture_member = member_for_original(provenance['qualified_source_capsule_seal']['path'])
    assert manifest[capture_member]['sha256'] == CAPTURE_SEAL
    capture_seal = json.loads(archive.read(capture_member))
    assert capture_seal['candidate'] == H and capture_seal['terminal_proof_sha256'] == TERMINAL
    source_map_member = member_for_original(provenance['captured_source_map']['path'])
    assert manifest[source_map_member]['sha256'] == capture_seal['map_file']['sha256']
    captured = json.loads(archive.read(source_map_member))['current']
    reference = provenance['trace_reference']
    source_member = member_for_original(reference['trace_sources_path'])
    trace_sources = json.loads(archive.read(source_member))
    trace = None
    if args.retained_workspace is not None:
        retained = provenance['existing_retained_state_archive']
        assert fingerprint(args.retained_workspace) == {key: retained[key] for key in ('bytes', 'sha256')}
        with zipfile.ZipFile(args.retained_workspace) as prior:
            prior_manifest = json.loads(prior.read('manifest.json'))
            trace = prior.read(reference['retained_archive_member'])
            assert prior_manifest[reference['retained_archive_member']] == {key: reference[key] for key in ('bytes', 'sha256')}
            assert prior.read(reference['retained_sources_member']) == archive.read(source_member)
    if args.originals:
        assert inventory(selected()) == inv, 'Complete original root union, body or metadata changed'
        original_trace = Path(reference['original_path']).read_bytes()
        assert len(original_trace) == reference['bytes'] and sha(original_trace) == reference['sha256']
        if trace is not None:
            assert trace == original_trace
        trace = original_trace
    verified = []
    for binding in provenance['observer_bindings']:
        native = archive.read(binding['native_member'])
        assert archive.read(binding['original_report_member']) == native
        assert manifest[binding['native_member']] == manifest[binding['original_report_member']] == binding['native_and_original_report_bytes']
        observed = archive.read(binding['original_records_member'])
        assert manifest[binding['original_records_member']] == binding['observed_records_bytes']
        report = json.loads(native)
        assert report['complete'] and report['sources_unchanged']
        assert report['sources_before'] == report['sources_after'] == trace_sources
        assert all(captured[name] == value for name, value in trace_sources.items())
        if trace is not None:
            assert verify_trace(report, observed, trace, trace_sources, captured) == binding['trace_checks']
        verified.append({'observer_root': binding['observer_root'], 'original_files': binding['original_regular_files'], 'records': binding['trace_checks']['records']})
print(json.dumps({'scope': 'Historical qualified candidate5 original-observer retention only; no new qualification/timings.',
                  'candidate': H, 'archive': fingerprint(args.archive), 'recursive_counts': counts,
                  'exact_outer_union': len(expected), 'original_files': len(inv['files']),
                  'original_observer_roots': len(verified), 'original_observer_files': sum(row['original_files'] for row in verified),
                  'whole_original_union_rehashed': args.originals, 'actual_trace_slices_reverified': trace is not None,
                  'retained_workspace_trace_reverified': args.retained_workspace is not None,
                  'observer_bindings': verified, 'SQL_opened': False, 'new_qualification_or_timing_claim': False}))
