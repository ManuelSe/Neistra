"""Retain the eight original historical candidate5 observer trees; no new qualification."""
from pathlib import Path
from datetime import datetime, timezone
import json
import zipfile
from support import OUT, H, HELPER, TERMINAL, CAPTURE_SEAL, ASSETS, CAPTURE, TRANSPORT, RETAINED, TRACE, frozen, helpers, inventory, selected, sha, verify_trace


def write(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


proof_path = TRANSPORT / 'primary-terminal-readback.json'
assert frozen(proof_path)['sha256'] == TERMINAL
proof = json.loads(proof_path.read_bytes())
assert proof['candidate'] == H and proof['actual_runner_wait_exit'] == 0 and proof['recorded_steps'] == 43 and proof['gate_complete'] is True
seal_path = CAPTURE / 'source-capture-seal.json'
assert frozen(seal_path)['sha256'] == CAPTURE_SEAL
seal = json.loads(seal_path.read_bytes())
assert seal['candidate'] == H and seal['source_capture_complete'] is True and seal['terminal_proof_sha256'] == TERMINAL
map_path = CAPTURE / 'captured-source-maps.json'
assert frozen(map_path)['sha256'] == seal['map_file']['sha256']
captured = json.loads(map_path.read_bytes())['current']
retained_handoff = json.loads((RETAINED / 'handoff.json').read_bytes())
assert retained_handoff['candidate'] == H and retained_handoff['candidate_gate_PASS'] is True
retained_archive = retained_handoff['archive']
retained_path = Path(retained_archive['path'])
assert frozen(retained_path) == {key: retained_archive[key] for key in ('bytes', 'sha256')}
trace = TRACE.read_bytes()
trace_sources_path = TRACE.with_suffix('.sources.json')
trace_sources_body = trace_sources_path.read_bytes()
trace_sources = json.loads(trace_sources_body)
with zipfile.ZipFile(retained_path) as archive:
    prior_manifest = json.loads(archive.read('manifest.json'))
    trace_member = 'workspace/e2e/qualification/worker-turns.jsonl'
    sources_member = 'workspace/e2e/qualification/worker-turns.sources.json'
    assert prior_manifest[trace_member] == frozen(TRACE)
    assert prior_manifest[sources_member] == frozen(trace_sources_path)
    assert archive.read(trace_member) == trace and archive.read(sources_member) == trace_sources_body
roots = selected()
before = inventory(roots)
write('input-inventory.json', before)
bindings = []
for attachment in roots['native-bindings']['paths']:
    report = json.loads(attachment.read_bytes())
    original_records = Path(report['work_order']['observed_records'])
    directory = original_records.parent
    original_report = directory / 'worker-observation.json'
    assert original_report.read_bytes() == attachment.read_bytes()
    records = original_records.read_bytes()
    trace_checks = verify_trace(report, records, trace, trace_sources, captured)
    label = 'observers/' + directory.name
    bindings.append({'observer_root': str(directory), 'inventory_label': label,
                     'native_attachment': str(attachment), 'native_member': 'native-bindings/' + attachment.relative_to(ASSETS).as_posix(),
                     'original_report': str(original_report), 'original_report_member': label + '/worker-observation.json',
                     'original_records': str(original_records), 'original_records_member': label + '/' + original_records.name,
                     'native_and_original_report_bytes': frozen(attachment),
                     'observed_records_bytes': frozen(original_records), 'observer_complete': True,
                     'sources_before_after_equal_actual_qualified_H_source_subset': True,
                     'observed_source_count': len(report['sources_before']), 'trace_checks': trace_checks,
                     'original_regular_files': before['roots'][label]['regular_files']})
assert len(bindings) == len({row['observer_root'] for row in bindings}) == 8
provenance = {'candidate': H, 'historical_original_gate_label': 'c4-candidate5',
              'terminal_proof': {'path': str(proof_path), **frozen(proof_path)},
              'qualified_source_capsule_seal': {'path': str(seal_path), **frozen(seal_path)},
              'captured_source_map': {'path': str(map_path), **frozen(map_path)},
              'existing_retained_state_archive': retained_archive,
              'existing_retained_state_handoff': {'path': str(RETAINED / 'handoff.json'), **frozen(RETAINED / 'handoff.json')},
              'trace_reference': {'original_path': str(TRACE), **frozen(TRACE), 'retained_archive_member': trace_member,
                                  'trace_sources_path': str(trace_sources_path), 'trace_sources_bytes': frozen(trace_sources_path),
                                  'retained_sources_member': sources_member,
                                  'scope': 'Actual original trace bytes already preserved in unchanged qualified candidate5 retained-state archive; all eight observed mirrors checked against exact contiguous source slices.'},
              'observer_bindings': bindings, 'observer_root_DB_WAL_SHM_files': [],
              'new_qualification_or_timing_claim': False, 'SQL_opened': False}
write('provenance.json', provenance)
metadata_members = ['input-inventory.json', 'provenance.json', 'context.json', 'input-seal.json', 'package.py', 'support.py', 'verify.py', 'release-evidence-used.py.txt']
context = {'scope': 'Historical qualified-H main-release supplement closing the eight original observer-root retention gap only.',
           'candidate': H, 'historical_label': 'c4-candidate5', 'retention_only': True,
           'previous_candidate_gate_PASS': True, 'original_runner_wait_exit': 0,
           'original_observer_roots': len(bindings), 'original_observer_regular_files': sum(row['original_regular_files'] for row in bindings),
           'observer_root_DB_WAL_SHM_files': [], 'named_cache_or_other_body_exclusions': [],
           'empty_directories_and_aliases': 'Full inert descriptors retained; alias targets and structural files are never opened.',
           'future_main_supplemental_name': 'qualified-candidate5-original-observers.zip',
           'not_a_tenth_failed_forensic_asset': True, 'source_capsules_and_existing_retained_archive_not_duplicated': True,
           'new_qualification_or_timing_claim': False, 'merged_master_or_native12_identity_claim': False,
           'release_or_publication_complete': False, 'SQL_opened': False,
           'metadata_members': metadata_members}
write('context.json', context)
write('input-seal.json', {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'candidate': H,
                         'input_inventory': frozen(OUT / 'input-inventory.json'), 'provenance': frozen(OUT / 'provenance.json'),
                         'context': frozen(OUT / 'context.json'), 'original_files': len(before['files']),
                         'original_bytes': sum(row['bytes'] for row in before['files'].values()),
                         'inputs_closed_and_originals_retained': True})
items = {name: Path(row['original_path']) for name, row in before['files'].items()}
for name in metadata_members:
    items['preservation/' + name] = OUT / name
packet = helpers()['archive'](items, OUT / 'qualified-candidate5-original-observers.zip')
assert selected() == roots
after = inventory(roots)
write('originals-after.json', after)
assert before == after, 'Original roots, union, bytes or metadata changed'
assert frozen(TRACE) == {key: provenance['trace_reference'][key] for key in ('bytes', 'sha256')}
verification = {'scope': context['scope'], 'candidate': H, 'archive': packet,
                'original_files': len(before['files']), 'original_bytes': sum(row['bytes'] for row in before['files'].values()),
                'original_observer_roots': len(bindings), 'original_observer_regular_files': context['original_observer_regular_files'],
                'empty_directories': len(before['empty_directories']), 'inert_aliases': len(before['inert_aliases']),
                'inert_nonregular_descriptors': len(before['inert_nonregular_descriptors']),
                'all_before_after_original_bytes_metadata_and_union_exact': True,
                'all8source_and_exact_original_trace_mirror_bindings': True,
                'strict_fullbody_CRC_manifest_union_recursive_verification': 'PASS',
                'configured_single_asset_cap_bytes': 2 * 1024**3, 'within_configured_single_asset_cap': packet['bytes'] < 2 * 1024**3,
                'retention_only': True, 'new_qualification_or_timing_claim': False,
                'not_a_tenth_failed_forensic_asset': True, 'SQL_opened': False}
assert verification['within_configured_single_asset_cap']
write('verification.json', verification)
with (OUT / 'qualified-candidate5-original-observers.zip.sha256').open('x') as stream:
    stream.write(packet['sha256'] + '  qualified-candidate5-original-observers.zip\n')
print(json.dumps(verification))
