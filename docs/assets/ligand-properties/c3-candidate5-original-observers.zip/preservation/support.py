"""Pure whole-original inventory and strict helper for historical candidate5 observers."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import stat

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
OUT = Path(__file__).absolute().parent
H = 'e47de3dd8f2e53fd27abac8d39dac3f0696da7f7'
HELPER = '34ef47ebd6fe9f12009600e099c8cd5599a851c4dc95ac5412b7eb12470173e3'
TERMINAL = '5a00498e17e1c3eda6fb2c556bc5c972776c829a3b9873e071574ad503725fcc'
CAPTURE_SEAL = '04eafc02f73b452bc47a8156b19e83fb568f197108c2204eaff23c69e9ff484d'
ASSETS = ROOT / 'docs/assets/ligand-properties/c4-candidate5-native'
CAPTURE = ROOT / '.issue-11-evidence/issue159-c4-candidate5-source-capture1'
TRANSPORT = ROOT / '.issue-11-evidence/issue159-c4-candidate5-transport1'
RETAINED = ROOT / '.issue-11-evidence/issue159-c4-candidate5-retained-state1'
TRACE = Path('/tmp/neistra159-c4-candidate5/e2e/qualification/worker-turns.jsonl')
DB_SUFFIXES = ('.db', '.sqlite', '.sqlite3', '-wal', '-shm')


def sha(body):
    return hashlib.sha256(body).hexdigest()


def fingerprint(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def frozen(path):
    before = path.stat()
    value = fingerprint(path)
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), path
    return value


def helpers():
    path = OUT / 'release-evidence-used.py.txt'
    assert frozen(path)['sha256'] == HELPER
    return runpy.run_path(str(path), run_name='closed_candidate5_observer_supplement')


def selected():
    attachments = sorted(ASSETS.rglob('descriptor-worker-observation-*.json'))
    assert len(attachments) == 8
    directories = []
    for attachment in attachments:
        report = json.loads(attachment.read_bytes())
        directory = Path(report['work_order']['observed_records']).parent
        assert directory.parent == ROOT / '.issue-11-evidence/issue159-performance'
        assert directory.is_dir() and not directory.is_symlink() and directory not in directories
        assert report['work_order']['trace'] == str(TRACE)
        directories.append(directory)
    rows = {f'observers/{directory.name}': {'root': directory, 'paths': [directory], 'scope': 'whole closed original observer root'} for directory in sorted(directories)}
    rows['native-bindings'] = {'root': ASSETS, 'paths': attachments, 'scope': 'exact eight native descriptor observer attachments'}
    rows['qualification-bindings'] = {'root': ROOT, 'paths': [TRANSPORT / 'primary-terminal-readback.json', CAPTURE / 'source-capture-seal.json', CAPTURE / 'captured-source-maps.json', RETAINED / 'handoff.json'], 'scope': 'exact historical candidate5 source/terminal/retained provenance files'}
    rows['trace-bindings'] = {'root': TRACE.parent, 'paths': [TRACE.with_suffix('.sources.json')], 'scope': 'exact existing trace source-map file; full trace already retained in candidate5 retained state'}
    return rows


def inventory(roots):
    files, directories, empty, aliases, special, root_rows = {}, {}, [], [], [], {}
    def visit(label, root, path):
        metadata = path.lstat()
        relative = path.relative_to(root).as_posix()
        key = label if relative == '.' else label + '/' + relative
        facts = {'mode': stat.S_IMODE(metadata.st_mode), 'mtime_ns': metadata.st_mtime_ns, 'uid': metadata.st_uid, 'gid': metadata.st_gid, 'nlink': metadata.st_nlink}
        if stat.S_ISLNK(metadata.st_mode):
            aliases.append({'path': key, 'original_path': str(path), 'target': os.readlink(path), 'active': False, 'metadata': facts})
        elif stat.S_ISDIR(metadata.st_mode):
            directories[key] = facts
            children = sorted(path.iterdir())
            if not children:
                empty.append(key)
            for child in children:
                visit(label, root, child)
        elif stat.S_ISREG(metadata.st_mode):
            assert path.name != 'PRODUCT_SPEC.md', path
            assert not label.startswith('observers/') or not path.name.lower().endswith(DB_SUFFIXES), ('Unexpected observer DB/WAL/SHM; stop before any SQL', path)
            files[key] = {'original_path': str(path), **frozen(path), 'metadata': facts}
        else:
            special.append({'path': key, 'original_path': str(path), 'active': False, 'opened': False, 'metadata': facts})
    for label, row in roots.items():
        root = row['root']
        assert root.is_dir() and not root.is_symlink()
        for path in row['paths']:
            visit(label, root, path)
        these = [v for k, v in files.items() if k.startswith(label + '/')]
        root_rows[label] = {'original_root': str(root), 'selected_paths': [str(p) for p in row['paths']], 'scope': row['scope'], 'regular_files': len(these), 'bytes': sum(v['bytes'] for v in these)}
    return {'roots': root_rows, 'files': files, 'directories': directories, 'empty_directories': sorted(empty), 'inert_aliases': sorted(aliases, key=lambda v: v['path']), 'inert_nonregular_descriptors': sorted(special, key=lambda v: v['path']), 'missing_roots': [], 'body_exclusions': []}


def verify_trace(report, observed, trace, trace_sources, captured_current):
    order = report['work_order']
    assert report['complete'] is True and report['sources_unchanged'] is True and order['complete'] is True
    assert report['sources_before'] == report['sources_after'] == trace_sources
    assert all(captured_current[name] == value for name, value in trace_sources.items())
    header_body = trace[:trace.index(b'\n') + 1]
    header = json.loads(header_body)
    assert order['header'] == header and header['source_count'] == len(trace_sources)
    assert header['source_digest'] == sha(json.dumps(trace_sources, sort_keys=True, separators=(',', ':')).encode())
    assert len(observed) == order['observed_bytes'] and sha(observed) == order['observed_sha256']
    assert observed.startswith(header_body)
    body = observed[len(header_body):]
    offset = order['source_start_offset']
    assert trace[offset:offset + len(body)] == body and trace[offset - 1:offset] == b'\n'
    previous = json.loads(trace[trace.rfind(b'\n', 0, offset - 1) + 1:offset - 1])
    assert previous['record'] == order['start_record']
    records = body.splitlines()
    assert len(records) == order['records'] == order['last_record'] - order['start_record']
    for number, line in enumerate(records, order['start_record'] + 1):
        assert json.loads(line)['record'] == number
    return {'records': len(records), 'start_record': order['start_record'], 'last_record': order['last_record'], 'source_start_offset': offset, 'body_bytes': len(body), 'all_observed_records_equal_exact_original_trace_slice': True}
