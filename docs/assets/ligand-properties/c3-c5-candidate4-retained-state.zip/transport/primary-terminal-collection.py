"""Read the original terminal gate; preserve raw stores without SQL or signals."""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import runpy
import shutil
import socket
import subprocess
import time

OUT = Path(__file__).absolute().parent
ROOT = OUT.parents[1]
ASSETS = ROOT / 'docs/assets/ligand-properties'

def sha(body):
    return hashlib.sha256(body).hexdigest()

def write(name, value):
    path = OUT / name
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + '\n')
    return {'path': str(path), 'sha256': sha(path.read_bytes())}

def kernel(pid):
    text = (Path('/proc') / str(pid) / 'stat').read_text()
    parts = text[text.rindex(')') + 2:].split()
    return {'pid': pid, 'state': parts[0], 'start_token': parts[19]}

status = json.loads((OUT / 'transport-status.json').read_bytes())
pins = json.loads((OUT / 'pins.json').read_bytes())
assert status['terminal'] and status['state'] == 'TERMINAL'
assert status['identity_complete'] is True
assert isinstance(status['actual_runner_returncode'], int)
assert pins['label'] == 'c5-candidate4'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == pins['head']
recipe = json.loads((ASSETS / 'c5-candidate4-recipe.json').read_bytes())
assert sha((ASSETS / 'c5-candidate4-recipe.json').read_bytes()) == pins['recipe_sha256']
workspace = Path('/tmp/neistra159-c5-candidate4')
assert workspace.is_dir() and not workspace.is_symlink()

known = {}
for key in ('supervisor', 'runner_identity'):
    item = status[key]
    known[(item['pid'], item['start_token'])] = item
for line in (OUT / 'primary-live-observations.jsonl').read_text().splitlines():
    row = json.loads(line)
    for item in row.get('owned_descendants', []):
        if item.get('start_token'):
            known[(item['pid'], item['start_token'])] = item
remaining, handle_checks = [], []
for (pid, token), expected in sorted(known.items()):
    try:
        actual = kernel(pid)
    except FileNotFoundError:
        handle_checks.append({'pid': pid, 'start_token': token, 'observation': 'missing'})
        continue
    handle_checks.append({'pid': pid, 'expected_start_token': token, 'actual': actual})
    if actual['start_token'] == token and actual['state'] != 'Z':
        remaining.append(actual)
markers = []
needle = str(workspace).encode()
for path in Path('/proc').iterdir():
    if not path.name.isdigit():
        continue
    try:
        before = kernel(int(path.name))
        command = (path / 'cmdline').read_bytes()
        after = kernel(int(path.name))
    except (FileNotFoundError, ProcessLookupError):
        continue
    if needle in command and before['start_token'] == after['start_token'] and after['state'] != 'Z':
        markers.append({**after, 'command': command.decode(errors='replace')})
ports = {}
for key in ('NEISTRA_E2E_API_PORT', 'NEISTRA_E2E_WORKER_PORT', 'NEISTRA_E2E_WEB_PORT'):
    port = int(recipe['environment'][key])
    with socket.socket() as probe:
        probe.settimeout(1)
        ports[str(port)] = probe.connect_ex(('127.0.0.1', port)) != 0
assert not remaining, remaining
assert not markers, markers
assert all(ports.values()), ports
cleanup_ns = time.monotonic_ns()
cleanup = {'complete': True, 'recorded_utc': datetime.now(timezone.utc).isoformat(),
           'monotonic_ns': cleanup_ns, 'known_PID_start_handles_checked': len(known),
           'positively_owned_processes_remaining': remaining,
           'live_exact_workspace_data_markers': markers, 'ports_unused': ports,
           'actual_original_runner_wait_exit': status['actual_runner_returncode'],
           'signals_sent': False, 'SQL_opened': False, 'handle_checks': handle_checks}
cleanup_ref = write('cleanup-before-raw-copy.json', cleanup)

started_ns = time.monotonic_ns()
destination = OUT / 'post-cleanup-raw-database-bytes'
assert not destination.exists()
files, absent = {}, []
databases = []
for source in sorted(workspace.rglob('*')):
    assert not source.is_symlink(), source
    if not source.is_file():
        continue
    if not (source.name.endswith(('.db', '.sqlite', '.sqlite3', '.db-wal', '.db-shm', '.sqlite-wal', '.sqlite-shm', '.sqlite3-wal', '.sqlite3-shm'))):
        continue
    relative = source.relative_to(workspace)
    body = source.read_bytes()
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert target.read_bytes() == body == source.read_bytes(), source
    files[str(relative)] = {'bytes': len(body), 'sha256': sha(body), 'original': str(source), 'copy': str(target)}
    if source.name.endswith(('.db', '.sqlite', '.sqlite3')):
        databases.append(source)
assert files
for database in databases:
    for suffix in ('-wal', '-shm'):
        sidecar = Path(str(database) + suffix)
        if not sidecar.exists():
            absent.append(str(sidecar.relative_to(workspace)))
raw = {'scope': 'Every existing DB/SQLite/WAL/SHM under the retained original recipe workspace; no disposable deleted fixture store is claimed.',
       'workspace': str(workspace), 'cleanup_monotonic_ns': cleanup_ns,
       'started_monotonic_ns': started_ns, 'cleanup_before_copy': cleanup_ns < started_ns,
       'files': files, 'absent_sidecars': absent, 'SQL_opened': False,
       'originals_retained': True, 'finished_utc': datetime.now(timezone.utc).isoformat()}
raw_ref = write('raw-database-copy.json', raw)

gate = json.loads((ASSETS / 'c5-candidate4-gate.json').read_bytes())
module = runpy.run_path(str(ASSETS / 'qualification.py.txt'))
current = module['current_identities'](ROOT)
assert current == pins['selected_sources'] == gate['source_before'] == gate['source_after']
old = module['tagged_identities'](gate['preceding_reader']['tag'])
assert old == gate['preceding_source_expected'] == gate['preceding_source_before'] == gate['preceding_source_after']
assert module['extracted_identities'](Path(gate['preceding_reader']['root']), old) == old
logs = {}
for step in gate['steps']:
    body = gzip.decompress((ROOT / step['log']).read_bytes())
    assert sha(body) == step['log_sha256']
    logs[step['label']] = {'bytes': len(body), 'sha256': sha(body), 'exit_code': step['exit_code']}
browser_path = ASSETS / 'c5-candidate4-browser.json'
browser = json.loads(browser_path.read_bytes()) if browser_path.exists() else {}
if status['actual_runner_returncode'] == 0:
    assert gate['complete'] and len(gate['steps']) == len(recipe['steps']) == 43
    assert browser and not browser.get('errors')
    for actual, expected in zip(gate['steps'], recipe['steps'], strict=True):
        assert actual['exit_code'] == 0
        for key in ('label', 'command', 'environment', 'cwd'):
            assert actual.get(key) == expected.get(key)
receipt = {'scope': 'Primary terminal source/log/positive cleanup/raw-store readback only; full qualification evaluation remains separate.',
           'recorded_utc': datetime.now(timezone.utc).isoformat(), 'candidate': pins['head'],
           'actual_runner_wait_exit': status['actual_runner_returncode'], 'original_transport_identity_complete': status['identity_complete'],
           'recorded_steps': len(gate['steps']), 'remaining_unrun_steps': len(recipe['steps']) - len(gate['steps']),
           'all_lossless_gzip_log_bodies_verified': logs, 'source_count': len(current),
           'source_before_after_current_exact': True,
           'source_digest_compact': sha(json.dumps(current, sort_keys=True, separators=(',', ':')).encode()),
           'actual_tagged_preceding_source_count': len(old), 'old_before_after_current_tagged_exact': True,
           'positive_cleanup_receipt': cleanup_ref, 'raw_copy_receipt': raw_ref,
           'raw_existing_DB_WAL_SHM_originals_and_copies_exact': True, 'SQL_opened': False,
           'gate_complete': gate['complete'], 'browser_report_present': bool(browser),
           'browser_stats': browser.get('stats'), 'browser_top_level_errors': browser.get('errors', []),
           'source_freeze_released_only_after_this_proof': True}
terminal_ref = write('primary-terminal-readback.json', receipt)
print(json.dumps({'terminal_readback': terminal_ref, 'raw_files': len(files), 'source_files': len(current), 'original_exit': status['actual_runner_returncode'], 'stats': browser.get('stats')}))
