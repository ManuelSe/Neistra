"""One-shot detached transport for an unchanged, explicitly pinned public gate.

This private adapter never qualifies a release, modifies a recipe, retries a gate,
or cleans up application descendants. Launcher success means acceptance only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback
import uuid

ASSETS = "docs/assets/ligand-properties"
QUALIFICATION = ASSETS + "/qualification.py.txt"
PREFIXES = ("apps/", "packages/", "tests/", "tools/", "scripts/", "patches/")
CONFIGS = {"pyproject.toml", "uv.lock", "package.json", "pnpm-lock.yaml",
           "pnpm-workspace.yaml", "playwright.config.ts", "alembic.ini",
           ".gitattributes", ".gitignore"}
TOOLS = {directory + name for directory in (
    "docs/assets/viewer-information/", "docs/assets/viewer-measurements/",
    "docs/assets/ligand-designation/", ASSETS + "/") for name in (
    "qualification.py.txt", "release-recipe.py.txt", "versions.py.txt",
    "production-audit.py.txt", "qualification-summary.py.txt", "release-evidence.py.txt")}
IDENTITY_KEYS = ("pid", "start_token", "pgid", "session", "command")


def sha(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def stamp() -> dict:
    return {"epoch_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns()}


def read(path: Path) -> dict:
    assert path.is_file() and not path.is_symlink(), path
    value = json.loads(path.read_bytes())
    assert isinstance(value, dict)
    return value


def check_hash(path: Path, expected: str) -> None:
    assert path.is_file() and not path.is_symlink(), path
    assert sha(path.read_bytes()) == expected, f"Changed pinned body: {path}"


def save(out: Path, name: str, value: dict, *, exclusive: bool = False) -> None:
    path = out / name
    body = json.dumps(value, indent=2, allow_nan=False) + "\n"
    if exclusive:
        with path.open("x") as stream:
            stream.write(body)
    else:
        temporary = out / (name + ".next")
        with temporary.open("x") as stream:
            stream.write(body)
        temporary.replace(path)


def identity(pid: int, command: list[str] | None = None) -> dict:
    base = Path("/proc") / str(pid)
    first = (base / "stat").read_text()
    before = first[first.rindex(")") + 2:].split()
    argv = [p.decode() for p in (base / "cmdline").read_bytes().split(b"\0") if p]
    last = (base / "stat").read_text()
    after = last[last.rindex(")") + 2:].split()
    assert before[19] == after[19] and after[0] != "Z", "Process disappeared/reused/zombie"
    assert command is None or argv == command, "Unexpected command"
    return {"pid": pid, "start_token": after[19], "pgid": int(after[2]),
            "session": int(after[3]), "state": after[0], "command": argv}


def observe_identity(process, command: list[str], *, parent_pid: int, pgid: int,
                     session: int, observations: list[dict], timeout: float = 3) -> dict:
    """Observe one existing Popen PID; never spawn, signal, restart or infer an exit."""
    assert 0 < timeout <= 3, "Identity observation is bounded by the registration budget"
    pid = process.pid
    deadline = time.monotonic() + timeout
    token = None
    observations.append({"event": "start", "at": stamp(), "pid": pid,
                         "expected": {"parent_pid": parent_pid, "pgid": pgid,
                                      "session": session, "command": command},
                         "timeout_seconds": timeout, "maximum_attempts": 300})
    for attempt in range(300):
        code = process.poll()
        if code is not None:
            observations.append({"event": "terminated", "at": stamp(), "pid": pid,
                                 "actual_returncode": code})
            raise AssertionError("Owned child terminated before identity was established")
        if time.monotonic() >= deadline:
            break
        try:
            raw = (Path("/proc") / str(pid) / "stat").read_text()
            fields = raw[raw.rindex(")") + 2:].split()
            kernel = {"start_token": fields[19], "ppid": int(fields[1]),
                      "pgid": int(fields[2]), "session": int(fields[3])}
        except (OSError, ValueError, IndexError) as error:
            observations.append({"event": "stat-unavailable", "at": stamp(),
                                 "pid": pid, "error": repr(error)})
        else:
            if token is None:
                token = kernel["start_token"]
            if kernel["start_token"] != token:
                observations.append({"event": "replacement", "at": stamp(), "pid": pid,
                                     "pinned_start_token": token, "observed": kernel})
                raise AssertionError("Owned PID start token changed; stop observing replacement")
            if kernel["ppid"] != parent_pid:
                observations.append({"event": "wrong-parent", "at": stamp(), "pid": pid,
                                     "pinned_start_token": token, "observed": kernel})
                raise AssertionError("Owned PID no longer has the expected parent")
            try:
                actual = identity(pid)  # Keep mismatching argv in the observation.
            except (OSError, AssertionError, ValueError) as error:
                observations.append({"event": "identity-unavailable", "at": stamp(),
                                     "pid": pid, "kernel": kernel, "error": repr(error)})
            else:
                observations.append({"event": "observed", "at": stamp(),
                                     "pid": pid, "kernel": kernel, "actual": actual})
                if actual["start_token"] != token:
                    raise AssertionError("Owned PID changed while reading its identity")
                if (actual["command"] == command and actual["pgid"] == kernel["pgid"] == pgid
                        and actual["session"] == kernel["session"] == session
                        and time.monotonic() <= deadline):
                    return {**actual, "ppid": kernel["ppid"]}
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        time.sleep(min(.01, remaining))
    observations.append({"event": "unresolved", "at": stamp(), "pid": pid,
                         "pinned_start_token": token, "actual_returncode": process.poll()})
    raise AssertionError("Owned child identity unresolved within bounded observation")


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


def selected(path: str) -> bool:
    return path.startswith(PREFIXES) or path in CONFIGS or path in TOOLS


def source_map(root: Path) -> dict:
    names = git(root, "ls-files", "--cached", "--others", "--exclude-standard").splitlines()
    result = {}
    for name in sorted(set(names)):
        if selected(name):
            path = root / name
            assert not path.is_symlink(), path
            if path.is_file():
                result[name] = sha(path.read_bytes())
    return result


def validate(pins_path: Path) -> tuple[dict, dict, list[str]]:
    assert sys.flags.optimize == 0, "Assertions require unoptimized Python"
    assert pins_path.is_absolute() and pins_path.resolve() == pins_path
    pins = read(pins_path)
    assert pins["authorized"] is True
    check_hash(Path(__file__), pins["transport_sha256"])
    root = Path(pins["root"])
    assert root.is_absolute() and root.resolve() == root
    assert git(root, "rev-parse", "HEAD") == pins["head"]
    assert not git(root, "status", "--porcelain=v1"), "Clean committed candidate required"
    assert source_map(root) == pins["selected_sources"], "Current selected source drift"
    label = pins["label"]
    assert re.fullmatch(r"[a-z0-9-]+", label)
    recipe_path = root / ASSETS / f"{label}-recipe.json"
    check_hash(recipe_path, pins["recipe_sha256"])
    check_hash(root / QUALIFICATION, pins["qualification_sha256"])
    recipe = read(recipe_path)
    assert recipe["label"] == label and recipe["require_clean"] is True
    assert len(recipe["steps"]) == 43
    assert recipe["application_version"] == pins["application_version"]
    assert recipe["preceding_reader"] == pins["preceding_reader"]
    old = Path(pins["preceding_reader"]["root"])
    assert old.is_absolute() and old.resolve() == old and old != root
    tag = pins["preceding_reader"]["tag"]
    assert git(root, "cat-file", "-t", tag) == "tag"
    assert git(root, "rev-parse", f"{tag}^{{}}") == pins["preceding_reader"]["commit"]
    for name, expected in pins["preceding_sources"].items():
        assert selected(name) and not Path(name).is_absolute() and ".." not in Path(name).parts
        check_hash(old / name, expected)
    # Do not resolve this executable: resolving the venv symlink loses venv identity.
    python = str(root / ".venv/bin/python")
    assert pins["python"] == python and Path(python).is_file()
    command = [python, "-B", str(root / QUALIFICATION), str(recipe_path)]
    assert pins["command"] == command
    expected_modules = ":".join(str(root / p) for p in (
        "apps/api/src", "packages/neistra_core/src", "packages/neistra_demo_plugin/src", "."))
    assert recipe["environment"]["PYTHONPATH"] == expected_modules
    assert recipe["compatibility_protocol"] == "private-derived-shared-schema-v1"
    return pins, recipe, command


def fresh(root: Path, recipe: dict) -> None:
    label = recipe["label"]
    outputs = [p.name for p in (root / ASSETS).iterdir()
               if p.name.startswith(label + "-") and p.name != f"{label}-recipe.json"]
    assert not outputs, f"Preserve earlier attempts: {outputs}"
    workspace = Path("/tmp") / f"neistra159-{label}"
    assert workspace.is_dir() and not workspace.is_symlink() and not any(workspace.iterdir())
    for step in recipe["steps"]:
        if "cwd" in step:
            assert step["cwd"] in (str(root), recipe["preceding_reader"]["root"])


def registered(out: Path, reservation: str, own: dict, timeout: float = 3) -> None:
    deadline = time.monotonic() + timeout
    while True:
        try:
            launch = read(out / "transport-launch.json")
            break
        except (FileNotFoundError, AssertionError, json.JSONDecodeError):
            if time.monotonic() >= deadline:
                raise RuntimeError("No complete launcher registration; no gate launched") from None
            time.sleep(.01)
    assert launch["accepted"] is True and launch["reservation_id"] == reservation
    assert all(launch["supervisor_identity"][key] == own[key] for key in IDENTITY_KEYS)


def wait_child(out: Path, command: list[str], root: Path, state: dict) -> int:
    process = None
    try:
        environment = {k: v for k, v in os.environ.items() if k != "PYTHONOPTIMIZE"}
        with (out / "runner-output.log").open("xb") as log:
            process = subprocess.Popen(command, cwd=root, env=environment,
                                       stdin=subprocess.DEVNULL, stdout=log,
                                       stderr=subprocess.STDOUT, close_fds=True)
            state.update(state="RUNNING", runner_pid=process.pid)
            state["runner_identity_observations"] = []
            try:
                state["runner_identity"] = observe_identity(
                    process, command, parent_pid=os.getpid(), pgid=os.getpgrp(),
                    session=os.getsid(0), observations=state["runner_identity_observations"])
                state["identity_complete"] = True
            except (OSError, AssertionError) as error:
                state["identity_error"] = repr(error)
            save(out, "transport-status.json", state)
            code = process.wait()
        state.update(state="TERMINAL" if state["identity_complete"] else "ERROR",
                     terminal=True, actual_runner_returncode=code, finished=stamp())
        save(out, "transport-status.json", state)
        return (code if code >= 0 else 128 - code) if state["identity_complete"] else 1
    except Exception:
        state.update(state="ERROR", error=traceback.format_exc(), finished=stamp())
        if process is not None:
            state["actual_runner_returncode"] = process.poll()
            state["terminal"] = state["actual_runner_returncode"] is not None
        save(out, "transport-status.json", state)
        raise


def launch(pins_path: Path) -> int:
    pins, recipe, command = validate(pins_path)
    root, out = Path(pins["root"]), pins_path.parent
    fresh(root, recipe)
    reservation = uuid.uuid4().hex
    supervisor = [pins["python"], "-B", str(Path(__file__).resolve()),
                  "--pins", str(pins_path), "supervise", reservation]
    save(out, "transport-reservation.json", {
        "scope": "One-shot reservation; never delete or restart",
        "reservation_id": reservation, "created": stamp(), "launcher": identity(os.getpid()),
        "pins_sha256": sha(pins_path.read_bytes()), "supervisor_command": supervisor,
        "runner_command": command}, exclusive=True)
    result = {"scope": "Acceptance only; not a gate result", "reservation_id": reservation,
              "accepted": False, "started": stamp()}
    try:
        environment = {k: v for k, v in os.environ.items() if k != "PYTHONOPTIMIZE"}
        with (out / "supervisor.log").open("xb") as log:
            process = subprocess.Popen(supervisor, cwd=root, env=environment,
                                       stdin=subprocess.DEVNULL, stdout=log,
                                       stderr=subprocess.STDOUT, close_fds=True,
                                       start_new_session=True)
        result.update(accepted=True, supervisor_pid=process.pid)
        result["supervisor_identity_observations"] = []
        try:
            result["supervisor_identity"] = observe_identity(
                process, supervisor, parent_pid=os.getpid(), pgid=process.pid,
                session=process.pid, observations=result["supervisor_identity_observations"])
        except (OSError, AssertionError) as error:
            result["identity_error"] = repr(error)
    except Exception:
        result["launch_error"] = traceback.format_exc()
        save(out, "transport-launch.json", {**result, "finished": stamp()}, exclusive=True)
        raise
    save(out, "transport-launch.json", {**result, "finished": stamp()}, exclusive=True)
    print(json.dumps(result), flush=True)
    return 0


def supervise(pins_path: Path, reservation_id: str) -> int:
    out = pins_path.parent
    reservation = read(out / "transport-reservation.json")
    assert reservation["reservation_id"] == reservation_id
    check_hash(pins_path, reservation["pins_sha256"])
    own = identity(os.getpid(), reservation["supervisor_command"])
    assert own["pid"] == own["pgid"] == own["session"]
    save(out, "transport-child-reservation.json", {
        "reservation_id": reservation_id, "supervisor": own, "created": stamp()}, exclusive=True)
    state = {"scope": "Actual public runner wait; not workflow/cleanup qualification",
             "reservation_id": reservation_id, "supervisor": own, "state": "REGISTERING",
             "started": stamp(), "terminal": False, "actual_runner_returncode": None,
             "identity_complete": False}
    save(out, "transport-status.json", state)
    try:
        registered(out, reservation_id, own)
        pins, recipe, command = validate(pins_path)
        assert command == reservation["runner_command"]
        root = Path(pins["root"])
        fresh(root, recipe)
    except Exception:
        state.update(state="ERROR", error=traceback.format_exc(), finished=stamp())
        save(out, "transport-status.json", state)
        raise
    return wait_child(out, command, root, state)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pins", required=True, type=Path)
    parser.add_argument("mode", choices=("launch", "supervise"))
    parser.add_argument("reservation_id", nargs="?")
    args = parser.parse_args()
    if args.mode == "launch":
        assert args.reservation_id is None
        raise SystemExit(launch(args.pins))
    assert args.reservation_id is not None
    raise SystemExit(supervise(args.pins, args.reservation_id))


if __name__ == "__main__":
    main()
