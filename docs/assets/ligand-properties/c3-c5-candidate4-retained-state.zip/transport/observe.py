"""Read one original gate's owned process handles; append observations only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

OUT = Path(__file__).absolute().parent
ROOT = OUT.parents[1]


def kernel(pid):
    raw = (Path('/proc') / str(pid) / 'stat').read_text()
    fields = raw[raw.rindex(')') + 2:].split()
    return {'pid': pid, 'state': fields[0], 'ppid': int(fields[1]),
            'pgid': int(fields[2]), 'session': int(fields[3]), 'start_token': fields[19]}


def positive(expected):
    try:
        before = kernel(expected['pid'])
        command = [part.decode() for part in
                   (Path('/proc') / str(expected['pid']) / 'cmdline').read_bytes().split(b'\0') if part]
        after = kernel(expected['pid'])
        assert before['start_token'] == after['start_token'] == expected['start_token']
        assert after['state'] != 'Z'
        assert command == expected['command']
        assert after['pgid'] == expected['pgid'] and after['session'] == expected['session']
        return {**after, 'command': command, 'live': True}
    except (OSError, AssertionError, UnicodeError, ValueError, IndexError) as error:
        return {'pid': expected['pid'], 'start_token': expected['start_token'],
                'live': False, 'observation_error': repr(error)}


pins = json.loads((OUT / 'pins.json').read_bytes())
status = json.loads((OUT / 'transport-status.json').read_bytes())
reservation = json.loads((OUT / 'transport-reservation.json').read_bytes())
assert status['reservation_id'] == reservation['reservation_id']
assert hashlib.sha256((OUT / 'pins.json').read_bytes()).hexdigest() == reservation['pins_sha256']
assert status['runner_identity']['command'] == pins['command']
assert status['supervisor']['command'] == reservation['supervisor_command']
assert status['identity_complete'] is True
owned = {role: positive(status[role]) for role in ('supervisor', 'runner_identity')}
if owned['runner_identity']['live']:
    assert owned['runner_identity']['ppid'] == status['supervisor']['pid']
snapshot = {}
for path in Path('/proc').iterdir():
    if path.name.isdigit():
        try:
            item = kernel(int(path.name))
            snapshot[item['pid']] = item
        except (OSError, ValueError, IndexError):
            continue
selected = {item['pid'] for item in owned.values() if item['live']}
while True:
    expanded = selected | {pid for pid, item in snapshot.items() if item['ppid'] in selected}
    if expanded == selected:
        break
    selected = expanded
descendants = []
for pid in sorted(selected - {status['supervisor']['pid'], status['runner_identity']['pid']}):
    try:
        item = snapshot[pid]
        command = [part.decode() for part in (Path('/proc') / str(pid) / 'cmdline').read_bytes().split(b'\0') if part]
        after = kernel(pid)
        assert after['start_token'] == item['start_token'] and after['state'] != 'Z'
        descendants.append({**after, 'command': command, 'observed_as_descendant': True})
    except (OSError, AssertionError, UnicodeError, ValueError, IndexError) as error:
        descendants.append({'pid': pid, 'start_token': snapshot[pid]['start_token'],
                            'observation_error': repr(error)})
gatepath = ROOT / 'docs/assets/ligand-properties' / (pins['label'] + '-gate.json')
gate_error = None
try:
    gate = json.loads(gatepath.read_bytes()) if gatepath.exists() else {}
except (OSError, json.JSONDecodeError) as error:
    gate, gate_error = {}, repr(error)
row = {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'state': status['state'],
       'terminal': status['terminal'], 'actual_runner_returncode': status['actual_runner_returncode'],
       'transport_identity_complete': status['identity_complete'],
       'positive_same_process_identities': owned, 'owned_descendants': descendants,
       'gate_complete': gate.get('complete'), 'completed_steps': len(gate.get('steps', [])),
       'gate_observation_error': gate_error,
       'last_step': gate.get('steps', [])[-1]['label'] if gate.get('steps') else None}
with (OUT / 'primary-live-observations.jsonl').open('a') as stream:
    stream.write(json.dumps(row, allow_nan=False) + '\n')
print(json.dumps({key: row[key] for key in row if key not in ('owned_descendants',)}, allow_nan=False))
print(json.dumps({'owned_descendant_count': len(descendants),
                  'owned_descendant_PIDs': [item['pid'] for item in descendants]}))
