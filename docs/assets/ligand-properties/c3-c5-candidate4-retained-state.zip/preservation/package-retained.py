"""Success-only complete closed candidate retention, including original observer UUIDs."""
from pathlib import Path
from datetime import datetime, timezone
import json
import shutil
from support import ROOT, OUT, ASSETS, TRANSPORT, WORKSPACE, PUBLIC_NAMES, H, DB_SUFFIXES, frozen, inventory, helper, read, select_roots, verify_mirror, verify_raw_bindings, write
from barriers import require_terminal


evidence = require_terminal()
source_root = OUT / 'candidate-source-capture1'
source_seal = read(source_root / 'source-capture-seal.json')
source_manifest = read(source_root / 'source-capsule-manifest.json')
assert source_seal['candidate'] == source_manifest['candidate'] == H and source_seal['source_capture_complete']
for name, row in source_manifest['files'].items():
    assert frozen(source_root / name) == row
source_maps = read(source_root / 'captured-source-maps.json')
assert source_maps['current'] == evidence['pins']['selected_sources'] and source_maps['actual036'] == evidence['pins']['preceding_sources']
assert source_seal['captures']['current']['source_count'] == len(source_maps['current'])
assert source_seal['captures']['actual036']['source_count'] == len(source_maps['actual036'])
target = OUT / 'candidate-retained-state1'
assert not target.exists(), target
raw = evidence['raw']
raw_count = verify_raw_bindings(raw)
roots = select_roots()
before = inventory(roots)
actual_databases = {name[len('workspace/'):] for name in before['files'] if name.startswith('workspace/') and name.lower().endswith(DB_SUFFIXES)}
assert actual_databases == set(raw['files'])
trace_path = WORKSPACE / 'e2e/qualification/worker-turns.jsonl'
trace = trace_path.read_bytes()
trace_sources_path = trace_path.with_suffix('.sources.json')
trace_sources = read(trace_sources_path)
assert trace_sources == evidence['reference']['native12']['observer_source_map']
observer_bindings = []
for attachment in roots['observer-attachments']['paths']:
    report = read(attachment)
    observed_path = Path(report['work_order']['observed_records'])
    directory = observed_path.parent
    matches = [name for name, row in roots.items() if name.startswith('observer-') and name != 'observer-attachments' and row['root'] == directory]
    assert len(matches) == 1
    label = matches[0]
    original_report = directory / 'worker-observation.json'
    assert original_report.read_bytes() == attachment.read_bytes()
    checks = verify_mirror(report, observed_path.read_bytes(), trace, trace_sources, source_maps['current'])
    observer_bindings.append({'original_root': str(directory), 'inventory_label': label,
                              'native_attachment': str(attachment), 'native_member': 'observer-attachments/' + attachment.relative_to(roots['observer-attachments']['root']).as_posix(),
                              'original_report_member': label + '/worker-observation.json',
                              'original_records_member': label + '/' + observed_path.name,
                              'report_bytes': frozen(attachment), 'observed_records_bytes': frozen(observed_path),
                              'original_regular_files': before['roots'][label]['regular_files'], 'trace_checks': checks})
assert len(observer_bindings) == len({row['original_root'] for row in observer_bindings}) == 8
bindings = {name: {'path': str(ASSETS / name), **frozen(ASSETS / name)} for name in PUBLIC_NAMES}
target.mkdir()
write(target / 'input-inventory.json', before)
provenance = {'candidate': H, 'primary_terminal_proof': evidence['proof_binding'],
              'positive_cleanup': {'path': str(TRANSPORT / 'cleanup-before-raw-copy.json'), **frozen(TRANSPORT / 'cleanup-before-raw-copy.json')},
              'preSQL_raw_copy_receipt': {'path': str(TRANSPORT / 'raw-database-copy.json'), **frozen(TRANSPORT / 'raw-database-copy.json')},
              'raw_original_copy_pairs_verified': raw_count, 'raw_original_copy_bindings': raw['files'],
              'closed_public_bindings': bindings, 'official_gate_parts_not_duplicated': evidence['package']['archives'],
              'official_exact_disjoint_union_members': evidence['official_exact_disjoint_union_members'],
              'qualifying_source_capsule_not_duplicated': {'directory': str(source_root), 'source_capture_seal': frozen(source_root / 'source-capture-seal.json')},
              'all_original_observer_bindings': observer_bindings,
              'original_worker_trace': {'path': str(trace_path), **frozen(trace_path)},
              'original_worker_trace_source_map': {'path': str(trace_sources_path), **frozen(trace_sources_path)},
              'method_count': len(evidence['reference']['native12']['method_map']),
              'native12_original_candidate': evidence['reference']['native12']['original_candidate'],
              'source_model': evidence['reference']['source_model'],
              'SQL_opened': False, 'raw_originals_retained': True}
write(target / 'provenance.json', provenance)
metadata_members = ['input-inventory.json', 'provenance.json', 'context.json', 'input-seal.json', 'package-retained.py', 'support.py', 'verify-retained.py', 'release-evidence-used.py.txt', 'barriers.py', 'preparation-input-bindings.json']
context = {'scope': 'Complete closed c5-candidate4 workspace/transport/original-observer retention only; no merged-master/release approval.',
           'candidate': H, 'candidate_gate_PASS': True, 'gate_command_exits_zero': 43,
           'summary': evidence['summary'], 'source_count': len(source_maps['current']), 'preceding_source_count': len(source_maps['actual036']),
           'method_count': len(evidence['reference']['native12']['method_map']),
           'current_and_native12_source_maps_distinct_with_exact_two_declared_test_deltas': True,
           'raw_original_copy_pairs': raw_count, 'original_observer_roots': len(observer_bindings),
           'original_observer_regular_files': sum(row['original_regular_files'] for row in observer_bindings),
           'body_exclusions': [], 'directory_and_alias_policy': 'Every regular byte and complete inert directory/empty/alias/structural metadata retained; no target or structural file opened.',
           'source_capsules_official_gate_parts_native12_packet_and_raw_forensics_not_duplicated': True,
           'separate_forensic_asset_count_from_frozen_metadata': evidence['reference']['publication_context']['actual_separate_forensic_count'],
           'future_main_supplemental_name': 'qualified-c5-candidate4-retained-state.zip',
           'artifact_role': 'qualified-main-supplement', 'separate_failed_forensic_asset': False,
           'native12_historical_identity_kept_distinct': True, 'new_timing_or_speedup_claim': False,
           'final_all7_merge_master_release_complete': False, 'publication_pending': True,
           'SQL_opened': False, 'runtime_or_process_actions': False, 'metadata_members': metadata_members}
write(target / 'context.json', context)
for name in metadata_members[4:]:
    shutil.copy2(OUT / name, target / name)
seal = {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'candidate': H,
        'original_closed_input_inventory': frozen(target / 'input-inventory.json'), 'provenance': frozen(target / 'provenance.json'), 'context': frozen(target / 'context.json'),
        'closed_public_binding_hashes': bindings, 'included_original_files': len(before['files']),
        'included_original_bytes': sum(row['bytes'] for row in before['files'].values()),
        'raw_original_copy_pairs_verified': raw_count, 'inputs_sealed_originals_must_remain_closed': True}
write(target / 'input-seal.json', seal)
items = {name: Path(row['original_path']) for name, row in before['files'].items()}
for name in metadata_members:
    items['preservation/' + name] = target / name
packet = helper()['archive'](items, target / 'qualified-c5-candidate4-retained-state.zip')
assert select_roots() == roots
after = inventory(roots)
write(target / 'originals-after.json', after)
assert before == after, 'Closed original union, bytes or metadata changed'
assert verify_raw_bindings(raw) == raw_count
verification = {'scope': context['scope'], 'candidate': H, 'archive': packet,
                'original_files': len(before['files']), 'original_bytes': sum(row['bytes'] for row in before['files'].values()),
                'original_observer_roots': len(observer_bindings), 'original_observer_regular_files': context['original_observer_regular_files'],
                'empty_directories': len(before['empty_directories']), 'inert_aliases': len(before['inert_aliases']), 'inert_nonregular_descriptors': len(before['inert_nonregular_descriptors']),
                'all_before_after_original_bytes_metadata_and_union_exact': True, 'raw_original_copy_pairs_verified_before_and_after': raw_count,
                'all_original_observer_source_and_trace_mirror_bindings': True, 'strict_fullbody_CRC_manifest_union_recursive_verification': 'PASS',
                'configured_single_asset_cap_bytes': 2 * 1024**3, 'within_configured_single_asset_cap': packet['bytes'] < 2 * 1024**3,
                'candidate_gate_PASS': True, 'final_all7_merge_master_release_complete': False, 'separate_failed_forensic_asset': False, 'SQL_opened': False}
assert verification['within_configured_single_asset_cap']
write(target / 'verification.json', verification)
with (target / 'qualified-c5-candidate4-retained-state.zip.sha256').open('x') as stream:
    stream.write(packet['sha256'] + '  qualified-c5-candidate4-retained-state.zip\n')
print(json.dumps(verification))
