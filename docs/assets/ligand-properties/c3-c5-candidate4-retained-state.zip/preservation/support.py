"""Private success-only post-gate retention helpers; no actions on import."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import stat

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).absolute().parent
ASSETS = ROOT / 'docs/assets/ligand-properties'
TRANSPORT = ROOT / '.issue-11-evidence/issue159-c5-candidate4-transport1'
WORKSPACE = Path('/tmp/neistra159-c5-candidate4')
LABEL = 'c5-candidate4'
H = 'b1cdb138c7becb5afa73b8f9bbf1e6d958ae8582'  # Actual qualifying checkpoint; gate success remains independently required.
HELPER = '34ef47ebd6fe9f12009600e099c8cd5599a851c4dc95ac5412b7eb12470173e3'
PUBLIC_NAMES = [LABEL + '-' + name + '.json' for name in ['recipe', 'gate', 'summary', 'reader-audit', 'packaging']]
DB_SUFFIXES = ('.db', '.sqlite', '.sqlite3', '-wal', '-shm')
DECLARED_SOURCE_DELTA = {'tests/e2e/rebranding-zoom.spec.ts': {'before': '5002451820458969f3da28ba6aceaa0a6cdb9753040e33745b632663f610c0bd', 'after': '75ed41b0e75e67cd92a3056311fc98785e0414ee6576aec0abe0e4bb24a19eb0'}, 'tests/unit/test_ligand_properties_release_recipe.py': {'before': 'fa019dffc96a972c56f18197728874eccfde426ea956f99bf2280757b25f783a', 'after': '9947c6b75171656d92578edc6a3dd624396d9520950daeef945558e657e2cce9'}}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def frozen(path):
    assert path.is_file() and not path.is_symlink(), path
    before = path.stat()
    value = fingerprint(path)
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), path
    return value


def helper():
    path = OUT / 'release-evidence-used.py.txt'
    assert frozen(path)['sha256'] == HELPER
    return runpy.run_path(str(path), run_name='postgate_candidate_retention')


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def verify_head_binding(primary, runtime, assessment, pins):
    """Bind typed before/after HEAD records to the original owned symbolic ref."""
    before = runtime['authoritative_HEAD_before']
    after = runtime['authoritative_HEAD_after']
    assert isinstance(before, dict) and isinstance(after, dict)
    assert before == after
    assert all(isinstance(before[key], str) for key in ('commit', 'ref', 'HEAD_text', 'scope'))
    candidate = primary['candidate']
    assert isinstance(candidate, str)
    assert candidate == runtime['binding']['HEAD'] == before['commit'] == assessment['candidate'] == pins['HEAD']
    ref = pins['ref']
    assert isinstance(ref, str) and ref.startswith('refs/heads/') and '..' not in Path(ref).parts
    assert before['ref'] == ref and before['HEAD_text'] == 'ref: ' + ref


def verify_source_model(reference):
    current = reference['gate']['selected_sources']
    native = reference['native12']['source_map']
    model = reference['source_model']
    assert set(current) == set(native)
    actual = {name: {'before': native[name], 'after': current[name]} for name in current if current[name] != native[name]}
    assert actual == model['declared_delta'] == DECLARED_SOURCE_DELTA
    assert len(current) == model['current_source_count'] == len(native) == model['native12_source_count']
    assert model['unchanged_source_count'] == len(current) - len(actual)
    assert sha(json.dumps(current, sort_keys=True, separators=(',', ':')).encode()) == model['current_source_digest_compact']
    assert sha(json.dumps(native, sort_keys=True, separators=(',', ':')).encode()) == model['native12_source_digest_compact']
    for key, count_key in [('method_map', 'method_count'), ('observer_source_map', 'observer_source_count')]:
        subjects = reference['native12'][key]
        assert len(subjects) == model[count_key] and not set(actual).intersection(subjects)
        assert all(current[name] == digest == native[name] for name, digest in subjects.items())


def load_reference():
    reference = read(OUT / 'preparation-input-bindings.json')
    assert reference.get('binding_status') == 'BOUND_ACTUAL_CANDIDATE', 'Static template is unbound; instantiate and reseal after actual commit/pins exist'
    assert isinstance(H, str) and len(H)==40 and all(c in '0123456789abcdef' for c in H)
    assert reference['gate']['pins_bytes'] is not None and reference['gate']['recipe_bytes'] is not None
    assert reference['publication_context']['forensic_index'] is not None
    assert reference['gate']['head'] == H and reference['gate']['label'] == LABEL and reference['gate']['root'] == str(ROOT)
    native = reference['native12']
    verify_head_binding(native['primary'], native['runtime'], native['assessment'], native['canonical_pins'])
    assert native['canonical_pins_bytes']['sha256'] == native['runtime']['binding']['canonical_root_pins_sha256']
    assert native['original_candidate'] == native['primary']['candidate']
    assert native['assessment']['workflow_passes'] == 8 and native['portable_only']
    assert not native['assessment']['final_feature_release_qualification']
    assert len(native['source_map']) == native['assessment']['source_count']
    assert len(native['method_map']) == native['assessment']['method_count']
    assert all(native['source_map'][name] == digest for name, digest in native['method_map'].items())
    assert all(native['source_map'][name] == digest for name, digest in native['observer_source_map'].items())
    verify_source_model(reference)
    return reference


def verify_raw_bindings(raw):
    assert raw['cleanup_before_copy'] is True and raw['SQL_opened'] is False and raw['originals_retained'] is True
    assert Path(raw['workspace']) == WORKSPACE and raw['files']
    for relative, row in raw['files'].items():
        expected = {key: row[key] for key in ('bytes', 'sha256')}
        assert Path(row['original']) == WORKSPACE / relative
        assert Path(row['copy']) == TRANSPORT / 'post-cleanup-raw-database-bytes' / relative
        assert frozen(Path(row['original'])) == frozen(Path(row['copy'])) == expected
    return len(raw['files'])


def select_roots():
    native = ASSETS / (LABEL + '-native')
    attachments = sorted(native.rglob('descriptor-worker-observation-*.json'))
    assert len(attachments) == 8
    observers = []
    for attachment in attachments:
        report = read(attachment)
        order = report['work_order']
        directory = Path(order['observed_records']).parent
        assert directory.parent == ROOT / '.issue-11-evidence/issue159-performance'
        assert directory.is_dir() and not directory.is_symlink() and directory not in observers
        assert order['trace'] == str(WORKSPACE / 'e2e/qualification/worker-turns.jsonl')
        assert report['complete'] and report['sources_unchanged'] and order['complete']
        observers.append(directory)
    roots = {'workspace': {'root': WORKSPACE, 'paths': [WORKSPACE], 'scope': 'whole closed recipe workspace'},
             'transport': {'root': TRANSPORT, 'paths': [TRANSPORT], 'scope': 'whole closed original one-shot transport'},
             'public-bindings': {'root': ASSETS, 'paths': [ASSETS / name for name in PUBLIC_NAMES], 'scope': 'exact five closed public binding files'},
             'observer-attachments': {'root': native, 'paths': attachments, 'scope': 'exact eight native observer attachments bound to original UUID roots'}}
    for number, directory in enumerate(sorted(observers), 1):
        roots[f'observer-{number:02d}'] = {'root': directory, 'paths': [directory], 'scope': 'whole exact actual original observer UUID tree'}
    return roots


def inventory(roots):
    files, directories, empty, aliases, special, root_rows = {}, {}, [], [], [], {}
    def visit(label, root, path):
        metadata = path.lstat()
        relative = path.relative_to(root).as_posix()
        key = label if relative == '.' else label + '/' + relative
        facts = {'mode': stat.S_IMODE(metadata.st_mode), 'file_type': stat.S_IFMT(metadata.st_mode), 'mtime_ns': metadata.st_mtime_ns, 'uid': metadata.st_uid, 'gid': metadata.st_gid, 'nlink': metadata.st_nlink}
        if stat.S_ISLNK(metadata.st_mode):
            aliases.append({'path': key, 'original_path': str(path), 'target': os.readlink(path), 'active': False, 'metadata': facts})
        elif stat.S_ISDIR(metadata.st_mode):
            directories[key] = facts
            children = sorted(path.iterdir())
            if not children:
                empty.append(key)
            for child in children:
                visit(label, root, child)
        elif stat.S_ISREG(metadata.st_mode):
            assert path.name != 'PRODUCT_SPEC.md', path
            if label.startswith('observer-'):
                assert not path.name.lower().endswith(DB_SUFFIXES), ('Unexpected observer store: require raw pre-SQL preservation before continuing', path)
            files[key] = {'original_path': str(path), **frozen(path), 'metadata': facts}
        else:
            special.append({'path': key, 'original_path': str(path), 'active': False, 'opened': False, 'metadata': facts})
    for label, row in roots.items():
        root = row['root']
        assert root.is_dir() and not root.is_symlink()
        assert root != OUT and not root.is_relative_to(OUT) and not OUT.is_relative_to(root)
        for path in row['paths']:
            visit(label, root, path)
        values = [value for name, value in files.items() if name.startswith(label + '/')]
        root_rows[label] = {'original_root': str(root), 'selected_paths': [str(path) for path in row['paths']], 'scope': row['scope'], 'regular_files': len(values), 'bytes': sum(value['bytes'] for value in values)}
    return {'roots': root_rows, 'files': files, 'directories': directories, 'empty_directories': sorted(empty), 'inert_aliases': sorted(aliases, key=lambda row: row['path']), 'inert_nonregular_descriptors': sorted(special, key=lambda row: row['path']), 'missing_roots': [], 'body_exclusions': []}


def verify_mirror(report, observed, trace, trace_sources, sources):
    order = report['work_order']
    assert report['complete'] and report['sources_unchanged'] and order['complete']
    assert report['sources_before'] == report['sources_after'] == trace_sources
    assert all(sources[name] == value for name, value in trace_sources.items())
    header_body = trace[:trace.index(b'\n') + 1]
    header = json.loads(header_body)
    assert order['header'] == header and header['source_count'] == len(trace_sources)
    assert header['source_digest'] == sha(json.dumps(trace_sources, sort_keys=True, separators=(',', ':')).encode())
    assert len(observed) == order['observed_bytes'] and sha(observed) == order['observed_sha256']
    assert observed.startswith(header_body)
    body = observed[len(header_body):]
    offset = order['source_start_offset']
    assert trace[offset:offset + len(body)] == body and trace[offset - 1:offset] == b'\n'
    previous = json.loads(trace[trace.rfind(b'\n', 0, offset - 1) + 1:offset - 1])
    assert previous['record'] == order['start_record']
    lines = body.splitlines()
    assert len(lines) == order['records'] == order['last_record'] - order['start_record']
    for number, line in enumerate(lines, order['start_record'] + 1):
        assert json.loads(line)['record'] == number
    return {'records': len(lines), 'first_record': order['start_record'] + 1, 'last_record': order['last_record'], 'source_start_offset': offset}
