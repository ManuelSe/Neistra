"""Portable full retained-state verification; optional complete CLOSED original readback."""
from pathlib import Path
import argparse
import json
import zipfile
from support import H, HELPER, helper, fingerprint, inventory, select_roots, sha, verify_mirror, verify_raw_bindings, verify_head_binding, verify_source_model

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--archive', type=Path, required=True)
parser.add_argument('--originals', action='store_true')
args = parser.parse_args()
assert isinstance(H, str) and len(H)==40 and all(c in '0123456789abcdef' for c in H), 'Unbound static verifier template'
counts = helper()['verify_layers'](args.archive, args.archive.name)
with zipfile.ZipFile(args.archive) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    inv = json.loads(archive.read('preservation/input-inventory.json'))
    context = json.loads(archive.read('preservation/context.json'))
    provenance = json.loads(archive.read('preservation/provenance.json'))
    seal = json.loads(archive.read('preservation/input-seal.json'))
    reference = json.loads(archive.read('preservation/preparation-input-bindings.json'))
    expected = set(inv['files']) | {'preservation/' + name for name in context['metadata_members']}
    assert len(archive.namelist()) == len(set(archive.namelist()))
    assert set(archive.namelist()) == expected | {'manifest.json'} and set(manifest) == expected
    assert context['candidate'] == provenance['candidate'] == seal['candidate'] == H and context['candidate_gate_PASS']
    assert context['gate_command_exits_zero'] == 43 and not context['final_all7_merge_master_release_complete']
    assert not context['separate_failed_forensic_asset'] and not inv['body_exclusions']
    assert manifest['preservation/release-evidence-used.py.txt']['sha256'] == HELPER
    for name, row in inv['files'].items():
        assert manifest[name] == {key: row[key] for key in ('bytes', 'sha256')}
    for name, key in [('input-inventory.json', 'original_closed_input_inventory'), ('provenance.json', 'provenance'), ('context.json', 'context')]:
        assert manifest['preservation/' + name] == seal[key]
    native12 = reference['native12']
    verify_source_model(reference)
    verify_head_binding(native12['primary'], native12['runtime'], native12['assessment'], native12['canonical_pins'])
    assert native12['canonical_pins_bytes']['sha256'] == native12['runtime']['binding']['canonical_root_pins_sha256']
    gate = json.loads(archive.read('public-bindings/c5-candidate4-gate.json'))
    recipe = json.loads(archive.read('public-bindings/c5-candidate4-recipe.json'))
    summary = json.loads(archive.read('public-bindings/c5-candidate4-summary.json'))
    primary = json.loads(archive.read('transport/primary-terminal-readback.json'))
    assert manifest['transport/primary-terminal-readback.json']['sha256'] == provenance['primary_terminal_proof']['sha256']
    assert primary['candidate'] == H and primary['actual_runner_wait_exit'] == 0
    assert primary['recorded_steps'] == 43 and primary['remaining_unrun_steps'] == 0 and primary['gate_complete']
    assert primary['original_transport_identity_complete']
    assert gate['complete'] and gate['commit'] == summary['commit'] == H
    assert summary['complete_steps'] == len(gate['steps']) == len(recipe['steps']) == 43
    assert all(row['exit_code'] == 0 for row in gate['steps'])
    for actual, expected_step in zip(gate['steps'], recipe['steps'], strict=True):
        assert all(actual.get(key) == expected_step.get(key) for key in ('label', 'command', 'environment', 'cwd'))
    assert summary['python_skips'] == summary['new_exclusions'] == summary['failures_flakes_retries'] == 0
    assert summary['complete_browser_inventory_executed'] and summary['existing_exclusion_identities_unchanged']
    pins_body = archive.read('transport/pins.json')
    assert len(pins_body) == reference['gate']['pins_bytes']['bytes']
    assert sha(pins_body) == reference['gate']['pins_bytes']['sha256']
    pins = json.loads(pins_body)
    assert pins['head'] == H and pins['selected_sources'] == gate['source_before'] == gate['source_after'] == reference['gate']['selected_sources']
    assert provenance['source_model'] == reference['source_model']
    assert len(native12['method_map']) == context['method_count'] == provenance['method_count']
    assert all(pins['selected_sources'][name] == digest for name, digest in native12['method_map'].items())
    assert gate['preceding_source_before'] == gate['preceding_source_after'] == pins['preceding_sources']
    raw_count = len(provenance['raw_original_copy_bindings'])
    assert raw_count == context['raw_original_copy_pairs'] == provenance['raw_original_copy_pairs_verified'] == seal['raw_original_copy_pairs_verified'] > 0
    for relative, row in provenance['raw_original_copy_bindings'].items():
        expected_hash = {key: row[key] for key in ('bytes', 'sha256')}
        assert manifest['workspace/' + relative] == manifest['transport/post-cleanup-raw-database-bytes/' + relative] == expected_hash
    cleanup = json.loads(archive.read('transport/cleanup-before-raw-copy.json'))
    raw = json.loads(archive.read('transport/raw-database-copy.json'))
    assert cleanup['complete'] and not cleanup['positively_owned_processes_remaining'] and all(cleanup['ports_unused'].values())
    assert raw['cleanup_monotonic_ns'] == cleanup['monotonic_ns'] < raw['started_monotonic_ns'] and raw['cleanup_before_copy']
    assert cleanup['SQL_opened'] is False and raw['SQL_opened'] is False
    trace = archive.read('workspace/e2e/qualification/worker-turns.jsonl')
    trace_sources = json.loads(archive.read('workspace/e2e/qualification/worker-turns.sources.json'))
    assert trace_sources == native12['observer_source_map']
    observer_bindings = provenance['all_original_observer_bindings']
    assert len(observer_bindings) == len({row['original_root'] for row in observer_bindings}) == context['original_observer_roots'] == 8
    for binding in observer_bindings:
        report_body = archive.read(binding['native_member'])
        assert archive.read(binding['original_report_member']) == report_body
        assert manifest[binding['native_member']] == manifest[binding['original_report_member']] == binding['report_bytes']
        assert manifest[binding['original_records_member']] == binding['observed_records_bytes']
        assert verify_mirror(json.loads(report_body), archive.read(binding['original_records_member']), trace, trace_sources, pins['selected_sources']) == binding['trace_checks']
if args.originals:
    assert inventory(select_roots()) == inv, 'Original CLOSED roots, union, bytes or metadata changed'
    raw_originals = {'cleanup_before_copy': True, 'SQL_opened': False, 'originals_retained': True,
                     'workspace': inv['roots']['workspace']['original_root'], 'files': provenance['raw_original_copy_bindings']}
    assert verify_raw_bindings(raw_originals) == raw_count
print(json.dumps({'scope': 'Closed c5-candidate4 retained-state supplement only; no final release qualification.',
                  'candidate': H, 'archive': fingerprint(args.archive), 'recursive_counts': counts,
                  'exact_outer_union': len(expected), 'original_files': len(inv['files']),
                  'full_original_inventory_rehashed': args.originals, 'raw_original_copy_pairs': raw_count,
                  'original_observer_roots': len(observer_bindings), 'original_observer_files': context['original_observer_regular_files'],
                  'all_original_observer_source_and_mirror_bindings': True, 'method_count': context['method_count'],
                  'candidate_gate_PASS': True, 'final_all7_merge_master_release_complete': False, 'SQL_opened': False}))
