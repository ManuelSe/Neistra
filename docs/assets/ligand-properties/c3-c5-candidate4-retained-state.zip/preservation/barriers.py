"""Actual success and complete official-package barriers; no launch or retry actions."""
from pathlib import Path
import json
import subprocess
import zipfile
from support import ROOT, OUT, ASSETS, TRANSPORT, WORKSPACE, LABEL, H, HELPER, frozen, helper, load_reference, read, sha, verify_raw_bindings


def require_terminal():
    # Never open growing workspace/output roots before the original owned wait.
    status = read(TRANSPORT / 'transport-status.json')
    assert status['terminal'] is True and status['state'] == 'TERMINAL'
    assert status['identity_complete'] is True and status['actual_runner_returncode'] == 0
    reference = load_reference()
    forensic_index = reference['publication_context']['forensic_index']
    assert frozen(Path(forensic_index['path'])) == {key: forensic_index[key] for key in ('bytes', 'sha256')}
    assert frozen(TRANSPORT / 'pins.json') == reference['gate']['pins_bytes']
    pins = read(TRANSPORT / 'pins.json')
    assert pins['head'] == H and pins['root'] == str(ROOT) and pins['label'] == LABEL
    assert pins['selected_sources'] == reference['gate']['selected_sources']
    assert len(pins['preceding_sources']) == reference['source_model']['preceding_source_count']
    assert sha(json.dumps(pins['preceding_sources'], sort_keys=True, separators=(',', ':')).encode()) == reference['source_model']['preceding_source_digest_compact']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == H
    proof_path = TRANSPORT / 'primary-terminal-readback.json'
    proof = read(proof_path)
    assert proof['candidate'] == H and proof['actual_runner_wait_exit'] == 0
    assert proof['original_transport_identity_complete'] is True
    assert proof['recorded_steps'] == 43 and proof['remaining_unrun_steps'] == 0 and proof['gate_complete'] is True
    assert proof['source_count'] == len(pins['selected_sources'])
    assert proof['actual_tagged_preceding_source_count'] == len(pins['preceding_sources'])
    assert proof['raw_existing_DB_WAL_SHM_originals_and_copies_exact'] is True and proof['SQL_opened'] is False
    cleanup_path = TRANSPORT / 'cleanup-before-raw-copy.json'
    assert frozen(cleanup_path)['sha256'] == proof['positive_cleanup_receipt']['sha256']
    cleanup = read(cleanup_path)
    assert cleanup['complete'] and not cleanup['positively_owned_processes_remaining']
    assert not cleanup['live_exact_workspace_data_markers'] and all(cleanup['ports_unused'].values())
    assert cleanup['signals_sent'] is False and cleanup['SQL_opened'] is False
    raw_path = TRANSPORT / 'raw-database-copy.json'
    assert frozen(raw_path)['sha256'] == proof['raw_copy_receipt']['sha256']
    raw = read(raw_path)
    assert raw['cleanup_monotonic_ns'] == cleanup['monotonic_ns'] < raw['started_monotonic_ns']
    assert verify_raw_bindings(raw) == len(raw['files']) > 0
    gate = read(ASSETS / f'{LABEL}-gate.json')
    summary = read(ASSETS / f'{LABEL}-summary.json')
    recipe = read(ASSETS / f'{LABEL}-recipe.json')
    assert frozen(ASSETS / f'{LABEL}-recipe.json') == reference['gate']['recipe_bytes']
    assert gate['commit'] == summary['commit'] == H
    assert gate['complete'] and summary['complete_steps'] == len(gate['steps']) == len(recipe['steps']) == 43
    assert all(step['exit_code'] == 0 for step in gate['steps'])
    assert gate['source_before'] == gate['source_after'] == pins['selected_sources']
    assert gate['preceding_source_before'] == gate['preceding_source_after'] == gate['preceding_source_expected'] == pins['preceding_sources']
    assert summary['source_count'] == len(pins['selected_sources'])
    assert summary['python_skips'] == summary['new_exclusions'] == summary['failures_flakes_retries'] == 0
    assert summary['existing_exclusion_identities_unchanged'] and summary['complete_browser_inventory_executed']
    scope = helper()
    package = scope['verify_package_receipt'](ASSETS / f'{LABEL}-packaging.json')
    assert package['qualified_commit'] == H and package['packager_sha256'] == HELPER
    items, context = scope['gate_items'](ROOT, LABEL)
    actual = {}
    for part in package['archives']:
        assert part['bytes'] < 95 * 1024 * 1024
        with zipfile.ZipFile(part['path']) as archive:
            manifest = json.loads(archive.read('manifest.json'))
            assert not set(actual).intersection(manifest)
            actual.update(manifest)
    assert set(actual) == set(items)
    assert all(actual[name] == scope['fingerprint'](member) for name, member in items.items())
    assert package['source_digest'] == summary['source_digest'] == context['source_digest']
    return {'proof': proof, 'proof_binding': {'path': str(proof_path), **frozen(proof_path)},
            'raw': raw, 'cleanup': cleanup, 'gate': gate, 'summary': summary, 'recipe': recipe,
            'pins': pins, 'package': package, 'reference': reference,
            'official_exact_disjoint_union_members': len(actual)}
