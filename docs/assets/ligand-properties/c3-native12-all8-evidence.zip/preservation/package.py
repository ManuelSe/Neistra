"""Package CLOSED native12 only after primary supplies actual closed analysis/hash."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import json
from support import ROOT, OUT, KIT, WORKSPACE, PRIMARY, PRIMARY_SHA, HELPER, DB_SUFFIXES, fingerprint, frozen, helpers, inventory, read, select_roots, verify_all8, verify_head_binding, verify_raw, verify_source_archives, write


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis-root', required=True, type=Path)
    parser.add_argument('--analysis-sha256', required=True)
    parser.add_argument('--analysis-proof', action='append', type=Path, default=[])
    args = parser.parse_args()
    # Actual closed analysis is a required input, never a placeholder or future output.
    analysis_root = args.analysis_root.absolute()
    assert analysis_root.parent == ROOT / '.issue-11-evidence'
    assert analysis_root.name.startswith('issue159-native12-closed-analysis')
    assert analysis_root != OUT and not analysis_root.is_symlink()
    assessment_path = analysis_root / 'assessment.json'
    assert frozen(assessment_path)['sha256'] == args.analysis_sha256
    assessment = read(assessment_path)
    assert assessment['workflow_passes'] == 8 and assessment['skips_failures_flakes_retries'] == 0
    assert assessment['final_feature_release_qualification'] is False
    assert (analysis_root / 'analyze.py').is_file() and (analysis_root / 'input-identities.json').is_file()
    assert frozen(PRIMARY)['sha256'] == PRIMARY_SHA
    primary = read(PRIMARY)
    assert primary['actual_original_runner_wait_exit'] == 0 and primary['SQL_opened'] is False
    assert not primary['qualification_PASS'] and all(primary['ports_unused'].values())
    status = read(KIT / 'transport-status.json')
    assert status['state'] == 'TERMINAL' and status['terminal'] and status['identity_complete'] and status['actual_runner_returncode'] == 0
    runtime = read(KIT / 'actual-receipt.json')
    assert runtime['binding']['root'] == str(ROOT)
    pins_path = KIT / 'canonical-root-pins.json'
    assert frozen(pins_path)['sha256'] == runtime['binding']['canonical_root_pins_sha256']
    verify_head_binding(primary, runtime, assessment, read(pins_path))
    assert runtime['exit_code'] == 0 and runtime['complete'] and runtime['source_unchanged']
    assert runtime['qualification_status'] == 'ORDINARY_COMPLETION' and not runtime['interrupted']
    assert runtime['workspace'] == str(WORKSPACE)
    assert assessment['actual_terminal_collector_proof']['sha256'] == PRIMARY_SHA
    assert assessment['source_count'] == primary['source_count'] and assessment['method_count'] == primary['method_count']
    assert assessment['source_digest_compact'] == primary['source_digest'] and assessment['method_digest_spaced'] == primary['method_digest']
    sources, methods, archives = verify_source_archives(runtime, primary)
    cases = verify_all8(read(KIT / 'browser.json'))
    raw_count = verify_raw(primary)
    roots = select_roots(primary, runtime, analysis_root, args.analysis_proof)
    before = inventory(roots)
    expected_stores = {row['original'] for row in primary['raw_original_runner_copy_primary_copy_pairs'].values()}
    actual_stores = {row['original_path'] for name, row in before['files'].items() if name.startswith('workspace/') and name.lower().endswith(DB_SUFFIXES)}
    assert actual_stores == expected_stores
    observer_counts = {}
    for label, row in before['roots'].items():
        if label.startswith('workflow-'):
            assert row['regular_files'] == primary['complete_original_observer_roots'][row['original_root']]
            observer_counts[row['original_root']] = row['regular_files']
    assert len(observer_counts) == 8
    write('input-inventory.json', before)
    provenance = {'candidate': primary['candidate'], 'primary_terminal_proof': {'path': str(PRIMARY), **frozen(PRIMARY)},
                  'actual_runner_receipt': {'path': str(KIT / 'actual-receipt.json'), **frozen(KIT / 'actual-receipt.json')},
                  'analysis': {'path': str(assessment_path), **frozen(assessment_path)}, 'analysis_root': str(analysis_root),
                  'analysis_input_identities': {'path': str(analysis_root / 'input-identities.json'), **frozen(analysis_root / 'input-identities.json')},
                  'source_count': len(sources), 'method_count': len(methods), 'source_digest': primary['source_digest'], 'method_digest': primary['method_digest'],
                  'source_archives': archives, 'raw_original_runner_copy_primary_copy_pairs': primary['raw_original_runner_copy_primary_copy_pairs'],
                  'raw_triplet_count': raw_count, 'complete_original_observer_roots': observer_counts,
                  'owned_cleanup_precedes_runner_raw_copy_and_diagnostic_SQL_not_opened': True,
                  'SQL_opened': False, 'current_qualifying_source_or_HEAD_requeried_by_packager': False}
    write('provenance.json', provenance)
    metadata_members = ['input-inventory.json', 'provenance.json', 'context.json', 'input-seal.json', 'package.py', 'support.py', 'verify.py', 'release-evidence-used.py.txt', 'inventory.schema.json']
    context = {'scope': 'Complete closed native12 ALL8 portable evidence retention; full feature, merged release and strict host qualification remain separate.',
               'candidate': primary['candidate'], 'actual_original_runner_wait_exit': 0, 'all8workflow_cases_passed': True,
               'skips_failures_flakes_retries': 0, 'workflow_cases': cases,
               'source_count': len(sources), 'method_count': len(methods), 'source_digest': primary['source_digest'], 'method_digest': primary['method_digest'],
               'original_observer_root_count': len(observer_counts), 'original_observer_files': sum(observer_counts.values()),
               'raw_original_runner_copy_primary_copy_triplets': raw_count,
               'strict_reference_host_certification': False, 'causal_speedup_or_same_method_comparison_claim': False,
               'resource_and_timing_limits': 'Closed assessment and all original measured records retained unchanged, including every observed limit/miss; no retention-stage budget reinterpretation.',
               'timing_policy': assessment['policy'], 'comparison_limits': assessment['descriptive_baseline_comparison']['limits'],
               'source_capsule_policy': 'Both actual before/after source ZIPs and exact selected source/method maps retained in full kit; current tree/HEAD is not substituted.',
               'all_regular_bytes_retained': True, 'body_exclusions': [],
               'directory_and_alias_policy': 'Full directory/empty-directory/inert alias and structural metadata retained; no alias target or structural file opened.',
               'final_feature_release_qualification': False, 'release_or_publication_complete': False,
               'SQL_opened': False, 'metadata_members': metadata_members}
    write('context.json', context)
    write('input-seal.json', {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'candidate': primary['candidate'],
                             'input_inventory': frozen(OUT / 'input-inventory.json'), 'provenance': frozen(OUT / 'provenance.json'), 'context': frozen(OUT / 'context.json'),
                             'original_files': len(before['files']), 'original_bytes': sum(row['bytes'] for row in before['files'].values()),
                             'analysis_assessment_hash_supplied_by_primary': args.analysis_sha256,
                             'inputs_closed_originals_retained': True, 'no_packet_self_SHA_in_inputs': True})
    items = {name: Path(row['original_path']) for name, row in before['files'].items()}
    for name in metadata_members:
        items['preservation/' + name] = OUT / name
    packet = helpers()['archive'](items, OUT / 'native12-all8-evidence.zip')
    after = inventory(roots)
    write('originals-after.json', after)
    assert before == after, 'Closed originals changed during packaging'
    assert verify_raw(primary) == raw_count
    verification = {'scope': context['scope'], 'candidate': primary['candidate'], 'archive': packet,
                    'original_roots': len(roots), 'original_files': len(before['files']), 'original_bytes': sum(row['bytes'] for row in before['files'].values()),
                    'original_observer_roots': len(observer_counts), 'original_observer_files': sum(observer_counts.values()),
                    'raw_triplets_verified_before_and_after': raw_count, 'source_count': len(sources), 'method_count': len(methods),
                    'empty_directories': len(before['empty_directories']), 'inert_aliases': len(before['inert_aliases']), 'inert_nonregular_descriptors': len(before['inert_nonregular_descriptors']),
                    'all_original_before_after_bytes_metadata_and_union_exact': True, 'all_original_bodies_CRC_recursive_unique_exact_union': True,
                    'analysis_assessment_sha256': args.analysis_sha256, 'configured_single_asset_cap_bytes': 2 * 1024**3,
                    'within_configured_single_asset_cap': packet['bytes'] < 2 * 1024**3, 'all8_portable_only': True,
                    'final_feature_release_qualification': False, 'SQL_opened': False}
    assert verification['within_configured_single_asset_cap']
    write('verification.json', verification)
    with (OUT / 'native12-all8-evidence.zip.sha256').open('x') as stream:
        stream.write(packet['sha256'] + '  native12-all8-evidence.zip\n')
    print(json.dumps(verification))


if __name__ == '__main__':
    main()
