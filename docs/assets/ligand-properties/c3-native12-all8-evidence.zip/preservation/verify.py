"""Standalone full native12 retention verification; optional closed-original reinventory."""
from pathlib import Path
import argparse
import io
import json
import zipfile
from support import ROOT, PRIMARY_SHA, HELPER, helpers, fingerprint, inventory, sha, verify_all8, verify_head_binding, verify_mirror


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', required=True, type=Path)
    parser.add_argument('--originals', action='store_true')
    args = parser.parse_args()
    counts = helpers()['verify_layers'](args.archive, args.archive.name)
    with zipfile.ZipFile(args.archive) as archive:
        manifest = json.loads(archive.read('manifest.json'))
        inv = json.loads(archive.read('preservation/input-inventory.json'))
        context = json.loads(archive.read('preservation/context.json'))
        provenance = json.loads(archive.read('preservation/provenance.json'))
        seal = json.loads(archive.read('preservation/input-seal.json'))
        expected = set(inv['files']) | {'preservation/' + name for name in context['metadata_members']}
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert set(archive.namelist()) == expected | {'manifest.json'} and set(manifest) == expected
        assert not inv['body_exclusions'] and not context['body_exclusions']
        assert context['candidate'] == provenance['candidate'] == seal['candidate']
        assert context['all8workflow_cases_passed'] and not context['final_feature_release_qualification']
        assert not context['strict_reference_host_certification'] and not context['causal_speedup_or_same_method_comparison_claim']
        assert manifest['preservation/release-evidence-used.py.txt']['sha256'] == HELPER
        for name, field in [('input-inventory.json', 'input_inventory'), ('provenance.json', 'provenance'), ('context.json', 'context')]:
            assert manifest['preservation/' + name] == seal[field]
        for name, row in inv['files'].items():
            assert manifest[name] == {key: row[key] for key in ('bytes', 'sha256')}

        def member_for_original(path):
            names = [name for name, row in inv['files'].items() if row['original_path'] == path]
            assert len(names) == 1
            return names[0]

        terminal_member = member_for_original(provenance['primary_terminal_proof']['path'])
        assert manifest[terminal_member]['sha256'] == PRIMARY_SHA
        primary = json.loads(archive.read(terminal_member))
        assert primary['actual_original_runner_wait_exit'] == 0 and primary['candidate'] == context['candidate']
        runtime = json.loads(archive.read('kit/actual-receipt.json'))
        assert runtime['binding']['HEAD'] == context['candidate'] and runtime['exit_code'] == 0
        assert runtime['source_before'] == runtime['source_after'] and runtime['methods_before'] == runtime['methods_after']
        sources, methods = runtime['source_before'], runtime['methods_before']
        assert len(sources) == primary['source_count'] == context['source_count']
        assert len(methods) == primary['method_count'] == context['method_count']
        assert sha(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()) == primary['source_digest'] == context['source_digest']
        assert sha(json.dumps(methods, sort_keys=True).encode()) == primary['method_digest'] == context['method_digest']
        assert all(sources[name] == value for name, value in methods.items())
        for name in ('source-preparation.zip', 'source-after.zip'):
            body = archive.read('kit/' + name)
            assert len(body) == provenance['source_archives'][name]['bytes'] and sha(body) == provenance['source_archives'][name]['sha256']
            with zipfile.ZipFile(io.BytesIO(body)) as captured:
                names = captured.namelist()
                assert len(names) == len(set(names)) == len(sources) and set(names) == set(sources)
                assert captured.testzip() is None
                assert all(sha(captured.read(name)) == digest for name, digest in sources.items())
        assert verify_all8(json.loads(archive.read('kit/browser.json'))) == context['workflow_cases']
        raw = provenance['raw_original_runner_copy_primary_copy_pairs']
        assert len(raw) == provenance['raw_triplet_count'] == context['raw_original_runner_copy_primary_copy_triplets']
        for row in raw.values():
            expected_hash = {key: row[key] for key in ('bytes', 'sha256')}
            assert all(manifest[member_for_original(row[key])] == expected_hash for key in ('original', 'runner_preSQL_copy', 'primary_copy'))
        cleanup = json.loads(archive.read('kit/cleanup-before-store-archive.json'))
        raw_archive = json.loads(archive.read('kit/database-byte-archive.json'))
        assert cleanup['complete'] and not cleanup['positively_owned_processes_remaining'] and all(cleanup['ports_unused'].values())
        assert cleanup['monotonic_ns'] < raw_archive['started_monotonic_ns']
        analysis_member = member_for_original(provenance['analysis']['path'])
        assert manifest[analysis_member]['sha256'] == seal['analysis_assessment_hash_supplied_by_primary'] == provenance['analysis']['sha256']
        assessment = json.loads(archive.read(analysis_member))
        pins_body = archive.read('kit/canonical-root-pins.json')
        assert sha(pins_body) == runtime['binding']['canonical_root_pins_sha256']
        verify_head_binding(primary, runtime, assessment, json.loads(pins_body))
        assert assessment['candidate'] == context['candidate'] and assessment['workflow_passes'] == 8 and assessment['skips_failures_flakes_retries'] == 0
        assert assessment['source_count'] == len(sources) and assessment['method_count'] == len(methods)
        assert assessment['source_digest_compact'] == context['source_digest'] and assessment['method_digest_spaced'] == context['method_digest']
        assert not assessment['final_feature_release_qualification']
        roots = {row['original_root']: (name, row) for name, row in inv['roots'].items() if name.startswith('workflow-')}
        assert set(roots) == set(primary['complete_original_observer_roots']) == set(runtime['new_harness_directories'])
        assert len(roots) == context['original_observer_root_count'] == 8
        trace = archive.read('workspace/e2e/qualification/worker-turns.jsonl')
        trace_sources = json.loads(archive.read('workspace/e2e/qualification/worker-turns.sources.json'))
        attachments = sorted(name for name in manifest if name.startswith('kit/native/') and '/attachments/descriptor-worker-observation-' in name and name.endswith('.json'))
        assert len(attachments) == 8
        mirrors = []
        seen = set()
        for name in attachments:
            body = archive.read(name)
            report = json.loads(body)
            directory = str(Path(report['work_order']['observed_records']).parent)
            assert directory in roots and directory not in seen
            seen.add(directory)
            label, row = roots[directory]
            assert row['regular_files'] == primary['complete_original_observer_roots'][directory]
            assert archive.read(label + '/worker-observation.json') == body
            observed = archive.read(label + '/' + Path(report['work_order']['observed_records']).name)
            mirrors.append(verify_mirror(report, observed, trace, trace_sources, sources))
        assert seen == set(roots)
        if args.originals:
            selected = {name: {'root': Path(row['original_root']), 'paths': [Path(path) for path in row['selected_paths']],
                               'scope': row['scope'], 'selected_files_only': Path(row['original_root']) == ROOT}
                        for name, row in inv['roots'].items()}
            assert inventory(selected) == inv, 'Complete original root union, bytes or metadata changed'
    print(json.dumps({'scope': 'Native12 complete portable ALL8 retention verification only; no final feature/release/strict-host/speedup claim.',
                      'candidate': context['candidate'], 'archive': fingerprint(args.archive), 'recursive_counts': counts,
                      'exact_outer_union': len(expected), 'original_files': len(inv['files']), 'source_count': len(sources), 'method_count': len(methods),
                      'raw_original_runner_primary_triplets': len(raw), 'original_observer_roots': len(roots),
                      'original_observer_files': sum(row['regular_files'] for _, row in roots.values()),
                      'all8original_observer_source_and_trace_mirrors_verified': True, 'mirrored_record_checks': mirrors,
                      'whole_original_union_rehashed': args.originals, 'SQL_opened': False, 'final_feature_release_qualification': False}))


if __name__ == '__main__':
    main()
