"""Closed-input retention primitives; no source-tree, runtime, SQL or process actions."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import stat
import zipfile

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).absolute().parent
KIT = ROOT / '.issue-11-evidence/issue159-native12-preparation1'
WORKSPACE = Path('/tmp/neistra159-performance-native12-all8')
PRIMARY = KIT / 'primary-terminal-readback1/readback.json'
PRIMARY_SHA = '8e0ade7b1bbf9cb906a149413918ad5867e919eff77dd41e62eadb60c62355af'
HELPER = '34ef47ebd6fe9f12009600e099c8cd5599a851c4dc95ac5412b7eb12470173e3'
DB_SUFFIXES = ('.db', '.sqlite', '.sqlite3', '-wal', '-shm')


def sha(body):
    return hashlib.sha256(body).hexdigest()


def fingerprint(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def frozen(path):
    assert path.is_file() and not path.is_symlink(), path
    before = path.stat()
    value = fingerprint(path)
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), path
    return value


def helpers():
    path = OUT / 'release-evidence-used.py.txt'
    assert frozen(path)['sha256'] == HELPER
    return runpy.run_path(str(path), run_name='closed_native12_retention')


def write(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def read(path):
    return json.loads(path.read_bytes())


def verify_head_binding(primary, runtime, assessment, pins):
    """Bind typed before/after HEAD records to the original owned symbolic ref."""
    before = runtime['authoritative_HEAD_before']
    after = runtime['authoritative_HEAD_after']
    assert isinstance(before, dict) and isinstance(after, dict)
    assert before == after
    assert all(isinstance(before[key], str) for key in ('commit', 'ref', 'HEAD_text', 'scope'))
    candidate = primary['candidate']
    assert isinstance(candidate, str)
    assert candidate == runtime['binding']['HEAD'] == before['commit'] == assessment['candidate'] == pins['HEAD']
    ref = pins['ref']
    assert isinstance(ref, str) and ref.startswith('refs/heads/') and '..' not in Path(ref).parts
    assert before['ref'] == ref and before['HEAD_text'] == 'ref: ' + ref


def inventory(roots):
    files, directories, empty, aliases, special, root_rows = {}, {}, [], [], [], {}
    def visit(label, root, path):
        metadata = path.lstat()
        relative = path.relative_to(root).as_posix()
        key = label if relative == '.' else label + '/' + relative
        facts = {'mode': stat.S_IMODE(metadata.st_mode), 'file_type': stat.S_IFMT(metadata.st_mode), 'mtime_ns': metadata.st_mtime_ns, 'uid': metadata.st_uid, 'gid': metadata.st_gid, 'nlink': metadata.st_nlink}
        if stat.S_ISLNK(metadata.st_mode):
            aliases.append({'path': key, 'original_path': str(path), 'target': os.readlink(path), 'active': False, 'metadata': facts})
        elif stat.S_ISDIR(metadata.st_mode):
            directories[key] = facts
            children = sorted(path.iterdir())
            if not children:
                empty.append(key)
            for child in children:
                visit(label, root, child)
        elif stat.S_ISREG(metadata.st_mode):
            assert path.name != 'PRODUCT_SPEC.md', path
            if label.startswith('workflow-'):
                assert not path.name.lower().endswith(DB_SUFFIXES), ('Unexpected workflow store: stop before diagnostic SQL', path)
            files[key] = {'original_path': str(path), **frozen(path), 'metadata': facts}
        else:
            special.append({'path': key, 'original_path': str(path), 'active': False, 'opened': False, 'metadata': facts})
    for label, row in roots.items():
        root = row['root']
        assert root.is_dir() and not root.is_symlink()
        assert (
            root != OUT and not root.is_relative_to(OUT) and not OUT.is_relative_to(root)
        ) or row.get('selected_files_only') is True
        for path in row['paths']:
            assert path != OUT and not path.is_relative_to(OUT)
            visit(label, root, path)
        values = [row for name, row in files.items() if name.startswith(label + '/')]
        root_rows[label] = {'original_root': str(root), 'selected_paths': [str(path) for path in row['paths']], 'scope': row['scope'], 'regular_files': len(values), 'bytes': sum(value['bytes'] for value in values)}
    return {'roots': root_rows, 'files': files, 'directories': directories, 'empty_directories': sorted(empty), 'inert_aliases': sorted(aliases, key=lambda row: row['path']), 'inert_nonregular_descriptors': sorted(special, key=lambda row: row['path']), 'missing_roots': [], 'body_exclusions': []}


def verify_source_archives(runtime, primary):
    sources, methods = runtime['source_before'], runtime['methods_before']
    assert sources == runtime['source_after'] and methods == runtime['methods_after']
    assert len(sources) == primary['source_count'] and len(methods) == primary['method_count']
    assert sha(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()) == primary['source_digest']
    assert sha(json.dumps(methods, sort_keys=True).encode()) == primary['method_digest']
    assert all(sources[name] == value for name, value in methods.items())
    for name in ('source-audit-before.json', 'source-audit-after.json'):
        audit = read(KIT / name)
        assert audit['sources'] == sources and audit['methods'] == methods
        assert audit['source_count'] == len(sources) and audit['method_count'] == len(methods)
    checked = {}
    for name in ('source-preparation.zip', 'source-after.zip'):
        path = KIT / name
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            assert len(names) == len(set(names)) == len(sources) and set(names) == set(sources)
            assert archive.testzip() is None
            for member, digest in sources.items():
                assert 'PRODUCT_SPEC' not in member and sha(archive.read(member)) == digest
        checked[name] = {**frozen(path), 'source_count': len(sources), 'full_CRC_body_hash_unique_exact_union': True}
    return sources, methods, checked


def verify_raw(primary):
    pairs = primary['raw_original_runner_copy_primary_copy_pairs']
    assert pairs and primary['SQL_opened'] is False
    for name, row in pairs.items():
        expected = {key: row[key] for key in ('bytes', 'sha256')}
        assert Path(row['original']) == WORKSPACE / 'e2e' / name
        assert Path(row['runner_preSQL_copy']) == KIT / 'post-cleanup-database-bytes' / name
        assert Path(row['primary_copy']) == KIT / 'primary-terminal-readback1/raw-database-bytes' / name
        assert frozen(Path(row['original'])) == frozen(Path(row['runner_preSQL_copy'])) == frozen(Path(row['primary_copy'])) == expected
    cleanup = read(KIT / 'cleanup-before-store-archive.json')
    archive = read(KIT / 'database-byte-archive.json')
    assert cleanup['complete'] is True and not cleanup['positively_owned_processes_remaining'] and all(cleanup['ports_unused'].values())
    assert cleanup['monotonic_ns'] < archive['started_monotonic_ns'] and archive['originals_retained'] is True
    existing = {name: row for name, row in archive['files'].items() if row['exists']}
    assert set(existing) == set(pairs)
    for name, row in existing.items():
        assert {key: row[key] for key in ('bytes', 'sha256')} == {key: pairs[name][key] for key in ('bytes', 'sha256')}
    return len(pairs)


def verify_all8(report):
    assert not report['errors']
    stats = report['stats']
    assert stats['expected'] == 8 and stats['skipped'] == stats['unexpected'] == stats['flaky'] == 0
    cases = []
    def visit(suite):
        for spec in suite.get('specs', []):
            for test in spec.get('tests', []):
                assert test['status'] == 'expected' and len(test['results']) == 1
                result = test['results'][0]
                assert result['status'] == 'passed' and result.get('retry', 0) == 0
                cases.append({'project': test['projectName'], 'title': spec['title'], 'status': 'passed', 'attempts': 1})
        for child in suite.get('suites', []):
            visit(child)
    for suite in report['suites']:
        visit(suite)
    assert len(cases) == len({(row['project'], row['title']) for row in cases}) == 8
    assert {row['project'] for row in cases} == {'chromium', 'mobile-chromium'}
    return cases


def verify_mirror(report, observed, trace, trace_sources, sources):
    order = report['work_order']
    assert report['complete'] and report['sources_unchanged'] and order['complete']
    assert report['sources_before'] == report['sources_after'] == trace_sources
    assert all(sources[name] == value for name, value in trace_sources.items())
    header_body = trace[:trace.index(b'\n') + 1]
    header = json.loads(header_body)
    assert order['header'] == header and header['source_count'] == len(trace_sources)
    assert header['source_digest'] == sha(json.dumps(trace_sources, sort_keys=True, separators=(',', ':')).encode())
    assert len(observed) == order['observed_bytes'] and sha(observed) == order['observed_sha256']
    assert observed.startswith(header_body)
    body = observed[len(header_body):]
    offset = order['source_start_offset']
    assert trace[offset:offset + len(body)] == body and trace[offset - 1:offset] == b'\n'
    previous = json.loads(trace[trace.rfind(b'\n', 0, offset - 1) + 1:offset - 1])
    assert previous['record'] == order['start_record']
    lines = body.splitlines()
    assert len(lines) == order['records'] == order['last_record'] - order['start_record']
    for number, line in enumerate(lines, order['start_record'] + 1):
        assert json.loads(line)['record'] == number
    return {'records': len(lines), 'first_record': order['start_record'] + 1, 'last_record': order['last_record'], 'source_start_offset': offset}


def select_roots(primary, runtime, analysis_root, extra_proofs):
    roots = {'kit': {'root': KIT, 'paths': [KIT], 'scope': 'whole closed native12 preparation/runner/transport/terminal/native/source/raw root'},
             'workspace': {'root': WORKSPACE, 'paths': [WORKSPACE], 'scope': 'whole closed actual native12 workspace'},
             'primary-launch': {'root': ROOT / '.issue-11-evidence/issue159-native12-primary-launch1', 'paths': [ROOT / '.issue-11-evidence/issue159-native12-primary-launch1'], 'scope': 'whole closed actual primary launch proof root'},
             'C1-readiness': {'root': ROOT / '.issue-11-evidence/issue159-observer-correction-c1-readiness1', 'paths': [ROOT / '.issue-11-evidence/issue159-observer-correction-c1-readiness1'], 'scope': 'whole closed C1 readiness proof root'},
             'closed-analysis': {'root': analysis_root, 'paths': [analysis_root], 'scope': 'whole closed actual analysis, scripts and proofs after primary supplies actual assessment hash'},
             'C1-bindings': {'root': ROOT, 'paths': [ROOT / '.issue-11-evidence/issue159-observer-c1-self-review1.json', ROOT / 'docs/assets/ligand-properties/c3-observer-snapshot-checkpoint.json', ROOT / 'docs/assets/ligand-properties/c3-observer-snapshot-evidence.zip'], 'scope': 'exact C1 self-review and public checkpoint/evidence bindings', 'selected_files_only': True}}
    workflows = sorted(Path(name) for name in primary['complete_original_observer_roots'])
    assert len(workflows) == len(set(workflows)) == 8
    assert set(map(str, workflows)) == set(runtime['new_harness_directories'])
    for number, directory in enumerate(workflows, 1):
        assert directory.parent == ROOT / '.issue-11-evidence/issue159-performance'
        roots[f'workflow-{number:02d}'] = {'root': directory, 'paths': [directory], 'scope': 'whole exact receipt-derived original workflow observer UUID root'}
    whole = [row['root'] for row in roots.values() if not row.get('selected_files_only')]
    assert len(whole) == len(set(whole))
    assert all(not a.is_relative_to(b) for a in whole for b in whole if a != b)
    extra = []
    for path in extra_proofs:
        path = path.absolute()
        assert path.is_relative_to(ROOT) and path.is_file() and not path.is_symlink()
        if any(path.is_relative_to(directory) for directory in whole):
            continue
        assert path not in roots['C1-bindings']['paths']
        extra.append(path)
    assert len(extra) == len(set(extra))
    if extra:
        roots['analysis-extra-proofs'] = {'root': ROOT, 'paths': sorted(extra), 'scope': 'exact primary-supplied external closed-analysis proof files', 'selected_files_only': True}
    return roots
