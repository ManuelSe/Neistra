"""Pure native12 candidate/method/receipt contract; import performs no I/O."""
from __future__ import annotations
import hashlib
import json
import re
from typing import Any

BASE = '26e7cc1b9fdc5758ed18049b0fa7be67d7559882'
BRANCH = 'refs/heads/fix/issue-159-observer-snapshots'
CHANGED = {'tests/e2e/ligand-properties-performance.spec.ts',
           'tests/support/ligand_property_performance_qualification.py'}
HELPER = 'tests/e2e/support/observer-snapshot.ts'
ADDED = {HELPER, 'apps/web/src/test/ligand-property-observer-snapshot.test.ts',
         'tests/unit/test_ligand_property_observation.py'}
CHECKS = {'observer_python_regressions', 'observer_reader_regressions', 'web_lint',
          'web_typecheck', 'strict_benchmark_types', 'web_build'}


def compact(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def spaced(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def validate(source: dict[str, str], methods: dict[str, str], pins: dict[str, Any],
             checkpoint: dict[str, Any], documents: dict[str, Any]) -> None:
    """Require actual clean C1, exact bounded correction and source-bound assessments."""
    head = pins['HEAD']
    assert re.fullmatch(r'[0-9a-f]{40}', head) and head != BASE
    assert pins['ref'] == BRANCH and pins['comparison_base'] == BASE
    assert pins['source_count'] == len(source) and pins['source_digest'] == compact(source)
    assert pins['method_count'] == len(methods) and pins['method_digest'] == spaced(methods)
    assert all(re.fullmatch(r'[0-9a-f]{64}', value) for value in source.values())
    assert set(methods) <= set(source) and all(source[name] == value for name, value in methods.items())
    previous = documents['failed_master_sources']
    previous_methods = documents['native11_methods']
    native11_sources = documents['native11_sources']
    assert set(source) - set(previous) == ADDED and not set(previous) - set(source)
    assert {name for name in previous if source[name] != previous[name]} == CHANGED
    assert set(methods) == set(previous_methods) | {HELPER}
    assert {name for name in previous_methods if methods[name] != previous_methods[name]} == CHANGED
    assert all(methods[name] == previous_methods[name] for name in set(previous_methods) - CHANGED)
    runtime = {name: value for name, value in native11_sources.items()
               if name.startswith(('apps/api/src/', 'apps/web/src/', 'packages/')) and '/test/' not in name}
    assert len(runtime) == 461 and all(source[name] == value for name, value in runtime.items())
    assert checkpoint['candidate'] == checkpoint['checkpoint'] == head
    assert checkpoint['comparison_base'] == BASE and checkpoint['clean_owned_tree'] is True
    assert checkpoint['source_count'] == len(source) and checkpoint['source_digest_compact_json'] == compact(source)
    assert checkpoint['method_count'] == len(methods) and checkpoint['method_digest_spaced_json'] == spaced(methods)
    assert checkpoint['no_production_science_TTL_API_schema_dependency_version_changes'] is True
    assert checkpoint['complete_intended_diff_and_newfiles_self_review'] == 'PASS'
    assert checkpoint['new_final_ALL8_success_receipt_created'] is False
    assert CHECKS <= set(checkpoint['checks'])
    assert all(checkpoint['checks'][name]['exit_code'] == 0 for name in CHECKS)
    for key, role in [('architecture', 'software_architecture'), ('performance', 'performance')]:
        assessment = documents[key]
        assert assessment['candidate'] == head and assessment['role'] == role
        assert assessment['verdict'] == 'PASS'
        assert assessment['comparison_base'] == BASE
        assert assessment['source_digest_compact_json'] == compact(source)
        assert assessment['method_digest_spaced_json'] == spaced(methods)
    self_review = documents['self_review']
    assert self_review['candidate'] == head and self_review['comparison_base'] == BASE
    assert self_review['verdict'] == 'PASS' and self_review['complete_intended_diff_and_newfiles'] is True
    assert self_review['source_digest_compact_json'] == compact(source)
    assert self_review['method_digest_spaced_json'] == spaced(methods)
    failure = documents['failed_master_preservation']
    primary = documents['failed_master_primary']
    assert failure['candidate'] == primary['candidate'] == BASE
    assert failure['qualification_PASS'] is False and primary['qualification_PASS'] is False
    assert failure['actual_runner_wait_exit'] == 1
    assert failure['actual_browser_outcome'] == {
        'authored_skipped': 32, 'failed': 1, 'passed': 391, 'report_combined_skipped': 248,
        'top_level_error': 'Maximum-failure fail-fast only', 'unrun': 216}
    assert failure['original_files'] == primary['original_files'] == 4860
    assert failure['raw_original_copy_pairs'] == primary['raw_original_copy_pairs'] == 4
    assert failure['SQL_opened'] is False and primary['SQL_opened'] is False
    assert primary['all_original_file_bodies_and_complete_union_metadata_rehashed'] is True
    versions = documents['protected_versions']
    assert set(versions['five_application_versions'].values()) == {'0.37.0'}
    assert all(source[name] == previous[name] == value for name, value in versions['bodies'].items())
    fixtures = documents['fixtures']
    assert fixtures['fixture_count'] == 44
    producer = 'tests/support/ligand_property_performance_qualification.py'
    assert set(fixtures['scientific_subjects']) & CHANGED == {producer}
    unchanged_science = {name: value for name, value in fixtures['scientific_subjects'].items() if name != producer}
    assert len(unchanged_science) == 156
    assert all(source[name] == value for name, value in unchanged_science.items())
    proof = documents['producer_science_preservation']
    assert proof['candidate'] == head and proof['comparison_base'] == BASE
    assert proof['source_digest_compact_json'] == compact(source)
    assert proof['method_digest_spaced_json'] == spaced(methods)
    assert proof['producer_path'] == producer
    assert proof['old_actual_Gitblob_sha256'] == previous[producer] == previous_methods[producer]
    assert proof['current_producer_sha256'] == source[producer]
    for name in ('baseline_actual_Gitblob_verified', 'exactly_two_observe_publications_normalized',
                 'only_new_tempfile_import_and_atomic_publisher_removed',
                 'entire_module_AST_equal_after_only_declared_normalization',
                 'unrelated_functions_and_classes_AST_exact'):
        assert proof[name] is True
    assert all(source[name] == previous_methods[name] for name in previous_methods
               if name.startswith('tests/fixtures/ligand-properties-performance/'))


def validate_prelaunch(binding: dict[str, Any], prepared_sha256: str,
                       documents: dict[str, Any]) -> None:
    """GO needs actual same-preparation architecture/performance assessments."""
    assert set(documents) == {'software_architecture', 'performance'}
    for role, assessment in documents.items():
        assert assessment['role'] == role and assessment['verdict'] == 'PASS'
        assert assessment['candidate'] == binding['HEAD']
        assert assessment['reviewed_prepared_sha256'] == prepared_sha256
        assert assessment['source_digest_compact_json'] == binding['source_digest']
        assert assessment['method_digest_spaced_json'] == binding['method_digest']
        for name in ('runner_sha256', 'supervisor_sha256', 'guard_sha256',
                     'binding_guard_sha256', 'binding_controls_sha256'):
            assert assessment[name] == binding[name]
