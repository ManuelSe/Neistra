"""Detached file-based transport only; import starts nothing and launcher exit is not a result."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace
import uuid

OUT = Path(__file__).resolve().parent


def digest(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def stamp() -> dict:
    return {"epoch_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns()}


def save(name: str, value: dict, *, exclusive: bool = False) -> None:
    path = OUT / name
    body = json.dumps(value, indent=2, allow_nan=False) + "\n"
    if exclusive:
        with path.open("x") as stream:
            stream.write(body)
        return
    temporary = OUT / (name + ".next")
    with temporary.open("x") as stream:
        stream.write(body)
    temporary.replace(path)


def identity(pid: int, command: list[str] | None = None) -> dict:
    base = Path("/proc") / str(pid)
    before = (base / "stat").read_text()
    fields = before[before.rindex(")") + 2:].split()
    argv = [part.decode() for part in (base / "cmdline").read_bytes().split(b"\0") if part]
    after = (base / "stat").read_text()
    final = after[after.rindex(")") + 2:].split()
    assert fields[19] == final[19] and final[0] != "Z", "Process disappeared/reused/zombie"
    assert command is None or argv == command, "Process command not the exact launched command"
    return {"pid": pid, "start_token": final[19], "state": final[0],
            "pgid": int(final[2]), "session": int(final[3]), "command": argv}


def observe_identity(process, command: list[str], *, parent_pid: int, pgid: int,
                     session: int, observations: list[dict], timeout: float = 3) -> dict:
    """Observe one existing Popen PID; never spawn, signal, restart or infer an exit."""
    assert 0 < timeout <= 3, "Identity observation is bounded by the registration budget"
    pid = process.pid
    deadline = time.monotonic() + timeout
    token = None
    observations.append({"event": "start", "at": stamp(), "pid": pid,
                         "expected": {"parent_pid": parent_pid, "pgid": pgid,
                                      "session": session, "command": command},
                         "timeout_seconds": timeout, "maximum_attempts": 300})
    for attempt in range(300):
        code = process.poll()
        if code is not None:
            observations.append({"event": "terminated", "at": stamp(), "pid": pid,
                                 "actual_returncode": code})
            raise AssertionError("Owned child terminated before identity was established")
        if time.monotonic() >= deadline:
            break
        try:
            raw = (Path("/proc") / str(pid) / "stat").read_text()
            fields = raw[raw.rindex(")") + 2:].split()
            kernel = {"start_token": fields[19], "ppid": int(fields[1]),
                      "pgid": int(fields[2]), "session": int(fields[3])}
        except (OSError, ValueError, IndexError) as error:
            observations.append({"event": "stat-unavailable", "at": stamp(),
                                 "pid": pid, "error": repr(error)})
        else:
            if token is None:
                token = kernel["start_token"]
            if kernel["start_token"] != token:
                observations.append({"event": "replacement", "at": stamp(), "pid": pid,
                                     "pinned_start_token": token, "observed": kernel})
                raise AssertionError("Owned PID start token changed; stop observing replacement")
            if kernel["ppid"] != parent_pid:
                observations.append({"event": "wrong-parent", "at": stamp(), "pid": pid,
                                     "pinned_start_token": token, "observed": kernel})
                raise AssertionError("Owned PID no longer has the expected parent")
            try:
                actual = identity(pid)  # Keep mismatching argv in the observation.
            except (OSError, AssertionError, ValueError) as error:
                observations.append({"event": "identity-unavailable", "at": stamp(),
                                     "pid": pid, "kernel": kernel, "error": repr(error)})
            else:
                observations.append({"event": "observed", "at": stamp(),
                                     "pid": pid, "kernel": kernel, "actual": actual})
                if actual["start_token"] != token:
                    raise AssertionError("Owned PID changed while reading its identity")
                if (actual["command"] == command and actual["pgid"] == kernel["pgid"] == pgid
                        and actual["session"] == kernel["session"] == session
                        and time.monotonic() <= deadline):
                    return {**actual, "ppid": kernel["ppid"]}
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        time.sleep(min(.01, remaining))
    observations.append({"event": "unresolved", "at": stamp(), "pid": pid,
                         "pinned_start_token": token, "actual_returncode": process.poll()})
    raise AssertionError("Owned child identity unresolved within bounded observation")


def reviewed_runner():
    # The root's exact GO pins runner bytes before any execution of that module.
    prepared_body = (OUT / "prepared.json").read_bytes()
    prepared = json.loads(prepared_body)
    go = json.loads((OUT / "go.json").read_text())
    assert go["authorized"] is True and go["binding"] == prepared["binding"]
    assert go["prepared_sha256"] == digest(prepared_body)
    path = OUT / "runner.py"
    source = path.read_bytes()
    assert digest(source) == go["binding"]["runner_sha256"], "Runner module hash differs from GO"
    namespace = {"__name__": "reviewed_transport_runner", "__file__": str(path)}
    exec(compile(source, str(path), "exec"), namespace)
    runner = SimpleNamespace(**namespace)
    runner.validate_go()  # Includes this transport's frozen extra-tool bytes.
    return runner, prepared


def registered_supervisor(reservation_id: str, own: dict) -> None:
    # The detached child may start before the launcher publishes its identity.
    deadline = time.monotonic() + 3
    while True:
        try:
            result = json.loads((OUT / "transport-launch.json").read_text())
            break
        except (FileNotFoundError, json.JSONDecodeError):
            if time.monotonic() >= deadline:
                raise RuntimeError("Launcher registration missing/incomplete; no runner launched") from None
            time.sleep(.01)
    assert result["accepted"] is True and result["reservation_id"] == reservation_id
    registered = result["supervisor_identity"]
    assert all(registered[key] == own[key] for key in ("pid", "start_token", "pgid", "session", "command"))


def launch() -> int:
    runner, prepared = reviewed_runner()
    runner.source_audit()
    assert not runner.WORKSPACE.exists()
    assert not any((OUT / name).exists() for name in ("native", "raw.log", "browser.json",
                                                    "owned-resource-samples.jsonl", "post-cleanup-database-bytes"))
    assert not (OUT / "actual-receipt.json").exists()
    assert all(runner.ports().values()) and not runner.owned_processes()
    reservation_id = uuid.uuid4().hex
    command = [sys.executable, "-B", str(OUT / "supervisor.py"), "supervise", reservation_id]
    reservation = {"scope": "Exclusive one-shot transport reservation; never delete/retry",
                   "reservation_id": reservation_id, "created": stamp(),
                   "prepared_sha256": digest((OUT / "prepared.json").read_bytes()),
                   "go_sha256": digest((OUT / "go.json").read_bytes()),
                   "binding": prepared["binding"], "launcher": identity(os.getpid()),
                   "supervisor_command": command}
    save("transport-reservation.json", reservation, exclusive=True)
    result = {"scope": "Launcher acceptance only; no workflow/profile result",
              "reservation_id": reservation_id, "accepted": False, "started": stamp()}
    try:
        with (OUT / "supervisor.log").open("xb") as log:
            process = subprocess.Popen(command, cwd=runner.ROOT, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT,
                                       close_fds=True, start_new_session=True)
        result.update(accepted=True, supervisor_pid=process.pid)
        result["supervisor_identity_observations"] = []
        try:
            result["supervisor_identity"] = observe_identity(
                process, command, parent_pid=os.getpid(), pgid=process.pid,
                session=process.pid, observations=result["supervisor_identity_observations"])
        except (OSError, AssertionError) as error:
            result["identity_error"] = repr(error)
    except Exception:
        result["launch_error"] = traceback.format_exc()
        save("transport-launch.json", {**result, "finished": stamp()}, exclusive=True)
        raise
    save("transport-launch.json", {**result, "finished": stamp()}, exclusive=True)
    print(json.dumps(result), flush=True)
    return 0  # Acceptance only; primary must observe the independent terminal receipt.


def supervise(reservation_id: str) -> int:
    runner, prepared = reviewed_runner()
    reservation = json.loads((OUT / "transport-reservation.json").read_text())
    assert reservation["reservation_id"] == reservation_id
    assert reservation["binding"] == prepared["binding"]
    assert reservation["prepared_sha256"] == digest((OUT / "prepared.json").read_bytes())
    assert reservation["go_sha256"] == digest((OUT / "go.json").read_bytes())
    own = identity(os.getpid(), reservation["supervisor_command"])
    assert own["pid"] == own["pgid"] == own["session"], "Supervisor is not in its detached session"
    command = [sys.executable, "-B", str(OUT / "runner.py"), "execute"]
    # A second supervise call cannot launch another runner, even after any failure.
    save("transport-child-reservation.json", {"reservation_id": reservation_id,
         "supervisor": own, "runner_command": command, "created": stamp()}, exclusive=True)
    state = {"scope": "Actual runner transport observation; no workflow/profile PASS inference",
             "reservation_id": reservation_id, "supervisor": own, "runner_command": command,
             "state": "REGISTERING", "started": stamp(), "terminal": False,
             "actual_runner_returncode": None, "identity_complete": False}
    save("transport-status.json", state)
    process = None
    try:
        registered_supervisor(reservation_id, own)
        state["state"] = "RUNNING"
        save("transport-status.json", state)
        with (OUT / "runner-output.log").open("xb") as log:
            process = subprocess.Popen(command, cwd=runner.ROOT, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, close_fds=True)
            state["runner_pid"] = process.pid
            state["runner_identity_observations"] = []
            try:
                state["runner_identity"] = observe_identity(
                    process, command, parent_pid=os.getpid(), pgid=os.getpgrp(),
                    session=os.getsid(0), observations=state["runner_identity_observations"])
                state["identity_complete"] = True
            except (OSError, AssertionError) as error:
                state["runner_identity_error"] = repr(error)
            save("transport-status.json", state)
            code = process.wait()
        state.update(state="TERMINAL" if state["identity_complete"] else "ERROR",
                     terminal=True, actual_runner_returncode=code, finished=stamp())
        save("transport-status.json", state)
        if not state["identity_complete"]:
            return 1
        return code if code >= 0 else 128 - code
    except Exception:
        state.update(state="ERROR", error=traceback.format_exc(), finished=stamp())
        # Do not guess an exit, restart, or signal an unknown/live child on transport errors.
        if process is not None:
            state["actual_runner_returncode"] = process.poll()
            state["terminal"] = state["actual_runner_returncode"] is not None
        save("transport-status.json", state)
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("launch", "supervise"))
    parser.add_argument("reservation_id", nargs="?")
    args = parser.parse_args()
    if args.mode == "launch":
        assert args.reservation_id is None
        raise SystemExit(launch())
    assert args.reservation_id is not None
    raise SystemExit(supervise(args.reservation_id))


if __name__ == "__main__":
    main()
