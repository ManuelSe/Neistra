"""Complete release-selected source discovery and frozen-method audits; no process/network I/O."""
from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path, PurePosixPath
from typing import Any

PREFIXES = ("apps", "packages", "tests", "tools", "scripts", "patches")
CONFIGS = {"pyproject.toml", "uv.lock", "package.json", "pnpm-lock.yaml", "pnpm-workspace.yaml",
           "playwright.config.ts", "alembic.ini", ".gitattributes", ".gitignore"}
TOOLS = {directory + name for directory in (
    "docs/assets/viewer-information/", "docs/assets/viewer-measurements/",
    "docs/assets/ligand-designation/", "docs/assets/ligand-properties/") for name in (
    "qualification.py.txt", "release-recipe.py.txt", "versions.py.txt", "production-audit.py.txt",
    "qualification-summary.py.txt", "release-evidence.py.txt")}
IGNORED_DIRS = {".venv", ".molweave", ".neistra", ".neistra-e2e", ".molweave-e2e",
                ".pytest_cache", ".mypy_cache", ".ruff_cache", "__pycache__", "htmlcov",
                "node_modules", ".playwright", "playwright-report", "test-results", ".rebranding"}
IGNORED_FILES = {".coverage", ".env", ".goal_prompt.txt", ".DS_Store"}
D195 = {
    "apps/web/src/ligands/inventoryQualification.ts": "83871bbc2c3cb13837994e24422e0650f689944c38bd79ac46d406e459745c7a",
    "apps/web/src/components/LigandDesignationControls.tsx": "9bfec3ed1694d17a36fb6ea4b34ea71e54f95515ab6979bd1c3e56afd88957fd",
    "apps/web/src/test/ligand-designation-controls.test.tsx": "4ab985295085657148074a39194d6891c6054a05bce4847afa765c9b48b4fa49",
}


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def map_digest(value: dict[str, str]) -> str:
    return digest(json.dumps(value, sort_keys=True).encode())


def relative(name: str) -> PurePosixPath:
    value = PurePosixPath(name)
    assert name and not value.is_absolute() and ".." not in value.parts and str(value) == name
    return value


def regular(path: Path) -> None:
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode) and not path.is_symlink(), f"Nonregular/symlink source: {path}"


def checked_hash(root: Path, name: str) -> str:
    parts = relative(name).parts
    for index in range(1, len(parts)):
        directory = root.joinpath(*parts[:index])
        assert stat.S_ISDIR(directory.lstat().st_mode), f"Nonregular source ancestor: {directory}"
    path = root / name
    regular(path)
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        before = os.fstat(descriptor)
        assert stat.S_ISREG(before.st_mode)
        hasher = hashlib.sha256()
        while block := os.read(descriptor, 1024 * 1024):
            hasher.update(block)
        after = os.fstat(descriptor)
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), f"Source changed while hashing: {name}"
        return hasher.hexdigest()
    finally:
        os.close(descriptor)


def discover(root: Path) -> set[str]:
    """Mirror the existing selected prefixes/config/tools and pinned ignore policy."""
    assert root.resolve() == root and not root.is_symlink()
    names: set[str] = set()

    def visit(directory: Path) -> None:
        assert stat.S_ISDIR(directory.lstat().st_mode)
        for entry in os.scandir(directory):
            path = Path(entry.path)
            name = str(path.relative_to(root))
            metadata = entry.stat(follow_symlinks=False)
            is_directory = stat.S_ISDIR(metadata.st_mode)
            if is_directory and (entry.name in IGNORED_DIRS or entry.name.endswith(".egg-info")
                                 or name in {"apps/web/dist", "apps/web/coverage"}):
                continue
            if entry.name in IGNORED_FILES or entry.name.endswith((".pyc", ".pyo", ".pyd", ".tsbuildinfo")):
                continue
            if is_directory:
                visit(path)
            else:
                assert stat.S_ISREG(metadata.st_mode) and not entry.is_symlink(), f"Nonregular selected source: {name}"
                names.add(name)

    for prefix in PREFIXES:
        directory = root / prefix
        if directory.exists() or directory.is_symlink():
            visit(directory)
    for name in CONFIGS | TOOLS:
        path = root / name
        if path.exists() or path.is_symlink():
            regular(path)
            names.add(name)
    return names


def audit(root: Path, expected: dict[str, str], methods: dict[str, str]) -> dict[str, Any]:
    names = discover(root)
    assert names == set(expected), {"added_selected": sorted(names - set(expected)),
                                    "missing_selected": sorted(set(expected) - names)}
    assert set(methods) <= names
    actual = {name: checked_hash(root, name) for name in sorted(names)}
    changed = {name: {"expected": expected[name], "actual": actual[name]}
               for name in actual if actual[name] != expected[name]}
    assert not changed, {"changed_selected_sources": changed}
    observed_methods = {name: actual[name] for name in methods}
    assert observed_methods == methods, "Frozen method source drift"
    return {"source_count": len(actual), "source_digest": digest(json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()), "sources": actual,
            "method_count": len(methods), "method_digest": map_digest(observed_methods),
            "methods": observed_methods, "no_source_exclusions": True,
            "added_selected_detection": True, "all_selected_regular_no_symlinks": True}
