"""Prepare or explicitly authorize all eight existing native cases. Import starts nothing."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import runpy
import shutil
import signal
import stat
import subprocess
import sys
import threading
import time
import traceback
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).resolve().parent
WORKSPACE = Path('/tmp/neistra159-performance-native12-all8')
DATA = WORKSPACE / 'e2e'
_PIN_PATH = OUT / 'canonical-root-pins.json'
_PIN_BODY = _PIN_PATH.read_bytes() if _PIN_PATH.exists() else None
_PINS = json.loads(_PIN_BODY) if _PIN_BODY is not None else None
DRAFT_HOLD = _PINS is None
PARENT_CANDIDATE = _PINS['HEAD'] if _PINS is not None else None
EXPECTED_DIGEST = _PINS['source_digest'] if _PINS is not None else None
EXPECTED_METHOD_DIGEST = _PINS['method_digest'] if _PINS is not None else None
GUARD_SHA = '60f3a1ff745d5f5916cbb98853325383b2a0b1743705bfc300c1c66562ca5a41'
ROOT_PINS_SHA = hashlib.sha256(_PIN_BODY).hexdigest() if _PIN_BODY is not None else None
ROOT_RECEIPT_SHA = _PINS['root_receipt_sha256'] if _PINS is not None else None
PORTS = (8540,8541,5540)
UUID_DIRECTORY = re.compile(r'(?:chromium|mobile-chromium)-[0-9a-f-]{36}')
RESOURCE_BYTE_CAP = 128*1024*1024
RESOURCE_RECORD_CAP = 200_000

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def write(name: str, data: Any) -> None:
    (OUT / name).write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')

def authoritative_head() -> dict[str, str]:
    pointer = (ROOT / '.git').read_text().strip()
    assert pointer.startswith('gitdir: ')
    gitdir = Path(pointer.removeprefix('gitdir: ')).resolve()
    head = (gitdir / 'HEAD').read_text().strip()
    if head.startswith('ref: '):
        ref = head.removeprefix('ref: ')
        assert ref.startswith('refs/heads/') and '..' not in Path(ref).parts
        common = (gitdir / (gitdir / 'commondir').read_text().strip()).resolve()
        loose = common / ref
        if loose.is_file():
            commit = loose.read_text().strip()
        else:
            matches = [line.split()[0] for line in (common / 'packed-refs').read_text().splitlines()
                       if line and not line.startswith(('#', '^')) and line.split()[1] == ref]
            assert len(matches) == 1
            commit = matches[0]
    else:
        ref, commit = 'detached', head
    assert re.fullmatch(r'[0-9a-f]{40}', commit)
    return {'commit': commit, 'ref': ref, 'HEAD_text': head,
            'scope': 'Authoritative worktree HEAD/ref metadata read directly; no Git command/status/remote claim'}

def environment() -> tuple[dict[str, str], dict[str, str], list[str]]:
    unset = sorted(key for key in os.environ if key.startswith(('NEISTRA_', 'MOLWEAVE_')) or key == 'DATABASE_URL')
    inherited = {key: value for key, value in os.environ.items() if key not in unset}
    overrides = {
        'PYTHONPATH': os.pathsep.join(str(ROOT / name) for name in ('apps/api/src', 'packages/neistra_core/src', 'packages/neistra_demo_plugin/src', '.')),
        'NEISTRA_E2E_DATA_DIR': str(DATA),
        'NEISTRA_E2E_API_PORT': '8540',
        'NEISTRA_E2E_WORKER_PORT': '8541',
        'NEISTRA_E2E_WEB_PORT': '5540',
        'NEISTRA_PROPERTY_WORKER_TRACE': str(DATA / 'qualification/worker-turns.jsonl'),
        'NEISTRA_PERFORMANCE': '0',
        'PLAYWRIGHT_BROWSERS_PATH': '/datadisk/dev/neistra/.playwright',
        'PLAYWRIGHT_JSON_OUTPUT_FILE': str(OUT / 'browser.json'),
    }
    inherited.update(overrides)
    return inherited, overrides, unset

def ports() -> dict[str, bool]:
    # Zero network traffic: read actual kernel TCP/TCP6 listening sockets.
    listening = set()
    for name in ('tcp', 'tcp6'):
        for line in (Path('/proc/net') / name).read_text().splitlines()[1:]:
            fields = line.split()
            if fields[3] == '0A':
                listening.add(int(fields[1].rsplit(':', 1)[1], 16))
    return {str(port): port not in listening for port in PORTS}

def evidence_directories() -> set[str]:
    # The actual native test helper owns UUID roots here, separately from this kit.
    parent = ROOT / '.issue-11-evidence/issue159-performance'
    if not parent.exists():
        return set()
    assert parent.is_dir() and not parent.is_symlink()
    return {str(path) for path in parent.iterdir()
            if path.is_dir() and not path.is_symlink() and UUID_DIRECTORY.fullmatch(path.name)}

def owned_processes() -> list[dict[str, Any]]:
    """Identify only this unique owned experiment, without exposing unrelated env."""
    expected = ("NEISTRA_E2E_DATA_DIR=" + str(DATA)).encode()
    rows = []
    for directory in Path("/proc").iterdir():
        if not directory.name.isdigit():
            continue
        try:
            if expected not in (directory / "environ").read_bytes().split(b"\0"):
                continue
            stat = (directory / "stat").read_text()
            fields = stat[stat.rindex(")") + 2 :].split()
            if fields[0] == "Z":
                continue
            rows.append({"pid": int(directory.name), "pgid": int(fields[2]),
                         "session": int(fields[3]), "start_token": fields[19],
                         "command": [part.decode(errors="replace") for part in
                                     (directory / "cmdline").read_bytes().split(b"\0") if part]})
        except (OSError, ValueError):
            continue
    return rows

def interrupt(reason: str) -> None:
    """Signal the actual owned Playwright CLI so its reporter/teardown can finish."""
    assert not (OUT / "interruption-request.json").exists()
    receipt = json.loads((OUT / "actual-receipt.json").read_text())
    assert not receipt.get("runner_observation_complete", False)
    owned = owned_processes()
    candidates = [row for row in owned if len(row["command"]) > 2
                  and "playwright" in row["command"][1] and row["command"][2] == "test"]
    assert len(candidates) == 1, "No unique positively owned Playwright CLI; do not signal guesses"
    target = candidates[0]
    current = Path(f"/proc/{target['pid']}/stat").read_text()
    fields = current[current.rindex(")") + 2 :].split()
    assert fields[19] == target["start_token"]
    write("interruption-request.json", {"scope": "Explicit interruption, never a completed timeout or measured case",
          "utc": datetime.now(UTC).isoformat(), "reason": reason,
          "signal": "SIGINT to actual Playwright CLI only; corepack wrapper left to observe exit",
          "target": target, "positively_owned_processes_at_interrupt": owned})
    os.kill(target["pid"], signal.SIGINT)


def file_sha(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024*1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def map_digest(value: dict[str, str]) -> str:
    return sha(json.dumps(value, sort_keys=True).encode())


def source_map_digest(value: dict[str, str]) -> str:
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def validate_root_qualification(source, methods, pins, checkpoint) -> None:
    documents = {key: json.loads((OUT / name).read_text())
                 for key, name in pins['documents'].items()}
    namespace = runpy.run_path(str(OUT / 'binding_guard.py'), run_name='native12_binding_guard')
    namespace['validate'](source, methods, pins, checkpoint, documents)


def pinned_inputs() -> tuple[dict[str, str], dict[str, str]]:
    """Bind actual committed C1, exact correction, assessments and all tool bodies."""
    assert DRAFT_HOLD is False, 'HOLD: actual clean C1 and scoped receipts have not been sealed'
    assert ROOT == Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
    assert OUT == ROOT / '.issue-11-evidence/issue159-native12-preparation1'
    assert file_sha(OUT / 'source_guard.py') == GUARD_SHA
    assert file_sha(OUT / 'canonical-root-pins.json') == ROOT_PINS_SHA
    pins = json.loads((OUT / 'canonical-root-pins.json').read_text())
    head = authoritative_head()
    assert head['commit'] == PARENT_CANDIDATE == pins['HEAD']
    assert head['ref'] == pins['ref'] == 'refs/heads/fix/issue-159-observer-snapshots'
    assert file_sha(OUT / pins['root_receipt']) == ROOT_RECEIPT_SHA
    for name, expected in pins['files'].items():
        assert file_sha(OUT / name) == expected, name
    source = json.loads((OUT / 'expected-sources.json').read_text())
    methods = json.loads((OUT / 'expected-methods.json').read_text())
    assert len(source) == pins['source_count'] and source_map_digest(source) == EXPECTED_DIGEST
    assert len(methods) == pins['method_count'] and map_digest(methods) == EXPECTED_METHOD_DIGEST
    assert all(source[name] == value for name, value in methods.items())
    guard = runpy.run_path(str(OUT / 'source_guard.py'), run_name='native12_transport_guard')
    for name, expected in json.loads((OUT / 'extra-tools.json').read_text()).items():
        assert guard['checked_hash'](OUT, name) == expected, name
    validate_root_qualification(source, methods, pins, json.loads((OUT / pins['root_receipt']).read_text()))
    return source, methods


def source_audit() -> dict[str, Any]:
    source,methods=pinned_inputs()
    return runpy.run_path(str(OUT/'source_guard.py'),run_name='native7_guard')['audit'](ROOT,source,methods)


def command() -> list[str]:
    # Both configured profiles and all four existing cases/profile; no grep/project filter.
    return ['corepack','pnpm','exec','playwright','test',
            'tests/e2e/ligand-properties-performance.spec.ts','--reporter=list,json',
            '--workers=1','--retries=0','--max-failures=1','--output',str(OUT/'native')]


def cgroup_facts(pid: int) -> dict[str, Any]:
    """Resolve actual v2 mount/root; preserve raw facts if a namespace prevents resolution."""
    base=Path('/proc')/str(pid)
    facts:dict[str,Any]={'pid':pid}
    try:
        facts['identity']=(base/'cgroup').read_text()
        rows=[line.split(':',2) for line in facts['identity'].splitlines()]
        member=next((row[2] for row in rows if row[:2]==['0','']),None)
        mounts=[]
        for line in (base/'mountinfo').read_text().splitlines():
            left,sep,right=line.partition(' - ')
            if sep and right.split()[0]=='cgroup2':
                fields=left.split();mounts.append({'root':fields[3],'mount':fields[4]})
        facts['v2_mounts']=mounts; facts['v2_member']=member
        facts['cpu_max_candidates']=[]
        if member is not None:
            for mount in mounts:
                # Relative membership must be contained in its declared mount root.
                root=Path(mount['root']);member_path=Path(member)
                try:relative=member_path.relative_to(root)
                except ValueError:continue
                if '..' in relative.parts:continue
                actual=Path(mount['mount'])/relative/'cpu.max'
                candidate={'path':str(actual),'exists':actual.is_file()}
                if actual.is_file():candidate['value']=actual.read_text().strip()
                facts['cpu_max_candidates'].append(candidate)
                facts.setdefault('cpu_max_ancestors',[])
                for parent in (actual.parent,*actual.parent.parents):
                    if not parent.is_relative_to(Path(mount['mount'])):break
                    quota=parent/'cpu.max'
                    if quota.is_file():facts['cpu_max_ancestors'].append({'path':str(quota),'value':quota.read_text().strip()})
        # Namespace roots may expose the current cgroup at the mountpoint despite an
        # inaccessible ancestor membership. Record this explicitly, never call it resolved.
        if not any(row.get('exists') for row in facts['cpu_max_candidates']):
            facts['namespace_mount_root_observations']=[]
            for mount in mounts:
                path=Path(mount['mount'])/'cpu.max'
                if path.is_file():facts['namespace_mount_root_observations'].append(
                    {'path':str(path),'value':path.read_text().strip(),
                     'scope':'Visible mount root only; membership resolution unavailable'})
    except OSError as error:facts['unavailable']=repr(error)
    return facts


def pid_metrics(row: dict[str, Any]) -> dict[str, Any]:
    result=dict(row);pid=row['pid'];base=Path('/proc')/str(pid)
    try:
        text=(base/'stat').read_text();fields=text[text.rindex(')')+2:].split()
        assert fields[19]==row['start_token'],'PID identity changed'
        result.update(user_cpu_ticks=int(fields[11]),system_cpu_ticks=int(fields[12]),
                      rss_bytes=int(fields[21])*os.sysconf('SC_PAGE_SIZE'),state=fields[0],
                      affinity_cpus=sorted(os.sched_getaffinity(pid)))
        result['cgroup']=cgroup_facts(pid)
    except (OSError,AssertionError,ValueError) as error:result['measurement_unavailable']=repr(error)
    return result


def context() -> dict[str, Any]:
    return {'utc':datetime.now(UTC).isoformat(),'monotonic_ns':time.monotonic_ns(),
            'uname':dict(zip(('system','node','release','version','machine'),os.uname(),strict=True)),
            'python':sys.version,'cpu_count':os.cpu_count(),
            'cpu_model':next((line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),None),
            'wrapper_affinity_cpus':sorted(os.sched_getaffinity(0)),
            'wrapper_cgroup':cgroup_facts(os.getpid()),'clock_ticks_per_second':os.sysconf('SC_CLK_TCK'),
            'load_average':os.getloadavg(),'loadavg_raw':Path('/proc/loadavg').read_text(),
            'meminfo_raw':Path('/proc/meminfo').read_text(),
            'inherited_thread_settings':{key:os.environ.get(key) for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')},
            'scope':'Shared-host portable observation; no exclusive CPU/cold OS/strict-reference timing claim; no affinity/quota/thread changes'}


def files_under(path: Path) -> dict[str, Any]:
    result:dict[str,Any]={}
    if not path.exists():return result
    for current,dirs,files in os.walk(path,followlinks=False):
        for name in list(dirs):
            directory=Path(current)/name
            if directory.is_symlink():
                result[str(directory.relative_to(path))]={'symlink_target':os.readlink(directory),'followed':False};dirs.remove(name)
        for name in files:
            file=Path(current)/name;relative=str(file.relative_to(path));mode=file.lstat().st_mode
            if stat.S_ISLNK(mode):result[relative]={'symlink_target':os.readlink(file),'followed':False}
            elif stat.S_ISREG(mode):result[relative]={'bytes':file.stat().st_size,'sha256':file_sha(file)}
            else:result[relative]={'nonregular':True,'mode':mode}
    return result


def archive_sources(name: str, expected: dict[str,str]) -> dict[str,Any]:
    path=OUT/name
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as archive:
        for relative,digest in sorted(expected.items()):
            # Full selected regular-file audit has already rejected links/added paths.
            data=(ROOT/relative).read_bytes();assert sha(data)==digest
            archive.writestr(relative,data)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':file_sha(path),'source_count':len(expected)}


def archive_store_before_sql() -> dict[str, Any]:
    """No sqlite3 import, connection, backup, checkpoint or diagnostic read precedes byte copies."""
    target=OUT/'post-cleanup-database-bytes';target.mkdir()
    receipt:dict[str,Any]={'started_utc':datetime.now(UTC).isoformat(),'started_monotonic_ns':time.monotonic_ns(),
           'method':'Raw DB/WAL/SHM copies after positive service cleanup; no SQLite connection/diagnostic SQL',
           'originals_retained':True,'files':{}}
    for name in ('neistra.db','neistra.db-wal','neistra.db-shm','molweave.db','molweave.db-wal','molweave.db-shm'):
        source=DATA/name
        if not source.exists():receipt['files'][name]={'exists':False};continue
        assert stat.S_ISREG(source.lstat().st_mode) and not source.is_symlink()
        before=source.stat();destination=target/name
        with source.open('rb') as src,destination.open('xb') as dst:shutil.copyfileobj(src,dst,1024*1024)
        after=source.stat()
        assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
        digest=file_sha(destination);assert digest==file_sha(source)
        receipt['files'][name]={'exists':True,'bytes':before.st_size,'sha256':digest,'copy':str(destination)}
    receipt['finished_utc']=datetime.now(UTC).isoformat();write('database-byte-archive.json',receipt)
    return receipt


def binding() -> dict[str, Any]:
    source,methods=pinned_inputs()
    controls=json.loads((OUT/'binding-controls-result.json').read_text())
    assert controls['successful'] is True and controls['negative_cases'] >= 20
    assert controls['failures']==controls['errors']==controls['skipped']==0
    assert controls['binding_guard_sha256']==file_sha(OUT/'binding_guard.py')
    assert controls['controls_source_sha256']==file_sha(OUT/'binding-controls.py')
    env,overrides,_=environment()
    assert env.get('MOLWEAVE_E2E_DATA_DIR') is None
    return {'root':str(ROOT),'HEAD':PARENT_CANDIDATE,'runner_sha256':file_sha(Path(__file__)),
            'guard_sha256':GUARD_SHA,'canonical_root_pins_sha256':ROOT_PINS_SHA,
            'root_receipt_sha256':ROOT_RECEIPT_SHA,
            'source_count':len(source),'source_digest':source_map_digest(source),
            'method_count':len(methods),'method_digest':map_digest(methods),
            'expected_sources_file_sha256':file_sha(OUT/'expected-sources.json'),
            'expected_methods_file_sha256':file_sha(OUT/'expected-methods.json'),
            'command':command(),'environment_overrides':overrides,'workspace':str(WORKSPACE),
            'selected_cases':8,'profiles':['chromium','mobile-chromium'],'bulk_1000_entry_cohorts':4,
            'extra_tools_sha256':file_sha(OUT/'extra-tools.json'),
            'binding_controls_sha256':file_sha(OUT/'binding-controls-result.json'),
            'supervisor_sha256':file_sha(OUT/'supervisor.py'),
            'binding_guard_sha256':file_sha(OUT/'binding_guard.py')}


def prepare() -> None:
    assert not (OUT/'prepared.json').exists(),'Preserve prior preparation'
    assert not WORKSPACE.exists(),'Fresh workspace required'
    assert all(ports().values()) and not owned_processes(),'Ports/ownership must be clear; do not stop unrelated processes'
    audit=source_audit();head=authoritative_head();assert head['commit']==PARENT_CANDIDATE
    source_archive=archive_sources('source-preparation.zip',audit['sources'])
    write('source-audit-preparation.json',audit)
    proof=binding()
    write('prepared.json',{'scope':'Preparation only: no services, browser workflows or performance measurements executed',
         'binding':proof,'authoritative_HEAD':head,'source_archive':source_archive,
         'methods':audit['methods'],'source_exclusions':[],'host':context(),'ports_unused':ports(),
         'canonical_database_expected':str(DATA/'neistra.db'),'workspace_created':WORKSPACE.exists(),
         'trace_policy':'Frozen retain-on-failure configuration, unchanged 128MiB/200k record/100k worker-turn bounds',
         'coactivity':'Actual launch snapshot required; shared host, no strict/exclusive claim. Preparation does not infer another gate current state.',
         'user_visible_workload':{'profiles':2,'cold_contexts_per_profile':5,'real_paired_edit_and_Undo_per_profile':20,
              'cancellation_cases':2,'repeated_bulk_1000_cases':2,'distinct_bulk_1000_cases':2,
              'fixture_preflight':'Existing actual-source read-only 30s setup preflight per editable target, frozen44SDFs; setup recorded outside edit latency'},
         'planning_runtime_estimate_unmeasured':'No completion-time claim; unchanged case limits and stop-after-first-failure1 remain',
         'timing_policy':'NEISTRA_PERFORMANCE=0 portable correctness; original100ms/2s/5s targets retained/reported, priorbaseline misses retained. Absolute timing qualification remains opt-in reference-host; candidate timing unmeasured',
         'observation_overhead':'External wrapper /proc sampling every2s with real monotonic timestamps, per-PID CPUticks/affinity/cgroup/RSS; included in timings; no extra SQL/native calculations',
         'resource_capture_caps':{'bytes':RESOURCE_BYTE_CAP,'records':RESOURCE_RECORD_CAP,'overflow':'Explicit incomplete evidence/failure; no silent drops'},
         'post_cleanup_order':['positive owned-process and dedicated-port cleanup proof','raw DB/WAL/SHM byte archive without diagnostic SQL','complete source/declared-method postguard and source archive','retained store/native/new UUID inventories'],
         'launch_status':'AWAITING ROOT GO plus independent preflight','completion_policy':'Detached supervisor actual Popen.wait runner exit must be observed separately from launcher acceptance; original eight outcomes/source/resource/cleanup/raw archive and root readback still mandatory'})
    write('go-template.json',{'authorized':False,'authorization':'Root must explicitly authorize the exact binding after independent preflight',
          'prepared_sha256':file_sha(OUT/'prepared.json'),'binding':proof,
          'prelaunch_assessments':{}})
    print('PREPARED ALL8; no services/browser launched',flush=True)


def validate_go() -> dict[str,Any]:
    prepared=json.loads((OUT/'prepared.json').read_text());go=json.loads((OUT/'go.json').read_text())
    actual=binding()
    assert prepared['binding']==actual,'Prepared no longer matches literal canonical pins/runner'
    assert go['authorized'] is True and go['binding']==actual,'Explicit exact root GO missing or stale'
    assert go['prepared_sha256']==file_sha(OUT/'prepared.json'),'GO must bind exact prepared bytes'
    assert authoritative_head()==prepared['authoritative_HEAD']
    prelaunch = {}
    for role, filename in [('software_architecture', 'prelaunch-architecture-assessment.json'),
                           ('performance', 'prelaunch-performance-assessment.json')]:
        binding_record = go['prelaunch_assessments'][role]
        assert binding_record['file'] == filename
        assert file_sha(OUT / filename) == binding_record['sha256']
        prelaunch[role] = json.loads((OUT / filename).read_text())
    guard = runpy.run_path(str(OUT / 'binding_guard.py'), run_name='native12_prelaunch_guard')
    guard['validate_prelaunch'](actual, file_sha(OUT / 'prepared.json'), prelaunch)
    return prepared


def resource_observer(stop: threading.Event, state: dict[str,Any]) -> None:
    path=OUT/'owned-resource-samples.jsonl';written=0;records=0
    try:
        with path.open('xb') as handle:
            while True:
                row={'utc':datetime.now(UTC).isoformat(),'monotonic_ns':time.monotonic_ns(),
                     'load_average':os.getloadavg(),'owned':[pid_metrics(row) for row in owned_processes()]}
                data=(json.dumps(row,allow_nan=False)+'\n').encode()
                if written+len(data)>RESOURCE_BYTE_CAP or records>=RESOURCE_RECORD_CAP:
                    raise RuntimeError('Explicit wrapper resource evidence overflow; measurement incomplete')
                handle.write(data);handle.flush();written+=len(data);records+=1
                if stop.wait(2):break
        state.update(complete=True,bytes=written,records=records)
    except BaseException:
        state.update(complete=False,error=traceback.format_exc(),bytes=written,records=records)
        write('owned-resource-samples.incomplete.json',state)


def execute() -> int:
    prepared=validate_go()
    assert not (OUT/'actual-receipt.json').exists() and not WORKSPACE.exists()
    before_audit=source_audit();write('source-audit-before.json',before_audit)
    assert all(ports().values()) and not owned_processes()
    env,overrides,unset=environment();old_dirs=evidence_directories();WORKSPACE.mkdir()
    state:dict[str,Any]={'scope':'All8 existing portable exploratory cases; completion is not PASS or release/prerequisite delivery',
       'binding':binding(),'started_utc':datetime.now(UTC).isoformat(),'host_before':context(),
       'coactivity':prepared['coactivity'],'authoritative_HEAD_before':authoritative_head(),
       'environment_overrides':overrides,'removed_environment_names':unset,
       'prior_harness_directories':sorted(old_dirs),'workspace':str(WORKSPACE),
       'source_before':before_audit['sources'],'methods_before':before_audit['methods'],
       'complete':False,'runner_observation_complete':False}
    write('actual-receipt.json',state)
    stop=threading.Event();observation:dict[str,Any]={};observer=threading.Thread(target=resource_observer,args=(stop,observation),daemon=True)
    observer.start()
    code=None;launch_error=None
    try:
        with (OUT/'raw.log').open('xb') as log:
            process=subprocess.Popen(command(),cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
            state.update(actual_child_pid=process.pid,actual_child_process_group=os.getpgid(process.pid));write('actual-receipt.json',state)
            assert process.stdout is not None
            for line in process.stdout:
                log.write(line);log.flush();print(line.decode(errors='replace').rstrip(),flush=True)
            code=process.wait()
    except BaseException:
        launch_error=traceback.format_exc()
    finally:
        stop.set();observer.join(timeout=10)
    # Preserve real cleanup result. Never kill unknown processes or mask leftovers.
    for _ in range(50):
        if all(ports().values()) and not owned_processes():break
        time.sleep(.1)
    leftovers=owned_processes();port_state=ports()
    cleanup={'utc':datetime.now(UTC).isoformat(),'monotonic_ns':time.monotonic_ns(),
             'positively_owned_processes_remaining':leftovers,'ports_unused':port_state,
             'complete':not leftovers and all(port_state.values())}
    write('cleanup-before-store-archive.json',cleanup)
    # This raw copy is the FIRST post-cleanup store operation. No SQLite diagnostics anywhere in runner.
    archive=None;archive_error=None
    if cleanup['complete']:
        try:archive=archive_store_before_sql()
        except BaseException:archive_error=traceback.format_exc();write('database-byte-archive-error.json',{'error':archive_error})
    else:
        archive_error='Cleanup incomplete; raw originals retained, no stable-store claim or SQL permitted'
        write('database-byte-archive-error.json',{'error':archive_error})
    guard_error=None;after_audit={}
    try:
        after_audit=source_audit();write('source-audit-after.json',after_audit)
        state['source_archive_after']=archive_sources('source-after.zip',after_audit['sources'])
    except BaseException:
        guard_error=traceback.format_exc();write('source-audit-after-error.json',{'error':guard_error,'complete':False})
    new_dirs=sorted(evidence_directories()-old_dirs)
    write('retained-store-inventory.json',files_under(WORKSPACE))
    write('retained-native-inventory.json',files_under(OUT/'native'))
    write('retained-workflow-inventories.json',{path:files_under(Path(path)) for path in new_dirs})
    interrupted=(OUT/'interruption-request.json').exists()
    state.update(exit_code=code,launch_error=launch_error,interrupted=interrupted,
        qualification_status='INTERRUPTED' if interrupted else ('LAUNCH_OR_OBSERVATION_ERROR' if launch_error else 'ORDINARY_COMPLETION'),
        complete=not interrupted and launch_error is None,runner_observation_complete=True,
        finished_utc=datetime.now(UTC).isoformat(),source_after=after_audit.get('sources'),
        methods_after=after_audit.get('methods'),source_unchanged=before_audit.get('sources')==after_audit.get('sources'),
        complete_source_guard_error=guard_error,authoritative_HEAD_after=authoritative_head(),host_after=context(),
        resource_observer=observation,resource_observer_alive=observer.is_alive(),
        database_byte_archive=archive,database_byte_archive_error=archive_error,
        cleanup=cleanup,new_harness_directories=new_dirs,
        canonical_database_exists=(DATA/'neistra.db').is_file(),legacy_database_exists=(DATA/'molweave.db').exists(),
        worker_trace_exists=(DATA/'qualification/worker-turns.jsonl').is_file(),
        worker_trace_incomplete=(DATA/'qualification/worker-turns.jsonl.incomplete.json').exists(),
        raw_log_sha256=file_sha(OUT/'raw.log') if (OUT/'raw.log').exists() else None)
    if (OUT/'browser.json').exists():
        try:state['browser_stats']=json.loads((OUT/'browser.json').read_text()).get('stats')
        except (OSError,ValueError):state['browser_report_error']=traceback.format_exc()
    write('actual-receipt.json',state)
    assert launch_error is None,launch_error
    assert cleanup['complete'],'Owned service cleanup incomplete'
    assert archive_error is None,'Immediate DB/WAL/SHM archive incomplete'
    assert guard_error is None and state['source_unchanged'],'Complete source/method guard failed'
    assert state['authoritative_HEAD_after']==state['authoritative_HEAD_before'],'HEAD changed'
    assert observation.get('complete') and not observer.is_alive(),'Resource evidence incomplete'
    assert not state['legacy_database_exists'],'Canonical run used unexpected legacy database'
    assert state['canonical_database_exists'],'Canonical database missing'
    assert state['worker_trace_exists'] and not state['worker_trace_incomplete'],'Mandatory worker trace missing/incomplete'
    assert code is not None
    return code


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('prepare','execute','interrupt'))
    parser.add_argument('--reason',default='Parent-directed interruption')
    args=parser.parse_args()
    if args.mode=='prepare':prepare()
    elif args.mode=='interrupt':interrupt(args.reason)
    else:raise SystemExit(execute())


if __name__=='__main__':main()
