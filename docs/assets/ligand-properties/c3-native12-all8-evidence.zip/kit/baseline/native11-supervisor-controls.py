"""Affected native11 supervisor controls; toy fixtures plus two tiny owned Python exits.

No application, molecular calculation, service, browser or SQL is launched.
"""
from contextlib import contextmanager
from pathlib import Path
import copy
import json
import runpy
import subprocess
import sys
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

OUT = Path(__file__).resolve().parent


class Clock:
    def __init__(self): self.value = 0
    def now(self): return self.value
    def sleep(self, duration): self.value += duration


class Process:
    pid = 123456789
    def __init__(self, code=None): self.code = code; self.waits = 0
    def poll(self): return self.code
    def wait(self): self.waits += 1; return self.code


@contextmanager
def kernel(namespace, frames, *, clock=None):
    clock = clock or Clock()
    globals_ = namespace['observe_identity'].__globals__
    reads = {'stat': 0, 'identity': 0}
    original_read = Path.read_text
    def frame(): return frames[min(int(round(clock.value/.01)), len(frames)-1)]
    def read(path, *args, **kwargs):
        if path != Path('/proc')/str(Process.pid)/'stat':
            return original_read(path,*args,**kwargs)
        reads['stat'] += 1
        current = frame()
        if current.get('stat_error'): raise FileNotFoundError('synthetic unavailable stat')
        fields = ['S',str(current['ppid']),str(current['pgid']),str(current['session'])]
        fields += ['0']*15+[current['start_token']]
        return f'{Process.pid} (synthetic owned child) '+ ' '.join(fields)
    def identify(pid, command=None):
        if pid != Process.pid:
            return {"pid":pid,"start_token":"synthetic-supervisor","state":"S",
                    "pgid":pid,"session":pid,"command":command or ["synthetic-launcher"]}
        assert command is None
        reads['identity'] += 1
        current = frame()
        if current.get('identity_error'): raise OSError('synthetic unavailable identity')
        clock.value += current.get('identity_delay',0)
        return {key:copy.deepcopy(current[key]) for key in
                ('pid','start_token','pgid','session','state','command')}
    with (patch.object(Path,'read_text',read),
          patch.object(globals_['time'],'monotonic',clock.now),
          patch.object(globals_['time'],'sleep',clock.sleep),
          patch.dict(globals_,{'identity':identify,'stamp':lambda:{'synthetic_time':clock.value}})):
        yield clock, reads


def snapshot(command, *, parent=77, group=88, session=88, token='123'):
    return {'pid':Process.pid,'ppid':parent,'pgid':group,'session':session,
            'start_token':token,'state':'S','command':command}


class IdentityControls(unittest.TestCase):
    def setUp(self):
        self.ns=runpy.run_path(str(OUT/'supervisor.py'),run_name='synthetic_private_transport')
        self.command=['synthetic-python','synthetic-owned-command']

    def observe(self, process, observations, **kwargs):
        return self.ns['observe_identity'](process,self.command,parent_pid=77,
                                          pgid=88,session=88,observations=observations,**kwargs)

    def test_delayed_exact_argv_at_both_parent_group_contexts(self):
        for parent,group,session in [(77,Process.pid,Process.pid),(77,88,88)]:
            with self.subTest(group=group):
                first=snapshot(['initial observed different argv'],parent=parent,group=group,session=session)
                final=snapshot(self.command,parent=parent,group=group,session=session)
                observations=[]
                with kernel(self.ns,[first,final]) as (clock,reads):
                    actual=self.ns['observe_identity'](Process(),self.command,parent_pid=parent,
                        pgid=group,session=session,observations=observations)
                self.assertEqual(actual['command'],self.command)
                self.assertEqual(actual['ppid'],parent)
                self.assertEqual(observations[1]['actual']['command'],first['command'])
                self.assertEqual(clock.value,.01)
                self.assertEqual(reads['identity'],2)

    def test_delayed_group_session_requires_exact_match(self):
        observations=[]
        with kernel(self.ns,[snapshot(self.command,group=99,session=99),snapshot(self.command)]):
            actual=self.observe(Process(),observations)
        self.assertEqual((actual['pgid'],actual['session']),(88,88))
        self.assertEqual(observations[1]['actual']['session'],99)

    def test_initial_errors_remain_in_observations(self):
        for field,event in [('stat_error','stat-unavailable'),('identity_error','identity-unavailable')]:
            with self.subTest(field=field):
                observations=[]
                with kernel(self.ns,[{**snapshot(self.command),field:True},snapshot(self.command)]):
                    self.observe(Process(),observations)
                self.assertEqual(observations[1]['event'],event)
                self.assertIn('error',observations[1])

    def test_replacement_stops_before_reading_replacement_argv(self):
        observations=[]
        with kernel(self.ns,[snapshot(['initial different argv']),snapshot(self.command,token='replacement')]) as (_,reads):
            with self.assertRaisesRegex(AssertionError,'start token changed'):
                self.observe(Process(),observations)
        self.assertEqual(reads['identity'],1)
        self.assertEqual(observations[-1]['event'],'replacement')

    def test_wrong_parent_stops_immediately(self):
        observations=[]
        with kernel(self.ns,[snapshot(self.command,parent=78)]) as (_,reads):
            with self.assertRaisesRegex(AssertionError,'expected parent'):
                self.observe(Process(),observations)
        self.assertEqual(reads['identity'],0)
        self.assertEqual(observations[-1]['event'],'wrong-parent')

    def test_unresolved_identity_stops_at_deadline(self):
        observations=[]
        with kernel(self.ns,[snapshot(['always different argv'])]) as (clock,_):
            with self.assertRaisesRegex(AssertionError,'bounded observation'):
                self.observe(Process(),observations,timeout=.035)
        self.assertLessEqual(clock.value,.035)
        self.assertLessEqual(len(observations),302)
        self.assertEqual(observations[-1]['event'],'unresolved')
        self.assertIsNone(observations[-1]['actual_returncode'])

    def test_early_actual_zero_nonzero_and_signal_codes_are_recorded(self):
        for code in (0,7,-15):
            with self.subTest(code=code):
                observations=[]
                with kernel(self.ns,[snapshot(self.command)]) as (_,reads):
                    with self.assertRaisesRegex(AssertionError,'terminated'):
                        self.observe(Process(code),observations)
                self.assertEqual(observations[-1]['actual_returncode'],code)
                self.assertEqual(reads['stat'],0)

    def fixture(self,name,*,registration=True):
        base=OUT/'synthetic-supervisor-controls';base.mkdir(exist_ok=True)
        folder=base/name;folder.mkdir()
        token='synthetic-reservation'
        prepared={'scope':'synthetic fixture only','binding':{'runner_sha256':'synthetic-only'}}
        prepared_body=json.dumps(prepared).encode()
        go_body=b'{"scope":"inert synthetic fixture, not actual GO"}\n'
        (folder/'prepared.json').write_bytes(prepared_body)
        (folder/'go.json').write_bytes(go_body)
        command=['synthetic-supervisor',token]
        own={'pid':222,'start_token':'synthetic-supervisor','state':'S','pgid':222,'session':222,'command':command}
        reservation={'reservation_id':token,'binding':prepared['binding'],
                     'prepared_sha256':self.ns['digest'](prepared_body),
                     'go_sha256':self.ns['digest'](go_body),'supervisor_command':command}
        (folder/'transport-reservation.json').write_text(json.dumps(reservation))
        if registration:
            (folder/'transport-launch.json').write_text(json.dumps({
                'accepted':True,'reservation_id':token,'supervisor_identity':own}))
        runner=SimpleNamespace(ROOT=folder,WORKSPACE=folder/'synthetic-unused-runtime',
            source_audit=lambda:{},ports=lambda:{'synthetic':True},owned_processes=lambda:[])
        return folder,token,runner,prepared

    def test_runner_capture_delayed_or_early_preserves_exact_wait_and_one_shot(self):
        for code in (0,7,-15):
            for early in (False,True):
                with self.subTest(code=code,early=early):
                    folder,token,runner,prepared=self.fixture(f'runner-{code}-early-{early}')
                    globals_=self.ns['supervise'].__globals__
                    command=[sys.executable,'-B',str(folder/'runner.py'),'execute']
                    process=Process(code)
                    if not early:process.poll=lambda:None
                    calls=[]
                    def spawned(actual,**kwargs):
                        self.assertEqual(actual,command);calls.append(actual)
                        self.assertEqual(kwargs['stdin'],subprocess.DEVNULL)
                        self.assertEqual(kwargs['stderr'],subprocess.STDOUT)
                        self.assertTrue(kwargs['close_fds'])
                        kwargs['stdout'].write(b'synthetic runner stdout\n')
                        return process
                    frames=[snapshot(['initial observed different argv'],parent=222,group=222,session=222),
                            snapshot(command,parent=222,group=222,session=222)]
                    with (patch.dict(globals_,{'OUT':folder,'reviewed_runner':lambda:(runner,prepared),
                            'os':SimpleNamespace(getpid=lambda:222,getpgrp=lambda:222,getsid=lambda _:222)}),
                          patch.object(globals_['subprocess'],'Popen',spawned),kernel(self.ns,frames)):
                        actual=self.ns['supervise'](token)
                        expected=1 if early else code if code>=0 else 128-code
                        self.assertEqual(actual,expected)
                        with self.assertRaises(FileExistsError):self.ns['supervise'](token)
                    saved=json.loads((folder/'transport-status.json').read_text())
                    self.assertEqual(len(calls),1);self.assertEqual(process.waits,1)
                    self.assertEqual(saved['actual_runner_returncode'],code)
                    self.assertTrue(saved['terminal'])
                    self.assertEqual(saved['identity_complete'],not early)
                    self.assertEqual(saved['state'],'ERROR' if early else 'TERMINAL')
                    self.assertEqual((folder/'runner-output.log').read_bytes(),b'synthetic runner stdout\n')
                    if not early:
                        self.assertEqual(saved['runner_identity_observations'][1]['actual']['command'],frames[0]['command'])
                        self.assertEqual(saved['runner_identity']['ppid'],222)

    def test_launcher_delayed_capture_requires_expected_parent_and_detached_group(self):
        base=OUT/'synthetic-supervisor-controls';base.mkdir(exist_ok=True)
        folder=base/'launcher-delayed';folder.mkdir()
        token='synthetic-reservation'
        prepared={'binding':{'runner_sha256':'synthetic-only'}}
        (folder/'prepared.json').write_text(json.dumps(prepared))
        (folder/'go.json').write_text('{"scope":"inert synthetic only"}')
        runner=SimpleNamespace(ROOT=folder,WORKSPACE=folder/'synthetic-unused-runtime',
            source_audit=lambda:{},ports=lambda:{'synthetic':True},owned_processes=lambda:[])
        command=[sys.executable,'-B',str(folder/'supervisor.py'),'supervise',token]
        process=Process();calls=[]
        globals_=self.ns['launch'].__globals__
        def spawned(actual,**kwargs):
            self.assertEqual(actual,command);calls.append(actual)
            self.assertTrue(kwargs['start_new_session']);self.assertTrue(kwargs['close_fds'])
            self.assertEqual(kwargs['stdin'],subprocess.DEVNULL)
            return process
        frames=[snapshot(['initial different argv'],parent=222,group=Process.pid,session=Process.pid),
                snapshot(command,parent=222,group=Process.pid,session=Process.pid)]
        with (patch.dict(globals_,{'OUT':folder,'reviewed_runner':lambda:(runner,prepared),
                'os':SimpleNamespace(getpid=lambda:222),
                'uuid':SimpleNamespace(uuid4=lambda:SimpleNamespace(hex=token))}),
              patch.object(globals_['subprocess'],'Popen',spawned),kernel(self.ns,frames)):
            self.assertEqual(self.ns['launch'](),0)
            with self.assertRaises(FileExistsError):self.ns['launch']()
        result=json.loads((folder/'transport-launch.json').read_text())
        self.assertEqual(len(calls),1);self.assertTrue(result['accepted'])
        self.assertEqual(result['supervisor_identity']['ppid'],222)
        self.assertEqual(result['supervisor_identity']['pgid'],Process.pid)
        self.assertEqual(result['supervisor_identity_observations'][1]['actual']['command'],frames[0]['command'])
        self.assertFalse((folder/'transport-status.json').exists())

    def test_registration_deadline_cannot_launch_a_runner(self):
        folder,token,runner,prepared=self.fixture('registration-deadline',registration=False)
        globals_=self.ns['supervise'].__globals__;calls=[]
        def prohibited(*args,**kwargs):calls.append(args);raise AssertionError('No child before registration')
        with (patch.dict(globals_,{'OUT':folder,'reviewed_runner':lambda:(runner,prepared),
                'os':SimpleNamespace(getpid=lambda:222)}),
              patch.object(globals_['subprocess'],'Popen',prohibited),
              kernel(self.ns,[snapshot(self.command)]) as (clock,_)):
            with self.assertRaisesRegex(RuntimeError,'registration missing'):
                self.ns['supervise'](token)
        saved=json.loads((folder/'transport-status.json').read_text())
        self.assertEqual(calls,[]);self.assertEqual(saved['state'],'ERROR')
        self.assertIsNone(saved['actual_runner_returncode']);self.assertFalse(saved['terminal'])
        self.assertGreaterEqual(clock.value,3);self.assertLess(clock.value,3.02)

    def test_identity_read_crossing_deadline_is_never_accepted_late(self):
        observations=[]
        with kernel(self.ns,[{**snapshot(self.command),'identity_delay':4}]) as (clock,reads):
            with self.assertRaisesRegex(AssertionError,'bounded observation'):
                self.observe(Process(),observations)
        self.assertEqual(reads['identity'],1)
        self.assertEqual(observations[-1]['event'],'unresolved')
        self.assertGreater(clock.value,3)

    def test_real_tiny_owned_process_exits_zero_and_seven(self):
        for code,detached in ((0,True),(7,False)):
            with self.subTest(code=code,detached=detached):
                command=[sys.executable,'-B','-c',
                    f"import time,sys;time.sleep(.1);print('SYNTHETIC PRIVATE TRANSPORT');sys.exit({code})"]
                observations=[]
                with (OUT/f'primitive-exit-{code}.log').open('xb') as output:
                    process=subprocess.Popen(command,cwd=OUT,stdin=subprocess.DEVNULL,
                        stdout=output,stderr=subprocess.STDOUT,close_fds=True,start_new_session=detached)
                    try:
                        actual=self.ns['observe_identity'](process,command,parent_pid=__import__('os').getpid(),
                            pgid=process.pid if detached else __import__('os').getpgrp(),
                            session=process.pid if detached else __import__('os').getsid(0),observations=observations)
                    finally:actual_exit=process.wait()
                self.assertEqual(actual_exit,code);self.assertEqual(actual['pid'],process.pid)
                self.assertEqual(actual['command'],command)
                self.assertEqual((OUT/f'primitive-exit-{code}.log').read_bytes(),b'SYNTHETIC PRIVATE TRANSPORT\n')
                (OUT/f'primitive-exit-{code}.json').write_text(json.dumps({
                    'scope':'Tiny Python transport primitive only; no app/native work',
                    'command':command,'actual_wait_exit':actual_exit,'identity':actual,
                    'observations':observations,'detached':detached},indent=2)+'\n')


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(IdentityControls)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'scope':'Affected native11 transport controls only; synthetic fixtures and two tiny owned Python exits; no app/browser/services/chemistry/SQL',
            'test_methods_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
            'skipped':len(result.skipped),'successful':result.wasSuccessful(),
            'actual_GO_created':(OUT/'go.json').exists(),
            'real_runtime_workspace_created':Path('/tmp/neistra159-performance-native11-all8').exists(),
            'real_primitive_waits':[json.loads((OUT/f'primitive-exit-{code}.json').read_text())['actual_wait_exit']
                for code in (0,7) if (OUT/f'primitive-exit-{code}.json').exists()]}
    with (OUT/'supervisor-controls.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps(report))
    raise SystemExit(0 if result.wasSuccessful() else 1)



