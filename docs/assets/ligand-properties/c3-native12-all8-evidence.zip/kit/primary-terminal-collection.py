"""Require original terminal wait, positive cleanup and raw copies before diagnostics.

No SQL, signals, retries or qualification PASS inference. One-shot output only.
"""
from pathlib import Path
import datetime
import hashlib
import json
import runpy
import shutil
import zipfile
from poll import kernel

OUT = Path(__file__).resolve().parent


def fp(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def main():
    status = json.loads((OUT / 'transport-status.json').read_bytes())
    assert status['terminal'] is True and isinstance(status['actual_runner_returncode'], int)
    assert status['state'] == 'TERMINAL' and status['identity_complete'] is True
    known = {}
    for name in ('supervisor', 'runner_identity'):
        row = status[name]
        known[(row['pid'], row['start_token'])] = row
    observations = OUT / 'primary-live-observations.jsonl'
    if observations.exists():
        for line in observations.read_text().splitlines():
            for item in json.loads(line).get('handles', {}).values():
                row = item['expected']
                known[(row['pid'], row['start_token'])] = row
    resources = OUT / 'owned-resource-samples.jsonl'
    if resources.exists():
        for line in resources.read_text().splitlines():
            for row in json.loads(line).get('owned', []):
                known[(row['pid'], row['start_token'])] = row
    checks = []
    for (pid, token), expected in sorted(known.items()):
        try:
            actual = kernel(pid)
        except (FileNotFoundError, ProcessLookupError):
            checks.append({'pid': pid, 'start_token': token, 'observation': 'missing'})
            continue
        assert actual['start_token'] != token or actual['state'] == 'Z', actual
        checks.append({'expected': expected, 'actual': actual})
    runner = runpy.run_path(str(OUT / 'runner.py'), run_name='terminal_native12_readback')
    assert not runner['owned_processes']() and all(runner['ports']().values())
    receipt = json.loads((OUT / 'actual-receipt.json').read_bytes())
    assert receipt['runner_observation_complete'] is True
    assert receipt['exit_code'] == status['actual_runner_returncode']
    assert receipt['cleanup']['complete'] is True
    assert receipt['database_byte_archive_error'] is None
    original_raw = json.loads((OUT / 'database-byte-archive.json').read_bytes())
    assert original_raw['originals_retained'] is True
    assert original_raw['started_monotonic_ns'] > receipt['cleanup']['monotonic_ns']
    target = OUT / 'primary-terminal-readback1'
    assert not target.exists()
    target.mkdir()
    raw = {}
    for name, row in original_raw['files'].items():
        if not row.get('exists'):
            continue
        source = runner['DATA'] / name
        expected = {key: row[key] for key in ('bytes', 'sha256')}
        assert fp(source) == fp(Path(row['copy'])) == expected
        copy = target / 'raw-database-bytes' / name
        copy.parent.mkdir(exist_ok=True)
        shutil.copy2(source, copy)
        assert fp(copy) == fp(source) == expected
        raw[name] = {'original': str(source), 'runner_preSQL_copy': row['copy'],
                     'primary_copy': str(copy), **expected}
    assert raw
    audit = runner['source_audit']()
    assert receipt['source_before'] == receipt['source_after'] == audit['sources']
    assert receipt['methods_before'] == receipt['methods_after'] == audit['methods']
    assert receipt['authoritative_HEAD_before'] == receipt['authoritative_HEAD_after'] == runner['authoritative_head']()
    for name in ['source-preparation.zip', 'source-after.zip']:
        with zipfile.ZipFile(OUT / name) as archive:
            assert archive.testzip() is None
            assert len(archive.namelist()) == len(set(archive.namelist())) == len(audit['sources'])
            assert set(archive.namelist()) == set(audit['sources'])
            for relative, expected in audit['sources'].items():
                assert hashlib.sha256(archive.read(relative)).hexdigest() == expected
    retained = {name: runner['files_under'](Path(name)) for name in receipt['new_harness_directories']}
    assert retained == json.loads((OUT / 'retained-workflow-inventories.json').read_bytes())
    assert all(Path(name).is_dir() and not Path(name).is_symlink() for name in retained)
    if status['actual_runner_returncode'] == 0:
        assert len(retained) == 8
    browser = json.loads((OUT / 'browser.json').read_bytes()) if (OUT / 'browser.json').exists() else {}
    result = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'Primary original terminal/source/raw/full-workflow-root readback only; full qualification remains separate.',
              'candidate': runner['PARENT_CANDIDATE'], 'actual_original_runner_wait_exit': status['actual_runner_returncode'],
              'positive_PID_start_checks': checks, 'ports_unused': runner['ports'](),
              'source_count': len(audit['sources']), 'method_count': len(audit['methods']),
              'source_digest': audit['source_digest'], 'method_digest': audit['method_digest'],
              'all_source_archive_bodies_CRC_unique_exact_union': True,
              'raw_original_runner_copy_primary_copy_pairs': raw,
              'complete_original_observer_roots': {name: len(rows) for name, rows in retained.items()},
              'all_original_observer_root_regular_bytes_rehashed': True,
              'browser_stats': browser.get('stats'), 'browser_errors': browser.get('errors'),
              'SQL_opened': False, 'qualification_PASS': False}
    path = target / 'readback.json'
    path.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'receipt': str(path), **fp(path)}))


if __name__ == '__main__':
    main()
