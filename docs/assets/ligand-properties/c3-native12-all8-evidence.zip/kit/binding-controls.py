"""Synthetic native12 binding controls only. Run explicitly; starts no application/process/SQL.

Produces a one-shot control receipt, never an actual candidate or qualification receipt.
"""
from pathlib import Path
import copy
import hashlib
import json
import runpy

OUT = Path(__file__).resolve().parent
G = runpy.run_path(str(OUT / 'binding_guard.py'), run_name='synthetic_native12_bindings')


def read(name):
    return json.loads((OUT / name).read_bytes())


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def fixture():
    previous = read('baseline/failed-master-source-map.json')
    source = dict(previous)
    for name in G['CHANGED'] | G['ADDED']:
        source[name] = digest('synthetic correction ' + name)
    old_methods = read('baseline/native11-expected-methods.json')
    methods = {name: source[name] for name in set(old_methods) | {G['HELPER']}}
    pins = {'HEAD': 'a' * 40, 'ref': G['BRANCH'], 'comparison_base': G['BASE']}
    checkpoint = {'candidate': pins['HEAD'], 'checkpoint': pins['HEAD'],
        'comparison_base': G['BASE'], 'clean_owned_tree': True,
        'no_production_science_TTL_API_schema_dependency_version_changes': True,
        'complete_intended_diff_and_newfiles_self_review': 'PASS',
        'new_final_ALL8_success_receipt_created': False,
        'checks': {name: {'exit_code': 0} for name in G['CHECKS']}}
    documents = {'failed_master_sources': previous,
        'native11_methods': old_methods, 'native11_sources': read('baseline/native11-expected-sources.json'),
        'failed_master_preservation': read('baseline/failed-master-handoff.json'),
        'failed_master_primary': read('baseline/failed-master-primary-readback.json'),
        'protected_versions': read('baseline/native11-protected-version-bindings.json'),
        'fixtures': read('baseline/native11-fixture-controls-reuse-proof.json')}
    for key, role in [('architecture', 'software_architecture'), ('performance', 'performance')]:
        documents[key] = {'candidate': pins['HEAD'], 'comparison_base': G['BASE'], 'role': role, 'verdict': 'PASS'}
    documents['self_review'] = {'candidate': pins['HEAD'], 'comparison_base': G['BASE'],
        'verdict': 'PASS', 'complete_intended_diff_and_newfiles': True}
    producer = 'tests/support/ligand_property_performance_qualification.py'
    documents['producer_science_preservation'] = {
        'candidate': pins['HEAD'], 'comparison_base': G['BASE'], 'producer_path': producer,
        'old_actual_Gitblob_sha256': previous[producer], 'current_producer_sha256': source[producer],
        'baseline_actual_Gitblob_verified': True, 'exactly_two_observe_publications_normalized': True,
        'only_new_tempfile_import_and_atomic_publisher_removed': True,
        'entire_module_AST_equal_after_only_declared_normalization': True,
        'unrelated_functions_and_classes_AST_exact': True}
    frame = {'source': source, 'methods': methods, 'pins': pins, 'checkpoint': checkpoint, 'documents': documents}
    rebind(frame)
    return frame


def rebind(frame):
    source, methods = frame['source'], frame['methods']
    frame['pins'].update(source_count=len(source), source_digest=G['compact'](source),
                         method_count=len(methods), method_digest=G['spaced'](methods))
    frame['checkpoint'].update(source_count=len(source), source_digest_compact_json=G['compact'](source),
                               method_count=len(methods), method_digest_spaced_json=G['spaced'](methods))
    for key in ['architecture', 'performance', 'self_review', 'producer_science_preservation']:
        frame['documents'][key].update(source_digest_compact_json=G['compact'](source),
                                        method_digest_spaced_json=G['spaced'](methods))


def check(frame):
    return G['validate'](frame['source'], frame['methods'], frame['pins'], frame['checkpoint'], frame['documents'])


def edit(path, value):
    def mutate(frame):
        target = frame
        for key in path[:-1]:
            target = target[key]
        target[path[-1]] = value
    return mutate


def remove(path):
    def mutate(frame):
        target = frame
        for key in path[:-1]:
            target = target[key]
        del target[path[-1]]
    return mutate


def main():
    target = OUT / 'binding-controls-result.json'
    assert not target.exists(), 'Preserve previous control result; no overwrite'
    original = fixture()
    outcomes = []
    failures = []
    errors = []
    try:
        check(original)
        positive = 1
    except BaseException as error:
        positive = 0
        errors.append({'case': 'synthetic coherent bounded correction', 'error': repr(error)})
    other_method = next(name for name in original['methods'] if name not in G['CHANGED'] | {G['HELPER']})
    cases = [
        ('new helper missing from complete source and method maps',
            lambda f: (f['source'].pop(G['HELPER']), f['methods'].pop(G['HELPER'])), True),
        ('new helper omitted from method map', remove(['methods', G['HELPER']]), True),
        ('changed producer omitted from method map', remove(['methods', 'tests/support/ligand_property_performance_qualification.py']), True),
        ('extra altered old method coherently rebound',
            lambda f: (f['source'].__setitem__(other_method, '1' * 64), f['methods'].__setitem__(other_method, '1' * 64)), True),
        ('unrelated config source drift coherently rebound', edit(['source', 'pyproject.toml'], '2' * 64), True),
        ('unexpected new selected source coherently rebound', edit(['source', 'tests/synthetic-unapproved.py'], '3' * 64), True),
        ('missing existing selected source', remove(['source', 'pyproject.toml']), True),
        ('missing new reader regression source', remove(['source', 'apps/web/src/test/ligand-property-observer-snapshot.test.ts']), True),
        ('architecture candidate mismatch', edit(['documents', 'architecture', 'candidate'], 'b' * 40), False),
        ('architecture source binding mismatch', edit(['documents', 'architecture', 'source_digest_compact_json'], '4' * 64), False),
        ('performance method binding mismatch', edit(['documents', 'performance', 'method_digest_spaced_json'], '5' * 64), False),
        ('missing architecture assessment', remove(['documents', 'architecture']), False),
        ('wrong specialist role', edit(['documents', 'performance', 'role'], 'ui_design'), False),
        ('specialist changes required', edit(['documents', 'performance', 'verdict'], 'CHANGES_REQUIRED'), False),
        ('specialist comparison base mismatch', edit(['documents', 'performance', 'comparison_base'], 'c' * 40), False),
        ('failed actual lint check', edit(['checkpoint', 'checks', 'web_lint', 'exit_code'], 1), False),
        ('missing strict benchmark check', remove(['checkpoint', 'checks', 'strict_benchmark_types']), False),
        ('missing observer regression check', remove(['checkpoint', 'checks', 'observer_reader_regressions']), False),
        ('checkpoint candidate mismatch', edit(['checkpoint', 'candidate'], 'd' * 40), False),
        ('dirty checkpoint', edit(['checkpoint', 'clean_owned_tree'], False), False),
        ('unapproved runtime or compatibility change', edit(['checkpoint', 'no_production_science_TTL_API_schema_dependency_version_changes'], False), False),
        ('incomplete diff self-review', edit(['checkpoint', 'complete_intended_diff_and_newfiles_self_review'], 'BLOCKED'), False),
        ('premature fresh ALL8 success claim', edit(['checkpoint', 'new_final_ALL8_success_receipt_created'], True), False),
        ('self-review source mismatch', edit(['documents', 'self_review', 'source_digest_compact_json'], '6' * 64), False),
        ('self-review omits new files', edit(['documents', 'self_review', 'complete_intended_diff_and_newfiles'], False), False),
        ('failed master relabeled qualified', edit(['documents', 'failed_master_preservation', 'qualification_PASS'], True), False),
        ('primary raw preservation opened SQL', edit(['documents', 'failed_master_primary', 'SQL_opened'], True), False),
        ('authoritative version changed', edit(['documents', 'protected_versions', 'five_application_versions', 'web'], '0.37.1'), False),
        ('source digest mismatch', edit(['pins', 'source_digest'], '7' * 64), False),
        ('comparison base mismatch', edit(['pins', 'comparison_base'], 'e' * 40), False),
        ('wrong owned branch', edit(['pins', 'ref'], 'refs/heads/master'), False),
        ('checkpoint method count mismatch', edit(['checkpoint', 'method_count'], 0), False),
        ('checkpoint source count mismatch', edit(['checkpoint', 'source_count'], 0), False),
        ('missing producer preservation proof', remove(['documents', 'producer_science_preservation']), False),
        ('producer preservation method mismatch', edit(['documents', 'producer_science_preservation', 'method_digest_spaced_json'], '8' * 64), False),
        ('producer actual baseline blob mismatch', edit(['documents', 'producer_science_preservation', 'old_actual_Gitblob_sha256'], '9' * 64), False),
        ('producer normalization not exact', edit(['documents', 'producer_science_preservation', 'entire_module_AST_equal_after_only_declared_normalization'], False), False),
    ]
    for name, mutate, bind in cases:
        frame = copy.deepcopy(original)
        mutate(frame)
        if bind:
            rebind(frame)
        try:
            check(frame)
        except (AssertionError, KeyError) as error:
            outcomes.append({'case': name, 'rejected': True, 'error_type': type(error).__name__})
        except BaseException as error:
            errors.append({'case': name, 'unexpected_error': repr(error)})
        else:
            failures.append({'case': name, 'wrongly_accepted': True})
    launch_binding = {'HEAD': 'a' * 40, 'source_digest': 'b' * 64, 'method_digest': 'c' * 64,
        'runner_sha256': 'd' * 64, 'supervisor_sha256': 'e' * 64, 'guard_sha256': 'f' * 64,
        'binding_guard_sha256': '1' * 64, 'binding_controls_sha256': '2' * 64}
    prepared_hash = '3' * 64
    launches = {role: {'role': role, 'verdict': 'PASS', 'candidate': launch_binding['HEAD'],
        'reviewed_prepared_sha256': prepared_hash,
        'source_digest_compact_json': launch_binding['source_digest'],
        'method_digest_spaced_json': launch_binding['method_digest'],
        **{name: value for name, value in launch_binding.items() if name.endswith('_sha256')}}
        for role in ['software_architecture', 'performance']}
    try:
        G['validate_prelaunch'](launch_binding, prepared_hash, launches)
        positive += 1
    except BaseException as error:
        errors.append({'case': 'synthetic coherent same-preparation prelaunch reviews', 'error': repr(error)})
    launch_cases = [
        ('missing prelaunch performance review', lambda f: f.pop('performance')),
        ('stale reviewed prepared snapshot', lambda f: f['software_architecture'].__setitem__('reviewed_prepared_sha256', '4' * 64)),
        ('stale reviewed runner code', lambda f: f['performance'].__setitem__('runner_sha256', '5' * 64)),
        ('different reviewed binding-controls receipt', lambda f: f['performance'].__setitem__('binding_controls_sha256', '6' * 64)),
    ]
    for name, mutate in launch_cases:
        frame = copy.deepcopy(launches)
        mutate(frame)
        try:
            G['validate_prelaunch'](launch_binding, prepared_hash, frame)
        except (AssertionError, KeyError) as error:
            outcomes.append({'case': name, 'rejected': True, 'error_type': type(error).__name__})
        except BaseException as error:
            errors.append({'case': name, 'unexpected_error': repr(error)})
        else:
            failures.append({'case': name, 'wrongly_accepted': True})
    result = {'scope': 'Synthetic binding guard controls only; no candidate/application/qualification outcome.',
        'binding_guard_sha256': hashlib.sha256((OUT / 'binding_guard.py').read_bytes()).hexdigest(),
        'controls_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'positive_cases': positive, 'negative_cases': len(outcomes),
        'failures': len(failures), 'errors': len(errors), 'skipped': 0,
        'successful': positive == 2 and len(outcomes) == len(cases) + len(launch_cases) and not failures and not errors,
        'negative_outcomes': outcomes, 'failure_details': failures, 'error_details': errors}
    with target.open('x') as handle:
        json.dump(result, handle, indent=2)
        handle.write('\n')
    print(json.dumps(result))
    raise SystemExit(0 if result['successful'] else 1)


if __name__ == '__main__':
    main()
