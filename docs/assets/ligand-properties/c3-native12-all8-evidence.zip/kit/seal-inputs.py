"""Future operation only: freeze actual clean C1 plus actual read-only scoped assessments.

This tool does not launch preparation, services, browsers, SQL, performance or GO.
It refuses a dirty candidate and never substitutes a current status for a receipt.
"""
from pathlib import Path
import argparse
import hashlib
import json
import runpy
import shutil
import subprocess
from binding_guard import ADDED, BASE, BRANCH, HELPER, compact, spaced, validate

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).resolve().parent


def sha(body):
    return hashlib.sha256(body).hexdigest()


def read(path):
    assert path.is_file() and not path.is_symlink(), path
    return json.loads(path.read_bytes())


def git(*args, data=None):
    return subprocess.check_output(['git', *args], cwd=ROOT, input=data)


def write(name, value):
    with (OUT / name).open('x') as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--architecture', type=Path, required=True)
    parser.add_argument('--performance', type=Path, required=True)
    parser.add_argument('--self-review', type=Path, required=True)
    parser.add_argument('--producer-science-preservation', type=Path, required=True)
    args = parser.parse_args()
    assert not (OUT / 'canonical-root-pins.json').exists(), 'One-shot candidate seal already exists'
    assert git('status', '--porcelain').strip() == b'', 'Clean committed C1 required'
    head = git('rev-parse', 'HEAD').decode().strip()
    ref = git('symbolic-ref', '-q', 'HEAD').decode().strip()
    assert ref == BRANCH and head != BASE
    subprocess.check_call(['git', 'merge-base', '--is-ancestor', BASE, head], cwd=ROOT)
    closed = read(OUT / 'closed-inputs.json')
    for name, row in closed['files'].items():
        body = (OUT / name).read_bytes()
        assert {'bytes': len(body), 'sha256': sha(body)} == row, name
    guard = runpy.run_path(str(OUT / 'source_guard.py'))
    source = {name: guard['checked_hash'](ROOT, name) for name in sorted(guard['discover'](ROOT))}
    original_methods = read(OUT / 'baseline/native11-expected-methods.json')
    methods = {name: source[name] for name in sorted(set(original_methods) | {HELPER})}
    checkpoint = read(args.checkpoint.resolve())
    documents = {
        'architecture': read(args.architecture.resolve()), 'performance': read(args.performance.resolve()),
        'self_review': read(args.self_review.resolve()),
        'producer_science_preservation': read(args.producer_science_preservation.resolve()),
        'failed_master_sources': read(OUT / 'baseline/failed-master-source-map.json'),
        'native11_sources': read(OUT / 'baseline/native11-expected-sources.json'),
        'native11_methods': original_methods,
        'failed_master_preservation': read(OUT / 'baseline/failed-master-handoff.json'),
        'failed_master_primary': read(OUT / 'baseline/failed-master-primary-readback.json'),
        'protected_versions': read(OUT / 'baseline/native11-protected-version-bindings.json'),
        'fixtures': read(OUT / 'baseline/native11-fixture-controls-reuse-proof.json'),
    }
    pins = {'HEAD': head, 'ref': ref, 'comparison_base': BASE, 'root': str(ROOT), 'OUT': str(OUT),
            'source_count': len(source), 'source_digest': compact(source),
            'method_count': len(methods), 'method_digest': spaced(methods)}
    validate(source, methods, pins, checkpoint, documents)
    # Every selected current body must be the body actually committed at C1.
    ordered = sorted(source)
    response = git('cat-file', '--batch', data=''.join(f'{head}:{name}\n' for name in ordered).encode())
    offset = 0
    for name in ordered:
        end = response.index(b'\n', offset)
        _, kind, size = response[offset:end].split()
        assert kind == b'blob'
        begin = end + 1
        offset = begin + int(size)
        assert sha(response[begin:offset]) == source[name] and response[offset:offset + 1] == b'\n'
        offset += 1
    assert offset == len(response)
    copies = {'root-receipt.json': args.checkpoint, 'architecture-assessment.json': args.architecture,
              'performance-assessment.json': args.performance, 'primary-self-review.json': args.self_review,
              'producer-science-preservation.json': args.producer_science_preservation}
    for name, path in copies.items():
        target = OUT / name
        assert not target.exists()
        shutil.copy2(path.resolve(), target)
    write('expected-sources.json', source)
    write('expected-methods.json', methods)
    write('current-source-delta.json', {
        'comparison_base': BASE, 'candidate': head,
        'added': sorted(ADDED), 'changed': sorted(name for name in documents['failed_master_sources']
            if source[name] != documents['failed_master_sources'][name]), 'removed': [],
        'source_count': len(source), 'source_digest': compact(source),
        'method_count': len(methods), 'method_digest': spaced(methods),
        'runtime_subjects': 461, 'runtime_native11_byte_exact': True,
        'scope': 'Actual committed C1 bindings only; no native qualification outcome.'})
    document_names = {'architecture': 'architecture-assessment.json', 'performance': 'performance-assessment.json',
        'self_review': 'primary-self-review.json',
        'producer_science_preservation': 'producer-science-preservation.json', 'failed_master_sources': 'baseline/failed-master-source-map.json',
        'native11_sources': 'baseline/native11-expected-sources.json',
        'native11_methods': 'baseline/native11-expected-methods.json',
        'failed_master_preservation': 'baseline/failed-master-handoff.json',
        'failed_master_primary': 'baseline/failed-master-primary-readback.json',
        'protected_versions': 'baseline/native11-protected-version-bindings.json',
        'fixtures': 'baseline/native11-fixture-controls-reuse-proof.json'}
    pins['documents'] = document_names
    pins['root_receipt'] = 'root-receipt.json'
    pins['root_receipt_sha256'] = sha((OUT / 'root-receipt.json').read_bytes())
    names = sorted(str(path.relative_to(OUT)) for path in OUT.rglob('*') if path.is_file()
                   and path.name not in {'canonical-root-pins.json', 'extra-tools.json'})
    tools = {name: sha((OUT / name).read_bytes()) for name in names}
    write('extra-tools.json', tools)
    pins['files'] = {**tools, 'extra-tools.json': sha((OUT / 'extra-tools.json').read_bytes())}
    pins['source_map_sha256'] = sha((OUT / 'expected-sources.json').read_bytes())
    pins['methods_map_sha256'] = sha((OUT / 'expected-methods.json').read_bytes())
    assert git('rev-parse', 'HEAD').decode().strip() == head and git('status', '--porcelain').strip() == b''
    guard['audit'](ROOT, source, methods)
    write('canonical-root-pins.json', pins)
    print(json.dumps({'status': 'Actual C1 inputs sealed; no prepare/GO/launch performed',
                      'candidate': head, 'source_count': len(source), 'method_count': len(methods),
                      'canonical_root_pins_sha256': sha((OUT / 'canonical-root-pins.json').read_bytes())}))


if __name__ == '__main__':
    main()
