# Native12 ALL8 preparation — no execution

This kit is prepared only. No current candidate inputs, actual pins, prepared
candidate capsule, GO, services, browser cases, SQL or performance results were
created by its author. The root owns every actual next step.

The existing native11 supervisor and source guard are byte-exact. Its twelve
supervisor controls and real tiny child exits 0/7 remain predecessor evidence for
unchanged code, not new native12 executions. Closed originals and checksums are in
`baseline/` and `closed-inputs.json`. The new binding adapter and observer-directory
discovery are explicit changes; the new controls MUST actually run before GO.

Future order, from the current owned correction checkout, each as a separate
command with actual exits/logs retained:

1. Inspect all scripts and their complete delta. Run `binding-controls.py`. Its
   two synthetic positive and forty-one negative cases exercise the changed
   candidate/method/assessment and same-preparation prelaunch bindings. They are
   file-data controls, not candidate/scientific/native qualification.
2. After the actual clean C1 and scoped receipts exist, run `seal-inputs.py` with
   `--checkpoint`, `--architecture`, `--performance`, `--self-review` and
   `--producer-science-preservation` pointing at the actual source-bound receipts.
   It refuses dirty/uncommitted sources, confirms every selected body against
   actual C1 Git blobs, checks exact method/source deltas, and writes one-shot
   canonical pins. This performs no prepare, GO or launch.
3. Run `runner.py prepare` using the correction checkout's `.venv/bin/python -B`.
   This requires successful current-code binding controls. It checks actual
   unused dedicated ports and absence of owned runtime/workspace, captures the
   actual selected source ZIP and writes a separate unauthorized GO template.
4. Obtain actual read-only architecture and performance prelaunch assessments
   covering that precise `prepared.json`, runner/transport/guard/control bytes,
   source/method maps and current original constraints. Root must write
   `prelaunch-architecture-assessment.json` and
   `prelaunch-performance-assessment.json`. Each needs role, verdict PASS,
   candidate, reviewed_prepared_sha256, source_digest_compact_json,
   method_digest_spaced_json, runner_sha256, supervisor_sha256, guard_sha256,
   binding_guard_sha256 and binding_controls_sha256. The GO must include their
   exact filename/SHA records under `prelaunch_assessments`, keyed by
   `software_architecture` and `performance`.
5. Only root may author the exact authorized `go.json` and invoke
   `supervisor.py launch`. Launcher 0 means acceptance only. Poll the ORIGINAL
   handles with `poll.py`; never restart due to elapsed time or an observation
   timeout. The original supervisor's Popen.wait status is terminal authority.
6. At actual terminal, stop live observer writes and run
   `primary-terminal-collection.py`. It requires positive PID/start cleanup,
   dedicated unused ports, original runner wait and pre-SQL raw database copies;
   rehashes all selected source/method bodies and full source capsules; and
   re-inventories every actual original UUID observer tree. A zero runner exit
   requires eight original observer roots. It does not declare qualification.
7. Root must assess all original native outcomes, scientific/resource/order
   predicates, complete closed ALL8 analysis, source/observer/raw retention and
   complete packaging. Native11 and failed master1 remain historical and are not
   relabeled. Full candidate/all-seven/corrective merge/fresh-master/release gates
   remain separate and mandatory.

Actual C1 receipt locations already supplied to root (read only by this kit):

- `../issue159-observer-correction-c1-readiness1/root-checkpoint.json`
- `../issue159-observer-correction-c1-readiness1/software_architecture-assessment.json`
- `../issue159-observer-correction-c1-readiness1/performance-assessment.json`
- `../issue159-observer-correction-c1-readiness1/producer-science-preservation-binding.json`
- `../issue159-observer-c1-self-review1.json`

The declared method is native11's original 51 paths plus the new observer reader
helper, with only its original producer/spec bodies changed. The complete source
set is derived dynamically and must be exactly failed-master source plus the three
new helper/regression files and those two changed bodies. All 461 runtime bodies,
44 frozen fixtures and all 49 other old method bodies stay exact. The old scientific
file map contains the changed producer: require its other 156 bodies exact, and
bind the actual producer AST-normalization receipt rather than falsely claiming
157 unchanged bodies. Sampling, write cadence, clocks, five cold contexts, twenty
paired edits per profile, cancellation, both 1,000-entry cohorts, thresholds,
deadlines, workers1/retries0/maxfailures1 and both profiles remain.

Workspace is `/tmp/neistra159-performance-native12-all8`; planned ports are
8540/8541/5540. No availability or workload result is inferred from this preparation.
The actual tests create observer roots under the correction checkout's
`.issue-11-evidence/issue159-performance/`; discovery uses that exact parent rather
than this kit's parent. Full eight original trees must be retained after success;
failed partial trees must also be retained without inventing missing cases.

The wrapper retains the existing shared-host 2s process/resource sampling and its
128MiB/200k record caps. Such sampling is incomplete browser/GPU/short-lived process
accounting, not an every-instant ceiling or strict-reference host certification.
No speedup or application-readiness claim follows these instrumentation changes.
