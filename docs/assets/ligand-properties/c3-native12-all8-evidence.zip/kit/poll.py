"""Observe the original native12 handles; never launch, signal, restart or infer an exit."""
from pathlib import Path
import datetime
import hashlib
import json

OUT = Path(__file__).resolve().parent


def kernel(pid):
    before = (Path('/proc') / str(pid) / 'stat').read_text()
    fields = before[before.rindex(')') + 2:].split()
    argv = [item.decode(errors='replace') for item in (Path('/proc') / str(pid) / 'cmdline').read_bytes().split(b'\0') if item]
    after = (Path('/proc') / str(pid) / 'stat').read_text()
    final = after[after.rindex(')') + 2:].split()
    assert fields[19] == final[19]
    return {'pid': pid, 'start_token': final[19], 'state': final[0], 'ppid': int(final[1]),
            'pgid': int(final[2]), 'session': int(final[3]), 'command': argv}


def observe(expected):
    try:
        actual = kernel(expected['pid'])
    except (FileNotFoundError, ProcessLookupError):
        return {'expected': expected, 'live': False, 'observation': 'missing'}
    same = actual['start_token'] == expected['start_token']
    return {'expected': expected, 'actual': actual,
            'live': same and actual['state'] != 'Z',
            'command_exact': same and actual['command'] == expected['command']}


def main():
    status = json.loads((OUT / 'transport-status.json').read_bytes())
    row = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'state': status['state'], 'terminal': status['terminal'],
           'actual_runner_returncode': status['actual_runner_returncode'],
           'identity_complete': status['identity_complete'],
           'handles': {name: observe(status[name]) for name in ('supervisor', 'runner_identity') if name in status},
           'scope': 'Specific original handle observation only; no browser/workflow qualification.'}
    log = OUT / 'runner-output.log'
    if log.exists():
        prefix = log.read_bytes()
        row['console_prefix'] = {'bytes': len(prefix), 'sha256': hashlib.sha256(prefix).hexdigest(),
                                 'tail': prefix.decode(errors='replace').splitlines()[-4:]}
    # A terminal read never reopens this root for appending; retention may seal it.
    if not row['terminal']:
        with (OUT / 'primary-live-observations.jsonl').open('a') as handle:
            handle.write(json.dumps(row) + '\n')
    print(json.dumps(row))


if __name__ == '__main__':
    main()
