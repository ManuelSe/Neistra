"""Pure HEAD-record metadata controls; no application or measurement execution."""
from pathlib import Path
from copy import deepcopy
import json
from support import verify_head_binding

OUT = Path(__file__).absolute().parent
fixture = json.loads((OUT / 'metadata-control-fixture.json').read_bytes())


def control(name, edits=(), expected=False):
    data = deepcopy(fixture['metadata'])
    for path, value in edits:
        target = data
        for key in path[:-1]:
            target = target[key]
        target[path[-1]] = value
    try:
        verify_head_binding(data['primary'], data['runtime'], data['assessment'], data['pins'])
    except (AssertionError, KeyError, TypeError) as error:
        accepted = False
        refusal = type(error).__name__
    else:
        accepted = True
        refusal = None
    assert accepted is expected, name
    return {'name': name, 'expected_accepted': expected, 'actual_accepted': accepted, 'refusal': refusal}


def both(field, value):
    return [(('runtime', 'authoritative_HEAD_' + phase, field), value) for phase in ('before', 'after')]


candidate = fixture['metadata']['primary']['candidate']
before = fixture['metadata']['runtime']['authoritative_HEAD_before']
cases = [
    control('actual complete symbolic-ref records', expected=True),
    control('equivalent after record with different dictionary insertion order', [(('runtime', 'authoritative_HEAD_after'), dict(reversed(list(before.items()))))], True),
    control('former incorrect scalar-string shape', [(('runtime', 'authoritative_HEAD_' + phase), candidate) for phase in ('before', 'after')]),
    control('incorrect list record shape', [(('runtime', 'authoritative_HEAD_' + phase), []) for phase in ('before', 'after')]),
    control('before and after commit disagree', [(('runtime', 'authoritative_HEAD_after', 'commit'), '0' * 40)]),
    control('equal records commit conflicts with candidate', both('commit', '0' * 40)),
    control('primary candidate conflicts', [(('primary', 'candidate'), '0' * 40)]),
    control('runner binding commit conflicts', [(('runtime', 'binding', 'HEAD'), '0' * 40)]),
    control('assessment candidate conflicts', [(('assessment', 'candidate'), '0' * 40)]),
    control('canonical pins candidate conflicts', [(('pins', 'HEAD'), '0' * 40)]),
    control('canonical pins ref conflicts', [(('pins', 'ref'), 'refs/heads/other')]),
    control('equal records point to different consistent symbolic ref', both('ref', 'refs/heads/other') + both('HEAD_text', 'ref: refs/heads/other')),
    control('HEAD text does not agree with symbolic ref', both('HEAD_text', 'ref: refs/heads/other')),
    control('detached text does not agree with owned symbolic ref', both('HEAD_text', candidate)),
    control('nonstr symbolic reference', both('ref', None)),
    control('nonstr authoritative scope', both('scope', None)),
    control('before and after metadata scopes disagree', [(('runtime', 'authoritative_HEAD_after', 'scope'), 'changed')]),
    control('missing typed record fields', [(('runtime', 'authoritative_HEAD_' + phase), {'commit': candidate}) for phase in ('before', 'after')]),
    control('canonical ref is outside a branch', [(('pins', 'ref'), 'refs/tags/other')] + both('ref', 'refs/tags/other') + both('HEAD_text', 'ref: refs/tags/other')),
]
result = {'scope': 'Pure preparatory metadata-boundary controls only; no native measurement or application tests.',
          'controls': cases, 'positive_controls': sum(row['actual_accepted'] for row in cases),
          'negative_controls': sum(not row['actual_accepted'] for row in cases),
          'all_controls_match_expected': True, 'package_or_verifier_executed': False,
          'original_root_inventory_or_packet_created': False}
with (OUT / 'metadata-controls.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(result))
