# Native12 closed-result analysis adapter — prepared, not executed

The root confirmed original native12 terminal success and ran the prepared primary
collector. This preparation inspected closed metadata/schema only; it did not run
analysis, oracles, tests, SQL, services, profiling, Git actions or change originals.

Future root invocation from the correction checkout:

```sh
.venv/bin/python -B .issue-11-evidence/issue159-native12-closed-analysis-preparation1/analyze.py --terminal-proof /datadisk/dev/neistra-worktrees/issue-159-observer-snapshots/.issue-11-evidence/issue159-native12-preparation1/primary-terminal-readback1/readback.json --terminal-proof-sha256 8e0ade7b1bbf9cb906a149413918ad5867e919eff77dd41e62eadb60c62355af
```

Inspect `adapter-delta.patch` and `adaptation-proof.json` first. Successful execution
would create one-shot `assessment.json`, `comparison-samples.json` and
`input-identities.json` here; those files do not currently exist. Future execution
may reveal a required correction; never alter original evidence to satisfy it.

The adapter first validates the actual collector proof hash and its REAL schema:
`actual_original_runner_wait_exit`, candidate/source/method identities, positive
PID/start cleanup, unused dedicated ports, pre-SQL raw original/runner/primary copy
bindings, full source capsule CRC/unique unions, and all eight original observer
roots. The collector intentionally says `qualification_PASS=false`; it is retention
proof, not an ALL8 verdict. The adapter then verifies original supervisor terminal
Popen.wait metadata and correlated acceptance/reservations/positive observations.
Only after this barrier does it open current native results and independently
establish eight single-attempt passes with no skip/failure/flake/retry/errors.

Native12 has NO `collection.json` or extra list run. CLOSED native11 collection
supplies expected normalized file/title/profile identities only, with original
995e provenance. Actual native12 outcomes derive solely from the final browser
report. Current source/method counts, hashes, roots and port sets derive from the
exact immutable native12 pins/prepared/maps. Every observer and worker trace must
match the exact sibling frozen observer map, whose current count is derived as789;
no old787 subset is substituted.

Nine original functions remain AST-exact, including statistics, nearest-rank p95,
threshold-miss meanings, renewal/cadence/full-UTF8-response accounting, browser
outcome checks and file/hash readers. The entire old scientific/work/resource/cohort
main block remains byte-exact after removing only declared stronger exact-observer
identity and descriptive retirement/clock additions. Cold/warm sample counts,
cohorts, 100ms/2000ms/5000ms targets, resource/work/fairness/deadline bounds and
scientific predicates remain unchanged. No old95-renewal count or bytes is carried;
all future traffic totals derive from actual closed records.

Every actual original observer tree is rehashed against its complete closed saved
inventory; all raw original/runner/primary copies and both source ZIPs are rechecked.
Every consumed closed input is rechecked before output creation. Inert aliases and
structural descriptors are retained without following or opening them. There are
no database connections or application imports.

Source-retirement output distinguishes recorded observable latency from hidden or
unobserved old values; missing latency stays unavailable. Saved per-document clock
calibrations remain explicit. Resource observations remain discrete PID/start-token
samples, with incomplete browser/GPU/short-lived-process accounting; missing samples
are unavailable and case-close retention is not an every-instant ceiling.

The descriptive historical comparison is now original native11 (995e, original51),
not a relabeled baseline. Native12 remains exact C1 `7da9913b` and its new52 methods.
All40 scientific input-hash pairs and four bulk hashes must still match. Historical
native11 timing limitations stay distinct. Changed observation methods/shared-host
conditions preclude controlled A/B, causal speedup/regression, same-method or strict
reference-host certification. This analysis does not establish full feature/release
acceptance; complete candidate/all-seven/normal corrective merge/fresh-master and
verified release gates remain separate.
