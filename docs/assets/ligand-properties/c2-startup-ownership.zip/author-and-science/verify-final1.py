from __future__ import annotations

import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
folder = root / '.issue-11-evidence/issue159-startup-ownership'
receipt = folder / 'verification-final1.json'
assert not receipt.exists()
owned = [
    'apps/api/src/neistra_api/job_worker.py',
    'apps/api/src/neistra_api/ligand_property_process.py',
    'apps/api/src/neistra_api/job_service.py',
    'apps/api/src/neistra_api/ligand_property_service.py',
    'tests/integration/test_ligand_property_startup_ownership.py',
]
source_roots = ['apps/api/src', 'apps/web/src', 'packages/neistra_core/src',
                'packages/molweave_core/src', 'packages/neistra_demo_plugin/src',
                'packages/molweave_demo_plugin/src', 'tests', 'scripts',
                'docs/assets/ligand-properties']
source_extensions = {'.py','.ts','.tsx','.js','.json','.toml','.yaml','.yml','.mol','.sdf'}
sources = sorted({str(path) for base in source_roots if Path(base).exists()
                  for path in Path(base).rglob('*')
                  if path.is_file() and not path.is_symlink() and path.suffix in source_extensions})
def hashes(paths):
    return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
source_before = hashes(sources)
owned_before = hashes(owned)
env = {k:v for k,v in os.environ.items() if k not in {'NEISTRA_DATA_DIR','NEISTRA_DATABASE_URL','MOLWEAVE_DATA_DIR','MOLWEAVE_DATABASE_URL','DATABASE_URL'}}
env.update(NEISTRA_PERFORMANCE='0', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
base = folder / 'final1-focused-stores'
supervisor_base = folder / 'final1-supervisor-stores'
assert not base.exists() and not supervisor_base.exists()
state = {
 'scope':'D196 author startup ownership/terminalization correction; independent review and propagated native/performance qualification pending',
 'parent_reported_head':'f6e847b8e25eb4d1068f8b14741fda6fb8bdd0d0',
 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'owned_source_before':owned_before,
 'selected_source_policy':{'roots':source_roots,'extensions':sorted(source_extensions),'symlinks':'excluded','count':len(sources),'not_parent_1110_map':True},
 'selected_source_before':source_before,
 'steps':[], 'complete':False,
}
commands = [
 ('ruff',['.venv/bin/ruff','check',*owned]),
 ('format',['.venv/bin/ruff','format','--check',*owned]),
 ('mypy',['.venv/bin/uv','run','mypy','apps/api','packages/neistra_core','packages/neistra_demo_plugin']),
 ('focused',['.venv/bin/uv','run','pytest','-q',
   'tests/integration/test_ligand_property_startup_ownership.py',
   'tests/integration/test_ligand_property_lifecycle.py',
   'tests/integration/test_ligand_property_warm_authority.py',
   'tests/integration/test_worker_recovery.py',
   'tests/integration/test_job_lifecycle.py',
   'tests/integration/test_job_implementation_version.py',
   'tests/integration/test_job_websocket.py',
   'tests/unit/jobs','tests/unit/test_ligand_property_cache.py',
   'tests/unit/test_ligand_property_preferences.py',
   'tests/unit/test_ligand_property_service_identity.py','--basetemp',str(base)]),
 ('supervisor',['.venv/bin/uv','run','pytest','-q','tests/integration/test_minimization_jobs.py',
   '-k','native_descendants or worker_loss','--basetemp',str(supervisor_base)]),
]
def save(): receipt.write_text(json.dumps(state,indent=2)+'\n')
save()
for name,command in commands:
 print('START',name,flush=True)
 run = subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=False)
 log=folder/f'final1-{name}.log';log.write_bytes(run.stdout)
 state['steps'].append({'phase':name,'command':command,'actual_child_exit':run.returncode,
  'log':str(log.relative_to(root)),'log_sha256':hashlib.sha256(run.stdout).hexdigest()})
 save();print('EXIT',name,run.returncode,flush=True);print(run.stdout.decode(errors='replace')[-7000:],flush=True)
 if run.returncode: sys.exit(run.returncode)
state['owned_source_after']=hashes(owned)
state['selected_source_after']=hashes(sources)
state['owned_sources_unchanged']=state['owned_source_after']==owned_before
state['selected_sources_unchanged']=state['selected_source_after']==source_before
assert state['owned_sources_unchanged'] and state['selected_sources_unchanged']
state.update(complete=True,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
save();print('ENCLOSING COMPLETE',receipt,flush=True)
