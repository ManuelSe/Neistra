"""Independent actual-service validation-gap negative control; no spawned process."""

from types import SimpleNamespace

from sqlalchemy import select

from neistra_api.ligand_property_process import PropertyAttempt, recover_property_processes
from neistra_api.ligand_property_service import LigandPropertyService
from neistra_api.models import Job, LigandPropertyBinding, LigandPropertyContent, LigandPropertyExecution
from tests.conftest import client as client
from tests.integration.test_ligand_property_lifecycle import captured_result, worker
from tests.integration.test_ligand_property_startup_ownership import claimed


def test_reaped_execution_cannot_publish_after_actual_validation_commit(client, monkeypatch):
    _, _, job, inputs = claimed(client)
    attempt = PropertyAttempt.capture(job, job.worker_id)
    values = captured_result(job.parameters, inputs)
    original_commit = LigandPropertyService._commit_derived
    held = False

    def validation_finished(service):
        nonlocal held
        original_commit(service)
        if held:
            return
        held = True
        # Existing recovery marks an unconfirmed child reaped and commits before
        # the ordinary abandoned-job recovery stage. No synthetic SQL mutation.
        with client.app.state.session_factory() as session:
            recover_property_processes(session)
            assert session.get(LigandPropertyExecution, attempt.execution_id).reaped
            assert session.get(Job, job.id).status == "running"

    monkeypatch.setattr(LigandPropertyService, "_commit_derived", validation_finished)
    result = SimpleNamespace(artifacts=(), values=values, warnings=(), message="Actual ready")
    assert worker(client)._handle_message(job.id, ("result", result), attempt=attempt)
    assert held
    with client.app.state.session_factory() as session:
        current = session.get(Job, job.id)
        content = session.scalar(select(LigandPropertyContent))
        binding = session.scalar(select(LigandPropertyBinding))
        print({"status": current.status, "reaped": session.get(LigandPropertyExecution, attempt.execution_id).reaped,
               "content_published": content is not None, "binding_published": binding is not None})
        assert content is None
        assert binding is None
