"""D196 focused startup/publication ownership checkpoint; no runtime/release action."""
from pathlib import Path
import ast,base64,datetime,difflib,hashlib,json,os,runpy,subprocess,zipfile
root=Path.cwd();private=root/'.issue-11-evidence';out=private/'issue159-startup-ownership-packet';assets=root/'docs/assets/ligand-properties';h=runpy.run_path(str(root/'docs/assets/ligand-designation/release-evidence.py.txt'));q=runpy.run_path(str(assets/'qualification.py.txt'));sha=lambda b:hashlib.sha256(b).hexdigest();base='f6e847b8e25eb4d1068f8b14741fda6fb8bdd0d0'
zip_path=assets/'c2-startup-ownership.zip';checkpoint_path=assets/'c2-startup-ownership-checkpoint.json';assert not zip_path.exists() and not checkpoint_path.exists()
author=private/'issue159-startup-ownership';arch1=Path('/tmp/neistra159-d196-independent-kpvsqxg1');arch2=Path('/tmp/neistra159-d196-final2-architecture-qwdshr9i');science=author/'scientific-review1'
def load(p):return json.loads(p.read_bytes())
f1=load(author/'handoff-final1.json');f2=load(author/'handoff-final2.json');sources=f2['owned_source_hashes'];candidate1=f1['owned_source_hashes'];assert len(sources)==len(candidate1)==5
owned_before={n:sha((root/n).read_bytes()) for n in sources};assert owned_before==sources
assert f1['actual_enclosing_exec_session']==95364 and f1['actual_enclosing_exit']==0 and f2['actual_enclosing_exec_session']==18451 and f2['actual_enclosing_exit']==0
receipts={}
for num,handoff,expected in [(1,f1,candidate1),(2,f2,sources)]:
 path=root/handoff['verification_receipt'];r=load(path);receipts[num]=r;assert h['fingerprint'](path)['sha256']==handoff['verification_receipt_sha256']
 assert r['complete'] and r['owned_sources_unchanged'] and r['selected_sources_unchanged'] and r['owned_source_before']==r['owned_source_after']==expected and r['selected_source_before']==r['selected_source_after'] and len(r['selected_source_before'])==988
 for step in r['steps']:assert step['actual_child_exit']==0 and h['fingerprint'](root/step['log'])['sha256']==step['log_sha256']
assert all(sha((author/'candidate1-sources'/n).read_bytes())==v for n,v in candidate1.items())
assert '144 passed' in (author/'final1-focused.log').read_text() and '156 passed' in (author/'final2-focused.log').read_text() and all('6 passed' in (author/f'final{n}-supervisor.log').read_text() for n in [1,2])
assert h['fingerprint'](arch2/'independent-architecture-assessment.json')['sha256']=='06dbb56045df19f4f90f33c3ee50004f180ac65565ad250fba493dae5135756b'
arc1=load(arch1/'independent-architecture-assessment.json');arc2=load(arch2/'independent-architecture-assessment.json');assert arc1['verdict']=='CHANGES_REQUIRED' and arc1['candidate_frozen_owned_sources']==candidate1 and arc2['verdict']=='PASS' and arc2['source_hashes']==sources and not arc2['unresolved_consequential_findings']
run2=load(arch2/'run.json');assert run2['source_before']==run2['source_after']==run2['source_final']==sources and run2['source_unchanged']
for step in run2['steps']:
 filename='original-negative-fixed-import.log' if step['label']=='original-independent-negative-explicit-root-import' else step['label']+'.log'
 assert h['fingerprint'](arch2/filename)['sha256']==step['log_sha256']
assert [s['exit'] for s in run2['steps']]==[0,2,0] and '29 passed' in (arch2/'source-and-gap-controls.log').read_text() and '1 passed' in (arch2/'original-negative-fixed-import.log').read_text()
assert h['fingerprint'](science/'reassessment-final2.json')['sha256']=='affc675f689b370efaf6556cc6345d1e814cd7003f35cd460c4e6fa8edd40863'
sc1=load(science/'assessment.json');sc2=load(science/'reassessment-final2.json');assert sc1['verdict']=='CHANGES_REQUIRED' and sc1['source_identities']==candidate1 and sc1['finding']['actual_session']==93702 and sc1['finding']['actual_exit']==1
assert sc2['verdict']=='PASS' and sc2['source_hashes']==sources and sc2['independent_checks']['actual_session']==93754 and sc2['independent_checks']['exit']==0 and not sc2['unresolved_consequential_findings']
assert h['fingerprint'](author/sc1['finding']['reproduction'])['sha256']==sc1['finding']['reproduction_sha256'] and h['fingerprint'](author/sc1['finding']['raw_log'])['sha256']==sc1['finding']['raw_log_sha256']
assert h['fingerprint'](root/sc2['independent_checks']['log'])['sha256']==sc2['independent_checks']['log_sha256'] and '19 passed' in (root/sc2['independent_checks']['log']).read_text()
perf=load(author/'performance-final2-reported-assessment.json');assert perf['verdict']=='PASS' and perf['owned_source_hashes']==sources and perf['independent_tests_rerun_by_performance_reviewer'] is False and perf['reviewer_execution_session_or_exit'] is None
full_before=q['current_identities'](root);assert all(full_before[n]==v for n,v in sources.items())
base_runtime={n:subprocess.check_output(['git','show',base+':'+n]) for n in sources if n.startswith('apps/')};assert len(base_runtime)==4
items={};captured={};retained={};links=[];omissions={}
def add_file(member,f):
 h['add'](items,member,f,reader_workspace=True);captured[member]=dict(path=str(f),**h['fingerprint'](f))
def collect(directory,prefix):
 assert directory.is_dir() and not directory.is_symlink();rows={};excluded=[]
 for f in sorted(directory.rglob('*')):
  member=prefix+'/'+f.relative_to(directory).as_posix()
  if f.is_symlink():
   target=f.resolve();assert target.exists() and target.is_relative_to(directory.resolve());links.append(dict(member=member,path=str(f),raw_link_text=os.readlink(f),raw_link_bytes_base64=base64.b64encode(os.fsencode(os.readlink(f))).decode(),lstat_mode=f.lstat().st_mode,resolved_member=prefix+'/'+target.relative_to(directory.resolve()).as_posix(),target_is_directory=target.is_dir(),followed=False));continue
  if not f.is_file():continue
  if h['CACHE_PARTS'].intersection(f.parts) or f.suffix in {'.pyc','.pyo'}:excluded.append(dict(path=f.relative_to(directory).as_posix(),**h['fingerprint'](f)));continue
  add_file(member,f);rows[member]=h['fingerprint'](f)
 retained[str(directory)]=dict(prefix=prefix,files=len(rows),bytes=sum(v['bytes'] for v in rows.values()),all_noncache_regular_files_retained=True);omissions[str(directory)]=excluded
collect(author,'author-and-science');collect(arch1,'independent-architecture-original');collect(arch2,'independent-architecture-final2')
assert len(links)==220
propagation={}
for tree,expected_count,session,chunk in [('issue-160-physicochemical-profiles',1080,14403,'4fc17d'),('issue-161-ligand-information-sidebar',1091,61535,'73e47b')]:
 dest=root.parent/tree;d=dest/'.issue-11-evidence/issue159-startup-ownership-propagation';prefix='destination-propagation/'+tree;root_actual=load(d/'root-actual-gate2-enclosing.json');gate2=load(d/'gate2/receipt.json');gate1=load(d/'gate1/receipt.json');overlay=load(d/'propagation.json');borrow=load(d/'borrowed-regression-baseline.json')
 assert root_actual['actual_session']==session and root_actual['actual_chunk']==chunk and root_actual['actual_exit']==0 and root_actual['complete_source_count']==expected_count and root_actual['receipt_sha256']==h['fingerprint'](d/'gate2/receipt.json')['sha256']
 assert gate2['complete'] and gate2['sources_unchanged'] and gate2['source_before']==gate2['source_after'] and len(gate2['source_before'])==expected_count
 assert overlay['source_frozen_hashes']==sources and overlay['all_copied_bytes_exact'] and overlay['all_current_runtime_AST_identical_to_pre_D196_before_copy']
 for step in gate2['steps']:assert step['exit_code']==0 and step['sources_fixed'] and h['fingerprint'](Path(step['log']))['sha256']==step['log_sha256']
 assert gate1['complete'] is False and gate1['steps'][-1]['exit_code']==4 and borrow['first_gate_observed_outer_exit']==4
 for step in gate1['steps']:assert h['fingerprint'](Path(step['log']))['sha256']==step['log_sha256']
 assert all(sha((dest/n).read_bytes())==v for n,v in sources.items())
 for n,b in base_runtime.items():assert ast.dump(ast.parse((d/'before'/n).read_bytes()),include_attributes=False)==ast.dump(ast.parse(b),include_attributes=False)
 for row in borrow['new_modules']:
  n=row['path'];body=subprocess.check_output(['git','show',base+':'+n]);assert sha(body)==row['sha256']==sha((dest/n).read_bytes())==sha((root/n).read_bytes());assert len(body)==row['bytes'];member='borrowed-C1-regression-source/'+n
  if member not in items:h['add'](items,member,body)
 for f in sorted(d.rglob('*')):
  if any('stores' in part for part in f.relative_to(d).parts):continue
  assert not f.is_symlink()
  if f.is_file():add_file(prefix+'/'+f.relative_to(d).as_posix(),f)
 propagation[tree]=dict(root_actual=root_actual,before_four_full_AST_equal_to_C1base=True,current_five_exact=True,borrowed_four_modules_exact=True,gate1_setup_exit=4,gate1_no_tests_collected=True,gate2_source_scope=expected_count,gate2_focused=156,gate2_supervisors=6,mypy=280,ruff_format='PASS',destination_stores_originals_untouched_not_bundled=True)
for n in sources:add_file('current-five-source/'+n,root/n)
for n,b in base_runtime.items():h['add'](items,'base-C1-runtime-source/'+n,b)
h['add'](items,'operations/packager.py',Path(__file__));h['add'](items,'owned-links.json',h['encoded'](dict(scope='Exact220pytestalias metadata only; no archive links or arbitrary following, actual owned target bytes retained separately',links=links)));h['add'](items,'raw-retention.json',h['encoded'](dict(roots=retained,named_cache_omissions=omissions,all_originals_preserved=True)))
proof=dict(scope='Frozen D196five source bodies and historical candidate1 exact-source maps; author988guard and root full union are distinct scopes',comparison_base=base,current_five_before=owned_before,current_five_after={n:sha((root/n).read_bytes()) for n in sources},current_five_count=5,candidate1_five=candidate1,candidate1_private_sources_retained=True,author_final1_guard_count=988,author_final2_guard_count=988,author_guards_are_not_full_root_release_union=True,author_final1_selected_before_after_equal=True,author_final2_selected_before_after_equal=True,root_full_union_snapshot_before=full_before,root_full_union_snapshot_count_before=len(full_before),root_full_union_snapshot_after=q['current_identities'](root),root_full_union_snapshot_is_not_release_qualification=True,captured_originals=captured,destination_five_source_checks={tree:True for tree in propagation});assert proof['current_five_before']==proof['current_five_after']==sources;h['add'](items,'source-proof.json',h['encoded'](proof))
review=dict(software_architecture=dict(verdict='PASS',scope='D196fivepathfinal2only',original_CHANGES_REQUIRED_retained=True,final2_assessment_sha256='06dbb56045df19f4f90f33c3ee50004f180ac65565ad250fba493dae5135756b',actual_sessions=[1384,35599],actual_exits=[0,0],controls=29,separate_original_negative_passed=1,setup_collection_exit2_retained=True),scientific_implementation=dict(verdict='PASS',scope='D196fivepathfinal2only',original_negative_session=93702,original_negative_exit=1,prior_positive_session=96530,prior_positive_cases=8,prior_positive_exit=0,final2_session=93754,final2_exit=0,final2_cases_including_original_negative=19,assessment_sha256='affc675f689b370efaf6556cc6345d1e814cd7003f35cd460c4e6fa8edd40863'),performance=dict(verdict='PASS',scope='Code/boundedwork and retained evidence inspection; no independent test execution or integrated performance approval',conversation_transcription=True,reviewer_execution_ids=None,independent_tests=False),three_scoped_roles_are_not_allsevenfinal=True)
h['add'](items,'scoped-review-provenance.json',h['encoded'](review));h['add'](items,'destination-proof.json',h['encoded'](propagation))
facts=dict(scope='D196focused startup/process/publication ownership checkpoint only; not full feature/native/performance/release/allsevenreadiness',repository='ManuelSe/Neistra',issue=159,parent=11,base=base,current_five_source_identities=sources,candidate1_source_identities=candidate1,source_guard=dict(author_selected_count=988,root_full_union_count_observed=len(full_before),author988_not_root_full1111_union=True,current_five_fixed=True),author_candidate1=dict(actual_session=95364,actual_exit=0,focused=144,real_supervisors=6,mypy=274,ruff_format='PASS'),author_final2=dict(actual_session=18451,actual_exit=0,focused=156,real_supervisors=6,mypy=274,ruff_format='PASS'),scoped_reviews=review,destination_propagation=propagation,mechanism='Immutable exact captured attempt/CAS guards startup, frames, terminalization and publication. Group signaling authority begins only after durable actual process registration; ACK ordering and original limits/checkpoints remain. Reaped execution is refused initially and after validation under the refreshed publication lock, with one shared exact-capture truthful failed/cancelled terminalizer. Replacement/deleted/terminal state is preserved.',scientific_scope='D196five paths do not change D194kernel/fixture method, numerical output, source/coverage identity, cache admission, resource budgets or fairness. Relevant source/science/performance assessments retained; no new scientific/performance qualification inferred.',raw_retention=retained,symlink_metadata_count=len(links),named_cache_omissions=omissions,failed_evidence='Original author probe1 scheduling8failures/10passes, scientific actual93702negative, architecture collection/import setup failure, original destination gate1exit4 before collection and all closed focused stores/logs remain distinct and byte-retained. Passing segments are not pooled into a full gate.',observation_limits='Native1 exact original runtime branch remains qualified inference; offline actualworker/database/process mechanisms are independently confirmed within recorded scopes. Performance assessment is a primary transcription of actual specialist conversation, not raw execution or an independent benchmark. Source count988guards author checks; root1111snapshot and destination1080/1091guards are separately named and no full release union approval follows.',required_next=['RootD197ownerfix propagation and current integrated workflow reconciliation','Fresh current native8/performance8 and four1000entrycohorts without pooling earlier timings','Allsevenfinalsamecandidate and fresh complete candidate/exactmaster release gates','Protectedreview/merge, actualrelease/publicassets verification and issue/programcloseout'])
h['add'](items,'checkpoint-context.json',h['encoded'](facts));estimate=sum(h['compressed_size'](b) for b in items.values());assert estimate<76*1024*1024;packet=h['archive'](items,zip_path);assert packet['bytes']<80*1024*1024
assert {n:sha((root/n).read_bytes()) for n in sources}==sources and all(h['fingerprint'](Path(row['path']))=={k:row[k] for k in ['bytes','sha256']} for row in captured.values())
for row in links:
 f=Path(row['path']);assert f.is_symlink() and os.readlink(f)==row['raw_link_text'] and f.lstat().st_mode==row['lstat_mode']
record=dict(**facts,archive=packet['file'],archive_bytes=packet['bytes'],archive_sha256=packet['sha256'],outer_manifest_entries=packet['outer_manifest_entries'],recursive_verification=packet['verification_counts'],observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());checkpoint_path.write_text(json.dumps(record,indent=2)+'\n');(out/'packager-result.json').write_text(json.dumps(dict(archive=packet,checkpoint=h['fingerprint'](checkpoint_path),five_frozen_sources_unchanged=True,all_captured_originals_unchanged=True,retention=retained,link_metadata_count=len(links),named_cache_omissions=omissions),indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
