from __future__ import annotations
import json, shutil, sqlite3, sys, hashlib
from pathlib import Path
from datetime import timedelta
from types import SimpleNamespace
from collections import deque
from unittest.mock import patch
root=Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
for d in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src']:
 sys.path.insert(0,str(root/d))
from neistra_api.database import create_database_engine,create_session_factory
from neistra_api.models import Job,LigandPropertyExecution,LigandPropertyConsumer,utc_now
from neistra_api.settings import Settings
from neistra_api.job_worker import JobWorker
from neistra_api import job_worker as worker_module
from neistra_api.ligand_property_service import LigandPropertyService
from neistra_core.jobs import PluginRegistry
out=Path(__file__).parent
src=Path('/datadisk/dev/neistra-worktrees/issue-161-ligand-information-sidebar/.issue-11-evidence/issue161-native-root/native1/sqlite-readback-copy')
jobid='01a1ebe2-563c-767b-b7e2-71daffeb6f5f'
second='01a1ebe2-6576-76cf-8b5e-9641590093a4'
results=[]
for wanted in [False,True]:
 store=out/('wanted-store' if wanted else 'retired-store');store.mkdir()
 raw=store/'readback';shutil.copytree(src,raw)
 with sqlite3.connect(raw/'neistra.db') as source,sqlite3.connect(store/'neistra.db') as target: source.backup(target)
 for d in ['artifacts','cache']: shutil.copytree(Path('/tmp/neistra161-worker-handshake-_8hqe6z2/store')/d,store/d)
 settings=Settings(data_dir=store,database_url='sqlite:///'+str(store/'neistra.db'))
 engine=create_database_engine(settings.database_url);factory=create_session_factory(engine)
 registry=PluginRegistry.load(allowlist=settings.job_plugin_allowlist,configured_targets=settings.job_plugin_targets,discover_installed=True)
 with factory() as session:
  job=session.get(Job,jobid); exe=session.get(LigandPropertyExecution,job.parameters['execution_id'])
  exe.reaped=False;exe.child_pid=None;exe.child_start_token=None;exe.group_confirmed=False
  session.get(LigandPropertyConsumer,second).expires_at=utc_now()+timedelta(seconds=120)
  if wanted:
   target=exe.captures[0]['targets'][0]; owner=target['consumers'][0];consumer=session.get(LigandPropertyConsumer,owner['id'])
   consumer.generation=owner['generation'];consumer.entries_json=[target['source']];consumer.descriptor_ids=owner['descriptor_ids'];consumer.active_entry_id=target['source']['entry_id'];consumer.released=False;consumer.failures={};consumer.expires_at=utc_now()+timedelta(seconds=120)
  session.commit();workerid=job.worker_id
 proc=SimpleNamespace(pid=99999999,alive=False,exitcode=None,starts=0,terminations=0)
 def start(): proc.starts+=1;proc.alive=True
 def terminate(): proc.terminations+=1;proc.alive=False;proc.exitcode=-15
 proc.start=start;proc.is_alive=lambda:proc.alive;proc.terminate=terminate;proc.join=lambda timeout:None
 frames=deque([('process_group',proc.pid)]);controls=[];signals=[]
 pipe=SimpleNamespace(poll=lambda *a:bool(frames),recv=frames.popleft,send=controls.append,close=lambda:None)
 context=SimpleNamespace(Pipe=lambda **kw:(pipe,SimpleNamespace(close=lambda:None)),Process=lambda **kw:proc)
 runner=JobWorker(settings,factory,registry,workerid)
 with patch.object(worker_module.multiprocessing,'get_context',lambda *a:context),patch.object(worker_module.os,'killpg',lambda *a:signals.append(a)):
  runner._run_claimed(job,())
 with factory() as session:
  actual=session.get(Job,jobid);exe=session.get(LigandPropertyExecution,job.parameters['execution_id'])
  assert actual.status==('failed' if wanted else 'cancelled'),actual.status
  assert actual.completed_at and exe.reaped
  assert not controls and not signals and not proc.alive
  nextjob=LigandPropertyService(session,settings).materialize('independent-next')
  assert isinstance(nextjob,Job) and nextjob.id!=jobid
  row={'case':'wanted_registration_refusal' if wanted else 'retired_original_attempt','status':actual.status,'error':actual.error,'reaped':exe.reaped,'process_starts':proc.starts,'owned_handle_terminations':proc.terminations,'group_signal_requests':signals,'calculation_permissions':controls,'next_materialize_admitted':nextjob.id,'actual_process_spawned':False,'actual_signals_sent':False}
  results.append(row)
 engine.dispose()
report={'scope':'Independent D196 replay on private copies of retained readback database and previously copied artifacts. Wanted case explicitly restores captured owner generation/source/lease; no native calculation/services/spawn/signals. Original failed run is untouched.','results':results}
(out/'copied-store-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
