"""Verify focused native results and copy retained SQLite bytes before SQL."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,shutil,socket,time

OUT=Path(__file__).absolute().parent
ROOT=OUT.parents[1]
launch=json.loads((OUT/'native-launch.json').read_bytes())
terminal=json.loads((OUT/'native-terminal.json').read_bytes())
WORK=Path(launch['workspace'])
assert terminal['actual_wait_returncode']==0 and terminal['source_unchanged']
known={}
for line in (OUT/'process-observations.jsonl').read_text().splitlines():
 for item in json.loads(line)['processes']:
  known[(item['pid'],item['start_token'])]=item
known[(launch['identity']['pid'],launch['identity']['start_token'])]=launch['identity']
def kernel(pid):
 text=(Path('/proc')/str(pid)/'stat').read_text();parts=text[text.rindex(')')+2:].split()
 return {'pid':pid,'state':parts[0],'start_token':parts[19]}
remaining=[]
for (pid,token) in known:
 try:actual=kernel(pid)
 except FileNotFoundError:continue
 if actual['start_token']==token and actual['state']!='Z':remaining.append(actual)
markers=[]
for path in Path('/proc').iterdir():
 if not path.name.isdigit():continue
 try:
  before=kernel(int(path.name));command=(path/'cmdline').read_bytes();after=kernel(int(path.name))
 except (FileNotFoundError,ProcessLookupError):continue
 if str(WORK).encode() in command and before['start_token']==after['start_token'] and after['state']!='Z':
  markers.append({**after,'command':command.decode(errors='replace')})
ports={}
for port in launch['ports']:
 with socket.socket() as probe:
  probe.settimeout(1);ports[str(port)]=probe.connect_ex(('127.0.0.1',port))!=0
assert not remaining and not markers and all(ports.values()),(remaining,markers,ports)
cleanup_ns=time.monotonic_ns()
cleanup={'complete':True,'monotonic_ns':cleanup_ns,'recorded_utc':datetime.now(timezone.utc).isoformat(),
 'known_PID_start_handles_checked':len(known),'positively_owned_processes_remaining':remaining,
 'live_exact_workspace_data_markers':markers,'ports_unused':ports,'signals_sent':False,'SQL_opened':False}
p=OUT/'cleanup-before-raw-copy.json';assert not p.exists();p.write_text(json.dumps(cleanup,indent=2)+'\n')
started=time.monotonic_ns();destination=OUT/'post-cleanup-raw-database-bytes';assert not destination.exists()
files={};absent=[]
for source in sorted(WORK.rglob('*')):
 assert not source.is_symlink(),source
 if not source.is_file() or not source.name.endswith(('.db','.sqlite','.sqlite3','.db-wal','.db-shm','.sqlite-wal','.sqlite-shm','.sqlite3-wal','.sqlite3-shm')):continue
 relative=source.relative_to(WORK);body=source.read_bytes();copy=destination/relative;copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy)
 assert copy.read_bytes()==body==source.read_bytes()
 files[str(relative)]={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'original':str(source),'copy':str(copy)}
 if source.name.endswith(('.db','.sqlite','.sqlite3')):
  absent.extend(str(Path(str(source)+suffix).relative_to(WORK)) for suffix in ('-wal','-shm') if not Path(str(source)+suffix).exists())
assert files
browser=json.loads((OUT/'browser.json').read_bytes());stats=browser['stats']
assert stats['expected']==12 and stats['skipped']==stats['unexpected']==stats['flaky']==0
assert not browser.get('errors')
tests=[]
def visit(suite):
 for spec in suite.get('specs',[]):
  for test in spec['tests']:
   assert test['expectedStatus']=='passed' and test['status']=='expected'
   assert len(test['results'])==1 and test['results'][0]['status']=='passed' and test['results'][0]['retry']==0
   tests.append({'project':test['projectName'],'title':spec['title'],'status':'passed','attempts':1,'retry':0})
 for child in suite.get('suites',[]):visit(child)
for suite in browser['suites']:visit(suite)
assert len(tests)==12
before=json.loads((OUT/'source-before.json').read_bytes());after=json.loads((OUT/'source-after.json').read_bytes());assert before==after and len(before)==1130
record={'scope':'Focused entire minimization-controls file both projects; not full qualification.',
 'actual_native_wait_returncode':0,'tests':tests,'stats':stats,'source_before_after_exact':True,'selected_source_count':len(before),
 'source_digest_compact':hashlib.sha256(json.dumps(before,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
 'cleanup_monotonic_ns':cleanup_ns,'raw_copy_started_monotonic_ns':started,'cleanup_before_copy':cleanup_ns<started,
 'files':files,'absent_sidecars':absent,'SQL_opened':False,'originals_retained':True,
 'finished_utc':datetime.now(timezone.utc).isoformat()}
p=OUT/'raw-copy-and-native-readback.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'receipt':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':len(tests),'raw_files':len(files),'known_owned_handles':len(known)}))
