import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import ts from '../../apps/web/node_modules/typescript/lib/typescript.js';

const root = process.cwd();
const output = path.join(root, '.issue-11-evidence/issue159-minimization-route-lifetime-correction1');
const subject = path.join(root, 'tests/e2e/minimization-controls.spec.ts');
const configPath = path.join(output, 'tsconfig.json');
const config = ts.readConfigFile(configPath, ts.sys.readFile);
assert.equal(config.error, undefined);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, output);
assert.deepEqual(parsed.errors, []);
const before = fs.readFileSync(path.join(output, 'minimization-controls.before.ts'), 'utf8');
const current = fs.readFileSync(subject, 'utf8');
const replacement = '  } finally {\n    held.resolve();\n    await page.unrouteAll({ behavior: "wait" });\n  }';
assert.equal(before.replaceAll('  } finally { held.resolve(); }', replacement), current);

function diagnostics(source) {
  const host = ts.createCompilerHost(parsed.options);
  const read = host.readFile.bind(host);
  host.readFile = filename => path.resolve(filename) === subject ? source : read(filename);
  const program = ts.createProgram(parsed.fileNames, parsed.options, host);
  return ts.getPreEmitDiagnostics(program).map(item => {
    const position = item.file && item.start !== undefined
      ? item.file.getLineAndCharacterOfPosition(item.start) : undefined;
    return {code: item.code, category: item.category,
      file: item.file ? path.relative(root, item.file.fileName) : null,
      line: position ? position.line + 1 : null, column: position ? position.character + 1 : null,
      message: ts.flattenDiagnosticMessageText(item.messageText, '\n')};
  });
}
const original = diagnostics(before);
const corrected = diagnostics(current);
const keys = entries => entries.map(({line, column, ...rest}) => JSON.stringify(rest)).sort();
assert.deepEqual(keys(original), keys(corrected), 'The correction added or changed strict diagnostics');
const sha = text => crypto.createHash('sha256').update(text).digest('hex');
const record = {scope: 'Optional expanded strict E2E boundary differential; not a passing strict check or substitute for normal web gate.',
  before_sha256: sha(before), current_sha256: sha(current), compiler_version: ts.version,
  config_sha256: sha(fs.readFileSync(configPath)), original, corrected,
  normalized_diagnostics_exact: true, additional_diagnostics: 0,
  strict_check_passed: corrected.length === 0, suppressions_added: false,
  source_override_in_memory_only: true};
const receipt = path.join(output, 'strict-types-differential.json');
assert.equal(fs.existsSync(receipt), false);
fs.writeFileSync(receipt, JSON.stringify(record, null, 2) + '\n');
console.log(JSON.stringify({receipt, original_diagnostics: original.length, corrected_diagnostics: corrected.length,
  additional_diagnostics: 0, strict_check_passed: record.strict_check_passed}));
