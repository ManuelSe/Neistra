"""Focused minimization-route lifetime qualification; no complete release-gate claim."""
from pathlib import Path
import datetime,hashlib,json,os,runpy,socket,subprocess,time
ROOT=Path.cwd();OUT=ROOT/'.issue-11-evidence/issue159-minimization-route-lifetime-correction1'
WORK=Path('/tmp/neistra159-minimization-route-lifetime-correction1')
FILES=['tests/e2e/minimization-controls.spec.ts']
PORTS=[23910,23911,23912]
helper=runpy.run_path(str(ROOT/'docs/assets/ligand-properties/qualification.py.txt'),run_name='pure_source_audit')
def sources():
 return helper['current_identities'](ROOT)

def kernel(pid):
 raw=(Path('/proc')/str(pid)/'stat').read_text();v=raw[raw.rindex(')')+2:].split()
 return {'pid':pid,'state':v[0],'ppid':int(v[1]),'pgid':int(v[2]),'session':int(v[3]),'start_token':v[19]}

def observe(pid,start):
 snapshot={}
 for proc in Path('/proc').iterdir():
  if proc.name.isdigit():
   try:snapshot[int(proc.name)]=kernel(int(proc.name))
   except (OSError,ValueError,IndexError):pass
 selected={pid} if pid in snapshot and snapshot[pid]['start_token']==start else set()
 while True:
  more=selected|{n for n,v in snapshot.items() if v['ppid'] in selected}
  if more==selected:break
  selected=more
 rows=[]
 for n in sorted(selected):
  try:
   cmd=[v.decode() for v in (Path('/proc')/str(n)/'cmdline').read_bytes().split(b'\0') if v];now=kernel(n)
   if now['start_token']==snapshot[n]['start_token'] and now['state']!='Z':rows.append({**now,'command':cmd})
  except (OSError,ValueError,IndexError,UnicodeError):pass
 with (OUT/'process-observations.jsonl').open('a') as out:out.write(json.dumps({'monotonic_ns':time.monotonic_ns(),'known_child_start':start,'processes':rows})+'\n')

assert not WORK.exists();WORK.mkdir()
for port in PORTS:
 with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',port))!=0,port
before=sources();(OUT/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
env=os.environ.copy()
for key in ['NEISTRA_DATA_DIR','NEISTRA_DATABASE_URL','MOLWEAVE_DATA_DIR','MOLWEAVE_DATABASE_URL','DATABASE_URL','NEISTRA_PROPERTY_WORKER_TRACE']:
 env.pop(key,None)
env.update({'NEISTRA_QUALIFICATION_VERSION':'0.37.0','NEISTRA_QUALIFICATION_BASE':'247ab651b35c2d58e8939985ae50633de70311a3','PYTHONPATH':':'.join(str(ROOT/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src','.']),'NEISTRA_AMBERTOOLS_PREFIX':'/datadisk/dev/.neistra-tools/ambertools-24.8','PLAYWRIGHT_BROWSERS_PATH':'/datadisk/dev/neistra/.playwright','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','NEISTRA_PERFORMANCE':'0','NEISTRA_E2E_DATA_DIR':str(WORK/'e2e'),'NEISTRA_E2E_API_PORT':str(PORTS[0]),'NEISTRA_E2E_WORKER_PORT':str(PORTS[1]),'NEISTRA_E2E_WEB_PORT':str(PORTS[2]),'PLAYWRIGHT_JSON_OUTPUT_FILE':str(OUT/'browser.json'),'NEISTRA_MINIMIZATION_EVIDENCE_DIR':str(WORK/'native')})
collect=['corepack','pnpm','exec','playwright','test',*FILES,'--list']
with (OUT/'inventory.log').open('xb') as log:code=subprocess.run(collect,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=False).returncode
assert code==0,'Focused collection failed; originals retained'
command=['corepack','pnpm','exec','playwright','test',*FILES,'--reporter=list,json','--max-failures=1','--retries=0','--output',str(OUT/'native')]
with (OUT/'native.log').open('xb') as log:
 process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,stdin=subprocess.DEVNULL)
 first=kernel(process.pid);assert first['pgid']==first['session']==process.pid
 identity={**first,'command':[v.decode() for v in (Path('/proc')/str(process.pid)/'cmdline').read_bytes().split(b'\0') if v]}
 launch={'scope':'Entire minimization-controls native file in both configured projects; local correction only.','base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'identity':identity,'workspace':str(WORK),'ports':PORTS,'selected_source_count':len(before),'source_selector':'Exact issue159 qualification.py.txt current_identities selector; before/after maps.'}
 (OUT/'native-launch.json').write_text(json.dumps(launch,indent=2)+'\n');print(json.dumps(launch),flush=True);started=time.monotonic()
 while True:
  observe(process.pid,first['start_token'])
  try:code=process.wait(timeout=1);break
  except subprocess.TimeoutExpired:pass
 observe(process.pid,first['start_token'])
after=sources();(OUT/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n');assert before==after,'Selected source changed during local run'
terminal={'scope':'Focused minimization-controls native run, not full release qualification.','actual_wait_returncode':code,'elapsed_seconds':time.monotonic()-started,'source_unchanged':True,'selected_source_count':len(after),'log_sha256':hashlib.sha256((OUT/'native.log').read_bytes()).hexdigest(),'original_child_identity':identity,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(OUT/'native-terminal.json').write_text(json.dumps(terminal,indent=2)+'\n');print(json.dumps(terminal),flush=True);raise SystemExit(code)
