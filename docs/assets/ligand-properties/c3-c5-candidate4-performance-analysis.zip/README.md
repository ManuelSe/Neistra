# Closed C4 property performance analysis

Candidate `b1cdb138c7becb5afa73b8f9bbf1e6d958ae8582`; original full gate label
`c5-candidate4`. This directory contains closed-data analysis and its complete
adapter history. It changes no application, test, selected source, original input,
database, budget, fixture, sampling cadence or policy. No workload is rerun.

The original gate actually exits zero with all43 commands,3598 Python tests,
1599 frontend tests,14 supervisor tests and640 native identities:565 passes and
the exact75 released exclusions. The analysis independently reconciles the full
browser report, cases, inventory and released exclusion identities, then selects
the exact eight single-attempt property performance cases.

`analyze3.py` is the executed adapter. It preserves all nine accepted native12
helper bodies, the complete numerical/work/per-case resource core and the combined
distribution core. It adds C4 terminal/source barriers, source-capsule checks,
complete480-file observer-root checks and exact mirror/header/global-trace-window
checks. Both original source maps remain separate; exactly two unrelated test
files differ, while all52 benchmark-method and789 observer bodies are equal.

The actual successful command is:

```sh
.venv/bin/python -B .issue-11-evidence/issue159-c5-candidate4-performance-analysis1/analyze3.py --terminal-proof /datadisk/dev/neistra-worktrees/issue-159-observer-snapshots/.issue-11-evidence/issue159-c5-candidate4-transport1/primary-terminal-readback.json --terminal-proof-sha256 6f22101b7f76027217844c9f3076663ac027a3bc97ca1bb23eecfa79bf5be0d9
```

The analyzer refuses to overwrite existing results. For independent reproduction
in this retained workspace, copy `analyze3.py` and `closed-input-bindings3.json`
into a fresh directory within the same workspace and invoke the copied script
with the same proof arguments. Absolute original-input paths remain explicit;
no different-host portability is claimed. `independent-numeric-check.py` is a
separate direct arithmetic reconciliation, whose actual run also exits zero.

Headline C4 measurements, using median/nearest-rank p95/max:

| Quantity | Median / p95 / max | Original target misses |
| --- | --- | --- |
|40 cold actual edits |2786.6 /3567.5 /3647.9ms |39/40 above2000ms |
|40 matching-cache projections |98.85 /124 /128.1ms |20/40 above100ms |
|84 click-feedback observations |103.4 /132.1 /1052.1ms |46/84 above100ms |
|4 active edits during bulk |6979.85 /7997.8 /7997.8ms |4/4 above5000ms |
|2 cancellation feedback observations |8.6 /13 /13ms |0/2 above100ms |

Desktop repeated/distinct bulk active updates are7070.7/7997.8ms; mobile updates
are5344.1/6889ms. Each bulk has1000 ready entries, five200-entry owners, actual
active-priority overlap, at most one productive fairness turn before admission,
one productive derived turn before the ordinary job claim, and3/127 private jobs
for repeated/distinct inputs, all reaped and within129. Each paired cold and warm
window has exactly two source READs and one demand PUT; all40 warm observations
create zero new jobs. These are aggregate descriptor operations.

Every one of93 actual lease renewals is included:28,056,765 UTF-8 response-body
bytes and133 consumer updates including allocation/initial demand. This byte total
describes renewal response strings, not all network traffic or transport framing.
Other request counts remain separately scoped in `assessment.json`; unavailable
non-renewal wire-byte totals are not inferred from reserialized objects.

Cold changed-input timing, warm automatic READY, deliberate mobile presentation
opening and matching-cache projection are distinct recorded boundaries. Five fresh
browser contexts per profile do not imply a cold operating system or process.
All50 document-clock calibrations retain their actual time origins. Both mobile
retirement phases each have20 hidden/unobserved values: their latency is unavailable,
never zero. Desktop retirement observations retain their measured spread.

The C4 case observers have10023 samples, with sampled child RSS peak119,357,440
bytes and worker-parent peak207,802,368 bytes. Those peaks are discrete observations,
not simultaneous process totals or every-instant ceilings. C4 has no wrapper
CPU/RSS/load sample stream; native12's535 wrapper samples remain historical.
Whole-browser/GPU/short-lived-process accounting and controlled hardware/load
conditions are unavailable. Counts of observed historical jobs across cases must
not be summed as new job spawns.

Bulk phase spans include approximately1.20–1.58s click-to-acknowledgement,
0.36–2.94s acknowledgement-to-first-current-READ and up to2.48s first READ await.
These client-observed spans may include scheduling, transport and overlapping
work; they neither isolate server CPU nor establish a causal bottleneck. A future
controlled attribution experiment would require matched load and tracing and is
outside this analysis. No optimization or timing-budget change is proposed here.

D148 permits portable correctness while retaining every original latency target
and miss. All hard work, source, resource-retention, fairness, cancellation and
scientific identity checks inspected here pass. Native12 remains descriptive
context with identical scientific inputs/method bodies; no controlled A/B speedup,
causal regression, universal throughput or strict reference-host certification
is claimed. Final same-candidate specialist and release approval remain separate.

Two preparation mistakes are preserved. `static-attempt1` records the absent raw
browser JSON path after official lossless gzip retention. `analysis-attempt2`
records a boolean exclusion-field schema correction before metric analysis.
Neither reruns a native campaign, modifies originals or becomes another failed
campaign forensic asset. Their commands and actual exits are in `execution.json`.
