"""Recompute C4 headline values directly from the eight closed metric files."""
from pathlib import Path
import hashlib
import json
import math
import statistics

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).resolve().parent
assessment = json.loads((OUT/'assessment.json').read_bytes())
identities = json.loads((OUT/'input-identities.json').read_bytes())


def read(path):
    body = path.read_bytes()
    expected = identities[str(path.relative_to(ROOT))]
    assert len(body) == expected['bytes']
    assert hashlib.sha256(body).hexdigest() == expected['sha256']
    return json.loads(body)


def distribution(values, limit=None):
    ordered = sorted(values)
    assert ordered and all(type(value) in [int,float] and math.isfinite(value) and value >= 0 for value in ordered)
    answer = {'n':len(ordered),'median':statistics.median(ordered),
              'p95_nearest_rank':ordered[math.ceil(.95*len(ordered))-1],
              'min':ordered[0],'max':ordered[-1]}
    if limit is not None:answer.update(limit=limit,misses=sum(value > limit for value in ordered))
    return answer


cold = []; cache = []; feedback = []; cancellation = []; bulk = []
renewals = []; updates = []; reports = []; annotations = {}
warm_jobs = 0; clocks = 0; edit_pairs = {}; bulk_values = {}
for item in assessment['closed_observers']:
    directory = ROOT/item['case']
    paths = list(directory.glob('native-*-performance.json'));assert len(paths) == 1
    data = read(paths[0]);observer = read(directory/'worker-observation.json')
    reports.append(observer)
    for target in data['targets']:annotations.setdefault(target['label'],[]).append(target)
    if 'records' in data:
        pairs = [row for row in data['records'] if row['kind'] == 'paired-edit']
        assert len(pairs) == 20
        cold.extend(row['cold']['networkCurrentMs'] for row in pairs)
        cache.extend(row['cachedProjectionMs'] for row in pairs)
        feedback.extend(row[phase]['feedbackMs'] for row in pairs for phase in ['cold','warm'])
        warm_jobs += sum(row['warmNewJobs'] for row in pairs)
        clocks += len(data['pageClocks'])
        edit_pairs[data['profile']] = [(row['index'],row['firstInputHash'],row['changedInputHash']) for row in pairs]
        profile = assessment['profiles'][data['profile']]
        assert distribution([row['cold']['networkCurrentMs'] for row in pairs],2000) == profile['cold_edit_ms']
        assert distribution([row['cachedProjectionMs'] for row in pairs],100) == profile['matching_cache_projection_ms']
        for phase in ['cold','warm']:
            available = [row[phase]['retirementMs'] for row in pairs if type(row[phase].get('retirementMs')) in [int,float]]
            assert profile['source_retirement_scope'][phase]['unavailable_retirement_latency'] == 20-len(available)
            assert profile['source_retirement_scope'][phase]['measured_retirement_ms'] == (distribution(available) if available else None)
    elif 'cancellation' in data:
        cancellation.append(data['cancellation']['currentMs'])
    else:
        bulk.append(data['active']['networkCurrentMs']);feedback.append(data['active']['feedbackMs'])
        updates.extend(data['consumerUpdates'])
        renewals.extend(row for row in data['consumerUpdates'] if row['kind'] == 'same-sequence-heartbeat')
        bulk_values[(data['profile'],data['kind'])] = data['active']['networkCurrentMs']

assert len(cold) == len(cache) == 40 and len(feedback) == 84 and len(bulk) == 4 and len(cancellation) == 2
assert distribution(cold,2000) == assessment['combined']['all40_cold_actual_edits_ms']
assert distribution(cache,100) == assessment['combined']['all40_matching_cache_projection_ms']
assert distribution(bulk,5000) == assessment['combined']['four_bulk_active_ms']
assert distribution(cancellation,100) == assessment['combined']['cancellation_feedback_ms']
assert warm_jobs == 0 and clocks == 50
for row in assessment['bulk_cases']:assert row['active_READY_ms'] == bulk_values[(row['profile'],row['kind'])]
for label,values in annotations.items():
    expected = {**distribution([row['actual'] for row in values],values[0]['limit']),'enforced':False}
    assert expected == assessment['all_timing_annotation_groups'][label]
assert set(annotations) == set(assessment['all_timing_annotation_groups'])
renewal = {'calls':len(renewals),'full_UTF8_response_body_bytes':sum(len(row['responseBody'].encode('utf-8')) for row in renewals),'all_consumer_updates':len(updates)}
assert renewal == assessment['renewal_totals']
assert sum(row['samples'] for row in reports) == assessment['saved_resources']['case_observer_samples_total']
assert max(max(row.get('peak_child_rss_bytes',{}).values(),default=0) for row in reports) == assessment['saved_resources']['case_observer_peak_child_RSS_bytes_max']
assert max(max(row.get('peak_worker_parent_rss_bytes',{}).values(),default=0) for row in reports) == assessment['saved_resources']['case_observer_peak_worker_parent_RSS_bytes_max']
result = {'scope':'Independent direct arithmetic reconciliation of actual closed C4 metric files; no workload execution.',
          'candidate':assessment['candidate'],'eight_metric_and_observer_files_bound_to_consumed_input_manifest':True,
          'cold_distribution':distribution(cold,2000),'cache_distribution':distribution(cache,100),
          'all84_click_feedback_ms':distribution(feedback,100),'bulk_distribution':distribution(bulk,5000),
          'cancellation_distribution':distribution(cancellation,100),'renewal_totals':renewal,
          'all_annotation_groups_reconciled':len(annotations),'case_observer_samples':sum(row['samples'] for row in reports),
          'saved_document_clocks':clocks,'warm_new_jobs':warm_jobs,
          'both_mobile_retirement_phases_unavailable_each':20,
          'SQL_or_original_raw_store_access':False,'verdict':'PASS'}
path = OUT/'independent-numeric-check.json';assert not path.exists()
path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result))
