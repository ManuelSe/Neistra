"""Prepare a closed C4 analysis adapter without changing measured inputs."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).resolve().parent
ORIGINAL = ROOT/'docs/assets/ligand-properties/c3-native12-analysis.py.txt'
source = ORIGINAL.read_text()
tree = ast.parse(source)
helpers = ('path_checked','fingerprint','sha','load','jsonl','dist','strict_zero','renewal_traffic','retirement_scope')
nodes = {node.name:node for node in tree.body if isinstance(node,ast.FunctionDef)}
helper_text = '\n\n'.join(ast.get_source_segment(source,nodes[name]) for name in helpers)
numeric = source[source.index('    inputs = INPUTS\n'):source.index("    resource_file=BASE/'owned-resource-samples.jsonl'")]
combined = source[source.index("    combined={'all40_cold_actual_edits_ms'"):source.index("    baseline_runtime=load(BASELINE/'actual-receipt.json')")]
prefix = '''"""Analyze closed C4 ALL8 inputs; no application, SQL, process or network execution.

Nine accepted helper bodies and the numerical/work/per-case resource core are
reused byte for byte from the retained native12 analyzer. C4 full-gate metadata,
terminal/source/mirror barriers and explicit resource availability are separate.
"""
from pathlib import Path
import argparse
import collections
import datetime
import hashlib
import json
import math
import os
import stat
import statistics
import zipfile

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).resolve().parent
WORKSPACE = Path('/tmp/neistra159-c5-candidate4')
HISTORICAL_ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
BASE = ROOT/'.issue-11-evidence/issue159-c5-candidate4-transport1'
CAPTURE = ROOT/'.issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-source-capture1'
RETAINED = ROOT/'.issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-retained-state1'
NATIVE12 = ROOT/'.issue-11-evidence/issue159-native12-preparation1'
NATIVE12_ANALYSIS = ROOT/'.issue-11-evidence/issue159-native12-closed-analysis-preparation1'
OBSERVER_PARENT = ROOT/'.issue-11-evidence/issue159-performance'
HEAD = 'b1cdb138c7becb5afa73b8f9bbf1e6d958ae8582'
SOURCE = '776cd8d21daf6dfd605b741bbab825423f1568deb1f20d624b45a8de646f5eec'
INPUTS = {}
EXPECTED_SOURCES = EXPECTED_METHODS = EXPECTED_OBSERVER = None
'''
barriers = '''
def configure(args):
    global EXPECTED_SOURCES, EXPECTED_METHODS, EXPECTED_OBSERVER
    assert args.terminal_proof == BASE/'primary-terminal-readback.json'
    assert args.terminal_proof_sha256 == '6f22101b7f76027217844c9f3076663ac027a3bc97ca1bb23eecfa79bf5be0d9'
    assert sha(args.terminal_proof) == args.terminal_proof_sha256
    proof = load(args.terminal_proof)
    assert proof['candidate'] == HEAD and proof['gate_complete'] is True
    strict_zero(proof['actual_runner_wait_exit'])
    assert proof['original_transport_identity_complete'] and proof['recorded_steps'] == 43
    assert proof['SQL_opened'] is False and proof['raw_existing_DB_WAL_SHM_originals_and_copies_exact']
    bindings = load(OUT/'closed-input-bindings.json')
    for name, expected in bindings['files'].items():
        assert fingerprint(Path(name)) == expected
    pins = load(BASE/'pins.json'); status = load(BASE/'transport-status.json')
    assert pins['head'] == HEAD and pins['label'] == 'c5-candidate4'
    assert status['state'] == 'TERMINAL' and status['terminal'] and status['identity_complete']
    strict_zero(status['actual_runner_returncode'])
    EXPECTED_SOURCES = pins['selected_sources']
    assert len(EXPECTED_SOURCES) == 1133
    assert hashlib.sha256(json.dumps(EXPECTED_SOURCES,sort_keys=True,separators=(',',':')).encode()).hexdigest() == SOURCE
    gate = load(ROOT/'docs/assets/ligand-properties/c5-candidate4-gate.json')
    summary = load(ROOT/'docs/assets/ligand-properties/c5-candidate4-summary.json')
    assert gate['complete'] and len(gate['steps']) == summary['complete_steps'] == 43
    assert all(type(step['exit_code']) is int and step['exit_code'] == 0 for step in gate['steps'])
    assert gate['commit'] == summary['commit'] == HEAD
    assert gate['source_before'] == gate['source_after'] == EXPECTED_SOURCES
    assert gate['preceding_source_before'] == gate['preceding_source_after'] == gate['preceding_source_expected'] == pins['preceding_sources']
    assert summary['complete_browser_inventory_executed'] and summary['existing_exclusion_identities_unchanged']
    assert summary['browser_passed'] == 565 and summary['browser_exclusions'] == 75
    assert summary['new_exclusions'] == summary['failures_flakes_retries'] == summary['python_skips'] == 0
    cleanup = load(BASE/'cleanup-before-raw-copy.json'); raw = load(BASE/'raw-database-copy.json')
    assert sha(BASE/'cleanup-before-raw-copy.json') == proof['positive_cleanup_receipt']['sha256']
    assert sha(BASE/'raw-database-copy.json') == proof['raw_copy_receipt']['sha256']
    assert cleanup['complete'] and not cleanup['positively_owned_processes_remaining'] and not cleanup['live_exact_workspace_data_markers']
    assert all(cleanup['ports_unused'].values()) and not cleanup['SQL_opened'] and not raw['SQL_opened']
    assert raw['cleanup_monotonic_ns'] == cleanup['monotonic_ns'] < raw['started_monotonic_ns']
    assert raw['files'] and raw['originals_retained']
    source_bindings = load(CAPTURE/'source-bindings.json')
    EXPECTED_METHODS = source_bindings['qualified_method_map']
    assert len(EXPECTED_METHODS) == source_bindings['qualified_method_count'] == 52
    assert EXPECTED_METHODS == load(NATIVE12/'expected-methods.json')
    assert all(EXPECTED_SOURCES[name] == digest for name,digest in EXPECTED_METHODS.items())
    previous_sources = load(NATIVE12/'expected-sources.json')
    assert set(previous_sources) == set(EXPECTED_SOURCES)
    delta = source_bindings['source_model']['declared_delta']
    assert set(delta) == {'tests/e2e/rebranding-zoom.spec.ts','tests/unit/test_ligand_properties_release_recipe.py'}
    assert {name for name in EXPECTED_SOURCES if EXPECTED_SOURCES[name] != previous_sources[name]} == set(delta)
    assert all(previous_sources[name] == item['before'] and EXPECTED_SOURCES[name] == item['after'] for name,item in delta.items())
    EXPECTED_OBSERVER = load(ROOT/'.issue-11-evidence/issue159-native12-primary-launch1/expected-observer-source-map.json')
    assert len(EXPECTED_OBSERVER) == 789 and all(EXPECTED_SOURCES[name] == digest for name,digest in EXPECTED_OBSERVER.items())
    capsule_manifest = load(CAPTURE/'source-capsule-manifest.json')
    assert capsule_manifest['candidate'] == HEAD
    maps = load(CAPTURE/'captured-source-maps.json')
    assert maps['current'] == EXPECTED_SOURCES and maps['actual036'] == pins['preceding_sources']
    for filename,key in [('captured-current-sources.zip','current'),('captured-actual036-sources.zip','actual036')]:
        assert fingerprint(CAPTURE/filename) == capsule_manifest['files'][filename]
        with zipfile.ZipFile(CAPTURE/filename) as archive:
            assert archive.testzip() is None
            assert len(archive.namelist()) == len(set(archive.namelist())) == len(maps[key])
            assert set(archive.namelist()) == set(maps[key])
            assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name,digest in maps[key].items())
    return proof, summary, raw, source_bindings

def completed_cases(browser):
    values = []
    total = []
    def walk(node, inherited_file=''):
        filename = node.get('file',inherited_file)
        for spec in node.get('specs',[]):
            actual_file = spec.get('file',filename)
            for test in spec['tests']:
                total.append((actual_file,test['projectName'],spec['title']))
                if Path(actual_file).name != 'ligand-properties-performance.spec.ts':
                    continue
                assert test['status'] == 'expected' and len(test['results']) == 1
                result = test['results'][0]; assert result['status'] == 'passed';strict_zero(result['retry'])
                assert not result.get('errors')
                values.append((test['projectName'],spec['title']))
        for child in node.get('suites',[]):walk(child,filename)
    walk(browser)
    assert len(total) == len(set(total)) == 640
    assert len(values) == len(set(values)) == 8
    assert all(sum(profile == wanted for profile,title in values) == 4 for wanted in ['chromium','mobile-chromium'])
    assert sum('1000-entry' in title for profile,title in values) == 4
    assert not browser.get('errors')
    return sorted(values)

def observer_inputs():
    observation = load(BASE/'primary-all8-property-cases-observation.json')
    assert observation['candidate'] == HEAD and observation['distinct_original_UUID_roots'] == 8
    inventories = load(RETAINED/'input-inventory.json')
    assert inventories == load(RETAINED/'originals-after.json')
    trace_path = WORKSPACE/'e2e/qualification/worker-turns.jsonl'
    trace_fp = fingerprint(trace_path);assert trace_fp['bytes'] <= 128*1024*1024
    count = maximum_turn = 0; header = None
    for row in jsonl(trace_path):
        count += 1;assert row['record'] == count
        if count == 1:header = row;assert row['event'] == 'header' and row['format_version'] == 1
        if row['turn'] is not None:maximum_turn = max(maximum_turn,row['turn'])
    assert count <= 200000 and maximum_turn <= 100000 and header
    actual_sources = load(trace_path.parent/header['sources'])
    assert actual_sources == EXPECTED_OBSERVER and len(actual_sources) == header['source_count']
    assert hashlib.sha256(json.dumps(actual_sources,sort_keys=True,separators=(',',':')).encode()).hexdigest() == header['source_digest']
    directories = []; roots_summary = {}; mirrors = []
    for item in observation['completed_observer_reports']:
        case = Path(item['original_observer_root']);assert case.parent == OBSERVER_PARENT and case.is_dir() and not case.is_symlink()
        directories.append(case)
        rows = {Path(value['original_path']):value for name,value in inventories['files'].items() if Path(value['original_path']).is_relative_to(case)}
        current = {path for path in case.rglob('*') if path.is_file()}
        assert current == set(rows)
        for path,value in rows.items():
            assert not path.name.endswith(('.db','.db-wal','.db-shm','.sqlite','.sqlite-wal','.sqlite-shm','.sqlite3','.sqlite3-wal','.sqlite3-shm'))
            assert fingerprint(path) == {key:value[key] for key in ['bytes','sha256']}
        attachment = Path(item['attachment'])
        assert fingerprint(attachment) == {key:item[key] for key in ['bytes','sha256']}
        assert fingerprint(attachment) == fingerprint(case/'worker-observation.json')
        observer = load(case/'worker-observation.json');work = observer['work_order']
        assert observer['complete'] and observer['sources_before'] == observer['sources_after'] == EXPECTED_OBSERVER and observer['sources_unchanged']
        assert work['complete'] and Path(work['trace']) == trace_path
        mirror_path = Path(work['observed_records']);assert mirror_path == case/'work-order-observed.jsonl'
        raw = mirror_path.read_bytes(); assert fingerprint(mirror_path) == {'bytes':work['observed_bytes'],'sha256':work['observed_sha256']}
        lines = raw.splitlines(keepends=True);assert json.loads(lines[0]) == header
        records = [json.loads(line) for line in lines[1:]]
        assert len(records) == work['records'] == work['last_record']-work['start_record']
        assert [row['record'] for row in records] == list(range(work['start_record']+1,work['last_record']+1))
        with trace_path.open('rb') as stream:
            stream.seek(work['source_start_offset']); assert stream.read(sum(map(len,lines[1:]))) == b''.join(lines[1:])
        roots_summary[str(case)] = {'regular_files':len(rows),'bytes':sum(row['bytes'] for row in rows.values())}
        mirrors.append({'case':str(case),'records':work['records'],'source_start_offset':work['source_start_offset'],'header_and_exact_global_trace_window':True,'sha256':work['observed_sha256']})
    assert len(directories) == len(set(directories)) == 8
    assert sum(row['regular_files'] for row in roots_summary.values()) == 480
    return directories, {'worker_trace':{**trace_fp,'records':count,'maximum_turn':maximum_turn,'source_count':len(actual_sources)},'original_observer_roots':roots_summary,'mirrors':mirrors}

def page_clock_checks(edits):
    clocks = 0
    for profile,entry in edits.items():
        data = load(ROOT/entry['path'])
        for item in data['pageClocks']:
            clock = item['clock'];before = clock['installed'];after = clock['observed']
            assert before['timeOrigin'] == after['timeOrigin']
            for sample in [before,after]:
                assert all(type(sample[key]) in [int,float] and math.isfinite(sample[key]) for key in ['timeOrigin','dateBeforeMs','performanceNowMs','dateAfterMs'])
                assert sample['dateBeforeMs'] <= sample['dateAfterMs'] and sample['performanceNowMs'] >= 0
            clocks += 1
        pairs = [row for row in data['records'] if row['kind'] == 'paired-edit']
        for row in pairs:
            origin = row['cold']['timeOrigin'];assert origin == row['warm']['timeOrigin'] == row['automaticReady']['timeOrigin'] == row['warmAutomaticReady']['timeOrigin']
            for phase in ['cold','warm']:
                assert row[phase]['clock']['installed']['timeOrigin'] == row[phase]['clock']['observed']['timeOrigin'] == origin
    assert clocks == 50
    return {'saved_per_document_calibrations':clocks,'same_document_origins_checked':True,'cross_document_origin_equality_inferred':False}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-proof',required=True,type=Path)
    parser.add_argument('--terminal-proof-sha256',required=True)
    args = parser.parse_args()
    for name in ['assessment.json','comparison-samples.json','input-identities.json']:
        assert not (OUT/name).exists(), 'Preserve an existing analysis result'
    proof,gate_summary,raw_proof,source_bindings = configure(args)
    browser = load(ROOT/'docs/assets/ligand-properties/c5-candidate4-browser.json')
    results = completed_cases(browser)
    directories,observer_integrity = observer_inputs()
    root = {'completed_case_metrics':[]}
    for case in directories:
        paths = list(case.glob('native-*-performance.json'));assert len(paths) == 1
        root['completed_case_metrics'].append({'path':str(paths[0])})
    runtime = {'source_before':EXPECTED_SOURCES}
'''
suffix = '''
    resource = {'wrapper_CPU_RSS_load_samples':None,'wrapper_sampling_status':'Unavailable in this C4 full-gate transport; native12 wrapper sampling is historical and is not borrowed.',
        'case_observer_samples_total':sum(row['samples'] for row in observers),
        'case_observer_samples_by_case':{row['case']:row['samples'] for row in observers},
        'case_observer_peak_child_RSS_bytes_max':max(row['peak_child_rss_bytes'] for row in observers),
        'case_observer_peak_worker_parent_RSS_bytes_max':max(row['peak_worker_parent_rss_bytes'] for row in observers),
        'scope':'Actual case observers sample the worker and property children. Peaks are discrete samples and are not simultaneous process totals or every-instant ceilings. Whole-browser/GPU/short-lived process accounting, wrapper CPU and host load are unavailable. Missing observations are not zero.'}
    baseline = load(NATIVE12_ANALYSIS/'assessment.json')
    assert baseline['candidate'] == '7da9913bcf4630f1f4ffbfa2af3eeffc7ff9705c' and baseline['workflow_passes'] == 8
    assert baseline['method_count'] == 52 and baseline['source_count'] == 1133
    baseline_inputs = load(NATIVE12_ANALYSIS/'input-identities.json')
    baseline_runtime = load(NATIVE12/'actual-receipt.json')
    assert baseline_runtime['source_before'] == baseline_runtime['source_after'] == load(NATIVE12/'expected-sources.json')
    assert baseline_runtime['methods_before'] == baseline_runtime['methods_after'] == EXPECTED_METHODS
    baseline_pairs = {};baseline_bulk = {}
    for name in baseline_runtime['new_harness_directories']:
        case = Path(name);assert case.parent == OBSERVER_PARENT
        paths = list(case.glob('native-*-performance.json'));assert len(paths) == 1
        path = paths[0]; key = str(path.relative_to(ROOT))
        assert fingerprint(path) == baseline_inputs[key]
        data = load(path)
        if 'records' in data:
            baseline_pairs[data['profile']] = [(row['index'],row['heavyAtoms'],row['firstInputHash'],row['changedInputHash']) for row in data['records'] if row['kind'] == 'paired-edit']
        elif 'kind' in data:baseline_bulk[(data['profile'],data['kind'])] = data['changedInputHash']
    assert baseline_pairs == exact_inputs and all(row['changed_input_hash'] == baseline_bulk[(row['profile'],row['kind'])] for row in bulks)
    timing_misses = {name:dict(value) for name,value in alltargets.items() if value['misses']}
    comparison = {'baseline_candidate':baseline['candidate'],'baseline_source_digest_compact':baseline['source_digest_compact'],
        'baseline_method_count':52,'baseline_combined':baseline['combined'],
        'all40_initial_changed_scientific_hash_pairs_and4bulk_changed_hashes_equal':True,
        'exact_two_test_only_source_deltas':source_bindings['source_model']['declared_delta'],
        'all52_method_and789_observer_bodies_unchanged':True,
        'baseline_wrapper_resources_are_historical_only':True,
        'limits':'Separate complete runs on a shared host, without controlled A/B or matched load conditions. Descriptive context only; no causal speedup/regression, strict-host certification or generalization to every host.'}
    summary = {'scope':'Closed C4 ALL8 numerical/work/resource analysis only; final same-candidate feature and release approval remain separate.',
        'candidate':HEAD,'workflow_cases':results,'workflow_passes':8,'skips_failures_flakes_retries':0,
        'source_count':len(EXPECTED_SOURCES),'method_count':len(EXPECTED_METHODS),'observer_source_count':len(EXPECTED_OBSERVER),
        'source_digest_compact':SOURCE,'method_digest_spaced':hashlib.sha256(json.dumps(EXPECTED_METHODS,sort_keys=True).encode()).hexdigest(),
        'actual_terminal_collector_proof':{'path':str(args.terminal_proof),'sha256':args.terminal_proof_sha256},
        'complete_gate_summary':gate_summary,'source_capsule_bodies_and_exact_unions_checked':True,
        'cleanup_and_raw_metadata':{'actual_primary_raw_copy_pairs':len(raw_proof['files']),'primary_preSQL_raw_copy_proof_verified':True,'raw_original_stores_opened_by_this_analyzer':False,'raw_store_bytes_independently_rehashed_by_this_analyzer':False},
        'observer_integrity':observer_integrity,'combined':combined,'profiles':edits,'cancellations':cancellations,'bulk_cases':bulks,
        'all_timing_annotation_groups':alltargets,'timing_groups_with_target_misses':timing_misses,'closed_observers':observers,
        'saved_resources':resource,'page_clock_checks':page_clock_checks(edits),'descriptive_native12_comparison':comparison,
        'recorded_environment':{'performance_profile':'portable correctness','NEISTRA_PERFORMANCE':'0','host_hardware_and_load_during_C4':'Unavailable in this gate transport; no matched controlled-host claim.', 'recipe':str(ROOT/'docs/assets/ligand-properties/c5-candidate4-recipe.json')},
        'renewal_totals':{'calls':sum(row['renewal_traffic']['heartbeat_calls'] for row in bulks),'full_UTF8_response_body_bytes':sum(row['renewal_traffic']['heartbeat_full_response_body_UTF8_bytes_total'] for row in bulks),'all_consumer_updates':sum(row['consumer_update_calls'] for row in bulks)},
        'policy':'D148 retains100ms feedback/cache,2000ms cold and5000ms bulk targets/misses. Portable work/resource/scientific/cancellation/deadline bounds remain mandatory; absolute latency enforcement is additional opt-in controlled reference-host qualification.',
        'no_SQL_apps_services_process_network_or_chemistry_execution':True,'final_feature_release_qualification':False}
    for name,expected in list(INPUTS.items()):
        actual = Path(name) if Path(name).is_absolute() else ROOT/name
        assert fingerprint(actual,register=False) == expected, f'Closed input drift: {actual}'
    for name,value in {'assessment.json':summary,'comparison-samples.json':{'cold_samples':cold_compares},'input-identities.json':dict(sorted(INPUTS.items()))}.items():
        with (OUT/name).open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\\n')
    print(json.dumps({'scope':summary['scope'],'candidate':HEAD,'workflow_passes':8,'input_files':len(INPUTS),'combined':combined,'renewal_totals':summary['renewal_totals'],'resource_samples':resource['case_observer_samples_total']}))

if __name__ == '__main__':main()
'''
generated = prefix + '\n\n' + helper_text + '\n\n' + barriers + numeric + combined + suffix
ast.parse(generated)
path = OUT/'analyze.py';assert not path.exists();path.write_text(generated)
generated_nodes = {node.name:node for node in ast.parse(generated).body if isinstance(node,ast.FunctionDef)}
proof = {'scope':'Static C4 analysis binding adaptation; no actual analysis result implied.',
         'original_analyzer':str(ORIGINAL),'original_analyzer_sha256':hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(),
         'analyzer_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
         'nine_helpers_AST_exact':all(ast.dump(nodes[name]) == ast.dump(generated_nodes[name]) for name in helpers),
         'numerical_work_per_case_resource_core_byte_exact':numeric in generated,
         'combined_distribution_core_byte_exact':combined in generated,
         'adapted_sections':['Actual C4 full43 terminal/source/observer metadata barriers','Full640 report extraction of exact8 single-attempt property cases','Actual complete observer-root and global trace-window verification','Unavailable C4 wrapper CPU/RSS/load scope; actual per-case samples retained','Descriptive original-native12 comparison with exactlytwo unrelated test-only source deltas'],
         'runtime_or_original_changes':False}
assert proof['nine_helpers_AST_exact'] and proof['numerical_work_per_case_resource_core_byte_exact'] and proof['combined_distribution_core_byte_exact']
(OUT/'adaptation-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
paths = [BASE for BASE in []]
relative_paths = [
 '.issue-11-evidence/issue159-c5-candidate4-transport1/primary-terminal-readback.json',
 '.issue-11-evidence/issue159-c5-candidate4-transport1/pins.json',
 '.issue-11-evidence/issue159-c5-candidate4-transport1/transport-status.json',
 '.issue-11-evidence/issue159-c5-candidate4-transport1/primary-all8-property-cases-observation.json',
 '.issue-11-evidence/issue159-c5-candidate4-transport1/cleanup-before-raw-copy.json',
 '.issue-11-evidence/issue159-c5-candidate4-transport1/raw-database-copy.json',
 'docs/assets/ligand-properties/c5-candidate4-recipe.json',
 'docs/assets/ligand-properties/c5-candidate4-gate.json',
 'docs/assets/ligand-properties/c5-candidate4-summary.json',
 'docs/assets/ligand-properties/c5-candidate4-browser.json',
 '.issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-source-capture1/source-capsule-manifest.json',
 '.issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-source-capture1/source-bindings.json',
 '.issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-source-capture1/captured-source-maps.json',
 '.issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-retained-state1/input-inventory.json',
 '.issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-retained-state1/originals-after.json',
 '.issue-11-evidence/issue159-native12-preparation1/expected-sources.json',
 '.issue-11-evidence/issue159-native12-preparation1/expected-methods.json',
 '.issue-11-evidence/issue159-native12-primary-launch1/expected-observer-source-map.json',
 '.issue-11-evidence/issue159-native12-closed-analysis-preparation1/assessment.json',
 '.issue-11-evidence/issue159-native12-closed-analysis-preparation1/input-identities.json',
 '.issue-11-evidence/issue159-native12-preparation1/actual-receipt.json',
 'docs/assets/ligand-properties/c3-native12-analysis.py.txt',
]
bindings = {}
for relative in relative_paths:
 p = ROOT/relative;body = p.read_bytes();bindings[str(p)] = {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
(OUT/'closed-input-bindings.json').write_text(json.dumps({'scope':'Closed metadata inputs; original metrics are separately bound to complete retained observer inventory at execution.','files':bindings},indent=2)+'\n')
print(json.dumps(proof))
