"""Analyze closed C4 ALL8 inputs; no application, SQL, process or network execution.

Nine accepted helper bodies and the numerical/work/per-case resource core are
reused byte for byte from the retained native12 analyzer. C4 full-gate metadata,
terminal/source/mirror barriers and explicit resource availability are separate.
"""
from pathlib import Path
import argparse
import collections
import gzip
import datetime
import hashlib
import json
import math
import os
import stat
import statistics
import zipfile

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).resolve().parent
WORKSPACE = Path('/tmp/neistra159-c5-candidate4')
HISTORICAL_ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
BASE = ROOT/'.issue-11-evidence/issue159-c5-candidate4-transport1'
CAPTURE = ROOT/'.issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-source-capture1'
RETAINED = ROOT/'.issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-retained-state1'
NATIVE12 = ROOT/'.issue-11-evidence/issue159-native12-preparation1'
NATIVE12_ANALYSIS = ROOT/'.issue-11-evidence/issue159-native12-closed-analysis-preparation1'
OBSERVER_PARENT = ROOT/'.issue-11-evidence/issue159-performance'
HEAD = 'b1cdb138c7becb5afa73b8f9bbf1e6d958ae8582'
SOURCE = '776cd8d21daf6dfd605b741bbab825423f1568deb1f20d624b45a8de646f5eec'
INPUTS = {}
EXPECTED_SOURCES = EXPECTED_METHODS = EXPECTED_OBSERVER = None


def path_checked(path):
    path = Path(path)
    if not path.is_absolute(): path = ROOT/path
    assert path.is_file() and not path.is_symlink() and path.resolve() == path, path
    assert any(path.is_relative_to(root) for root in (ROOT,WORKSPACE,HISTORICAL_ROOT)), path
    return path

def fingerprint(path, *, register=True):
    path = path_checked(path)
    before = path.stat(); digest = hashlib.sha256(); size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block); size += len(block)
    after = path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns) == (
        after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns), path
    value = {'bytes':size,'sha256':digest.hexdigest()}
    if register:
        key = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
        assert key not in INPUTS or INPUTS[key] == value, f'Closed input changed: {path}'
        INPUTS[key] = value
    return value

def sha(path): return fingerprint(path)['sha256']

def load(path):
    path = path_checked(path)
    expected = fingerprint(path)
    body = path.read_bytes()
    assert len(body) == expected['bytes'] and hashlib.sha256(body).hexdigest() == expected['sha256']
    return json.loads(body)

def jsonl(path):
    path = path_checked(path); fingerprint(path)
    with path.open('rb') as stream:
        for line in stream:
            assert line.endswith(b'\n'), f'Incomplete closed JSONL: {path}'
            value = json.loads(line); assert isinstance(value,dict)
            yield value

def dist(values, limit=None):
    # Same median/nearest-rank p95 and target-miss semantics as closed baseline.
    values = sorted(values)
    assert values and all(type(v) in (int,float) and math.isfinite(v) and v >= 0 for v in values)
    result = {'n':len(values),'median':statistics.median(values),
              'p95_nearest_rank':values[math.ceil(.95*len(values))-1],
              'min':values[0],'max':values[-1]}
    if limit is not None: result.update(limit=limit,misses=sum(v>limit for v in values))
    return result

def strict_zero(value): assert type(value) is int and value == 0

def renewal_traffic(data):
    owners = {row['id']:row for row in data['owners']}
    updates = data['consumerUpdates']; groups = collections.defaultdict(list)
    for row in updates:
        assert row['owner'] in owners and row['status'] == 200
        assert row['kind'] in {'allocate','demand','same-sequence-heartbeat'}
        groups[row['kind']].append(row)
    assert len(owners) == 5 and len(groups['allocate']) == len(groups['demand']) == 5
    assert {row['owner'] for row in groups['allocate']} == {row['owner'] for row in groups['demand']} == set(owners)
    assert all(row['sequence'] == 0 and row['entries'] == 0 for row in groups['allocate'])
    assert all(row['sequence'] == 1 and row['entries'] == 200 for row in groups['demand'])
    heartbeat = groups['same-sequence-heartbeat']
    assert len(heartbeat) <= 5*math.ceil(1_200_000/20_000)
    by_owner = collections.defaultdict(list); body_sizes = []
    previous_response = None
    latest = {row['owner']:row['at']+row['elapsedMs'] for row in groups['demand']}
    for row in heartbeat:
        assert row['sequence'] == 1 and row['entries'] == 200
        assert row['responseAt'] >= row['at'] and row['elapsedMs'] == row['responseAt']-row['at']
        assert row['at']-latest[row['owner']] >= 20_000
        if previous_response is not None: assert row['at'] >= previous_response
        previous_response = row['responseAt']; latest[row['owner']] = row['responseAt']
        assert isinstance(row['responseBody'],str)
        decoded = json.loads(row['responseBody'])
        assert row['expiresAt'] == decoded['expires_at']
        datetime.datetime.fromisoformat(row['expiresAt'].replace('Z','+00:00'))
        body_sizes.append(len(row['responseBody'].encode('utf-8')))
        by_owner[row['owner']].append(row)
    assert all(len(rows) <= math.ceil(1_200_000/20_000) for rows in by_owner.values())
    return {'all_consumer_updates':len(updates),'kinds':dict(collections.Counter(row['kind'] for row in updates)),
            'heartbeat_calls':len(heartbeat),'cadence_derived_per_case_count_cap':300,
            'heartbeat_count_per_owner':{owner:len(by_owner[owner]) for owner in owners},
            'heartbeat_header_response_ms':dist([row['elapsedMs'] for row in heartbeat]) if heartbeat else None,
            'heartbeat_full_response_body_UTF8_bytes':dist(body_sizes) if body_sizes else None,'heartbeat_full_response_body_UTF8_bytes_total':sum(body_sizes),
            'heartbeat_requests_overlap_in_recorded_header_intervals':False,'same_sequence_payload_entries':200,
            'scope':'Independent serial20s maintenance traffic is included in actual workload. Full response strings are preserved; responseAt is before text/JSON consumption, so body-read/parse latency is not separately timestamped. Count cap is derived from the unchanged20min case deadline and20s cadence, not a new performance target.'}

def retirement_scope(pairs):
    result = {}
    for phase in ('cold','warm'):
        timings = [pair[phase] for pair in pairs]
        observed = [row['retirementMs'] for row in timings if type(row.get('retirementMs')) in (int,float)]
        result[phase] = {'observations':len(timings),
            'retirement_observation_kinds':dict(collections.Counter(row.get('retirementObservation','unrecorded') for row in timings)),
            'retirement_qualification_kinds':dict(collections.Counter(row.get('retirementQualification','unrecorded') for row in timings)),
            'measured_retirement_ms':dist(observed) if observed else None,
            'unavailable_retirement_latency':sum(row.get('retirementMs') is None for row in timings),
            'scope':'Only recorded observable retirement supplies latency. Hidden/unobserved old values remain unavailable, never inferred as zero or immediate retirement.'}
    return result

def walk(suite, output, parents=(), *, inventory=False):
    for spec in suite.get("specs", []):
        for test in spec["tests"]:
            result = None if inventory else test["results"][-1]
            title = " \u203a ".join((*parents, spec["title"]))
            output.append(
                {
                    "identity": (
                        f"[{test['projectName']}] \u203a tests/e2e/{spec['file']} \u203a {title}"
                    ),
                    "file": spec["file"],
                    "project": test["projectName"],
                    "title": title,
                    "status": None if result is None else result["status"],
                    "expected_status": test["expectedStatus"],
                    "retries": 0 if inventory else len(test["results"]) - 1,
                }
            )
    for child in suite.get("suites", []):
        walk(
            child,
            output,
            parents + ((suite["title"],) if suite.get("specs") else ()),
            inventory=inventory,
        )


def configure(args):
    global EXPECTED_SOURCES, EXPECTED_METHODS, EXPECTED_OBSERVER
    assert args.terminal_proof == BASE/'primary-terminal-readback.json'
    assert args.terminal_proof_sha256 == '6f22101b7f76027217844c9f3076663ac027a3bc97ca1bb23eecfa79bf5be0d9'
    assert sha(args.terminal_proof) == args.terminal_proof_sha256
    proof = load(args.terminal_proof)
    assert proof['candidate'] == HEAD and proof['gate_complete'] is True
    strict_zero(proof['actual_runner_wait_exit'])
    assert proof['original_transport_identity_complete'] and proof['recorded_steps'] == 43
    assert proof['SQL_opened'] is False and proof['raw_existing_DB_WAL_SHM_originals_and_copies_exact']
    bindings = load(OUT/'closed-input-bindings.json')
    for name, expected in bindings['files'].items():
        assert fingerprint(Path(name)) == expected
    pins = load(BASE/'pins.json'); status = load(BASE/'transport-status.json')
    assert pins['head'] == HEAD and pins['label'] == 'c5-candidate4'
    assert status['state'] == 'TERMINAL' and status['terminal'] and status['identity_complete']
    strict_zero(status['actual_runner_returncode'])
    EXPECTED_SOURCES = pins['selected_sources']
    assert len(EXPECTED_SOURCES) == 1133
    assert hashlib.sha256(json.dumps(EXPECTED_SOURCES,sort_keys=True,separators=(',',':')).encode()).hexdigest() == SOURCE
    gate = load(ROOT/'docs/assets/ligand-properties/c5-candidate4-gate.json')
    summary = load(ROOT/'docs/assets/ligand-properties/c5-candidate4-summary.json')
    assert gate['complete'] and len(gate['steps']) == summary['complete_steps'] == 43
    assert all(type(step['exit_code']) is int and step['exit_code'] == 0 for step in gate['steps'])
    assert gate['commit'] == summary['commit'] == HEAD
    assert gate['source_before'] == gate['source_after'] == EXPECTED_SOURCES
    assert gate['preceding_source_before'] == gate['preceding_source_after'] == gate['preceding_source_expected'] == pins['preceding_sources']
    assert summary['complete_browser_inventory_executed'] and summary['existing_exclusion_identities_unchanged']
    assert summary['browser_passed'] == 565 and summary['browser_exclusions'] == 75
    assert summary['new_exclusions'] == summary['failures_flakes_retries'] == summary['python_skips'] == 0
    cleanup = load(BASE/'cleanup-before-raw-copy.json'); raw = load(BASE/'raw-database-copy.json')
    assert sha(BASE/'cleanup-before-raw-copy.json') == proof['positive_cleanup_receipt']['sha256']
    assert sha(BASE/'raw-database-copy.json') == proof['raw_copy_receipt']['sha256']
    assert cleanup['complete'] and not cleanup['positively_owned_processes_remaining'] and not cleanup['live_exact_workspace_data_markers']
    assert all(cleanup['ports_unused'].values()) and not cleanup['SQL_opened'] and not raw['SQL_opened']
    assert raw['cleanup_monotonic_ns'] == cleanup['monotonic_ns'] < raw['started_monotonic_ns']
    assert raw['files'] and raw['originals_retained']
    source_bindings = load(CAPTURE/'source-bindings.json')
    EXPECTED_METHODS = source_bindings['qualified_method_map']
    assert len(EXPECTED_METHODS) == source_bindings['qualified_method_count'] == 52
    assert EXPECTED_METHODS == load(NATIVE12/'expected-methods.json')
    assert all(EXPECTED_SOURCES[name] == digest for name,digest in EXPECTED_METHODS.items())
    previous_sources = load(NATIVE12/'expected-sources.json')
    assert set(previous_sources) == set(EXPECTED_SOURCES)
    delta = source_bindings['source_model']['declared_delta']
    assert set(delta) == {'tests/e2e/rebranding-zoom.spec.ts','tests/unit/test_ligand_properties_release_recipe.py'}
    assert {name for name in EXPECTED_SOURCES if EXPECTED_SOURCES[name] != previous_sources[name]} == set(delta)
    assert all(previous_sources[name] == item['before'] and EXPECTED_SOURCES[name] == item['after'] for name,item in delta.items())
    EXPECTED_OBSERVER = load(ROOT/'.issue-11-evidence/issue159-native12-primary-launch1/expected-observer-source-map.json')
    assert len(EXPECTED_OBSERVER) == 789 and all(EXPECTED_SOURCES[name] == digest for name,digest in EXPECTED_OBSERVER.items())
    capsule_manifest = load(CAPTURE/'source-capsule-manifest.json')
    assert capsule_manifest['candidate'] == HEAD
    maps = load(CAPTURE/'captured-source-maps.json')
    assert maps['current'] == EXPECTED_SOURCES and maps['actual036'] == pins['preceding_sources']
    for filename,key in [('captured-current-sources.zip','current'),('captured-actual036-sources.zip','actual036')]:
        assert fingerprint(CAPTURE/filename) == capsule_manifest['files'][filename]
        with zipfile.ZipFile(CAPTURE/filename) as archive:
            assert archive.testzip() is None
            assert len(archive.namelist()) == len(set(archive.namelist())) == len(maps[key])
            assert set(archive.namelist()) == set(maps[key])
            assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name,digest in maps[key].items())
    return proof, summary, raw, source_bindings

def load_browser(path):
    path = path_checked(path);expected = fingerprint(path)
    compressed = path.read_bytes();assert len(compressed) == expected['bytes'] and hashlib.sha256(compressed).hexdigest() == expected['sha256']
    body = gzip.decompress(compressed)
    return json.loads(body), {'path':str(path),'compressed':expected,'uncompressed_bytes':len(body),'uncompressed_sha256':hashlib.sha256(body).hexdigest()}

def full_browser_qualification(browser,gate_summary):
    records = []
    for suite in browser['suites']:walk(suite,records)
    assert records == load(ROOT/'docs/assets/ligand-properties/c5-candidate4-browser-cases.json')
    inventory_path = ROOT/'docs/assets/ligand-properties/c5-candidate4-browser-inventory.json'
    inventory = load(inventory_path);assert not inventory.get('errors')
    listed = []
    for suite in inventory['suites']:walk(suite,listed,inventory=True)
    actual_ids = [row['identity'] for row in records];listed_ids = [row['identity'] for row in listed]
    assert len(actual_ids) == len(set(actual_ids)) == len(listed_ids) == len(set(listed_ids)) == 640
    assert set(actual_ids) == set(listed_ids)
    assert all(row['retries'] == 0 and row['status'] in ['passed','skipped'] for row in records)
    skipped = {row['identity'] for row in records if row['status'] == 'skipped'}
    assert len(skipped) == 75 and sum(row['status'] == 'passed' for row in records) == 565
    exclusions = load(ROOT/'docs/assets/ligand-properties/c5-candidate4-exclusions.json')
    assert set(exclusions['baseline']) == set(exclusions['existing_unchanged']) == skipped
    assert not exclusions['new_approved_desktop_only']
    baseline_path = ROOT/gate_summary['exclusion_baseline']
    assert sha(baseline_path) == gate_summary['exclusion_baseline_sha256']
    baseline,_ = load_browser(baseline_path);old_records=[]
    for suite in baseline['suites']:walk(suite,old_records)
    assert {row['identity'] for row in old_records if row['status'] == 'skipped'} == skipped
    assert sha(inventory_path) == gate_summary['browser_inventory_sha256']
    return {'cases':640,'passed':565,'exact_released_exclusions':75,'new_exclusions':0,'failures_flakes_retries':0,'inventory_and_actual_case_identities_exact':True,'released_exclusion_baseline':str(baseline_path),'exclusion_identities':sorted(skipped)}

def completed_cases(browser):
    values = []
    total = []
    def walk(node, inherited_file=''):
        filename = node.get('file',inherited_file)
        for spec in node.get('specs',[]):
            actual_file = spec.get('file',filename)
            for test in spec['tests']:
                total.append((actual_file,test['projectName'],spec['title']))
                if Path(actual_file).name != 'ligand-properties-performance.spec.ts':
                    continue
                assert test['status'] == 'expected' and len(test['results']) == 1
                result = test['results'][0]; assert result['status'] == 'passed';strict_zero(result['retry'])
                assert not result.get('errors')
                values.append((test['projectName'],spec['title']))
        for child in node.get('suites',[]):walk(child,filename)
    walk(browser)
    assert len(total) == len(set(total)) == 640
    assert len(values) == len(set(values)) == 8
    assert all(sum(profile == wanted for profile,title in values) == 4 for wanted in ['chromium','mobile-chromium'])
    assert sum('1000-entry' in title for profile,title in values) == 4
    assert not browser.get('errors')
    return sorted(values)

def observer_inputs():
    observation = load(BASE/'primary-all8-property-cases-observation.json')
    assert observation['candidate'] == HEAD and observation['distinct_original_UUID_roots'] == 8
    inventories = load(RETAINED/'input-inventory.json')
    assert inventories == load(RETAINED/'originals-after.json')
    trace_path = WORKSPACE/'e2e/qualification/worker-turns.jsonl'
    trace_fp = fingerprint(trace_path);assert trace_fp['bytes'] <= 128*1024*1024
    count = maximum_turn = 0; header = None
    for row in jsonl(trace_path):
        count += 1;assert row['record'] == count
        if count == 1:header = row;assert row['event'] == 'header' and row['format_version'] == 1
        if row['turn'] is not None:maximum_turn = max(maximum_turn,row['turn'])
    assert count <= 200000 and maximum_turn <= 100000 and header
    actual_sources = load(trace_path.parent/header['sources'])
    assert actual_sources == EXPECTED_OBSERVER and len(actual_sources) == header['source_count']
    assert hashlib.sha256(json.dumps(actual_sources,sort_keys=True,separators=(',',':')).encode()).hexdigest() == header['source_digest']
    directories = []; roots_summary = {}; mirrors = []
    for item in observation['completed_observer_reports']:
        case = Path(item['original_observer_root']);assert case.parent == OBSERVER_PARENT and case.is_dir() and not case.is_symlink()
        directories.append(case)
        rows = {Path(value['original_path']):value for name,value in inventories['files'].items() if Path(value['original_path']).is_relative_to(case)}
        current = {path for path in case.rglob('*') if path.is_file()}
        assert current == set(rows)
        for path,value in rows.items():
            assert not path.name.endswith(('.db','.db-wal','.db-shm','.sqlite','.sqlite-wal','.sqlite-shm','.sqlite3','.sqlite3-wal','.sqlite3-shm'))
            assert fingerprint(path) == {key:value[key] for key in ['bytes','sha256']}
        attachment = Path(item['attachment'])
        assert fingerprint(attachment) == {key:item[key] for key in ['bytes','sha256']}
        assert fingerprint(attachment) == fingerprint(case/'worker-observation.json')
        observer = load(case/'worker-observation.json');work = observer['work_order']
        assert observer['complete'] and observer['sources_before'] == observer['sources_after'] == EXPECTED_OBSERVER and observer['sources_unchanged']
        assert work['complete'] and Path(work['trace']) == trace_path
        mirror_path = Path(work['observed_records']);assert mirror_path == case/'work-order-observed.jsonl'
        raw = mirror_path.read_bytes(); assert fingerprint(mirror_path) == {'bytes':work['observed_bytes'],'sha256':work['observed_sha256']}
        lines = raw.splitlines(keepends=True);assert json.loads(lines[0]) == header
        records = [json.loads(line) for line in lines[1:]]
        assert len(records) == work['records'] == work['last_record']-work['start_record']
        assert [row['record'] for row in records] == list(range(work['start_record']+1,work['last_record']+1))
        with trace_path.open('rb') as stream:
            stream.seek(work['source_start_offset']); assert stream.read(sum(map(len,lines[1:]))) == b''.join(lines[1:])
        roots_summary[str(case)] = {'regular_files':len(rows),'bytes':sum(row['bytes'] for row in rows.values())}
        mirrors.append({'case':str(case),'records':work['records'],'source_start_offset':work['source_start_offset'],'header_and_exact_global_trace_window':True,'sha256':work['observed_sha256']})
    assert len(directories) == len(set(directories)) == 8
    assert sum(row['regular_files'] for row in roots_summary.values()) == 480
    return directories, {'worker_trace':{**trace_fp,'records':count,'maximum_turn':maximum_turn,'source_count':len(actual_sources)},'original_observer_roots':roots_summary,'mirrors':mirrors}

def page_clock_checks(edits):
    clocks = 0
    for profile,entry in edits.items():
        data = load(ROOT/entry['path'])
        for item in data['pageClocks']:
            clock = item['clock'];before = clock['installed'];after = clock['observed']
            assert before['timeOrigin'] == after['timeOrigin']
            for sample in [before,after]:
                assert all(type(sample[key]) in [int,float] and math.isfinite(sample[key]) for key in ['timeOrigin','dateBeforeMs','performanceNowMs','dateAfterMs'])
                assert sample['dateBeforeMs'] <= sample['dateAfterMs'] and sample['performanceNowMs'] >= 0
            clocks += 1
        pairs = [row for row in data['records'] if row['kind'] == 'paired-edit']
        for row in pairs:
            origin = row['cold']['timeOrigin'];assert origin == row['warm']['timeOrigin'] == row['automaticReady']['timeOrigin'] == row['warmAutomaticReady']['timeOrigin']
            for phase in ['cold','warm']:
                assert row[phase]['clock']['installed']['timeOrigin'] == row[phase]['clock']['observed']['timeOrigin'] == origin
    assert clocks == 50
    return {'saved_per_document_calibrations':clocks,'same_document_origins_checked':True,'cross_document_origin_equality_inferred':False}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-proof',required=True,type=Path)
    parser.add_argument('--terminal-proof-sha256',required=True)
    args = parser.parse_args()
    for name in ['assessment.json','comparison-samples.json','input-identities.json']:
        assert not (OUT/name).exists(), 'Preserve an existing analysis result'
    proof,gate_summary,raw_proof,source_bindings = configure(args)
    browser,browser_binding = load_browser(ROOT/'docs/assets/ligand-properties/c5-candidate4-browser.json.gz')
    results = completed_cases(browser)
    inventory_evidence = full_browser_qualification(browser,gate_summary)
    directories,observer_integrity = observer_inputs()
    root = {'completed_case_metrics':[]}
    for case in directories:
        paths = list(case.glob('native-*-performance.json'));assert len(paths) == 1
        root['completed_case_metrics'].append({'path':str(paths[0])})
    runtime = {'source_before':EXPECTED_SOURCES}
    inputs = INPUTS
    exact_inputs = {}
    edits={};cancellations=[];bulks=[];observers=[];targets=collections.defaultdict(list);allcold=[];allwarm=[];cold_compares=[]
    for item in root["completed_case_metrics"]:
     path=Path(item["path"]);assert path.is_relative_to(ROOT)
     case=path.parent;data=load(path);obs=load(case/"worker-observation.json");assert data.get("failures",[])==[]
     assert obs["complete"] and obs["sources_unchanged"] and obs["sources_before"]==obs["sources_after"]==EXPECTED_OBSERVER
     assert all(runtime["source_before"].get(n)==h for n,h in obs["sources_before"].items())
     assert obs["max_running_property_jobs"]<=1
     retained=obs["retained"];assert retained["content_bytes"]<=16*1024*1024 and retained["ligand_property_content"]<=2048 and retained["ligand_property_proofs"]<=4096 and retained["ligand_property_executions"]<=33
     for name in [path.name,"worker-observation.json","work-order-observed.jsonl","observer.stop","observer.log"]:
      f=case/name
      if f.is_file():inputs[str(f.relative_to(ROOT))]={"bytes":f.stat().st_size,"sha256":sha(f)}
     tracepath=case/"work-order-observed.jsonl"
     assert sha(tracepath)==obs["work_order"]["observed_sha256"] and obs["work_order"]["complete"]
     for target in data["targets"]:
      assert target["enforced"] is False and math.isfinite(target["actual"]) and target["actual"]>=0
      assert target["withinTarget"]==(target["actual"]<=target["limit"])
      targets[target["label"]].append(target)
     private=[j for j in obs["jobs"].values() if j.get("execution_id")];completed=[j for j in private if j["status"]=="completed"]
     maxima={"capture_verified_bytes":0,"capture_source_reads":0,"capture_byte_cap":0,"publication_verified_bytes":0,"publication_reads":0,"publication_byte_cap":0,"materialized_verified_bytes":0,"envelope_bytes":0,"batch_sources":0,"child_stage_capture_bytes":0}
     totals={"capture_verified_bytes":0,"capture_source_reads":0,"publication_verified_bytes":0,"publication_reads":0,"materialized_verified_bytes":0}
     for job in completed:
      p=job["provenance"];cap=p["source_capture"];pub=p["publication_verification"];material=p["input_materialization"]
      assert cap["coordinator_native_preparations"]==0 and 0<cap["source_proofs"]<=8 and cap["verified_bytes"]<=64*1024*1024 and cap["source_read_calls"]<=16 and cap["source_read_byte_cap"]<=64*1024*1024+16
      assert pub["verified_bytes"]<=64*1024*1024 and pub["source_reads"]<=16 and pub["read_byte_cap"]<=64*1024*1024+16
      assert material["verified_bytes"]<=64*1024*1024 and material["envelope_bytes"]<=96*1024*1024
      stages=job["result_values"]["stage_timings"];assert 0<len(stages)<=8
      assert all(stage["capture_bytes"]>0 and stage["capture_bytes"]<=96*1024*1024 for stage in stages)
      assert all(all(math.isfinite(stage[k]) and stage[k]>=0 for k in ("raw_proof_seconds","prepare_seconds","calculate_seconds")) for stage in stages)
      assert all(job["reaped"] for job in completed)
      vals={"capture_verified_bytes":cap["verified_bytes"],"capture_source_reads":cap["source_read_calls"],"capture_byte_cap":cap["source_read_byte_cap"],"publication_verified_bytes":pub["verified_bytes"],"publication_reads":pub["source_reads"],"publication_byte_cap":pub["read_byte_cap"],"materialized_verified_bytes":material["verified_bytes"],"envelope_bytes":material["envelope_bytes"],"batch_sources":cap["source_proofs"],"child_stage_capture_bytes":max(x["capture_bytes"] for x in stages)}
      for k,v in vals.items():maxima[k]=max(maxima[k],v)
      for k in totals:totals[k]+=vals[k]
     observer={"case":str(case.relative_to(ROOT)),"samples":obs["samples"],"observed_jobs":len(obs["jobs"]),"private_jobs_observed":len(private),"completed_private_jobs":len(completed),"private_statuses":dict(collections.Counter(j["status"] for j in private)),"completed_private_all_reaped":all(j["reaped"] for j in completed),"max_running_property_jobs":obs["max_running_property_jobs"],"retained_at_case_close":retained,"peak_child_rss_bytes":max(obs.get("peak_child_rss_bytes",{}).values(),default=0),"peak_worker_parent_rss_bytes":max(obs.get("peak_worker_parent_rss_bytes",{}).values(),default=0),"per_completed_private_job_maxima":maxima,"per_case_observed_job_totals":totals}
     observers.append(observer)
     if "edit-performance" in path.name:
      pairs=[r for r in data["records"] if r["kind"]=="paired-edit"];prefix=[r for r in data["records"] if r["kind"]=="fresh-browser-context-cold-start"]
      assert len(pairs)==20 and len(prefix)==5 and len(data["pageClocks"])==25
      assert all(r["matchingQualifiedResultReadyBeforeViewOpen"] and r["warmNewJobs"]==0 for r in pairs)
      profile=data["profile"]
      exact_inputs[profile]=[(r["index"],r["heavyAtoms"],r["firstInputHash"],r["changedInputHash"]) for r in pairs]
      entry={"path":str(path.relative_to(ROOT)),"cold_edit_ms":dist([r["cold"]["networkCurrentMs"] for r in pairs],2000),"cold_context_first_five_network_ms":dist([r["timing"]["networkCurrentMs"] for r in prefix],2000),"cold_context_first_five_visible_ms":data["coldStarts"],"warm_visible_including_command_and_view_open_ms":dist([r["warm"]["currentMs"] for r in pairs]),"warm_automatic_READY_ms":dist([r["warm"]["networkCurrentMs"] for r in pairs]),"matching_cache_projection_ms":dist([r["cachedProjectionMs"] for r in pairs],100),"cold_click_feedback_ms":dist([r["cold"]["feedbackMs"] for r in pairs],100),"warm_click_feedback_ms":dist([r["warm"]["feedbackMs"] for r in pairs],100),"warm_new_jobs":sum(r["warmNewJobs"] for r in pairs),"page_clock_count":len(data["pageClocks"])}
      if profile.startswith("mobile"):
       assert all(r["warm"]["presentationOpened"]>r["warmAutomaticReady"]["observedAt"] for r in pairs)
       entry["mobile_deliberate_presentation_open_after_READY_ms"]=dist([r["warm"]["presentationOpened"]-r["warmAutomaticReady"]["observedAt"] for r in pairs])
      entry["source_retirement_scope"]=retirement_scope(pairs)
      entry["page_clock_evidence"]=data["pageClocks"]
      entry["clock_scope"]="Actual saved per-document installed/observed calibrations; no cross-document monotonic-origin equality is inferred."
      edits[profile]=entry;allcold.extend(r["cold"]["networkCurrentMs"] for r in pairs);allwarm.extend(r["cachedProjectionMs"] for r in pairs)
      for pair in pairs:
       s=pair["changedSource"];req=[q for q in pair["requests"] if q.get("sources")==[s] and pair["cold"]["started"]<=q["at"]<=pair["automaticReady"]["requestAt"]]
       warmreq=[q for q in pair["requests"] if q.get("sources")==[pair["oldSource"]] and pair["warm"]["started"]<=q["at"]<=pair["warmAutomaticReady"]["requestAt"]]
       cold_compares.append({"warm_exact_source_READs":sum(q["method"]=="POST" and q["path"].endswith("/read") for q in warmreq),"warm_exact_source_demand_PUTs":sum(q["method"]=="PUT" for q in warmreq),"profile":profile,"index":pair["index"],"heavy_atoms":pair["heavyAtoms"],"cold_ms":pair["cold"]["networkCurrentMs"],"matching_cache_projection_ms":pair["cachedProjectionMs"],"cold_feedback_ms":pair["cold"]["feedbackMs"],"warm_feedback_ms":pair["warm"]["feedbackMs"],"exact_changed_source_READs":sum(q["method"]=="POST" and q["path"].endswith("/read") for q in req),"exact_changed_source_demand_PUTs":sum(q["method"]=="PUT" for q in req),"warm_new_jobs":pair["warmNewJobs"]})
     elif "cancellation" in path.name:
      assert sum(q["method"]=="PUT" for q in data["requests"])==1
      cancellations.append({"profile":data["profile"],"path":str(path.relative_to(ROOT)),"feedback_ms":data["cancellation"]["currentMs"],"recorded_pre_Retry_requests":len(data["requests"]),"recorded_pre_Retry_demand_PUTs":1,"source":data["source"],"scope":data["scope"],"functional_evidence":"Actual passing case asserts accepted late reply stays cancelled after reopen/quiet period and explicitRetry subsequently works; not worker-kill latency."})
     else:
      assert data["hardWorkOrderStatus"]=="passed" and data["readyCount"]==1000 and len(data["finalBindings"])==1000
      assert len(data["owners"])==5 and all(x["entries"]==200 for x in data["owners"])
      assert all(x["entries"]==200 and x["status"]==200 for x in data["aggregateReads"])
      assert data["qualifiedDistinctInputHashes"]==(1 if data["kind"]=="repeated" else 1000)
      hard=data["hardWorkOrder"];assert hard["ordinary"]["productiveDerivedTurnsBeforeClaim"]<=4 and len(hard["active"]["productiveBulkFairnessTurnsBeforeAdmission"])<=1
      assert hard["active"]["source"]==data["changedSource"] and hard["active"]["inputHash"]==data["changedInputHash"]
      if data["kind"]=="distinct":assert hard["active"]["priorityOverlapExercised"]
      assert hard["trace"]["sha256"]==sha(tracepath)
      trace=list(jsonl(tracepath));byid={r["record"]:r for r in trace}
      actor=hard["active"];bind=byid[actor["publicationRecord"]];mat=byid[actor["admissionRecord"]];seen=byid[actor["observedRecord"]]
      assert bind["event"]=="bind_return" and bind["input_hash"]==data["changedInputHash"]
      turnend=next(r for r in trace if r["event"]=="turn_end" and r["turn"]==bind["turn"]);assert turnend["worked"]
      s=data["changedSource"];current=[q for q in data["activeRequests"] if q.get("sources")==[s]];demand=next(q for q in current if q["method"]=="PUT");reads=[q for q in current if q["method"]=="POST" and q["path"].endswith("/read")];ready=reads[-1]
      assert ready["results"][0]["status"]=="ready" and ready["results"][0]["inputHash"]==data["changedInputHash"]
      ack=next(q for q in data["activeRequests"] if q["path"].endswith("/model-edits"));active=data["active"];origin=active["timeOrigin"]
      assert all(q["timeOrigin"]==origin for q in current)
      stage={"click_to_ACK_ms":ack["finished"]-active["started"],"ACK_to_first_current_READ_ms":reads[0]["at"]-ack["finished"],"first_current_READ_http_ms":reads[0]["finished"]-reads[0]["at"],"demand_http_ms":demand["finished"]-demand["at"],"demand_response_to_final_READY_READ_start_ms":ready["at"]-demand["finished"],"demand_response_to_successful_turn_end_ms":turnend["epoch_us"]/1000-origin-demand["finished"],"publication_to_READY_READ_start_lower_ms":origin+ready["at"]-turnend["epoch_us"]/1000,"publication_to_READY_READ_start_upper_ms":origin+ready["at"]-bind["epoch_us"]/1000,"active_owner_observed_to_materialize_return_ms":(mat["epoch_us"]-seen["epoch_us"])/1000}
      pending_gaps=[{"status":q["results"][0]["status"],"READ_start_after_demand_response_ms":q["at"]-demand["finished"],"http_ms":q["finished"]-q["at"]} for q in reads[1:]]
      bulks.append({"profile":data["profile"],"kind":data["kind"],"path":str(path.relative_to(ROOT)),"active_READY_ms":active["networkCurrentMs"],"target_ms":5000,"target_missed":active["networkCurrentMs"]>5000,"click_feedback_ms":active["feedbackMs"],"visible_including_presentation_ms":active["currentMs"],"hard_work_order_passed":True,"ordinary_productive_derived_turns_before_claim":hard["ordinary"]["productiveDerivedTurnsBeforeClaim"],"ordinary_warm_progress_turns":hard["ordinary"]["warmProgressTurnsBeforeClaim"],"productive_bulk_fairness_turns_before_active_admission":len(hard["active"]["productiveBulkFairnessTurnsBeforeAdmission"]),"post_acceptance_bulk_bindings":hard["active"]["actualPostAcceptanceBulkBindings"],"priority_overlap_exercised":hard["active"]["priorityOverlapExercised"],"ready_bulk_entries":1000,"distinct_qualified_input_hashes":data["qualifiedDistinctInputHashes"],"bulk_owner_count":5,"bulk_owner_entries":200,"aggregate_READ_calls":len(data["aggregateReads"]),"aggregate_READ_entry_operations":sum(q["entries"] for q in data["aggregateReads"]),"aggregate_READ_http_ms":dist([q["elapsedMs"] for q in data["aggregateReads"]]),"consumer_update_calls":len(data["consumerUpdates"]),"consumer_update_kinds":dict(collections.Counter(q["kind"] for q in data["consumerUpdates"])),"all_App_requests":len(data["allAppRequests"]),"App_changed_source_READs":len(reads),"App_changed_source_demand_PUTs":1,"post_demand_READ_sequence":pending_gaps,"observed_jobs":len(data["actualOrder"]),"observed_private_jobs":sum(bool(q["execution_id"]) for q in data["actualOrder"]),"private_job_count_limit":129,"private_jobs_all_reaped":all(q["reaped"] for q in data["actualOrder"] if q["execution_id"]),"phase_metrics_ms":stage,"retained_at_close":retained})
      assert sum(bool(q["execution_id"]) for q in data["actualOrder"])<=129
      assert all(q["reaped"] for q in data["actualOrder"] if q["execution_id"])
      bulks[-1]["renewal_traffic"]=renewal_traffic(data)
      bulks[-1]["changed_input_hash"]=data["changedInputHash"]

    assert set(edits)=={'chromium','mobile-chromium'}
    assert len(allcold)==len(allwarm)==40 and len(cancellations)==2 and len(bulks)==4
    assert {row['profile'] for row in cancellations}==set(edits)
    assert {(row['profile'],row['kind']) for row in bulks}=={
        (profile,kind) for profile in edits for kind in ('repeated','distinct')}
    job_children=set()
    for case in observers:
        saved=load(ROOT/case['case']/'worker-observation.json')
        job_children.update((job.get('child_pid'),str(job.get('child_start_token')))
            for job in saved['jobs'].values() if job.get('child_pid') and job.get('child_start_token'))
    combined={'all40_cold_actual_edits_ms':dist(allcold,2000),
        'all40_matching_cache_projection_ms':dist(allwarm,100),
        'cancellation_feedback_ms':dist([row['feedback_ms'] for row in cancellations],100),
        'four_bulk_active_ms':dist([row['active_READY_ms'] for row in bulks],5000),
        'four_bulk_click_feedback_ms':dist([row['click_feedback_ms'] for row in bulks],100)}
    alltargets={label:{**dist([item['actual'] for item in values],values[0]['limit']),'enforced':False}
                for label,values in targets.items()}

    resource = {'wrapper_CPU_RSS_load_samples':None,'wrapper_sampling_status':'Unavailable in this C4 full-gate transport; native12 wrapper sampling is historical and is not borrowed.',
        'case_observer_samples_total':sum(row['samples'] for row in observers),
        'case_observer_samples_by_case':{row['case']:row['samples'] for row in observers},
        'case_observer_peak_child_RSS_bytes_max':max(row['peak_child_rss_bytes'] for row in observers),
        'case_observer_peak_worker_parent_RSS_bytes_max':max(row['peak_worker_parent_rss_bytes'] for row in observers),
        'scope':'Actual case observers sample the worker and property children. Peaks are discrete samples and are not simultaneous process totals or every-instant ceilings. Whole-browser/GPU/short-lived process accounting, wrapper CPU and host load are unavailable. Missing observations are not zero.'}
    baseline = load(NATIVE12_ANALYSIS/'assessment.json')
    assert baseline['candidate'] == '7da9913bcf4630f1f4ffbfa2af3eeffc7ff9705c' and baseline['workflow_passes'] == 8
    assert baseline['method_count'] == 52 and baseline['source_count'] == 1133
    baseline_inputs = load(NATIVE12_ANALYSIS/'input-identities.json')
    baseline_runtime = load(NATIVE12/'actual-receipt.json')
    assert baseline_runtime['source_before'] == baseline_runtime['source_after'] == load(NATIVE12/'expected-sources.json')
    assert baseline_runtime['methods_before'] == baseline_runtime['methods_after'] == EXPECTED_METHODS
    baseline_pairs = {};baseline_bulk = {}
    for name in baseline_runtime['new_harness_directories']:
        case = Path(name);assert case.parent == OBSERVER_PARENT
        paths = list(case.glob('native-*-performance.json'));assert len(paths) == 1
        path = paths[0]; key = str(path.relative_to(ROOT))
        assert fingerprint(path) == baseline_inputs[key]
        data = load(path)
        if 'records' in data:
            baseline_pairs[data['profile']] = [(row['index'],row['heavyAtoms'],row['firstInputHash'],row['changedInputHash']) for row in data['records'] if row['kind'] == 'paired-edit']
        elif 'kind' in data:baseline_bulk[(data['profile'],data['kind'])] = data['changedInputHash']
    assert baseline_pairs == exact_inputs and all(row['changed_input_hash'] == baseline_bulk[(row['profile'],row['kind'])] for row in bulks)
    timing_misses = {name:dict(value) for name,value in alltargets.items() if value['misses']}
    comparison = {'baseline_candidate':baseline['candidate'],'baseline_source_digest_compact':baseline['source_digest_compact'],
        'baseline_method_count':52,'baseline_combined':baseline['combined'],
        'all40_initial_changed_scientific_hash_pairs_and4bulk_changed_hashes_equal':True,
        'exact_two_test_only_source_deltas':source_bindings['source_model']['declared_delta'],
        'all52_method_and789_observer_bodies_unchanged':True,
        'baseline_wrapper_resources_are_historical_only':True,
        'limits':'Separate complete runs on a shared host, without controlled A/B or matched load conditions. Descriptive context only; no causal speedup/regression, strict-host certification or generalization to every host.'}
    summary = {'scope':'Closed C4 ALL8 numerical/work/resource analysis only; final same-candidate feature and release approval remain separate.',
        'candidate':HEAD,'workflow_cases':results,'workflow_passes':8,'skips_failures_flakes_retries':0,
        'source_count':len(EXPECTED_SOURCES),'method_count':len(EXPECTED_METHODS),'observer_source_count':len(EXPECTED_OBSERVER),
        'source_digest_compact':SOURCE,'method_digest_spaced':hashlib.sha256(json.dumps(EXPECTED_METHODS,sort_keys=True).encode()).hexdigest(),
        'actual_terminal_collector_proof':{'path':str(args.terminal_proof),'sha256':args.terminal_proof_sha256},
        'complete_gate_summary':gate_summary,'browser_binding':browser_binding,'complete_browser_inventory_evidence':inventory_evidence,'source_capsule_bodies_and_exact_unions_checked':True,
        'cleanup_and_raw_metadata':{'actual_primary_raw_copy_pairs':len(raw_proof['files']),'primary_preSQL_raw_copy_proof_verified':True,'raw_original_stores_opened_by_this_analyzer':False,'raw_store_bytes_independently_rehashed_by_this_analyzer':False},
        'observer_integrity':observer_integrity,'combined':combined,'profiles':edits,'cancellations':cancellations,'bulk_cases':bulks,
        'all_timing_annotation_groups':alltargets,'timing_groups_with_target_misses':timing_misses,'closed_observers':observers,
        'saved_resources':resource,'page_clock_checks':page_clock_checks(edits),'descriptive_native12_comparison':comparison,
        'recorded_environment':{'performance_profile':'portable correctness','NEISTRA_PERFORMANCE':'0','host_hardware_and_load_during_C4':'Unavailable in this gate transport; no matched controlled-host claim.', 'recipe':str(ROOT/'docs/assets/ligand-properties/c5-candidate4-recipe.json')},
        'renewal_totals':{'calls':sum(row['renewal_traffic']['heartbeat_calls'] for row in bulks),'full_UTF8_response_body_bytes':sum(row['renewal_traffic']['heartbeat_full_response_body_UTF8_bytes_total'] for row in bulks),'all_consumer_updates':sum(row['consumer_update_calls'] for row in bulks)},
        'policy':'D148 retains100ms feedback/cache,2000ms cold and5000ms bulk targets/misses. Portable work/resource/scientific/cancellation/deadline bounds remain mandatory; absolute latency enforcement is additional opt-in controlled reference-host qualification.',
        'no_SQL_apps_services_process_network_or_chemistry_execution':True,'final_feature_release_qualification':False}
    for name,expected in list(INPUTS.items()):
        actual = Path(name) if Path(name).is_absolute() else ROOT/name
        assert fingerprint(actual,register=False) == expected, f'Closed input drift: {actual}'
    for name,value in {'assessment.json':summary,'comparison-samples.json':{'cold_samples':cold_compares},'input-identities.json':dict(sorted(INPUTS.items()))}.items():
        with (OUT/name).open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'scope':summary['scope'],'candidate':HEAD,'workflow_passes':8,'input_files':len(INPUTS),'combined':combined,'renewal_totals':summary['renewal_totals'],'resource_samples':resource['case_observer_samples_total']}))

if __name__ == '__main__':main()
