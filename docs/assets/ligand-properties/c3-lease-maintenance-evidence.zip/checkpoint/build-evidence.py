"""Preserve bounded tooling correction evidence; never assert final qualification."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import runpy
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
ASSETS = ROOT / "docs/assets/ligand-properties"
BASE = "0f843c17733ef1a84b8c804be6cdcb485c0ddde6"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


worker = ROOT / ".issue-11-evidence/issue159-bulk-lease-maintenance-validation1"
handoff = json.loads((worker / "handoff.json").read_text())
delta = json.loads((OUT / "source-delta.json").read_text())
sources = json.loads((OUT / "selected-sources.json").read_text())
methods = json.loads((OUT / "benchmark-methods.json").read_text())
tool_paths = ["docs/assets/ligand-properties/release-evidence.py.txt",
              "tests/unit/test_ligand_properties_release_recipe.py"]
subjects = {**handoff["owned_subjects"], **{n: sources[n] for n in tool_paths}}
assert len(subjects) == 5 and all(sha(ROOT / n) == value for n, value in subjects.items())
assert delta["source_count"] == len(sources) == 1128 and len(methods) == 50
for row in handoff["checks"].values():
    assert row["exit_code"] == 0 and sha(ROOT / row["log"]) == row["log_sha256"]
strict = json.loads((worker / "strict-ts-observed.json").read_text())
common = {"scope": "Primary-persisted independent scoped conversation assessment; not final all-seven approval",
          "base_candidate": BASE, "subjects": subjects, "scoped_verdict": "PASS",
          "consequential_findings": [], "final_qualification": "BLOCKED pending fresh ALL8/full43/final same-candidate reviews",
          "reviewer_actions": "Read-only source and closed evidence; no tests/apps/browser/SQL/Git or files"}
save(OUT / "architecture-assessment.json", {**common,
     "reviewer": "/root/issue159_native9_lease_failure_architecture", "role": "software_architecture",
     "inspected": "Complete five-path correction, original/native9 diff, all eight timer controls and closed logs; both release-helper P2 findings closed",
     "guards": "Serial renewal/stop-await/first-error/evidence lifetime; actual scoped sidecars, correct plan and genuine successful final ALL8 required",
     "existing_other_tool_function_ASTs_unchanged": 24})
save(OUT / "performance-assessment.json", {**common,
     "reviewer": "/root/issue159_independent_performance_review", "role": "performance",
     "subjects": handoff["owned_subjects"],
     "inspected": "Complete three-file correction, frozen-spec diff, eight timer controls and raw test/lint/type logs",
     "limits": "Renewal traffic and response retention are new measured benchmark overhead; genuine API/event-loop failure can still expire leases; no fresh runtime result"})
preservation = ROOT / ".issue-11-evidence/issue159-native9-failure-preservation1"
failed = json.loads((preservation / "handoff.json").read_text())
root_readback = ROOT / ".issue-11-evidence/issue159-native9-primary-preservation-readback1/readback.json"
assert sha(root_readback) == "6263a57f79b32fe7045bb36ff88f09f4ad210cc0e7e1306d6a94c52e4b938929"
save(ASSETS / "c3-native9-failed-checkpoint.json", {
    "scope": "Complete failed native9 preservation; never final ALL8 or release qualification",
    "captured_candidate": BASE, "source_count": 1126, "benchmark_method_count": 49,
    "actual_runner_wait_exit": 1, "passed": 3, "failed": 1, "did_not_run": 4,
    "failure": "HTTP409 property_consumer_expired: next heartbeat starts27.443ms after returned60s expiry; backend correctly rejects it",
    "correction": "Test-only independent serial20s maintenance; same payloads/sequences/TTL/workload/deadlines; requires fresh full ALL8",
    "private_packet": failed["private_archive"],
    "regular_original_files": 3225, "original_bytes": 160009333,
    "roots": 7, "empty_directories": 5, "inert_aliases": 0,
    "all_regular_original_and_archived_bodies_CRC_exact_union_verified": True,
    "recursive_verification": failed["recursive_verification"],
    "primary_readback_sha256": sha(root_readback), "originals_retained": True,
    "raw_DB_WAL_SHM_copied_before_SQL_and_revalidated": True,
    "planned_separate_release_asset": failed["planned_separate_release_asset"],
    "planned_checksum_companion": failed["planned_checksum_companion"],
    "publication_pending": True, "qualified_main_member": False,
    "partial_measurements": {"desktop_cold_median_ms": 4438.55, "desktop_cold_p95_ms": 7681.7,
        "desktop_cold_max_ms": 8695.7, "cache_projection_median_ms": 158.7,
        "cache_above100ms": "17/20", "repeated_bulk_active_ms": 17494.1,
        "cancellation_ms": 27.9, "warm_new_jobs": 0,
        "limits": "Materially higher shared-host load; no causal speedup/regression or strict-host certification. Distinct incomplete, mobile unrun."}})
tools = runpy.run_path(str(ASSETS / "release-evidence.py.txt"), run_name="local_checkpoint_archive_only")
items = {}
for n in subjects:
    items["source-after/" + n] = ROOT / n
    if n in delta["changed"]:
        items["source-before/" + n] = subprocess.check_output(["git", "show", f"{BASE}:{n}"], cwd=ROOT)
for p in sorted(worker.iterdir()):
    assert p.is_file() and not p.is_symlink()
    items["validation/maintenance/" + p.name] = p
for n in ["source-delta.json", "selected-sources.json", "benchmark-methods.json",
          "architecture-assessment.json", "performance-assessment.json", "build-evidence.py"]:
    items["checkpoint/" + n] = OUT / n
for relative, name in [
    ("issue159-release-packager-correction-validation1/verification.json", "packaging-verification.json"),
    ("issue159-native9-primary-terminal-readback1/readback.json", "native9-terminal-readback.json"),
    ("issue159-native9-primary-diagnosis1/architecture-diagnosis.json", "native9-architecture-diagnosis.json"),
    ("issue159-native9-primary-preservation-readback1/readback.json", "native9-packet-readback.json"),
    ("issue159-native9-failure-preservation1/handoff.json", "native9-forensic-handoff.json"),
]:
    items["validation/" + name] = ROOT / ".issue-11-evidence" / relative
analysis = ROOT / ".issue-11-evidence/issue159-native9-partial-performance-assessment1"
for p in sorted(analysis.iterdir()):
    assert p.is_file() and not p.is_symlink()
    items["native9-partial-analysis/" + p.name] = p
items["checkpoint/native9-public-metadata.json"] = ASSETS / "c3-native9-failed-checkpoint.json"
packet = tools["archive"](items, ASSETS / "c3-lease-maintenance-evidence.zip")
save(OUT / "packet-verification.json", {"packet": packet, "input_members": len(items),
     "all_supplied_bodies_CRC_recursive_hashes_and_exact_union_verified": True,
     "scope": "Local tooling evidence; both raw failed assets remain separately preserved"})
save(ASSETS / "c3-lease-maintenance-checkpoint.json", {
    "scope": "Passing LOCAL benchmark-maintenance and release-packaging checkpoint; no current ALL8 or release readiness",
    "base_candidate": BASE, "source_count": 1128,
    "source_digest_compact_json": delta["source_compact_digest"],
    "source_digest_spaced_json": delta["source_spaced_digest"],
    "method_count": 50, "method_digest_spaced_json": delta["method_spaced_digest"],
    "subjects": subjects, "source_delta": delta,
    "focused_maintenance_tests": 8, "focused_packaging_tests": 52,
    "web_lint": "PASS", "web_types": "PASS", "strict_benchmark_TypeScript": strict,
    "scoped_architecture": "PASS", "scoped_performance": "PASS",
    "original_assertion_chains": 167, "original_expect_call_nodes": 334,
    "original_budget_calls": 8, "original_wait_calls": 5, "original_case_deadlines": 3,
    "original_assertion_workload_target_deadline_ASTs_preserved": True,
    "production_scientific_API_TTL_schema_dependency_versions_changed": False,
    "actual_native9_outcome": "exit1/3PASS/1FAIL/4unrun; failed evidence retained",
    "actual_final_ALL8_success_receipt_created": False,
    "fresh_complete_ALL8_full43_both_final7_and_delivery_pending": True,
    "packet": "docs/assets/ligand-properties/c3-lease-maintenance-evidence.zip",
    **{k: packet[k] for k in ("bytes", "sha256", "outer_manifest_entries", "verification_counts")},
    "recorded_utc": datetime.now(timezone.utc).isoformat()})
print(json.dumps({"packet": packet, "subjects": subjects}, indent=2))
