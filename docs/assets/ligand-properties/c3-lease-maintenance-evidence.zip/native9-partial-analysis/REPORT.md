# Partial native9 performance assessment

Candidate0f843c17733ef1a84b8c804be6cdcb485c0ddde6; baselinec22e75792f0d9c01ef797baa8396871153c33aa0. Independent performance specialist assessment is BLOCKED for final qualification. Actual native9 runner exit1: three desktop cases passed, distinct desktop bulk failed, and four mobile cases were unrun after max-failures1. These are not timing exclusions. The primary separately verified terminal identity, owned cleanup and original raw DB/WAL/SHM capture before SQL; this assessment reads no databases.

## Measurements and comparison limits

Same49 benchmark bodies and intended graphs. All20 paired initial/changed scientific hashes agree with baseline. The only changed existing selected body is Inspector; the new selected body is its regression test (1125 to1126). Original workload, targets, deadlines and portable profile remain unchanged for these recorded runs.

| Desktop observation | Baseline | Partial native9 |
| --- | --- | --- |
| Five fresh-browser cold contexts, median / max ms | 910.2 /935.5 |1897.0 /1934.5 |
| Twenty actual cold edits, median / nearest-rank p95 / max ms |1995.0 /2199.8 /2210.4 |4438.55 /7681.7 /8695.7 |
| Actual cold edits above2000ms |8/20 |20/20 |
| Twenty matching-cache projections, median / max ms |57.95 /69.0 |158.7 /464.5 |
| Cache projections above100ms |0/20 |17/20 |
| Cold-edit visible feedback, median / max ms |37.1 /94.3 |269.25 /945.1 |
| Cold-edit feedback above100ms |0/20 |20/20 |
| Warm Undo visible feedback, median / max ms |103.9 /110.5 |217.35 /703.7 |
| Warm feedback above100ms |19/20 |20/20 |
| Accepted-demand cancellation feedback ms |11.7 |27.9 |
| Repeated1000-entry active READY ms |7623.9 |17494.1 |
| Repeated1000-entry edit feedback ms |1228.3 |3740.0 |

These current observations are slower; they establish neither a causal regression nor a speedup from the Inspector correction. Both runs use the same16-logical-CPU machine, but sampled one-minute load median/p95/max changes from4.69/7.31/8.44 to12.62/28.95/32.12. Current initial load25.07 versus baseline1.65. N=1 repeated bulk observation per revision is not a cohort percentile estimate. No power, affinity, CPU quota or host setting was altered by this assessment. Fresh browser contexts are not cold server/OS starts. Cancellation measures UI retention after a late accepted reply, not sole-worker termination latency.

## Work, requests and retention

All20 current Undo/cache paths create zero new jobs. Both revisions record one demandPUT and two exact-source READs per warm Undo, after the trusted Undo trigger. Cold edited-source requests change from two READs for all20 to three for19 and two for1, with one demandPUT throughout. These are measured counts, not newly imposed or relaxed caps. Source byte/CPU costs for every App request are not captured by worker provenance and must not be described as free.

The successful repeated cohort reaches1000 current bindings and one content hash, with three private calculation jobs plus one ordinary job. All private jobs are reaped. Its ordinary job is claimed after one actual productive derived turn (warm progress); active admission has zero intervening productive bulk-fairness turns;856 bulk bindings publish after acceptance, proving overlap. The closed work-order body hash and every record's contiguous numbering verify. Repeated cohort aggregate reads are60x200=12000 entry operations versus65x200=13000 before; consumer update/allocation calls50 versus25. Execution duration and renewal traffic differ, so these do not imply an efficiency improvement.

All four current closed observers are complete with max one running private job. Their retained counts/provenance satisfy existing source/read/capture/cache/execution bounds. Current peak observed childRSS119607296B and worker-parentRSS211300352B remain below the applicable child limit; these sampled values are not every-instant limits. The complete-sample outer owned-process RSS maximum is1797079040B; two process observations lacked RSS because the process vanished. Browser/GPU accounting is incomplete. Case job sets may overlap and must not be summed into a global new-job count.

The failed distinct cohort has91 observed completed/reaped private jobs plus one ordinary job,768 retained content records,769 proofs and32 executions at observer close. Its output explicitly says incomplete_workload and has no readyCount, final binding/hash count or hard work-order PASS. Do not substitute baseline's1000-ready/127-jobs/distinct fairness result. Four mobile cases provide no fresh candidate measurements.

## Required disposition

D148 preserves100ms feedback/cache,2000ms cold and5000ms bulk targets. Portable correctness/work/resource/cancellation/production deadlines remain mandatory; absolute targets are opt-in controlled reference-host qualification. No complete ALL8 or final feature performance acceptance follows from this partial run.

Architecture and primary separately own the reproduced expired-heartbeat failure and its correction. A serial independent renewal-maintenance lane is reasonable if it preserves the same five owners/payloads/sequences/60s leases and20s cadence, permits at most one outstanding renewal globally, accumulates no catch-up tasks, stops and awaits before sequence2 teardown, and propagates failures without retries/reallocation. Record additional renewal traffic and the changed method identity. No further profiling is needed for this established defect. This is a pre-code assessment, not approval of an unseen implementation.

The analyzer uses only standard-library closed-file parsing, hashing and arithmetic. Its final execution exits0 (tool6819b3);35 input bodies are enumerated in input-identities.json. During authoring, metadata-only checks corrected header-versus-record counting, the cancellation currentMs field, and unavailable RSS handling; no application workload was run. Current fullALL8, full43 candidate/exact-master gates and all-seven same-final-candidate assessments remain required.
