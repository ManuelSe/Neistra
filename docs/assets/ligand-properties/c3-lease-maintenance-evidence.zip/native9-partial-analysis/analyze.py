"""Closed-file partial-run arithmetic only; no application imports or SQL."""

import collections
import datetime
import hashlib
import json
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
PERF = ROOT / ".issue-11-evidence/issue159-performance"
INPUTS = {}


def read(path):
    path = Path(path)
    body = path.read_bytes()
    key = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
    INPUTS[key] = {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}
    return body


def load(path):
    return json.loads(read(path))


def metric(values, limit=None):
    values = sorted(values)
    assert values and all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in values)
    result = {"n": len(values), "min": values[0], "median": statistics.median(values),
              "p95_nearest_rank": values[math.ceil(len(values) * .95) - 1], "max": values[-1]}
    if limit is not None:
        result.update(limit=limit, misses=sum(v > limit for v in values))
    return result


def distribution(values):
    return dict(sorted(collections.Counter(map(str, values)).items()))


def has_source(request, source):
    return source in request.get("sources", [])


def request_counts(pairs, source_key):
    rows = []
    for pair in pairs:
        phase = "cold" if source_key == "changedSource" else "warm"
        requests = [r for r in pair["requests"] if has_source(r, pair[source_key])
                    and r["at"] >= pair[phase]["started"]]
        rows.append({"READ": sum(r["path"].endswith("/read") for r in requests),
                     "PUT": sum(r["method"] == "PUT" for r in requests)})
    return {key: distribution(r[key] for r in rows) for key in ["READ", "PUT"]}


def browser_cases(document):
    result = []
    def visit(suite):
        for spec in suite.get("specs", []):
            for test in spec["tests"]:
                result.append({"title": spec["title"], "project": test["projectName"],
                               "outcome": test["status"], "attempts": [
                                   {"status": r["status"], "duration_ms": r["duration"], "retry": r["retry"]}
                                   for r in test["results"]]})
        for child in suite.get("suites", []):
            visit(child)
    for suite in document["suites"]:
        visit(suite)
    return result


def observer(path):
    data = load(path / "worker-observation.json")
    jobs = list(data["jobs"].values())
    private = [job for job in jobs if job.get("execution_id")]
    maxima = collections.defaultdict(float)
    guard_errors = []
    for job in private:
        provenance = job["provenance"]
        for group in ["source_capture", "input_materialization", "publication_verification"]:
            for key, value in provenance.get(group, {}).items():
                if type(value) in (int, float):
                    maxima[group + "." + key] = max(maxima[group + "." + key], value)
        capture = provenance.get("source_capture", {})
        materialization = provenance.get("input_materialization", {})
        publication = provenance.get("publication_verification", {})
        checks = [capture.get("coordinator_native_preparations", 0) == 0,
                  capture.get("source_proofs", 0) <= 8,
                  capture.get("verified_bytes", 0) <= 64 * 1024**2,
                  capture.get("source_read_calls", 0) <= 16,
                  capture.get("source_read_byte_cap", 0) <= 64 * 1024**2 + 16,
                  publication.get("verified_bytes", 0) <= 64 * 1024**2,
                  publication.get("source_reads", 0) <= 16,
                  publication.get("read_byte_cap", 0) <= 64 * 1024**2 + 16,
                  materialization.get("verified_bytes", 0) <= 64 * 1024**2,
                  materialization.get("envelope_bytes", 0) <= 96 * 1024**2]
        if not all(checks):
            guard_errors.append(job["id"])
    retained = data["retained"]
    assert data["complete"] and data["sources_unchanged"]
    assert data["max_running_property_jobs"] <= 1
    assert retained["content_bytes"] <= 16 * 1024**2
    assert retained["ligand_property_content"] <= 2048
    assert retained["ligand_property_proofs"] <= 4096
    assert retained["ligand_property_executions"] <= 33
    assert not guard_errors
    trace = data.get("work_order")
    trace_verified = False
    if trace and trace["complete"]:
        body = read(trace["observed_records"])
        assert hashlib.sha256(body).hexdigest() == trace["observed_sha256"]
        header, *records = [json.loads(line) for line in body.splitlines()]
        assert header["event"] == "header" and header["format_version"] == 1
        assert len(records) == trace["records"]
        assert all(r["record"] == trace["start_record"] + i + 1 for i, r in enumerate(records))
        trace_verified = True
    return {"complete": data["complete"], "samples": data["samples"],
            "observed_jobs": len(jobs), "observed_private_jobs": len(private),
            "private_statuses": dict(collections.Counter(j["status"] for j in private)),
            "all_observed_private_jobs_reaped": all(j["reaped"] for j in private),
            "max_running_property_jobs": data["max_running_property_jobs"],
            "retained": retained, "peak_child_RSS_bytes": max(data["peak_child_rss_bytes"].values(), default=0),
            "peak_worker_parent_RSS_bytes": max(data["peak_worker_parent_rss_bytes"].values(), default=0),
            "observed_provenance_bound_errors": guard_errors, "provenance_maxima": dict(maxima),
            "closed_work_order_hash_and_contiguity_verified": trace_verified,
            "limits": "Case-close retention and sampled RSS, not every-instant/browser/GPU ceilings. Job sets across cases may overlap."}


def run(label):
    folder = PERF / label
    receipt = load(folder / "actual-receipt.json")
    browser = load(folder / "browser.json")
    resources = [json.loads(line) for line in read(folder / "owned-resource-samples.jsonl").splitlines()]
    assert receipt["source_before"] == receipt["source_after"]
    assert receipt["methods_before"] == receipt["methods_after"]
    assert receipt["cleanup"]["complete"] and not receipt["cleanup"]["positively_owned_processes_remaining"]
    assert all(receipt["cleanup"]["ports_unused"].values())
    result = {"candidate": receipt["authoritative_HEAD_before"], "exit": receipt["exit_code"],
              "browser_stats": receipt["browser_stats"], "cases": browser_cases(browser),
              "source_count": len(receipt["source_before"]),
              "source_digest_compact": hashlib.sha256(json.dumps(receipt["source_before"], sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
              "methods": len(receipt["methods_before"]),
              "host": {"cpu": receipt["host_before"]["cpu_model"], "logical_cpus": receipt["host_before"]["cpu_count"],
                       "load_before": receipt["host_before"]["load_average"], "load_after": receipt["host_after"]["load_average"],
                       "sampled_load_1min": metric([r["load_average"][0] for r in resources]),
                       "resource_samples": len(resources),
                       "unavailable_process_RSS_measurements": sum("rss_bytes" not in p for r in resources for p in r["owned"]),
                       "max_complete_sample_owned_total_RSS_bytes": max(sum(p["rss_bytes"] for p in r["owned"]) for r in resources if all("rss_bytes" in p for p in r["owned"]))},
              "cleanup_complete": True, "raw_database_capture_error": receipt["database_byte_archive_error"],
              "workflows": {}}
    for raw_path in receipt["new_harness_directories"]:
        path = Path(raw_path)
        for file in path.glob("native*performance.json"):
            data = load(file)
            if data["profile"] != "chromium":
                continue
            obs = observer(path)
            name = "bulk-" + data["kind"] if "kind" in data else "edits" if "records" in data else "cancel"
            item = {"input": str(file.relative_to(ROOT)), "worker_observation": obs}
            targets = collections.defaultdict(list)
            for target in data.get("targets", []):
                targets[(target["label"], target["limit"])].append(target["actual"])
            item["all_target_groups"] = {key[0]: metric(values, key[1]) for key, values in targets.items()}
            if name == "edits":
                pairs = [r for r in data["records"] if r["kind"] == "paired-edit"]
                cold = [r for r in data["records"] if r["kind"] == "fresh-browser-context-cold-start"]
                assert len(pairs) == 20 and len(cold) == 5
                item.update(cold_edits_ms=metric([r["cold"]["networkCurrentMs"] for r in pairs], 2000),
                            fresh_browser_cold_starts_ms=metric([r["timing"]["networkCurrentMs"] for r in cold], 2000),
                            matching_cache_projection_ms=metric([r["cachedProjectionMs"] for r in pairs], 100),
                            cold_feedback_ms=metric([r["cold"]["feedbackMs"] for r in pairs], 100),
                            warm_feedback_ms=metric([r["warm"]["feedbackMs"] for r in pairs], 100),
                            warm_new_jobs=sum(r["warmNewJobs"] for r in pairs),
                            cold_exact_source_requests=request_counts(pairs, "changedSource"),
                            warm_exact_source_requests=request_counts(pairs, "oldSource"),
                            exact_pair_inputs=[{"index": r["index"], "heavy_atoms": r["heavyAtoms"],
                                                "original_graph_hash": r["firstInputHash"], "changed_graph_hash": r["changedInputHash"]} for r in pairs])
            elif name == "cancel":
                assert data["cancellation"]["currentMs"] == data["targets"][0]["actual"]
                item.update(feedback_ms=metric([data["cancellation"]["currentMs"]], 100),
                            requests_before_Retry=len(data["requests"]),
                            demand_PUTs_before_Retry=sum(r["method"] == "PUT" for r in data["requests"]))
            else:
                item["hard_work_order_status"] = data["hardWorkOrderStatus"]
                item["completed_bulk_workload"] = "readyCount" in data
                if "readyCount" in data:
                    hard = data["hardWorkOrder"]
                    item.update(active_READY_ms=metric([data["active"]["networkCurrentMs"]], 5000),
                                active_feedback_ms=metric([data["active"]["feedbackMs"]], 100),
                                ready_count=data["readyCount"], distinct_hashes=data["qualifiedDistinctInputHashes"],
                                changed_input_hash=data["changedInputHash"],
                                aggregate_READ_calls=len(data["aggregateReads"]),
                                aggregate_READ_entry_operations=sum(r["entries"] for r in data["aggregateReads"]),
                                consumer_update_calls=len(data["consumerUpdates"]),
                                actual_productive_derived_turns_before_ordinary=hard["ordinary"]["productiveDerivedTurnsBeforeClaim"],
                                actual_warm_progress_turns_before_ordinary=hard["ordinary"]["warmProgressTurnsBeforeClaim"],
                                productive_bulk_fairness_turns_before_active=len(hard["active"]["productiveBulkFairnessTurnsBeforeAdmission"]),
                                post_acceptance_bulk_bindings=hard["active"]["actualPostAcceptanceBulkBindings"],
                                priority_overlap=hard["active"]["priorityOverlapExercised"])
            result["workflows"][name] = item
    return receipt, result


previous, baseline = run("native-probe8-all8")
current, candidate = run("native-probe9-all8")
assert baseline["exit"] == 0 and candidate["exit"] == 1
assert current["methods_before"] == previous["methods_before"]
changed = sorted(p for p in previous["source_before"] if current["source_before"].get(p) != previous["source_before"][p])
added = sorted(set(current["source_before"]) - set(previous["source_before"]))
assert changed == ["apps/web/src/components/ProjectInspector.tsx"]
assert added == ["apps/web/src/test/project-inspector-query-scaling.test.tsx"]
assert candidate["workflows"]["edits"]["exact_pair_inputs"] == baseline["workflows"]["edits"]["exact_pair_inputs"]
root_proof_path = ROOT / ".issue-11-evidence/issue159-native9-primary-terminal-readback1/readback.json"
assert hashlib.sha256(read(root_proof_path)).hexdigest() == "8290fe84e68fa714a38d5180b0b938394e1dd81b9d09b90de30b3fb785319350"
assessment = {"scope": "Independent performance specialist closed-file assessment of partial native9; no final qualification or causal speedup claim",
              "reviewer": "/root/issue159_independent_performance_review", "role": "performance", "verdict": "BLOCKED",
              "recorded_utc": datetime.datetime.now(datetime.UTC).isoformat(),
              "performed": "Standard-library closed JSON/JSONL byte hashing and arithmetic only; no apps, SQL, services, browsers, tests, source edits or Git",
              "baseline": baseline, "candidate": candidate,
              "exact_source_delta": {"changed": changed, "added": added, "all49_benchmark_bodies_equal": True},
              "findings": ["Actual terminal1: three desktop cases passed; distinct desktop case failed; four mobile cases unrun after max-failures1, not timing exclusions.",
                           "Current desktop observations are slower than the source-qualified baseline. Shared-host load differs materially; these observations establish neither a causal regression nor a speedup from the Inspector correction.",
                           "The successful repeated cohort still reaches1000 current bindings,1contenthash, bounded jobs/resources and productive fairness. Distinct cohort is incomplete and must not inherit those success claims.",
                           "Actual expired-heartbeat failure diagnosis/correction is separately owned by architecture and primary; no duplicate diagnosis or new profile requested."],
              "policy": "D148: keep100ms feedback/cache,2000ms cold and5000ms bulk targets unchanged. Portable correctness/work/resource/cancellation/deadline bounds mandatory; strict absolute timings opt-in, not established by partial workflow passes.",
              "limits": ["One run per revision under different shared-host conditions; desktop-only partial overlap, no all-profile qualification or controlled A/B inference.",
                         "Fresh-browser contexts are not cold OS/server claims. Cancellation feedback is not sole-worker termination latency.",
                         "Sampled RSS and case-close retention are not complete browser/GPU or every-instant accounting. Case job sets may overlap and must not be summed as new global jobs.",
                         "Current fullALL8, full43candidate/exactmaster and same-final-candidate seven-role acceptance remain required."]}
(OUT / "input-identities.json").write_text(json.dumps(INPUTS, indent=2, sort_keys=True) + "\n")
(OUT / "assessment.json").write_text(json.dumps(assessment, indent=2, sort_keys=True) + "\n")
print(json.dumps({"candidate": candidate["candidate"], "exit": candidate["exit"], "cases": candidate["browser_stats"],
                  "input_files": len(INPUTS), "output": str(OUT / "assessment.json"),
                  "source_delta": assessment["exact_source_delta"], "current_host": candidate["host"],
                  "baseline_host": baseline["host"]}, indent=2))
