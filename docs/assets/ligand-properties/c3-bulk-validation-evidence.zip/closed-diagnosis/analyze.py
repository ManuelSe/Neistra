"""Bounded closed trace/JSON arithmetic; no application imports or SQL."""
import collections
import datetime
import hashlib
import json
import statistics
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
RUN = ROOT / ".issue-11-evidence/issue159-performance/native-probe10-all8"
INPUTS = {}


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    key = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
    INPUTS[key] = {"bytes": path.stat().st_size, "sha256": digest.hexdigest()}
    return INPUTS[key]


def load(path):
    identity(path)
    return json.loads(Path(path).read_bytes())


root_proof = ROOT / ".issue-11-evidence/issue159-native10-primary-terminal-readback1/readback.json"
assert identity(root_proof)["sha256"] == "983735480a9d4259b1d1551371577d31db7a2c0e65703d0215439e6b28b7ea68"
receipt = load(RUN / "actual-receipt.json")
assert receipt["exit_code"] == 1 and receipt["cleanup"]["complete"]
assert receipt["source_before"] == receipt["source_after"]
assert receipt["methods_before"] == receipt["methods_after"]
harness = next(Path(p) for p in receipt["new_harness_directories"]
               if (Path(p) / "native-bulk-performance.json").exists()
               and json.loads((Path(p) / "native-bulk-performance.json").read_bytes())["kind"] == "distinct")
data = load(harness / "native-bulk-performance.json")
assert data["hardWorkOrderStatus"] == "incomplete_workload"
browser = load(RUN / "browser.json")
trace = RUN / "native/ligand-properties-performa-bf63b-nd-an-ordinary-job-progress-chromium/trace.zip"
identity(trace)
updates = [{k: v for k, v in row.items() if k != "responseBody"}
           | {"response_body_bytes": len(row.get("responseBody", "").encode()),
              "response_body_sha256": hashlib.sha256(row.get("responseBody", "").encode()).hexdigest()}
           for row in data["consumerUpdates"]]
renewals = [row for row in updates if row["kind"] == "same-sequence-heartbeat"]
failed = next(row for row in renewals if row["status"] != 200)
last_same_owner = [row for row in renewals if row["owner"] == failed["owner"] and row["at"] < failed["at"]][-1]
network = []
steps = []
member_identities = {}
with zipfile.ZipFile(trace) as archive:
    for name in ["test.trace", "0-trace.trace", "0-trace.network"]:
        digest = hashlib.sha256()
        with archive.open(name) as stream:
            for line in stream:
                digest.update(line)
                event = json.loads(line)
                if name == "test.trace":
                    if event["type"] == "context-options":
                        trace_epoch_offset_ms = event["wallTime"] - event["monotonicTime"]
                    if event["type"] == "before":
                        stack = event.get("stack", [])
                        steps.append({"id": event["callId"], "start": event["startTime"],
                                      "method": event.get("method"), "title": event.get("title"),
                                      "line": stack[0].get("line") if stack else None})
                    elif event["type"] == "after":
                        # Preserve only timing, never attachment bodies.
                        steps.append({"id": event["callId"], "end": event["endTime"]})
                elif name == "0-trace.trace":
                    if event["type"] == "before" and event.get("class") == "APIRequestContext" and event.get("method") == "fetch":
                        pass  # Member identity retained; network supplies independently logged body timing.
                else:
                    snapshot = event["snapshot"]
                    request = snapshot.get("request", {})
                    if request.get("method") == "PUT" and "/consumers/" in request.get("url", ""):
                        network.append({"owner": request["url"].rsplit("/", 1)[-1],
                                        "start_trace_ms": snapshot["_monotonicTime"],
                                        "started_utc": snapshot["startedDateTime"],
                                        "duration_ms": snapshot["time"], "timings": snapshot["timings"],
                                        "status": snapshot["response"]["status"],
                                        "response_bytes": snapshot["response"]["bodySize"]})
        member_identities[name] = {"bytes": archive.getinfo(name).file_size, "sha256": digest.hexdigest()}

starts = {}
completed = []
for step in steps:
    if "start" in step:
        starts[step["id"]] = step
    elif step["id"] in starts:
        completed.append(starts[step["id"]] | {"end": step["end"]})
expect_steps = [s for s in completed if s["method"] == "expect"]
groups = []
group = None
for step in completed:
    if step["method"] == "expect" and step["line"] == 854:
        if group:
            groups.append(group)
        group = {"start_trace_ms": step["start"], "end_trace_ms": step["end"], "expect_steps": 1, "lines": collections.Counter({854: 1})}
    elif group and step["method"] == "expect" and step["line"] in {856, 858, 859, 860}:
        group["end_trace_ms"] = step["end"]
        group["expect_steps"] += 1
        group["lines"][step["line"]] += 1
    elif group and step["method"] == "pw:api" and step.get("line") == 848:
        groups.append(group)
        group = None
if group:
    groups.append(group)
for group in groups:
    group["duration_ms"] = group["end_trace_ms"] - group["start_trace_ms"]
    group["lines"] = dict(group["lines"])
assert len(network) == len([row for row in updates if row["kind"] != "allocate"])
offsets = [net["start_trace_ms"] - row["at"] for net, row in zip(network, [row for row in updates if row["kind"] != "allocate"], strict=True)]
assert all(net["owner"] == row["owner"] and net["status"] == row["status"]
           for net, row in zip(network, [row for row in updates if row["kind"] != "allocate"], strict=True))
late_network = network[-6:]
for net in late_network:
    timings = net["timings"]
    net["receive_start_trace_ms"] = net["start_trace_ms"] + timings["send"] + timings["wait"]
    net["receive_end_trace_ms"] = net["start_trace_ms"] + net["duration_ms"]
    net["validation_span_overlap_ms"] = sum(max(0, min(net["receive_end_trace_ms"], g["end_trace_ms"]) - max(net["receive_start_trace_ms"], g["start_trace_ms"])) for g in groups)

resource_path = RUN / "owned-resource-samples.jsonl"
identity(resource_path)
resources = [json.loads(line) for line in resource_path.read_bytes().splitlines()]
worker_points = []
for sample in resources:
    for process in sample["owned"]:
        if process.get("command", [""])[-1:] and process["command"][-1].endswith("playwright/lib/common/process.js") and "user_cpu_ticks" in process:
            utc_ms = datetime.datetime.fromisoformat(sample["utc"]).timestamp() * 1000
            worker_points.append({"utc_ms": utc_ms, "trace_ms": utc_ms - trace_epoch_offset_ms,
                                  "pid": process["pid"], "start_token": process["start_token"],
                                  "ticks": process["user_cpu_ticks"] + process["system_cpu_ticks"], "rss_bytes": process["rss_bytes"]})
assert len({(p["pid"], p["start_token"]) for p in worker_points}) == 1
final_start = late_network[0]["start_trace_ms"]
final_end = late_network[-1]["start_trace_ms"] + late_network[-1]["duration_ms"]
points = [p for p in worker_points if final_start <= p["trace_ms"] <= final_end]
cpu = {"identity": {"pid": points[0]["pid"], "start_token": points[0]["start_token"]},
       "sampling_wall_seconds": (points[-1]["utc_ms"] - points[0]["utc_ms"]) / 1000,
       "CPU_seconds": (points[-1]["ticks"] - points[0]["ticks"]) / receipt["host_before"]["clock_ticks_per_second"],
       "samples": len(points), "max_sampled_RSS_bytes": max(p["rss_bytes"] for p in points)}
result = {"scope": "Closed failed native10 performance diagnosis; no new workload or exact server fault diagnosis",
          "candidate": receipt["authoritative_HEAD_before"]["commit"], "verdict": "BLOCKED",
          "run_outcome": receipt["browser_stats"], "failed_owner": failed["owner"],
          "failed_renewal": failed, "last_success_same_owner": last_same_owner,
          "same_owner_request_start_gap_ms": failed["at"] - last_same_owner["at"],
          "same_owner_previous_response_to_failure_start_ms": failed["at"] - last_same_owner["responseAt"],
          "renewal_records": updates, "total_retained_heartbeat_response_bytes": sum(r["response_body_bytes"] for r in renewals),
          "expect_steps": len(expect_steps), "expect_steps_by_source_line": dict(collections.Counter(s["line"] for s in expect_steps)),
          "validation_groups": groups, "longest_validation_groups": sorted(groups, key=lambda g: g["duration_ms"], reverse=True)[:8],
          "validation_span_sum_ms": sum(g["duration_ms"] for g in groups),
          "last_six_renewal_network_records": late_network,
          "metric_to_network_start_offset_ms": {"min": min(offsets), "median": statistics.median(offsets), "max": max(offsets)},
          "final_network_window_test_worker_CPU": cpu, "trace_member_identities": member_identities,
          "limits": ["Trace step spans and sampled process CPU establish the synchronous test path but are not a fresh function CPU profile or event-loop-lag instrument.",
                     "API network receive timings are client-observed spans, not independent wire/server CPU measurements.",
                     "Do not infer host load caused the failure or promise a new timing result. Exact HTTP/source/TTL diagnosis belongs to architecture.",
                     "Three earlier passes and four unrun mobile cases do not establish complete ALL8 qualification."]}
(OUT / "input-identities.json").write_text(json.dumps(INPUTS, indent=2, sort_keys=True) + "\n")
(OUT / "diagnosis.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({key: result[key] for key in ["candidate", "expect_steps", "validation_span_sum_ms", "longest_validation_groups", "same_owner_request_start_gap_ms", "same_owner_previous_response_to_failure_start_ms", "last_six_renewal_network_records", "final_network_window_test_worker_CPU", "total_retained_heartbeat_response_bytes"]}, indent=2))
