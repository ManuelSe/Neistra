# Closed native10 performance diagnosis

Candidate060c0fa0e06f156df253ffe55473fcaeb007242a. Actual runner exit1, three desktop cases passed, distinct bulk failed and four mobile cases unrun. Final qualification verdict: BLOCKED. Root independently verified terminal/source/owned cleanup/raw capture before this analysis; no database was opened here. Exact HTTP/source/TTL fault diagnosis belongs to the architecture reviewer.

The closed failed-case trace records48,641 completed expect steps. Of these,88 foreground200-row response validation blocks span193,354.975ms. The longest span is7,878.925ms and emits801 synchronous matcher steps: one source-array equality;200 status checks;200 ready-report qualification checks;200 length14 checks;200 every-value-ready-and-finite checks. The captured source has no await inside that validation loop. These are measured synchronous test validation spans, not browser renderer timings or exact individual-function CPU.

The renewal lane was operating, not absent. The failed owner's request-start gap is67,036.780ms, with51,171.632ms from its previous response to the failed request. Preceding serial renewals occupy the lane. The last two successful request network records take14,774.262ms and19,125.899ms, including client-observed receive spans9,422.510ms and9,583.627ms. Those receive spans overlap6,652.441ms and7,878.925ms of foreground validation. The same positively identified test-worker PID4071276/start183624868 accumulates42.98CPU seconds over66.459wall seconds in the final six-request window (33 samples). This supports reducing repeated synchronous test matcher/report work. It does not isolate all network/server cost, establish exact function CPU, or demonstrate host load caused failure.

The test trace is51,832,778 bytes. Recorded heartbeat response bodies total15,559,120 bytes. Both assertion/report and response-preservation overhead are part of the measured harness; neither should be called cost-free or an application performance regression. Actual HTTP lease expiry is separately established by architecture; this analysis does not change its contract.

## Smallest correction accepted before implementation

Replace per-row Playwright matcher/report invocations with a pure all-row predicate collector and a constant number of matcher steps per200-row response. Preserve exact ordered source-array equality. Every row must still have an accepted ready/pending status. Every ready row must still contain a qualified report, exactly14 values, and every value must have ready status and a finite numeric result. Preserve all1000 rows, all14 values, original graphs, workload ordering, actual fairness proof, resources and successful completion. Do not sample, skip malformed rows, accept missing reports as pending, or replace semantic checks with counts alone.

Keep the independent20s serial renewal lane, same five200-entry owners, original payloads/sequences and60s TTL. No retries, reallocation, extra renewal process, longer deadlines or changed targets are needed for this correction. Preserve all eight cases,15-minute bulk progress cap,20-minute case cap and D148 portable/strict distinction. This recommendation is a pre-code assessment; actual implementation needs scoped review and fresh execution.

Independent regression acceptance:

- Compare the new predicate outcomes with the preceding pointwise rules on valid and malformed fixtures.
- Independently reject wrong/missing/out-of-order source identity; wrong row status; absent/unqualified ready report; wrong value count; wrong value status; nonfinite value.
- Place faults in the final row200 and final descriptor14, as well as early positions; prove all entries/values are checked.
- Preserve pending rows without demanding a completed report; reject an unavailable/failed row where only ready/pending are allowed.
- Verify matcher/report work is bounded per batch and the same aggregate data is observed. Retain heartbeat failure, serial/no-retry and stop/await controls.

No further profile is required before this bounded correction. Fresh complete ALL8 and full release gates remain necessary; no predicted timing improvement or complete capacity acceptance is claimed.

Analysis uses standard-library closed-file parsing, hashing and arithmetic only. Actual tool2a6d31 exits0; original trace/resource/JSON bodies and analyzed trace members are hashed in input-identities.json and diagnosis.json. No application imports, chemistry, SQL, tests, browsers, services, Git actions or source edits were performed. Files were written only inside the assigned diagnosis directory.
