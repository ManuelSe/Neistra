"""Preserve complete local oracle correction evidence; no final PASS is inferred."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import runpy
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
ASSETS = ROOT / "docs/assets/ligand-properties"
BASE = "060c0fa0e06f156df253ffe55473fcaeb007242a"
PRIVATE = ROOT / ".issue-11-evidence"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


worker = PRIVATE / "issue159-bulk-validation-correction1"
handoff = json.loads((worker / "handoff.json").read_text())
delta = json.loads((OUT / "source-delta.json").read_text())
subjects = {n: handoff["subjects"][n] for n in handoff["owned_public_paths"]}
assert len(subjects) == 3 and all(sha(ROOT / n) == h for n, h in subjects.items())
for row in handoff["checks"].values():
    assert row["exit_code"] == 0 and sha(ROOT / row["log"]) == row["log_sha256"]
common = {"scope": "Primary-persisted independent scoped conversation assessment; not final application approval",
          "base_candidate": BASE, "subjects": subjects, "scoped_verdict": "PASS",
          "consequential_findings": [], "final_qualification": "BLOCKED pending fresh ALL8/full43/final seven",
          "checks": "Read complete source/frozen-spec delta and independently hash closed16PASS/lint/types/strictTS logs",
          "reviewer_actions": "Read-only; no apps/tests/services/browser/SQL/Git/writes"}
save(OUT / "architecture-assessment.json", {**common,
     "reviewer": "/root/issue159_native9_lease_failure_architecture", "role": "software_architecture",
     "assessment": "Complete old predicates, ordered sources and all other spec bytes retained; bounded indexed diagnostics and meaningful independent faults"})
save(OUT / "performance-assessment.json", {**common,
     "reviewer": "/root/issue159_independent_performance_review", "role": "performance",
     "assessment": "Measured reporting bottleneck addressed by complete pure predicates and constant2 data matchers; no sampling/workload/deadline or heartbeat changes",
     "limits": "No causal application speedup; changed51-subject method requires fresh complete run"})
preservation = PRIVATE / "issue159-native10-failure-preservation1"
failed = json.loads((preservation / "handoff.json").read_text())
readback = PRIVATE / "issue159-native10-primary-preservation-readback1/readback.json"
assert sha(readback) == "61dee004bdcef0a52cdd102c05094c4d841f8daaff87a50252d160d482798147"
save(ASSETS / "c3-native10-failed-checkpoint.json", {
    "scope": "Complete failed native10 forensic preservation; never current ALL8 or release qualification",
    "captured_candidate": BASE, "source_count": 1128, "benchmark_subjects": 50,
    "actual_runner_wait_exit": 1, "passed": 3, "failed": 1, "did_not_run": 4,
    "original_transport": failed["original_transport"],
    "failure": "Expired same-sequence heartbeat after serial request head-of-line delay; backend correctly rejects it",
    "private_packet": failed["private_archive"], "regular_original_files": 3407,
    "original_bytes": 206055602, "roots": 7, "empty_directories": 3, "inert_aliases": 0,
    "all_regular_original_and_archived_bodies_CRC_exact_union_verified": True,
    "recursive_verification": failed["recursive_verification"],
    "primary_readback_sha256": sha(readback), "originals_retained": True,
    "planned_separate_release_asset": failed["planned_separate_release_asset"],
    "planned_checksum_companion": failed["planned_checksum_companion"],
    "publication_pending": True, "qualified_main_member": False,
    "closed_test_instrumentation": {"matcher_steps": 48641, "synchronous_blocks": 88,
        "sum_block_seconds": 193.355, "longest_block_seconds": 7.879,
        "longest_block_matcher_steps": 801, "identified_test_worker_CPU_seconds": 42.98,
        "CPU_window_wall_seconds": 66.459,
        "limits": "Closed test/end-to-end observations; not exclusive function/server/wire CPU or application speedup"}})
items = {}
for n in subjects:
    items["source-after/" + n] = ROOT / n
    if n in delta["changed"]:
        items["source-before/" + n] = subprocess.check_output(["git", "show", f"{BASE}:{n}"], cwd=ROOT)
for directory, prefix in [(worker, "validation"),
                          (PRIVATE / "issue159-native10-closed-performance-diagnosis1", "closed-diagnosis")]:
    for p in sorted(directory.iterdir()):
        assert p.is_file() and not p.is_symlink()
        items[prefix + "/" + p.name] = p
for n in ["source-delta.json", "selected-sources.json", "benchmark-methods.json",
          "architecture-assessment.json", "performance-assessment.json", "build-evidence.py"]:
    items["checkpoint/" + n] = OUT / n
for relative, name in [
    ("issue159-native10-primary-terminal-readback1/readback.json", "native10-terminal-readback.json"),
    ("issue159-native10-primary-preservation-readback1/readback.json", "native10-packet-readback.json"),
    ("issue159-native10-failure-preservation1/handoff.json", "native10-forensic-handoff.json"),
    ("issue159-native10-instrumentation-primary1/precode-assessments.json", "precode-assessments.json"),
]:
    items["proofs/" + name] = PRIVATE / relative
recipe_hashes = {}
for label in ["c4-candidate1", "c4-master1"]:
    p = ASSETS / f"{label}-recipe.json"
    r = json.loads(p.read_text())
    assert r["require_clean"] and len(r["steps"]) == 43
    assert r["preceding_reader"]["commit"] == "247ab651b35c2d58e8939985ae50633de70311a3"
    recipe_hashes[label] = {"path": str(p.relative_to(ROOT)), "sha256": sha(p), "commands": 43, "executed": False}
    items["authored-recipes/" + p.name] = p
items["checkpoint/native10-public-metadata.json"] = ASSETS / "c3-native10-failed-checkpoint.json"
tools = runpy.run_path(str(ASSETS / "release-evidence.py.txt"), run_name="local_oracle_archive_only")
packet = tools["archive"](items, ASSETS / "c3-bulk-validation-evidence.zip")
save(OUT / "packet-verification.json", {"packet": packet, "input_members": len(items),
     "all_supplied_bodies_CRC_recursive_hashes_and_exact_union_verified": True,
     "scope": "Local correction; three large raw forensic assets remain separately preserved"})
save(ASSETS / "c3-bulk-validation-checkpoint.json", {
    "scope": "Passing LOCAL complete batch-oracle checkpoint; no fresh ALL8 or final release readiness",
    "base_candidate": BASE, "source_count": 1130,
    "source_digest_compact_json": delta["source_compact_digest"],
    "source_digest_spaced_json": delta["source_spaced_digest"],
    "method_count": 51, "method_digest_spaced_json": delta["method_spaced_digest"],
    "subjects": subjects, "source_delta": delta,
    "new_oracle_tests": 8, "existing_maintenance_tests": 8, "combined_focused_tests": 16,
    "independent_predicate_fault_batches_rejected": 641, "independent_source_fault_batches_rejected": 4,
    "ready_rows_in_matcher_control": 200, "old_data_matcher_calls": 801, "new_data_matcher_calls": 2,
    "web_lint_types_strict_benchmark_TS": "PASS", "scoped_architecture": "PASS", "scoped_performance": "PASS",
    "all_other_spec_bytes_and_heartbeat_body_exact": True,
    "production_scientific_API_TTL_schema_dependency_versions_changed": False,
    "authored_full_gate_recipes": recipe_hashes,
    "actual_native10_outcome": "runner1/3PASS1FAIL4unrun and separate original transportERROR/identityfalse retained",
    "actual_final_ALL8_success_receipt_created": False,
    "fresh_complete_ALL8_full43_both_final7_and_delivery_pending": True,
    "packet": "docs/assets/ligand-properties/c3-bulk-validation-evidence.zip",
    **{k: packet[k] for k in ("bytes", "sha256", "outer_manifest_entries", "verification_counts")},
    "recorded_utc": datetime.now(timezone.utc).isoformat()})
print(json.dumps({"packet": packet, "subjects": subjects, "recipes": recipe_hashes}, indent=2))
