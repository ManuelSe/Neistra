"""Verify portable source capsule bodies; no current source or runtime access."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import stat
import zipfile

ROOT = Path(__file__).absolute().parent
H = 'b1cdb138c7becb5afa73b8f9bbf1e6d958ae8582'  # Actual qualifying checkpoint; gate success remains independently required.
OLD = '247ab651b35c2d58e8939985ae50633de70311a3'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    path = ROOT / name
    assert path.is_file() and not path.is_symlink()
    return path.read_bytes()


assert isinstance(H, str) and len(H)==40 and all(c in '0123456789abcdef' for c in H), 'Unbound static verifier template'
seal_body = read('source-capture-seal.json')
seal = json.loads(seal_body)
assert seal['candidate'] == H and seal['source_capture_complete'] is True
bindings_body = read(seal['bindings_file']['file'])
assert sha(bindings_body) == seal['bindings_file']['sha256']
bindings = json.loads(bindings_body)
assert bindings['candidate'] == H and bindings['complete_gate_commands'] == 43 and bindings['all_gate_command_exits_zero'] is True
assert bindings['preceding_annotated_tag'] == {'tag': 'v0.36.0', 'object_type': 'tag', 'tag_object': '05ec6685d117d000cd6c23eddfa90144b4d2a5dc', 'peeled_commit': OLD}
maps_body = read(seal['map_file']['file'])
assert sha(maps_body) == seal['map_file']['sha256']
maps = json.loads(maps_body)
assert sha(json.dumps(maps['current'], sort_keys=True, separators=(',', ':')).encode()) == bindings['current_compact_source_digest']
assert len(bindings['qualified_method_map']) == bindings['qualified_method_count']
assert all(maps['current'][name] == digest for name, digest in bindings['qualified_method_map'].items())
model = bindings['source_model']
delta = model['declared_delta']
assert delta == {'tests/e2e/rebranding-zoom.spec.ts': {'before': '5002451820458969f3da28ba6aceaa0a6cdb9753040e33745b632663f610c0bd', 'after': '75ed41b0e75e67cd92a3056311fc98785e0414ee6576aec0abe0e4bb24a19eb0'}, 'tests/unit/test_ligand_properties_release_recipe.py': {'before': 'fa019dffc96a972c56f18197728874eccfde426ea956f99bf2280757b25f783a', 'after': '9947c6b75171656d92578edc6a3dd624396d9520950daeef945558e657e2cce9'}}
native_map = dict(maps['current'])
for name, change in delta.items():
    assert native_map[name] == change['after'] and name not in bindings['qualified_method_map']
    native_map[name] = change['before']
assert len(maps['current']) == model['current_source_count'] == len(native_map) == model['native12_source_count']
assert model['unchanged_source_count'] == len(native_map) - len(delta)
assert sha(json.dumps(native_map, sort_keys=True, separators=(',', ':')).encode()) == model['native12_source_digest_compact']
assert bindings['current_compact_source_digest'] == model['current_source_digest_compact']
verified = {}
for label, commit in [('current', H), ('actual036', OLD)]:
    count = len(maps[label])
    assert count > 0
    row = seal['captures'][label]
    body = read(row['file'])
    assert row['source_count'] == len(maps[label]) == count and row['commit'] == commit
    assert len(body) == row['bytes'] and sha(body) == row['sha256']
    with zipfile.ZipFile(ROOT / row['file']) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) == count and set(names) == set(maps[label])
        assert archive.testzip() is None
        for name, expected in maps[label].items():
            relative = PurePosixPath(name)
            assert not relative.is_absolute() and '..' not in relative.parts and 'PRODUCT_SPEC' not in name
            info = archive.getinfo(name)
            assert not info.is_dir() and not stat.S_ISLNK(info.external_attr >> 16) and not info.flag_bits & 1
            assert sha(archive.read(name)) == expected
    verified[label] = {'source_count': count, 'commit': commit, 'bytes': len(body), 'sha256': sha(body)}
manifest = json.loads(read('source-capsule-manifest.json'))
assert set(manifest['files']) == {'captured-current-sources.zip', 'captured-actual036-sources.zip', 'captured-source-maps.json', 'source-bindings.json', 'source-capture-seal.json', 'verify-sources.py'}
for name, row in manifest['files'].items():
    body = read(name)
    assert len(body) == row['bytes'] and sha(body) == row['sha256']
print(json.dumps({'scope': 'Passed c5-candidate4 source evidence only; no publication qualification.', 'candidate': H, 'source_capture_seal_sha256': sha(seal_body), 'archives': verified, 'qualified_method_count': bindings['qualified_method_count'], 'native12_original_candidate': bindings['native12_original_candidate'], 'CRC_body_hash_unique_exact_unions': 'PASS', 'capsule_manifest_files': len(manifest['files']), 'current_tree_or_HEAD_read': False, 'runtime_or_SQL_access': False}))
