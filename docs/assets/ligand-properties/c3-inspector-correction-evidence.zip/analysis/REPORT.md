The retained diagnostic identifies renderer work, including a concrete quadratic Inspector query-tracking path. The smallest supported first correction is the proposed linear Inspector update. The data does not justify changing polling cadence, scientific work, API source verification or the benchmark.

The complete diagnostic failed: actual runner exit1, two cases passed and repeated bulk failed its profiling-fixture completeness assertion after the trace-buffer guard. The original body recorded1000 ready entries, one repeated-input hash and passed hard work order; the browser report contains no earlier body error. CPU/timeline/Network/backend records fully cover the narrower8253.4ms click-to-READY interval. This is a usable diagnostic window, not whole-capture PASS or latency qualification.

Exact changed-source entry/artifact/instance,129 atom IDs, membership hash, input hash, captured job and owner generation3 agree. The page clock maps to CDP monotonic668823.585264–668831.838664s. CPU coverage starts51.211s earlier and ends118.277s later; trace clock markers also bracket the window and the returned stream reports no data loss. The exact page frame maps to renderer4039092/main thread4039092. CDP epoch-offset spread is0.662ms; page Date-clock residuals are−0.5/−0.1ms. Sampling median is1060us and maximum active-window delta5197us. These are sampled wall distributions, not exact per-function CPU accounting.

| Covered phase | Elapsed | Main attribution |
| --- | ---: | --- |
| Click→automatic READY |8253.4ms |6306.3ms React render/commit/dispatch stacks;929.7ms existing framework DOM snapshots;85.1ms benchmark init-script stacks |
| ACK→first current-source READ |3152.6ms |2794.6ms React;130.0ms framework snapshots |
| Current READ body complete→renderer fetch reply |788.9ms |488.0ms React;150.6ms snapshots |
| Demand body complete→renderer fetch reply |1797.0ms |1557.3ms React;127.4ms snapshots |

The timeline independently shows repeated synchronous React microtask functions lasting1416.5,1559.2,1640.2 and1639.0ms. Renderer Layout union is61.3ms for the entire window and UpdateLayoutTree47.6ms; event categories overlap and must not be summed. Script3 `captureSnapshot→visitChild→visitNode` matches the installed framework DOM snapshotter. Script6 is the separate benchmark fetch/visibility observer. The benchmark instrumentation has a measured cost, but the ACK and demand gaps are predominantly application React stacks.

The Inspector component invocation/structures-memo ancestry accounts for1022.5ms, including405.3ms during ACK→READ and217.4ms after the demand body arrived. Its structures callback accounts for869.0ms. All546.1ms of sampled `trackProp` self work sits beneath that Inspector callback; the tracking proxy getter contributes about153.6ms across callers. These nested costs cannot be added. Installed `QueriesObserver` tracks each accessed result property across every query observer. The Inspector reads three distinct fields for each of1001 relevant queries, yielding quadratic tracking, and separately performs two repeated linear entry lookups inside query/result loops. Exact stacks and frozen source references are retained.

EntryRow invocation has354.3ms sampled inclusive work and ProjectBrowser240.0ms. These parent stacks do not assign the later descendant React component work to individual rows or closed menus. A broader row/menu refactor is therefore a separate decision; the linear Inspector correction already removes measured algorithmic redundancy with a smaller compatibility surface.

The apparent long HTTP waits are not server-route CPU:

| Exact new-source request | Browser fetch span | Network body | ASGI wall | Original route thread CPU |
| --- | ---: | ---: | ---: | ---: |
| First current READ |823.3ms |34.1ms |28.4ms |21.8ms |
| Demand |1840.7ms |43.6ms |35.8ms |31.5ms |
| Qualifying READY READ |32.0ms |32.1ms |25.4ms |22.0ms |

ASGI-minus-route wall is6.5/3.5/3.2ms, including profiler retention, dependencies, serialization and waits; it is not isolated serialization CPU. Backend pstats retain identity verification, JSON and database calls in tens of milliseconds. The async model-edit route has1209.2ms ASGI wall and a1,743,377-byte response; its CPU remains unattributed. Native wrapper, CDP and backend events join through unique method/path/order and calibrated timestamps, with exact source membership in native/API evidence. Their internal request IDs are separate. Fetch resolution is a headers event; a quarter-millisecond difference from body completion is not negative transport latency.

The exact successful worker turn bounds publication18.5ms after precommit bind_return. Publication precedes the qualifying READ start by1028.8–1047.3ms and the delayed demand reply by at least258.7ms. The observed timer then contributes a770.1ms reply-to-next-READ interval, including412.5ms of framework snapshot work. This does not establish an immediate-read or600ms counterfactual; reducing renderer work changes when pending replies are handled.

Proceed with memoized entriesById, memoized query options and explicit `notifyOnChangeProps: ['data', 'isError', 'isPlaceholderData']` on this Inspector observer list. Keep every relevant query, original project/entry/artifact key, signal, retry, complete-projection/coordinate-seed guard and error/placeholder rule. The three notification fields are exactly those read by the current component. This removes identified redundant lookup/tracking; no numerical speedup or5s outcome is promised.

Validate unchanged hidden-entry/selection coverage, project/artifact transitions and each data/error/placeholder transition, then the original fullALL8 and release gates. Keep all recorded misses and D148: absolute targets remain opt-in reference-host criteria, while portable scientific/state/request/work/DOM/memory/cancellation and production limits remain mandatory. No second profiling run is warranted merely because the whole-case trace guard fired.
