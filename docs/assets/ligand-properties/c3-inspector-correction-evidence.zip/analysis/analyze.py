"""Closed-file diagnostic attribution only; no app imports, SQL or workloads."""
from pathlib import Path
import collections
import hashlib
import json
import pstats
import statistics
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
CAP = ROOT/".issue-11-evidence/issue159-desktop-bulk-profile2"
RAW = CAP/"profile-raw"
CASE = ROOT/".issue-11-evidence/issue159-performance/chromium-9312fc27-316d-437c-8401-d8e50cb067d4"
def read(path):
    return json.loads(path.read_text())
def write(name, value):
    with (OUT/name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False); stream.write("\n")
def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""): h.update(block)
    return h.hexdigest()
bulk = read(CASE/"native-bulk-performance.json")
capture = read(RAW/"capture.json")
profile = read(RAW/"page.cpuprofile")
net = [json.loads(line) for line in (RAW/"network.jsonl").read_text().splitlines()]
spans = [json.loads(line) for line in (RAW/"api/spans.jsonl").read_text().splitlines()]
origin = bulk["active"]["timeOrigin"]
requests = [event for event in net if event["event"] == "request"]
offsets = [event["wallTime"]*1e6-event["timestamp"]*1e6 for event in requests]
offset = statistics.median(offsets)
def mono(page_ms): return (origin+page_ms)*1000-offset
def page(monotonic_us): return (monotonic_us+offset)/1000-origin
by_id = collections.defaultdict(list)
for event in net: by_id[event["requestId"]].append(event)
changed = bulk["changedSource"]
membership = hashlib.sha256(json.dumps(changed["atom_ids"], separators=(",", ":")).encode()).hexdigest()
source_facts = {"entry_id": changed["entry_id"], "source_artifact_id": changed["source_artifact_id"],
    "instance_id": changed["instance_id"], "atom_count": len(changed["atom_ids"]), "membership_sha256": membership}
routes = [x for x in spans if x["event"] == "synchronous_route"]
asgi = {x["request_id"]: x for x in spans if x["event"] == "ASGI"}
matches = []
for record in bulk["activeRequests"]:
    candidates = [x for x in requests if x["method"] == record["method"] and urlsplit(x["url"]).path == record["path"]
        and abs(x["wallTime"]*1000-origin-record["at"]) < 10]
    assert len(candidates) == 1, (record["at"], len(candidates))
    req = candidates[0]
    events = by_id[req["requestId"]]
    response = next((x for x in events if x["event"] == "response"), None)
    finish = next((x for x in events if x["event"] == "finished"), None)
    failed = next((x for x in events if x["event"] == "failed"), None)
    server = [x for x in asgi.values() if x["method"] == record["method"] and x["path"] == record["path"]
        and 0 <= x["start"]["epoch_ns"]/1e6-req["wallTime"]*1000 < 10]
    assert len(server) == 1, (record["at"], len(server))
    server = server[0]
    route = next((x for x in routes if x["request_id"] == server["request_id"]), None)
    row = {"native_record_at_page_ms": record["at"], "method": record["method"], "path": record["path"],
        "native_sources": record["sources"], "wrapper_finished_page_ms": record.get("finished"),
        "native_results": [{"source": x["source"], "status": x["status"], "inputHash": x["inputHash"]} for x in record.get("results", [])],
        "CDP_request_id": req["requestId"], "CDP_frame_id": req["frameId"], "CDP_loader_id": req["loaderId"],
        "CDP_request_page_ms": req["wallTime"]*1000-origin,
        "CDP_response_event_page_ms": page(response["timestamp"]*1e6) if response else None,
        "CDP_loading_finished_page_ms": page(finish["timestamp"]*1e6) if finish else None,
        "CDP_failed": failed, "CDP_response_status": response["status"] if response else None,
        "CDP_headers_page_ms": page(response["timing"]["requestTime"]*1e6 + response["timing"]["receiveHeadersEnd"]*1000) if response else None,
        "CDP_body_network_ms": (finish["timestamp"]-req["timestamp"])*1000 if finish else None,
        "CDP_renderer_response_after_body_ms": (response["timestamp"]-finish["timestamp"])*1000 if response and finish else None,
        "ASGI_request_id": server["request_id"], "ASGI_start_page_ms": server["start"]["epoch_ns"]/1e6-origin,
        "ASGI_end_page_ms": server["end"]["epoch_ns"]/1e6-origin, "ASGI_wall_ms": server["wall_ns"]/1e6,
        "ASGI_response_start_page_ms": server["response_start"]["epoch_ns"]/1e6-origin,
        "ASGI_response_bytes": server["response_bytes"], "route": route,
        "join": "Unique method/path/order and <10ms epoch start join. CDP IDs join only CDP events; ASGI IDs join only API spans/profile. No common injected request ID."}
    if route:
        row["route_matches_changed_source"] = route["source"] == source_facts
        row["route_wall_ms"] = route["wall_ns"]/1e6
        row["route_thread_CPU_ms"] = route["thread_cpu_ns"]/1e6
        row["route_retention_wall_ms"] = route["profile_retention_wall_ns"]/1e6
    matches.append(row)
new_read = next(x for x in matches if x.get("route_matches_changed_source") and x["method"] == "POST")
demand = next(x for x in matches if x.get("route_matches_changed_source") and x["method"] == "PUT")
ready_read = next(x for x in matches if any(r["status"] == "ready" and r["source"] == changed and r["inputHash"] == bulk["changedInputHash"] for r in x["native_results"]))
ack = matches[0]["wrapper_finished_page_ms"]
phases = {"click_to_READY": (bulk["active"]["started"], bulk["active"]["networkReadyAt"]),
    "click_to_ACK": (bulk["active"]["started"], ack),
    "ACK_to_current_READ": (ack, new_read["native_record_at_page_ms"]),
    "current_READ_body_network_to_renderer_response": (new_read["CDP_loading_finished_page_ms"], new_read["wrapper_finished_page_ms"]),
    "current_READ_wrapper_to_demand": (new_read["wrapper_finished_page_ms"], demand["native_record_at_page_ms"]),
    "demand_body_network_to_renderer_response": (demand["CDP_loading_finished_page_ms"], demand["wrapper_finished_page_ms"]),
    "demand_wrapper_to_READY_READ": (demand["wrapper_finished_page_ms"], ready_read["native_record_at_page_ms"])}
low, high = (mono(x) for x in phases["click_to_READY"])
assert profile["startTime"] < low < high < profile["endTime"]
assert capture["complete"] is False and capture["stopReason"] == "trace_buffer_guard"
assert capture["artifacts"][1]["tracingComplete"]["dataLossOccurred"] is False
assert bulk["hardWorkOrderStatus"] == "passed" and bulk["readyCount"] == 1000
clock_residuals = {name: {"before_residual_ms": x["dateBeforeMs"]-(x["timeOrigin"]+x["performanceNowMs"]),
    "after_residual_ms": x["dateAfterMs"]-(x["timeOrigin"]+x["performanceNowMs"])} for name, x in bulk["browserClock"].items()}
write("network-api-phase-joins.json", matches)
nodes = {n["id"]: n for n in profile["nodes"]}
parents = {child: n["id"] for n in profile["nodes"] for child in n.get("children", [])}
def frame_key(node):
    f = node["callFrame"]
    return (f["functionName"], f["url"], f["lineNumber"]+1, f["scriptId"])
stack_cache = {}
def stack(sid):
    if sid not in stack_cache:
        original_id = sid
        values = []
        while sid in nodes:
            values.append(frame_key(nodes[sid])); sid = parents.get(sid)
        stack_cache[original_id] = values
        return values
    return stack_cache[sid]
def top(counter, limit=40):
    return [{"function": key[0], "url": key[1], "line": key[2], "script_id": key[3], "sample_weighted_ms": weight/1000} for key, weight in counter.most_common(limit)]
cpu = {}
for name, (a, b) in phases.items():
    start, end = mono(a), mono(b)
    flat, inc, categories = collections.Counter(), collections.Counter(), collections.Counter()
    samples, total, cursor = 0, 0, profile["startTime"]
    for sid, dt in zip(profile["samples"], profile["timeDeltas"]):
        last = cursor; cursor += dt
        overlap = max(0, min(cursor, end)-max(last, start))
        if not overlap: continue
        frames = stack(sid); samples += 1; total += overlap; flat[frames[0]] += overlap
        for key in set(frames): inc[key] += overlap
        if any(f[0] == "captureSnapshot" and not f[1] for f in frames): category = "existing_Playwright_DOM_snapshot_stack"
        elif any(f[3] == "6" and not f[1] for f in frames): category = "existing_benchmark_init_script_stack"
        elif any("react-dom_client" in f[1] for f in frames): category = "React_render_commit_or_dispatch_stack"
        elif frames[0][0] in ("(idle)", "(program)", "(garbage collector)"): category = frames[0][0]
        else: category = "other_browser_or_application_stack"
        categories[category] += overlap
    cpu[name] = {"page_start_ms": a, "page_end_ms": b, "duration_ms": b-a,
        "samples": samples, "sample_weighted_total_ms": total/1000,
        "exclusive_stack_categories_ms": {k:v/1000 for k,v in categories.items()},
        "self_top": top(flat), "inclusive_top": top(inc,70)}
write("page-CPU-phases.json", {"scope": "Sampling-weighted intervals, not exact per-function CPU; overlapping inclusive frames must not be summed. Requested1000us sampling, all original instrumentation retained.", "profile_start_us": profile["startTime"], "profile_end_us": profile["endTime"], "sample_delta_max_us": max(profile["timeDeltas"]), "sample_delta_median_us": statistics.median(profile["timeDeltas"]), "phases": cpu})
api_profiles = []
for route in routes:
    if route["source"] != source_facts: continue
    path = RAW/"api"/route["profile"]["path"]
    assert sha(path) == route["profile"]["sha256"]
    stats = pstats.Stats(str(path))
    def functions(index):
        return [{"file": key[0], "line": key[1], "function": key[2], "primitive_calls": value[0], "calls": value[1], "self_thread_CPU_ms": value[2]*1000, "cumulative_thread_CPU_ms": value[3]*1000} for key,value in sorted(stats.stats.items(),key=lambda x:x[1][index],reverse=True)[:20]]
    api_profiles.append({"request_id": route["request_id"], "kind": route["kind"], "path": str(path), "wall_ms":route["wall_ns"]/1e6, "thread_CPU_ms":route["thread_cpu_ns"]/1e6, "pstats_total_thread_CPU_ms":stats.total_tt*1000, "calls":stats.total_calls, "cumulative_top":functions(3),"self_top":functions(2)})
write("API-new-source-pstats.json", api_profiles)
trace = read(RAW/"timeline.json")
events = trace["traceEvents"]
frame = ready_read["CDP_frame_id"]
commit = [x for x in events if x["name"] == "FrameCommittedInBrowser" and x.get("args",{}).get("data",{}).get("frame") == frame]
assert len(commit) == 1
pid = commit[0]["args"]["data"]["processId"]
names = {(x["pid"], x["tid"]):x["args"]["name"] for x in events if x["ph"] == "M" and x["name"] == "thread_name"}
tid = next(t for (p,t),name in names.items() if p == pid and name == "CrRendererMain")
main = [x for x in events if x["pid"] == pid and x["tid"] == tid and x.get("ph") == "X" and x.get("ts",0) < high and x.get("ts",0)+x.get("dur",0) > low]
def union(intervals):
    end = -1; result = 0
    for a,b in sorted(intervals):
        result += max(0,b-max(a,end)); end=max(end,b)
    return result
trace_phases = {}
for name, (a,b) in phases.items():
    start,end=mono(a),mono(b); counts=collections.Counter(); intervals=collections.defaultdict(list); long=[]
    for x in main:
        left,right=max(start,x["ts"]),min(end,x["ts"]+x.get("dur",0))
        if right<=left:continue
        counts[x["name"]]+=1;intervals[x["name"]].append((left,right))
        if x["name"] == "RunTask" and right-left >= 50000:long.append({"start_page_ms":page(x["ts"]),"end_page_ms":page(x["ts"]+x["dur"]),"clipped_wall_ms":(right-left)/1000})
    trace_phases[name]={"renderer_pid":pid,"renderer_main_tid":tid,"event_name_union_wall_ms":{key:union(value)/1000 for key,value in intervals.items()},"counts":dict(counts),"long_tasks_over50ms":long}
clock_markers=[x for x in events if x["name"] == "clock_sync"]
write("renderer-timeline-phases.json",{"scope":"Only exact page frame renderer main lane; each event-name union excludes self-nesting, but different names remain overlapping and cannot be summed as CPU.","clock_sync_markers":clock_markers,"frame_commit":commit[0],"phases":trace_phases})
selected_functions=[x for x in main if x["name"] == "FunctionCall" and x.get("dur",0)>=20000]
write("renderer-long-function-calls.json",[{"start_page_ms":page(x["ts"]),"end_page_ms":page(x["ts"]+x["dur"]),"wall_ms":x["dur"]/1000,"args":x.get("args")} for x in selected_functions])
coverage={"scope":"Covered active-edit window only; whole diagnostic remains FAILED/incomplete due trace_buffer_guard, no qualification/speedup claim", "source":changed,"input_hash":bulk["changedInputHash"],"source_membership_sha256":membership,"page_time_origin_ms":origin,"CDP_epoch_offset_median_us":offset,"CDP_epoch_offset_spread_ms":(max(offsets)-min(offsets))/1000,"browser_clock_residuals":clock_residuals,"window_page_ms":phases["click_to_READY"],"window_CDP_us":[low,high],"CPU_start_us":profile["startTime"],"CPU_end_us":profile["endTime"],"CPU_margin_before_ms":(low-profile["startTime"])/1000,"CPU_margin_after_ms":(profile["endTime"]-high)/1000,"trace_clock_markers":clock_markers,"trace_stream_complete":capture["artifacts"][1]["complete"],"trace_data_loss":False,"trace_frame_renderer_join":{"frame":frame,"pid":pid,"tid":tid},"exact_new_source_route_profiles":len(api_profiles),"network_and_API_join_method":"Unique method/path/epoch/order with full source membership for API profiles and native requests/results; separate subsystem IDs, no invented common request ID", "original_bulk_completed_facts":{"ready_count":bulk["readyCount"],"distinct_hashes":bulk["qualifiedDistinctInputHashes"],"hard_work_order_status":bulk["hardWorkOrderStatus"]},"whole_capture_complete":False,"actual_runner_exit":1,"phase_boundaries":phases}
write("coverage.json",coverage)
inputs=[CAP/"actual-enclosing-root.json",CAP/"actual-receipt.json",CAP/"transport-status.json",RAW/"capture.json",RAW/"page.cpuprofile",RAW/"network.jsonl",RAW/"timeline.json",RAW/"api/spans.jsonl",RAW/"api/status.json",CASE/"native-bulk-performance.json",CASE/"worker-observation.json",CASE/"work-order-observed.jsonl"]+[RAW/"api"/x["profile"]["path"] for x in routes]
write("input-identities.json",{"scope":"Exact retained input hashes; originals left unchanged; no SQL or application import","files":{str(p.relative_to(ROOT)):{"bytes":p.stat().st_size,"sha256":sha(p)} for p in inputs}})
print(json.dumps({"coverage":coverage,"CPU_summary":{k:{"duration_ms":v["duration_ms"],"categories_ms":v["exclusive_stack_categories_ms"]} for k,v in cpu.items()},"trace_layout_wall_ms":{k:{n:v["event_name_union_wall_ms"].get(n,0) for n in ("Layout","UpdateLayoutTree","Paint","PrePaint","RunTask","RunMicrotasks")} for k,v in trace_phases.items()}},indent=2))
