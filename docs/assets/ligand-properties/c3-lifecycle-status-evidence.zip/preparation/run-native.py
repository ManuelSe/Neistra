"""Focused lifecycle regression, isolated resources, exact source/child identity."""
from pathlib import Path
import datetime,hashlib,json,os,runpy,socket,subprocess,time
ROOT=Path.cwd();OUT=ROOT/'.issue-11-evidence/issue159-lifecycle-status-correction1'
WORK=Path('/tmp/neistra159-lifecycle-status-correction1')
assert not WORK.exists();WORK.mkdir()
helper=runpy.run_path(str(ROOT/'docs/assets/ligand-properties/qualification.py.txt'),run_name='pure_source_audit')
before=helper['current_identities'](ROOT)
(OUT/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
for port in [8340,8341,5423]:
 with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',port))!=0,port
recipe=json.loads((ROOT/'docs/assets/ligand-properties/c4-candidate2-recipe.json').read_text())
env=os.environ.copy()
for key in recipe['unset_environment']:env.pop(key,None)
env.update(recipe['environment'])
env.pop('NEISTRA_PROPERTY_WORKER_TRACE',None)
env.update({'NEISTRA_E2E_DATA_DIR':str(WORK/'e2e'),'PLAYWRIGHT_JSON_OUTPUT_FILE':str(OUT/'browser.json'),'NEISTRA_MINIMIZATION_EVIDENCE_DIR':str(WORK/'native')})
command=['corepack','pnpm','exec','playwright','test','tests/e2e/project-lifecycle.spec.ts','--reporter=list,json','--max-failures=1','--output',str(OUT/'native')]
with (OUT/'native.log').open('xb') as log:
 process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,stdin=subprocess.DEVNULL)
 raw=(Path('/proc')/str(process.pid)/'stat').read_text();v=raw[raw.rindex(')')+2:].split();actual=[x.decode() for x in (Path('/proc')/str(process.pid)/'cmdline').read_bytes().split(b'\0') if x]
 identity={'pid':process.pid,'start_token':v[19],'pgid':int(v[2]),'session':int(v[3]),'command':actual};assert identity['pgid']==identity['session']==process.pid
 launch={'scope':'Focused lifecycle only; not full qualification.','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'identity':identity,'workspace':str(WORK),'selected_source_count':len(before),'unset_environment':recipe['unset_environment'],'ports':[8340,8341,5423]}
 (OUT/'native-launch.json').write_text(json.dumps(launch,indent=2)+'\n');print(json.dumps(launch),flush=True)
 started=time.monotonic();code=process.wait()
after=helper['current_identities'](ROOT);(OUT/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
assert before==after,'Source changed during focused run'
result={'scope':'Focused lifecycle only; not full qualification.','actual_wait_returncode':code,'elapsed_seconds':time.monotonic()-started,'source_unchanged':True,'selected_source_count':len(after),'log_sha256':hashlib.sha256((OUT/'native.log').read_bytes()).hexdigest(),'original_child_identity':identity,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'native-terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(code)
