"""Positive focused-reader cleanup, followed by raw DB/sidecar copying; no SQL."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import stat
import time

OUT = Path(__file__).absolute().parent
WORKSPACE = Path('/tmp/neistra159-c5-reader-recovery1')


def fingerprint(path):
    body = path.read_bytes()
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def kernel(pid):
    try:
        text = Path(f'/proc/{pid}/stat').read_text()
        fields = text[text.rindex(')')+2:].split()
        return {'state':fields[0],'pgid':int(fields[2]),'start_token':fields[19]}
    except FileNotFoundError:
        return None


def write(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')


def main():
    execution = json.loads((OUT/'execution.json').read_bytes())
    assert execution['complete'] and execution['source_unchanged'] and len(execution['steps'])==2
    assert all(row['actual_wait_exit']==0 for row in execution['steps'])
    known = []
    groups = set()
    for step in execution['steps']:
        identity = step['identity']
        current = kernel(identity['pid'])
        same = current is not None and current['start_token']==identity['start_token'] and current['state']!='Z'
        assert not same
        groups.add(identity['pgid'])
        known.append({'recorded':identity,'current':current,'same_original_live':False})
    live = []
    marker = str(WORKSPACE).encode()
    for item in Path('/proc').glob('[0-9]*'):
        pid = int(item.name)
        current = kernel(pid)
        if current is None or current['state']=='Z':
            continue
        try:
            command = (item/'cmdline').read_bytes()
            environment = (item/'environ').read_bytes()
        except (FileNotFoundError,PermissionError,ProcessLookupError):
            continue
        if marker in command or marker in environment or current['pgid'] in groups:
            live.append({'pid':pid,**current})
    assert not live, live
    cleanup_ns = time.monotonic_ns()
    cleanup = {'recorded_utc':datetime.now(timezone.utc).isoformat(),'monotonic_ns':cleanup_ns,
        'known_coordinator_identities':known,'live_exact_workspace_or_original_groups':live,
        'complete':True,'signals_sent':False,'SQL_opened':False}
    write('cleanup-before-raw-copy.json',cleanup)
    destination = OUT/'post-cleanup-raw-bytes'
    destination.mkdir(exist_ok=False)
    started_ns = time.monotonic_ns()
    files = {}
    for source in sorted(WORKSPACE.rglob('*')):
        assert not source.is_symlink(),source
        if not source.name.lower().endswith(('.db','.sqlite','.sqlite3','-wal','-shm')):
            continue
        assert stat.S_ISREG(source.lstat().st_mode),source
        relative = source.relative_to(WORKSPACE)
        target = destination/relative
        before = fingerprint(source)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
        assert before==fingerprint(source)==fingerprint(target)
        files[relative.as_posix()]={'original':str(source),'copy':str(target),**before}
    assert files
    receipt = {'recorded_utc':datetime.now(timezone.utc).isoformat(),'cleanup_monotonic_ns':cleanup_ns,
        'started_monotonic_ns':started_ns,'cleanup_before_copy':cleanup_ns<started_ns,
        'files':files,'originals_retained':True,'SQL_opened':False,'complete':True}
    write('raw-copy-before-diagnostic-sql.json',receipt)
    print(json.dumps({'cleanup_complete':True,'original_coordinators_gone':len(known),
        'raw_original_copy_pairs':len(files),'SQL_opened':False,
        'cleanup':fingerprint(OUT/'cleanup-before-raw-copy.json'),
        'raw_copy':fingerprint(OUT/'raw-copy-before-diagnostic-sql.json')}))


if __name__=='__main__':
    main()
