"""Run two unchanged reader commands in fresh owned workspaces; not a full gate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import runpy
import subprocess
import sys

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).absolute().parent
PLAN = ROOT/'.issue-11-evidence/issue159-c5-reader-recovery-preparation1/focused-reader-commands.json'


def digest(body):
    return hashlib.sha256(body).hexdigest()


def main():
    assert digest(PLAN.read_bytes()) == '813bd14e75950cba071b13366d73bc5c0e8b6434bd64075743676f5d65fe3087'
    plan = json.loads(PLAN.read_bytes())
    assert not (OUT/'execution.json').exists()
    assert not Path('/tmp/neistra159-c5-reader-recovery1').exists()
    head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert head == '2061c55f3afc5100c242882d4a5c63dae1ee3ac7'
    qualification = runpy.run_path(str(ROOT/'docs/assets/ligand-properties/qualification.py.txt'))
    before = qualification['current_identities'](ROOT)
    record = {'scope':'Focused actual reader recovery only; never complete43 qualification',
        'candidate':head,'started_utc':datetime.now(timezone.utc).isoformat(),
        'source_before':before,'plan_sha256':digest(PLAN.read_bytes()),'steps':[],
        'complete':False,'qualification_PASS':False,'diagnostic_SQL_opened':False}
    failed = False
    for step in plan['steps']:
        print('START',step['label'],flush=True)
        env = {key:value for key,value in os.environ.items() if key not in plan['unset_environment']}
        env.update(plan['environment'])
        env.update(step.get('environment',{}))
        log = OUT/(step['label']+'.log')
        with log.open('xb') as stream:
            proc = subprocess.Popen(step['command'],cwd=step.get('cwd',str(ROOT)),env=env,
                stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            kernel = Path(f'/proc/{proc.pid}/stat').read_text()
            fields = kernel[kernel.rindex(')')+2:].split()
            identity = {'pid':proc.pid,'start_token':fields[19],'pgid':int(fields[2])}
            code = proc.wait()
        record['steps'].append({**step,'identity':identity,'actual_wait_exit':code,
            'log':str(log),'bytes':log.stat().st_size,'sha256':digest(log.read_bytes())})
        (OUT/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
        print('DONE',step['label'],code,flush=True)
        if code:
            failed = True
            break
    after = qualification['current_identities'](ROOT)
    record.update(finished_utc=datetime.now(timezone.utc).isoformat(),source_after=after,
        source_unchanged=before==after,complete=not failed and len(record['steps'])==2,
        HEAD_after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
    (OUT/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
    assert before == after and record['HEAD_after']==head
    print(json.dumps({'complete':record['complete'],'actual_exits':[s['actual_wait_exit'] for s in record['steps']],
        'source_unchanged':True,'source_count':len(before),'qualification_PASS':False}),flush=True)
    return 1 if failed else 0


if __name__=='__main__':
    sys.exit(main())
