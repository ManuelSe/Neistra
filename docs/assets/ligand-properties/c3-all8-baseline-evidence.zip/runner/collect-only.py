from pathlib import Path
import datetime,hashlib,json,runpy,subprocess,time
out=Path(__file__).resolve().parent;r=runpy.run_path(str(out/'runner.py'),run_name='preparation_collection_only')
before=r['source_audit']();env,overrides,unset=r['environment']();env['PLAYWRIGHT_JSON_OUTPUT_FILE']=str(out/'collection.json');cmd=r['command']()+['--list'];started=time.monotonic()
assert not r['WORKSPACE'].exists() and not (out/'go.json').exists()
with (out/'collection.log').open('wb') as log:result=subprocess.run(cmd,cwd=r['ROOT'],env=env,stdout=log,stderr=subprocess.STDOUT)
after=r['source_audit']();assert after==before
assert not r['WORKSPACE'].exists() and not r['owned_processes']() and all(r['ports']().values())
assert result.returncode==0
record=json.loads((out/'collection.json').read_text())
def cases(value):
 result=[]
 for spec in value.get('specs',[]):
  result +=[(test['projectName'],spec['title']) for test in spec['tests']]
 for suite in value.get('suites',[]):result+=cases(suite)
 return result
actual=cases(record);old=json.loads((out.parent/'native-probe7-all8/collection.json').read_text());assert sorted(actual)==sorted(cases(old));assert len(actual)==8 and len(set(actual))==8
receipt={'scope':'Static Playwright collection only; no services/browser/workflows/performance executed; skipped collection entries are not native skips','command':cmd,'exit_code':result.returncode,'seconds':time.monotonic()-started,'source_count':after['source_count'],'source_digest':after['source_digest'],'sources_unchanged':before==after,'workspace_exists':r['WORKSPACE'].exists(),'owned_processes':r['owned_processes'](),'ports_unused':r['ports'](),'cases':actual,'prior_prep7_case_identity_exact':True,'log_sha256':r['file_sha'](out/'collection.log'),'json_sha256':r['file_sha'](out/'collection.json')}
(out/'collection-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'collected':len(actual),'source_count':after['source_count'],'sources_unchanged':True,'workspace_created':False}))
