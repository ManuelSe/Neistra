"""Bounded private source/pin refusals and filesystem preparation; no live work."""
from pathlib import Path
from unittest.mock import patch
import copy
import hashlib
import json
import os
import runpy
import socket
import subprocess
import time

OUT=Path(__file__).resolve().parent
started=time.monotonic(); forbidden=[]; passed=[]
def blocked(*args, **kwargs):
    forbidden.append("external process/network call attempted")
    raise AssertionError(forbidden[-1])
with patch.object(subprocess,"Popen",blocked), patch.object(subprocess,"run",blocked), \
     patch.object(subprocess,"check_output",blocked), patch.object(subprocess,"call",blocked), \
     patch.object(subprocess,"check_call",blocked), patch.object(socket,"socket",blocked), \
     patch.object(socket,"create_connection",blocked), patch.object(os,"system",blocked):
    r=runpy.run_path(str(OUT/"runner.py"),run_name="bounded_static_import")
    g=runpy.run_path(str(OUT/"source_guard.py"),run_name="bounded_guard_import")
    assert not r["WORKSPACE"].exists() and not (OUT/"go.json").exists()
    before=r["source_audit"](); passed.append("real_current1125_and49_method_union_match")
    root=OUT/"guard-control-tree8";root.mkdir()
    payloads={"apps/web/src/clean.ts":b"export const ready = true;\n", "tests/support/helper.py":b"value=1\n", "package.json":b"{}\n", "docs/assets/ligand-properties/qualification.py.txt":b"# fixture\n"}
    for name,body in payloads.items():
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
    expected={n:hashlib.sha256(body).hexdigest() for n,body in payloads.items()}
    methods={"tests/support/helper.py":expected["tests/support/helper.py"]}
    assert g["audit"](root,expected,methods)["source_count"]==4
    passed.append("complete_regular_fixture_accepted")
    def refuse(label,action,restore):
        action()
        try:g["audit"](root,expected,methods)
        except (AssertionError,FileNotFoundError):passed.append(label)
        else:raise AssertionError("unexpected acceptance: "+label)
        finally:restore()
    clean=root/"apps/web/src/clean.ts"
    refuse("changed_source_refused",lambda:clean.write_bytes(b"changed"),lambda:clean.write_bytes(payloads["apps/web/src/clean.ts"]))
    extra=root/"tests/support/new.py"
    refuse("added_selected_path_refused",lambda:extra.write_bytes(b"new"),extra.unlink)
    hidden=root/"tests/support/.new-source"
    refuse("added_hidden_selected_path_refused",lambda:hidden.write_bytes(b"new"),hidden.unlink)
    refuse("missing_selected_path_refused",clean.unlink,lambda:clean.write_bytes(payloads["apps/web/src/clean.ts"]))
    outside=OUT/"guard-external-target8";outside.write_bytes(b"target")
    def link_clean():clean.unlink();clean.symlink_to(outside)
    def restore_clean():clean.unlink();clean.write_bytes(payloads["apps/web/src/clean.ts"])
    refuse("expected_file_symlink_refused",link_clean,restore_clean)
    link=root/"tests/support/link"
    refuse("extra_file_symlink_refused",lambda:link.symlink_to(outside),link.unlink)
    directory=root/"tests/linked-directory"
    refuse("directory_symlink_refused",lambda:directory.symlink_to(OUT,target_is_directory=True),directory.unlink)
    fifo=root/"tests/support/fifo"
    refuse("FIFO_refused_without_open",lambda:os.mkfifo(fifo),fifo.unlink)
    cache=root/"apps/web/node_modules/cache/file.ts";cache.parent.mkdir(parents=True);cache.write_bytes(b"generated")
    assert g["audit"](root,expected,methods)["source_count"]==4
    passed.append("existing_tool_cache_ignore_policy_preserved")
    try:g["audit"](root,expected,{"tests/support/helper.py":"0"*64})
    except AssertionError:passed.append("independent_method_digest_mismatch_refused")
    else:raise AssertionError("method drift accepted")
    def corrupt_private(label,name):
        p=OUT/name;body=p.read_bytes();p.write_bytes(body+b" ")
        try:r["pinned_inputs"]()
        except AssertionError:passed.append(label)
        else:raise AssertionError("changed private pin accepted: "+name)
        finally:p.write_bytes(body)
    for name in ("source_guard.py","canonical-root-pins.json","expected-sources.json","expected-methods.json","current-source-delta.json","fixture-controls-reuse-proof.json"):
        corrupt_private("corrupt_"+name+"_refused",name)
    globals_=r["pinned_inputs"].__globals__
    with patch.dict(globals_,{"PARENT_CANDIDATE":"0"*40}):
        try:r["pinned_inputs"]()
        except AssertionError:passed.append("actual_HEAD_mismatch_refused")
        else:raise AssertionError("HEAD mismatch accepted")
    source,method=r["pinned_inputs"]();pins=json.loads((OUT/"canonical-root-pins.json").read_text())
    checkpoint=json.loads((r["ROOT"]/pins["root_receipt"]).read_text())
    for field,value in (("checkpoint","0"*40),("clean_owned_tree",False),("source_count",1124),("method49_digest_sorted_spaced_json","0"*64)):
        bad=copy.deepcopy(checkpoint);bad[field]=value
        try:r["validate_root_qualification"](source,method,pins,bad)
        except AssertionError:passed.append("checkpoint_"+field+"_mismatch_refused")
        else:raise AssertionError("bad current checkpoint accepted")
    assert not r["owned_processes"]() and all(r["ports"]().values())
    passed.append("fresh_workspace_ports_and_positive_ownership_preconditions")
    for name in ("runner.py","source_guard.py","guard-controls.py"):compile((OUT/name).read_text(),str(OUT/name),"exec")
    passed.append("private_modules_compile_without_bytecode")
    r["prepare"]()
    assert not r["WORKSPACE"].exists() and not (OUT/"actual-receipt.json").exists() and not (OUT/"go.json").exists()
    passed.append("filesystem_preparation_does_not_launch_or_create_store")
    try:r["validate_go"]()
    except FileNotFoundError:passed.append("missing_root_GO_refused")
    else:raise AssertionError("missing GO accepted")
    read_text=Path.read_text
    def fake_go(p,*args,**kwargs):
        if p==OUT/"go.json":return json.dumps(json.loads((OUT/"go-template.json").read_text()))
        return read_text(p,*args,**kwargs)
    with patch.object(Path,"read_text",fake_go):
        try:r["validate_go"]()
        except AssertionError:passed.append("unauthorized_template_GO_refused_without_writing_GO")
        else:raise AssertionError("unauthorized GO accepted")
    assert r["source_audit"]()==before and not forbidden
    passed.append("complete_current_source_guard_unchanged_after_controls")
record={"scope":"Bounded source/pin negative controls and filesystem preparation only; no subprocess/network/services/SQL/native/performance", "all_passed":True,"checks":passed,"count":len(passed),"external_call_attempts":len(forbidden),"seconds":time.monotonic()-started,"source_count":before["source_count"],"source_digest_compact_json":before["source_digest"],"method_count":before["method_count"],"method_digest_spaced_json":before["method_digest"],"runtime_workspace_created":False,"GO_written":False}
(OUT/"guard-controls.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2))
