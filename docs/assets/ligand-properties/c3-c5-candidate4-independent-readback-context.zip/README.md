# Candidate4 independent readback — static preparation only

This kit prepares an independent root-executable readback for actual candidate
`b1cdb138c7becb5afa73b8f9bbf1e6d958ae8582`. Preparation reads only helper source
and closed JSON metadata. It does not execute postgate/readback entrypoints, query
Git, scan original roots, inspect processes, open SQL, run application tests, or
open/hash/copy any actual raw file or ZIP payload. Small synthetic in-memory ZIP
controls exercise the local integrity checker separately from actual evidence.

The primary reports actual terminal0/all43, official summary/package completion,
source capture and retained packet creation. Those actual metadata records are
bound as inputs, not substituted for this script's future original-body checks.
No readback PASS, application review readiness, merge or release claim follows
this static preparation.

## Independent checks at actual execution

`readback.py` imports only its new `archive_checks.py` plus standard libraries.
It never imports or invokes BOUND2 retention/source helpers, the portable verifier
or the archive helper. The prior C3 independent readback guides its explicit
original/source/observer comparisons. The new recursive reader independently
checks every ZIP member CRC, SHA/size manifest row, duplicate/unsafe names,
encryption/active aliases, project empty-directory declarations and nested ZIP/gzip
layers. Its evidence/project counting semantics match the existing archive format.

The retained packet's outer union must be exactly its complete original regular
files plus declared preservation metadata. Every regular member is streamed and
compared byte-for-byte against its still-closed original. The script independently
derives the exact twelve roots: entire workspace and transport, five public files,
eight selected native attachments and eight whole UUID observer directories.
It rebuilds all file/directory/empty-directory/inert alias/special metadata and
requires equality with the captured inventory. A final independent path/type/
metadata/alias rescan detects changes during the complete readback. No shared
historical parent or undeclared original tree is substituted.

Current1,133 and actual-tagged-old1,013 source bodies are checked independently
against read-only `git cat-file --batch`, each current/extracted disk body and each
captured body. The annotated v0.36.0 tag object, peeled commit and ancestry are
checked directly. Source maps must equal the actual deployed pins and gate
before/after maps. Original native12 remains7da9913b with its original be93 map;
current776 map has exactly the declared catalogue-unit and zoom-test deltas.
All52 method and789 observer subjects retain their unchanged bodies. Typed native
HEAD records remain dictionaries and retain their original ref/text identity.

The original source capsules are **not inside the retained-state ZIP**. All seven
files in `candidate-source-capture1` are a distinct sealed companion. This script
checks that directory and both capsules directly, then independently verifies the
separate source-evidence ZIP: exact seven-member union and byte equality with each
original companion file. It does not confuse that companion with retained-state,
official gate parts, historical native12 or failed forensic assets.

Every actual raw original/copy pair derives dynamically from the pinned raw-copy
receipt. Paths, complete workspace DB/WAL/SHM union, archived body/size/SHA and
actual original bodies must agree. Positive cleanup must precede copying, with
the exact terminal/cleanup/raw receipt SHA chain, monotonic ordering and no SQL.
No historical4/17/42 count is carried into C4; the closed current receipt happens
to record59 pairs, and execution derives the count again.

All eight attachment bodies must equal their original UUID report copies. Entire
original UUID trees are independently inventoried. Each observed record stream
must have the exact original worker header/source digest, byte size/SHA, original
trace slice and offset, preceding start-record anchor and contiguous record
sequence. Source-before/after maps and original trace/source identity must agree.
These checks retain actual scientific observation semantics without reinterpreting
budgets, timing, comparison methods or authored browser exclusions.

Official gate parts remain separate as well: each actual part gets independent
full recursive integrity verification, exact file fingerprint and disjoint-union
count checks against the retained provenance. Their contents are not duplicated
into the retained supplement. The script confirms all43 commands and exact
command/env/cwd vectors, plus actual official summary counts/unchanged exclusions.
It does not rerun the workload or replace the qualification-summary procedure.

## Execution barriers and command

The primary must inspect this seal and first finish its actual portable retained
verification. Keep HEAD/current selected bodies, extracted old bodies, all original
roots, official parts, source companion and retained metadata closed through this
readback. Do not execute the script against incomplete/uncreated output or alter
an original to satisfy a check. No original transport observer should append again.

After review, from the corrective checkout, use the pinned interpreter with `-B`:

```sh
.venv/bin/python -B \
  .issue-11-evidence/issue159-c5-candidate4-independent-readback-preparation1/readback.py \
  --archive .issue-11-evidence/issue159-c5-candidate4-postgate-bound2/candidate-retained-state1/qualified-c5-candidate4-retained-state.zip \
  --sha256 4307cf92b5b95fd246de658dd8fe61da0b4b6216e595c330bfb48a30198d34e2 \
  --preparation-seal-sha256 ACTUAL_PREPARATION_SEAL_SHA
```

All original counts, archive counts, observer record counts and sizes are derived
from actual bytes and compared with their closed records. The supplied SHA binds
the now-created actual packet; it is not a future placeholder or guessed outcome.
Successful completion creates this directory's `readback.json` exclusively and
prints the same actual result. Failures propagate without replacing evidence.
The script performs read-only Git operations and data reads; it writes only its
new local readback. Final all-seven acceptance, protected merge, fresh exact merged
qualification, release verification and parent closeout remain separate work.
