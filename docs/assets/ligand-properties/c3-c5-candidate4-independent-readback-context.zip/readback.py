"""Independent C4 complete original/Git/disk/capsule/raw/observer readback; no SQL."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import gzip
import hashlib
import json
import os
import stat
import subprocess
import zipfile
from archive_checks import fingerprint, recursive, safe, sha

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).absolute().parent
BOUND = ROOT / '.issue-11-evidence/issue159-c5-candidate4-postgate-bound2'
SOURCES = BOUND / 'candidate-source-capture1'
RETAINED = BOUND / 'candidate-retained-state1'
ASSETS = ROOT / 'docs/assets/ligand-properties'
WORKSPACE = Path('/tmp/neistra159-c5-candidate4')
TRANSPORT = ROOT / '.issue-11-evidence/issue159-c5-candidate4-transport1'
H = 'b1cdb138c7becb5afa73b8f9bbf1e6d958ae8582'
OLD = '247ab651b35c2d58e8939985ae50633de70311a3'
TAG_OBJECT = '05ec6685d117d000cd6c23eddfa90144b4d2a5dc'
PRIMARY = '6f22101b7f76027217844c9f3076663ac027a3bc97ca1bb23eecfa79bf5be0d9'
DB_ENDINGS = ('.db', '.sqlite', '.sqlite3', '-wal', '-shm')


def git(*args, data=None):
    return subprocess.check_output(['git', *args], cwd=ROOT, input=data)


def git_bodies(commit, mapping):
    names = sorted(mapping)
    data = git('cat-file', '--batch', data=''.join(f'{commit}:{safe(name)}\n' for name in names).encode())
    offset, result = 0, {}
    for name in names:
        end = data.index(b'\n', offset)
        _, kind, size = data[offset:end].split()
        assert kind == b'blob'
        begin = end + 1
        offset = begin + int(size)
        assert data[offset:offset + 1] == b'\n'
        body = data[begin:offset]
        assert sha(body) == mapping[name]
        result[name] = body
        offset += 1
    assert offset == len(data)
    return result


def stability(value):
    return (value.st_dev, value.st_ino, value.st_size, value.st_mode, value.st_mtime_ns,
            value.st_ctime_ns, value.st_uid, value.st_gid, value.st_nlink)


def facts(value):
    return {'mode': stat.S_IMODE(value.st_mode), 'file_type': stat.S_IFMT(value.st_mode),
            'mtime_ns': value.st_mtime_ns, 'uid': value.st_uid, 'gid': value.st_gid, 'nlink': value.st_nlink}


def roots_for_run():
    native = ASSETS / 'c5-candidate4-native'
    attachments = sorted(native.rglob('descriptor-worker-observation-*.json'))
    assert len(attachments) == 8
    directories = []
    for attachment in attachments:
        report = json.loads(attachment.read_bytes())
        order = report['work_order']
        directory = Path(order['observed_records']).parent
        assert directory.parent == ROOT / '.issue-11-evidence/issue159-performance'
        assert directory not in directories and order['trace'] == str(WORKSPACE / 'e2e/qualification/worker-turns.jsonl')
        assert report['complete'] and report['sources_unchanged'] and order['complete']
        directories.append(directory)
    names = [f'c5-candidate4-{name}.json' for name in ('recipe', 'gate', 'summary', 'reader-audit', 'packaging')]
    roots = {'workspace': (WORKSPACE, [WORKSPACE]), 'transport': (TRANSPORT, [TRANSPORT]),
             'public-bindings': (ASSETS, [ASSETS / name for name in names]),
             'observer-attachments': (native, attachments)}
    roots.update({f'observer-{index:02d}': (directory, [directory]) for index, directory in enumerate(sorted(directories), 1)})
    return roots


def compare_originals(archive, inv, roots):
    files, directories, empty, aliases, special, watches = {}, {}, [], [], [], {}

    def visit(label, root, path):
        value = path.lstat()
        relative = path.relative_to(root).as_posix()
        name = label if relative == '.' else label + '/' + relative
        metadata = facts(value)
        watches[str(path)] = (stability(value), os.readlink(path) if stat.S_ISLNK(value.st_mode) else None)
        if stat.S_ISLNK(value.st_mode):
            aliases.append({'path': name, 'original_path': str(path), 'target': os.readlink(path), 'active': False, 'metadata': metadata})
        elif stat.S_ISDIR(value.st_mode):
            directories[name] = metadata
            children = sorted(path.iterdir())
            if not children:
                empty.append(name)
            for child in children:
                visit(label, root, child)
        elif stat.S_ISREG(value.st_mode):
            assert name in inv['files'] and path.name != 'PRODUCT_SPEC.md'
            if label.startswith('observer-'):
                assert not path.name.lower().endswith(DB_ENDINGS), 'Unexpected observer store; stop before SQL'
            digest, size = hashlib.sha256(), 0
            with path.open('rb') as original, archive.open(name) as retained:
                while True:
                    a, b = original.read(1048576), retained.read(1048576)
                    assert a == b, name
                    if not a:
                        break
                    size += len(a)
                    digest.update(a)
            assert stability(path.lstat()) == stability(value)
            files[name] = {'original_path': str(path), 'bytes': size, 'sha256': digest.hexdigest(), 'metadata': metadata}
            assert files[name] == inv['files'][name]
        else:
            special.append({'path': name, 'original_path': str(path), 'active': False, 'opened': False, 'metadata': metadata})
    assert set(roots) == set(inv['roots'])
    for label, (root, selected) in roots.items():
        row = inv['roots'][label]
        assert root.is_dir() and not root.is_symlink()
        assert str(root) == row['original_root'] and list(map(str, selected)) == row['selected_paths']
        for path in selected:
            visit(label, root, path)
        chosen = [value for name, value in files.items() if name.startswith(label + '/')]
        assert row['regular_files'] == len(chosen) and row['bytes'] == sum(value['bytes'] for value in chosen)
    assert files == inv['files'] and directories == inv['directories']
    assert sorted(empty) == inv['empty_directories']
    assert sorted(aliases, key=lambda row: row['path']) == inv['inert_aliases']
    assert sorted(special, key=lambda row: row['path']) == inv['inert_nonregular_descriptors']
    return watches


def recheck_metadata(roots, watches):
    actual = {}
    def visit(path):
        value = path.lstat()
        actual[str(path)] = (stability(value), os.readlink(path) if stat.S_ISLNK(value.st_mode) else None)
        if stat.S_ISDIR(value.st_mode):
            for child in sorted(path.iterdir()):
                visit(child)
    for _, selected in roots.values():
        for path in selected:
            visit(path)
    assert actual == watches, 'Original path/kind/metadata/link union changed during readback'


def source_capsules(pins, gate, reference):
    source_watches = {}
    for path in SOURCES.iterdir():
        assert path.is_file() and not path.is_symlink()
        source_watches[str(path)] = stability(path.lstat())
    capsule_manifest = json.loads((SOURCES / 'source-capsule-manifest.json').read_bytes())
    assert capsule_manifest['candidate'] == H
    assert set(path.name for path in SOURCES.iterdir()) == set(capsule_manifest['files']) | {'source-capsule-manifest.json'}
    for name, row in capsule_manifest['files'].items():
        assert fingerprint(SOURCES / safe(name)) == row
    seal = json.loads((SOURCES / 'source-capture-seal.json').read_bytes())
    maps = json.loads((SOURCES / 'captured-source-maps.json').read_bytes())
    bindings = json.loads((SOURCES / 'source-bindings.json').read_bytes())
    assert seal['candidate'] == bindings['candidate'] == H and seal['source_capture_complete']
    assert fingerprint(SOURCES / seal['map_file']['file']) == {key: seal['map_file'][key] for key in ('bytes', 'sha256')}
    assert fingerprint(SOURCES / seal['bindings_file']['file']) == {key: seal['bindings_file'][key] for key in ('bytes', 'sha256')}
    assert maps['current'] == pins['selected_sources'] == gate['source_before'] == gate['source_after']
    assert maps['actual036'] == pins['preceding_sources'] == gate['preceding_source_before'] == gate['preceding_source_after'] == gate['preceding_source_expected']
    assert len(maps['current']) == 1133 and len(maps['actual036']) == 1013
    assert git('cat-file', '-t', 'v0.36.0').decode().strip() == 'tag'
    assert git('rev-parse', 'v0.36.0').decode().strip() == TAG_OBJECT
    assert git('rev-parse', 'v0.36.0^{}').decode().strip() == OLD
    subprocess.check_call(['git', 'merge-base', '--is-ancestor', OLD, H], cwd=ROOT)
    assert bindings['preceding_annotated_tag'] == {'tag': 'v0.36.0', 'object_type': 'tag', 'tag_object': TAG_OBJECT, 'peeled_commit': OLD}
    result = {}
    for label, commit, disk in [('current', H, ROOT), ('actual036', OLD, Path(gate['preceding_reader']['root']))]:
        capture = seal['captures'][label]
        assert capture['commit'] == commit and capture['source_count'] == len(maps[label])
        path = SOURCES / safe(capture['file'])
        assert fingerprint(path) == {key: capture[key] for key in ('bytes', 'sha256')}
        bodies = git_bodies(commit, maps[label])
        with zipfile.ZipFile(path) as capsule:
            names = capsule.namelist()
            assert len(names) == len(set(names)) == len(bodies) and set(names) == set(bodies)
            for name, body in bodies.items():
                info = capsule.getinfo(name)
                assert not info.is_dir() and not stat.S_ISLNK(info.external_attr >> 16) and not info.flag_bits & 1
                original = disk / safe(name)
                assert original.is_file() and not original.is_symlink()
                before = stability(original.lstat())
                source_watches[str(original)] = before
                assert capsule.read(name) == body == original.read_bytes()
                assert stability(original.lstat()) == before
        result[label] = {'commit': commit, 'source_count': len(bodies), **fingerprint(path)}
    native = reference['native12']
    actual = {name: {'before': native['source_map'][name], 'after': digest}
              for name, digest in maps['current'].items() if digest != native['source_map'][name]}
    assert set(native['source_map']) == set(maps['current'])
    assert actual == reference['source_model']['declared_delta'] == bindings['source_model']['declared_delta']
    assert actual == {
        'tests/e2e/rebranding-zoom.spec.ts': {'before': '5002451820458969f3da28ba6aceaa0a6cdb9753040e33745b632663f610c0bd', 'after': '75ed41b0e75e67cd92a3056311fc98785e0414ee6576aec0abe0e4bb24a19eb0'},
        'tests/unit/test_ligand_properties_release_recipe.py': {'before': 'fa019dffc96a972c56f18197728874eccfde426ea956f99bf2280757b25f783a', 'after': '9947c6b75171656d92578edc6a3dd624396d9520950daeef945558e657e2cce9'}}
    assert sha(json.dumps(maps['current'], sort_keys=True, separators=(',', ':')).encode()) == '776cd8d21daf6dfd605b741bbab825423f1568deb1f20d624b45a8de646f5eec'
    assert sha(json.dumps(native['source_map'], sort_keys=True, separators=(',', ':')).encode()) == 'be93fda78fdb9b16b400006b8ae20617087b4e72014b2554cdd29b9fd45111e7'
    assert native['original_candidate'] == '7da9913bcf4630f1f4ffbfa2af3eeffc7ff9705c'
    for key, count in [('method_map', 52), ('observer_source_map', 789)]:
        assert len(native[key]) == count and not set(actual).intersection(native[key])
        assert all(maps['current'][name] == native['source_map'][name] == digest for name, digest in native[key].items())
    before = native['runtime']['authoritative_HEAD_before']
    after = native['runtime']['authoritative_HEAD_after']
    assert isinstance(before, dict) and before == after
    assert native['original_candidate'] == native['primary']['candidate'] == native['runtime']['binding']['HEAD'] == before['commit'] == native['assessment']['candidate'] == native['canonical_pins']['HEAD']
    assert before['ref'] == native['canonical_pins']['ref'] and before['HEAD_text'] == 'ref: ' + before['ref']
    return maps, result, source_watches


def source_publication(inputs):
    value = inputs['source_publication']
    assert value['candidate'] == H and value['source_directory'] == str(SOURCES)
    path = Path(value['archive']['path'])
    assert fingerprint(path) == {key: value['archive'][key] for key in ('bytes', 'sha256')}
    counts = recursive(path, path.name)
    assert counts == value['archive']['verification_counts']
    originals = {file.name: fingerprint(file) for file in SOURCES.iterdir()}
    assert len(originals) == 7 and originals == value['original_files']
    with zipfile.ZipFile(path) as archive:
        manifest = json.loads(archive.read('manifest.json'))
        assert manifest == originals and set(archive.namelist()) == set(originals) | {'manifest.json'}
        for name in originals:
            assert archive.read(name) == (SOURCES / name).read_bytes()
    assert fingerprint(path) == {key: value['archive'][key] for key in ('bytes', 'sha256')}
    return {'archive': fingerprint(path), 'complete_companion_files': len(originals),
            'recursive_counts': counts, 'all_seven_original_companion_bytes_and_union_exact': True}


def observer_mirrors(archive, inv, provenance, maps, reference, roots):
    trace = archive.read('workspace/e2e/qualification/worker-turns.jsonl')
    trace_sources = json.loads(archive.read('workspace/e2e/qualification/worker-turns.sources.json'))
    assert trace_sources == reference['native12']['observer_source_map']
    assert all(maps['current'][name] == digest for name, digest in trace_sources.items())
    header_end = trace.index(b'\n') + 1
    header_body, header = trace[:header_end], json.loads(trace[:header_end])
    assert header['source_count'] == len(trace_sources)
    assert header['source_digest'] == sha(json.dumps(trace_sources, sort_keys=True, separators=(',', ':')).encode())
    bindings = provenance['all_original_observer_bindings']
    assert len(bindings) == len({row['original_root'] for row in bindings}) == 8
    assert {row['original_root'] for row in bindings} == {str(root) for label, (root, _) in roots.items() if label.startswith('observer-') and label != 'observer-attachments'}
    results = []
    for row in bindings:
        attachment = archive.read(row['native_member'])
        assert attachment == archive.read(row['original_report_member'])
        assert {'bytes': len(attachment), 'sha256': sha(attachment)} == row['report_bytes']
        report = json.loads(attachment)
        order = report['work_order']
        assert report['complete'] and report['sources_unchanged'] and order['complete']
        assert report['sources_before'] == report['sources_after'] == trace_sources
        assert order['header'] == header and order['trace'] == str(WORKSPACE / 'e2e/qualification/worker-turns.jsonl')
        assert Path(order['observed_records']).parent == Path(row['original_root'])
        assert inv['files'][row['original_records_member']]['original_path'] == order['observed_records']
        observed = archive.read(row['original_records_member'])
        assert {'bytes': len(observed), 'sha256': sha(observed)} == row['observed_records_bytes']
        assert len(observed) == order['observed_bytes'] and sha(observed) == order['observed_sha256']
        assert observed.startswith(header_body)
        mirror, offset = observed[header_end:], order['source_start_offset']
        assert trace[offset - 1:offset] == b'\n' and trace[offset:offset + len(mirror)] == mirror
        previous = json.loads(trace[trace.rfind(b'\n', 0, offset - 1) + 1:offset - 1])
        assert previous['record'] == order['start_record']
        lines = mirror.splitlines()
        assert len(lines) == order['records'] == order['last_record'] - order['start_record']
        assert [json.loads(line)['record'] for line in lines] == list(range(order['start_record'] + 1, order['last_record'] + 1))
        checks = {'records': len(lines), 'first_record': order['start_record'] + 1,
                  'last_record': order['last_record'], 'source_start_offset': offset}
        assert checks == row['trace_checks']
        assert row['original_regular_files'] == inv['roots'][row['inventory_label']]['regular_files']
        results.append({'original_root': row['original_root'], **checks})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', required=True, type=Path)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--preparation-seal-sha256', required=True)
    args = parser.parse_args()
    assert not (OUT / 'readback.json').exists()
    assert fingerprint(OUT / 'preparation-seal.json')['sha256'] == args.preparation_seal_sha256
    for row in json.loads((OUT / 'preparation-seal.json').read_bytes())['files']:
        assert fingerprint(OUT / row['path']) == {key: row[key] for key in ('bytes', 'sha256')}
    inputs = json.loads((OUT / 'input-bindings.json').read_bytes())
    for row in inputs['closed_metadata']:
        assert fingerprint(Path(row['path'])) == {key: row[key] for key in ('bytes', 'sha256')}
    assert git('rev-parse', 'HEAD').decode().strip() == H
    packet = fingerprint(args.archive)
    assert packet['sha256'] == args.sha256 == inputs['retained_archive']['sha256']
    assert packet['bytes'] == inputs['retained_archive']['bytes']
    counts = recursive(args.archive, args.archive.name)
    with zipfile.ZipFile(args.archive) as archive:
        manifest = json.loads(archive.read('manifest.json'))
        inv = json.loads(archive.read('preservation/input-inventory.json'))
        context = json.loads(archive.read('preservation/context.json'))
        provenance = json.loads(archive.read('preservation/provenance.json'))
        seal = json.loads(archive.read('preservation/input-seal.json'))
        reference = json.loads(archive.read('preservation/preparation-input-bindings.json'))
        expected = set(inv['files']) | {'preservation/' + name for name in context['metadata_members']}
        assert set(manifest) == expected and set(archive.namelist()) == expected | {'manifest.json'}
        assert inv['body_exclusions'] == inv['missing_roots'] == context['body_exclusions'] == []
        assert context['candidate'] == provenance['candidate'] == seal['candidate'] == H
        assert context['candidate_gate_PASS'] and context['gate_command_exits_zero'] == 43
        assert not context['final_all7_merge_master_release_complete'] and not context['separate_failed_forensic_asset']
        for name, row in inv['files'].items():
            assert manifest[name] == {key: row[key] for key in ('bytes', 'sha256')}
        for name, field in [('input-inventory.json', 'original_closed_input_inventory'), ('provenance.json', 'provenance'), ('context.json', 'context')]:
            assert manifest['preservation/' + name] == seal[field]
            assert archive.read('preservation/' + name) == (RETAINED / name).read_bytes()
        assert inv == json.loads((RETAINED / 'originals-after.json').read_bytes())
        roots = roots_for_run()
        watches = compare_originals(archive, inv, roots)
        gate = json.loads(archive.read('public-bindings/c5-candidate4-gate.json'))
        recipe = json.loads(archive.read('public-bindings/c5-candidate4-recipe.json'))
        summary = json.loads(archive.read('public-bindings/c5-candidate4-summary.json'))
        primary_body = archive.read('transport/primary-terminal-readback.json')
        assert sha(primary_body) == provenance['primary_terminal_proof']['sha256'] == PRIMARY
        primary = json.loads(primary_body)
        assert primary['candidate'] == H and primary['actual_runner_wait_exit'] == 0 and primary['original_transport_identity_complete']
        assert primary['recorded_steps'] == 43 and primary['remaining_unrun_steps'] == 0 and primary['gate_complete']
        assert gate['commit'] == summary['commit'] == H and gate['complete']
        assert len(gate['steps']) == len(recipe['steps']) == summary['complete_steps'] == 43
        assert all(row['exit_code'] == 0 for row in gate['steps'])
        for actual, declared_step in zip(gate['steps'], recipe['steps'], strict=True):
            assert all(actual.get(key) == declared_step.get(key) for key in ('label', 'command', 'environment', 'cwd'))
        assert summary['python'] == 3598 and summary['frontend'] == 1599 and summary['supervisor'] == 14
        assert summary['browser_passed'] == 565 and summary['browser_exclusions'] == 75 and summary['browser_inventory_count'] == 640
        assert summary['python_skips'] == summary['new_exclusions'] == summary['failures_flakes_retries'] == 0
        assert summary['complete_browser_inventory_executed'] and summary['existing_exclusion_identities_unchanged']
        pins = json.loads(archive.read('transport/pins.json'))
        assert pins['head'] == H and sha(archive.read('transport/pins.json')) == reference['gate']['pins_bytes']['sha256']
        maps, captured, source_watches = source_capsules(pins, gate, reference)
        assert summary['source_digest'] == sha(json.dumps(maps['current'], sort_keys=True).encode())
        raw_body = archive.read('transport/raw-database-copy.json')
        cleanup_body = archive.read('transport/cleanup-before-raw-copy.json')
        assert sha(raw_body) == primary['raw_copy_receipt']['sha256'] == provenance['preSQL_raw_copy_receipt']['sha256']
        assert sha(cleanup_body) == primary['positive_cleanup_receipt']['sha256'] == provenance['positive_cleanup']['sha256']
        raw = json.loads(raw_body)
        cleanup = json.loads(cleanup_body)
        assert cleanup['complete'] and not cleanup['positively_owned_processes_remaining'] and not cleanup['live_exact_workspace_data_markers']
        assert cleanup['ports_unused'] and all(cleanup['ports_unused'].values()) and cleanup['signals_sent'] is False
        assert raw['cleanup_before_copy'] and raw['originals_retained'] and raw['workspace'] == str(WORKSPACE)
        assert raw['cleanup_monotonic_ns'] == cleanup['monotonic_ns'] < raw['started_monotonic_ns']
        assert raw['SQL_opened'] is cleanup['SQL_opened'] is primary['SQL_opened'] is False
        assert raw['files'] == provenance['raw_original_copy_bindings']
        actual_stores = {name.removeprefix('workspace/') for name in inv['files'] if name.startswith('workspace/') and name.lower().endswith(DB_ENDINGS)}
        assert actual_stores == set(raw['files'])
        for relative, row in raw['files'].items():
            expected_raw = {key: row[key] for key in ('bytes', 'sha256')}
            original = 'workspace/' + safe(relative)
            copy = 'transport/post-cleanup-raw-database-bytes/' + relative
            assert row['original'] == str(WORKSPACE / relative) and row['copy'] == str(TRANSPORT / 'post-cleanup-raw-database-bytes' / relative)
            assert manifest[original] == manifest[copy] == expected_raw
            assert archive.read(original) == archive.read(copy)
        assert len(raw['files']) == context['raw_original_copy_pairs'] == provenance['raw_original_copy_pairs_verified'] == seal['raw_original_copy_pairs_verified']
        mirrors = observer_mirrors(archive, inv, provenance, maps, reference, roots)
        official = json.loads(archive.read('public-bindings/c5-candidate4-packaging.json'))
        assert official['qualified_commit'] == H and official['archives'] == provenance['official_gate_parts_not_duplicated']
        official_union, official_locations, part_counts = {}, {}, []
        for part in official['archives']:
            path = Path(part['path'])
            assert path.parent == ASSETS and path.name == part['file'] and part['bytes'] < 95 * 1024 * 1024
            assert fingerprint(path) == {key: part[key] for key in ('bytes', 'sha256')}
            checked = recursive(path, path.name)
            assert checked == part['verification_counts']
            with zipfile.ZipFile(path) as bundle:
                entries = json.loads(bundle.read('manifest.json'))
                assert not set(entries).intersection(official_union)
                official_union.update(entries)
                official_locations.update({name: path for name in entries})
            assert fingerprint(path) == {key: part[key] for key in ('bytes', 'sha256')}
            part_counts.append(checked)
        assert len(official_union) == provenance['official_exact_disjoint_union_members']
        for step in gate['steps']:
            log = ROOT / step['log']
            assert log.parent == ASSETS
            member = 'gate/' + log.name
            with zipfile.ZipFile(official_locations[member]) as bundle:
                body = gzip.decompress(bundle.read(member))
            primary_log = primary['all_lossless_gzip_log_bodies_verified'][step['label']]
            assert sha(body) == step['log_sha256'] == primary_log['sha256']
            assert len(body) == primary_log['bytes'] and primary_log['exit_code'] == 0
        companion = source_publication(inputs)
        recheck_metadata(roots, watches)
        assert all(stability(Path(path).lstat()) == value for path, value in source_watches.items())
    verification = json.loads((RETAINED / 'verification.json').read_bytes())
    assert counts == verification['archive']['verification_counts']
    assert len(inv['files']) == verification['original_files'] and len(inv['empty_directories']) == verification['empty_directories']
    assert sum(row['bytes'] for row in inv['files'].values()) == verification['original_bytes']
    assert len(raw['files']) == verification['raw_original_copy_pairs_verified_before_and_after']
    assert sum(row['original_regular_files'] for row in provenance['all_original_observer_bindings']) == context['original_observer_regular_files'] == verification['original_observer_regular_files']
    assert fingerprint(args.archive) == packet and git('rev-parse', 'HEAD').decode().strip() == H
    result = {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'candidate': H,
              'scope': 'Independent complete C4 candidate original/source/raw/observer/archive readback; not final-seven/merge/release readiness',
              'archive': packet, 'independent_recursive_counts': counts, 'outer_manifest_members': len(manifest),
              'original_roots': len(roots), 'original_files': len(inv['files']), 'original_bytes': verification['original_bytes'],
              'empty_directories': len(inv['empty_directories']), 'inert_aliases': len(inv['inert_aliases']),
              'all_original_bodies_metadata_and_exact_union': True, 'final_original_path_metadata_alias_union_rechecked': True,
              'source_capsules': captured, 'actual_Git_disk_capsule_bodies': sum(len(value) for value in maps.values()),
              'separate_public_source_companion': companion,
              'raw_original_copy_pairs': len(raw['files']), 'original_observer_roots': len(mirrors),
              'original_observer_files': sum(row['original_regular_files'] for row in provenance['all_original_observer_bindings']),
              'all8_observer_original_attachment_source_and_exact_trace_mirrors': mirrors,
              'official_disjoint_union_members': len(official_union), 'official_part_recursive_counts': part_counts,
              'portable_verifier_or_postgate_helpers_imported_or_executed': False,
              'SQL_opened': False, 'final_all7_merge_master_release_complete': False}
    with (OUT / 'readback.json').open('x') as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
