"""Independent evidence/project ZIP integrity; no retention-helper imports."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import stat
import zipfile


def sha(body):
    return hashlib.sha256(body).hexdigest()


def safe(name):
    assert isinstance(name, str) and name and '\\' not in name and '\x00' not in name
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and str(path) == name
    return name


def fingerprint(path):
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            size += len(block)
            digest.update(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def declared(manifest, names):
    assert isinstance(manifest, dict)
    rows = manifest.get('files', manifest)
    project = manifest.get('schema_version') in (2, 3) and isinstance(rows, list)
    if isinstance(rows, list):
        assert all(isinstance(row, dict) and 'path' in row for row in rows)
        members = {row['path']: row for row in rows}
        assert len(members) == len(rows)
    else:
        assert isinstance(rows, dict)
        members = rows
    empty = manifest.get('empty_directories', []) if 'files' in manifest else []
    assert isinstance(empty, list) and all(isinstance(name, str) for name in empty)
    assert len(empty) == len(set(empty)) and not {'.', 'manifest.json'}.intersection(empty)
    assert not set(members).intersection(empty)
    directories = {safe(name) + '/' for name in empty}
    assert set(names) == set(members) | directories | {'manifest.json'}
    parents = {str(parent) for name in names for parent in PurePosixPath(name).parents}
    assert not (set(members) | set(empty) | {'manifest.json'}).intersection(parents)
    for name in members:
        safe(name)
    return members, directories, project


def recursive(source, name, depth=0):
    """Read every member through CRC verification, then independently validate manifests."""
    assert depth < 16, name
    if isinstance(source, Path):
        with source.open('rb') as stream:
            prefix = stream.read(4)
    else:
        prefix = source[:4]
    counts = {'zip_archives': 0, 'evidence_manifest_entries': 0, 'project_archive_files': 0}
    if prefix.startswith(b'\x1f\x8b'):
        body = source.read_bytes() if isinstance(source, Path) else source
        return recursive(gzip.decompress(body), name + '!gunzip', depth + 1)
    if prefix not in (b'PK\x03\x04', b'PK\x05\x06', b'PK\x07\x08'):
        return counts
    with zipfile.ZipFile(source if isinstance(source, Path) else io.BytesIO(source)) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)), name
        infos = archive.infolist()
        assert all(not row.flag_bits & 1 and not stat.S_ISLNK(row.external_attr >> 16) for row in infos)
        counts['zip_archives'] = 1
        members, directories, project = {}, set(), False
        if 'manifest.json' in names:
            members, directories, project = declared(json.loads(archive.read('manifest.json')), names)
            counts['project_archive_files' if project else 'evidence_manifest_entries'] = len(members)
        for info in infos:
            member = info.filename
            if info.is_dir():
                safe(member[:-1])
            else:
                safe(member)
            body = archive.read(member)  # ZipFile checks the actual CRC on full read.
            if member in directories:
                assert info.is_dir() and stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFDIR)
                assert info.file_size == 0 and body == b''
            if member in members:
                assert not info.is_dir() and stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG)
                expected = members[member]
                digest = expected if isinstance(expected, str) else expected['sha256']
                assert re.fullmatch('[a-f0-9]{64}', digest) and sha(body) == digest
                if isinstance(expected, dict):
                    size = expected.get('bytes', expected.get('size'))
                    assert size is not None and len(body) == size
            if not info.is_dir():
                nested = recursive(body, name + '!' + member, depth + 1)
                for key, value in nested.items():
                    counts[key] += value
    return counts
