# Private declared-directory manifest correction

Ready for primary and architecture review. No public source was changed.

Future integration replaces exactly `docs/assets/ligand-properties/release-evidence.py.txt` and `tests/unit/test_ligand_properties_release_recipe.py` with the same-named files in this folder, or applies `future-public-change.patch`. Root owns integration only after resolving the current source freeze and preserving the original gate outcome.

Only `check_manifest` changes. All other25 helper function ASTs remain identical. Every existing test byte remains an exact prefix; new tests cover two real retained archives, valid flat/project manifests and31 independent malformed directory/file conditions. Unsafe-path fixtures deliberately keep the ZIP and manifest names aligned so rejection checks path policy rather than an incidental missing member.

Final helper SHA256: `368454a07a513cb57b06e0134886082cd560cff38828655bdfc29a4fc09231ba`.
Final public test SHA256: `fa019dffc96a972c56f18197728874eccfde426ea956f99bf2280757b25f783a`.
Patch SHA256: `0768b6cf36e73ce737dc56cf7ffbd5cfaa731c73e598017888e2fcd9b999f2d2`.

Actual final offline pytest:89passed, exit0, `cf7454`→`947fba`; all52old controls plus37new. The private execution copy changes only the loader to select the corrected private helper; future public test bytes are otherwise preserved separately. Final Ruff/format exit0. Original helper reproductions retain exit1 for both valid legacy packets.

Corrected full recursive verification of ALL10 publicC1/C2/C3 ZIPs exits0 (`6e79b2`→`2269a7`), with every original archive hash unchanged before/after. Total compressed bytes:152533886; elapsed7.0314seconds on this shared host. Reader-clock recursively verifies810ZIPs/386evidence/1822project files; baseline15/4817/20; current remeasurement15/4909/20. These are artifact integrity results, not application timing or release acceptance.

All1130current selected source bodies still match the frozen native11 map. The two proposed changed files are selected sources but outside all51 runtime method subjects. The predicted integrated map digest is `144d1784239f3585ef386619307f1d6209ddbe94f69f343963d2453127a71650`; it is NOT a claim of current integration. Root must recompute actual identities after integration. Preserve native11's historical source identity, all old ZIP bytes and all timing/failure distinctions.

No apps, scientific runtime, SQL, signals, Git mutations, publication or subagents were used. Only isolated pure offline pytest/static/checksum/ZIP verification subprocesses ran. Rawlogs/actual exit receipts, before snapshots, exact patch and source proofs are retained here. Final source proof supersedes the initial proof's earlier test hash; helper bytes never changed after initial successful validation.
