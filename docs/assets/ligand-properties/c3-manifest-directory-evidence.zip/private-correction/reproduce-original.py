from pathlib import Path
import runpy,sys
root=Path.cwd()
helper=runpy.run_path(str(root/'.issue-11-evidence/issue159-manifest-directory-correction1/public-before-release-evidence.py.txt'))
path=root/'docs/assets/ligand-properties'/sys.argv[1]
helper['verify_layers'](path,path.name)
