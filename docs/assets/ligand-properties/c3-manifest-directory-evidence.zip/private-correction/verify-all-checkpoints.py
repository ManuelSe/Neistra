from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import runpy
import time

ROOT=Path.cwd()
OUT=ROOT/'.issue-11-evidence/issue159-manifest-directory-correction1'
ASSETS=ROOT/'docs/assets/ligand-properties'

def fingerprint(path):
    digest=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block);size+=len(block)
    return {'bytes':size,'sha256':digest.hexdigest()}

helper=runpy.run_path(str(OUT/'release-evidence.py.txt'))
paths=sorted(ASSETS.glob('c[123]-*.zip'))
assert {'c3-reader-clock-evidence.zip','c3-all8-baseline-evidence.zip'} <= {p.name for p in paths}
records=[]
started=time.monotonic()
for path in paths:
    before=fingerprint(path)
    begin=time.monotonic()
    counts=helper['verify_layers'](path,path.name)
    assert fingerprint(path)==before
    row={'path':str(path.relative_to(ROOT)),**before,'recursive_verification':counts,
         'all_recursive_manifest_bodies_CRC_and_exact_union_verified':True,
         'original_bytes_unchanged':True,'seconds':round(time.monotonic()-begin,6)}
    records.append(row)
    print(json.dumps(row),flush=True)
report={'scope':'Full corrected recursive verification of every immutable public C1/C2/C3 ZIP; not application qualification',
        'recorded_utc':datetime.now(timezone.utc).isoformat(),'helper_sha256':fingerprint(OUT/'release-evidence.py.txt')['sha256'],
        'packets':records,'packet_count':len(records),'total_compressed_bytes':sum(r['bytes'] for r in records),
        'elapsed_seconds':round(time.monotonic()-started,6),'SQL_apps_services_tests_or_chemistry_executed':False}
with (OUT/'all-checkpoint-verification.json').open('x') as handle:
    json.dump(report,handle,indent=2);handle.write('\n')
print(json.dumps({'packet_count':len(records),'all_passed':True,'elapsed_seconds':report['elapsed_seconds']}),flush=True)
