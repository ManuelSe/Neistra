"""Standalone portable verification; --originals additionally rehashes closed roots."""
from pathlib import Path
import argparse
import json
import zipfile
from support import HELPER_SHA, ROOTS, fingerprint, helpers, inventory, sha
from validate import validate


def verify_archive(path, originals=False):
    recursive = helpers()['verify_layers'](path, path.name)
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and archive.testzip() is None
        manifest = json.loads(archive.read('manifest.json'))
        inv = json.loads(archive.read('preservation/input-inventory.json'))
        after = json.loads(archive.read('preservation/originals-after-capture.json'))
        capture = json.loads(archive.read('preservation/capture-result.json'))
        meta = json.loads(archive.read('preservation/archive-metadata.json'))
        assert inv == after
        assert not inv['body_exclusions'] and not inv['missing_roots'] and not meta['body_exclusions']
        expected = set(inv['files']) | {'preservation/' + name for name in meta['metadata_members']}
        assert set(manifest) == expected and set(names) == expected | {'manifest.json'}
        assert manifest['preservation/release-evidence-used.py.txt']['sha256'] == HELPER_SHA
        for name, row in inv['files'].items():
            assert manifest[name] == {key: row[key] for key in ('bytes', 'sha256')}
        assert inv['roots'] == {label: str(root) for label, root in ROOTS.items()}
        assert len(inv['files']) == len({row['original_path'] for row in inv['files'].values()})
        for label, original in inv['roots'].items():
            assert label in inv['directories'] and inv['directories'][label]['original_path'] == original
        assert all(row['active'] is False and isinstance(row['target'], str) for row in inv['inert_aliases'])
        assert all(row['active'] is row['opened'] is False for row in inv['inert_special_descriptors'])
        for name, field in [('input-inventory.json', 'input_inventory'), ('originals-after-capture.json', 'originals_after_capture'),
                            ('capture-result.json', 'capture_result')]:
            assert manifest['preservation/' + name] == meta[field]
        seal_bytes = archive.read('preservation/preparation-seal.json')
        assert sha(seal_bytes) == capture['preparation_seal_sha256'] == meta['preparation_seal_sha256']
        seal = json.loads(seal_bytes)
        for row in seal['files']:
            assert manifest['preservation/' + row['path']] == {key: row[key] for key in ('bytes', 'sha256')}

        def get(name):
            assert name in inv['files']
            body = archive.read(name)
            assert {'bytes': len(body), 'sha256': sha(body)} == {key: inv['files'][name][key] for key in ('bytes', 'sha256')}
            return body

        assessment = validate(get, inv)
        assert assessment == capture['assessment']
        assert capture['original_files'] == len(inv['files'])
        assert capture['original_bytes'] == sum(row['bytes'] for row in inv['files'].values())
        assert capture['original_empty_directories'] == len(inv['empty_directories'])
        assert capture['original_inert_aliases'] == len(inv['inert_aliases'])
        assert capture['complete_originals_before_after_capture_exact'] and capture['all_originals_retained_in_place']
        assert capture['SQL_opened'] is meta['SQL_opened'] is False
        assert not meta['final_feature_release_qualification'] and not meta['publication_complete']
        if originals:
            assert inventory() == inv, 'Current complete closed-original union/body/metadata changed'
    return {'scope': 'Complete focused readiness evidence only; no full43, merged, final feature or release acceptance',
            'archive': fingerprint(path), 'recursive_counts': recursive,
            'original_roots': len(inv['roots']), 'original_files': len(inv['files']),
            'original_empty_directories': len(inv['empty_directories']),
            'inert_aliases': len(inv['inert_aliases']), 'inert_special_descriptors': len(inv['inert_special_descriptors']),
            'outer_manifest_entries': len(expected), 'exact_original_and_metadata_union': True,
            'source_count': assessment['sources']['source_count'],
            'source_digest': assessment['sources']['compact_source_sha256'],
            'successful_raw_pairs': assessment['successful_raw_pair_count'],
            'nested_failed_raw_pairs': assessment['nested_failed_probe1']['nested_failed_raw_pairs'],
            'probe_loading_loaded_focused': [14, 25, 25],
            'native_focus_calls': assessment['probe']['native_trace']['actual_native_focus_calls'],
            'expected_intermediate_poll_child_errors': len(assessment['probe']['native_trace']['expected_intermediate_poll_attempts']),
            'unhandled_trace_after_errors': assessment['probe']['native_trace']['unhandled_failed_trace_after_events'],
            'whole_file_desktop_passes': 4, 'whole_file_unchanged_authored_mobile_exclusions': 4,
            'nested_original_probe1_terminal': 1, 'whole_closed_originals_rehashed': originals,
            'later_HEAD_or_source_tree_queried': False, 'SQL_opened': False,
            'feature_or_release_qualification': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', required=True, type=Path)
    parser.add_argument('--originals', action='store_true')
    args = parser.parse_args()
    print(json.dumps(verify_archive(args.archive, args.originals)))


if __name__ == '__main__':
    main()
