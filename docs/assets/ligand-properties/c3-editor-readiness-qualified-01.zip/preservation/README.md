# Focused editor-readiness retention — static preparation

This kit prepares preservation of two actual closed successful focused scopes and
the retained original failed diagnostic. No collector, packager or portable
verifier entrypoint has run during preparation. No ZIP payload has been opened,
copied or repackaged by this preparation. Any archive/count/output subsequently
created by these helpers must come from actual execution after primary review.

## Complete capture boundary

Six whole roots are selected, without regular-file exclusions:

- `/tmp/neistra159-editor-readiness-native-probe2`
- `/tmp/neistra159-editor-readiness-zoomfile1`
- `.issue-11-evidence/issue159-editor-readiness-native-probe1`
- `.issue-11-evidence/issue159-editor-readiness-native-probe2`
- `.issue-11-evidence/issue159-editor-readiness-correction1`
- `.issue-11-evidence/issue159-editor-readiness-native-probe1-preservation1`

All browser profiles, logs, traces, screenshots, reports, handles, terminal/cleanup
records, raw databases/WAL/SHM and their original copies remain in place. The
complete correction directory is inventoried at actual capture time, including
the actual corrected independent readback, observer-body proof, scoped review
assessments and unused future candidate preparation. No future file count is
assumed. The complete failed-preservation directory includes its byte-exact
19,993,645-byte packet SHA
`5096cfae6f156019776ac18893ae792762ca6a4ff9c54fe85fc4b1ca65d54e51`.
Its 967 original files, eight empty directories, original failed terminal1 and
three raw pairs stay failed inside that nested packet. Its old workspace is not
reopened or substituted; its exact retained bodies are checked portably.

Every regular file is hashed and retained. Every directory, empty directory,
alias target text and structural file descriptor retains complete metadata.
Aliases and special files remain inert and are never followed/opened. No bytecode,
browser cache, profile, native artifact or named regular file is omitted. Before
and after complete original inventories must match exactly. Overlapping roots,
duplicate original paths, drifting metadata or body changes stop the helper.

## Scientific and source identity

The captured source is the actual historical **working body**, based on Git
`dfeb499aef32a8b53715a65f00cfa056951fb231` with the exact three-line canonical
Atoms/N readiness guard. It is not described as a new Git commit. The collector
never asks the current checkout or later HEAD for replacement source bodies.

The original correction `source-before.zip` supplies all 1,133 bodies; the exact
selected map has compact SHA
`776cd8d21daf6dfd605b741bbab825423f1568deb1f20d624b45a8de646f5eec`.
Every member hash, the complete unique source union and CRC are verified, and both
actual successful source-after maps must match it exactly. The original capsule
is preserved once as an original correction file; no invented second capture is
claimed. The actual before/after maps and runner's source checks bind those same
bodies across both runs. Removing only the three-line guard must reconstruct the
original canonical bytes. Native12's original identity and its two declared source
deltas remain explicit; there is no new timing or method comparison claim.

## Focused result checks

Both actual original terminals must be0, with one attempt per recorded case,
no retries, flakes or report/result errors. The held probe must have one desktop
pass and no skips. The complete original zoom file must retain four desktop
passes and the exact four unchanged authored mobile exclusions with their reasons.
The two scope names, launches, configuration bytes and source maps remain separate.
The successful scopes' six raw original/copy pairs must match body/SHA/size and
their positive owned cleanup evidence. Cleanup's recorded monotonic point must
precede the raw-copy record; no diagnostic SQL is opened. The nested failed
diagnostic keeps its own three raw pairs and terminal1 classification.

The real held response is decoded from its actual report attachment, checked
against its4,377-byte/SHA`eeff8f497709abeeb88f23dbac48a8796144474318f542efa62715897f64aaae`
identity and retained receipt. Artifact, project/entry, revision, original hash,
the single real +H request and added bonded H must agree. The actual receipt's
14 loading controls,25 loaded controls and25 individually focused identities,
loading/disabled DOM proof and strict release/readiness/enumeration event order
are retained and rechecked. No molecular response is reconstructed or edited.

The native trace retains26 focus calls (launcher plus25 controls). The actual
three failed intermediate `expect.poll` child attempts remain in `test.trace`.
Each must belong to its actual passed poll parent, followed by a later passing
child. Native action errors and unhandled failed after-events are rejected.
This deliberately does not require zero error records across an otherwise
successful poll trace. The original overstrict inline readback attempt `efd9d5`
and its correction remain in the primary input JSON. No test was rerun for that
metadata correction, and no error/trace byte is erased.

The narrow probe covers light100% actual browser zoom. The complete original file
separately covers its four original scenarios, themes and zooms. Its shell sweep
reaches360 pixels; its editor zoom widths are1440 and720. These results make no
320-pixel, Tab-navigation, assistive-technology, Undo/Redo, locked-target or
error-path coverage claim for this file. Scoped review records are preserved;
they do not replace all-seven final application acceptance or the full43 gate.

The actual private launch-runner identities remain distinct: original probe1 and
the whole file launched with `67bbffd2…`, while probe2 launched with the currently
retained `6afc60b0…` runner. The frozen execution ledger records both. The portable
check reports the actual runner body found inside the failed packet separately;
it never labels the current private runner as every historical launch's source.

## Actual execution barriers and commands

The primary must inspect the sealed helpers, confirm both successful scopes and
failed original retention are closed, then freeze **all six roots**, particularly
the correction directory, for capture and packaging. Required closed metadata
hashes are listed in `input-bindings.json`. Existing originals must never be
edited/moved/deleted to satisfy a check. An unexpected mismatch requires diagnosis
and a new preparation revision; output files use exclusive creation.

Run only after that review, from this private directory, using the corrective
checkout's already pinned absolute interpreter. Commands below are templates;
replace placeholders with actual seal/capture hashes from readback, not invented
future values:

```sh
/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots/.venv/bin/python -B \
  collect.py --preparation-seal-sha256 ACTUAL_PREPARATION_SEAL_SHA
/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots/.venv/bin/python -B \
  package.py --preparation-seal-sha256 ACTUAL_PREPARATION_SEAL_SHA \
  --capture-sha256 ACTUAL_CAPTURE_RESULT_SHA
/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots/.venv/bin/python -B \
  verify.py --archive editor-readiness-evidence.zip --originals
```

The collector writes complete before/after capture inventories and actual semantic
results only after every check succeeds. Packaging requires their actual hashes
and unchanged originals, then uses the byte-exact unchanged archive helper SHA
`34ef47ebd6fe9f12009600e099c8cd5599a851c4dc95ac5412b7eb12470173e3`.
All source/profile/native/nested ZIP layers receive strict CRC/SHA/manifest checks.
The outer union is exactly all original regular files plus declared preservation
metadata. Empty directories and inert aliases are retained through the inventory,
never restored as active links. The helper retains all bytes; the2GiB release asset
limit is checked rather than trimming data.

The packet contains both exact before/after capture inventories. A complete final
after-packaging inventory and its hash are written beside the immutable archive
after creation, avoiding a circular archive self-hash. The primary must retain
that readback and independently run the portable verifier with `--originals`
before changing the original scope or publishing the small checkpoint.

Portable verification needs only the archive and the preserved audited helper
scripts in its `preservation/` directory. Without `--originals`, it never reads
later HEAD, current source files, original workspaces, SQL, API or services.
Publication/copying to `c3-editor-readiness-evidence.zip`, release verification and
the next candidate/merged/full-seven gates remain primary-owned future work.
