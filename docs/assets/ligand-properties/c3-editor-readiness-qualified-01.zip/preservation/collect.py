"""Collect only the six closed focused-evidence roots after primary review."""
import argparse
import json
from support import OUT, disk_reader, frozen, inventory, read, sha, write
from validate import validate


def reviewed_preparation(expected_sha):
    seal = OUT / 'preparation-seal.json'
    assert frozen(seal)['sha256'] == expected_sha
    value = read(seal)
    assert value['status'] == 'STATIC PREPARATION ONLY; no retention entrypoint executed'
    for row in value['files']:
        assert frozen(OUT / row['path']) == {key: row[key] for key in ('bytes', 'sha256')}
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preparation-seal-sha256', required=True)
    args = parser.parse_args()
    reviewed_preparation(args.preparation_seal_sha256)
    assert not any((OUT / name).exists() for name in (
        'input-inventory.json', 'originals-after-capture.json', 'capture-result.json',
        'archive-metadata.json', 'editor-readiness-evidence.zip'))
    bindings = read(OUT / 'input-bindings.json')
    before = inventory()
    get = disk_reader(before)
    for row in bindings['required_closed_metadata']:
        body = get(row['member'])
        assert {'bytes': len(body), 'sha256': sha(body)} == {key: row[key] for key in ('bytes', 'sha256')}
    for row in bindings['closed_archive_metadata_only']:
        captured = before['files'][row['member']]
        assert captured['bytes'] == row['bytes_from_stat_only']
        assert captured['sha256'] == row['expected_sha256_from_existing_closed_record']
    assessment = validate(get, before)
    after = inventory()
    assert before == after, 'Complete closed-original union/body/metadata changed during capture'
    reviewed_preparation(args.preparation_seal_sha256)
    write('input-inventory.json', before)
    write('originals-after-capture.json', after)
    result = {
        'scope': 'Complete focused editor readiness evidence; not full43 or release qualification',
        'assessment': assessment, 'preparation_seal_sha256': args.preparation_seal_sha256,
        'input_inventory': frozen(OUT / 'input-inventory.json'),
        'originals_after_capture': frozen(OUT / 'originals-after-capture.json'),
        'original_roots': len(before['roots']), 'original_files': len(before['files']),
        'original_bytes': sum(row['bytes'] for row in before['files'].values()),
        'original_empty_directories': len(before['empty_directories']),
        'original_inert_aliases': len(before['inert_aliases']),
        'original_inert_special_descriptors': len(before['inert_special_descriptors']),
        'complete_originals_before_after_capture_exact': True,
        'all_originals_retained_in_place': True, 'body_exclusions': [],
        'source_tree_or_HEAD_requeried': False, 'SQL_opened': False,
        'archive_not_yet_created': True,
    }
    write('capture-result.json', result)
    print(json.dumps({'scope': result['scope'], 'capture_result': frozen(OUT / 'capture-result.json'),
                      'original_roots': result['original_roots'], 'original_files': result['original_files'],
                      'raw_success_pairs': assessment['successful_raw_pair_count'],
                      'raw_failed_nested_pairs': assessment['nested_failed_probe1']['nested_failed_raw_pairs'],
                      'source_count': assessment['sources']['source_count'], 'SQL_opened': False}))


if __name__ == '__main__':
    main()
