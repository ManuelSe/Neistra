"""Portable semantic checks over retained bytes, independent of later HEAD or SQL."""
import base64
import io
import json
import re
import zipfile
from urllib.parse import parse_qs, urlsplit
from support import BASE, DB_ENDINGS, FAILED_SHA, HELPER_SHA, RESPONSE_SHA, ROOTS, SOURCE_DIGEST, ZOOM_NEW, ZOOM_OLD, ZOOM_PATH, original_member, safe, sha

SKIPS = {
    'keeps actions and dialogs reachable at real 100% and 200% browser zoom':
        'Real desktop browser zoom is separate from mobile emulation.',
    'keeps shell and inspector controls bounded around both responsive breakpoints':
        'Exact-width breakpoint sweep runs once; Pixel 7 has its own workflow matrix.',
    'keeps the molecular editor keyboard controls reachable at actual browser zoom':
        'Desktop zoom is independent of touch emulation.',
    'keeps expanded protein residues selectable at actual 100% and 200% browser zoom':
        'Actual desktop zoom; mobile residue navigation has separate native qualification.',
}


def report_cases(report, whole_file=False):
    assert not report['errors']
    assert {key: report['stats'][key] for key in ('expected', 'skipped', 'unexpected', 'flaky')} == {
        'expected': 4 if whole_file else 1, 'skipped': 4 if whole_file else 0, 'unexpected': 0, 'flaky': 0}
    assert all(project['retries'] == 0 and project['repeatEach'] == 1 for project in report['config']['projects'])
    assert report['config']['metadata']['actualWorkers'] == 1 and not report['config']['fullyParallel']
    rows = []

    def visit(suites):
        for suite in suites:
            for spec in suite.get('specs', []):
                for test in spec['tests']:
                    assert len(test['results']) == 1
                    result = test['results'][0]
                    assert result['retry'] == 0 and not result.get('errors') and not result.get('error')
                    project, title = test['projectName'], spec['title']
                    if project == 'chromium':
                        assert test['status'] == 'expected' and test['expectedStatus'] == result['status'] == 'passed'
                    else:
                        assert whole_file and project == 'mobile-chromium'
                        assert test['status'] == test['expectedStatus'] == result['status'] == 'skipped'
                        reasons = [item['description'] for item in test['annotations'] if item['type'] == 'skip']
                        assert reasons == [SKIPS[title]]
                    if whole_file:
                        assert spec['file'].endswith('rebranding-zoom.spec.ts') and title in SKIPS
                    else:
                        assert project == 'chromium' and spec['file'].endswith('editor-readiness.spec.ts')
                    rows.append({'project': project, 'title': title, 'status': result['status'],
                                 'retry': result['retry'], 'attachments': result.get('attachments', [])})
            visit(suite.get('suites', []))
    visit(report['suites'])
    assert len(rows) == (8 if whole_file else 1)
    assert len({(row['project'], row['title']) for row in rows}) == len(rows)
    if whole_file:
        assert {(row['project'], row['title']) for row in rows} == {
            (project, title) for project in ('chromium', 'mobile-chromium') for title in SKIPS}
    return rows


def raw_pairs(label, get, inv):
    terminal = json.loads(get(label + '/terminal.json'))
    assert terminal['actual_wait_exit'] == 0 and terminal['runner_complete']
    cleanup = json.loads(get(label + '/cleanup-before-raw-copy.json'))
    raw = json.loads(get(label + '/raw-copy.json'))
    assert cleanup['complete'] and cleanup['SQL_opened'] is raw['SQL_opened'] is False
    assert cleanup['signals_sent'] is False and cleanup['ports_free'] and all(cleanup['ports_free'].values())
    assert set(cleanup['ports_free']) == ({'8410', '8411', '5439'} if label == 'probe-workspace' else {'8400', '8401', '5438'})
    assert cleanup['handle_checks'] and cleanup['monotonic_ns'] == raw['cleanup_monotonic_ns']
    cleanup_written = inv['files'][label + '/cleanup-before-raw-copy.json']['metadata']['mtime_ns']
    raw_record_written = inv['files'][label + '/raw-copy.json']['metadata']['mtime_ns']
    assert cleanup_written < raw_record_written
    for row in cleanup['handle_checks']:
        assert row['state'] in ('missing', 'Z') or (
            'expected_start_token' in row and row['start_token'] != row['expected_start_token'])
    pairs = []
    assert len(raw['files']) == 3
    for relative, expected in raw['files'].items():
        safe(relative)
        original = label + '/e2e/' + relative
        copy = label + '/post-cleanup-raw-database-bytes/' + relative
        for name in (original, copy):
            assert {key: inv['files'][name][key] for key in ('bytes', 'sha256')} == expected
            body = get(name)
            assert {'bytes': len(body), 'sha256': sha(body)} == expected
        assert get(original) == get(copy)
        assert cleanup_written < inv['files'][copy]['metadata']['ctime_ns'] <= raw_record_written
        pairs.append({'original': original, 'copy': copy, **expected})
    actual = {name.removeprefix(label + '/e2e/') for name in inv['files']
              if name.startswith(label + '/e2e/') and name.lower().endswith(DB_ENDINGS)}
    assert actual == set(raw['files'])
    return pairs


def source_binding(get):
    expected = json.loads(get('primary-inputs/expected-sources.json'))
    assert len(expected) == 1133 and all(re.fullmatch('[a-f0-9]{64}', value) for value in expected.values())
    assert sha(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()) == SOURCE_DIGEST
    source_proof = json.loads(get('primary-inputs/source-proof.json'))
    assert source_proof['compact_source_digest'] == SOURCE_DIGEST and source_proof['selected_count'] == len(expected)
    capsule = get('primary-inputs/source-before.zip')
    assert sha(capsule) == source_proof['source_before_sha256'] == '34f7059397326fdb83bbc13a96a08df97ab854cb5904fd32162796e08154ac31'
    with zipfile.ZipFile(io.BytesIO(capsule)) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) == len(expected) and set(names) == set(expected)
        assert archive.testzip() is None
        for name, digest in expected.items():
            assert safe(name) == name and sha(archive.read(name)) == digest
        canonical = archive.read(ZOOM_PATH)
        original_fixture = archive.read('tests/fixtures/editing/ethanol-3d.mol')
    before = get('primary-inputs/canonical-before.ts')
    after = get('primary-inputs/canonical-after.ts')
    assert sha(before) == ZOOM_OLD and sha(after) == expected[ZOOM_PATH] == ZOOM_NEW and after == canonical
    insertion = (b'          if (section === "Atoms") {\n'
                 b'            await expect(panel.getByRole("button", { name: "Replace selected atom with N", exact: true })).toBeEnabled();\n'
                 b'          }\n')
    assert after.count(insertion) == 1 and after.replace(insertion, b'') == before
    change = json.loads(get('primary-inputs/change.json'))
    assert change['base'] == BASE and change['path'] == ZOOM_PATH
    assert change['before_sha256'] == ZOOM_OLD and change['after_sha256'] == ZOOM_NEW
    assert change['failed_campaign_preserved_before_change']
    assert source_proof['native12_other_bodies_unchanged'] == 1131 and source_proof['method52_all_exact']
    assert source_proof['only_tracked_diff'] == [ZOOM_PATH]
    assert source_proof['native12_deltas'] == {
        ZOOM_PATH: {'native12': ZOOM_OLD, 'current': ZOOM_NEW},
        'tests/unit/test_ligand_properties_release_recipe.py': {
            'native12': 'fa019dffc96a972c56f18197728874eccfde426ea956f99bf2280757b25f783a',
            'current': '9947c6b75171656d92578edc6a3dd624396d9520950daeef945558e657e2cce9'}}
    for label in ('probe-workspace', 'zoom-workspace'):
        launch = json.loads(get(label + '/launch.json'))
        assert launch['candidate_HEAD'] == BASE and launch['working_tree_source_map'] == expected
        assert launch['scope'] == ('probe2' if label == 'probe-workspace' else 'zoomfile')
        assert launch['no_retry'] and json.loads(get(label + '/source-after.json')) == expected
        config_key = 'probe2-preparation/playwright.config.ts' if label == 'probe-workspace' else 'primary-inputs/zoomfile.config.ts'
        config_path = ROOTS['probe2-preparation'] / 'playwright.config.ts' if label == 'probe-workspace' else ROOTS['primary-inputs'] / 'zoomfile.config.ts'
        assert sha(get(config_key)) == launch['config_sha256']
        assert launch['command'] == ['corepack', 'pnpm', 'exec', 'playwright', 'test', '--config', str(config_path)]
        assert launch['environment_overrides']['NEISTRA_E2E_DATA_DIR'] == str(ROOTS[label] / 'e2e')
    return {'base_Git_HEAD': BASE, 'identity': 'Actual historical working bodies; base plus exact canonical zoom guard, not a new Git commit',
            'source_count': len(expected), 'compact_source_sha256': SOURCE_DIGEST,
            'capsule_sha256': sha(capsule), 'capsule_source_union_SHA_CRC_exact': True,
            'both_success_source_after_maps_exact': True, 'declared_zoom_delta': change,
            'native12_identity_and_two_declared_deltas_preserved': source_proof['native12_deltas']}, original_fixture


def probe_trace(body):
    polls, focuses, native_failed = [], 0, 0
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            if not name.endswith('.trace'):
                continue
            events = [json.loads(line) for line in archive.read(name).splitlines()]
            before = {event['callId']: event for event in events if event['type'] == 'before'}
            after = {event['callId']: event for event in events if event['type'] == 'after'}
            focuses += sum(event.get('method') == 'focus' for event in before.values())
            for call, event in after.items():
                if not event.get('error'):
                    continue
                assert name == 'test.trace', 'Native action error is not an intermediate test poll attempt'
                child = before[call]
                parent = before[child['parentId']]
                assert parent['method'] == 'test.step' and 'poll ' in parent['title']
                assert not after[parent['callId']].get('error')
                later = [other['callId'] for other in before.values()
                         if other.get('parentId') == parent['callId'] and other['startTime'] > event['endTime']
                         and other['callId'] in after and not after[other['callId']].get('error')]
                assert later
                polls.append({'trace': name, 'call_id': call, 'parent': parent['callId'],
                              'error': event['error'], 'later_passing_children': later,
                              'parent_poll_completed_successfully': True})
    assert focuses == 26 and len(polls) == 3
    assert {row['call_id'] for row in polls} == {'expect@46', 'expect@48', 'expect@50'}
    assert {row['parent'] for row in polls} == {'test.step@44'}
    return {'actual_native_focus_calls': focuses, 'expected_intermediate_poll_attempts': polls,
            'unhandled_failed_trace_after_events': native_failed, 'trace_bytes_retained_without_changes': True}


def probe_binding(get, inv, rows, original_fixture):
    names = [name for name in inv['files'] if name.startswith('probe-workspace/test-results/') and name.endswith('/readiness-receipt.json')]
    assert len(names) == 1
    receipt_bytes = get(names[0])
    receipt = json.loads(receipt_bytes)
    assert receipt['status'] == 'all diagnostic assertions completed' and not receipt['failures']
    assert receipt['canonical_source_before_sha256'] == receipt['canonical_source_after_sha256'] == ZOOM_NEW
    assert receipt['original_failed_candidate'] == BASE and receipt['no_full_feature_or_release_claim']
    attachments = rows[0]['attachments']
    held = [row for row in attachments if row['name'] == 'actual-held-structure-1.json']
    attached_receipt = [row for row in attachments if row['name'] == 'readiness-receipt.json']
    traces = [row for row in attachments if row['name'] == 'trace']
    assert len(held) == len(attached_receipt) == len(traces) == 1
    assert base64.b64decode(attached_receipt[0]['body'], validate=True) == receipt_bytes
    body = base64.b64decode(held[0]['body'], validate=True)
    projection = json.loads(body)
    assert len(body) == 4377 and sha(body) == RESPONSE_SHA
    assert len(receipt['holds']) == len(receipt['writes']) == 1
    hold = receipt['holds'][0]
    baseline, after = receipt['baseline'], receipt['after']
    assert hold['response_sha256'] == after['canonical_response_sha256'] == sha(body)
    assert hold['response_bytes'] == len(body) and hold['response_status'] == 200 and hold['released']
    assert hold['artifact'] == after['artifact_id'] == projection['artifact_id'] != baseline['artifact_id']
    assert projection['entry_id'] == baseline['entry_id']
    url = urlsplit(hold['request_url'])
    assert url.path == f"/api/v1/projects/{baseline['project_id']}/entries/{baseline['entry_id']}/structure"
    assert parse_qs(url.query) == {'expected_artifact_id': [projection['artifact_id']]}
    assert hold['committed_revision'] == after['revision'] == baseline['revision'] + 1
    assert sha(original_fixture) == baseline['original_sha256'] == after['original_sha256']
    assert len(original_fixture) == baseline['original_bytes']
    write = receipt['writes'][0]
    assert urlsplit(write['url']).path == url.path.removesuffix('/structure') + '/model-edits'
    assert write['body']['action'] == {'operation': 'hydrogens.add_one'}
    assert write['body']['expected_revision'] == baseline['revision']
    assert write['body']['expected_artifact_id'] == baseline['artifact_id']
    assert write['body']['selection']['atoms'] == [{'structure_id': baseline['entry_id'], 'atom_id': 1}]
    assert write['body']['hydrogen_policy'] == 'preserve' and re.fullmatch('[a-f0-9-]{36}', write['attempt'])
    atoms, bonds = projection['structure']['atoms'], projection['structure']['bonds']
    assert len(atoms) == baseline['atoms'] + 1 == 4
    assert next(atom for atom in atoms if atom['id'] == 1)['element'] == 'C'
    hydrogen = next(atom for atom in atoms if atom['id'] == after['added_hydrogen_id'])
    assert hydrogen['element'] == 'H' and sum(atom['element'] == 'H' for atom in atoms) == 1
    assert any({bond['atom_1_id'], bond['atom_2_id']} == {1, hydrogen['id']} for bond in bonds)
    assert len(receipt['loading_controls']) == 14
    assert len(receipt['loaded_controls']) == len(receipt['focused_controls']) == 25
    for index, control in enumerate(receipt['focused_controls']):
        assert control == {'index': index, **receipt['loaded_controls'][index]}
    labels = [row['label'] for row in receipt['loaded_controls']]
    assert 'Replace selected atom with N' in labels and 'Replace selected atom with O' in labels
    assert 'Replace selected atom with C' not in labels
    assert receipt['held_browser_state'] == {'target': 'Loading current target…', 'nitrogenDisabled': True, 'fieldsetDisabled': True}
    events = receipt['events']
    assert [row['sequence'] for row in events] == list(range(len(events)))
    order = ['initial selected C1 projection ready', 'real committed current-artifact response fetched and held',
             'held projection visibly loading with disabled Atoms and N', 'semantic N readiness wait started',
             'enumeration blocked while actual response held', 'held-response release requested',
             'same actual response delivered', 'semantic N readiness wait completed',
             'loaded control enumeration reached', 'routes released and teardown awaited']
    assert [row['name'] for row in events] == order and events[-1]['details']['failures'] == 0
    trace_key = original_member(traces[0]['path'], inv)
    trace_result = probe_trace(get(trace_key))
    primary = json.loads(get('primary-inputs/held-probe2-primary-readback.json'))
    assert primary['actual_terminal_wait_exit'] == 0 and primary['decoded_response_sha256'] == RESPONSE_SHA
    assert primary['report_sha256'] == sha(get('probe-workspace/browser-report.json'))
    assert primary['receipt_sha256'] == sha(receipt_bytes) and primary['trace_sha256'] == sha(get(trace_key))
    assert primary['unhandled_failed_trace_after_events'] == 0 and primary['initial_readback_attempt']['tool_chunk'] == 'efd9d5'
    assert {row['call_id'] for row in primary['expected_intermediate_poll_attempts']} == {row['call_id'] for row in trace_result['expected_intermediate_poll_attempts']}
    return {'receipt_member': names[0], 'receipt_sha256': sha(receipt_bytes),
            'decoded_actual_response_bytes': len(body), 'decoded_response_sha256': sha(body),
            'artifact': projection['artifact_id'], 'revision': after['revision'], 'original_sha256': sha(original_fixture),
            'loading_controls': 14, 'loaded_focused_controls': 25, 'ordered_real_response_readiness_barrier': True,
            'one_actual_H_edit_and_unchanged_original_hash': True, 'native_trace': trace_result}


def nested_failure(get):
    record = json.loads(get('failed-probe1/retention.json'))
    body = get('failed-probe1/failed-probe1-evidence.zip')
    assert len(body) == record['archive']['bytes'] == 19993645
    assert sha(body) == record['archive']['sha256'] == FAILED_SHA
    assert record['originals_retained'] and record['SQL_opened'] is record['qualification_PASS'] is False
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        assert archive.testzip() is None
        manifest = json.loads(archive.read('manifest.json'))
        inventory = json.loads(archive.read('original-inventory.json'))
        expected = {name for name, row in inventory.items() if row['kind'] == 'file'}
        aliases = {'inert-alias-descriptors/' + name + '.json' for name, row in inventory.items() if row['kind'] == 'inert_alias'}
        assert set(manifest) == expected | aliases | {'original-inventory.json', 'release-evidence-used.py.txt'}
        assert set(archive.namelist()) == set(manifest) | {'manifest.json'}
        assert len(archive.namelist()) == len(set(archive.namelist()))
        for name in expected:
            data = archive.read(name)
            assert sha(data) == inventory[name]['sha256'] == manifest[name]['sha256']
            assert len(data) == inventory[name]['size'] == manifest[name]['bytes']
        assert sha(archive.read('release-evidence-used.py.txt')) == HELPER_SHA
        terminal = json.loads(archive.read('workspace/terminal.json'))
        assert terminal['actual_wait_exit'] == 1 and terminal['runner_complete']
        raw = json.loads(archive.read('workspace/raw-copy.json'))
        cleanup = json.loads(archive.read('workspace/cleanup-before-raw-copy.json'))
        assert cleanup['complete'] and cleanup['SQL_opened'] is raw['SQL_opened'] is False
        assert cleanup['monotonic_ns'] == raw['cleanup_monotonic_ns']
        assert inventory['workspace/cleanup-before-raw-copy.json']['mtime_ns'] < inventory['workspace/raw-copy.json']['mtime_ns']
        for relative, binding in raw['files'].items():
            a = archive.read('workspace/e2e/' + safe(relative))
            b = archive.read('workspace/post-cleanup-raw-database-bytes/' + relative)
            assert a == b and {'bytes': len(a), 'sha256': sha(a)} == binding
        empty = sum(row['kind'] == 'directory' and row['empty'] for row in inventory.values())
        assert len(expected) == record['original_files'] == 967
        assert empty == record['empty_directories'] == 8
        assert len(raw['files']) == record['raw_original_copy_pairs'] == 3
        captured_runner_sha = sha(archive.read('primary-inputs/run-focused.py'))
    return {'bytes': len(body), 'sha256': sha(body), 'original_failed_files': len(expected),
            'original_failed_empty_directories': empty, 'nested_failed_raw_pairs': len(raw['files']),
            'terminal_exit': 1, 'qualification_PASS': False, 'entire_original_union_verified': True,
            'runner_bytes_present_in_original_failed_packet_sha256': captured_runner_sha}


def validate(get, inv):
    assert inv['roots'] == {label: str(root) for label, root in ROOTS.items()}
    assert not inv['body_exclusions'] and not inv['missing_roots']
    for name in ('held-probe2-primary-readback.py', 'held-probe2-primary-readback.json',
                 'observer-body-proof.json', 'scoped-specialist-assessments.json', 'prepare-candidate4.py',
                 'focused-executions.json', 'static-prerequisite-architecture-assessment.json'):
        assert 'primary-inputs/' + name in inv['files']
    sources, fixture = source_binding(get)
    probe_report = json.loads(get('probe-workspace/browser-report.json'))
    zoom_report = json.loads(get('zoom-workspace/browser-report.json'))
    probe_rows, zoom_rows = report_cases(probe_report), report_cases(zoom_report, whole_file=True)
    for rows in (probe_rows, zoom_rows):
        for row in rows:
            for attachment in row['attachments']:
                if 'path' in attachment:
                    original_member(attachment['path'], inv)
    pairs = raw_pairs('probe-workspace', get, inv) + raw_pairs('zoom-workspace', get, inv)
    assert len(pairs) == 6
    for label, expected_sha in [('probe1-preparation', '8a39197fcda94e2cf00949f2057f569a40448eca64301f1477f315a8c410b560'),
                                ('probe2-preparation', '3f0213b057f1c1032cd023547c958eaa7171802682b1814f93c7dcfaa9fb7a8a')]:
        seal_bytes = get(label + '/seal.json')
        assert sha(seal_bytes) == expected_sha
        seal = json.loads(seal_bytes)
        actual = {name.removeprefix(label + '/') for name in inv['files'] if name.startswith(label + '/')}
        assert actual == {item['path'] for item in seal['files']} | {'seal.json'}
        for item in seal['files']:
            body = get(label + '/' + item['path'])
            assert {'bytes': len(body), 'sha256': sha(body)} == {key: item[key] for key in ('bytes', 'sha256')}
    probe = probe_binding(get, inv, probe_rows, fixture)
    failed = nested_failure(get)
    executions = json.loads(get('primary-inputs/focused-executions.json'))
    assert executions['canonical_before'] == ZOOM_OLD and executions['canonical_after'] == ZOOM_NEW
    assert executions['SQL_opened'] is executions['full43_gate'] is executions['release_or_push_readiness'] is False
    assert executions['successful_scope_raw_pairs'] == len(pairs) and executions['failed_scope_raw_pairs'] == 3
    scopes = executions['scopes']
    assert scopes['probe1']['actual_exit'] == 1 and scopes['probe1']['complete_retention_sha256'] == FAILED_SHA
    assert scopes['probe2']['actual_exit'] == scopes['complete_original_zoomfile']['actual_exit'] == 0
    original_runner = scopes['probe1']['actual_runner_source_sha256_at_launch']
    assert original_runner == scopes['complete_original_zoomfile']['actual_runner_source_sha256_at_launch'] == '67bbffd23bfb8e87b25620cf0e10b01a636c84d4416f5ff2f5db0f5b1decffc2'
    current_runner = sha(get('primary-inputs/run-focused.py'))
    assert current_runner == scopes['probe2']['actual_runner_source_sha256_at_launch'] == '6afc60b0ce0b51bdcc7b559ef72fd616dc44e64d32722f6cd0368de7d01cc97e'
    assert scopes['probe2']['no_test_rerun_for_readback_correction']
    whole_primary = json.loads(get('primary-inputs/whole-file-primary-readback.json'))
    assert whole_primary['actual_wait_exit'] == 0 and whole_primary['positive_cleanup']
    assert whole_primary['report_sha256'] == sha(get('zoom-workspace/browser-report.json'))
    assert whole_primary['stats'] == zoom_report['stats'] and whole_primary['SQL_opened'] is False
    return {'sources': sources, 'probe': probe, 'whole_original_file': {
                'desktop_passes': 4, 'unchanged_authored_mobile_exclusions': 4,
                'cases': [{key: row[key] for key in ('project', 'title', 'status', 'retry')} for row in zoom_rows],
                'shell_minimum_width': 360, 'editor_actual_zoom_widths': [1440, 720],
                'limits': ['No 320-pixel claim', 'No Tab or assistive-technology navigation claim',
                           'No Undo/Redo, locked-target or error-path coverage supplied by this file']},
            'successful_original_raw_copy_pairs': pairs, 'successful_raw_pair_count': len(pairs),
            'private_runner_identities': {'original_probe1_and_zoom_launch_sha256': original_runner,
                'probe2_launch_and_current_retained_runner_sha256': current_runner,
                'runner_retained_in_failed_packet_sha256': failed['runner_bytes_present_in_original_failed_packet_sha256'],
                'launch_metadata_and_actual_capture_times_distinguished': True},
            'nested_failed_probe1': failed, 'SQL_opened': False,
            'full43_qualification': False, 'feature_or_release_qualification': False}
