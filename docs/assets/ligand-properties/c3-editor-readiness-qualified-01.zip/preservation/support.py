"""Closed-original retention primitives; no Git, process, API or SQL operations."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import runpy
import stat

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).absolute().parent
HELPER_SHA = '34ef47ebd6fe9f12009600e099c8cd5599a851c4dc95ac5412b7eb12470173e3'
BASE = 'dfeb499aef32a8b53715a65f00cfa056951fb231'
SOURCE_DIGEST = '776cd8d21daf6dfd605b741bbab825423f1568deb1f20d624b45a8de646f5eec'
ZOOM_PATH = 'tests/e2e/rebranding-zoom.spec.ts'
ZOOM_OLD = '5002451820458969f3da28ba6aceaa0a6cdb9753040e33745b632663f610c0bd'
ZOOM_NEW = '75ed41b0e75e67cd92a3056311fc98785e0414ee6576aec0abe0e4bb24a19eb0'
FAILED_SHA = '5096cfae6f156019776ac18893ae792762ca6a4ff9c54fe85fc4b1ca65d54e51'
RESPONSE_SHA = 'eeff8f497709abeeb88f23dbac48a8796144474318f542efa62715897f64aaae'
ROOTS = {
    'probe-workspace': Path('/tmp/neistra159-editor-readiness-native-probe2'),
    'zoom-workspace': Path('/tmp/neistra159-editor-readiness-zoomfile1'),
    'probe1-preparation': ROOT / '.issue-11-evidence/issue159-editor-readiness-native-probe1',
    'probe2-preparation': ROOT / '.issue-11-evidence/issue159-editor-readiness-native-probe2',
    'primary-inputs': ROOT / '.issue-11-evidence/issue159-editor-readiness-correction1',
    'failed-probe1': ROOT / '.issue-11-evidence/issue159-editor-readiness-native-probe1-preservation1',
}
DB_ENDINGS = ('.db', '.db-wal', '.db-shm', '.sqlite', '.sqlite-wal', '.sqlite-shm',
              '.sqlite3', '.sqlite3-wal', '.sqlite3-shm')


def sha(body):
    return hashlib.sha256(body).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def write(name, value):
    with (OUT / name).open('xb') as stream:
        stream.write(encoded(value))


def read(path):
    return json.loads(path.read_bytes())


def fingerprint(path):
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def metadata(value):
    return {'mode': value.st_mode, 'mtime_ns': value.st_mtime_ns, 'ctime_ns': value.st_ctime_ns, 'size': value.st_size,
            'inode': value.st_ino, 'device': value.st_dev, 'uid': value.st_uid,
            'gid': value.st_gid, 'nlink': value.st_nlink}


def frozen(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and not path.is_symlink(), path
    result = fingerprint(path)
    assert metadata(before) == metadata(path.lstat()), path
    return result


def safe(name):
    assert isinstance(name, str) and name and '\\' not in name and '\x00' not in name
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and str(path) == name
    return name


def helpers():
    path = OUT / 'release-evidence-used.py.txt'
    assert frozen(path)['sha256'] == HELPER_SHA
    return runpy.run_path(str(path), run_name='closed_editor_retention_archive_helpers')


def inventory(roots=ROOTS):
    """Inventory every original, preserving aliases/specials inertly without following."""
    files, directories, aliases, special, empty = {}, {}, [], [], []

    def visit(label, root, path):
        value = path.lstat()
        relative = path.relative_to(root).as_posix()
        key = label if relative == '.' else label + '/' + relative
        facts = metadata(value)
        if stat.S_ISLNK(value.st_mode):
            aliases.append({'path': key, 'original_path': str(path), 'target': os.readlink(path),
                            'active': False, 'metadata': facts})
        elif stat.S_ISDIR(value.st_mode):
            directories[key] = {'original_path': str(path), 'metadata': facts}
            children = sorted(path.iterdir())
            if not children:
                empty.append(key)
            for child in children:
                visit(label, root, child)
        elif stat.S_ISREG(value.st_mode):
            assert key not in files
            files[key] = {'original_path': str(path), **frozen(path), 'metadata': facts}
        else:
            special.append({'path': key, 'original_path': str(path), 'active': False,
                            'opened': False, 'metadata': facts})

    paths = list(roots.values())
    assert len(paths) == len(set(paths))
    assert all(not a.is_relative_to(b) for a in paths for b in paths if a != b)
    for label, root in roots.items():
        assert safe(label) == label and '/' not in label
        assert root.is_absolute() and root.is_dir() and not root.is_symlink()
        assert root != OUT and not OUT.is_relative_to(root) and not root.is_relative_to(OUT)
        visit(label, root, root)
    assert len(files) == len({row['original_path'] for row in files.values()})
    return {'roots': {label: str(root) for label, root in roots.items()}, 'files': files,
            'directories': directories, 'empty_directories': sorted(empty),
            'inert_aliases': sorted(aliases, key=lambda row: row['path']),
            'inert_special_descriptors': sorted(special, key=lambda row: row['path']),
            'body_exclusions': [], 'missing_roots': []}


def original_member(path, inventory_value):
    names = [name for name, row in inventory_value['files'].items() if row['original_path'] == path]
    assert len(names) == 1, path
    return names[0]


def disk_reader(inventory_value):
    def get(name):
        row = inventory_value['files'][safe(name)]
        path = Path(row['original_path'])
        expected = {key: row[key] for key in ('bytes', 'sha256')}
        assert frozen(path) == expected, path
        body = path.read_bytes()
        assert {'bytes': len(body), 'sha256': sha(body)} == expected
        return body
    return get
