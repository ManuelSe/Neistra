"""Package the reviewed, captured closed focused originals without altering them."""
from pathlib import Path
import argparse
import json
from collect import reviewed_preparation
from support import OUT, frozen, helpers, inventory, read, write


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preparation-seal-sha256', required=True)
    parser.add_argument('--capture-sha256', required=True)
    args = parser.parse_args()
    preparation = reviewed_preparation(args.preparation_seal_sha256)
    assert frozen(OUT / 'capture-result.json')['sha256'] == args.capture_sha256
    capture = read(OUT / 'capture-result.json')
    assert capture['preparation_seal_sha256'] == args.preparation_seal_sha256
    assert capture['complete_originals_before_after_capture_exact'] and capture['all_originals_retained_in_place']
    assert capture['SQL_opened'] is False and not capture['body_exclusions']
    before = read(OUT / 'input-inventory.json')
    assert frozen(OUT / 'input-inventory.json') == capture['input_inventory']
    assert frozen(OUT / 'originals-after-capture.json') == capture['originals_after_capture']
    assert before == read(OUT / 'originals-after-capture.json') == inventory()
    assert not any((OUT / name).exists() for name in ('archive-metadata.json', 'editor-readiness-evidence.zip',
                                                    'originals-after-packaging.json', 'verification.json'))
    metadata_names = sorted({row['path'] for row in preparation['files']} | {
        'preparation-seal.json', 'input-inventory.json', 'originals-after-capture.json',
        'capture-result.json', 'archive-metadata.json'})
    write('archive-metadata.json', {
        'scope': capture['scope'], 'preparation_seal_sha256': args.preparation_seal_sha256,
        'capture_result': frozen(OUT / 'capture-result.json'),
        'input_inventory': capture['input_inventory'],
        'originals_after_capture': capture['originals_after_capture'],
        'metadata_members': metadata_names, 'body_exclusions': [],
        'later_HEAD_or_source_tree_required': False,
        'failed_probe1_remains_failed_inside_exact_nested_original_packet': True,
        'all_regular_original_bytes_and_structural_metadata_retained': True,
        'originals_after_packaging_policy': 'Reinventory outside the immutable packet after creation; exact before/after capture inventories are already inside. Primary retains the final after-packaging inventory/hash and independent readback.',
        'final_feature_release_qualification': False, 'publication_complete': False, 'SQL_opened': False,
    })
    items = {name: Path(row['original_path']) for name, row in before['files'].items()}
    for name in metadata_names:
        assert name not in items and (OUT / name).is_file()
        items['preservation/' + name] = OUT / name
    packet = helpers()['archive'](items, OUT / 'editor-readiness-evidence.zip')
    after = inventory()
    write('originals-after-packaging.json', after)
    assert before == after, 'Complete original union/body/metadata changed during packaging'
    reviewed_preparation(args.preparation_seal_sha256)
    from verify import verify_archive
    portable = verify_archive(Path(packet['path']), originals=False)
    assert packet['bytes'] < 2 * 1024**3
    result = {'scope': capture['scope'], 'archive': packet,
              'portable_semantic_and_exact_union_verification': portable,
              'originals_after_packaging': frozen(OUT / 'originals-after-packaging.json'),
              'complete_originals_before_after_packaging_exact': True,
              'all_originals_retained_in_place': True, 'within_2GiB_asset_cap': True,
              'SQL_opened': False, 'full43_or_release_qualification': False}
    write('verification.json', result)
    with (OUT / 'editor-readiness-evidence.zip.sha256').open('x') as stream:
        stream.write(packet['sha256'] + '  editor-readiness-evidence.zip\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
