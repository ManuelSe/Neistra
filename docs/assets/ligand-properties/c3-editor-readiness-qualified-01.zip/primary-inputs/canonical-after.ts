import { addOneHydrogen } from "./support/hydrogen";
import { prepare } from "./support/interactions";
import { expectCompactInspection } from "./support/modeling";
import { browseComponents, showEntries } from "./support/navigation";
import type { Project, StructureProjection } from "../../apps/web/src/api/types";
import AxeBuilder from "@axe-core/playwright";
import { chromium, expect, test, type Locator, type Page, type TestInfo, type Worker } from "@playwright/test";
import { mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

interface ZoomAPI {
  tabs: {
    query(query: object): Promise<{ id: number; url?: string }[]>;
    setZoom(id: number, factor: number): Promise<void>;
    getZoom(id: number): Promise<number>;
  };
}

async function setZoom(worker: Worker, url: string, factor: number) {
  return worker.evaluate(async ({ url, factor }) => {
    const chrome = (globalThis as unknown as { chrome: ZoomAPI }).chrome;
    const tab = (await chrome.tabs.query({})).find(tab => tab.url?.startsWith(url));
    if (!tab) throw new Error("Qualification tab not found");
    await chrome.tabs.setZoom(tab.id, factor);
    return chrome.tabs.getZoom(tab.id);
  }, { url, factor });
}

async function expectBoundedActions(page: Page) {
  const size = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
  const inspector = page.getByRole("button", { name: "Inspector", exact: true });
  if (size.width <= 840) await expect(inspector).toBeVisible();
  else await expect(inspector).toBeHidden();
  const bounds = await page.locator('.topbar button:visible, .viewer-toolbar button:visible, .viewer-toolbar select:visible, .transform-launcher button:visible')
    .evaluateAll(nodes => nodes.map(node => {
      const box = node.getBoundingClientRect();
      return { name: node.getAttribute("aria-label"), x: box.x, y: box.y, width: box.width, height: box.height };
    }));
  for (const box of bounds) {
    expect(box.x, box.name ?? "action").toBeGreaterThanOrEqual(0);
    expect(box.x + box.width, box.name ?? "action").toBeLessThanOrEqual(size.width + 1);
    expect(box.y + box.height, box.name ?? "action").toBeLessThanOrEqual(size.height + 1);
  }
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
}

async function captureZoomPage(page: Page, info: TestInfo, name: string) {
  // Playwright 1.55 clips real browser-zoom captures using CSS dimensions as
  // device pixels. Capture the full native surface instead, without a clip.
  const session = await page.context().newCDPSession(page);
  try {
    const metrics = await session.send("Page.getLayoutMetrics");
    const { data } = await session.send("Page.captureScreenshot", { format: "png", fromSurface: true });
    const png = Buffer.from(data, "base64");
    expect(png.readUInt32BE(16)).toBe(metrics.layoutViewport.clientWidth);
    expect(png.readUInt32BE(20)).toBe(metrics.layoutViewport.clientHeight);
    await writeFile(info.outputPath(name), png);
  } finally { await session.detach(); }
}

async function expectBoundedSurfaceOpening(manager: Locator, info: TestInfo, name: string) {
  const samples = await manager.evaluate(node => {
    // Restart the actual CSS entrance, then sample its native animation timeline.
    // This checks opening geometry deterministically, including before opacity 1.
    const original = node.style.animation;
    node.style.animation = "none";
    node.getBoundingClientRect();
    node.style.animation = original;
    const animations = node.getAnimations();
    for (const animation of animations) animation.pause();
    try {
      return [0, 0.5, 1].map(progress => {
        for (const animation of animations) {
          const duration = Number(animation.effect?.getComputedTiming().duration);
          if (!Number.isFinite(duration) || duration < 0) throw new Error("Invalid panel entrance duration");
          animation.currentTime = duration * progress;
        }
        const box = node.getBoundingClientRect(), style = getComputedStyle(node);
        return { progress, left: box.left, right: box.right, top: box.top, bottom: box.bottom,
          viewportWidth: innerWidth, viewportHeight: innerHeight,
          scrollWidth: node.scrollWidth, clientWidth: node.clientWidth,
          transform: style.transform, opacity: style.opacity, animation: style.animationName };
      });
    } finally { for (const animation of animations) animation.finish(); }
  });
  await writeFile(info.outputPath(name), JSON.stringify(samples, null, 2));
  for (const sample of samples) {
    expect(sample.left, JSON.stringify(sample)).toBeGreaterThanOrEqual(0);
    expect(sample.right, JSON.stringify(sample)).toBeLessThanOrEqual(sample.viewportWidth);
    expect(sample.top, JSON.stringify(sample)).toBeGreaterThanOrEqual(0);
    expect(sample.bottom, JSON.stringify(sample)).toBeLessThanOrEqual(sample.viewportHeight);
    expect(sample.scrollWidth, JSON.stringify(sample)).toBeLessThanOrEqual(sample.clientWidth + 1);
  }
}

test("keeps actions and dialogs reachable at real 100% and 200% browser zoom", async ({ request, baseURL }, info) => {
  test.skip(info.project.name !== "chromium", "Real desktop browser zoom is separate from mobile emulation.");
  test.setTimeout(240_000);
  const extension = resolve("tests/e2e/support/zoom-extension");
  const profile = await mkdtemp(join(tmpdir(), "neistra-zoom-qualification-"));
  // A null emulated viewport is essential: a forced CSS viewport masks real zoom.
  const context = await chromium.launchPersistentContext(profile, {
    channel: "chromium", headless: true, viewport: null, deviceScaleFactor: undefined,
    args: ["--window-size=1440,1000", `--disable-extensions-except=${extension}`, `--load-extension=${extension}`,
      "--enable-webgl", "--ignore-gpu-blocklist", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
  });
  try {
    const worker = context.serviceWorkers()[0] ?? await context.waitForEvent("serviceworker");
    const page = context.pages()[0];
    page.setDefaultTimeout(15_000);
    const created = await request.post("/api/v1/projects", { data: { name: `Zoom qualification ${Date.now()}` } });
    expect(created.status()).toBe(201);
    const project = await created.json() as { id: string; name: string };
    await page.goto(baseURL!);
    await page.getByRole("button", { name: "Projects", exact: true }).click();
    await page.getByRole("dialog", { name: "Projects" }).getByRole("button", { name: new RegExp(`^${project.name}`) }).click();
    await page.getByRole("button", { name: "Import structures" }).first().click();
    const importer = page.getByRole("dialog", { name: "Import structures" });
    await importer.locator('input[type="file"]').setInputFiles(resolve("tests/fixtures/formats/ethanol.mol"));
    await importer.getByRole("button", { name: "Import", exact: true }).click();
    await expect(importer).toBeHidden();
    await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded", { timeout: 30_000 });
    const imported = await (await request.get(`/api/v1/projects/${project.id}`)).json() as Project;
    const grouped = await request.post(`/api/v1/projects/${project.id}/groups`, { data: { expected_revision: imported.revision, name: "Zoom destination", entry_ids: imported.entries.map(entry => entry.id) } });
    expect(grouped.status()).toBe(200);
    await page.reload();
    await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded", { timeout: 30000 });
    for (const theme of ["light", "dark"]) {
      if (theme === "dark") await page.getByRole("button", { name: "Use dark theme" }).click();
      for (const factor of [1, 2]) {
        expect(await setZoom(worker, baseURL!, factor)).toBe(factor);
        await expect.poll(() => page.evaluate(() => devicePixelRatio)).toBe(factor);
        await expect.poll(() => page.evaluate(() => innerWidth)).toBe(1440 / factor);
        await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded");
        await expectBoundedActions(page);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-workspace.png`);
        if (factor === 2) await page.getByRole("button", { name: "Project browser", exact: true }).click();
        await browseComponents(page, imported.entries[0].name);
        const navigation = page.locator(".project-browser");
        await expect(page.locator(".hierarchy-category").first()).toBeVisible();
        expect((await new AxeBuilder({ page }).include(".project-browser").analyze()).violations).toEqual([]);
        expect(await navigation.evaluate(node => node.scrollWidth <= node.clientWidth + 1)).toBe(true);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-navigation.png`);
        await showEntries(page);
        await page.getByRole("button", { name: `Actions for ${imported.entries[0].name}`, exact: true }).click();
        await page.getByRole("menuitem", { name: "Details", exact: true }).click();
        await expect(page.getByRole("dialog", { name: "Entry details" })).toContainText(imported.entries[0].original_filename!);
        await page.keyboard.press("Escape");
        if (factor === 2) await page.getByRole("button", { name: "Close panel", exact: true }).click();
        const interactionsLauncher = page.getByRole("button", { name: "Interactions", exact: true });
        await interactionsLauncher.focus(); await page.keyboard.press("Enter");
        const interactions = page.getByRole("dialog", { name: "Interactions", exact: true });
        await expect(interactions).toBeVisible();
        expect(await interactions.evaluate(node => { const box = node.getBoundingClientRect(); return box.left >= 0 && box.right <= innerWidth && box.top >= 0 && box.bottom <= innerHeight && node.scrollWidth <= node.clientWidth + 1; })).toBe(true);
        // Contrast measurements must sample the settled panel, not its opacity
        // transition. Keep the actual WCAG assertions unchanged.
        await expect(interactions).toHaveCSS("opacity", "1");
        expect((await new AxeBuilder({ page }).include(".interaction-panel").analyze()).violations).toEqual([]);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-interactions.png`);
        await interactions.getByRole("button", { name: "Interaction help" }).click();
        await interactions.getByRole("button", { name: "Close interactions" }).focus(); await page.keyboard.press("Enter");
        await expect(interactionsLauncher).toBeFocused();
        if (factor === 2) await page.getByRole("button", { name: "Inspector", exact: true }).click();
        await page.getByRole("tab", { name: "selection", exact: true }).click();
        await page.getByLabel("Select by").selectOption("structure");
        await page.getByLabel("Value", { exact: true }).fill(imported.entries[0].id);
        await page.getByRole("button", { name: "Apply query", exact: true }).click();
        await page.getByRole("tab", { name: "transform", exact: true }).click();
        await page.getByRole("button", { name: "Move selection", exact: true }).focus();
        await page.keyboard.press("Enter");
        const movement = page.getByRole("region", { name: "Move selection controls" });
        await expect(movement).toBeVisible();
        if (factor === 2) {
          await page.getByRole("button", { name: "Close panel", exact: true }).click({ position: { x: 2, y: 100 } });
          await expect(page.getByRole("dialog", { name: "Inspector panel", exact: true })).toBeHidden();
          await expect(page.getByRole("button", { name: "Inspector", exact: true })).toBeFocused();
        }
        const movementCanvas = page.getByRole("group", { name: "Move selection canvas" });
        await movementCanvas.focus();
        await expect(movementCanvas).toBeFocused();
        await page.keyboard.down("Space");
        await expect(movement).toContainText("Adjusting camera");
        await page.keyboard.up("Space");
        await expect(movement).toContainText("Transforming selection");
        await movement.getByRole("button", { name: "Adjust view" }).focus();
        await page.keyboard.press("Space");
        await expect(movement).toContainText("Adjusting camera");
        await movement.getByRole("button", { name: "Resume transform" }).focus();
        await page.keyboard.press("Space");
        await expect(movement).toContainText("Transforming selection");
        expect((await new AxeBuilder({ page }).include(".movement-banner").include(".movement-pointer-surface").include(".movement-panel")
          .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"]).analyze()).violations).toEqual([]);
        await movement.getByRole("button", { name: "More movement tools", exact: true }).click();
        const statusBox = (await page.locator(".viewer-status").boundingBox())!;
        const movementBox = (await movement.boundingBox())!;
        expect(movementBox.y).toBeGreaterThan(statusBox.y + statusBox.height);
        for (const control of await page.locator(".movement-banner button, .movement-panel button, .movement-panel input").all()) {
          await control.scrollIntoViewIfNeeded();
          const box = (await control.boundingBox())!;
          const viewport = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
          expect(box.x).toBeGreaterThanOrEqual(0); expect(box.x + box.width).toBeLessThanOrEqual(viewport.width + 1);
          expect(box.y).toBeGreaterThanOrEqual(0); expect(box.y + box.height).toBeLessThanOrEqual(viewport.height + 1);
          expect(box.height).toBeGreaterThanOrEqual(await control.evaluate(node => !node.classList.contains("movement-action") || matchMedia("(pointer: coarse)").matches ? 44 : 32));
          for (const name of ["Apply movement", "Cancel movement"]) {
            expect(await movement.getByRole("button", { name }).evaluate(node => {
              const box = node.getBoundingClientRect();
              const hit = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2);
              return hit === node || Boolean(hit && node.contains(hit));
            })).toBe(true);
          }
        }
        await page.getByRole("dialog", { name: "More movement tools", exact: true }).getByRole("button", { name: "Translate", exact: true }).focus(); await page.keyboard.press("Enter");
        await page.getByRole("group", { name: "Move selection canvas" }).focus(); await page.keyboard.press("ArrowRight");
        await page.getByRole("dialog", { name: "More movement tools", exact: true }).getByRole("button", { name: "Depth", exact: true }).click();
        await page.getByRole("dialog", { name: "More movement tools", exact: true }).getByRole("button", { name: "Step away" }).click();
        expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
        await movement.evaluate(element => { element.scrollTop = 0; });
        await captureZoomPage(page, info, `${theme}-${factor * 100}-interactive-movement.png`);
        await page.keyboard.press("Escape");
        await expect(page.getByRole("dialog", { name: "More movement tools" })).toBeHidden();
        await expect(movement).toBeVisible();
        await page.keyboard.press("Escape"); await expect(movement).toBeHidden();
        await expect(page.getByRole("button", { name: factor === 2 ? "Transform selection" : "Move selection", exact: true })).toBeFocused();
        await expect(page.locator(".msp-viewport-controls, .msp-viewport-controls-panel, .msp-logo")).toHaveCount(0);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-application-viewer.png`);
        const inspector = page.getByRole("button", { name: "Inspector", exact: true });
        if (await inspector.isVisible()) await inspector.click();
        for (const tab of await page.locator('.inspector-tabs [role="tab"]').all()) {
          await tab.click();
          expect(await tab.evaluate(el => el.scrollWidth <= el.clientWidth + 1)).toBe(true);
        }
        await captureZoomPage(page, info, `${theme}-${factor * 100}-inspector.png`);
        if (await page.locator(".mobile-panel").isVisible()) await page.keyboard.press("Escape");
        await page.getByRole("button", { name: "Export", exact: true }).click();
        const dialog = page.getByRole("dialog", { name: "Export" });
        await dialog.getByRole("tab", { name: "Project archive" }).click();
        await dialog.getByRole("button", { name: "Generate", exact: true }).scrollIntoViewIfNeeded();
        const box = await dialog.boundingBox();
        const height = await page.evaluate(() => innerHeight);
        expect(box!.y).toBeGreaterThanOrEqual(0);
        expect(box!.y + box!.height).toBeLessThanOrEqual(height + 1);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-export.png`);
        await page.keyboard.press("Escape");
        const browser = page.getByRole("button", { name: "Project browser", exact: true });
        if (await browser.isVisible()) await browser.click();
        await page.locator(".entry-row .entry-select").click();
        await page.locator(".entry-menu-trigger").focus();
        await page.keyboard.press("Enter");
        await page.getByRole("menuitem", { name: "Move to group…", exact: true }).click();
        const membership = page.getByRole("dialog", { name: "Move to group", exact: true });
        await expect(membership).toContainText("1 complete structure.");
        await expect(membership.getByLabel("Destination group")).toBeFocused();
        for (const control of await membership.locator("button:visible, select:visible").all()) {
          await control.scrollIntoViewIfNeeded();
          const bounds = await control.boundingBox();
          const viewport = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
          expect(bounds!.x).toBeGreaterThanOrEqual(0);
          expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(viewport.width + 1);
          expect(bounds!.y + bounds!.height).toBeLessThanOrEqual(viewport.height + 1);
        }
        await captureZoomPage(page, info, `${theme}-${factor * 100}-group-membership.png`);
        await membership.getByRole("button", { name: "Move structures" }).click();
        await expect(membership).toBeHidden();
        await expect(page.locator(".entry-menu-trigger")).toBeFocused();
        await page.keyboard.press("Enter");
        await page.getByRole("menuitem", { name: "Remove from group", exact: true }).click();
        await expect(page.locator('.entry-group[data-group-id="ungrouped"] .entry-row')).toBeVisible();
        // Membership relocates/remounts the row. Escape belongs to its drawer
        // only after the captured action's scheduled focus restoration completes.
        await expect(page.getByRole("menu")).toBeHidden();
        await expect(page.locator(".entry-menu-trigger")).toBeFocused();

        if (await page.locator(".mobile-panel").isVisible()) {
          await page.keyboard.press("Escape");
          await expect(page.getByRole("dialog", { name: "Project browser panel" })).toBeHidden();
          await expect(browser).toBeFocused();
        }
        const launcher = page.getByRole("button", { name: "Style selection", exact: true });
        await expect(launcher).toBeEnabled();
        await launcher.focus();
        await expect(launcher).toBeFocused();
        await page.keyboard.press("Enter");
        const appearance = page.getByRole("dialog", { name: "Style selection" });
        for (const control of await appearance.locator("button:visible, input:visible, select:visible").all()) {
          await control.scrollIntoViewIfNeeded();
          const bounds = await control.boundingBox();
          const viewport = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
          expect(bounds!.x).toBeGreaterThanOrEqual(0);
          expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(viewport.width + 1);
          expect(bounds!.y + bounds!.height).toBeLessThanOrEqual(viewport.height + 1);
        }
        for (const name of ["Hide atom detail", "Show atom detail"]) {
          const action = appearance.getByRole("button", { name, exact: true });
          await action.scrollIntoViewIfNeeded();
          const bounds = await action.boundingBox();
          expect(bounds!.width).toBeGreaterThanOrEqual(44);
          expect(bounds!.height).toBeGreaterThanOrEqual(44);
          await action.focus(); await page.keyboard.press("Enter");
          await expect(appearance.getByRole("status")).toContainText("Atom detail");
        }
        const createSurface = appearance.getByRole("button", { name: "Create surface", exact: true });
        await createSurface.scrollIntoViewIfNeeded();
        await createSurface.focus(); await page.keyboard.press("Enter");
        const manager = page.getByRole("dialog", { name: "Surfaces", exact: true });
        await manager.getByRole("button", { name: "Create fragment", exact: true }).focus(); await page.keyboard.press("Enter");
        await expect(manager.getByText("1 surface created.", { exact: true })).toBeVisible();
        const fragment = manager.getByRole("button", { name: /Captured fragment/ });
        await expect(fragment).toHaveAttribute("aria-pressed", "true");
        await fragment.focus(); await page.keyboard.press("Enter");
        await expect(fragment).toHaveAttribute("aria-pressed", "false");
        await expect(manager.getByLabel("Surface color scheme")).toBeHidden();
        await expect(fragment).toBeFocused();
        await page.keyboard.press("Enter");
        await expect(fragment).toHaveAttribute("aria-pressed", "true");
        await manager.getByLabel("Surface color scheme").selectOption("custom");
        await expect(manager.getByLabel("Surface color scheme")).toHaveAttribute("aria-disabled", "false");
        await manager.getByLabel("Surface opacity", { exact: true }).fill("0.3");
        await manager.getByLabel("Surface opacity", { exact: true }).press("Enter");
        await expect(manager.getByLabel("Surface color scheme")).toHaveAttribute("aria-disabled", "false");
        await manager.getByLabel("Surface display").selectOption("mesh");
        await expect(manager.getByLabel("Surface display")).toHaveAttribute("aria-disabled", "false");
        await manager.getByRole("button", { name: /^Rename surface/ }).click();
        await expect.poll(() => manager.evaluate(node => getComputedStyle(node).opacity)).toBe("1");
        expect((await new AxeBuilder({ page }).include(".surface-manager").withTags(["wcag2a", "wcag2aa", "wcag21aa"]).analyze()).violations).toEqual([]);
        for (const control of await manager.locator("button:visible, input:visible, select:visible").all()) {
          await control.scrollIntoViewIfNeeded();
          const box = (await control.boundingBox())!;
          const viewport = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
          expect(box.x).toBeGreaterThanOrEqual(0); expect(box.x + box.width).toBeLessThanOrEqual(viewport.width + 1);
          expect(box.y + box.height).toBeLessThanOrEqual(viewport.height + 1);
        }
        expect(await manager.evaluate(node => node.scrollWidth <= node.clientWidth + 1)).toBe(true);
        await manager.getByLabel("Surface name").scrollIntoViewIfNeeded();
        await captureZoomPage(page, info, `${theme}-${factor * 100}-surface-manager.png`);
        await manager.getByRole("button", { name: /^Remove surface/ }).focus(); await page.keyboard.press("Enter");
        await expect(manager.getByText(/No saved surfaces/)).toBeVisible();
        await manager.getByRole("button", { name: "Close surfaces" }).focus(); await page.keyboard.press("Enter");
        await expect(launcher).toBeFocused();
        await page.keyboard.press("Enter");
        await appearance.getByLabel("About surfaces").click();
        await expect(appearance.getByText(/Cut boundaries can create artificial faces/)).toBeVisible();
        await appearance.getByRole("button", { name: "Create surface", exact: true }).focus(); await page.keyboard.press("Enter");
        await manager.getByRole("button", { name: "Around selection", exact: true }).click();
        await expect(manager.getByRole("combobox", { name: "Surface receptor" })).toBeVisible();
        await expectBoundedSurfaceOpening(manager, info, `${theme}-${factor * 100}-surface-opening.json`);
        expect(await manager.evaluate((node) => {
          const box = node.getBoundingClientRect();
          return box.left >= 0 && box.right <= innerWidth && box.top >= 0 && box.bottom <= innerHeight &&
            node.scrollWidth <= node.clientWidth + 1;
        })).toBe(true);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-pocket.png`);
        await manager.getByRole("button", { name: "Close surfaces" }).click();
        await expect(launcher).toBeFocused();
        await page.keyboard.press("Enter");
        await captureZoomPage(page, info, `${theme}-${factor * 100}-selection-appearance.png`);
        await page.keyboard.press("Escape");
        await expect(launcher).toBeFocused();
      }
      expect(await setZoom(worker, baseURL!, 1)).toBe(1);
      await expect.poll(() => page.evaluate(() => devicePixelRatio)).toBe(1);
    }
  } finally { await context.close(); }
});

test("keeps shell and inspector controls bounded around both responsive breakpoints", async ({ page }, info) => {
  test.skip(info.project.name !== "chromium", "Exact-width breakpoint sweep runs once; Pixel 7 has its own workflow matrix.");
  test.setTimeout(90_000);
  await page.goto("/");
  await page.getByRole("main").getByRole("button", { name: "Create project" }).click();
  const create = page.getByRole("dialog", { name: "Create project" });
  await create.getByLabel("Name", { exact: true }).fill(`Breakpoint qualification ${Date.now()}`);
  await create.getByRole("button", { name: "Create project" }).click();
  await expect(create).toBeHidden();
  for (const theme of ["light", "dark"]) {
    if (theme === "dark") await page.getByRole("button", { name: "Use dark theme" }).click();
    for (const width of [1440, 841, 840, 839, 521, 520, 519, 360]) {
      await page.setViewportSize({ width, height: 900 });
      await expectBoundedActions(page);
      await page.getByRole("button", { name: "Projects", exact: true }).click();
      await expect(page.getByRole("dialog", { name: "Projects" })).toBeVisible();
      await page.getByRole("dialog", { name: "Projects" }).focus();
      await page.keyboard.press("Escape");
      if (width <= 840) await page.getByRole("button", { name: "Inspector", exact: true }).click();
      for (const name of ["selection", "details"]) {
        await page.locator(".inspector-tabs").getByRole("tab", { name, exact: true }).click();
        expect(await page.locator(".project-facts dt, .selection-summary dt").evaluateAll(nodes =>
          nodes.filter(node => node.scrollWidth > node.clientWidth + 1).map(node => node.textContent))).toEqual([]);
        await page.screenshot({ path: info.outputPath(`${theme}-${width}-${name}.png`) });
      }
      if (width <= 840) {
        await page.locator(".mobile-panel").focus();
        await page.keyboard.press("Escape");
      }
      await page.screenshot({ path: info.outputPath(`${theme}-${width}.png`) });
    }
  }
});

test("keeps the molecular editor keyboard controls reachable at actual browser zoom", async ({ request, baseURL }, info) => {
  test.skip(info.project.name !== "chromium", "Desktop zoom is independent of touch emulation.");
  test.setTimeout(180000);
  const extension = resolve("tests/e2e/support/zoom-extension");
  const profile = await mkdtemp(join(tmpdir(), "neistra-edit-zoom-"));
  const context = await chromium.launchPersistentContext(profile, {
    channel: "chromium", headless: true, viewport: null, deviceScaleFactor: undefined, baseURL,
    args: ["--window-size=1440,1000", `--disable-extensions-except=${extension}`, `--load-extension=${extension}`,
      "--enable-webgl", "--ignore-gpu-blocklist", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
  });
  try {
    const worker = context.serviceWorkers()[0] ?? await context.waitForEvent("serviceworker");
    const page = context.pages()[0];
    page.setDefaultTimeout(10000);
    const project = await prepare(page, request, ["tests/fixtures/editing/ethanol-3d.mol"], "Edit zoom");
    const select = async () => {
      if (await page.getByRole("button", { name: "Inspector", exact: true }).isVisible()) await page.getByRole("button", { name: "Inspector", exact: true }).click();
      await page.getByRole("tab", { name: "selection", exact: true }).click();
      await page.getByRole("combobox", { name: "Select by", exact: true }).selectOption("atom_reference");
      await page.getByRole("textbox", { name: "Value", exact: true }).fill(`${project.entries[0].id}:1`);
      await page.getByRole("button", { name: "Apply query", exact: true }).click();
      if (await page.locator(".mobile-panel").isVisible()) await page.getByRole("button", { name: "Close panel", exact: true }).click({ position: { x: 2, y: 100 } });
    };
    await select();
    const launcher = page.getByRole("button", { name: "Edit molecule", exact: true });
    await launcher.click();
    const panel = page.getByRole("dialog", { name: "Edit molecule", exact: true });
    await addOneHydrogen(page);
    await expect(page.getByText(/Molecular edit stored/)).toBeVisible();
    await panel.getByRole("button", { name: "Close molecular editor" }).click();
    for (const theme of ["light", "dark"]) {
      if (theme === "dark") await page.getByRole("button", { name: "Use dark theme" }).click();
      for (const factor of [1, 2]) {
        expect(await setZoom(worker, baseURL!, factor)).toBe(factor);
        await expect.poll(() => page.evaluate(() => devicePixelRatio)).toBe(factor);
        await expect.poll(() => page.evaluate(() => innerWidth)).toBe(1440 / factor);
        await launcher.focus(); await page.keyboard.press("Enter");
        await expect(panel).toBeFocused();
        for (const section of ["Atoms", "Bonds", "Fragments", "Residues"]) {
          await panel.getByRole("button", { name: section, exact: true }).click();
          if (section === "Atoms") {
            await expect(panel.getByRole("button", { name: "Replace selected atom with N", exact: true })).toBeEnabled();
          }
          for (const control of await panel.locator("button:visible:enabled, summary:visible").all()) {
            await control.focus();
            await expect(control).toBeFocused();
            expect(await control.evaluate(node => {
              const b = node.getBoundingClientRect();
              return b.x >= 0 && b.right <= innerWidth && b.y >= 0 && b.bottom <= innerHeight &&
                node.contains(document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2));
            })).toBe(true);
          }
        }
        expect((await new AxeBuilder({ page }).include(".molecular-edit-panel").withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze()).violations).toEqual([]);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-molecular-edit.png`);
        await panel.getByRole("button", { name: "Atoms", exact: true }).click();
        await panel.getByText("Add atom", { exact: true }).click();
        const more = panel.getByText("Advanced atom details", { exact: true });
        if (!(await more.evaluate(node => node.closest("details")!.open))) await more.click();
        expect((await new AxeBuilder({ page }).include(".molecular-edit-panel").withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze()).violations).toEqual([]);
        await panel.getByRole("button", { name: "Preview atom", exact: true }).click();
        await expect(panel.getByRole("button", { name: "Apply placement", exact: true })).toBeEnabled();
        await expect(panel.getByRole("status")).toContainText(/Ready.*warnings?/);
        await expectCompactInspection(panel);
        for (const control of await panel.getByRole("button").all()) {
          await control.focus(); await expect(control).toBeFocused();
          expect(await control.evaluate(node => {
            const b = node.getBoundingClientRect();
            return b.width >= 44 && b.height >= 44 && b.x >= 0 && b.right <= innerWidth &&
              b.y >= 0 && b.bottom <= innerHeight && node.contains(document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2));
          })).toBe(true);
        }
        expect((await new AxeBuilder({ page }).include(".molecular-edit-panel").withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze()).violations).toEqual([]);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-placement-inspection.png`);
        await panel.getByRole("button", { name: "Cancel placement", exact: true }).click();
        await page.keyboard.press("Escape"); await expect(launcher).toBeFocused();
      }
    }
    for (const factor of [1, 2]) {
      expect(await setZoom(worker, baseURL!, factor)).toBe(factor);
      await expect.poll(() => page.evaluate(() => devicePixelRatio)).toBe(factor);
      await expect.poll(() => page.evaluate(() => innerWidth)).toBe(1440 / factor);
      const empty = await (await request.post("/api/v1/projects", { data: { name: `Empty edit recovery ${factor} ${Date.now()}` } })).json() as Project;
      await page.reload();
      await page.getByRole("button", { name: "Projects", exact: true }).click();
      await page.getByRole("dialog", { name: "Projects" }).getByRole("button", { name: new RegExp(`^${empty.name}`) }).click();
      await page.evaluate(() => sessionStorage.setItem("neistra.edit-attempts.v1", "unreadable earlier edit")); await page.reload();
      const recovery = page.getByLabel("Molecular edit recovery", { exact: true }); await expect(recovery).toBeVisible();
      await recovery.getByRole("button", { name: "Review current state", exact: true }).click();
      const continuation = recovery.getByRole("button", { name: "Continue editing current state", exact: true });
      await continuation.scrollIntoViewIfNeeded(); await continuation.focus(); await expect(continuation).toBeFocused();
      expect(await continuation.evaluate(node => {
        const bounds = node.getBoundingClientRect(), workspace = node.closest(".workspace-canvas")!.getBoundingClientRect();
        return bounds.height >= 44 && bounds.top >= workspace.top && bounds.bottom <= workspace.bottom && bounds.left >= workspace.left && bounds.right <= workspace.right
          && node.contains(document.elementFromPoint(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2));
      })).toBe(true);
      expect((await new AxeBuilder({ page }).include(".project-stage").withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze()).violations).toEqual([]);
      await captureZoomPage(page, info, `${factor * 100}-empty-edit-recovery.png`);
      await page.keyboard.press("Enter"); await expect(recovery).toBeHidden();
      expect((await (await request.get(`/api/v1/projects/${empty.id}`)).json() as Project).revision).toBe(empty.revision);
    }
  } finally { await context.close(); }
});

test("keeps expanded protein residues selectable at actual 100% and 200% browser zoom", async ({ request, baseURL }, info) => {
  test.skip(info.project.name !== "chromium", "Actual desktop zoom; mobile residue navigation has separate native qualification.");
  test.setTimeout(180000);
  const extension = resolve("tests/e2e/support/zoom-extension");
  const context = await chromium.launchPersistentContext(await mkdtemp(join(tmpdir(), "neistra-residue-zoom-")), {
    channel: "chromium", headless: true, viewport: null, deviceScaleFactor: undefined, baseURL,
    args: ["--window-size=1440,1000", `--disable-extensions-except=${extension}`, `--load-extension=${extension}`,
      "--enable-webgl", "--ignore-gpu-blocklist", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
  });
  try {
    const worker = context.serviceWorkers()[0] ?? await context.waitForEvent("serviceworker");
    const page = context.pages()[0]; page.setDefaultTimeout(15000);
    const project = await prepare(page, request, ["tests/fixtures/complex/1stp.pdb"], "Residue browser zoom");
    const entry = project.entries[0];
    const projection: StructureProjection = await (await request.get(`/api/v1/projects/${project.id}/entries/${entry.id}/structure`)).json();
    const component = projection.hierarchy.components.find(c => c.category === "protein")!;
    const residue = projection.structure.residues.find(r => r.id === component.residue_ids[0])!;
    const label = `${residue.name} ${residue.author_number ?? residue.label_number}${residue.insertion_code ?? ""}`;
    const baseline = await (await request.get(`/api/v1/projects/${project.id}`)).json();
    await browseComponents(page, entry.name);
    await page.getByRole("button", { name: `Expand Protein in ${entry.name}`, exact: true }).click();
    await page.getByRole("button", { name: `Expand ${component.display_label} in ${entry.name}`, exact: true }).click();
    for (const theme of ["light", "dark"] as const) {
      if (theme === "dark") await page.getByRole("button", { name: "Use dark theme", exact: true }).click();
      for (const factor of [1, 2]) {
        expect(await setZoom(worker, baseURL!, factor)).toBe(factor);
        await expect.poll(() => page.evaluate(() => devicePixelRatio)).toBe(factor);
        await expect.poll(() => page.evaluate(() => innerWidth)).toBe(1440 / factor);
        if (factor === 2) { await page.getByRole("button", { name: "Project browser", exact: true }).click(); await page.getByRole("tab", { name: "Components", exact: true }).click(); }
        const chain = page.getByRole("button", { name: `Select ${component.display_label} in ${entry.name}`, exact: true });
        const button = page.getByRole("button", { name: `Select ${label} · ${component.display_label} in ${entry.name}`, exact: true });
        await button.focus(); await expect(button).toBeFocused();
        await page.keyboard.press("ArrowLeft"); await expect(chain).toBeFocused();
        await page.keyboard.press("ArrowRight"); await expect(button).toBeFocused();
        await button.press("Enter"); await expect(button).toHaveAttribute("aria-pressed", "true");
        expect(await button.evaluate(node => { const b = node.getBoundingClientRect(); return b.x >= 0 && b.right <= innerWidth &&
          b.y >= 0 && b.bottom <= innerHeight && node.contains(document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2)); })).toBe(true);
        expect((await new AxeBuilder({ page }).include(".component-pane").withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze()).violations).toEqual([]);
        expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-residue-navigation.png`);
        if (factor === 2) await page.keyboard.press("Escape");
        const sequences = page.getByRole("region", { name: "Protein sequence viewer", exact: true });
        const tile = sequences.getByRole("button", { name: `${label} · chain ${projection.structure.chains.find(c => c.id === residue.chain_id)!.name} in ${entry.name}`, exact: true });
        await tile.focus(); await expect(tile).toBeFocused();
        await tile.press("ArrowRight"); await page.keyboard.press("ArrowLeft"); await expect(tile).toBeFocused();
        await tile.press("Enter"); await expect(tile).toHaveAttribute("aria-pressed", "true");
        expect(await tile.evaluate(node => { const b = node.getBoundingClientRect(); return b.x >= 0 && b.right <= innerWidth && b.y >= 0 && b.bottom <= innerHeight && node.contains(document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2)); })).toBe(true);
        expect((await new AxeBuilder({ page }).include(".sequence-viewer").withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze()).violations).toEqual([]);
        await captureZoomPage(page, info, `${theme}-${factor * 100}-protein-sequences.png`);
      }
    }
    expect(await (await request.get(`/api/v1/projects/${project.id}`)).json()).toEqual(baseline);
  } finally { await context.close(); }
});
