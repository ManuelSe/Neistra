"""Run one explicitly selected focused scope once; collect raw stores before SQL."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).resolve().parent
MODE = sys.argv[1]
assert MODE in ('probe', 'probe2', 'zoomfile')
SCOPES = {
    'probe': ('/tmp/neistra159-editor-readiness-native-probe1', (8390, 8391, 5437),
              '.issue-11-evidence/issue159-editor-readiness-native-probe1/playwright.config.ts'),
    'probe2': ('/tmp/neistra159-editor-readiness-native-probe2', (8410, 8411, 5439),
               '.issue-11-evidence/issue159-editor-readiness-native-probe2/playwright.config.ts'),
    'zoomfile': ('/tmp/neistra159-editor-readiness-zoomfile1', (8400, 8401, 5438),
                 '.issue-11-evidence/issue159-editor-readiness-correction1/zoomfile.config.ts'),
}
workspace_name, PORTS, config_name = SCOPES[MODE]
WORKSPACE = Path(workspace_name)
CONFIG = ROOT / config_name
EXPECTED = json.loads((OUT / 'expected-sources.json').read_bytes())
Q = runpy.run_path(str(ROOT / 'docs/assets/ligand-properties/qualification.py.txt'))

def sha(body):
    return hashlib.sha256(body).hexdigest()

def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

def kernel(pid):
    value = (Path('/proc') / str(pid) / 'stat').read_text()
    row = value[value.rindex(')') + 2:].split()
    return {'pid': pid, 'start_token': row[19], 'state': row[0]}

def owned():
    marker = ('NEISTRA_E2E_DATA_DIR=' + str(WORKSPACE / 'e2e')).encode()
    result = []
    for base in Path('/proc').iterdir():
        if not base.name.isdigit():
            continue
        try:
            before = kernel(int(base.name))
            environment = (base / 'environ').read_bytes().split(b'\0')
            after = kernel(int(base.name))
        except (OSError, ValueError):
            continue
        if marker in environment and before['start_token'] == after['start_token'] and after['state'] != 'Z':
            result.append(after)
    return result

def ports_free():
    listening = set()
    for name in ('tcp', 'tcp6'):
        for line in (Path('/proc/net') / name).read_text().splitlines()[1:]:
            fields = line.split()
            if fields[3] == '0A':
                listening.add(int(fields[1].rsplit(':', 1)[1], 16))
    return {str(port): port not in listening for port in PORTS}

assert Q['current_identities'](ROOT) == EXPECTED
assert all(ports_free().values()) and not owned()
assert not WORKSPACE.exists(), 'One-shot workspace already exists; never restart it'
WORKSPACE.mkdir()
env = {k: v for k, v in os.environ.items()
       if not k.startswith(('NEISTRA_', 'MOLWEAVE_')) and k not in ('DATABASE_URL', 'PLAYWRIGHT_JSON_OUTPUT_FILE')}
overrides = {
    'NEISTRA_E2E_DATA_DIR': str(WORKSPACE / 'e2e'),
    'NEISTRA_E2E_API_PORT': str(PORTS[0]), 'NEISTRA_E2E_WORKER_PORT': str(PORTS[1]),
    'NEISTRA_E2E_WEB_PORT': str(PORTS[2]), 'NEISTRA_PERFORMANCE': '0',
    'PLAYWRIGHT_BROWSERS_PATH': '/datadisk/dev/neistra/.playwright',
}
if MODE in ('probe', 'probe2'):
    overrides['NEISTRA_READINESS_PROBE_ENABLE'] = 'after-preservation-and-canonical-N-guard'
env.update(overrides)
command = ['corepack', 'pnpm', 'exec', 'playwright', 'test', '--config', str(CONFIG)]
record = {'scope': MODE, 'candidate_HEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
          'working_tree_source_map': EXPECTED, 'config_sha256': sha(CONFIG.read_bytes()),
          'command': command, 'environment_overrides': overrides,
          'started_utc': datetime.now(timezone.utc).isoformat(), 'no_retry': True}
write(WORKSPACE / 'launch.json', record)
known = {}
with (WORKSPACE / 'raw.log').open('xb') as log, (WORKSPACE / 'live-handles.jsonl').open('x') as observations:
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    identity = kernel(process.pid)
    write(WORKSPACE / 'process.json', identity)
    while process.poll() is None:
        rows = owned()
        for row in rows:
            known[(row['pid'], row['start_token'])] = row
        observations.write(json.dumps({'monotonic_ns': time.monotonic_ns(), 'handles': rows}) + '\n')
        observations.flush()
        time.sleep(.5)
    code = process.wait()
write(WORKSPACE / 'terminal.json', {'actual_wait_exit': code, 'runner_complete': True,
      'recorded_utc': datetime.now(timezone.utc).isoformat()})
remaining = []
checks = []
for (pid, token) in sorted(known):
    try:
        actual = kernel(pid)
    except FileNotFoundError:
        checks.append({'pid': pid, 'start_token': token, 'state': 'missing'})
        continue
    checks.append({'expected_start_token': token, **actual})
    if actual['start_token'] == token and actual['state'] != 'Z':
        remaining.append(actual)
assert not remaining and not owned() and all(ports_free().values()), 'Cleanup incomplete; no raw copy or diagnostic SQL authorized'
cleanup_ns = time.monotonic_ns()
write(WORKSPACE / 'cleanup-before-raw-copy.json', {'complete': True, 'monotonic_ns': cleanup_ns,
      'handle_checks': checks, 'ports_free': ports_free(), 'signals_sent': False, 'SQL_opened': False})
destination = WORKSPACE / 'post-cleanup-raw-database-bytes'
destination.mkdir()
files = {}
for source in sorted((WORKSPACE / 'e2e').rglob('*')):
    assert not source.is_symlink()
    if not source.is_file() or not source.name.endswith(('.db', '.db-wal', '.db-shm', '.sqlite', '.sqlite-wal', '.sqlite-shm', '.sqlite3', '.sqlite3-wal', '.sqlite3-shm')):
        continue
    relative = source.relative_to(WORKSPACE / 'e2e')
    body = source.read_bytes()
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert target.read_bytes() == body == source.read_bytes()
    files[str(relative)] = {'bytes': len(body), 'sha256': sha(body)}
assert files
write(WORKSPACE / 'raw-copy.json', {'cleanup_monotonic_ns': cleanup_ns, 'files': files, 'SQL_opened': False})
assert Q['current_identities'](ROOT) == EXPECTED
write(WORKSPACE / 'source-after.json', EXPECTED)
print(json.dumps({'scope': MODE, 'actual_wait_exit': code, 'raw_original_copy_pairs': len(files),
                  'positive_cleanup': True, 'selected_sources_fixed': len(EXPECTED), 'SQL_opened': False}), flush=True)
sys.exit(code)
