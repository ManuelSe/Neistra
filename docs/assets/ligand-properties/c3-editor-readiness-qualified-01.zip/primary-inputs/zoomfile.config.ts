import { defineConfig } from "@playwright/test";
import { resolve } from "node:path";
import base from "../../playwright.config";

const root = "/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots";
const workspace = "/tmp/neistra159-editor-readiness-zoomfile1";
if (process.cwd() !== root) throw new Error("Run from the explicit corrective root");
const required = { NEISTRA_E2E_DATA_DIR: `${workspace}/e2e`, NEISTRA_E2E_API_PORT: "8400",
  NEISTRA_E2E_WORKER_PORT: "8401", NEISTRA_E2E_WEB_PORT: "5438", NEISTRA_PERFORMANCE: "0" };
for (const [name, value] of Object.entries(required)) {
  if (process.env[name] !== value) throw new Error(`Explicit focused input required: ${name}`);
}
const servers = Array.isArray(base.webServer) ? base.webServer : [base.webServer];
if (servers.length !== 3 || servers.some(server => !server)) throw new Error("Expected three root services");
export default defineConfig({
  ...base,
  testDir: resolve(root, "tests/e2e"),
  testMatch: "rebranding-zoom.spec.ts",
  outputDir: `${workspace}/test-results`,
  fullyParallel: false,
  workers: 1,
  retries: 0,
  maxFailures: 1,
  reporter: [["line"], ["json", { outputFile: `${workspace}/browser-report.json` }]],
  use: { ...base.use, trace: "on" },
  webServer: servers.map(server => ({ ...server!, cwd: root, reuseExistingServer: false })),
});
