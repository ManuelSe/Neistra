"""Independent closed native receipt/response/trace readback; no SQL or runtime."""
from pathlib import Path
import base64
import hashlib
import json
import runpy
import zipfile

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = Path(__file__).resolve().parent
WORK = Path('/tmp/neistra159-editor-readiness-native-probe2')
receipt_path = next((WORK / 'test-results').rglob('readiness-receipt.json'))
receipt = json.loads(receipt_path.read_bytes())
report = json.loads((WORK / 'browser-report.json').read_bytes())
tests = []

def walk(suites):
    for suite in suites:
        for spec in suite.get('specs', []):
            tests.extend(spec['tests'])
        walk(suite.get('suites', []))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

walk(report['suites'])
assert len(tests) == 1 and not report.get('errors')
assert {key: report['stats'][key] for key in ('expected', 'skipped', 'unexpected', 'flaky')} == {
    'expected': 1, 'skipped': 0, 'unexpected': 0, 'flaky': 0}
results = tests[0]['results']
assert len(results) == 1 and results[0]['status'] == 'passed' and results[0]['retry'] == 0
assert not results[0].get('errors')
attached = [a for a in results[0]['attachments'] if a['name'] == 'actual-held-structure-1.json']
assert len(attached) == 1
body = base64.b64decode(attached[0]['body'], validate=True)
projection = json.loads(body)
response_sha = hashlib.sha256(body).hexdigest()
assert len(body) == 4377 and response_sha == receipt['holds'][0]['response_sha256'] == receipt['after']['canonical_response_sha256']
assert projection['artifact_id'] == receipt['after']['artifact_id'] == receipt['holds'][0]['artifact']
assert projection['entry_id'] == receipt['baseline']['entry_id']
assert len(projection['structure']['atoms']) == 4 and receipt['after']['added_hydrogen_id'] == 4
assert receipt['baseline']['original_sha256'] == receipt['after']['original_sha256'] == 'ea4f86ae1c9269b50cf06deb8efe715e69ab0a8b4a1e395e0e3b713c21c5c69a'
assert receipt['after']['revision'] == receipt['baseline']['revision'] + 1
assert len(receipt['loading_controls']) == 14
assert len(receipt['loaded_controls']) == len(receipt['focused_controls']) == 25
for index, entry in enumerate(receipt['focused_controls']):
    assert entry == {'index': index, **receipt['loaded_controls'][index]}
assert receipt['held_browser_state'] == {'target': 'Loading current target…', 'nitrogenDisabled': True, 'fieldsetDisabled': True}
names = [e['name'] for e in receipt['events']]
ordered = ['semantic N readiness wait started', 'enumeration blocked while actual response held',
           'held-response release requested', 'same actual response delivered',
           'semantic N readiness wait completed', 'loaded control enumeration reached']
assert [names.index(name) for name in ordered] == sorted(names.index(name) for name in ordered)
assert not receipt['failures'] and len(receipt['writes']) == 1
assert receipt['writes'][0]['body']['action'] == {'operation': 'hydrogens.add_one'}
assert receipt['canonical_source_before_sha256'] == receipt['canonical_source_after_sha256'] == '75ed41b0e75e67cd92a3056311fc98785e0414ee6576aec0abe0e4bb24a19eb0'
trace_path = next((WORK / 'test-results').rglob('trace.zip'))
poll_attempts = []
focus_count = 0
with zipfile.ZipFile(trace_path) as zipped:
    assert zipped.testzip() is None
    for name in zipped.namelist():
        if not name.endswith('.trace'):
            continue
        events = [json.loads(line) for line in zipped.read(name).splitlines()]
        before = {e['callId']: e for e in events if e['type'] == 'before'}
        after = {e['callId']: e for e in events if e['type'] == 'after'}
        focus_count += sum(e.get('method') == 'focus' for e in before.values())
        for call_id, event in after.items():
            if not event.get('error'):
                continue
            child = before[call_id]
            parent = before[child['parentId']]
            assert parent['method'] == 'test.step' and 'poll ' in parent['title']
            assert not after[parent['callId']].get('error')
            assert any(other.get('parentId') == parent['callId'] and
                       other['startTime'] > event['endTime'] and
                       other['callId'] in after and not after[other['callId']].get('error')
                       for other in before.values())
            poll_attempts.append({'trace': name, 'call_id': call_id, 'parent': parent['callId'],
                                  'error': event['error'], 'parent_poll_completed_successfully': True})
assert focus_count >= 26
qualification = runpy.run_path(str(ROOT / 'docs/assets/ligand-properties/qualification.py.txt'))
expected = json.loads((OUT / 'expected-sources.json').read_bytes())
assert qualification['current_identities'](ROOT) == expected
assert json.loads((WORK / 'terminal.json').read_bytes())['actual_wait_exit'] == 0
assert json.loads((WORK / 'cleanup-before-raw-copy.json').read_bytes())['complete']
assert len(json.loads((WORK / 'raw-copy.json').read_bytes())['files']) == 3
record = {'scope': 'Independent actual held-response diagnostic2 readback only',
          'actual_terminal_wait_exit': 0, 'report_sha256': sha(WORK / 'browser-report.json'),
          'receipt_sha256': sha(receipt_path), 'trace_sha256': sha(trace_path),
          'decoded_real_response_bytes': len(body), 'decoded_response_sha256': response_sha,
          'actual_native_focus_calls': focus_count, 'expected_intermediate_poll_attempts': poll_attempts,
          'unhandled_failed_trace_after_events': 0, 'loading_controls': 14,
          'loaded_and_individually_focused_controls': 25,
          'ordered_readiness_before_enumeration_after_real_response_release': True,
          'one_real_H_edit_revision_and_original_hash_verified': True,
          'single_pass_retry0_no_skips_or_report_errors': True,
          'positive_cleanup_and3_raw_copy_pairs': True, 'selected1133_sources_fixed': True,
          'diagnostic_SQL_opened': False, 'full43_qualification': False,
          'initial_readback_attempt': {'tool_chunk': 'efd9d5', 'exit': 1,
              'reason': 'Overstrict zero-all-trace-errors assertion rejected three expected expect.poll intermediate attempts; original data unchanged, no test rerun.'}}
target = OUT / 'held-probe2-primary-readback.json'
assert not target.exists()
target.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'expected_intermediate_poll_attempts'}))
