"""Bind the actual clean committed checkpoint; never launch a qualification."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import runpy
import shutil
import subprocess

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
HERE = Path(__file__).resolve().parent
PREP = ROOT / '.issue-11-evidence/issue159-c5-candidate4-preparation1'
OUT = ROOT / '.issue-11-evidence/issue159-c5-candidate4-transport1'
WORK = Path('/tmp/neistra159-c5-candidate4')
ASSETS = ROOT / 'docs/assets/ligand-properties'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')

assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT)
assert not OUT.exists() and not WORK.exists()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head != 'dfeb499aef32a8b53715a65f00cfa056951fb231'
qualification = runpy.run_path(str(ASSETS / 'qualification.py.txt'))
sources = qualification['current_identities'](ROOT)
expected = json.loads((HERE / 'expected-sources.json').read_bytes())
assert sources == expected and len(sources) == 1133
for name, digest in sources.items():
    body = subprocess.check_output(['git', 'show', head + ':' + name], cwd=ROOT)
    assert hashlib.sha256(body).hexdigest() == digest
old_pins = json.loads((ROOT / '.issue-11-evidence/issue159-c5-candidate3-transport1/pins.json').read_bytes())
recipe_path = ASSETS / 'c5-candidate4-recipe.json'
recipe = json.loads(recipe_path.read_bytes())
assert sha(recipe_path) == '8e29851e7b7d2fdf7534c3d66b31ee233a5cca4e7490ad75667808485e0eb42f'
assert recipe['preceding_reader'] == old_pins['preceding_reader']
assert qualification['tagged_identities'](recipe['preceding_reader']['tag']) == old_pins['preceding_sources']
for name, digest in old_pins['preceding_sources'].items():
    actual = Path(recipe['preceding_reader']['root']) / name
    assert sha(actual) == digest
for path, binding in old_pins['external_inputs'].items():
    actual = Path(path)
    assert actual.is_file() and not actual.is_symlink()
    assert actual.stat().st_size == binding['bytes'] and sha(actual) == binding['sha256']
listening = set()
for name in ('tcp', 'tcp6'):
    for line in (Path('/proc/net') / name).read_text().splitlines()[1:]:
        fields = line.split()
        if fields[3] == '0A':
            listening.add(int(fields[1].rsplit(':', 1)[1], 16))
ports = (8390, 8391, 5437)
assert not set(ports).intersection(listening)
assert json.loads(Path('/tmp/neistra159-editor-readiness-native-probe1/cleanup-before-raw-copy.json').read_bytes())['complete']
assert json.loads(Path('/tmp/neistra159-editor-readiness-native-probe2/cleanup-before-raw-copy.json').read_bytes())['complete']
seal = json.loads((PREP / 'handoff-seal.json').read_bytes())
for name, binding in seal['files'].items():
    assert (PREP / name).stat().st_size == binding['bytes'] and sha(PREP / name) == binding['sha256']
assert sha(ASSETS / 'c5-master1-recipe.json') == '3018bf0bca5d19951a6930aa54148aef0a0168a19f98d6f7d670715e7ec82db5'
OUT.mkdir()
for name in ('transport.py', 'observe.py', 'primary-terminal-collection.py'):
    shutil.copy2(PREP / name, OUT / name)
pins = {**old_pins, 'head': head, 'label': 'c5-candidate4', 'selected_sources': sources,
        'recipe_sha256': sha(recipe_path), 'transport_sha256': sha(OUT / 'transport.py'),
        'qualification_sha256': sha(ASSETS / 'qualification.py.txt'),
        'command': [str(ROOT / '.venv/bin/python'), '-B', str(ASSETS / 'qualification.py.txt'), str(recipe_path)]}
save(OUT / 'pins.json', pins)
WORK.mkdir()
transport = runpy.run_path(str(OUT / 'transport.py'))
actual_pins, actual_recipe, actual_command = transport['validate'](OUT / 'pins.json')
transport['fresh'](ROOT, actual_recipe)
assert actual_pins == pins and actual_recipe == recipe and actual_command == pins['command']
record = {'scope': 'Actual clean candidate4 pin/deployment/preflight only; no GO or launch',
          'recorded_utc': datetime.now(timezone.utc).isoformat(), 'candidate': head,
          'selected_sources': len(sources), 'source_digest_compact': hashlib.sha256(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
          'pins_sha256': sha(OUT / 'pins.json'), 'recipe_sha256': sha(recipe_path),
          'transport_sha256': sha(OUT / 'transport.py'), 'observer_sha256': sha(OUT / 'observe.py'),
          'collector_sha256': sha(OUT / 'primary-terminal-collection.py'),
          'all1133_actual_Git_disk_bodies_exact': True, 'preceding1013_extracted_bodies_exact': True,
          'external_receipt_exact': True, 'fresh_empty_workspace': str(WORK),
          'ports_unused_at_preparation': {str(port): True for port in ports},
          'transport_validate_and_fresh': 'PASS', 'SQL_opened': False,
          'GO_created_or_gate_launched': False, 'final_all7_readiness': False}
save(OUT / 'primary-prelaunch-readback.json', record)
print(json.dumps(record))
