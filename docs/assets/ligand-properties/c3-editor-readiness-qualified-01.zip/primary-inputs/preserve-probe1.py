"""Preserve the entire closed first diagnostic, including its failed assertion."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import stat
import zipfile

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots')
OUT = ROOT / '.issue-11-evidence/issue159-editor-readiness-native-probe1-preservation1'
WORK = Path('/tmp/neistra159-editor-readiness-native-probe1')
SOURCES = {
    'workspace': WORK,
    'preparation': ROOT / '.issue-11-evidence/issue159-editor-readiness-native-probe1',
    'primary-inputs': Path(__file__).resolve().parent,
}
assert not OUT.exists()
assert json.loads((WORK / 'terminal.json').read_bytes())['actual_wait_exit'] == 1
assert json.loads((WORK / 'cleanup-before-raw-copy.json').read_bytes())['complete']
raw = json.loads((WORK / 'raw-copy.json').read_bytes())['files']
assert len(raw) == 3
for name, binding in raw.items():
    a = WORK / 'e2e' / name
    b = WORK / 'post-cleanup-raw-database-bytes' / name
    assert a.read_bytes() == b.read_bytes()
    assert hashlib.sha256(a.read_bytes()).hexdigest() == binding['sha256']
OUT.mkdir()
tool = ROOT / 'docs/assets/ligand-properties/release-evidence.py.txt'
module = runpy.run_path(str(tool))

def snapshot():
    result = {}
    for label, base in SOURCES.items():
        for path in sorted(base.rglob('*')):
            relative = path.relative_to(base).as_posix()
            info = path.lstat()
            row = {'mode': info.st_mode, 'mtime_ns': info.st_mtime_ns,
                   'size': info.st_size, 'inode': info.st_ino}
            if stat.S_ISREG(info.st_mode):
                body = path.read_bytes()
                row.update(kind='file', sha256=hashlib.sha256(body).hexdigest())
            elif stat.S_ISDIR(info.st_mode):
                row.update(kind='directory', empty=not any(path.iterdir()))
            elif stat.S_ISLNK(info.st_mode):
                row.update(kind='inert_alias', target=os.readlink(path))
            else:
                raise AssertionError(f'Unexpected special member {path}')
            result[label + '/' + relative] = row
    return result

before = snapshot()
items = {}
for name, row in before.items():
    label, relative = name.split('/', 1)
    if row['kind'] == 'file':
        items[name] = SOURCES[label] / relative
    elif row['kind'] == 'inert_alias':
        items['inert-alias-descriptors/' + name + '.json'] = module['encoded'](row)
items['original-inventory.json'] = module['encoded'](before)
items['release-evidence-used.py.txt'] = tool
archive = module['archive'](items, OUT / 'failed-probe1-evidence.zip')
after = snapshot()
assert before == after
with zipfile.ZipFile(archive['path']) as z:
    manifest = json.loads(z.read('manifest.json'))
    assert set(manifest) == set(items)
    assert set(z.namelist()) == set(items) | {'manifest.json'}
    for name, row in before.items():
        if row['kind'] != 'file':
            continue
        label, relative = name.split('/', 1)
        body = (SOURCES[label] / relative).read_bytes()
        assert z.read(name) == body
        assert manifest[name] == {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
record = {'scope': 'Entire failed diagnostic1 retained; not native success or full qualification',
          'archive': archive, 'original_files': sum(r['kind'] == 'file' for r in before.values()),
          'empty_directories': sum(r['kind'] == 'directory' and r['empty'] for r in before.values()),
          'all_before_after_body_metadata_and_exact_union': True,
          'independent_all_original_body_archive_comparison': True,
          'raw_original_copy_pairs': 3, 'SQL_opened': False,
          'originals_retained': True, 'qualification_PASS': False}
(OUT / 'retention.json').write_bytes(module['encoded'](record))
print(json.dumps(record))
