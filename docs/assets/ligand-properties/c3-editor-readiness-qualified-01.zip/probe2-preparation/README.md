# Editor-readiness probe2 — static preparation only

Probe1 actually failed at its private fieldset assertion before reaching the
held-state child-N assertion, semantic readiness continuation or enumeration.
Its receipt records the real new-current-artifact response (4,377 bytes, HTTP200,
committed revision2), its hold and cleanup release. This is a diagnostic assertion
API error; it does not establish a product readiness/focus defect or a successful
native readiness measurement. The original kit and original outputs remain intact.

Installed Playwright1.55 routes `to.be.disabled` through `getAriaDisabled`.
`isNativelyDisabled` restricts native controls to BUTTON, INPUT, SELECT, TEXTAREA,
OPTION and OPTGROUP. FIELDSET itself is excluded. Thus the native matcher can
report a fieldset enabled despite its actual `disabled` attribute. Buttons remain
covered by their own attribute and disabled ancestor fieldset. The closed actual
trace's `after@call@108` target snapshot verifies `disabled: ""`; another full Atoms
snapshot independently records that same empty value. The installed-library
binding, extracted original functions and exact trace/receipt bindings are retained
in the accompanying metadata. No library function was executed for these checks.

The only assertion changes are the fieldset group calls:

```ts
await expect(panel.getByRole("group", { name: "Atoms", exact: true })).toHaveAttribute("disabled");
// After delivering the same actual response:
await expect(panel.getByRole("group", { name: "Atoms", exact: true })).not.toHaveAttribute("disabled");
```

Per architecture review, these assert attribute presence and complete absence
under every serialization, independent of the verified original empty value.
The exact child N disabled/enabled guards, O enabled/C disabled checks and native
fieldset `.disabled` property proof remain unchanged. Exact inverse-byte checks
prove every other assertion, deadline, real +H workflow, response hold/hash,
25-control enumeration, focus/bounds/hit tests, source guard and cleanup matches
the original sealed probe after only declared directory/workspace/port substitutions.
No requirement, assertion set, retry policy or deadline is reduced.

The primary reports completed failed-probe1 retention: 19,993,645 bytes,
SHA`5096cfae6f156019776ac18893ae792762ca6a4ff9c54fe85fc4b1ca65d54e51`,
967 original files, eight empty directories and three raw pairs. Before actual
probe2 execution, the primary agent must review these sealed static inputs. Probe1 must never
be rerun or overwritten. The canonical source remains the primary's already
installed guard-only working file SHA
`75ed41b0e75e67cd92a3056311fc98785e0414ee6576aec0abe0e4bb24a19eb0`;
this preparation makes no canonical or application change.

Planned fresh workspace `/tmp/neistra159-editor-readiness-native-probe2` and ports
API8410/worker8411/web5439 have not been created, reserved or probed by this work.
The root base config still supplies all three actual services with reuse disabled.
Root owns the future one-shot runner, positive service/browser cleanup, original
raw-store copies before diagnostic SQL and independent evidence readback.

Future invocation, **not executed here**, from the explicit corrective root:

```sh
env -u DATABASE_URL -u NEISTRA_DATABASE_URL -u MOLWEAVE_DATABASE_URL \
  -u MOLWEAVE_E2E_DATA_DIR -u MOLWEAVE_E2E_API_PORT \
  -u MOLWEAVE_E2E_WORKER_PORT -u MOLWEAVE_E2E_WEB_PORT \
  -u NEISTRA_PROPERTY_WORKER_TRACE \
  NEISTRA_READINESS_PROBE_ENABLE=after-preservation-and-canonical-N-guard \
  NEISTRA_E2E_DATA_DIR=/tmp/neistra159-editor-readiness-native-probe2/e2e \
  NEISTRA_E2E_API_PORT=8410 NEISTRA_E2E_WORKER_PORT=8411 \
  NEISTRA_E2E_WEB_PORT=5439 NEISTRA_PERFORMANCE=0 \
  corepack pnpm exec playwright test \
  --config .issue-11-evidence/issue159-editor-readiness-native-probe2/playwright.config.ts \
  --project chromium --workers=1 --retries=0 --max-failures=1
```

The spec is deliberately bound to actual light100% browser zoom, original source,
actual molecular responses and the entire25-control set. Future outcomes remain
unknown. Static TypeScript/import/AST checks and inverse-byte controls do not
execute either probe entrypoint, any service or any application test. The whole
canonical file across both themes/zooms and all candidate/merged/release gates
remain separate required work.
