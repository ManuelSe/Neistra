import { defineConfig } from "@playwright/test";
import { resolve } from "node:path";
import base from "../../playwright.config";

// Preparation only: importing this configuration is not an execution authorization.
const root = "/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots";
if (process.cwd() !== root) throw new Error("Run the private probe from its explicit corrective root");
const directory = resolve(root, ".issue-11-evidence/issue159-editor-readiness-native-probe2");
const workspace = "/tmp/neistra159-editor-readiness-native-probe2";
const required = {
  NEISTRA_READINESS_PROBE_ENABLE: "after-preservation-and-canonical-N-guard",
  NEISTRA_E2E_DATA_DIR: `${workspace}/e2e`,
  NEISTRA_E2E_API_PORT: "8410",
  NEISTRA_E2E_WORKER_PORT: "8411",
  NEISTRA_E2E_WEB_PORT: "5439",
};
for (const [name, value] of Object.entries(required)) {
  if (process.env[name] !== value) throw new Error(`Explicit probe input required: ${name}`);
}
for (const name of ["NEISTRA_PROPERTY_WORKER_TRACE", "DATABASE_URL", "NEISTRA_DATABASE_URL",
  "MOLWEAVE_DATABASE_URL", "MOLWEAVE_E2E_DATA_DIR", "MOLWEAVE_E2E_API_PORT",
  "MOLWEAVE_E2E_WORKER_PORT", "MOLWEAVE_E2E_WEB_PORT"]) {
  if (process.env[name] !== undefined) throw new Error(`Remove unrelated probe override: ${name}`);
}
if (process.env.NEISTRA_PERFORMANCE !== undefined && process.env.NEISTRA_PERFORMANCE !== "0") {
  throw new Error("This diagnostic does not enable performance qualification");
}
const servers = Array.isArray(base.webServer) ? base.webServer : [base.webServer];
if (servers.length !== 3 || servers.some(server => !server)) throw new Error("Expected the three unchanged root services");
const projects = base.projects!.filter(project => project.name === "chromium");
if (projects.length !== 1) throw new Error("Expected exactly the original desktop chromium project");

export default defineConfig({
  ...base,
  testDir: directory,
  testMatch: "editor-readiness.spec.ts",
  outputDir: `${workspace}/test-results`,
  fullyParallel: false,
  workers: 1,
  retries: 0,
  maxFailures: 1,
  reporter: [["line"], ["json", { outputFile: `${workspace}/browser-report.json` }]],
  use: { ...base.use, trace: "on" },
  projects,
  webServer: servers.map(server => ({ ...server!, cwd: root, reuseExistingServer: false })),
});
