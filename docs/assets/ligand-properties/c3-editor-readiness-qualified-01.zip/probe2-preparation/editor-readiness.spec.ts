import { chromium, expect, test, type Locator, type Worker } from "@playwright/test";
import { createHash } from "node:crypto";
import { mkdtemp, readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import type { Project, StructureProjection } from "../../apps/web/src/api/types";
import { addOneHydrogen } from "../../tests/e2e/support/hydrogen";
import { prepare } from "../../tests/e2e/support/interactions";

const root = "/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots";
const workspace = "/tmp/neistra159-editor-readiness-native-probe2";
const controlsSelector = "button:visible:enabled, summary:visible";
const hash = (bytes: Buffer | string) => createHash("sha256").update(bytes).digest("hex");

interface ZoomAPI {
  tabs: {
    query(query: object): Promise<{ id: number; url?: string }[]>;
    setZoom(id: number, factor: number): Promise<void>;
    getZoom(id: number): Promise<number>;
  };
}

// Same extension API and actual browser zoom operation as the canonical scenario.
async function setZoom(worker: Worker, url: string, factor: number) {
  return worker.evaluate(async ({ url, factor }) => {
    const chrome = (globalThis as unknown as { chrome: ZoomAPI }).chrome;
    const tab = (await chrome.tabs.query({})).find(tab => tab.url?.startsWith(url));
    if (!tab) throw new Error("Qualification tab not found");
    await chrome.tabs.setZoom(tab.id, factor);
    return chrome.tabs.getZoom(tab.id);
  }, { url, factor });
}

async function identities(controls: Locator) {
  return controls.evaluateAll(nodes => nodes.map(node => ({
    tag: node.tagName.toLowerCase(),
    label: (node.getAttribute("aria-label") ?? node.textContent ?? "").replace(/\s+/g, " ").trim(),
  })));
}

test("waits for a real held current-artifact projection before enumerating Atoms controls", async ({ request, baseURL }, info) => {
  // Keep the canonical scenario deadline and its 10s action / inherited 15s expect limits.
  test.setTimeout(180000);
  expect(info.project.name).toBe("chromium");
  expect(baseURL).toBe("http://127.0.0.1:5439");
  const canonicalPath = resolve(root, "tests/e2e/rebranding-zoom.spec.ts");
  const canonicalBefore = await readFile(canonicalPath);
  expect(hash(canonicalBefore), "Run the explicitly inspected guard-only canonical source").toBe("75ed41b0e75e67cd92a3056311fc98785e0414ee6576aec0abe0e4bb24a19eb0");
  const canonicalText = canonicalBefore.toString("utf8");
  const guardedSection = /for \(const section of \["Atoms", "Bonds", "Fragments", "Residues"\]\) \{\s*await panel\.getByRole\("button", \{ name: section, exact: true \}\)\.click\(\);\s*if \(section === "Atoms"\)\s*(?:\{\s*)?await expect\(panel\.getByRole\("button", \{ name: "Replace selected atom with N", exact: true \}\)\)\.toBeEnabled\(\);\s*(?:\}\s*)?for \(const control of await panel\.locator\("button:visible:enabled, summary:visible"\)\.all\(\)\)/;
  expect(canonicalText, "Root must preserve the failure and install the bounded canonical N guard first").toMatch(guardedSection);

  const extension = resolve(root, "tests/e2e/support/zoom-extension");
  const profile = await mkdtemp(join(workspace, "browser-profile-"));
  const context = await chromium.launchPersistentContext(profile, {
    channel: "chromium", headless: true, viewport: null, deviceScaleFactor: undefined, baseURL,
    args: ["--window-size=1440,1000", `--disable-extensions-except=${extension}`, `--load-extension=${extension}`,
      "--enable-webgl", "--ignore-gpu-blocklist", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
  });
  const page = context.pages()[0];
  page.setDefaultTimeout(10000);
  const events: { sequence: number; name: string; details?: unknown }[] = [];
  const event = (name: string, details?: unknown) => events.push({ sequence: events.length, name, details });
  const holds: { artifact: string; request_url: string; response_status: number; response_sha256: string; response_bytes: number; committed_revision: number; released: boolean }[] = [];
  const pendingRoutes: Promise<void>[] = [];
  const writes: { url: string; body: unknown; attempt: string | undefined }[] = [];
  const failures: unknown[] = [];
  const receipt: Record<string, unknown> = { status: "not completed", scope: "single real-browser light 100% held-projection diagnostic", events, holds, writes,
    canonical_source_before_sha256: hash(canonicalBefore), original_failed_candidate: "dfeb499aef32a8b53715a65f00cfa056951fb231",
    no_full_feature_or_release_claim: true };
  let release!: () => void;
  const released = new Promise<void>(resolve => { release = resolve; });
  let enumerationReached = false;
  let readinessOutcome: Promise<{ error?: unknown }> | undefined;
  try {
    const worker = context.serviceWorkers()[0] ?? await context.waitForEvent("serviceworker");
    const project = await prepare(page, request, ["tests/fixtures/editing/ethanol-3d.mol"], "Edit zoom readiness diagnostic");
    const entry = project.entries[0];
    expect(project.entries).toHaveLength(1);
    const path = `/api/v1/projects/${project.id}`;
    const endpoint = `${path}/entries/${entry.id}/structure`;
    const current = async () => {
      const response = await request.get(path); expect(response.ok()).toBe(true);
      return await response.json() as Project;
    };
    const original = async () => {
      const response = await request.get(`${path}/entries/${entry.id}/original`); expect(response.ok()).toBe(true);
      return response.body();
    };
    const originalBefore = await original();
    const baselineResponse = await request.get(`${endpoint}?${new URLSearchParams({ expected_artifact_id: entry.current_artifact_id! })}`);
    expect(baselineResponse.ok()).toBe(true);
    const baseline = await baselineResponse.json() as StructureProjection;
    expect(baseline.entry_id).toBe(entry.id);
    expect(baseline.artifact_id).toBe(entry.current_artifact_id);
    expect(baseline.structure.atoms.find(atom => atom.id === 1)?.element).toBe("C");
    receipt.baseline = { project_id: project.id, revision: project.revision, entry_id: entry.id,
      artifact_id: baseline.artifact_id, original_artifact_id: entry.original_artifact_id,
      original_bytes: originalBefore.length, original_sha256: hash(originalBefore), atoms: baseline.structure.atoms.length };

    // The same actual selection and +H workflow; no molecular API data is synthesized.
    if (await page.getByRole("button", { name: "Inspector", exact: true }).isVisible()) await page.getByRole("button", { name: "Inspector", exact: true }).click();
    await page.getByRole("tab", { name: "selection", exact: true }).click();
    await page.getByRole("combobox", { name: "Select by", exact: true }).selectOption("atom_reference");
    await page.getByRole("textbox", { name: "Value", exact: true }).fill(`${entry.id}:1`);
    await page.getByRole("button", { name: "Apply query", exact: true }).click();
    if (await page.locator(".mobile-panel").isVisible()) await page.getByRole("button", { name: "Close panel", exact: true }).click({ position: { x: 2, y: 100 } });
    const launcher = page.getByRole("button", { name: "Edit molecule", exact: true });
    await launcher.click();
    const panel = page.getByRole("dialog", { name: "Edit molecule", exact: true });
    const nitrogen = panel.getByRole("button", { name: "Replace selected atom with N", exact: true });
    const oxygen = panel.getByRole("button", { name: "Replace selected atom with O", exact: true });
    const carbon = panel.getByRole("button", { name: "Replace selected atom with C", exact: true });
    await expect(nitrogen).toBeEnabled();
    await expect(carbon).toBeDisabled();
    event("initial selected C1 projection ready");

    context.on("request", outgoing => {
      if (outgoing.method() === "POST" && new URL(outgoing.url()).pathname === `${path}/entries/${entry.id}/model-edits`) {
        writes.push({ url: outgoing.url(), body: outgoing.postDataJSON(), attempt: outgoing.headers()["x-neistra-edit-attempt"] });
      }
    });
    await context.route(url => url.pathname === endpoint, route => {
      const job = (async () => {
        const outgoing = route.request();
        const artifact = new URL(outgoing.url()).searchParams.get("expected_artifact_id");
        if (outgoing.method() !== "GET" || artifact === baseline.artifact_id) { await route.continue(); return; }
        expect(artifact, "Only an explicitly identified immutable structure read may be held").toBeTruthy();
        const response = await route.fetch({ maxRetries: 0 });
        expect(response.ok()).toBe(true);
        const bytes = await response.body();
        const projection = JSON.parse(bytes.toString("utf8")) as StructureProjection;
        const committed = await current();
        expect(committed.revision).toBe(project.revision + 1);
        expect(committed.entries.find(candidate => candidate.id === entry.id)?.current_artifact_id).toBe(artifact);
        expect(projection.entry_id).toBe(entry.id);
        expect(projection.artifact_id).toBe(artifact);
        expect(projection.projection_state).not.toBe("coordinate-seed");
        const record = { artifact: artifact!, request_url: outgoing.url(), response_status: response.status(),
          response_sha256: hash(bytes), response_bytes: bytes.length, committed_revision: committed.revision, released: false };
        holds.push(record);
        await info.attach(`actual-held-structure-${holds.length}.json`, { body: bytes, contentType: "application/json" });
        event("real committed current-artifact response fetched and held", record);
        await released;
        // Fulfill directly with the fetched response: no fabricated or edited molecular body.
        await route.fulfill({ response });
        record.released = true;
        event("same actual response delivered", { artifact, response_sha256: record.response_sha256 });
      })();
      pendingRoutes.push(job);
      return job;
    });

    await addOneHydrogen(page);
    await expect(page.getByText(/Molecular edit stored/)).toBeVisible();
    await expect.poll(() => holds.length).toBeGreaterThan(0);
    await panel.getByRole("button", { name: "Close molecular editor" }).click();
    expect(await page.locator("html").getAttribute("data-theme")).toBe("light");
    expect(await setZoom(worker, baseURL!, 1)).toBe(1);
    await expect.poll(() => page.evaluate(() => devicePixelRatio)).toBe(1);
    await expect.poll(() => page.evaluate(() => innerWidth)).toBe(1440);
    await launcher.focus(); await page.keyboard.press("Enter");
    await expect(panel).toBeFocused();
    await panel.getByRole("button", { name: "Atoms", exact: true }).click();
    await expect(panel.getByLabel("Current target chemistry", { exact: true })).toHaveText("Loading current target…");
    await expect(panel.getByRole("group", { name: "Atoms", exact: true })).toHaveAttribute("disabled");
    await expect(nitrogen).toBeDisabled();
    const loadingIdentities = await identities(panel.locator(controlsSelector));
    receipt.loading_controls = loadingIdentities;
    event("held projection visibly loading with disabled Atoms and N", { count: loadingIdentities.length });

    // The continuation cannot enumerate until this exact semantic prerequisite passes.
    event("semantic N readiness wait started");
    const readiness = (async () => {
      await expect(nitrogen).toBeEnabled();
      event("semantic N readiness wait completed");
      enumerationReached = true;
      event("loaded control enumeration reached");
      const loaded = await identities(panel.locator(controlsSelector));
      receipt.loaded_controls = loaded;
      // Preserve every observed control; fail visibly if this fixture differs from the actual trace's 25.
      expect(loaded).toHaveLength(25);
      const focused: unknown[] = [];
      receipt.focused_controls = focused;
      let index = 0;
      for (const control of await panel.locator("button:visible:enabled, summary:visible").all()) {
        expect((await identities(control))[0]).toEqual(loaded[index]);
        await control.focus();
        await expect(control).toBeFocused();
        expect(await control.evaluate(node => {
          const b = node.getBoundingClientRect();
          return b.x >= 0 && b.right <= innerWidth && b.y >= 0 && b.bottom <= innerHeight &&
            node.contains(document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2));
        })).toBe(true);
        expect((await identities(control))[0]).toEqual(loaded[index]);
        focused.push({ index, ...loaded[index] });
        index++;
      }
      expect(focused).toHaveLength(loaded.length);
      expect(await identities(panel.locator(controlsSelector))).toEqual(loaded);
    })();
    // Retain rejection immediately and propagate it after safe route teardown, never ignore it.
    readinessOutcome = readiness.then(() => ({}), error => ({ error }));
    await expect(nitrogen).toBeDisabled();
    const heldBrowserState = await panel.evaluate(node => ({
      target: node.querySelector('[aria-label="Current target chemistry"]')?.textContent,
      nitrogenDisabled: node.querySelector('button[aria-label="Replace selected atom with N"]')?.matches(":disabled"),
      fieldsetDisabled: node.querySelector('button[aria-label="Replace selected atom with N"]')?.closest("fieldset")?.disabled,
    }));
    expect(heldBrowserState).toEqual({ target: "Loading current target…", nitrogenDisabled: true, fieldsetDisabled: true });
    expect(enumerationReached).toBe(false);
    expect(events.some(item => item.name === "semantic N readiness wait completed")).toBe(false);
    expect(holds.every(item => !item.released)).toBe(true);
    receipt.held_browser_state = heldBrowserState;
    event("enumeration blocked while actual response held", heldBrowserState);
    release(); event("held-response release requested");
    const outcome = await readinessOutcome;
    if (outcome.error !== undefined) throw outcome.error;
    await expect(nitrogen).toBeEnabled(); await expect(oxygen).toBeEnabled(); await expect(carbon).toBeDisabled();
    await expect(panel.getByRole("group", { name: "Atoms", exact: true })).not.toHaveAttribute("disabled");
    await expect.poll(() => holds.every(item => item.released)).toBe(true);
    expect(new Set(holds.map(item => item.artifact)).size).toBe(1);
    const after = await current();
    expect(after.revision).toBe(project.revision + 1);
    expect(after.entries).toHaveLength(1);
    expect(after.entries[0].original_artifact_id).toBe(entry.original_artifact_id);
    expect(after.entries[0].current_artifact_id).toBe(holds[0].artifact);
    expect(after.entries[0].current_artifact_id).not.toBe(baseline.artifact_id);
    expect(writes).toHaveLength(1);
    expect(writes[0].body).toMatchObject({ expected_revision: project.revision, expected_artifact_id: baseline.artifact_id,
      action: { operation: "hydrogens.add_one" }, selection: { atoms: [{ structure_id: entry.id, atom_id: 1 }] } });
    expect(writes[0].attempt).toMatch(/^[a-f0-9-]{36}$/i);
    const afterResponse = await request.get(`${endpoint}?${new URLSearchParams({ expected_artifact_id: holds[0].artifact })}`);
    expect(afterResponse.ok()).toBe(true);
    const afterBytes = await afterResponse.body();
    const afterProjection = JSON.parse(afterBytes.toString("utf8")) as StructureProjection;
    expect(afterProjection.artifact_id).toBe(holds[0].artifact);
    expect(afterProjection.structure.atoms).toHaveLength(baseline.structure.atoms.length + 1);
    expect(afterProjection.structure.atoms.filter(atom => atom.element === "H")).toHaveLength(baseline.structure.atoms.filter(atom => atom.element === "H").length + 1);
    expect(afterProjection.structure.atoms.filter(atom => baseline.structure.atoms.some(before => before.id === atom.id)))
      .toEqual(baseline.structure.atoms);
    const added = afterProjection.structure.atoms.filter(atom => !baseline.structure.atoms.some(before => before.id === atom.id));
    expect(added).toHaveLength(1); expect(added[0].element).toBe("H");
    expect(afterProjection.structure.bonds).toHaveLength(baseline.structure.bonds.length + 1);
    expect(afterProjection.structure.bonds.some(bond => (bond.atom_1_id === 1 && bond.atom_2_id === added[0].id) || (bond.atom_2_id === 1 && bond.atom_1_id === added[0].id))).toBe(true);
    const originalAfter = await original(); expect(originalAfter).toEqual(originalBefore);
    receipt.after = { revision: after.revision, artifact_id: afterProjection.artifact_id, original_sha256: hash(originalAfter),
      canonical_response_sha256: hash(afterBytes), added_hydrogen_id: added[0].id };
    await page.screenshot({ path: info.outputPath("light-100-loaded-atoms.png") });
    receipt.status = "all diagnostic assertions completed";
  } catch (error) { failures.push(error); }
  finally {
    // Release first, then wait for all owned handlers before trace/context closure.
    release();
    for (const cleanup of [
      () => context.unrouteAll({ behavior: "wait" }),
      () => page.unrouteAll({ behavior: "wait" }),
      async () => {
        const errors = (await Promise.allSettled(pendingRoutes)).flatMap(outcome => outcome.status === "rejected" ? [outcome.reason] : []);
        if (errors.length) throw new AggregateError(errors, "Actual structure response route failures");
      },
      async () => { const outcome = await readinessOutcome; if (outcome?.error !== undefined) throw outcome.error; },
      async () => { const canonicalAfter = await readFile(canonicalPath); receipt.canonical_source_after_sha256 = hash(canonicalAfter); expect(canonicalAfter).toEqual(canonicalBefore); },
    ]) {
      try { await cleanup(); } catch (error) { failures.push(error); }
    }
    receipt.failures = failures.map(error => error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : String(error));
    receipt.status = failures.length ? "diagnostic failed; inspect original errors" : receipt.status;
    event("routes released and teardown awaited", { failures: failures.length });
    try {
      const bytes = Buffer.from(JSON.stringify(receipt, null, 2) + "\n");
      await writeFile(info.outputPath("readiness-receipt.json"), bytes);
      await info.attach("readiness-receipt.json", { body: bytes, contentType: "application/json" });
    } catch (error) { failures.push(error); }
    finally { try { await context.close(); } catch (error) { failures.push(error); } }
  }
  if (failures.length) throw new AggregateError(failures, "Held current-projection readiness diagnostic failed");
});
