// Static adaptation and installed-library AST inspection; never imports a probe.
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const directory = dirname(fileURLToPath(import.meta.url));
const root = resolve(directory, "../..");
const original = resolve(root, ".issue-11-evidence/issue159-editor-readiness-native-probe1");
const ts = createRequire(resolve(root, "apps/web/package.json"))("typescript");
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const originalSeal = readFileSync(resolve(original, "seal.json"));
assert.equal(sha(originalSeal), "8a39197fcda94e2cf00949f2057f569a40448eca64301f1477f315a8c410b560");
for (const file of JSON.parse(originalSeal).files) {
  const bytes = readFileSync(resolve(original, file.path));
  assert.equal(bytes.length, file.bytes); assert.equal(sha(bytes), file.sha256);
}
const substitutions = [
  ["issue159-editor-readiness-native-probe1", "issue159-editor-readiness-native-probe2"],
  ["neistra159-editor-readiness-native-probe1", "neistra159-editor-readiness-native-probe2"],
  ["8390", "8410"], ["8391", "8411"], ["5437", "5439"],
];
const changes = [
  ['await expect(panel.getByRole("group", { name: "Atoms", exact: true })).toBeDisabled();',
    'await expect(panel.getByRole("group", { name: "Atoms", exact: true })).toHaveAttribute("disabled");'],
  ['await expect(panel.getByRole("group", { name: "Atoms", exact: true })).toBeEnabled();',
    'await expect(panel.getByRole("group", { name: "Atoms", exact: true })).not.toHaveAttribute("disabled");'],
];
const files = [];
for (const name of ["editor-readiness.spec.ts", "playwright.config.ts", "static-validate.mjs"]) {
  const prior = readFileSync(resolve(original, name), "utf8");
  const current = readFileSync(resolve(directory, name), "utf8");
  let inverse = current;
  for (const [before, after] of [...substitutions].reverse()) inverse = inverse.replaceAll(after, before);
  if (name === "editor-readiness.spec.ts") for (const [before, after] of changes) {
    assert.equal(inverse.split(after).length - 1, 1);
    inverse = inverse.replace(after, before);
  }
  assert.equal(inverse, prior, `${name}: no additional byte delta authorized`);
  files.push({ path: name, original_sha256: sha(prior), adapted_sha256: sha(current), inverse_exact_original_bytes: true });
}
const spec = readFileSync(resolve(directory, "editor-readiness.spec.ts"), "utf8");
for (const statement of [
  'await expect(nitrogen).toBeDisabled();', 'await expect(nitrogen).toBeEnabled();',
  'await expect(oxygen).toBeEnabled();', 'await expect(carbon).toBeDisabled();',
  'fieldsetDisabled: node.querySelector(\'button[aria-label="Replace selected atom with N"]\')?.closest("fieldset")?.disabled,',
  'expect(heldBrowserState).toEqual({ target: "Loading current target…", nitrogenDisabled: true, fieldsetDisabled: true });',
]) assert(spec.includes(statement), `Retain actual child and DOM-property prerequisite: ${statement}`);

const generatedPath = "node_modules/.pnpm/playwright-core@1.55.0/node_modules/playwright-core/lib/generated/injectedScriptSource.js";
const generated = readFileSync(resolve(root, generatedPath), "utf8");
const generatedAST = ts.createSourceFile(generatedPath, generated, ts.ScriptTarget.Latest, true);
let source;
for (const statement of generatedAST.statements) if (ts.isVariableStatement(statement)) {
  for (const item of statement.declarationList.declarations) if (item.name.getText(generatedAST) === "source") {
    assert(ts.isStringLiteral(item.initializer)); source = item.initializer.text;
  }
}
assert(source);
const injectedAST = ts.createSourceFile("decoded-installed-injected.js", source, ts.ScriptTarget.Latest, true);
const declarations = new Map(injectedAST.statements.filter(ts.isFunctionDeclaration).map(node => [node.name?.text, node]));
const snippets = {};
for (const name of ["getAriaDisabled", "isNativelyDisabled", "belongsToDisabledFieldSet"]) {
  assert(declarations.has(name)); snippets[name] = declarations.get(name).getText(injectedAST);
}
let nativeTags;
const visit = node => {
  if (ts.isVariableDeclaration(node) && node.name.getText(injectedAST) === "isNativeFormControl") {
    const call = node.initializer;
    assert(ts.isCallExpression(call)); assert(ts.isPropertyAccessExpression(call.expression));
    assert(ts.isArrayLiteralExpression(call.expression.expression));
    nativeTags = call.expression.expression.elements.map(item => item.text);
  }
  ts.forEachChild(node, visit);
};
visit(declarations.get("isNativelyDisabled"));
assert.deepEqual(nativeTags, ["BUTTON", "INPUT", "SELECT", "TEXTAREA", "OPTION", "OPTGROUP"]);
assert(!nativeTags.includes("FIELDSET")); assert(nativeTags.includes("BUTTON"));
assert(source.includes('if (state === "disabled" || state === "enabled") {\n      const disabled = getAriaDisabled(element);'));
assert(source.includes('expression === "to.be.disabled") {\n        result = this.elementState(element, "disabled");'));
assert(snippets.belongsToDisabledFieldSet.includes('element.closest("FIELDSET[DISABLED]")'));
const matcherPath = "node_modules/.pnpm/playwright@1.55.0/node_modules/playwright/lib/matchers/matchers.js";
const matcherSource = readFileSync(resolve(root, matcherPath), "utf8");
const matcherAST = ts.createSourceFile(matcherPath, matcherSource, ts.ScriptTarget.Latest, true);
const attributeMatcher = matcherAST.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === "toHaveAttribute");
assert(attributeMatcher);
assert(attributeMatcher.getText(matcherAST).includes('if (expected === void 0)'));
assert(attributeMatcher.getText(matcherAST).includes('locator._expect("to.have.attribute", { expressionArg: name, isNot, timeout })'));
assert(source.includes('if (expression === "to.have.attribute") {\n        const hasAttribute = element.hasAttribute(options.expressionArg);'));
const failure = JSON.parse(readFileSync(resolve(directory, "probe1-failure-binding.json")));
assert.equal(failure.actual_failed_target_snapshot.attributes.disabled, "");
assert.equal(failure.actual_failed_target_snapshot.attributes.__playwright_target__, "call@108");
assert.equal(failure.actual_failed_target_snapshot.snapshot_name, "after@call@108");
assert.equal(failure.actual_Atoms_snapshot.attributes.disabled, "");
const report = {
  status: "STATIC adaptation only; native probe2 unexecuted",
  original_probe1_preserved_and_still_failed: true,
  original_seal_sha256: sha(originalSeal),
  substitutions, exact_two_fieldset_matcher_changes: changes,
  files, no_other_assertion_deadline_route_workflow_or_cleanup_delta: true,
  child_N_O_C_matchers_and_DOM_fieldset_property_proof_retained: true,
  installed_Playwright: { version: "1.55.0", path: generatedPath, file_sha256: sha(generated), decoded_source_sha256: sha(source),
    native_disabled_tags: nativeTags, fieldset_excluded: true, button_included: true,
    matcher_disabled_state_uses_getAriaDisabled: true, original_function_snippets: snippets },
  actual_empty_disabled_attribute_verified_in_closed_original_trace: true,
  installed_attribute_presence_matcher: { path: matcherPath, sha256: sha(matcherSource),
    no_expected_value_uses_to_have_attribute: true, injected_expression_uses_actual_DOM_hasAttribute: true,
    absence_via_isNot_preserved: true },
  new_fieldset_guards: { loading: 'toHaveAttribute("disabled")', loaded: 'not.toHaveAttribute("disabled")',
    basis: "Explicit attribute presence then absence for every serialization; actual original empty value also verified. Child disabled semantics and DOM property proof remain required" },
  no_entrypoint_or_library_function_executed: true,
};
writeFileSync(resolve(directory, "adaptation-proof.json"), JSON.stringify(report, null, 2) + "\n");
process.stdout.write(JSON.stringify({ status: report.status, exact_inverse_files: files.length, matcher_changes: changes.length, installed_FIELDSET_excluded: true, actual_empty_attribute: true }) + "\n");
