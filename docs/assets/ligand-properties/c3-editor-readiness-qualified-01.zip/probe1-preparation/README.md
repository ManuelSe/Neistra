# Private editor-readiness native probe — preparation only

This directory contains an unexecuted diagnostic for the loading prerequisite
identified in the failed original c5-candidate3 campaign at
`dfeb499aef32a8b53715a65f00cfa056951fb231`. It does not qualify that failed
campaign, certify a fix, or establish product focus failure. Its source bindings
and static validation describe preparation, not native measurement.

The original failure's selected trace records show a positional locator created
from 14 enabled/visible controls while current chemistry was loading. The same
position later resolved within 25 controls after projection completion. The
primary diagnosis records the limits of that observation, including the absence
of an independently recorded final active element. The original failure and all
unrun workload retain their actual classification.

## Execution barriers

The primary agent reports complete original c5-candidate3 failure retention and
independent readback `517146e2f35fc2abf5f2b556166aff0e19b25e5ae3dc1f01305a0aa40fb758a7`.
Only afterward, the primary agent installed the accepted canonical test-only
prerequisite after clicking Atoms, immediately before its unchanged `.all()` loop:

```ts
if (section === "Atoms") {
  await expect(panel.getByRole("button", { name: "Replace selected atom with N", exact: true })).toBeEnabled();
}
```

The actual corrected canonical SHA is
`75ed41b0e75e67cd92a3056311fc98785e0414ee6576aec0abe0e4bb24a19eb0`.
Static removal of only those three added lines reconstructs the original
`5002451820458969f3da28ba6aceaa0a6cdb9753040e33745b632663f610c0bd`.
Those are actual source bindings; the probe remains unexecuted.

The private spec verifies that exact semantic guard occupies the required
canonical location before launching its own browser. The configuration also
requires an explicit execution token. Neither mechanism replaces the primary
agent's preservation and source-diff review. No preparation command runs this
configuration or spec, reserves ports, or creates the planned workspace.

## Planned resources and launch

Run only from `/datadisk/dev/neistra-worktrees/issue-159-observer-snapshots`.
The primary agent must independently confirm fresh, owned resources before the
future invocation: `/tmp/neistra159-editor-readiness-native-probe1`, API 8390,
worker health 8391, web 5437. These names are planned, not reserved or probed.
The next candidate4 gate plans these same ports. The focused probe must finish
with positive complete owned-service cleanup before candidate4; concurrent use
is prohibited even though the two planned workspaces differ.
Do not reuse an existing data directory or service. The root Playwright config
provides the real migrations/API, real worker and real Vite proxy commands;
the private config changes their working directory and disables server reuse.
It selects the original desktop project, one worker, zero retries and one maximum
failure. Root expect/service deadlines remain unchanged. The spec preserves the
canonical 180-second scenario limit and 10-second action limit. Trace mode `on`
retains the diagnostic even if it passes; Playwright 1.55 automatically traces
the persistent browser context, so the spec does not start a competing trace.

Future command, **not executed during preparation**:

```sh
env -u DATABASE_URL -u NEISTRA_DATABASE_URL -u MOLWEAVE_DATABASE_URL \
  -u MOLWEAVE_E2E_DATA_DIR -u MOLWEAVE_E2E_API_PORT \
  -u MOLWEAVE_E2E_WORKER_PORT -u MOLWEAVE_E2E_WEB_PORT \
  -u NEISTRA_PROPERTY_WORKER_TRACE \
  NEISTRA_READINESS_PROBE_ENABLE=after-preservation-and-canonical-N-guard \
  NEISTRA_E2E_DATA_DIR=/tmp/neistra159-editor-readiness-native-probe1/e2e \
  NEISTRA_E2E_API_PORT=8390 NEISTRA_E2E_WORKER_PORT=8391 \
  NEISTRA_E2E_WEB_PORT=5437 NEISTRA_PERFORMANCE=0 \
  corepack pnpm exec playwright test \
  --config .issue-11-evidence/issue159-editor-readiness-native-probe1/playwright.config.ts \
  --project chromium --workers=1 --retries=0 --max-failures=1
```

The output report, browser profile and test artifacts remain beneath the planned
fresh workspace. No runtime payload belongs inside this sealed preparation.

## What the future native diagnostic actually exercises

It reuses the canonical `prepare` and `addOneHydrogen` helpers for an actual
project, actual ethanol-3d upload, actual C1 atom-reference selection, real +H
commit, close/reopen editor and light-theme 100% actual browser zoom. The extension
zoom helper is AST-identical to the canonical helper; native DPR and inner width
are asserted. The canonical preparation helper instruments the viewer JavaScript
mount exactly as in the original workflow; it does not fabricate molecular API
responses. The probe never imports the original registering spec.

After initial molecular source readiness, the new context route fetches an actual
post-commit structure response. It validates entry, immutable requested artifact,
actual current project artifact and exactly one revision increment. It records
the unedited response bytes, SHA-256, status and artifact identity, then holds
delivery. Every concurrent matching new-current-artifact response uses the same
hold; unexpected identities fail rather than being treated as ready. Original
artifact reads continue normally. No API result, cache entry, React state or
molecular body is rewritten.

While delivery remains held, assertions require visible `Loading current target…`,
the disabled Atoms fieldset and disabled exact N control. The semantic N-enabled
wait starts with its enumeration continuation attached. A fresh browser-state
read proves loading/disabled state and that enumeration has not been reached.
No fixed sleep, retry, deadline extension or synthetic response establishes this
barrier. Releasing the same real response permits the wait and enumeration.

The loaded snapshot must contain all 25 controls observed for the actual fixture.
Each real tag/label is retained. The unchanged original enabled-control locator,
focus assertion and viewport bounds/hit-test statements then run over the whole
enumeration. Additional identity assertions expose positional changes rather
than concealing them. A differing count fails visibly and requires inspection;
the probe does not silently accept a smaller set. N/O enabled and C disabled are
asserted after completion. Original bytes/artifact identity, exactly one +H POST,
revision +1, one newly bonded H and retained original atoms are checked against
real API reads. No click in the focus-only enumeration issues another command.

Cleanup releases the hold first, awaits both context and inherited page routes
with `behavior: "wait"`, propagates all route/readiness errors, records the
receipt and closes the context. There is no ignored route-error fallback. The
canonical test file is rehashed and must remain byte-identical during execution.

## Evidence and limits

The future receipt records the actual ordered events, loading identities, loaded
25-control identities, each focused identity, held browser state, actual request
body/attempt token, original hash, artifact/revision and actual response hashes.
The fetched molecular body is an attachment; an always-retained native trace,
screenshot and JSON browser report provide the native context. No future outcome,
response hash, artifact identity or control list is invented by this preparation.

Static validation checks syntax and owned-file TypeScript semantics without
executing either entrypoint. It resolves direct imports, proves the original
focus statements and zoom helper via AST, and exercises the source-guard regex
against pure in-memory original/approved/incorrect metadata variants. This is not
an application test or native execution. The initial validator's Node-builtin
resolver assertion was corrected before a successful static rerun. A subsequent
static run correctly detected the primary agent's newly installed guard; the
validator then explicitly bound the actual corrected source and reconstructed
the original by removing only that declared guard. No runtime entrypoint was
involved in these preparation corrections.

After a real run, the primary agent must retain original terminal output, positive
owned-service cleanup and fresh raw DB/WAL/SHM copies before diagnostic SQL, then
inspect the actual trace/receipt and all failures. The full existing canonical
file across both themes and zooms, a fresh complete 43-command candidate, all-seven
same-candidate acceptance, normal protected corrective merge, fresh exact merged
qualification and verified publication remain separate required work. This narrow
probe does not replace any of those gates or reclassify historical evidence.
