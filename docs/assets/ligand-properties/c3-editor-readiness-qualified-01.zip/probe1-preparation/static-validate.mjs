// Static source inspection only. Never import/execute the configuration or spec.
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { createRequire, isBuiltin } from "node:module";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const directory = dirname(fileURLToPath(import.meta.url));
const root = resolve(directory, "../..");
const require = createRequire(resolve(root, "apps/web/package.json"));
const ts = require("typescript");
const sha = value => createHash("sha256").update(value).digest("hex");
const names = ["playwright.config.ts", "editor-readiness.spec.ts"];
const parsed = new Map();
const report = { status: "static checks only; native diagnostic unexecuted", compiler_version: ts.version, files: [], checks: [] };
const options = { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext,
  moduleResolution: ts.ModuleResolutionKind.Bundler, strict: true, skipLibCheck: true,
  allowJs: true, checkJs: false, noEmit: true, jsx: ts.JsxEmit.ReactJSX,
  types: ["node"], typeRoots: [resolve(root, "apps/web/node_modules/@types")] };
for (const name of names) {
  const path = resolve(directory, name), text = readFileSync(path, "utf8");
  const result = ts.transpileModule(text, { fileName: path, compilerOptions: options, reportDiagnostics: true });
  assert.equal((result.diagnostics ?? []).filter(item => item.category === ts.DiagnosticCategory.Error).length, 0);
  parsed.set(name, ts.createSourceFile(path, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS));
  report.files.push({ path: name, bytes: Buffer.byteLength(text), sha256: sha(text), syntax_errors: 0 });
}
// Resolve types without evaluating either entrypoint or any imported module.
const program = ts.createProgram(names.map(name => resolve(directory, name)), options);
for (const name of names) {
  const file = program.getSourceFile(resolve(directory, name));
  const diagnostics = [...program.getSyntacticDiagnostics(file), ...program.getSemanticDiagnostics(file)];
  const formatted = diagnostics.map(item => ts.flattenDiagnosticMessageText(item.messageText, "\n"));
  report.files.find(file => file.path === name).owned_file_type_diagnostics = formatted;
  assert.equal(diagnostics.length, 0, `${name}: ${formatted.join("\n")}`);
}
report.checks.push("Both private TypeScript files parse and have zero owned-file semantic diagnostics; no entrypoints imported/executed");

const spec = parsed.get("editor-readiness.spec.ts");
const config = parsed.get("playwright.config.ts");
const imports = [];
for (const file of [spec, config]) for (const statement of file.statements) {
  if (ts.isImportDeclaration(statement)) {
    const module = statement.moduleSpecifier.text;
    assert(!module.endsWith(".spec") && !module.endsWith(".spec.ts"), "Never import a registering canonical spec");
    if (isBuiltin(module)) {
      imports.push({ owner: file.fileName.slice(directory.length + 1), module, resolved: "Node builtin; ambient declarations type-checked" });
      continue;
    }
    const resolution = ts.resolveModuleName(module, file.fileName, options, ts.sys).resolvedModule;
    assert(resolution, `Unresolved ${module}`);
    imports.push({ owner: file.fileName.slice(directory.length + 1), module, resolved: resolution.resolvedFileName });
  }
}
report.import_bindings = imports;
report.checks.push("All direct imports resolve; no canonical registering suite imported");

let guard;
function walk(node, visit) { visit(node); ts.forEachChild(node, child => walk(child, visit)); }
walk(spec, node => {
  if (ts.isVariableDeclaration(node) && node.name.getText(spec) === "guardedSection") {
    assert(ts.isRegularExpressionLiteral(node.initializer));
    const literal = node.initializer.text;
    guard = new RegExp(literal.slice(1, literal.lastIndexOf("/")), literal.slice(literal.lastIndexOf("/") + 1));
  }
});
assert(guard);
const canonicalPath = resolve(root, "tests/e2e/rebranding-zoom.spec.ts");
const currentCanonical = readFileSync(canonicalPath, "utf8");
assert.equal(sha(currentCanonical), "75ed41b0e75e67cd92a3056311fc98785e0414ee6576aec0abe0e4bb24a19eb0");
const actualGuard = '          if (section === "Atoms") {\n            await expect(panel.getByRole("button", { name: "Replace selected atom with N", exact: true })).toBeEnabled();\n          }\n';
assert.equal(currentCanonical.split(actualGuard).length, 2);
const canonical = currentCanonical.replace(actualGuard, "");
assert.equal(sha(canonical), "5002451820458969f3da28ba6aceaa0a6cdb9753040e33745b632663f610c0bd");
assert(!guard.test(canonical), "Reconstructed exact frozen original must not contain the guard");
assert(guard.test(currentCanonical), "Actual root-installed braced guard must satisfy the prerequisite");
const needle = '          await panel.getByRole("button", { name: section, exact: true }).click();\n          for (const control of await panel.locator("button:visible:enabled, summary:visible").all()) {';
const insertion = '          if (section === "Atoms") await expect(panel.getByRole("button", { name: "Replace selected atom with N", exact: true })).toBeEnabled();\n';
assert.equal(canonical.split(needle).length, 2);
const corrected = canonical.replace(needle, needle.replace("          for (const control", `${insertion}          for (const control`));
assert(guard.test(corrected), "Pure metadata positive: exact planned guard enables runtime-source check");
assert(!guard.test(corrected.replace('name: "Replace selected atom with N", exact: true', 'name: "Replace selected atom with O", exact: true')));
assert(!guard.test(corrected.replace('.toBeEnabled();\n          for (const control', '.toBeVisible();\n          for (const control')));
report.guard_controls = { original_rejected: true, exact_planned_insertion_accepted: true, oxygen_substitution_rejected: true,
  visibility_substitution_rejected: true, original_sha256: sha(canonical), planned_in_memory_only_sha256: sha(corrected),
  actual_root_installed_braced_guard_accepted: true, actual_root_corrected_canonical_sha256: sha(currentCanonical),
  exact_original_reconstructed_by_only_declared_three_line_guard_removal: true };
report.checks.push("Pure in-memory original/guard/incorrect-control/incorrect-condition metadata controls; canonical file never written");

const printer = ts.createPrinter({ removeComments: true });
const print = (node, file) => printer.printNode(ts.EmitHint.Unspecified, node, file);
const canonicalAST = ts.createSourceFile(canonicalPath, canonical, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
const zoomFunction = file => file.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === "setZoom");
assert.equal(print(zoomFunction(spec), spec), print(zoomFunction(canonicalAST), canonicalAST));
report.actual_zoom_helper = { canonical_AST_identical: true, printed_function_sha256: sha(print(zoomFunction(spec), spec)) };
report.checks.push("Actual extension zoom helper is AST-identical to canonical helper; no viewport or CSS simulation");
function controlLoops(file) {
  const found = [];
  walk(file, node => {
    if (ts.isForOfStatement(node) && node.expression.getText(file) === 'await panel.locator("button:visible:enabled, summary:visible").all()') found.push(node);
  });
  return found;
}
const originalLoops = controlLoops(canonicalAST), preparedLoops = controlLoops(spec);
assert.equal(originalLoops.length, 1); assert.equal(preparedLoops.length, 1);
const originalBody = originalLoops[0].statement.statements.map(node => print(node, canonicalAST));
const preparedBody = preparedLoops[0].statement.statements.map(node => print(node, spec));
let position = 0;
for (const statement of originalBody) {
  const match = preparedBody.indexOf(statement, position);
  assert(match >= position, "Canonical focus/assertion/bounds/hit-test statements retained exactly as AST in original order");
  position = match + 1;
}
report.canonical_focus_loop = { original_statements: originalBody.length, all_retained_in_order: true,
  original_printed_body_sha256: sha(originalBody.join("\n")), prepared_additions: preparedBody.length - originalBody.length };
report.checks.push("Original Atoms control locator plus all focus, focus assertion and exact viewport/hit-test statements retained in order");
const text = spec.text;
for (const forbidden of [/waitForTimeout\s*\(/, /setTimeout\s*\(\s*(?:\(\)|function)/, /behavior:\s*["']ignoreErrors["']/, /route\.abort\s*\(/]) {
  assert(!forbidden.test(text));
}
assert(text.includes("route.fulfill({ response })"));
assert(text.includes('context.unrouteAll({ behavior: "wait" })'));
assert(text.includes('page.unrouteAll({ behavior: "wait" })'));
assert(text.includes('test.setTimeout(180000)'));
assert(text.includes('page.setDefaultTimeout(10000)'));
report.checks.push("No fixed sleeps, route aborts, ignored route errors or raised canonical deadlines; fetched response fulfilled without body replacement");
report.executed_native_or_service_entrypoints = false;
writeFileSync(resolve(directory, "static-validation.json"), JSON.stringify(report, null, 2) + "\n");
process.stdout.write(JSON.stringify({ status: report.status, files: report.files.map(file => ({ path: file.path, sha256: file.sha256 })), checks: report.checks.length }) + "\n");
