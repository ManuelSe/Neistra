# Private pre-launch recovery correction — static preparation only

This worker changes only `apps/api/src/neistra_api/job_worker.py` and the new
`tests/integration/test_ligand_property_preload_ownership.py`. No application imports,
execution tests, SQL, services, browser/native/performance workload, Git action or
remote action occurred. Source and tests are prepared for primary review, not proven
correct by execution and not ready to push.

The two architecture findings are addressed in the proposed code:

- Startup handles `PropertyCacheError` and `OSError` only around exclusive descriptor
  cache housekeeping, rolling back and warning. Positive process recovery and shared
  database/ownership failures remain outside that catch.
- Both pre-child refusal paths capture immutable private attempt identity before
  checking implementation admission or loading inputs. The caller rolls back before
  a fresh finalizer session. The finalizer locks and refreshes exact association and
  all three absent process fields before using the existing truthful terminalizer.
  Already terminal jobs retain their authority. It then ends any post-commit read,
  re-locks and repeats association/process checks before reaping and pruning only a
  terminal matching capture. Replacement, foreign/deleted rows and positive process
  metadata grant no never-started mutation authority.

Sixteen new test definitions describe thirty-three parameter combinations. These are
AST-derived authored cases, not pytest collection or passes. They cover real private
cache path refusal plus controlled construction/iteration/unlink failures, ordinary
job admission, repair and explicit retry, fatal process/shared-database recovery
errors, actual captured-byte read refusal, configured implementation mismatch,
retention beyond32 captures and the actual0017 downgrade, retirement/cancellation,
existing terminal state, foreign/replaced/deleted ownership, unexpected process
metadata, replacement after the terminalization commit, already-reaped work and
unchanged ordinary failure semantics. Process launch and signals are forbidden by
their test fixture. No descriptor computation is used as a test oracle.

All1,121 other previously frozen selected source bodies remain exact, including all
original startup/lifecycle regressions and protected benchmark fixtures. The old1,122
map, all earlier packets and ALL8 preparation7 remain untouched. The new mapped set
contains1,123 subjects, solely the changed worker and new regression file.

`job-worker-correction.patch`, `new-test.patch`, before/after source maps and the
original worker bytes support review. Standalone Ruff lint/format and standard-library
AST/source checks pass; those tools did not import the application. The initial new
file's one-line lint/format failure is retained and was corrected with the standalone
formatter. No runtime result is inferred from static success.

`proposed-validation.json` lists the focused execution and affected regressions for
root to run after prerequisite qualification/resources permit. Final prerequisite
integration, complete gates, all required performance cases, seven same-candidate
specialist reviews and normal release delivery remain pending.
