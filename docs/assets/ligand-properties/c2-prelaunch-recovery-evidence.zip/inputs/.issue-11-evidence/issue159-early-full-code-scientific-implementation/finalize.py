from pathlib import Path
import hashlib,json
root=Path.cwd();folder=root/'.issue-11-evidence/issue159-early-full-code-scientific-implementation';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
proof=read(folder/'evidence-readback.json');source=read(root/'.issue-11-evidence/issue159-verified-source-integration/frozen-source-map.json');assert all(sha(root/p)==h for p,h in source.items())
rows=[
('molecular_weight','Descriptors.MolWt','g/mol','finite nonnegative float; qualified_graph'),
('heavy_atom_count','observed atomic number >1',None,'nonnegative integer; observed_elements'),
('heteroatom_count','observed atomic number not in {1,6}',None,'nonnegative integer; observed_elements'),
('carbon_count','observed atomic number ==6',None,'nonnegative integer; observed_elements'),
('formal_charge','fully qualified atomic formal-charge sum','e','signed integer; qualified_atomic_charge'),
('hbd','rdMolDescriptors.CalcNumHBD',None,'nonnegative integer; qualified_graph'),
('hba','rdMolDescriptors.CalcNumHBA',None,'nonnegative integer; qualified_graph'),
('tpsa','rdMolDescriptors.CalcTPSA(includeSandP=False)','Å²','finite nonnegative float; qualified_graph'),
('calculated_logp','rdMolDescriptors.CalcCrippenDescriptors(includeHs=True,force=True)[0]',None,'finite signed float; qualified_graph'),
('molar_refractivity','rdMolDescriptors.CalcCrippenDescriptors(includeHs=True,force=True)[1]','cm³/mol','finite nonnegative float; qualified_graph'),
('rotatable_bond_count','rdMolDescriptors.CalcNumRotatableBonds(Strict)',None,'nonnegative integer; qualified_graph'),
('ring_count','rdMolDescriptors.CalcNumRings',None,'nonnegative integer; pinned perceived ring definition'),
('aromatic_ring_count','rdMolDescriptors.CalcNumAromaticRings',None,'nonnegative integer; pinned perceived aromatic rings'),
('fraction_sp3','rdMolDescriptors.CalcFractionCSP3',None,'finite0..1; carbon-free undefined/unavailable')]
assessment={
'role':'scientific_implementation','verdict':'PASS','scope':'EARLY complete issue159 scientific implementation CODE audit only. Not final feature/readiness, performance/capacity, release or publication qualification.',
'candidate':{'commit':'049173da69cebd7264abc26a0028aa4d9d3f9938','comparison_base':'cd6715d3c5b458eefeb5d24e0305e0da69567dc3','base_kind':'Exact initial159branch tip; parent-produced read-only Git artifacts also identify it as actual merge base with158runtime247ab651b35c2d58e8939985ae50633de70311a3','all_changed_paths':147,'parent_comparison_artifacts':'.issue-11-evidence/issue159-early-full-code-comparison/comparison.json','runtime_test_patch_sha256':'e08b50cb2649e5ed868c047a0d2ecb727b848b9c5a1479f2da3456de06240abd','source_count':1122,'source_map_sha256':proof['source_map_sha256'],'compact_digest':proof['compact_digest'],'all_current_sources_independently_exact':True},
'prioritized_findings':[],
'complete_inspected_scientific_slice':[
'Approved159child/parent/product/global plan and D178-D185,D187-D188,D194,D196,D198 contracts; all147changed-path inventory and complete scientific/backend/frontend contracts, not just D198.',
'All five new kernel modules: strict typed models,14-definition registry, disposable input qualification/H normalization/CIP/evidence canonicalization and per-descriptor calculators.',
'Existing strict158chemistry adapter as reused boundary; selected current normalized membership, immutable original recovery, protected isotope/radical/H/stereo facts, inferred provenance and exact atom correspondence.',
'New private backend models/migration0017/aggregate schemas, bounded verified artifact reads, raw source identity/proof verification, sealed report cache and file/transaction lifecycle.',
'Full1256-line property service read/demand/materialize/capture/complete/failure/publication lifecycle; private plugin and process identity; relevant job_worker/job_service/allowlist/archive integration and reaped-startup correction.',
'Frontend API/types/context/ownership/session/hook/App bridge and Properties value projection: exact source/method/coverage keys, partial cache, preview/ABA/Cancel/Retry, hidden presentation and source retirement.',
'Scientific/kernel tests, service identity/cache/preferences/migration/lifecycle/warm-authority/startup/source-failure integrations, frontend scientific authority tests and pending reader/performance harness contracts.',
'D19444frozen idealized originals/manifest/helper/runtime guard/unit oracles and49protected paths; existing actual attempts remain separate evidence, no new fixture generation or execution.'
],
'descriptor_audit':[{'id':a,'implementation':b,'unit':c,'qualification':d} for a,b,c,d in rows],
'acceptance_assessment':[
'All14accepted descriptors are implemented using pinned RDKit2026.03.4 capabilities and explicit approved options. No neutral/single fallback, pKa/protonation, silent salt/tautomer/stereo alteration or new approximation was found.',
'Ordinary terminal neutral H normalization uses a disposable copy, conservative RemoveHs options and independent expanded representation/H-inventory/charge/heavy-atom roundtrip. Unsupported isotopes/radicals/nonterminal-H/query/dummy/enhanced stereo/elements stay unavailable for graph-dependent descriptors while independently known counts/atomic charge may remain.',
'Input identity jointly binds physical graph/H/stereo and site-associated protection/inference through absolute CIP-labeled incidence evidence. Atom/bond/native mapping and tetrahedral neighbor frame are proved first; stale CIP properties are cleared;100000-iteration refusal fails closed. Unavailable stereo fallback preserves ordered evidence and gives up unsupported reuse.',
'Library/implementation/policy/options and canonical scientific content are separate from current project/entry/current+original artifact/instance/membership bindings. Coordinates/display fields are excluded only where graph-only semantics permit; a fresh current source proof is still required before coordinate reuse.',
'Actual native calculators preserve independent outcomes; missing/unsupported/error outcomes carry null values and reasons. Finite/type/domain checks exist at typed model/cache boundaries; carbon-free fractionsp3 is undefined. Negative logP and signed formal charge remain valid. Plot domains do not clamp values.',
'All chemistry/CIP/canonicalization preparation is in the existing controlled child; parent raw-source fingerprints only locate previously sealed child-produced associations. Current source bytes and selected membership are reverified; locator metadata alone cannot authorize another report.',
'Private complete-publication requires captured job/project/worker/execution/parameters, exact report count/coverage/method/fingerprint and fresh locked target/consumer authority. Source bindings use incarnation CAS to protect B/ABA replacements. Reaped, cancelled, replaced or deleted attempts cannot publish current output.',
'Derived content/files are exclusively owned and bounded. Valid cache victim bytes retire only after successful SQL publication and locked reference recheck; rollback preserves valid prior bytes; housekeeping failure does not falsify a successful publication. Originals/user artifacts remain outside cleanup authority.',
'App-owned values/currentness remain independent of viewer presentation. Exact source failures retire all matching aliases/captures synchronously; old/demand/manual/candidate success cannot bypass the fresh matching property READ recovery fence. Generic transport/semantic/worker/capacity/derived errors do not become physical-source facts.',
'Canonical project/history/original data and ordinary user jobs remain authoritative. Private executions/results are excluded only by positive private association, not a forgeable plugin marker. Preference ownership and derived rebuild-on-archive behavior match the approved contract.'
],
'existing_execution_evidence_assessed':{
'kernel':{'actual_recorded_session':88018,'actual_recorded_exit':0,'tests':83,'raw_logs_and12_current_subject_hashes_verified':True,'scope':'Exact current kernel/API compatibility models and scientific/unit tests; not a complete application gate'},
'kernel_independent_oracles':['Analytic ethanol mass/counts and explicit published Crippen fragment sums, absolute1e-10/relative0 with exact integers','Foscarnic acid TPSA94.83 excludes104.64SandP variant; cubane six perceived rings differs from cycle rankfive','Explicit/implicit-H equivalence, selected fragment/counterion boundary, unsupported and partial-value domains','Atom permutations and site-associated inference/protection, stereo-inequivalent atom/E-Z evidence placement, lowercase CIP, stale/missing labels, real iteration refusal and wrong neighbor frame'],
'backend':{'historical_author_focused':158,'actual_recorded_session':85651,'actual_recorded_exit':0,'scope':'Recorded earlier backend correction evidence; later worker/process/provenance changes are separately reconciled, not called unchanged or pooled into a current full count'},
'D196':{'author_recorded':{'focused':156,'real_supervisors':6,'session':18451,'exit':0},'independent_recorded':{'tests':19,'session':93754,'exit':0,'raw_log_hash_verified':True},'scope':'Captured startup and recovery/publication correction; current protected worker/process/job/startup files exact. Service_currentlater adds D198failure projection; no wider D196 method rewrite.'},
'D198':{'current_author':{'focused_frontend':357,'web':1559,'session':97831,'exit':0},'earlier_own_independent':{'backend':58,'frontend':148,'actual_ASGI':7,'session_recovery_controls':12},'scope':'These are source-producer/current-authority controls only; none is substituted for a complete descriptor-method audit.'},
'C1_full_python':{'recorded_tests':3234,'scope':'Historical source-bound run. Later fairness/worker/source changes have separate evidence; not claimed as a current full-suite pass.'},
'D194':{'originals':44,'protected_paths':49,'hashes_current_and_exact':True,'scope':'Frozen idealized/unoptimized setup chemistry and retained tests/method evidence; no new generation, test or browser execution.'},
'public_packets':proof['archives']},
'nonblocking_notes':['The frontend acceptance parser is a transport/method guard and is less comprehensive than the producer cache scientific-domain validation. The approved162shared-extraction alignment should preserve the established producer policy. This audit found no reachable current producer path emitting the invalid negative reports discussed during planning; it is not a demonstrated defect or instruction to mutate frozen159/160.'],
'limitations':[
'No new tests, chemistry/numerical calculations, SQL inspection, services, browser/native or performance workloads were run during this audit, as required while158Mbrowser is active. Existing executed evidence is identified as such.',
'Actual released158integration,0.37version reconciliation, actual preceding-reader compatibility, current full candidate/exact-master gates and final all-seven same-candidate assessments remain mandatory.',
'ALL8/current measured performance and four1000-entry cohorts remain pending. Earlier desktop probe4and26-case native evidence are historical/source-bound; no current full native or strict-host performance/capacity pass is inferred.',
'Private job/cache resource bounds are implementation limits, not measured throughput/latency certification. Window/capacity qualification belongs to the pending performance work.',
'CODE PASS is not feature completion or readiness to push. This audit does not approve publication or replace required human/remote reviews.'
],
'own_validation':{'passive_source_and_evidence_readback':'PASS','actual_exec_chunk':'73e438','actual_exit_code':0,'raw_evidence':'evidence-readback.json','current_source_bodies':1122,'new_test_or_numerical_invocations':0},
'source_edits':[],'private_evidence_only':True,'ready_to_push':False,'publication_authorized':False}
(folder/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')
manifest={p.name:sha(p) for p in folder.iterdir() if p.is_file() and p.name!='manifest.json'};(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'verdict':'PASS','scope':'early complete159scientific implementation CODE only','candidate':assessment['candidate']['commit'],'base':assessment['candidate']['comparison_base'],'sources':1122,'descriptors':len(rows),'new_workloads':0,'assessment_sha256':sha(folder/'assessment.json')}))
