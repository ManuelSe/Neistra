from pathlib import Path
from datetime import datetime,UTC
import hashlib,json
root=Path.cwd();out=root/'.issue-11-evidence/issue159-early-full-code-scientific-implementation';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
map_path=root/'.issue-11-evidence/issue159-verified-source-integration/frozen-source-map.json';source=read(map_path)
assert len(source)==1122 and sha(map_path)=='29c3c5c31aaead721d442b95052848786d2786731864405e1777055e22329fbd'
assert all(sha(root/p)==h for p,h in source.items())
comparison=read(root/'.issue-11-evidence/issue159-early-full-code-comparison/comparison.json')
assert comparison['candidate']=='049173da69cebd7264abc26a0028aa4d9d3f9938'
assert sha(Path(comparison['runtime_test_patch']['path']))==comparison['runtime_test_patch']['sha256']
assert sha(root/'.issue-11-evidence/issue159-early-full-code-comparison/all-path-name-status.txt')==comparison['all_paths_file_sha256']
kernel=read(root/'.issue-11-evidence/issue159-kernel/final2.json');assert kernel['complete']
assert kernel['source_before']==kernel['source_after']
assert all(sha(root/p)==h for p,h in kernel['source_after'].items())
for command in kernel['commands']:
 assert command['exit_code']==0 and sha(root/command['log'])==command['log_sha256']
assert '83 passed' in (root/'.issue-11-evidence/issue159-kernel/pytest-final2.log').read_text()
protected=read(root/'.issue-11-evidence/issue159-verified-source-integration/D194-49-source-readback.json')['sources'];assert len(protected)==49
assert all(sha(root/p)==h for p,h in protected.items())
d196=read(root/'.issue-11-evidence/issue159-verified-source-integration/D196-protected-source-readback.json');assert all(sha(root/p)==h for p,h in d196['unchanged_exact_files'].items())
fixture=read(root/'tests/fixtures/ligand-properties-performance/editable/manifest.json');assert len(fixture['fixtures'])==44
assert all(sha(root/'tests/fixtures/ligand-properties-performance/editable'/f['filename'])==f['sha256'] for f in fixture['fixtures'])
startup=read(root/'.issue-11-evidence/issue159-startup-ownership/verification-final2.json')
independent_startup=read(root/'.issue-11-evidence/issue159-startup-ownership/scientific-review1/reassessment-final2.json')
assert sha(root/independent_startup['independent_checks']['log'])==independent_startup['independent_checks']['log_sha256']
d198=read(root/'.issue-11-evidence/issue159-verified-source-integration/final2-gate-receipt.json');assert d198['complete']
for step in d198['steps']:
 assert step['exit_code']==0 and sha(root/step['log'])==step['sha256']
archives=[]
for name in ['c1-checkpoint.json','c2-startup-ownership-checkpoint.json','c2-source-producer-checkpoint.json']:
 p=root/'docs/assets/ligand-properties'/name;record=read(p)
 if name=='c1-checkpoint.json':
  archive='c1-evidence.zip';expected='f25634d34eb5de3c3fc280291074e3a3375cb74faea517722ef0196f8202b0fe'
 else:archive=record['archive'];expected=record['archive_sha256']
 actual=sha(p.parent/archive);assert actual==expected
 archives.append({'checkpoint':name,'checkpoint_sha256':sha(p),'archive':archive,'archive_sha256':actual,'scope':'Existing source-bound evidence packet hash readback only; no new test or recursive gate execution'})
report={'scope':'Passive existing source/code/log/evidence audit only; no new tests, numerical workloads, services, native/browser/performance, SQL or Git mutation','candidate':comparison['candidate'],'comparison_base':comparison['initial_branch_tip'],'base_evidence':'Primary-produced read-only comparison artifacts; exact initial branch tip and merge base with current158runtime agree','all_changed_paths':comparison['all_changed_paths'],'source_count':1122,'source_map_sha256':sha(map_path),'compact_digest':hashlib.sha256(json.dumps(source,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'all_source_bodies_exact':True,'kernel83_evidence_source_and_log_hashes_verified':True,'kernel_current_owned_paths':len(kernel['source_after']),'D19449_protected_paths_and44_fixture_hashes_exact':True,'D196_protected_files_exact':True,'D196_independent19_log_hash_verified':True,'D198_current_author_gate_zero_exit_logs_verified':True,'archives':archives,'timestamp':datetime.now(UTC).isoformat(),'new_test_or_numerical_invocations':0}
(out/'evidence-readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passive_verification':'PASS','source_count':1122,'kernel_subject_files':len(kernel['source_after']),'D194_paths':49,'frozen_originals':44,'evidence_packets':3,'new_workloads':0,'base':comparison['initial_branch_tip']}))
