"""Test-only old-worker substitution for three targeted negative regressions."""
from pathlib import Path
import hashlib
import importlib.machinery
import importlib.util
import sys


def pytest_configure():
    import neistra_api.job_worker as current
    path = Path(__file__).resolve().parents[2] / ".issue-11-evidence/issue159-prelaunch-recovery-correction/job_worker.before.py.txt"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == "b7972af2864dc83ee111a70d0b432bc9ef3428edd8fe9776f5ee846b572a0c43"
    name = "neistra_api._prelaunch_baseline_worker"
    loader = importlib.machinery.SourceFileLoader(name, str(path))
    spec = importlib.util.spec_from_loader(name, loader)
    assert spec is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    loader.exec_module(module)
    current.JobWorker = module.JobWorker
