import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
previous = Path('/tmp/neistra159-reader036-actual247-1')
out = root / '.issue-11-evidence/issue159-reader036-launch-architecture'
interpreter = root / '.venv/bin/python'
code = '''import importlib.util,json,site,sys
names = ("alembic", "sqlalchemy", "fastapi", "rdkit", "neistra_api", "neistra_core")
def spec(name):
    found = importlib.util.find_spec(name)
    return None if found is None else {"origin": found.origin, "locations": list(found.submodule_search_locations or ())}
print(json.dumps({"executable": sys.executable, "prefix": sys.prefix, "base_prefix": sys.base_prefix, "site_packages": site.getsitepackages(), "specs": {name: spec(name) for name in names}, "no_app_imports": not any(name in sys.modules for name in names)}, sort_keys=True))
'''
results=[]
for selected in (root, previous):
    assert selected.is_dir()
    env={key:value for key,value in os.environ.items() if not key.startswith(('NEISTRA_', 'MOLWEAVE_')) and key not in {'PYTHONPATH','PYTHONOPTIMIZE','DATABASE_URL'}}
    env.update(PYTHONPATH=os.pathsep.join(str(selected / part) for part in ('apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src','.')), PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    for label, executable in (('lexical_absolute', interpreter.absolute()), ('resolved', interpreter.resolve())):
        process=subprocess.run([str(executable), '-B', '-c', code], cwd=selected, env=env, capture_output=True, text=True, check=True)
        result=json.loads(process.stdout)
        assert result['no_app_imports']
        assert (result['prefix'] != result['base_prefix']) == (label == 'lexical_absolute')
        assert (result['specs']['alembic'] is not None) == (label == 'lexical_absolute')
        assert result['specs']['neistra_api']['locations'] == [str(selected/'apps/api/src/neistra_api')]
        results.append({'cwd': str(selected), 'kind': label, 'argv_executable': str(executable), 'returncode':process.returncode, 'stderr':process.stderr,'result':result})
paths=['tests/support/ligand_properties_reader_qualification.py','tests/unit/test_ligand_properties_reader_contract.py','docs/assets/ligand-properties/release-recipe.py.txt','docs/assets/ligand-properties/qualification-summary.py.txt']
report={'head_expected':'d4f1e89d6cdac9b4b62c1a37465fc97e0e535011','symlink_target':os.readlink(interpreter),'resolved':str(interpreter.resolve()),'probes':results,'subjects':{p:{'bytes':(root/p).stat().st_size,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths},'limits':'Only stdlib, site and top-level import-spec discovery; no application import, actor, database or reader test execution.'}
(out/'interpreter-probe.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'probes':len(results),'all_safe_controls_pass':True,'subjects':report['subjects']}))
