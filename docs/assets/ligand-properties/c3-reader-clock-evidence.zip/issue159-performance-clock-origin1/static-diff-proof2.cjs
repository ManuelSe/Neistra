const fs = require("node:fs"), path = require("node:path"), assert = require("node:assert/strict");
const root = process.cwd(), out = path.join(root, ".issue-11-evidence/issue159-performance-clock-origin1");
const ts = require(path.join(root, "apps/web/node_modules/typescript/lib/typescript.js"));
const parse = name => ts.createSourceFile(name, fs.readFileSync(path.join(out, name), "utf8"), ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
const old = parse("before-performance.spec.ts"), next = parse("candidate-performance.spec.ts");
assert.equal(old.parseDiagnostics.length, 0); assert.equal(next.parseDiagnostics.length, 0);
function collect(file, predicate) { const values=[]; function visit(node) { if(predicate(node)) values.push(node.getText(file)); ts.forEachChild(node, visit); } visit(file); return values; }
const assertions = file => collect(file, n => ts.isCallExpression(n) && /^(expect(?:\.|\()|performanceBudget\()/u.test(n.getText(file)));
assert.deepEqual(assertions(next), assertions(old));
const bounds = file => collect(file, n => ts.isCallExpression(n) && (n.expression.getText(file)==="test.setTimeout" || /(?:waitForTimeout|waitForResponse)$/u.test(n.expression.getText(file))));
assert.deepEqual(bounds(next),bounds(old));
assert.deepEqual(collect(next, ts.isNumericLiteral), collect(old, ts.isNumericLiteral));
const imports = file => file.statements.filter(ts.isImportDeclaration).map(n => n.getText(file));
assert.deepEqual(imports(next), imports(old));
const cases = file => { const result=[]; function visit(n){ if(ts.isCallExpression(n)&&n.expression.getText(file)==="test") result.push(n.arguments[0].getText(file));ts.forEachChild(n,visit); }visit(file);return result;};
assert.deepEqual(cases(next),cases(old));
const diagnosticNames = new Set(["timeOrigin", "clock", "readClock"]);
function normalized(node, source) {
 const transform = context => { const visit = n => {
  if ((ts.isVariableDeclaration(n)||ts.isPropertyAssignment(n)||ts.isShorthandPropertyAssignment(n)||ts.isPropertySignature(n)||ts.isBindingElement(n)) && diagnosticNames.has(n.name?.getText())) return undefined;
  const result=ts.visitEachChild(n,visit,context);
  if(ts.isVariableStatement(result)&&result.declarationList.declarations.length===0)return undefined;
  return result;
 };return n=>ts.visitNode(n,visit);};
 const result=ts.transform(node,[transform]);
 try { const printed=ts.createPrinter({removeComments:true}).printNode(ts.EmitHint.Unspecified,result.transformed[0],source); const scanner=ts.createScanner(ts.ScriptTarget.Latest,true,ts.LanguageVariant.Standard,printed);const tokens=[];for(let kind=scanner.scan();kind!==ts.SyntaxKind.EndOfFileToken;kind=scanner.scan())tokens.push(scanner.getTokenText());return JSON.stringify(tokens); } finally { result.dispose(); }
}
const critical=["installObservation","arm","automaticReady","timing"];
for(const name of critical){
 const before=old.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name), after=next.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name);
 assert.ok(before&&after,name);assert.equal(normalized(after,next),normalized(before,old),name);
}
const allFunctions = file => file.statements.filter(ts.isFunctionDeclaration).map(n=>n.name.text);
assert.deepEqual(allFunctions(next),allFunctions(old));
const unchangedFunctions = allFunctions(old).filter(name=>!critical.includes(name));
for(const name of unchangedFunctions){
 const before=old.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name), after=next.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name);
 assert.equal(after.getText(next),before.getText(old),name);
}
const report={scope:"Static TypeScript AST comparison of private prepared clock candidate only; no compilation/browser/application/workload",parseDiagnostics:0,old_assertion_call_count:assertions(old).length,assertions_all_exact:true,old_timeout_and_wait_call_count:bounds(old).length,timeout_and_wait_calls_exact:true,numeric_literals_all_exact:true,imports_all_exact:true,test_case_templates:cases(old),test_case_templates_exact:true,critical_timing_and_ready_functions_equal_after_only_diagnostic_field_erasure:critical,all_other_top_level_functions_exact:unchangedFunctions};
fs.writeFileSync(path.join(out,"static-diff-proof.json"),JSON.stringify(report,null,2)+"\n");console.log(JSON.stringify(report,null,2));
