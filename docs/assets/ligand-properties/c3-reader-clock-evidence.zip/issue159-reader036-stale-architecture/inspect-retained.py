import hashlib
import json
from pathlib import Path
import zipfile

root=Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
w=Path('/tmp/neistra159-reader036-properties1')
out=root/'.issue-11-evidence/issue159-reader036-stale-architecture'
def load(name): return json.loads((w/name).read_bytes())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
produced=load('property-cases.json'); old=load('old-property-outcomes.json'); a=load('produce-current.json'); b=load('old-write.json'); phases=load('phases.json')
assert [p['exit_code'] for p in phases]==[0,0,1]
for record in phases[:2]:
 assert sha(Path(record['report']))==record['report_sha256']
 assert sha(Path(record['log']))==record['log_sha256']
assert sha(w/'reopen-current.log')==phases[2]['log_sha256']
identity=b['identity'];oldroot=Path(identity['root'])
assert set(identity['versions'].values())=={'0.36.0'}
assert identity['previous_receipt']['files_verified']==1013
for module in identity['module_paths'].values():
 path=Path(module['path']); assert path.is_relative_to(oldroot) and sha(path)==module['sha256']
for relative,digest in identity['source_files'].items(): assert sha(oldroot/relative)==digest
rows={}
for label,c in produced.items():
 o=old[label]; before=c['state']; after=o['state_after_old_write']
 assert o['unknown_0017_migration']['exit']!=0 and o['unknown_0017_migration']['unchanged']
 assert o['unknown_0017_migration']['before']==o['unknown_0017_migration']['after']
 assert o['api_read_save_entry_delete_undo'] and o['old_insert_server_default']=='user'
 assert {x['suffix'] for x in o['both_suffixes']}=={'neistra','molweave'}
 assert all(x['canonical_originals_exact'] and x['ordinary_private_inputs_results_absent'] for x in o['both_suffixes'])
 post=o['post_delete_archive']; assert post['target_absent_during_all_roundtrips'] and post['anchor_and_user_jobs_preserved'] and post['original_project_unchanged_during_roundtrips']
 assert {x['suffix'] for x in post['both_suffixes']}=={'neistra','molweave'}
 if after is not None:
  assert after['molecular']==before['molecular']
  assert after['history'][:len(before['history'])]==before['history']
  assert len(after['history'])==len(before['history'])+1
  assert after['history'][-1]['command_type']=='entry.delete'
 rows[label]={'canonical_original_current_ids_designations_allocator_exact':after is not None,'prior_history_exact_prefix':after is not None,'appended_old_entry_delete_undone':after is not None,'old_writer_suffixes':['neistra','molweave'],'unknown_0017_refusal_unchanged':True,'old_insert_server_default':'user','intentional_project_deletion':o['original_project_intentionally_deleted']}
reports=[]
for path in (w/'cases/stale/cache').rglob('*'):
 if path.is_file():
  envelope=json.loads(path.read_bytes());reports.append({'path':str(path.relative_to(w)),'file_sha256':sha(path),'report':envelope['report'],'semantic_fingerprints':envelope['semantic_fingerprints']})
assert len(reports)==2
fresh=next(x['report'] for x in reports if x['report']['model_status']=='unavailable');origin=next(x['report'] for x in reports if x['report']['model_status']=='qualified')
assert fresh['input_hash']!=origin['input_hash']
assert fresh['model_reason']=='hydrogen_semantics_unavailable'
expected={'heavy_atom_count':3,'heteroatom_count':2,'carbon_count':1,'formal_charge':0}
for v in fresh['values']:
 if v['descriptor_id'] in expected: assert (v['status'],v['value'],v['reason'])==('ready',expected[v['descriptor_id']],None)
 else: assert (v['status'],v['value'],v['reason'])==('unavailable',None,'hydrogen_semantics_unavailable')
canonical=produced['stale']['state']['molecular']['canonical']['Descriptor target']
assert [(x['id'],x['element']) for x in canonical['atoms']]==[(1,'N'),(2,'C'),(3,'O')]
z=root/'.issue-11-evidence/issue159-actual036-reader-execution1/failed-properties-raw.zip'
assert sha(z)=='0e0b6c7f621d3ef1fd34a4f78c03cf1bbd05a4bcb713d3e230ae14e9afa8669f'
with zipfile.ZipFile(z) as archive:
 members=archive.infolist();assert len([i for i in members if not i.is_dir() and i.filename != 'raw-capture-manifest.json'])==198
 assert len([i for i in members if not i.is_dir()])==199 and len([i for i in members if i.is_dir()])==22
result={'actor_exit_codes':[p['exit_code'] for p in phases],'old_identity':{'root':str(oldroot),'versions':identity['versions'],'previous_receipt':identity['previous_receipt'],'verified_module_paths':len(identity['module_paths']),'verified_source_files':len(identity['source_files'])},'old_case_contracts':rows,'stale_canonical_elements':[(x['id'],x['element']) for x in canonical['atoms']],'stale_reports':reports,'raw_zip':{'sha256':sha(z),'bytes':z.stat().st_size,'regular_members':198,'total_members':len(members)},'limits':'No application imports, SQL, actors, tests or workloads; regular JSON/source/ZIP bytes inspected only.'}
(out/'retained-evidence.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('stale_reports','old_case_contracts')}))
