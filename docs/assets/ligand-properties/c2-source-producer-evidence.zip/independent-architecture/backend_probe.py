from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
ROOT=Path.cwd(); OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from neistra_api.database import Base
from neistra_api.main import create_app
from neistra_api.settings import Settings
from neistra_api import ligand_property_verification
from tests.support.api_client import ApiClient
from tests.integration.test_ligand_property_lifecycle import imported,source,read
from tests.integration.test_ligand_property_source_failures import damaged
source_map=json.loads((ROOT/'.issue-11-evidence/issue159-verified-source-integration/frozen-source-map.json').read_text())
def guard():
    assert len(source_map)==1122
    assert all(hashlib.sha256((ROOT/k).read_bytes()).hexdigest()==v for k,v in source_map.items())
guard()
store=OUT/'store'; store.mkdir()
app=create_app(Settings(data_dir=store,database_url=f'sqlite:///{store/"probe.db"}',auto_create_schema=True,enable_test_routes=True))
Base.metadata.create_all(app.state.engine); client=ApiClient(app); cases=[]
for role in ('current','original'):
    for kind in ('bytes','file','metadata'):
        project=imported(client); entry=project['entries'][0]
        endpoint=f"/api/v1/projects/{project['id']}/entries/{entry['id']}/ligand-candidates"
        params={'expected_artifact_id':entry['current_artifact_id']}
        baseline=client.get(endpoint,params=params)
        assert baseline.status_code==200
        assert read(client,project).json()['entries'][0]['status']=='pending'
        with damaged(client,entry[f'{role}_artifact_id'],kind):
            result=read(client,project)
            assert result.status_code==200
            row=result.json()['entries'][0]
            assert row['status']=='failed' and row['report'] is None
            assert row['source_failure']=={'source_identity':{'project_id':project['id'],'entry_id':entry['id'],'current_artifact_id':entry['current_artifact_id'],'original_artifact_id':entry['original_artifact_id']},'source_verification':role,'reason':'artifact_unavailable'}
            assert client.get(f"/api/v1/projects/{project['id']}").json()==project
        recovered=client.get(endpoint,params=params)
        assert recovered.status_code==200
        cases.append({'role':role,'kind':kind,'project':project,'inventory':baseline.json(),'recoveredInventory':recovered.json(),'failure':result.json()})
app.state.engine.dispose(); guard()
report={'source_count':1122,'source_map_sha256':hashlib.sha256((ROOT/'.issue-11-evidence/issue159-verified-source-integration/frozen-source-map.json').read_bytes()).hexdigest(),'installed_verifier':ligand_property_verification.__file__,'cases':cases,'external_services':0,'workers':0,'source_unchanged':True}
(OUT/'backend-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cases':len(cases),'source_unchanged':True,'installed_verifier':report['installed_verifier']}))
