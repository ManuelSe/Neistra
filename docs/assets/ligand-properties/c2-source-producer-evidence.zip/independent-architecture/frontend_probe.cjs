const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=process.cwd(),out=__dirname,req=Module.createRequire(path.join(root,'apps/web/package.json')),ts=req('typescript');
require.extensions['.ts']=(module,file)=>module._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,file);
const {QueryClient}=req('@tanstack/react-query');
const {getLigandInventoryOwner,inventorySourceKey}=require(path.join(root,'apps/web/src/ligands/inventoryQualification.ts'));
const {LigandPropertySession,propertySourceIdentity,propertyTargetKey}=require(path.join(root,'apps/web/src/ligandProperties/session.ts'));
const {PropertyInputOwner}=require(path.join(root,'apps/web/src/ligandProperties/ownership.ts'));
const {propertyTarget,propertyResult}=require(path.join(root,'apps/web/src/test/ligand-properties-fixtures.ts'));
const expected=JSON.parse(fs.readFileSync(path.join(root,'.issue-11-evidence/issue159-verified-source-integration/frozen-source-map.json')));
function guard(){for(const[name,hash]of Object.entries(expected))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex'),hash,name)}
const settle=async()=>{for(let i=0;i<35;i++)await Promise.resolve()};
(async()=>{
 guard();const report={scope:'Independent installed QueryClient/canonical owner/session with own six actual ASGI failures. Numeric READY and API demand transport controlled; no chemistry job, browser or App rendering claimed.',source_count:Object.keys(expected).length,cases:[]};
 const backend=JSON.parse(fs.readFileSync(path.join(out,'backend-results.json')));
 for(const item of backend.cases){
  const entry=item.project.entries[0],row=item.failure.entries[0],target={...propertyTarget(),projectId:item.project.id,source:row.source,originalArtifactId:entry.original_artifact_id};
  const source=propertySourceIdentity(target),key=['ligand-candidates','ligand-instance-v3',source.projectId,source.entryId,source.currentArtifactId,source.originalArtifactId,'ligand-exact-representation-v2','ligand-occurrence-v1','designation',0,12];
  const client=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity}}}),inventory=getLigandInventoryOwner(client);
  const owner=new PropertyInputOwner(()=>({activeProjectId:target.projectId,inspectedEntryId:source.entryId,inputKey:propertyTargetKey(target),paused:false,sourceIdentity:source}));
  let next=propertyResult(target),reads=0,demands=0,events=0;const session=new LigandPropertySession(t=>owner.capture(t),{read:async()=>{reads++;return next},demand:async()=>{demands++;throw Error('Unexpected demand')},release:async()=>({})});
  const stop=inventory.subscribeVerificationFailures(event=>{events++;session.invalidateSource(event.source,event.token,event.reason,()=>owner.retireSource(event.source))});
  const unpublish=session.publishSourceFailuresTo(inventory.recordSourceFailure);
  const qualifies=()=>!inventory.qualification(inventorySourceKey({id:source.projectId},entry)).blocked;
  await client.fetchQuery({queryKey:key,staleTime:0,queryFn:async()=>item.inventory});
  session.connect(target);await settle();assert.equal(session.view(target).status,'ready');const captured=owner.capture(target);
  let finish,signal;const held=new Promise(resolve=>{finish=resolve});const oldKey=[...key];oldKey[9]=12;
  const old=client.fetchQuery({queryKey:oldKey,queryFn:context=>{signal=context.signal;return held}}).catch(()=>undefined);
  let beforeNotification=false;const unnotify=inventory.subscribe(()=>{beforeNotification=!captured()&&!session.view(target).current&&!qualifies()});
  next=item.failure;session.retry(target);await settle();assert.equal(events,1);assert.equal(beforeNotification,true);assert.equal(signal.aborted,true);assert.equal(qualifies(),false);assert.equal(session.view(target).current,undefined);
  finish(item.inventory);await old;client.setQueryData(key,item.inventory);assert.equal(qualifies(),false);
  await client.fetchQuery({queryKey:key,staleTime:0,queryFn:async()=>item.recoveredInventory});assert.equal(qualifies(),true);assert.equal(session.view(target).current,undefined);assert.equal(captured(),false);assert.equal(reads,2);
  next=propertyResult(target);session.retry(target);await settle();assert.equal(session.view(target).status,'ready');assert.equal(demands,0);
  next=item.failure;session.retry(target);await settle();assert.equal(events,2);assert.equal(qualifies(),false);
  next=propertyResult(target);session.retry(target);await settle();assert.equal(session.view(target).status,'ready');assert.equal(qualifies(),false);assert.equal(events,2);assert.equal(reads,5);assert.equal(demands,0);
  report.cases.push({role:item.role,kind:item.kind,barrierAndNumericBeforeNotification:beforeNotification,heldCandidateCancelled:true,oldSuccessAndManualWriteInert:true,actualCandidateGETDoesNotRestoreNumeric:true,freshPropertyReadRecoversNumeric:true,numericReadDoesNotQualifyCandidates:true,events,reads,demands});
  unnotify();unpublish();stop();session.deactivate();inventory.deactivate();client.clear();
 }
 // Exercise the actual explicit port through more unique physical facts than either owner retains.
 const client=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity}}}),inventory=getLigandInventoryOwner(client),session=new LigandPropertySession();
 const stop=inventory.subscribeVerificationFailures(event=>session.invalidateSource(event.source,event.token,event.reason));
 for(let i=0;i<300;i++){const source={projectId:'bounded',entryId:`entry-${i}`,currentArtifactId:`current-${i}`,originalArtifactId:'original'};inventory.recordSourceFailure({source,reason:'artifact_unavailable'});const r=inventory.retention();assert(r.records<=128&&r.sourceKeyBytes<=65536)}
 report.retention=inventory.retention();assert.equal(report.retention.unknownRequiresCheck,true);stop();session.deactivate();inventory.deactivate();client.clear();
 guard();report.source_unchanged=true;fs.writeFileSync(path.join(out,'frontend-results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({cases:report.cases.length,retention:report.retention,source_unchanged:true}));
})().catch(error=>{console.error(error);process.exitCode=1});
