import userEvent from "@testing-library/user-event";
import { ViewerMeasurements } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/components/ViewerMeasurements";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { act, cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { StrictMode, type ComponentProps } from "react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import App from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/App";
import { ApiError, projectApi, workspacePresentationApi } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/api/client";
import type { CoordinateTransform, Project } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/api/types";
import type * as LigandControlsModule from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/components/LigandDesignationControls";
import type { LigandDesignationControls } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/components/LigandDesignationControls";
import type { ProjectInspector } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/components/ProjectInspector";
import type { WorkspaceCanvas } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/components/WorkspaceCanvas";
import { ligandApi } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/ligands/api";
import type { LigandCandidatesRead } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/ligands/types";
import { useMinimizationStore } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/minimization/store";
import { useEditingStore } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/store/editing";
import { useNavigationStore } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/store/navigation";
import { useSelectionStore } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/store/selection";
import { useWorkspaceStore } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/store/workspace";
import { structureQueryKey } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/structures/query";
import { molecularEntry, molecularProject, proteinProjection } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/test/molecular-fixtures";
import { ligandPropertyApi } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/ligandProperties/api";
import { propertyEntry, propertyPreferences, propertyRegistry, propertyResult } from "/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/test/ligand-properties-fixtures";

type Controls = ComponentProps<typeof LigandDesignationControls>;
const seen = vi.hoisted(() => ({ renderMeasurements: false, controls: null as Controls | null,
  inspector: null as ComponentProps<typeof ProjectInspector> | null,
  workspace: null as ComponentProps<typeof WorkspaceCanvas> | null }));
vi.mock("/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/components/LigandDesignationControls", async importOriginal => {
  const actual = await importOriginal<typeof LigandControlsModule>();
  return { LigandDesignationControls: (props: Controls) => {
    seen.controls = props; return <actual.LigandDesignationControls {...props} />;
  } };
});
vi.mock("/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/components/ProjectInspector", () => ({ ProjectInspector: (props: ComponentProps<typeof ProjectInspector>) => {
  seen.inspector = props; return props.ligandControls;
} }));
vi.mock("/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/components/WorkspaceCanvas", () => ({ WorkspaceCanvas: (props: ComponentProps<typeof WorkspaceCanvas>) => {
  seen.workspace = props;
  const session = props.measurementSession;
  return seen.renderMeasurements && session && props.project ? <ViewerMeasurements session={session} project={props.project}
    sceneAvailable={false} busy={false} inspection={{ projectId: props.project.id, viewer: undefined, sources: [],
      selection: props.selection, order: null, structures: new Map(), entries: props.project.entries, paused: false, onOrder: () => undefined }}
    onUpdate={() => Promise.resolve()} onDelete={() => Promise.resolve()} onSelect={() => undefined}
    onReturnFocus={() => undefined} /> : null;
} }));
vi.mock("/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties/apps/web/src/components/LowerPanel", () => ({ LowerPanel: () => null }));
const clients: QueryClient[] = [];
beforeEach(() => {
  localStorage.clear(); vi.restoreAllMocks(); seen.renderMeasurements = false; seen.controls = null; seen.inspector = null; seen.workspace = null;
  useWorkspaceStore.getState().setActiveProjectId(null);
  useSelectionStore.getState().setProject(null); useEditingStore.getState().setProject(null);
  useMinimizationStore.getState().setProject(null); useNavigationStore.getState().setProject(null);
  vi.spyOn(workspacePresentationApi, "read").mockResolvedValue({ schema_version: 1, revision: 0, camera: null, updated_at: null });
});
afterEach(() => { cleanup(); clients.splice(0).forEach(client => client.clear()); vi.restoreAllMocks(); });
function deferred<T>() {
  let resolve!: (value: T) => void, reject!: (error: Error) => void;
  const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
function inventory(project: Project): LigandCandidatesRead {
  const entry = project.entries[0];
  return { project_id: project.id, entry_id: entry.id, artifact_id: entry.current_artifact_id,
    designation: entry.ligand_designation, input_hash: "inventory", resolver_version: "ligand-instance-v3",
    total: 1, offset: 0, limit: 12, designated_candidate: null, warnings: [], selectable_candidate_keys: ["candidate"],
    candidates: [{ candidate_key: "candidate", atom_ids: [1, 2], residue_ids: [1], component_ids: ["LIG"],
      label: "Exact instance", locations: [], boundary_status: "qualified", potential_ligand: true,
      reason_codes: [], provenance: [], heavy_atom_count: 2, formal_charge: 0, formula: "C2H6",
      molecular_weight: 30, chemistry_status: "qualified", chemistry_reason: null, chemical_input_hash: "chemistry",
      occurrence_count: null, occurrence_basis: null, occurrence_reason: "occurrence_count_not_qualified" }] };
}
async function setup(legacy = false, strict = false, withProperties = false) {
  const entry = withProperties ? propertyEntry() : molecularEntry("protein", "Entry", "protein");
  if (!legacy && !withProperties) entry.ligand_designation = { ...entry.ligand_designation, status: "selection_required" };
  if (withProperties) {
    entry.original_filename = "uploaded.sdf";
    vi.spyOn(ligandPropertyApi, "registry").mockResolvedValue(propertyRegistry);
    vi.spyOn(ligandPropertyApi, "preferences").mockResolvedValue(propertyPreferences);
    vi.spyOn(ligandPropertyApi, "read").mockResolvedValue(propertyResult());
    vi.spyOn(ligandPropertyApi, "demand"); vi.spyOn(ligandPropertyApi, "allocate");
  }
  const project = molecularProject([entry]); project.has_uncheckpointed_changes = false;
  if (withProperties) {
    const remaining = molecularEntry("remaining", "Remaining", "ligand");
    remaining.ligand_designation = { ...remaining.ligand_designation, status: "not_applicable" };
    project.entries.push(remaining);
  }
  const other = { ...molecularProject([]), id: "other", name: "Other" };
  const query = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: Infinity }, mutations: { retry: false } } });
  clients.push(query); query.setQueryData(["project", project.id], project); query.setQueryData(["project", other.id], other);
  query.setQueryData(structureQueryKey(project.id, entry.id, entry.current_artifact_id),
    { ...proteinProjection(), entry_id: entry.id, artifact_id: entry.current_artifact_id });
  vi.spyOn(globalThis, "fetch").mockImplementation(input => {
    const path = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    return Promise.resolve(Response.json(path.endsWith(`/projects/${project.id}`) ? project
      : path.endsWith(`/projects/${other.id}`) ? other
        : path === "/api/v1/projects" ? [project, other].map(value => ({ ...value, entry_count: value.entries.length })) : []));
  });
  vi.spyOn(ligandApi, "candidates").mockResolvedValue(inventory(project));
  vi.spyOn(ligandApi, "depiction").mockResolvedValue({ entry_id: entry.id, artifact_id: entry.current_artifact_id,
    candidate_key: "candidate", status: "unavailable", reason: "not_qualified", input_hash: null,
    cache_key: null, artifact: null, implementation: "ligand-2d-v1", library_version: "pinned",
    formula: null, molecular_weight: null, formal_charge: null, provenance: null });
  useWorkspaceStore.getState().setActiveProjectId(project.id); useWorkspaceStore.setState({ mobilePanel: null });
  const content = <QueryClientProvider client={query}><App /></QueryClientProvider>;
  render(strict ? <StrictMode>{content}</StrictMode> : content);
  await waitFor(() => expect(useSelectionStore.getState().projectId).toBe(project.id));
  act(() => useNavigationStore.getState().inspect(project.id, entry.id));
  if (!window.matchMedia("(max-width: 840px)").matches) {
    await waitFor(() => expect(seen.controls?.entryId).toBe(entry.id));
  }
  return { entry, project, other, query };
}
function leaveAndReturn(other: Project, project: Project) {
  useWorkspaceStore.getState().setActiveProjectId(other.id);
  useWorkspaceStore.getState().setActiveProjectId(project.id);
}

it("retires numerical source authority when actual App designation reports a tagged source failure", async () => {
 const f=await setup(false,false,true);
 await screen.findByText("Properties current", {exact:true,selector:"p.ligand-properties-status"});
 expect(screen.getByText("46.069")).toBeVisible();
 const reads=vi.mocked(ligandPropertyApi.read).mock.calls.length;
 vi.spyOn(ligandApi,"designate").mockRejectedValue(new ApiError(409,"artifact_integrity_error","Controlled original input verification failure",[],[],null,"original"));
 await act(async()=>{ await seen.controls!.onDesignate(f.entry,"candidate","inventory").catch(()=>undefined); });
 console.log(JSON.stringify({scope:"Actual App owned designation callback/commandMutation with controlled typed API error",numericalCurrent:!!screen.queryByText("Properties current",{exact:true,selector:"p.ligand-properties-status"}),massVisible:!!screen.queryByText("46.069"),propertyReadsBefore:reads,propertyReadsAfter:vi.mocked(ligandPropertyApi.read).mock.calls.length,candidateCalls:vi.mocked(ligandApi.candidates).mock.calls.length}));
 expect(screen.queryByText("46.069")).toBeNull();
 expect(screen.queryByText("Properties current",{exact:true,selector:"p.ligand-properties-status"})).toBeNull();
});
