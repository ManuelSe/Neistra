const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=process.cwd(),req=Module.createRequire(path.join(root,'apps/web/package.json')),ts=req('typescript');
require.extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,f);
const {QueryClient}=req('@tanstack/react-query');
const {getLigandInventoryOwner,inventorySourceKey}=require(path.join(root,'apps/web/src/ligands/inventoryQualification.ts'));
const {LigandPropertySession,propertySourceIdentity,propertyTargetKey}=require(path.join(root,'apps/web/src/ligandProperties/session.ts'));
const {PropertyInputOwner}=require(path.join(root,'apps/web/src/ligandProperties/ownership.ts'));
const {propertyTarget,propertyResult}=require(path.join(root,'apps/web/src/test/ligand-properties-fixtures.ts'));
const evidence=__dirname,proof=JSON.parse(fs.readFileSync(path.join(evidence,'backend-results.json'),'utf8'));
const expected=JSON.parse(fs.readFileSync(path.join(root,'.issue-11-evidence/issue159-verified-source-integration/frozen-source-map.json'),'utf8'));
function guard(){assert.equal(Object.keys(expected).length,1122);for(const[n,d]of Object.entries(expected))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,n))).digest('hex'),d,n)}
const settle=async()=>{for(let i=0;i<25;i++)await Promise.resolve()};
(async()=>{guard();const observations=[];for(const item of proof.cases){
 const entry=item.project.entries[0],row=item.response.entries[0],target={...propertyTarget(),projectId:item.project.id,source:row.source,originalArtifactId:entry.original_artifact_id};
 const client=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity}}}),inventory=getLigandInventoryOwner(client);
 const owner=new PropertyInputOwner(()=>({activeProjectId:target.projectId,inspectedEntryId:target.source.entry_id,sourceIdentity:propertySourceIdentity(target),inputKey:propertyTargetKey(target),paused:false}));
 let next=propertyResult(target),reads=0,events=0,allocations=0,demands=0,lastFailure=null;
 const session=new LigandPropertySession(t=>owner.capture(t),{read:async()=>{reads++;return next},allocate:async()=>{allocations++;throw new Error("Unexpected allocation")},demand:async()=>{demands++;throw new Error("Unexpected demand")},release:async()=>({})});
 const stop=inventory.subscribeVerificationFailures(f=>{events++;lastFailure=f;session.invalidateSource(f.source,f.token,f.reason,()=>owner.retireSource(f.source))});
 const source=propertySourceIdentity(target),key=['ligand-candidates','ligand-instance-v3',source.projectId,source.entryId,source.currentArtifactId,source.originalArtifactId,'ligand-exact-representation-v2','ligand-occurrence-v1','designation',0,12];
 await client.fetchQuery({queryKey:key,queryFn:async()=>item.inventory});
 const stopPublishing=session.publishSourceFailuresTo(inventory.recordSourceFailure);
 session.connect(target);await settle();assert.equal(session.view(target).status,'ready');const capture=owner.capture(target);
 next=item.response;session.retry(target);await settle();assert.equal(session.view(target).status,'unavailable');assert.equal(capture(),false);assert.equal(events,1);assert.equal(reads,2);assert.equal(allocations,0);assert.equal(demands,0);assert.equal(session.view(target).current,undefined);assert.deepEqual(lastFailure.source,source);
 const observation={role:item.role,kind:item.kind,propertyStatus:session.view(target).status,inventoryBlocked:inventory.qualification(inventorySourceKey({id:source.projectId},entry)).blocked,cachedFormula:client.getQueryData(key).candidates[0].formula,verificationEvents:events,reads,originalSource:source.originalArtifactId,currentSource:source.currentArtifactId};observations.push(observation);
 assert.equal(inventory.qualification(inventorySourceKey({id:source.projectId},entry)).blocked,true);
 await client.fetchQuery({queryKey:key,queryFn:async()=>item.recovery_inventory,staleTime:0});await settle();
 assert.equal(inventory.qualification(inventorySourceKey({id:source.projectId},entry)).blocked,false);
 assert.equal(session.view(target).current,undefined);assert.equal(capture(),false);assert.equal(reads,2);assert.equal(allocations,0);assert.equal(demands,0);assert.equal(events,1);
 Object.assign(observation,{candidateGetVerified:true,numbersAbsentAfterCandidateGet:true,readsAfterCandidateGet:reads,demandCalls:demands,allocationCalls:allocations,receivedSource:lastFailure.source,producerRole:row.source_failure.source_verification});
 next=propertyResult(target);session.retry(target);await settle();assert.equal(session.view(target).status,'ready');assert.equal(reads,3);assert.equal(events,1);assert.equal(capture(),false);assert.equal(inventory.qualification(inventorySourceKey({id:source.projectId},entry)).blocked,false);assert.equal(allocations,0);assert.equal(demands,0);
 Object.assign(observation,{capturedAuthorityRetired:true,freshWarmNumericRecovery:true,candidateQualifiedOnlyByFreshCandidateGet:true,finalReads:reads,noNewDemand:true});
 stopPublishing();stop();session.deactivate();inventory.deactivate();client.clear();
 }
 guard();fs.writeFileSync(path.join(evidence,'frontend-result.json'),JSON.stringify({scope:'Installed actual QueryClient/canonical inventory owner/production property session; replays actual physical-source failure HTTP aggregates from disposable backend probe. Baseline property READY transport controlled; no App renderer/browser or scientific job claimed.',source_count:1122,source_fixed:true,observations},null,2)+'\n');
 console.log(JSON.stringify(observations));
 assert(observations.every(r=>r.inventoryBlocked),'Known physical-source failure from property READ must retire cached candidate source qualification');
})().catch(e=>{console.error(e);process.exitCode=1});
