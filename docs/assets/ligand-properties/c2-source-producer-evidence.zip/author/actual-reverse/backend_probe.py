from __future__ import annotations

import hashlib
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))

from neistra_api.database import Base
from neistra_api.main import create_app
from neistra_api.settings import Settings

from tests.integration.test_ligand_property_lifecycle import source
from tests.support.api_client import ApiClient

ROOT = Path.cwd()
FOLDER = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / '.issue-11-evidence/issue159-source-authority-depiction-science'))
from independent_backend_matrix import damage, setup

expected = json.loads((ROOT / '.issue-11-evidence/issue159-verified-source-integration/frozen-source-map.json').read_text())
def guard():
    assert len(expected) == 1122
    assert all(hashlib.sha256((ROOT / n).read_bytes()).hexdigest() == d for n, d in expected.items())
guard()
store = Path(tempfile.mkdtemp(prefix='store-', dir=FOLDER))
settings = Settings(data_dir=store, database_url=f'sqlite:///{store / "test.db"}', auto_create_schema=True, enable_test_routes=True)
app = create_app(settings)
Base.metadata.create_all(app.state.engine)
client = ApiClient(app)
results = []
for role in ('current', 'original'):
    for kind in ('bytes', 'file', 'row'):
        project, entry, url, params, depiction = setup(client, 'warm')
        candidate_reply = client.get(url.rsplit('/', 2)[0], params=params)
        assert candidate_reply.status_code == 200
        inventory = candidate_reply.json()
        body = {'entries': [source(project)], 'descriptor_ids': ['molecular_weight']}
        endpoint = f"/api/v1/projects/{project['id']}/ligand-properties/read"
        baseline = client.post(endpoint, json=body)
        assert baseline.status_code == 200 and baseline.json()['entries'][0]['status'] == 'pending', baseline.text
        with damage(client, entry[f'{role}_artifact_id'], kind):
            reply = client.post(endpoint, json=body)
            assert reply.status_code == 200, reply.text
            current = reply.json()['entries'][0]
            assert current['status'] == 'failed' and current['report'] is None, current
            assert current['source_failure'] == {'source_identity': {'project_id': project['id'], 'entry_id': entry['id'], 'current_artifact_id': entry['current_artifact_id'], 'original_artifact_id': entry['original_artifact_id']}, 'source_verification': role, 'reason': 'artifact_unavailable'}
            results.append({'role': role, 'kind': kind, 'project': project, 'inventory': inventory,
                            'depiction': depiction, 'response': reply.json(),
                            'proof': 'Actual physical-source corruption/missing in disposable store; no worker or scientific job executed'})
app.state.engine.dispose()
guard()
report = {'scope': 'Actual aggregate READ physical-source error classification; no frontend stale-facts claim by this script alone',
          'source_count': len(expected), 'source_fixed': True, 'store': str(store), 'cases': results,
          'public_fields': sorted(results[0]['response']['entries'][0]), 'worker_runs': 0,
          'external_services': 0, 'external_network': 0}
(FOLDER / 'backend-results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'cases': len(results), 'statuses': [r['response']['entries'][0]['status'] for r in results],
                  'public_fields': report['public_fields'], 'source_fixed': True, 'store': str(store)}))
