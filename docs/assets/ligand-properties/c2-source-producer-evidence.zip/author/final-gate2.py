from __future__ import annotations
import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
root = Path.cwd()
e = root / '.issue-11-evidence/issue159-verified-source-integration'
expected = json.loads((e / 'frozen-source-map.json').read_text())
receipt = {'scope':'Author correctness checkpoint, not independent review/readiness/release', 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_count':len(expected), 'source_map_sha256':hashlib.sha256((e/'frozen-source-map.json').read_bytes()).hexdigest(), 'steps':[], 'complete':False}
env = {k:v for k,v in os.environ.items() if k not in {'NEISTRA_DATA_DIR','NEISTRA_DATABASE_URL','MOLWEAVE_DATA_DIR','MOLWEAVE_DATABASE_URL','DATABASE_URL'}}
env.update(NEISTRA_PERFORMANCE='0', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
def guard():
    actual = {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in expected}
    assert actual == expected, [p for p in expected if actual[p] != expected[p]]
def save(): (e/'final2-gate-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
focused = ['src/test/ligand-property-source-producer.test.tsx','src/test/ligand-source-producer-api.test.ts','src/test/ligand-source-producer-app.test.tsx','src/test/ligand-source-producer-owner.test.ts','src/test/ligand-properties-source-verification.test.tsx','src/test/ligand-source-error-api.test.ts','src/test/ligand-properties-session.test.ts','src/test/ligand-properties-ownership.test.ts','src/test/ligand-properties.test.tsx','src/test/ligand-properties-api.test.ts','src/test/ligand-inventory-owner.test.ts','src/test/ligand-designation-controls.test.tsx','src/test/ligand-app-owner.test.tsx']
steps = [
 ('actual-reverse-backend',['.venv/bin/python',str(e/'actual-reverse/backend_probe.py')]),
 ('actual-reverse-frontend',['node',str(e/'actual-reverse/frontend_probe.cjs')]),
 ('ruff',['.venv/bin/uv','run','ruff','check','.']),
 ('format',['.venv/bin/uv','run','ruff','format','--check','apps/api/src/neistra_api/ligand_property_verification.py','apps/api/src/neistra_api/ligand_property_schemas.py','tests/integration/test_ligand_property_source_failures.py','tests/integration/test_ligand_source_producers.py','tests/integration/test_ligand_depiction_source_verification.py']),
 ('mypy',['.venv/bin/uv','run','mypy','apps/api','packages/neistra_core','packages/neistra_demo_plugin']),
 ('frontend-focused',['corepack','pnpm','--filter','@neistra/web','exec','vitest','run',*focused]),
 ('lint',['corepack','pnpm','--filter','@neistra/web','lint']),
 ('types',['corepack','pnpm','--filter','@neistra/web','typecheck']),
 ('web',['corepack','pnpm','--filter','@neistra/web','test']),
 ('build',['corepack','pnpm','--filter','@neistra/web','build']),
]
probe_env = dict(env)
probe_env['PYTHONPATH'] = os.pathsep.join(str(root/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src'])
guard()
prior = json.loads((e/'final-gate-receipt.json').read_text())
oldmap = json.loads((e/'candidate1/frozen-source-map.json').read_text())
assert [p for p in expected if expected[p] != oldmap[p]] == ['apps/web/src/test/ligand-property-source-producer.test.tsx']
for step in prior['steps'][:3]:
    assert step['exit_code'] == 0
    assert hashlib.sha256((root/step['log']).read_bytes()).hexdigest() == step['sha256']
    receipt['steps'].append({**step, 'reused_unchanged_subject':True, 'reason':'Only a TypeScript regression import and mock typing changed; all Python/runtime/fixture source hashes match candidate1 exactly.'})
receipt['preserved_prior_failure'] = {'receipt':'final-gate-receipt.json','outer_exit':1,'failure':'new test unused import/untyped mock; no runtime change'}
save()
for name,command in steps:
    guard();print('START',name,flush=True)
    log=e/f'final2-{name}.log'
    with log.open('wb') as output: result=subprocess.run(command,cwd=root,env=probe_env if name=='actual-reverse-backend' else env,stdout=output,stderr=subprocess.STDOUT)
    receipt['steps'].append({'name':name,'command':command,'exit_code':result.returncode,'log':str(log.relative_to(root)),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});save(); print('EXIT',name,result.returncode,flush=True)
    guard()
    if result.returncode:sys.exit(result.returncode)
receipt.update(complete=True, source_unchanged=True, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print('FINAL AUTHOR CHECKPOINT COMPLETE; sources fixed',len(expected),flush=True)
