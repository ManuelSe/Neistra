"""Package the completed source-producer checkpoint without publication claims."""
from pathlib import Path
import ast
import base64
import datetime
import gzip
import hashlib
import io
import json
import os
import re
import runpy
import zipfile

root = Path.cwd()
private = root / '.issue-11-evidence'
out = private / 'issue159-source-producer-checkpoint-packet'
assets = root / 'docs/assets/ligand-properties'
h = runpy.run_path(str(assets / 'release-evidence.py.txt'))
q = runpy.run_path(str(assets / 'qualification.py.txt'))
sha = lambda body: hashlib.sha256(body).hexdigest()
load = lambda path: json.loads(path.read_bytes())
author = private / 'issue159-verified-source-integration'
arch = private / 'issue159-source-producers-architecture'
science = private / 'issue159-source-producers-science'
docs = private / 'issue159-source-producer-docs'
write_negative = Path('/tmp/neistra159-d198-provenance-architecture-ykeged5i')
archive_path = assets / 'c2-source-producer-evidence.zip'
checkpoint_path = assets / 'c2-source-producer-checkpoint.json'
assert not archive_path.exists() and not checkpoint_path.exists()

expected = {
    author / 'handoff.json': 'eeca044fa297387f5c7cb4507118dfead0ed1d4918b81be49b825e5b61e0e8b5',
    author / 'primary-independent-artifact-readback.json': '6c429b3cbec14399dd252608eb07478d437c60fa97b84670e700224106572db9',
    arch / 'assessment.json': '47aeead9d9a3cd15f1a3162596877f998f2b277a3b37b069b1f6853a7fa5a94b',
    science / 'assessment.json': 'ad4d7e5771ad5176aff7f8c8b088f40708a49d2efb856892fac2026e204ee12f',
    author / 'frozen-source-map.json': '29c3c5c31aaead721d442b95052848786d2786731864405e1777055e22329fbd',
}
for path, value in expected.items():
    assert h['fingerprint'](path)['sha256'] == value, path
handoff = load(author / 'handoff.json')
frozen = load(author / 'frozen-source-map.json')
before = load(author / 'before-source-map.json')
owned = load(author / 'frozen-owned-map.json')
current = q['current_identities'](root)
assert current == frozen and len(current) == 1122
assert sha(json.dumps(current, sort_keys=True, separators=(',', ':')).encode()) == handoff['source_digest']
changed = {n: v for n, v in current.items() if before.get(n) != v}
new = sorted(set(current) - set(before))
assert changed == owned == handoff['owned_paths_and_sha256']
assert len(changed) == 20 and len(new) == 7 and len(before) == 1115 and set(before) <= set(current)
assert len([n for n in before if before[n] == current[n]]) == 1102
for name, row in handoff['artifacts'].items():
    assert h['fingerprint'](author / name) == {'bytes': row['size_bytes'], 'sha256': row['sha256']}, name
assert len(handoff['artifacts']) == 100

old_public = {p.name: h['fingerprint'](p) for p in sorted(assets.iterdir()) if p.is_file()}
protected = load(author / 'D194-49-source-readback.json')
assert len(protected['sources']) == 49
assert all(current[n] == value for n, value in protected['sources'].items())
assert sha(json.dumps(protected['sources'], sort_keys=True).encode()) == protected['method_digest']
d196 = load(author / 'D196-protected-source-readback.json')
assert all(current[n] == value for n, value in d196['unchanged_exact_files'].items())

zip_proofs = []
def check_zip_map(body, identity_map, label):
    with zipfile.ZipFile(io.BytesIO(body)) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist()))
        assert set(z.namelist()) == set(identity_map), label
        for name, value in identity_map.items():
            assert sha(z.read(name)) == value, (label, name)
        zip_proofs.append(dict(label=label, bytes=len(body), sha256=sha(body), entries=len(identity_map), crc_and_exact_complete_entry_hash_map=True))

for directory, prefix in [(author, 'author'), (author / 'candidate1', 'author/candidate1')]:
    for archive, source_map in [('frozen-complete-sources.zip', 'frozen-source-map.json'), ('frozen-owned-sources.zip', 'frozen-owned-map.json')]:
        check_zip_map((directory / archive).read_bytes(), load(directory / source_map), prefix + '/' + archive)
check_zip_map((author / 'before-complete-sources.zip').read_bytes(), before, 'author/before-complete-sources.zip')

negative = private / 'issue159-source-authority-depiction-science/reverse-property-source'
negative_sha = '72841d050ca371a1778aa461610eec39a683f07b9eab6ae08d0476fabf77ea95'
assert h['fingerprint'](negative / 'negative-assessment.json')['sha256'] == negative_sha
with zipfile.ZipFile(author / 'before-prior-evidence.zip') as prior:
    assert prior.testzip() is None and len(prior.namelist()) == 63
    for path in negative.iterdir():
        assert path.is_file() and not path.is_symlink()
        assert prior.read(path.relative_to(private).as_posix()) == path.read_bytes()
    prefix = 'issue159-source-authority-depiction/'
    for archive, map_name in [('complete-before-sources.zip', 'source-before.json'), ('frozen-complete-sources.zip', 'frozen-source-map.json'), ('frozen-owned-sources.zip', 'frozen-owned-map.json')]:
        check_zip_map(prior.read(prefix + archive), json.loads(prior.read(prefix + map_name)), 'author/before-prior-evidence.zip!' + prefix + archive)
    with zipfile.ZipFile(io.BytesIO(prior.read(prefix + 'frozen-complete-sources.zip'))) as old_source:
        source_name = 'apps/api/src/neistra_api/ligand_property_service.py'
        previous_body = old_source.read(source_name)
        final_body = (root / source_name).read_bytes()
        def methods(body):
            lines = body.splitlines(keepends=True)
            parsed = ast.parse(body)
            cls = next(node for node in parsed.body if isinstance(node, ast.ClassDef) and node.name == 'LigandPropertyService')
            return {node.name: b''.join(lines[min([node.lineno] + [d.lineno for d in node.decorator_list]) - 1:node.end_lineno]) for node in cls.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        old_methods, final_methods = methods(previous_body), methods(final_body)
        assert set(old_methods) == set(final_methods) and len(final_methods) == 34
        assert [name for name in old_methods if old_methods[name] != final_methods[name]] == ['_current']
        final_text = final_body.decode()
        service_class = next(node for node in ast.parse(final_text).body if isinstance(node, ast.ClassDef) and node.name == 'LigandPropertyService')
        segment_hashes = {node.name: sha(ast.get_source_segment(final_text, node).encode()) for node in service_class.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name != '_current'}
        assert segment_hashes == d196['unchanged_methods']

gate = load(author / 'final2-gate-receipt.json')
assert gate['complete'] and gate['source_unchanged'] and len(gate['steps']) == 13
for step in gate['steps']:
    assert step['exit_code'] == 0 and h['fingerprint'](root / step['log'])['sha256'] == step['sha256']
assert [s['name'] for s in gate['steps'] if s.get('reused_unchanged_subject')] == ['backend-source', 'D196-focused', 'supervisor']
for name, session, exit_code in [('final-gate-actual-enclosing.json', 55633, 1), ('final2-gate-actual-enclosing.json', 97831, 0), ('extended-reverse-actual-enclosing.json', 46715, 0)]:
    receipt = load(author / name)
    assert receipt['tool_session'] == session and receipt['actual_outer_exit'] == exit_code
for directory in [arch, science]:
    assessment = load(directory / 'assessment.json')
    assert assessment['verdict'] == 'PASS' and assessment['candidate']['source_count'] == 1122
    for name, value in load(directory / 'manifest.json').items():
        expected_sha = value if isinstance(value, str) else value['sha256']
        assert h['fingerprint'](directory / name)['sha256'] == expected_sha

items = {}
captured = {}
retention = {}
links = []
omissions = {}
def add_file(member, path):
    h['add'](items, member, path, reader_workspace=True)
    captured[member] = dict(path=str(path), **h['fingerprint'](path))
def collect(directory, prefix):
    assert directory.is_dir() and not directory.is_symlink()
    retained = {}
    excluded = []
    for path in sorted(directory.rglob('*')):
        member = prefix + '/' + path.relative_to(directory).as_posix()
        if path.is_symlink():
            target = path.resolve(strict=True)
            assert target.is_relative_to(directory.resolve())
            convenience = path.name.endswith('current')
            if not convenience:
                assert directory == author and path.relative_to(directory).as_posix() == 'final-D196-stores/test_corrupt_path_and_symlink_0/cache/ligand-properties-v1/artifacts/sha256/f8/f839f6148749e60fdd9c6f5bb16ede356af31774d4b3c4a01629eae9693729fb'
                assert target.name == 'external-user-file' and target.is_file()
            links.append(dict(member=member, path=str(path), raw_link_text=os.readlink(path), raw_link_bytes_base64=base64.b64encode(os.fsencode(os.readlink(path))).decode(), lstat_mode=path.lstat().st_mode, resolved_member=prefix + '/' + target.relative_to(directory.resolve()).as_posix(), target_is_directory=target.is_dir(), target_within_owned_root=True, followed=False, classification='pytest convenience alias' if convenience else 'intentional owned synthetic security fixture'))
            continue
        if not path.is_file():
            continue
        if h['CACHE_PARTS'].intersection(path.parts) or path.suffix in {'.pyc', '.pyo'}:
            excluded.append(dict(path=path.relative_to(directory).as_posix(), **h['fingerprint'](path)))
            continue
        add_file(member, path)
        retained[member] = h['fingerprint'](path)
    retention[str(directory)] = dict(prefix=prefix, regular_files=len(retained), bytes=sum(v['bytes'] for v in retained.values()), all_noncache_regular_files_retained=True, regular_file_identities=retained)
    omissions[str(directory)] = excluded

collect(author, 'author')
collect(arch, 'independent-architecture')
collect(science, 'independent-scientific-implementation')
collect(docs, 'primary-documentation-update')
assert h['fingerprint'](write_negative / 'complete-architecture-assessment.json')['sha256'] == 'be091041dc6ae7d84ddff425bad403784bd318e30061042e2c188caf2ce74a4b'
assert h['fingerprint'](write_negative / 'designation-negative.log')['sha256'] == '707b4c22938ac2378e4d170c8824421f706ad4ab1623239a26827ce85cbefe22'
collect(write_negative, 'original-159-write-negative')
assert retention[str(write_negative)]['regular_files'] == 12
for row in links:
    if row['target_is_directory']:
        assert any(n.startswith(row['resolved_member'] + '/') for n in items), row
    else:
        assert row['resolved_member'] in items, row
assert len(links) == 138
for name in changed:
    add_file('current-owned-source/' + name, root / name)
for name in load(docs / 'documentation-update.json')['paths']:
    add_file('current-checkpoint-documentation/' + name, root / name)
add_file('operations/packager.py', Path(__file__).resolve())
for name in ['package-attempt1.py', 'package-attempt1.log', 'package-attempt1-actual-enclosing.json', 'package-attempt2.py', 'package-attempt2.log', 'package-attempt2-actual-enclosing.json']:
    add_file('operations/' + name, out / name)

tool_facts = dict(scope='Truthful packaging inspection tool observations; no fabricated raw logs', observations=[dict(actual_tool_chunk='2a7c9b', actual_outer_exit=127, command='python - << heredoc', phase='inspection before package construction', observed_output='/bin/bash: line 1: python: command not found', correction='Use installed python3; no repository change', evidence_kind='Direct visible tool-result transcription; no persisted raw log exists'), dict(actual_tool_chunk='6f60e4', actual_outer_exit=1, command='ls documentation-update folder; cat receipt.json then bound evidence', phase='inspection before package construction', observed_output='Requested receipt.json absent; actual file is documentation-update.json', correction='Read the existing documentation-update.json; no repository change', evidence_kind='Direct visible tool-result transcription; no persisted raw log exists')], historical_observer_failure=dict(bound_receipt='author/primary-independent-artifact-readback.json', actual_tool_chunk='3a724b', actual_outer_exit=1, failure='Observer expected extended log/sha256 keys instead of name/log_sha256', evidence_kind='Primary transcription in original bound receipt; no invented raw log'))
h['add'](items, 'packaging-observed-tool-facts.json', h['encoded'](tool_facts))
h['add'](items, 'owned-links.json', h['encoded'](dict(scope='Validated metadata only; target bodies separately retained as regular payloads; no active archive symlinks', links=links)))
h['add'](items, 'raw-retention.json', h['encoded'](dict(roots=retention, named_cache_omissions=omissions, all_originals_preserved=True)))
h['add'](items, 'nested-source-zip-map-readback.json', h['encoded'](zip_proofs))

proof = dict(scope='Exact source identity for this local checkpoint; not execution of a full qualification gate', source_count=1122, source_map_sha256=expected[author / 'frozen-source-map.json'], compact_source_digest=handoff['source_digest'], source_before=current, source_after=q['current_identities'](root), original_source_count=1115, original_source_map=before, changed_or_added_count=20, existing_changed_count=13, new_count=7, new_paths=new, changed_or_added_sources=owned, unchanged_previous_count=1102, removed_paths=[], D194_49_exact=True, D194_method_digest=protected['method_digest'], D196_protected_files_exact=True, service_methods_total=34, service_methods_byte_exact=33, sole_service_method_changed='_current', captured_originals=captured, previous_public_assets=old_public, previous_public_assets_embedded=False, previous_public_assets_scope='Bound by full byte identity; existing C1/startup packets and unrelated historical workloads are not duplicated')
assert proof['source_before'] == proof['source_after']
h['add'](items, 'source-proof.json', h['encoded'](proof))
reviews = dict(software_architecture=dict(verdict='PASS', assessment='independent-architecture/assessment.json', sha256=expected[arch / 'assessment.json'], scope='Accepted D198 source-producer integration only', independent_backend_cases=21, actual_ASGI_cases=6, production_session_replays=6, unavailable_PYTHONPATH_failure_preserved=True), scientific_implementation=dict(verdict='PASS', assessment='independent-scientific-implementation/assessment.json', sha256=expected[science / 'assessment.json'], scope='Accepted D198 source-producer integration only', independent_backend_cases=58, independent_frontend_cases=148, actual_ASGI_cases=6, production_session_replays=12), all_seven_final_assessment_complete=False, distinct_proofs_not_pooled=True)
h['add'](items, 'scoped-review-provenance.json', h['encoded'](reviews))
facts = dict(scope='Completed D198 source-producer local checkpoint only; no feature completion, readiness, prerequisite delivery, merge or release claim', issue=159, parent=11, declared_local_base=handoff['local_base'], candidate=2, source_count=1122, source_map_sha256=expected[author / 'frozen-source-map.json'], compact_source_digest=handoff['source_digest'], changed_or_added_source_count=20, existing_changed_source_count=13, new_source_count=7, physical_fact_boundary='Known physical current/original input snapshot and read failures carry exact four primitive source IDs and role. Existing request/generation/ownership guards validate READ and demand facts before synchronous canonical barrier/event publication and immediate return. No physical authority is inferred from generic status/reason, worker, chemistry, capacity, transport, designation or derived SVG/report failures.', write_boundary='Candidates/depiction use exact query owners; Use and legacy resolve publish inside the captured actual API operation before feedback gates. Batch facts require an exact requested member and all four immutable source fields. Malformed supplied identity cannot fall back. Clear and semantic input-hash rejection fabricate no physical proof.', recovery='Canonical candidate qualification and numeric authority are independent. Candidate success alone cannot restore numbers; a fresh matching source-verified property READ may recover warm numbers without a new demand and without qualifying candidate facts. Old held reads remain fenced.', author_verification=dict(reused_from_unchanged_python_subject=dict(backend=90, D196_regressions=156, process_supervisors=6, supervisor_deselected=3, reason='Candidate2 changes only new TypeScript test unused import/mock typing; no runtime or assertion changes'), fresh_candidate2=dict(frontend_focused=357, frontend_focused_files=13, web=1559, web_files=133, ruff='PASS', scoped_format='PASS', mypy_files=274, web_lint='PASS', web_types='PASS', web_build='PASS'), actual_outer_observations=[dict(session=55633, exit=1, chunk='650bbd', scope='Preserved candidate1 lint failure'), dict(session=97831, exit=0, chunk='8103de', scope='Candidate2 author checkpoint'), dict(session=46715, exit=0, chunk='8672b5', scope='Extended six-case actual-source replay')], actual_scope='Physical failures and restored candidate GET use disposable real in-process ASGI. READY and warm numeric recovery responses use controlled frontend transports. No new scientific calculation or App/browser execution.'), scoped_specialist_agent_reviews=reviews, source_preservation=dict(complete_before_sources=1115, complete_current_sources=1122, failed_candidate1_sources=1122, owned_current_and_candidate1_sources=20, original_reverse_negative_sha256=negative_sha, before_prior_evidence_members=63, original_reverse_negative_files_exact=8, author_handoff_artifacts_exact=100, protected_D194_sources=49, protected_D196_service_methods=33), remaining_limits=['Actual delivered preceding child integration and final159 native/full qualification remain required.', 'Downstream160/161 profile/radar propagation and verification are separate parent-owned work.', 'No full Python suite, fresh native/browser/services, new descriptor calculation, performance or release gate was run for this packet.', 'Historical D194 selected desktop probe4: five cold starts and20 paired edits; median2057.95ms/p952242.60ms exceeds unchanged2000ms target. Portable correctness evidence is not target or strict-host certification.', 'Seven other performance cases and four1000-entry cohorts remain unexecuted; ALL8 preparation5/6 is historical HOLD.', 'All-seven same-final-candidate assessments and complete candidate/exact-master gates remain pending.', 'Copied native source-write regression is retained as source, unexecuted here. Existing large-chunk build advisory remains.'], previous_public_assets=old_public, previous_public_assets_not_duplicated=True, all_original_stores_and_evidence_preserved=True)
h['add'](items, 'checkpoint-context.json', h['encoded'](facts))

# Build the neutral-name guard without embedding restricted reference terms.
restricted = re.compile(r'\b(?:' + '|'.join(bytes.fromhex(s).decode() for s in ['6d61657374726f', '736368726f64696e676572', '73636872c3b664696e676572', '736368726f6564696e676572']) + r')\b', re.I)
scan_counts = dict(zip_archives=0, text_payloads=0)
def scan(body, label):
    assert not restricted.search(label), 'restricted member name'
    if body[:4] in {b'PK\x03\x04', b'PK\x05\x06', b'PK\x07\x08'}:
        scan_counts['zip_archives'] += 1
        with zipfile.ZipFile(io.BytesIO(body)) as z:
            for name in z.namelist():
                scan(z.read(name), label + '!' + name)
    elif body.startswith(b'\x1f\x8b'):
        scan(gzip.decompress(body), label + '!gunzip')
    else:
        try:
            text = body.decode('utf-8')
        except UnicodeDecodeError:
            return
        scan_counts['text_payloads'] += 1
        assert not restricted.search(text), 'restricted text payload: ' + label
for name, member in items.items():
    scan(member.read_bytes() if isinstance(member, Path) else member, name)
estimate = sum(h['compressed_size'](member) for member in items.values())
assert estimate < 76 * 1024 * 1024
packet = h['archive'](items, archive_path)
assert packet['bytes'] < 80 * 1024 * 1024
assert q['current_identities'](root) == current
assert {p.name: h['fingerprint'](p) for p in assets.iterdir() if p.is_file() and p.name in old_public} == old_public
for row in captured.values():
    assert h['fingerprint'](Path(row['path'])) == {key: row[key] for key in ['bytes', 'sha256']}
record = dict(**facts, archive=packet['file'], archive_bytes=packet['bytes'], archive_sha256=packet['sha256'], outer_manifest_entries=packet['outer_manifest_entries'], recursive_verification=packet['verification_counts'], naming_scan=scan_counts, observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
record_bytes = h['encoded'](record)
scan(record_bytes, checkpoint_path.name)
checkpoint_path.write_bytes(record_bytes)
result = dict(archive=packet, checkpoint=h['fingerprint'](checkpoint_path), source_count=1122, final_source_exact=True, previous_public_assets_unchanged=True, captured_originals_unchanged=True, retained_root_counts={v['prefix']: v['regular_files'] for v in retention.values()}, symlink_metadata_count=len(links), named_cache_omission_count=sum(len(v) for v in omissions.values()), naming_scan=scan_counts, no_git_mutation=True)
(out / 'packager-result.json').write_bytes(h['encoded'](result))
print(json.dumps(result, indent=2), flush=True)
