from pathlib import Path
import ast, hashlib, json, subprocess, zipfile
from datetime import datetime, UTC
root=Path.cwd()
out=root/'.issue-11-evidence/issue159-source-producers-science'
author=root/'.issue-11-evidence/issue159-verified-source-integration'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected=json.loads((author/'frozen-source-map.json').read_text())
def guard():
    mismatches=[p for p,h in expected.items() if sha((root/p).read_bytes())!=h]
    assert not mismatches, mismatches
    return {'source_count':len(expected),'map_sha256':sha((author/'frozen-source-map.json').read_bytes()),'compact_digest':sha(json.dumps(expected,sort_keys=True,separators=(',',':')).encode()),'mismatches':mismatches}
report={'scope':'Independent bounded scientific implementation review; no final feature or release approval','started':datetime.now(UTC).isoformat(),'before':guard(),'steps':[]}
assert sha((author/'handoff.json').read_bytes())=='eeca044fa297387f5c7cb4507118dfead0ed1d4918b81be49b825e5b61e0e8b5'
owned=json.loads((author/'frozen-owned-map.json').read_text())
before=json.loads((author/'before-source-map.json').read_text())
changes=[p for p,h in expected.items() if before.get(p)!=h]
assert set(changes)==set(owned), (set(changes)-set(owned),set(owned)-set(changes))
report['changed_paths']=changes
report['unchanged_previous_sources']=len(set(before)&set(expected))-sum(p in before for p in changes)
report['author_artifact_verification']=[]
for name in ('frozen-complete-sources.zip','before-complete-sources.zip','frozen-owned-sources.zip'):
    with zipfile.ZipFile(author/name) as z:
        assert z.testzip() is None
        source_map=before if name.startswith('before') else owned if 'owned' in name else expected
        assert set(z.namelist())==set(source_map)
        assert all(sha(z.read(p))==h for p,h in source_map.items())
    report['author_artifact_verification'].append({'path':name,'sha256':sha((author/name).read_bytes()),'verified_sources':len(source_map)})
with zipfile.ZipFile(author/'before-complete-sources.zip') as z:
    p='apps/api/src/neistra_api/ligand_property_service.py'
    old=z.read(p).decode();new=(root/p).read_text()
    def methods(s):
        return {n.name:ast.get_source_segment(s,n) for n in ast.walk(ast.parse(s)) if isinstance(n,ast.ClassDef) and n.name=='LigandPropertyService' for n in n.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    oldmethods,newmethods=methods(old),methods(new)
    changed=[n for n in oldmethods if oldmethods[n]!=newmethods[n]]
    assert changed==['_current']; report['service_changed_methods']=changed;report['unchanged_service_methods']=len(oldmethods)-1
    original_tests=['apps/web/src/test/ligand-properties-source-verification.test.tsx','apps/web/src/test/ligand-source-error-api.test.ts']
    assert all(z.read(p)==(root/p).read_bytes() for p in original_tests)
    report['old_source_authority_test_files_exact']=original_tests
for name,field in [('D194-49-source-readback.json','sources'),('D196-protected-source-readback.json','unchanged_exact_files')]:
    proof=json.loads((author/name).read_text()); entries=proof[field]
    assert all(sha((root/p).read_bytes())==h for p,h in entries.items())
    report[name]={'checked':len(entries),'exact':True}
steps=[('backend', ['.venv/bin/python','-m','pytest','-q','tests/integration/test_ligand_property_source_failures.py','tests/integration/test_ligand_source_producers.py','tests/integration/test_ligand_depiction_source_verification.py','--basetemp',str(out/'backend-stores')]),('frontend',['corepack','pnpm','--filter','@neistra/web','exec','vitest','run','src/test/ligand-property-source-producer.test.tsx','src/test/ligand-properties-source-verification.test.tsx','src/test/ligand-source-error-api.test.ts','src/test/ligand-source-producer-owner.test.ts','src/test/ligand-source-producer-api.test.ts','src/test/ligand-source-producer-app.test.tsx'])]
try:
    for name,cmd in steps:
        with (out/f'{name}.log').open('w') as log:
            result=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
        report['steps'].append({'name':name,'command':cmd,'exit_code':result.returncode,'log':f'{name}.log','log_sha256':sha((out/f'{name}.log').read_bytes())})
        print(name,result.returncode,flush=True)
        assert result.returncode==0
finally:
    report['after']=guard();report['finished']=datetime.now(UTC).isoformat()
    (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
