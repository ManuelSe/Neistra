from pathlib import Path
import hashlib,json
from importlib.metadata import version
root=Path.cwd();folder=root/'.issue-11-evidence/issue159-source-producers-science';author=root/'.issue-11-evidence/issue159-verified-source-integration'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_map=json.loads((author/'frozen-source-map.json').read_text());assert all(sha(root/p)==h for p,h in source_map.items())
receipt=json.loads((folder/'receipt.json').read_text())
receipt['actual_outer_completions']=[{'session_id':29382,'chunk_id':'b935cb','exit_code':0,'scope':'Independent source archive/readback and focused backend/frontend subprocess harness','evidence_kind':'Direct tool completion observation'},{'session_id':52261,'chunk_id':'6846be','exit_code':0,'command':'PYTHONPATH=apps/api/src:packages/neistra_core/src:packages/neistra_demo_plugin/src .venv/bin/python .issue-11-evidence/issue159-source-producers-science/independent_asgi.py','log':'independent-asgi.log','scope':'Independent real in-process ASGI six physical failures and unsupported molecular-metadata control','evidence_kind':'Direct tool completion observation'},{'chunk_id':'bc1e1f','exit_code':0,'command':'node .issue-11-evidence/issue159-source-producers-science/independent_session.cjs','log':'independent-session.log','scope':'12 independent installed production session/canonical-owner replays of actual ASGI responses, both recovery orders','evidence_kind':'Direct tool completion observation'}]
receipt['installed_versions']={p:version(p) for p in ['rdkit','pydantic','fastapi','sqlalchemy','pytest']}
receipt['final_source_guard']={'count':len(source_map),'all_exact':True}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assessment={
'verdict':'PASS',
'scope':'Independent read-only scientific implementation assessment of D198 source-producer integration in issue159 before propagation; not final whole-feature/readiness/release approval',
'candidate':{'parent_declared_head':'f6e847b8e25eb4d1068f8b14741fda6fb8bdd0d0','uncommitted_candidate':2,'source_count':1122,'source_map_sha256':sha(author/'frozen-source-map.json'),'compact_digest':hashlib.sha256(json.dumps(source_map,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'author_handoff_sha256':sha(author/'handoff.json'),'independently_verified_current_files':True},
'inspected_scope':{'all_changed_or_added_paths':receipt['changed_paths'],'surrounding_boundaries':['apps/api/src/neistra_api/ligand_property_identity.py','apps/web/src/ligandProperties/ownership.ts','apps/api/src/neistra_api/import_export.py'],'contract':'Repository product/global and issue159 plan/progress, D194/D196/D198 decisions; no new method selection','author_evidence':['handoff.json','owned.diff','property-service-owned.diff','final2-gate-receipt.json','extended-reverse/backend_probe.py','extended-reverse/frontend_probe.cjs','extended-reverse/backend-results.json','extended-reverse/frontend-result.json']},
'prioritized_findings':[],
'acceptance_evidence':[
'All 1122 current source hashes match frozen map before and after independent checks; archive CRC/all source payload hashes match. Exactly 20 changed/added paths versus 1115-source snapshot; outside paths unchanged.',
'Original 49 source-authority test file and separate 9 API-error cases byte exact; focused fresh execution includes all 49. D194 49 protected files and D196 protected file set exact. Of 34 property-service methods, only _current changes and merely projects optional typed provenance.',
'58 fresh backend tests pass: actual current/original physical source failures, read/demand, shared-artifact per-row attribution, primitive identity preserved across ORM refresh, unsupported/capacity/worker/designation and derived-depiction discrimination, write producer identity and unchanged project state.',
'148 fresh frontend cases pass in six files: new36 producer, original49 source-authority,9 API error,29 API producer,14 canonical owner and11 App cases.',
'Independent ASGI probe separately obtains six physical failures (two roles times corruption/missing file/missing metadata), each HTTP200 failed/no report with exact four IDs and role; restored sources and project GETs remain intact. A physically verified but unsupported normalized-metadata control is unavailable/no report/no source_failure.',
'12 independent production session/canonical inventory owner/installed QueryClient replays consume the six independent ASGI responses in both candidate-first and numeric-first recovery orders. Exactly one event retires numerical current values and old capture; no allocation/demand. Actual post-restore candidate GET cannot revive numbers; controlled fresh property READ cannot qualify candidate facts.',
'Author focused static/global web evidence inspected and source-matched; independent review does not relabel author evidence as reviewer execution.'
],
'scientific_assumptions':[
'Observed physical source availability is separate from valid molecular interpretation, descriptor method qualification and candidate qualification. Generic failed status/reason, unsupported chemistry, worker/capacity and derived report/SVG errors do not prove physical source damage.',
'Four primitive source IDs are captured before refresh; immutable-source identity and current/original attribution survive shared-artifact memoization and delayed events.',
'No numerical methods, descriptor parameters, units, coordinate frame, dtype, atom identity/order, original bytes, chemistry stack or worker scheduling change in this correction.'
],
'limitations':[
'Independent numerical READY baseline/recovery transports use existing controlled fixtures; actual physical failures and restored candidate GETs use real disposable ASGI. No new descriptor calculation, browser/App-renderer replay or performance claim.',
'Native regression reviewed as source but not executed; no services/native workers/browser/performance run. No full-suite duplication.',
'Propagation to160/161, profile/radar consumers, final integrated native/performance/full candidate/exact-master gates, delivered prerequisite and all-seven final readiness remain parent responsibilities.'
],
'private_evidence_only':True,
'source_edits':[]}
(folder/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')
manifest={p.name:sha(p) for p in folder.iterdir() if p.is_file() and p.name!='manifest.json'}
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'verdict':assessment['verdict'],'source_count':len(source_map),'assessment_sha256':sha(folder/'assessment.json'),'receipt_sha256':sha(folder/'receipt.json'),'independent_backend':58,'independent_frontend':148,'independent_ASGI':7,'independent_session':12,'source_fixed':True}))
