const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const root=process.cwd(),req=Module.createRequire(path.join(root,'apps/web/package.json')),ts=req('typescript');
require.extensions['.ts']=(m,p)=>m._compile(ts.transpileModule(fs.readFileSync(p,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,p);
const {QueryClient}=req('@tanstack/react-query');
const {getLigandInventoryOwner,inventorySourceKey}=require(path.join(root,'apps/web/src/ligands/inventoryQualification.ts'));
const {LigandPropertySession,propertySourceIdentity,propertyTargetKey}=require(path.join(root,'apps/web/src/ligandProperties/session.ts'));
const {PropertyInputOwner}=require(path.join(root,'apps/web/src/ligandProperties/ownership.ts'));
const {propertyTarget,propertyResult}=require(path.join(root,'apps/web/src/test/ligand-properties-fixtures.ts'));
const input=JSON.parse(fs.readFileSync(path.join(__dirname,'independent-asgi-results.json'),'utf8'));
const settle=async()=>{for(let i=0;i<30;i++)await Promise.resolve()};
(async()=>{const checks=[];for(const item of input.physical_cases)for(const order of ['candidate-first','numeric-first']){
 const project=item.project,entry=project.entries[0],target={...propertyTarget(),projectId:project.id,source:item.response.entries[0].source,originalArtifactId:entry.original_artifact_id};
 const source=propertySourceIdentity(target),queryClient=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity}}}),inventory=getLigandInventoryOwner(queryClient);
 const key=['ligand-candidates','ligand-instance-v3',source.projectId,source.entryId,source.currentArtifactId,source.originalArtifactId,'ligand-exact-representation-v2','ligand-occurrence-v1','designation',0,12];
 const qualification=()=>inventory.qualification(inventorySourceKey({id:source.projectId},entry));
 const owner=new PropertyInputOwner(()=>({activeProjectId:source.projectId,inspectedEntryId:source.entryId,inputKey:propertyTargetKey(target),sourceIdentity:source,paused:false}));
 let response=propertyResult(target),readCount=0,eventCount=0;
 const session=new LigandPropertySession(t=>owner.capture(t),{read:async()=>{readCount++;return response},allocate:async()=>{throw Error('Unexpected allocation')},demand:async()=>{throw Error('Unexpected demand')},release:async()=>({})});
 const unlisten=inventory.subscribeVerificationFailures(failure=>{eventCount++;assert.deepEqual(failure.source,source);session.invalidateSource(failure.source,failure.token,failure.reason,()=>owner.retireSource(failure.source))});
 const unpublish=session.publishSourceFailuresTo(inventory.recordSourceFailure);
 await queryClient.fetchQuery({queryKey:key,queryFn:async()=>item.inventory});session.connect(target);await settle();assert.equal(session.view(target).status,'ready');const capture=owner.capture(target);
 response=item.response;session.retry(target);await settle();assert.equal(eventCount,1);assert.equal(readCount,2);assert.equal(session.view(target).current,undefined);assert.equal(capture(),false);assert.equal(qualification().blocked,true);
 const freshCandidate=async()=>{await queryClient.fetchQuery({queryKey:key,queryFn:async()=>item.recovered_inventory,staleTime:0});await settle();assert.equal(qualification().blocked,false)};
 const freshNumeric=async()=>{response=propertyResult(target);session.retry(target);await settle();assert.equal(session.view(target).status,'ready');assert.equal(capture(),false)};
 if(order==='candidate-first'){await freshCandidate();assert.equal(session.view(target).current,undefined);assert.equal(readCount,2);await freshNumeric()}
 else{await freshNumeric();assert.equal(qualification().blocked,true);await freshCandidate()}
 assert.equal(eventCount,1);assert.equal(readCount,3);
 checks.push({role:item.role,kind:item.kind,order,verification_events:eventCount,reads:readCount,old_capture_retired:!capture(),numerical_recovery_independent:true,candidate_recovery_independent:true});
 unpublish();unlisten();session.deactivate();inventory.deactivate();queryClient.clear();
 }
 fs.writeFileSync(path.join(__dirname,'independent-session-results.json'),JSON.stringify({scope:'Production session/canonical owner/actual QueryClient replay of independently obtained ASGI failures and recovered candidate GETs; initial and recovery numerical transports are controlled fixtures, no chemistry calculation or browser claimed',checks},null,2)+'\n');console.log('PASS: 12 production session replays, exact identity, one event, capture retirement, both independent recovery orders, no allocation/demand');
})().catch(error=>{console.error(error);process.exitCode=1});
