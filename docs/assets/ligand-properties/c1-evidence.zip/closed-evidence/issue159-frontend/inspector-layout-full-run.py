import datetime,hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path.cwd();out=root/'.issue-11-evidence/issue159-frontend';receipt=out/'inspector-layout-full-checks.json';assert not receipt.exists()
paths=list(json.loads((out/'inspector-layout-before.json').read_text())['source_before16'])
def identities():
 return {p:{'bytes':len(b:=(root/p).read_bytes()),'sha256':hashlib.sha256(b).hexdigest()} for p in paths}
state={'scope':'Affected fullfrontend validation for inspector layout correction; no native geometry or release qualification claim','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_before':identities(),'steps':[],'complete':False}
def save(): receipt.write_text(json.dumps(state,indent=2)+'\n')
save()
for label,argv in [('lint',['corepack','pnpm','--dir','apps/web','lint']),('types',['corepack','pnpm','--dir','apps/web','typecheck']),('test',['corepack','pnpm','--dir','apps/web','test']),('build',['corepack','pnpm','--dir','apps/web','build'])]:
 log=out/f'inspector-layout-full-{label}.log';started=time.monotonic();print('START',label,flush=True)
 with log.open('wb') as stream:
  child=subprocess.Popen(argv,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);code=child.wait()
 data=log.read_bytes();after=identities();state['steps'].append({'label':label,'command':argv,'actual_child_pid':child.pid,'exit_code':code,'seconds':round(time.monotonic()-started,3),'log':str(log),'log_sha256':hashlib.sha256(data).hexdigest(),'source_after':after,'owned_sources_unchanged':after==state['source_before']});save();print('EXIT',label,code,'SOURCES_UNCHANGED',after==state['source_before'],flush=True);print(data.decode(errors='replace')[-1700:],flush=True)
 if code or after!=state['source_before']:raise SystemExit(code or 1)
state['complete']=True;state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('ALL FRONTEND CHECKS PASS',receipt,flush=True)
