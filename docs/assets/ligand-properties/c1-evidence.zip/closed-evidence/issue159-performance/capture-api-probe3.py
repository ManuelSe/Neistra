from pathlib import Path
import json,traceback
import tests.support.ligand_property_performance_qualification as h
ROOT=Path.cwd(); OUT=ROOT/".issue-11-evidence/issue159-performance/api-probe3-capture"
def differences(a,b,path=""):
 if type(a) is not type(b):return [{"path":path,"before":a,"after":b}]
 if isinstance(a,dict):return [d for k in sorted(set(a)|set(b)) for d in (differences(a.get(k),b.get(k),path+"/"+k))]
 if isinstance(a,list):
  if len(a)!=len(b):return [{"path":path,"before_len":len(a),"after_len":len(b)}]
  return [d for i,(x,y) in enumerate(zip(a,b)) for d in differences(x,y,path+"/"+str(i))]
 return [] if a==b else [{"path":path,"before":a,"after":b}]
if __name__=="__main__":
 assert not OUT.exists();OUT.mkdir();events=[];original=h.Calls.send
 def observed(self,method,path,**kwargs):
  result=original(self,method,path,**kwargs);events.append({"method":method,"path":path,"result":result});return result
 h.Calls.send=observed
 try:h.sample(OUT,0)
 except BaseException as error:
  (OUT/"raw-error.txt").write_text(traceback.format_exc());(OUT/"actual-calls.json").write_text(json.dumps(events,indent=2)+"\n")
  changed=next(row["result"] for row in events if row["method"]=="POST" and row["path"].endswith("/selection-transform"));projectpath="/api/v1/projects/"+changed["id"];after=[row["result"] for row in events if row["method"]=="GET" and row["path"]==projectpath][-1];delta=differences(changed,after);(OUT/"coordinate-comparison.json").write_text(json.dumps({"scope":"ExactproductionAPI replay with response observation only; no substituted outputs or source edits","failure_type":type(error).__name__,"differences":delta},indent=2)+"\n");print(json.dumps(delta,indent=2));raise
