const { readFileSync } = require('node:fs');
const { resolve } = require('node:path');
const assert = require('node:assert/strict');
const text = readFileSync('tests/e2e/ligand-properties-performance.spec.ts', 'utf8');
const start = text.indexOf('  const legacyStore =');
const end = text.indexOf('  const turnTrace =', start);
assert(start >= 0 && end > start);
const actual = new Function('process', 'resolve', text.slice(start, end) + '\nreturn { data, database };');
const cases = [
  [{}, '.neistra-e2e', 'neistra.db'],
  [{ NEISTRA_E2E_DATA_DIR: '/tmp/canonical-property-contract' }, '/tmp/canonical-property-contract', 'neistra.db'],
  [{ MOLWEAVE_E2E_DATA_DIR: '/tmp/legacy-property-contract' }, '/tmp/legacy-property-contract', 'molweave.db'],
  [{ NEISTRA_E2E_DATA_DIR: '/tmp/canonical-property-contract', MOLWEAVE_E2E_DATA_DIR: '/tmp/legacy-property-contract' }, '/tmp/canonical-property-contract', 'neistra.db'],
];
for (const [env, data, basename] of cases) assert.deepEqual(actual({ env }, resolve), { data: resolve(data), database: resolve(data, basename) });
console.log(JSON.stringify({ scope: 'Offline evaluation of exact native harness database-prefix statements; no database or service opened', passed: cases.length }, null, 2));
