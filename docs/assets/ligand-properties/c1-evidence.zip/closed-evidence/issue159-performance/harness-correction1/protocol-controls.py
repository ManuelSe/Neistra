"""Offline harness evidence controls; no scheduler, API, services or chemistry run."""
from __future__ import annotations
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path.cwd()))
from tests.support import ligand_property_performance_qualification as q

checks = []

def record(name, action):
    action()
    checks.append(name)

with tempfile.TemporaryDirectory(prefix='neistra-property-harness-protocol-') as name:
    root = Path(name)
    def make(label):
        data = root / label
        data.mkdir()
        settings = SimpleNamespace(data_dir=data, database_url='sqlite:///' + str(data / 'neistra.db'))
        with patch.object(q, 'source_inventory', return_value={}):
            return q.QualificationWorkerTrace(data / 'qualification/worker-turns.jsonl', settings)
    def invalid_path():
        data = root / 'bad-path'; data.mkdir()
        settings = SimpleNamespace(data_dir=data, database_url='sqlite:///' + str(data / 'neistra.db'))
        try: q.QualificationWorkerTrace(data / 'unexpected.jsonl', settings)
        except AssertionError: pass
        else: raise AssertionError('arbitrary trace path accepted')
        assert not (data / 'unexpected.jsonl').exists()
    record('arbitrary_trace_path_rejected_without_file', invalid_path)
    def symlink_path():
        data = root / 'linked'; data.mkdir(); external = root / 'outside'; external.mkdir()
        (data / 'qualification').symlink_to(external, target_is_directory=True)
        settings = SimpleNamespace(data_dir=data, database_url='sqlite:///' + str(data / 'neistra.db'))
        try: q.QualificationWorkerTrace(data / 'qualification/worker-turns.jsonl', settings)
        except AssertionError: pass
        else: raise AssertionError('retargeted path accepted')
        assert not (external / 'worker-turns.jsonl').exists()
    record('symlink_retarget_rejected_without_external_write', symlink_path)
    def record_overflow():
        trace = make('record-cap'); trace.MAX_RECORDS = 1
        try: trace.emit('must-not-appear')
        except RuntimeError: pass
        else: raise AssertionError('record cap did not fail')
        trace.handle.close()
        incomplete = json.loads(trace.incomplete_path.read_text())
        assert incomplete['complete'] is False
        assert len(trace.path.read_text().splitlines()) == 1
    record('record_overflow_explicit_incomplete_no_silent_drop', record_overflow)
    def finite_json():
        trace = make('finite')
        try: trace.emit('invalid', value=float('nan'))
        except RuntimeError: pass
        else: raise AssertionError('nonfinite record accepted')
        trace.handle.close()
        assert json.loads(trace.incomplete_path.read_text())['complete'] is False
        assert len(trace.path.read_text().splitlines()) == 1
    record('nonfinite_json_explicit_incomplete_no_partial_publish', finite_json)
    def cap_tail():
        trace = make('tail')
        trace.emit('large-complete', payload='x' * (trace.MAX_RECORD_BYTES - 512))
        partial = b'{"partial":"' + b'x' * (trace.MAX_RECORD_BYTES - 512)
        with trace.path.open('ab') as writer: writer.write(partial)
        output = trace.path.parent / 'observer.json'
        tail = q.WorkOrderTail(trace.path, output, trace.path.parent.parent / 'neistra.db', {})
        assert tail.state['start_record'] == 2
        state = tail.finish()
        assert state['complete'] and state['records'] == 0
        assert state['trailing_inflight_record']['bytes'] == len(partial)
        trace.handle.close()
    record('maximum_complete_record_plus_inflight_tail_preserved', cap_tail)
    def discontinuity():
        trace = make('discontinuity')
        tail = q.WorkOrderTail(trace.path, trace.path.parent / 'observer.json', trace.path.parent.parent / 'neistra.db', {})
        with trace.path.open('a') as writer: writer.write(json.dumps({'record':3}) + '\n')
        try: tail.poll()
        except AssertionError: pass
        else: raise AssertionError('record gap accepted')
        tail.target.close(); tail.source.close(); trace.handle.close()
    record('noncontiguous_work_order_rejected', discontinuity)

print(json.dumps({'scope':'Offline protocol controls only; no worker, API, browser or scientific measurement executed', 'checks':checks,'passed':len(checks)}, indent=2))
