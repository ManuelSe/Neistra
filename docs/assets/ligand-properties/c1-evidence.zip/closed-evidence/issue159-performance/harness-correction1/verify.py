from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import time
from datetime import UTC, datetime
root = Path.cwd()
evidence = root / '.issue-11-evidence/issue159-performance/harness-correction1'
owned = ['tests/support/ligand_property_performance_qualification.py', 'tests/e2e/ligand-properties-performance.spec.ts']
commands = [
    ('ruff-format', ['.venv/bin/ruff', 'format', '--check', owned[0]], root),
    ('ruff', ['.venv/bin/ruff', 'check', owned[0]], root),
    ('mypy', ['.venv/bin/mypy', owned[0], '--follow-imports=silent'], root),
    ('compile', ['.venv/bin/python', '-c', 'from pathlib import Path; p=Path(' + repr(owned[0]) + '); compile(p.read_text(),str(p),"exec"); print("Compile PASS without bytecode")'], root),
    ('cli-help', ['.venv/bin/python', '-m', 'tests.support.ligand_property_performance_qualification', '--help'], root),
    ('worker-help', ['.venv/bin/python', '-m', 'tests.support.ligand_property_performance_qualification', 'worker', '--help'], root),
    ('protocol-controls', ['.venv/bin/python', str(evidence / 'protocol-controls.py')], root),
    ('database-path-controls', ['node', str(evidence / 'database-path-controls.cjs')], root),
    ('native-ts', ['./node_modules/.bin/tsc', '--noEmit', '--target', 'ES2022', '--module', 'ESNext', '--moduleResolution', 'Bundler', '--lib', 'ES2022,DOM,DOM.Iterable', '--typeRoots', 'node_modules/@types', '--types', 'node', '--skipLibCheck', '../../' + owned[1]], root / 'apps/web'),
    ('native-collection', ['corepack', 'pnpm', 'exec', 'playwright', 'test', owned[1], '--list', '--reporter=list'], root),
]
results=[]
for name, args, cwd in commands:
    started=time.monotonic()
    run=subprocess.run(args, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log=evidence / (name + '.log')
    log.write_text(run.stdout)
    results.append({'name':name,'command':args,'cwd':str(cwd),'exit_code':run.returncode,'seconds':time.monotonic()-started,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    print(name, run.returncode, flush=True)
files={}
patches=[]
for name in owned:
    path=root / name
    data=path.read_bytes()
    old=evidence / ('before-' + path.name + '.txt')
    patches += list(difflib.unified_diff(old.read_text().splitlines(keepends=True), data.decode().splitlines(keepends=True), fromfile='before/'+name,tofile='after/'+name))
    assert all(line.rstrip()==line for line in data.decode().splitlines()), 'trailing whitespace'
    files[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
patch=evidence / 'correction.patch'
patch.write_text(''.join(patches))
receipt={'scope':'Scoped static and offline protocol author checks only; no services, scientific workloads, native workflow, benchmark, release gate or performance qualification run','finished_utc':datetime.now(UTC).isoformat(),'files':files,'commands':results,'all_passed':all(r['exit_code']==0 for r in results),'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest()}
(evidence / 'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert receipt['all_passed']
