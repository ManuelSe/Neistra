"""Offline controls using retained actual DTOs/artifact; no API or worker executes."""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import sqlite3
import sys
sys.path.insert(0, str(Path.cwd()))
from tests.support.ligand_property_performance_qualification import coordinate_baseline

root=Path('.issue-11-evidence/issue159-performance')
source=root/'api-probe3-capture'
calls=json.loads((source/'actual-calls.json').read_text())
command=next(row['result'] for row in calls if row['path'].endswith('/selection-transform'))
persisted=calls[-1]['result']
entry=persisted['entries'][0]
with sqlite3.connect('file:'+str((source/'store/molweave.db').resolve())+'?mode=ro',uri=True) as db:
    artifact=db.execute('SELECT relative_path,sha256,size FROM artifacts WHERE id=?',(entry['current_artifact_id'],)).fetchone()
assert artifact is not None
payload=(source/'store'/artifact[0]).read_bytes()
assert len(payload)==artifact[2] and hashlib.sha256(payload).hexdigest()==artifact[1]
canonical={'entry_id':entry['id'],'artifact_id':entry['current_artifact_id'],'structure':json.loads(payload)}
proof=coordinate_baseline(command,persisted,canonical)
assert len(proof['timestamp_suffix_differences'])==2
assert proof['validated_patch']==command['structure_patches'][0]
# Prove validators leave original observations unchanged.
originals=deepcopy((command,persisted,canonical))
coordinate_baseline(command,persisted,canonical)
assert (command,persisted,canonical)==originals
passed=['retained_actual_DTO_pair_with_hash_verified_artifact','validator_does_not_mutate_observations']
def reject(name,mutate):
    a,b,c=deepcopy(originals)
    mutate(a,b,c)
    try: coordinate_baseline(a,b,c)
    except (AssertionError,KeyError): passed.append(name)
    else: raise AssertionError('Incorrectly accepted '+name)
def change_stamp(value):
    return value[:-1]+('7' if value[-1]!='7' else '8')
reject('changed_project_fraction_digits',lambda a,b,c:b.__setitem__('modified_at',change_stamp(b['modified_at'])))
reject('changed_entry_fraction_digits',lambda a,b,c:b['entries'][0].__setitem__('modified_at',change_stamp(b['entries'][0]['modified_at'])))
reject('timezone_offset_substitution',lambda a,b,c:a.__setitem__('modified_at',b['modified_at']+'+00:00'))
reject('arbitrary_timestamp_precision',lambda a,b,c:a.__setitem__('modified_at',b['modified_at'][:-1]+'Z'))
reject('changed_history',lambda a,b,c:b['history'].__setitem__('position',9999))
reject('changed_revision',lambda a,b,c:b.__setitem__('revision',b['revision']+1))
reject('changed_current_artifact',lambda a,b,c:b['entries'][0].__setitem__('current_artifact_id','wrong-artifact'))
reject('changed_original_artifact',lambda a,b,c:b['entries'][0].__setitem__('original_artifact_id','wrong-original'))
reject('additional_field_omission',lambda a,b,c:b.pop('name'))
reject('entry_field_omission',lambda a,b,c:b['entries'][0].pop('viewer_settings'))
reject('unexpected_transport_field',lambda a,b,c:b.__setitem__('unexpected',[]))
reject('persisted_patch_not_empty',lambda a,b,c:b.__setitem__('structure_patches',a['structure_patches']))
reject('missing_command_patch',lambda a,b,c:a.__setitem__('structure_patches',[]))
reject('patch_entry_changed',lambda a,b,c:a['structure_patches'][0].__setitem__('entry_id','wrong-entry'))
reject('patch_artifact_changed',lambda a,b,c:a['structure_patches'][0].__setitem__('artifact_id','wrong-artifact'))
reject('patch_membership_changed',lambda a,b,c:a['structure_patches'][0]['atom_ids'].pop())
reject('patch_coordinates_changed',lambda a,b,c:a['structure_patches'][0]['coordinates'][0].__setitem__(0,1.1))
reject('patch_nonfinite_coordinates',lambda a,b,c:a['structure_patches'][0]['coordinates'][0].__setitem__(0,float('nan')))
reject('patch_boolean_coordinates',lambda a,b,c:a['structure_patches'][0]['coordinates'][0].__setitem__(0,True))
reject('canonical_artifact_changed',lambda a,b,c:c.__setitem__('artifact_id','wrong-artifact'))
reject('canonical_membership_changed',lambda a,b,c:c['structure']['atoms'].pop())
reject('canonical_coordinates_changed',lambda a,b,c:c['structure']['atoms'][0]['coordinates'].__setitem__(0,1.1))
reject('unqualified_other_timestamp_difference',lambda a,b,c:b.__setitem__('created_at',b['created_at']+'Z'))
print(json.dumps({'scope':'Offline comparator acceptance/refusal controls only. Canonical structure is a hash-verified retained actual artifact with explicit identity envelope, not a new HTTP response or performance measurement.','passed':len(passed),'controls':passed,'actual_calls_sha256':hashlib.sha256((source/'actual-calls.json').read_bytes()).hexdigest(),'canonical_artifact_sha256':artifact[1]},indent=2))
