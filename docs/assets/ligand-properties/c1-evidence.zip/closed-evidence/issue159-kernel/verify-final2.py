from pathlib import Path
import ast,datetime,hashlib,json,os,subprocess,sys
root=Path.cwd();out=root/'.issue-11-evidence/issue159-kernel';receipt=out/'final2.json';assert not receipt.exists()
names=['__init__.py','models.py','registry.py','input.py','calculate.py']
owned=[Path('packages/neistra_core/src')/package/'ligand_properties'/name for package in ['neistra_core','molweave_core'] for name in names]+[Path('tests/scientific/test_ligand_properties.py'),Path('tests/unit/test_ligand_properties_kernel.py')]
def hashes():return {str(p):hashlib.sha256((root/p).read_bytes()).hexdigest() for p in owned}
state={'scope':'Actual focused scientific kernel verification only; no release/readiness/oldreader claim','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_before':hashes(),'commands':[],'complete':False}
def save():receipt.write_text(json.dumps(state,indent=2)+'\n')
save()
env={**os.environ,'PYTHONPATH':str(root/'apps/api/src')+':'+str(root/'packages/neistra_core/src')+':'+str(root/'packages/neistra_demo_plugin/src')+':'+str(root),'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
commands=[('source-and-toolchain',[str(root/'.venv/bin/python'),'-c',"import sys,rdkit,neistra_core.ligand_properties; from pathlib import Path; p=Path(neistra_core.ligand_properties.__file__).resolve(); assert p.is_relative_to(Path.cwd()); print(sys.version); print('RDKit',rdkit.__version__); print('Actual kernel',p)"]),('ruff',[str(root/'.venv/bin/ruff'),'check',*[str(p) for p in owned]]),('mypy',[str(root/'.venv/bin/mypy'),*[str(p) for p in owned[:10]]]),('pytest',[str(root/'.venv/bin/pytest'),'-q',*[str(p) for p in owned[10:]]])]
for label,command in commands:
 result=subprocess.run(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=out/(label+'-final2.log');log.write_bytes(result.stdout)
 state['commands'].append({'label':label,'argv':command,'exit_code':result.returncode,'log':str(log.relative_to(root)),'log_sha256':hashlib.sha256(result.stdout).hexdigest(),'log_bytes':len(result.stdout)});save()
 print(label,result.returncode,result.stdout.decode(errors='replace').strip(),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
for p in owned:ast.parse((root/p).read_text(),filename=str(p))
state['syntax_files']=len(owned);state['source_after']=hashes();state['source_unchanged']=state['source_before']==state['source_after'];assert state['source_unchanged'];state['complete']=True;state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('COMPLETE',receipt,flush=True)
