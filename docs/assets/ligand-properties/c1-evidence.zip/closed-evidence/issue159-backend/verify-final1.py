import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
root=Path.cwd(); out=root/'.issue-11-evidence/issue159-backend'; receipt=out/'verification-final1.json'; assert not receipt.exists()
existing=['apps/api/src/neistra_api/'+n+'.py' for n in ('models','job_service','job_worker','archive_service','main','settings','import_export')]+['packages/neistra_core/src/neistra_core/artifacts.py','apps/api/migrations/versions/0017_ligand_properties.py']
new=[str(p) for folder,pattern in [('apps/api/src/neistra_api','ligand_property_*.py'),('apps/api/src/molweave_api','ligand_property_*.py'),('tests/integration','test_ligand_property*.py'),('tests/unit','test_ligand_property*.py')] for p in Path(folder).glob(pattern)]
paths=sorted(set(existing+new)); before={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
historical=sorted(str(p) for p in Path('apps/api/migrations/versions').glob('*.py') if p.name[:4].isdigit() and int(p.name[:4])<17)
for p in historical:
 assert Path(p).read_bytes()==subprocess.check_output(['git','show','HEAD:'+p]),p
state={'scope':'Author backend implementation verification; not final application or push approval','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'uncommitted_owned_sources':before,'historical_migrations_unchanged':historical,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'complete':False}
env={k:v for k,v in os.environ.items() if k not in {'NEISTRA_DATA_DIR','NEISTRA_DATABASE_URL','MOLWEAVE_DATA_DIR','MOLWEAVE_DATABASE_URL','DATABASE_URL'}}
env.update(NEISTRA_PERFORMANCE='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
commands=[('ruff',[str(root/'.venv/bin/ruff'),'check',*paths]),('mypy',[str(root/'.venv/bin/uv'),'run','mypy','apps/api','packages/neistra_core','packages/neistra_demo_plugin']),('focused',[str(root/'.venv/bin/uv'),'run','pytest','-q',*sorted(p for p in paths if p.startswith('tests/')), 'tests/integration/test_job_lifecycle.py','tests/unit/jobs/test_spawn_bootstrap.py','tests/unit/jobs/test_registry.py','tests/integration/test_archive_roundtrip.py']),('diff',['git','diff','--check'])]
def save(): receipt.write_text(json.dumps(state,indent=2)+'\n')
save()
for phase,command in commands:
 print('START',phase,flush=True); log=out/f'final1-{phase}.log'; result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,check=False);log.write_bytes(result.stdout);state['steps'].append({'phase':phase,'command':command,'actual_child_exit':result.returncode,'log':str(log.relative_to(root)),'log_sha256':hashlib.sha256(result.stdout).hexdigest()});save();print('EXIT',phase,result.returncode,flush=True);print(result.stdout.decode(errors='replace')[-1400:],flush=True)
 if result.returncode: sys.exit(result.returncode)
after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths};state['owned_source_after']=after;state['owned_sources_unchanged']=after==before;assert after==before
state.update(complete=True,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print('ENCLOSING COMPLETE',receipt,flush=True)
