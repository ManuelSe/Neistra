"""Package the local descriptor vertical checkpoint without release-readiness claims."""
from pathlib import Path
import base64
import datetime
import json
import os
import runpy
import subprocess

root=Path.cwd();private=root/'.issue-11-evidence';out=private/'issue159-c1-packet'
assert not out.exists();out.mkdir()
a=root/'docs/assets/ligand-properties'
h=runpy.run_path(str(a/'release-evidence.py.txt'));q=runpy.run_path(str(a/'qualification.py.txt'))
sha=h['sha'];digest=lambda value:sha(json.dumps(value,sort_keys=True).encode())
before=q['current_identities'](root);assert len(before)==1062
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
baseline=q['tagged_identities']('HEAD')
changed=sorted(n for n,v in before.items() if baseline.get(n)!=v)
deleted=sorted(n for n in baseline if n not in before)
assert len(changed)==73 and not deleted
def read(name):return json.loads((private/name).read_text())
def hashes(mapping):return {n:v['sha256'] if isinstance(v,dict) else v for n,v in mapping.items()}
def changes(mapping):return sorted(n for n,v in hashes(mapping).items() if before.get(n)!=v)
def log_checks(receipt,field,default_directory=None):
    for row in receipt[field]:
        code=row.get('exit_code',row.get('actual_child_exit'))
        assert code==0,row
        log=row.get('log')
        if log:
            path=Path(log);path=path if path.is_absolute() else root/path
        else:
            assert default_directory is not None
            path=default_directory/(row['label']+'.log')
        assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(private)
        assert h['fingerprint'](path)['sha256']==row['log_sha256']
kernel=read('issue159-kernel/final2.json');assert kernel['complete'] and kernel['source_before']==kernel['source_after'] and kernel['source_unchanged']
assert len(kernel['source_after'])==12 and not changes(kernel['source_after']);log_checks(kernel,'commands')
backend=read('issue159-backend/verification-retirement-correction3-final.json')
backend_handoff=read('issue159-backend/handoff-retirement-correction3.json')
assert h['fingerprint'](private/'issue159-backend/verification-retirement-correction3-final.json')['sha256']==backend_handoff['verification_receipt_sha256']
assert backend['complete'] and backend['owned_sources_unchanged'] and len(backend['owned_source_after'])==29
backend_superseded=changes(backend['owned_source_after'])
assert backend_superseded==['apps/api/src/neistra_api/job_worker.py','tests/integration/test_ligand_property_lifecycle.py']
log_checks(backend,'steps')
fairness=read('issue159-fairness-after1/receipt.json');assert fairness['complete'] and fairness['source_before']==fairness['source_after'] and not changes(fairness['source_after']);log_checks(fairness,'steps',private/'issue159-fairness-after1')
python_full=read('issue159-c1-python1/receipt.json');assert python_full['complete'] and python_full['source_unchanged'] and python_full['source_before']==python_full['source_after'];log_checks(python_full,'steps',private/'issue159-c1-python1')
python_superseded=changes(python_full['source_after'])
frontend=read('issue159-frontend/inspector-layout-handoff.json')
assert len(frontend['owned_sources_after16'])==16 and not changes(frontend['owned_sources_after16'])
frontend_full_path=private/'issue159-frontend'/frontend['verification']['full_frontend']['receipt']
assert h['fingerprint'](frontend_full_path)==frontend['verification']['full_frontend']['receipt_identity']
frontend_full=json.loads(frontend_full_path.read_text());log_checks(frontend_full,'steps')
reader=read('issue159-reader-tooling/correction2/handoff-final2.json');assert reader['source_count']==9
reader_current_delta=changes(reader['source_files'])
reader_verification=read('issue159-reader-tooling/correction2/verification-final2.json')
assert reader_verification['complete'] and reader_verification['owned_source_unchanged'];log_checks(reader_verification,'checks')
performance=read('issue159-performance/harness-correction2/author-handoff.json')
assert not changes(performance['files'])
assert performance['files']['tests/support/ligand_property_performance_qualification.py']['sha256']=='35d7f5382a8ef335879c5ba64f8ecd5757bff2234993506ae93b717411ac7fa4'
assert performance['files']['tests/e2e/ligand-properties-performance.spec.ts']['sha256']=='5951f294bb4c88a02ce016696da21dc9804e24dbc487c2a1f02c6f3bcefff79e'
native=read('issue159-integration-root/native8/receipt.json')
excluded=['tests/e2e/ligand-properties-performance.spec.ts','tests/support/ligand_property_performance_qualification.py']
assert native['exit_code']==0 and native['source_unchanged'] and native['source_before']==native['source_after']
assert len(native['source_before'])==1060 and sorted(native['source_paths_excluded'])==excluded
assert h['fingerprint'](private/'issue159-integration-root/native8/raw.log')['sha256']==native['log_sha256']
native_delta=changes(native['source_after'])
assert native_delta==['docs/assets/ligand-properties/release-recipe.py.txt','playwright.config.ts','tests/unit/test_ligand_properties_release_recipe.py']
native_actual=read('issue159-integration-root/native8/actual-enclosing.json')
assert native_actual['actual_session']==71526 and native_actual['actual_exit']==0
assert native_actual['receipt_sha256']==h['fingerprint'](private/'issue159-integration-root/native8/receipt.json')['sha256']
browser=read('issue159-integration-root/native8/browser.json');stats=browser['stats']
assert (stats['expected'],stats['skipped'],stats['unexpected'],stats['flaky'])==(26,0,0,0) and not browser['errors']
assert native_actual['browser_sha256']==h['fingerprint'](private/'issue159-integration-root/native8/browser.json')['sha256']
api_dir=private/'issue159-performance/api-probe5';api=read('issue159-performance/api-probe5/actual-receipt.json')
assert api['exit_code']==0 and h['fingerprint'](api_dir/'raw.log')['sha256']==api['log_sha256']
qualification=json.loads((api_dir/'run/qualification.json').read_text())
assert qualification['complete'] and qualification['sources_before']==qualification['sources_after'] and len(qualification['sources_before'])==729
assert qualification['timing_enforced'] is False
processes=qualification['cold_process_starts'];assert len(processes)==5
pids=[row['coordinator_process_pid'] for row in processes];assert len(set(pids))==5
coordinate=[]
for number in range(5):
    directory=api_dir/'run'/('cold-'+str(number));result=json.loads((directory/'result.json').read_text())
    before_rows=json.loads((directory/'coordinate-persisted-before.json').read_text());after_rows=json.loads((directory/'coordinate-persisted-after.json').read_text())
    assert before_rows==after_rows and result['coordinate_reuse']['new_jobs']==0 and result['coordinate_reuse']['persisted_baseline_exactly_preserved']
    coordinate.append(dict(index=number,pid=result['coordinator_process_pid'],demand_to_current_ms=result['demand_to_current_ms'],coordinate_new_jobs=0,persisted_row_values_exactly_preserved=True,before=h['fingerprint'](directory/'coordinate-persisted-before.json'),after=h['fingerprint'](directory/'coordinate-persisted-after.json')))
complex_result=qualification['observed_complex'];assert complex_result['full_source_atoms']==1001 and complex_result['scientific_model_qualified'] is False and complex_result['report']['model_status']=='unavailable'
roots=['issue159-kernel','issue159-backend','issue159-frontend','issue159-reader-tooling','issue159-c1-python1','issue159-fairness-before1','issue159-fairness-after1','issue159-integration-root','issue159-animation-oracle','issue159-layout-oracle4','issue159-layout-oracle5','issue159-layout-oracle6','issue159-panel-oracle7','issue159-panel-oracle8','issue159-performance']
items={};link_rows=[];retained={};excluded_caches={}
def collect(directory,prefix):
    assert directory.is_dir() and not directory.is_symlink()
    count=0;omitted=[]
    # Closed failed runs and intentional corruption fixtures are retained as raw
    # regular files. Links are encoded, never followed or installed as ZIP links.
    for path in sorted(directory.rglob('*')):
        name=prefix+'/'+path.relative_to(directory).as_posix()
        if path.is_symlink():
            target=path.resolve();assert target.is_relative_to(directory.resolve()) and target.exists(),path
            target_member=prefix+'/'+target.relative_to(directory.resolve()).as_posix()
            raw=os.fsencode(os.readlink(path))
            link_rows.append(dict(path=name,target_text=os.readlink(path),target_bytes_base64=base64.b64encode(raw).decode(),lstat_mode=path.lstat().st_mode,resolved_member=target_member,target_is_directory=target.is_dir(),target_within_owned_snapshot=True,classification='pytest convenience link' if path.name.endswith('current') else 'intentional synthetic corruption/security fixture',followed=False))
            continue
        if not path.is_file():continue
        if h['CACHE_PARTS'].intersection(path.parts) or path.suffix in {'.pyc','.pyo'}:
            omitted.append(path.relative_to(directory).as_posix());continue
        h['add'](items,name,path,reader_workspace=True);count+=1
    return count,omitted
for name in roots:
    retained[name],excluded_caches[name]=collect(private/name,'closed-evidence/'+name)
for number in range(1,9):
    name='neistra159-integrated-native'+str(number);retained[name],excluded_caches[name]=collect(Path('/tmp')/name,'owned-native-stores/'+name)
for path in sorted(private.glob('issue159-*.py')):h['add'](items,'operations/'+path.name,path)
for name in ['issue159-integration-158-oracles.json','issue159-profile-integration-review-notes.json']:
    h['add'](items,'operations/'+name,private/name)
for name in changed:h['add'](items,'changed-source/'+name,root/name)
h['add'](items,'operations/packager.py',Path(__file__))
assert len(link_rows)==146
h['add'](items,'owned-link-provenance.json',h['encoded'](dict(scope='Exact link metadata, not active archive symlinks; all resolved target bytes are separately retained regular files in the same owned snapshots',links=link_rows,convenience_links=sum(row['classification']=='pytest convenience link' for row in link_rows),synthetic_security_fixture_links=sum(row['classification']!='pytest convenience link' for row in link_rows))))
evidence_identities={name:h['fingerprint'](member) for name,member in sorted(items.items())}
raw=sum(row['bytes'] for row in evidence_identities.values());estimate=sum(h['compressed_size'](member) for member in items.values())
assert estimate<76*1024*1024,('Report before exceeding single-packet strategy',estimate)
source_proof=dict(scope='Current local C1 identity only; neither predecessor release integration nor complete qualification',head=head,head_source_count=len(baseline),head_source_identities=baseline,current_source_count=1062,current_source_digest=digest(before),current_before=before,current_after=q['current_identities'](root),changed_or_new_source_count=73,changed_or_new_source_identities={n:before[n] for n in changed},deleted_sources=deleted,current_unchanged=True,
    current_native8_relation=dict(scoped_run_source_count=1060,explicit_unexecuted_performance_source_exclusions=excluded,subsequent_optional_trace_config_tool_unit_changes=native_delta,actual26_case_run_runtime_scientific_ui_sources_still_current=True),
    python3234_subsequent_source_changes=python_superseded,backend158_subsequent_fairness_sources=backend_superseded,reader77_subsequent_trace_sources=reader_current_delta)
assert source_proof['current_after']==before
h['add'](items,'source-proof.json',h['encoded'](source_proof))
root_facts=dict(scope='Explicit root-observed tool facts without persisted raw receipt/log files; not fabricated machine evidence',reader_recipe_units=dict(actual_session=62263,actual_exit=0,passed=78,scope='Combined offline reader/recipe units after optional worker trace-path addition'),recipe_units=dict(actual_session=90271,actual_exit=0,passed=11),current_scope_source_identities={name:before[name] for name in ['playwright.config.ts','docs/assets/ligand-properties/release-recipe.py.txt','tests/unit/test_ligand_properties_release_recipe.py']},limitation='No persisted raw logs/receipts were found for these two root executions. Prior77offline controls retain their own raw proof and differ from these reported observations.')
h['add'](items,'root-reported-current-trace-units.json',h['encoded'](root_facts))
scope=dict(scope='Coherent local C1 descriptor vertical checkpoint; implementation and focused proof only, NOT final all-seven readiness, complete capacity qualification, merge or release',repository='ManuelSe/Neistra',issue=159,parent=11,head_plus_working_changes=head,
    implemented='Fourteen strict versioned descriptors; private bounded execution/cache/source proofs/consumer lifecycle; App-owned current-input values and compact installation options; actual focused desktop/mobile/native workflows.',
    current_source_count=1062,current_source_digest=digest(before),changed_or_new_source_count=73,head_baseline_fully_hashed=True,current_changed_source_code_tests_helpers_and_config_copied=True,
    checks=dict(kernel=dict(python=83,owned_sources=12,current=True,actual_enclosing='closed-evidence/issue159-kernel/final2-enclosing.json'),backend=dict(focused=158,owned_sources=29,scope='Historical author correction; two later scheduler/lifecycle paths have dedicated29case proof',source_delta=backend_superseded,handoff='closed-evidence/issue159-backend/handoff-retirement-correction3.json'),full_python_static=dict(root_observed_session=96589,root_observed_exit=0,python_passed=3234,ruff='PASS',mypy_files=274,scope='Actual earlier complete Python/static checkpoint, before three fairness cases and later trace-control unit; not an invented sum for current sources',subsequent_source_delta=python_superseded),fairness=dict(negative_root_observed_session=55627,negative_exit=1,real_aliases=41,positive_root_observed_session=31942,positive_exit=0,lifecycle_cases=29,ruff='PASS',mypy_files=274,scope='Productive warm/cold/mixed/cache-failure turns; distinct from prior3234full suite'),frontend=dict(focused=133,full_passed=1387,full_suites=126,lint='PASS',types='PASS',build='PASS',owned_sources=16,current=True,handoff='closed-evidence/issue159-frontend/inspector-layout-handoff.json'),reader_tools=dict(scoped_sources=9,offline_cases=77,actual_old036_actors_executed=False,current_trace_reported_units=root_facts),native=dict(actual_enclosing=native_actual,passed=26,failed=0,skipped=0,flaky=0,retries=0,source_count=1060,explicit_unexecuted_performance_source_exclusions=excluded,subsequent_default_preserving_trace_config_changes=native_delta,all_eight_runs_and_owned_stores_retained=True,actual_cdp_zoom_captures_retained=True)),
    source_authority='Final scientific kernel, frontend and backend author maps/logs are retained. Later two-file fairness and optional trace changes are explicitly separate proof scopes. No earlier candidate approval or count is silently carried to the entire current tree.',
    performance=dict(harness_source_files=performance['files'],offline_controls=35,native_cases_collected=8,native_performance_cases_executed=0,code_review_scope='Author static/offline controls plus root-reported nonauthor scoped CODE assessment; no final timing or thousand-entry native capacity approval',api5=dict(root_observed_session=32820,root_observed_exit=0,actual_processes=5,unique_coordinator_pids=pids,source_scope_count=729,source_scope_before_after_equal=True,cold_ms=qualification['cold_result_ms'],coordinate_reuse=coordinate,observed_complex=dict(source_atoms=1001,scientific_model_qualified=False,model_status=complex_result['report']['model_status'],model_reason=complex_result['report']['model_reason'],scope='Truthful partial independent counts; no extra charge or bond assignment')),host_context='Portable0 with concurrent158C9native workload. These exploratory ASGI/real-child correctness/resource observations are not reference-host timing approval, actual browser capacity qualification, GPU or physical-device claims.',earlier_probes='APIprobe1 fails before measurement because import path is unavailable; probe2 fails a POST/GET transport oracle, captureprobe3 preserves exact timestamp-suffix/coordinate-patch evidence; smoke4 is one real cold plus coordinate reuse pass, not five-process qualification. All raw outputs and stores remain included.'),
    retained=retained,raw_regular_payload_bytes_before_metadata=raw,estimated_deflate_bytes_before_metadata=estimate,encoded_links=146,omitted_named_cache_files=excluded_caches,
    prior_failures_and_limits='All seven earlier failed native runs, exact before/after animation/layout/panel oracle sources, retained backend/frontend/kernel corrective proofs and source archives remain distinct. Ad hoc E2E TypeScript attempts encountered pre-existing mixed upload typing and Vite path/global setup issues; no whole legacy E2E TypeScript pass is claimed. Root trace-unit tool facts have an explicit missing-raw-receipt limitation.',
    prerequisite='Actual verified158deliverymaster and immutable0.36tag are still required before final159integration/qualification. This local plan-base checkpoint does not establish that prerequisite or actual older-reader compatibility.',
    specialist_scope='Retained handoffs and review/diagnosis/control files identify their actual authors, scopes and hashes. No missing specialist execution or all-seven final verdict is inferred. All-seven same-final-candidate review remains required.',
    required_remaining=['Integrate actual released158master/tag0.36 and reconcile all inherited source/runtime contracts','Finish actual native performance/capacity/resource measurements, including both1000entry workloads, under accepted qualification policy','Prepare versions and execute complete fresh43candidate and exact merged-master gates, actual old/current actors and source-bound packaging','Obtain all-seven final same-candidate specialist assessments and normal protected PR/merge','Verify immutable tag/release/public assets, child closeout/owned cleanup and complete parent program'])
h['add'](items,'checkpoint-context.json',h['encoded'](scope))
packet=h['archive'](items,a/'c1-evidence.zip');assert packet['bytes']<80*1024*1024
assert q['current_identities'](root)==before
assert all(h['fingerprint'](member)==evidence_identities[name] for name,member in items.items() if name in evidence_identities)
assert q['tagged_identities']('HEAD')==baseline
record=dict(**scope,archive=packet['file'],archive_bytes=packet['bytes'],archive_sha256=packet['sha256'],outer_manifest_entries=packet['outer_manifest_entries'],recursive_verification=packet['verification_counts'],all_payload_hashes_and_recursive_crcs_verified=True,all_current_sources_and_snapshotted_payloads_unchanged=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
target=a/'c1-checkpoint.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
(out/'packager-result.json').write_text(json.dumps(dict(archive=packet,checkpoint=h['fingerprint'](target),current1062_unchanged=True,changed73_copied=True),indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
