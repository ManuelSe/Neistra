import os,json,runpy,subprocess,hashlib,datetime
from pathlib import Path
root=Path.cwd();out=root/".issue-11-evidence/issue159-c1-python1";assert not out.exists();out.mkdir();helper=runpy.run_path(str(root/"docs/assets/ligand-properties/qualification.py.txt"))
def identities():
 names=subprocess.check_output(["git","ls-files","--cached","--others","--exclude-standard"],text=True).splitlines();return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(set(names)) if helper["selected"](n) and (root/n).is_file()}
before=identities();env={k:v for k,v in os.environ.items() if k not in {"NEISTRA_DATA_DIR","NEISTRA_DATABASE_URL","MOLWEAVE_DATA_DIR","MOLWEAVE_DATABASE_URL","DATABASE_URL"}};env.update(OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1",NEISTRA_PERFORMANCE="0",NEISTRA_AMBERTOOLS_PREFIX="/datadisk/dev/.neistra-tools/ambertools-24.8")
d={"scope":"FullPython/static integration checkpoint only; not release gate, benchmark or prerequisite delivery","source_before":before,"steps":[],"complete":False};receipt=out/"receipt.json"
for label,cmd in [("ruff",[".venv/bin/uv","run","ruff","check","."]),("mypy",[".venv/bin/uv","run","mypy","apps/api","packages/neistra_core","packages/neistra_demo_plugin"]),("python",[".venv/bin/uv","run","pytest"])]:
 log=out/(label+".log");print("START",label,flush=True)
 with log.open("wb") as stream:p=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
 d["steps"].append({"label":label,"command":cmd,"actual_child_pid":p.pid if hasattr(p,"pid") else None,"exit_code":p.returncode,"log_sha256":hashlib.sha256(log.read_bytes()).hexdigest()});receipt.write_text(json.dumps(d,indent=2)+"\n");print(log.read_text()[-2000:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
after=identities();d.update(source_after=after,source_unchanged=before==after,complete=before==after,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());receipt.write_text(json.dumps(d,indent=2)+"\n");assert before==after;print("COMPLETE checkpointPython/static",flush=True)
