import subprocess,json,runpy,datetime,hashlib,sys
from pathlib import Path
root=Path.cwd();out=root/'.issue-11-evidence/issue159-integration-root/web1';assert not out.exists();out.mkdir(parents=True);helpers=runpy.run_path(str(root/'docs/assets/ligand-designation/qualification.py.txt'));excluded={'tests/support/ligand_property_performance_qualification.py','tests/e2e/ligand-properties-performance.spec.ts'}
def identities():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],text=True).splitlines();return{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(names)) if helpers['selected'](p) and p not in excluded and (root/p).is_file()}
before=identities();state={'scope':'Actualcompletefrontend lint/type/test/build integration; unrelatedtwoqualificationharnessfiles separatelyownedandin-development','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_before':before,'excluded_unexecuted_harness_paths':sorted(excluded),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'complete':False}
def save():(out/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for label,task in [('lint','lint'),('types','typecheck'),('web','test'),('build','build')]:
 cmd=['corepack','pnpm','--dir','apps/web',task];print('START',label,flush=True);p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);data=p.communicate()[0];code=p.returncode;log=out/(label+'.log');log.write_bytes(data);state['steps'].append({'label':label,'command':cmd,'actual_child_pid':p.pid,'exit_code':code,'log':str(log),'log_sha256':hashlib.sha256(data).hexdigest()});after=identities();state.update(source_after=after,source_unchanged=before==after);save();print('PASS' if code==0 else 'FAIL',label,flush=True);print(data.decode(errors='replace')[-1000:],flush=True);assert before==after,'Relevantfrozenintegration source changed';
 if code:raise SystemExit(code)
state.update(complete=True,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print('INTEGRATED WEB COMPLETE',flush=True)
