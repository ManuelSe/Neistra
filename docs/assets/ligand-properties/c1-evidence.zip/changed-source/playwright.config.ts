import { defineConfig, devices } from "@playwright/test";
import { resolve } from "node:path";
import { environmentValue } from "./scripts/configuration.mjs";
import { performanceEnabled } from "./scripts/performance-policy.mjs";

// Reject invalid profiles before starting any services.
performanceEnabled();

function e2ePort(name: string, fallback: string): string {
  const raw = environmentValue(name, fallback);
  const port = Number(raw);
  if (!/^\d+$/.test(raw) || !Number.isInteger(port) || port < 1 || port > 65_535) {
    throw new Error(`${name} must be an integer port between 1 and 65535`);
  }
  return String(port);
}

function e2eDataDir(): string {
  const raw = environmentValue("E2E_DATA_DIR", ".neistra-e2e");
  if (
    !/^[A-Za-z0-9._/-]+$/.test(raw) ||
    raw === "/" ||
    raw.split("/").includes("..")
  ) {
    throw new Error(
      "NEISTRA_E2E_DATA_DIR must be a dedicated path without spaces, shell metacharacters, or parent traversal",
    );
  }
  return raw;
}

const apiPort = e2ePort("E2E_API_PORT", "8010");
const workerPort = e2ePort("E2E_WORKER_PORT", "8011");
const webPort = e2ePort("E2E_WEB_PORT", "5173");
const dataDir = e2eDataDir();
const workerTrace = process.env.NEISTRA_PROPERTY_WORKER_TRACE;
if (workerTrace !== undefined && (
  !/^[A-Za-z0-9._/-]+$/.test(workerTrace) ||
  workerTrace !== resolve(dataDir, "qualification", "worker-turns.jsonl")
)) {
  throw new Error("NEISTRA_PROPERTY_WORKER_TRACE must be the dedicated qualification path under E2E_DATA_DIR");
}
const workerModule = workerTrace === undefined ? "neistra_api.worker"
  : `tests.support.ligand_property_performance_qualification worker --trace ${workerTrace}`;
// A legacy explicit fixture override exercises the full old configuration path.
const configPrefix = process.env.NEISTRA_E2E_DATA_DIR === undefined &&
  process.env.MOLWEAVE_E2E_DATA_DIR !== undefined ? "MOLWEAVE" : "NEISTRA";
const apiUrl = `http://127.0.0.1:${apiPort}`;
const workerUrl = `http://127.0.0.1:${workerPort}`;
const webUrl = `http://127.0.0.1:${webPort}`;

export default defineConfig({
  testDir: "./tests/e2e",
  fullyParallel: false,
  workers: 1,
  timeout: 60_000,
  expect: {
    timeout: 15_000,
  },
  use: {
    baseURL: webUrl,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    launchOptions: {
      args: [
        "--enable-webgl",
        "--ignore-gpu-blocklist",
        "--use-angle=swiftshader",
        "--enable-unsafe-swiftshader",
      ],
    },
  },
  webServer: [
    {
      command: `PYTHONPATH=apps/api/src:packages/neistra_core/src:packages/neistra_demo_plugin/src ${configPrefix}_DATA_DIR=${dataDir} .venv/bin/alembic upgrade head && PYTHONPATH=apps/api/src:packages/neistra_core/src:packages/neistra_demo_plugin/src ${configPrefix}_DATA_DIR=${dataDir} ${configPrefix}_ENABLE_TEST_ROUTES=1 .venv/bin/uvicorn neistra_api.main:app --host 127.0.0.1 --port ${apiPort}`,
      url: `${apiUrl}/api/v1/health`,
      reuseExistingServer: true,
      timeout: 30_000,
    },
    {
      command: `while ! curl -sf ${apiUrl}/api/v1/health >/dev/null; do sleep 0.1; done; PYTHONPATH=apps/api/src:packages/neistra_core/src:packages/neistra_demo_plugin/src ${configPrefix}_DATA_DIR=${dataDir} ${configPrefix}_JOB_WORKER_HEALTH_PORT=${workerPort} .venv/bin/python -m ${workerModule}`,
      url: `${workerUrl}/health`,
      reuseExistingServer: true,
      timeout: 30_000,
    },
    {
      command: `VITE_API_TARGET=${apiUrl} corepack pnpm --dir apps/web dev --host 127.0.0.1 --port ${webPort} --strictPort`,
      url: webUrl,
      reuseExistingServer: true,
      timeout: 30_000,
    },
  ],
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
    {
      name: "mobile-chromium",
      use: { ...devices["Pixel 7"] },
    },
  ],
});
