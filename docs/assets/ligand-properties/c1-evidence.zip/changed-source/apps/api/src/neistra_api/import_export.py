from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import quote

from neistra_core.adapters import ImportOptions
from neistra_core.adapters.defaults import create_default_registry
from neistra_core.adapters.registry import AdapterRegistry
from neistra_core.artifacts import LocalArtifactStore
from neistra_core.components import derive_component_hierarchy
from neistra_core.export_policy import (
    ExportInput,
    ExportPolicyError,
    PreparedExport,
)
from neistra_core.molecular import MolecularWarning, NormalizedStructureV1
from sqlalchemy import select
from sqlalchemy.orm import Session
from uuid6 import uuid7

from neistra_api.artifact_errors import ArtifactIntegrityError as ArtifactIntegrityError
from neistra_api.artifact_errors import ArtifactNotFoundError as ArtifactNotFoundError
from neistra_api.models import Artifact, Project, StructureEntry
from neistra_api.project_service import (
    EntryNotFoundError,
    ProjectNotFoundError,
    ProjectService,
    RevisionConflictError,
)
from neistra_api.schemas import (
    ArtifactRead,
    BatchExportRead,
    ExportEntryReportRead,
    ExportRead,
    FormatRead,
    ImportRead,
    StructureRead,
    ViewerProjection,
)
from neistra_api.settings import Settings
from neistra_api.viewer_state import default_viewer_settings

NORMALIZED_MEDIA_TYPE = "application/vnd.molweave.normalized-structure+json"


class ImportLimitError(ValueError):
    def __init__(self, code: str, message: str, *, filename: str | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.filename = filename


class StructureUnavailableError(LookupError):
    pass


class StructureArtifactConflictError(RuntimeError):
    pass


class LossAcknowledgementRequiredError(RuntimeError):
    def __init__(
        self,
        warnings: list[MolecularWarning],
        *,
        reports: list[ExportEntryReportRead] | None = None,
    ) -> None:
        super().__init__("Export would lose molecular information")
        self.warnings = warnings
        self.reports = reports or []


@dataclass(frozen=True, slots=True)
class UploadPayload:
    filename: str
    data: bytes
    media_type: str | None = None


@dataclass(frozen=True, slots=True)
class PreparedFile:
    filename: str
    data: bytes
    media_type: str
    source_format: str
    structures: tuple[NormalizedStructureV1, ...]


@dataclass(frozen=True, slots=True)
class ExportSourceSet:
    project_name: str
    source_revision: int
    inputs: tuple[ExportInput, ...]


def safe_display_filename(filename: str) -> str:
    normalized = filename.replace("\\", "/").replace("\x00", "")
    basename = PurePosixPath(normalized).name.strip()
    cleaned = "".join(
        character if character.isprintable() and character not in {"/", "\\"} else "_"
        for character in basename
    )
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" .")
    return (cleaned or "structure")[:255]


def safe_filename_stem(name: str) -> str:
    sanitized = safe_display_filename(name)
    stem = Path(sanitized).stem
    portable = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._")
    return (portable or "structure")[:120]


def prepare_uploads(
    settings: Settings,
    uploads: list[UploadPayload],
    *,
    generate_3d: bool = True,
    infer_bonds: bool = True,
    registry: AdapterRegistry | None = None,
) -> list[PreparedFile]:
    if not uploads:
        raise ImportLimitError("empty_import", "Select at least one structure file.")
    aggregate_size = sum(len(upload.data) for upload in uploads)
    if aggregate_size > settings.max_upload_request_bytes:
        raise ImportLimitError(
            "aggregate_upload_too_large",
            (
                f"Upload is {aggregate_size} bytes; the request limit is "
                f"{settings.max_upload_request_bytes} bytes."
            ),
        )
    prepared: list[PreparedFile] = []
    adapter_registry = registry or create_default_registry()
    options = ImportOptions(generate_3d=generate_3d, infer_bonds=infer_bonds)
    for upload in uploads:
        filename = safe_display_filename(upload.filename)
        if len(upload.data) > settings.max_structure_file_bytes:
            raise ImportLimitError(
                "structure_file_too_large",
                (
                    f"{filename} is {len(upload.data)} bytes; the per-file limit is "
                    f"{settings.max_structure_file_bytes} bytes."
                ),
                filename=filename,
            )
        adapter = adapter_registry.for_filename(filename)
        parsed = adapter.parse(upload.data, filename, options)
        structures: list[NormalizedStructureV1] = []
        for structure in parsed.structures:
            atom_count = len(structure.atoms)
            if atom_count > settings.atom_hard_limit:
                raise ImportLimitError(
                    "atom_hard_limit_exceeded",
                    (
                        f"{filename} record {structure.source.record_index + 1} has "
                        f"{atom_count} atoms; the hard limit is {settings.atom_hard_limit}."
                    ),
                    filename=filename,
                )
            if atom_count > settings.atom_warning_limit:
                warning = MolecularWarning(
                    code="atom_warning_limit_exceeded",
                    message=(
                        f"This structure has {atom_count} atoms; interactive "
                        "rendering may be slower."
                    ),
                    operation="import",
                    field="atoms",
                )
                structure = structure.model_copy(
                    update={"warnings": [*structure.warnings, warning]}
                )
            structures.append(structure)
        media_type = (
            upload.media_type
            if upload.media_type and upload.media_type != "application/octet-stream"
            else adapter.capabilities.media_types[0]
        )
        prepared.append(
            PreparedFile(
                filename=filename,
                data=upload.data,
                media_type=media_type,
                source_format=adapter.capabilities.format,
                structures=tuple(structures),
            )
        )
    return prepared


class ArtifactService:
    def __init__(self, session: Session, store: LocalArtifactStore) -> None:
        self.session = session
        self.store = store

    def publish(self, data: bytes, filename: str, media_type: str) -> Artifact:
        stored = self.store.put_bytes(data)
        artifact = self.session.scalar(select(Artifact).where(Artifact.sha256 == stored.sha256))
        if artifact is not None:
            return artifact
        artifact = Artifact(
            id=str(uuid7()),
            sha256=stored.sha256,
            size=stored.size,
            media_type=media_type,
            filename=safe_display_filename(filename),
            relative_path=stored.relative_path,
        )
        self.session.add(artifact)
        self.session.flush()
        return artifact

    def get(self, artifact_id: str) -> Artifact:
        artifact = self.session.get(Artifact, artifact_id)
        if artifact is None:
            raise ArtifactNotFoundError(artifact_id)
        return artifact

    def read(self, artifact_id: str) -> tuple[Artifact, bytes]:
        artifact = self.get(artifact_id)
        return artifact, self.store.read_bytes(artifact.relative_path)

    def read_verified_bytes(self, artifact_id: str) -> bytes:
        artifact = self.get(artifact_id)
        try:
            payload = self.store.read_bytes(artifact.relative_path)
        except OSError as error:
            raise ArtifactIntegrityError(
                "The stored artifact is unavailable or unreadable"
            ) from error
        if len(payload) != artifact.size or hashlib.sha256(payload).hexdigest() != artifact.sha256:
            raise ArtifactIntegrityError("The stored artifact failed its integrity check")
        return payload

    def read_bounded_verified_bytes(self, artifact_id: str, max_bytes: int) -> bytes:
        """Verify immutable content while bounding the actual read, including file growth."""
        if type(max_bytes) is not int or max_bytes < 1:
            raise ValueError("A positive artifact byte limit is required")
        artifact = self.get(artifact_id)
        if not 0 <= artifact.size <= max_bytes:
            raise ArtifactIntegrityError("The artifact exceeds the supported input byte budget")
        try:
            payload = self.store.read_bytes_bounded(artifact.relative_path, max_bytes)
        except (OSError, ValueError) as error:
            raise ArtifactIntegrityError(
                "The bounded artifact is unavailable or oversized"
            ) from error
        if len(payload) != artifact.size or hashlib.sha256(payload).hexdigest() != artifact.sha256:
            raise ArtifactIntegrityError("The stored artifact failed its bounded integrity check")
        return payload

    def load_normalized(self, artifact_id: str) -> NormalizedStructureV1:
        artifact = self.get(artifact_id)
        if artifact.media_type != NORMALIZED_MEDIA_TYPE:
            raise StructureArtifactConflictError(
                "This artifact is not a canonical molecular source"
            )
        try:
            return NormalizedStructureV1.from_bytes(self.read_verified_bytes(artifact_id))
        except ValueError as error:
            raise ArtifactIntegrityError("The canonical molecular source is invalid") from error

    @staticmethod
    def response(artifact: Artifact, *, filename: str | None = None) -> ArtifactRead:
        download_filename = safe_display_filename(filename or artifact.filename)
        return ArtifactRead(
            id=artifact.id,
            filename=download_filename,
            media_type=artifact.media_type,
            sha256=artifact.sha256,
            size=artifact.size,
            download_url=(
                f"/api/v1/artifacts/{artifact.id}"
                f"?filename={quote(download_filename, safe='')}"
            ),
        )


class ImportExportService:
    def __init__(
        self,
        session: Session,
        settings: Settings,
        *,
        registry: AdapterRegistry | None = None,
        store: LocalArtifactStore | None = None,
    ) -> None:
        self.session = session
        self.settings = settings
        self.registry = registry
        self.artifacts = ArtifactService(session, store or LocalArtifactStore(settings.data_dir))

    def formats(self) -> list[FormatRead]:
        return [
            FormatRead(
                format=item.format,
                label=item.label,
                extensions=list(item.extensions),
                media_types=list(item.media_types),
                can_import=item.can_import,
                can_export=item.can_export,
                multi_record=item.multi_record,
            )
            for item in self._registry().capabilities()
        ]

    def prepare(
        self,
        uploads: list[UploadPayload],
        *,
        generate_3d: bool = True,
        infer_bonds: bool = True,
    ) -> list[PreparedFile]:
        return prepare_uploads(
            self.settings,
            uploads,
            generate_3d=generate_3d,
            infer_bonds=infer_bonds,
            registry=self.registry,
        )

    def commit_import(
        self,
        project_id: str,
        expected_revision: int,
        prepared: list[PreparedFile],
    ) -> ImportRead:
        project = self.session.get(Project, project_id)
        if project is None:
            raise ProjectNotFoundError(project_id)
        if project.revision != expected_revision:
            raise RevisionConflictError(project.revision)

        now = datetime.now(UTC)
        entry_states: list[dict[str, Any]] = []
        warnings: list[MolecularWarning] = []
        for prepared_file in prepared:
            original = self.artifacts.publish(
                prepared_file.data,
                prepared_file.filename,
                prepared_file.media_type,
            )
            for record_number, structure in enumerate(prepared_file.structures, start=1):
                normalized_filename = (
                    f"{safe_filename_stem(prepared_file.filename)}-{record_number}.normalized.json"
                )
                normalized = self.artifacts.publish(
                    structure.to_bytes(),
                    normalized_filename,
                    NORMALIZED_MEDIA_TYPE,
                )
                entry_id = str(uuid7())
                entry_states.append(
                    {
                        "id": entry_id,
                        "group_id": None,
                        "name": structure.title[:160],
                        "description": None,
                        "structure_type": structure.structure_type,
                        "original_filename": prepared_file.filename,
                        "source_format": prepared_file.source_format,
                        "normalized_data": {
                            "schema_version": 1,
                            "storage": "artifact",
                        },
                        "atom_count": len(structure.atoms),
                        "atom_ids": [atom.id for atom in structure.atoms],
                        "bond_count": len(structure.bonds),
                        "residue_count": len(structure.residues),
                        "conformer_count": len(structure.conformers),
                        "warnings": [
                            warning.model_dump(mode="json") for warning in structure.warnings
                        ],
                        "next_atom_id": max(
                            (atom.id for atom in structure.atoms), default=0
                        )
                        + 1,
                        "next_bond_id": max(
                            (bond.id for bond in structure.bonds), default=0
                        )
                        + 1,
                        "viewer_settings": default_viewer_settings(structure.structure_type),
                        "visible": True,
                        "locked": False,
                        "user_metadata": {},
                        "job_links": [],
                        "generated_results": [],
                        "original_artifact_id": original.id,
                        "current_artifact_id": normalized.id,
                        "created_at": now.isoformat(),
                    }
                )
                warnings.extend(structure.warnings)
        project_read = ProjectService(
            self.session,
            load_structure=self.artifacts.load_normalized,
            load_original_bytes=self.artifacts.read_verified_bytes,
        ).import_entries(
            project_id,
            expected_revision,
            entry_states,
            len(prepared),
        )
        return ImportRead(
            project=project_read,
            imported_entry_ids=[str(state["id"]) for state in entry_states],
            warnings=warnings,
        )

    def structure(
        self,
        project_id: str,
        entry_id: str,
        *,
        expected_artifact_id: str | None = None,
    ) -> StructureRead:
        entry = self._entry(project_id, entry_id)
        artifact_id = entry.current_artifact_id
        if artifact_id is None:
            raise StructureUnavailableError(entry_id)
        if expected_artifact_id is not None and artifact_id != expected_artifact_id:
            raise StructureArtifactConflictError(
                f"Entry {entry_id} changed. Refresh its structure before continuing."
            )
        # Bind both the payload and its response identity to this immutable snapshot.
        # Reading a later current pointer here can poison an artifact-keyed cache.
        captured_entry_id, captured_name = entry.id, entry.name
        _, payload = self.artifacts.read(artifact_id)
        structure = NormalizedStructureV1.from_bytes(payload)
        viewer_format = (
            "mmcif"
            if structure.structure_type
            in {
                "protein",
                "complex",
                "solvent",
            }
            else "sdf"
        )
        from neistra_core.viewer_projection import ligand_viewer_sdf

        # Display has no requirement to produce chemically normalized export.
        data = ligand_viewer_sdf(structure) if viewer_format == "sdf" else (
            self._registry().for_format(viewer_format)
            .export(structure, safe_filename_stem(captured_name)).data.decode("utf-8")
        )
        return StructureRead(
            entry_id=captured_entry_id,
            artifact_id=artifact_id,
            structure=structure,
            hierarchy=derive_component_hierarchy(structure),
            viewer=ViewerProjection(
                format=viewer_format,
                data=data,
            ),
        )

    def original(self, project_id: str, entry_id: str) -> tuple[Artifact, bytes]:
        entry = self._entry(project_id, entry_id)
        if entry.original_artifact_id is None:
            raise StructureUnavailableError(entry_id)
        return self.artifacts.read(entry.original_artifact_id)

    def export(
        self,
        project_id: str,
        entry_id: str,
        format_name: str,
        *,
        acknowledge_losses: bool,
    ) -> ExportRead:
        entry = self._entry(project_id, entry_id)
        if entry.current_artifact_id is None:
            raise StructureUnavailableError(entry_id)
        _, payload = self.artifacts.read(entry.current_artifact_id)
        structure = NormalizedStructureV1.from_bytes(payload)
        result = (
            self._registry()
            .for_format(format_name)
            .export(structure, safe_filename_stem(entry.name))
        )
        blocking = [warning for warning in result.warnings if warning.blocking]
        if blocking and not acknowledge_losses:
            raise LossAcknowledgementRequiredError(blocking)
        artifact = self.artifacts.publish(result.data, result.filename, result.media_type)
        self.session.commit()
        return ExportRead(
            artifact=self.artifacts.response(artifact, filename=result.filename),
            warnings=list(result.warnings),
        )

    def batch_sources(
        self,
        project_id: str,
        *,
        scope: str,
        entry_ids: list[str],
    ) -> ExportSourceSet:
        project = self.session.get(Project, project_id)
        if project is None:
            raise ProjectNotFoundError(project_id)
        entries = sorted(project.entries, key=lambda item: item.id)
        if scope == "visible":
            entries = [entry for entry in entries if entry.visible]
        elif scope == "selected":
            requested_ids = set(entry_ids)
            found_ids = {entry.id for entry in entries if entry.id in requested_ids}
            missing_ids = sorted(requested_ids - found_ids)
            if missing_ids:
                raise ExportPolicyError(
                    "invalid_export_selection",
                    f"Selected entries are not in this project: {', '.join(missing_ids)}.",
                )
            entries = [entry for entry in entries if entry.id in requested_ids]
        elif scope != "all":
            raise ExportPolicyError("invalid_export_scope", f"Unsupported export scope: {scope}.")
        if not entries:
            raise ExportPolicyError(
                "empty_export_scope",
                f"The {scope} export scope contains no structures.",
            )

        inputs: list[ExportInput] = []
        for entry in entries:
            if entry.current_artifact_id is None:
                raise StructureUnavailableError(entry.id)
            _, payload = self.artifacts.read(entry.current_artifact_id)
            inputs.append(
                ExportInput(
                    entry_id=entry.id,
                    entry_name=entry.name,
                    structure=NormalizedStructureV1.from_bytes(payload),
                )
            )
        return ExportSourceSet(
            project_name=project.name,
            source_revision=project.revision,
            inputs=tuple(inputs),
        )

    def publish_batch_export(
        self,
        prepared: PreparedExport,
        *,
        scope: str,
        source_revision: int,
        acknowledge_losses: bool,
    ) -> BatchExportRead:
        reports = [
            ExportEntryReportRead(
                entry_id=report.entry_id,
                entry_name=report.entry_name,
                output_filename=report.output_filename,
                record_index=report.record_index,
                warnings=list(report.warnings),
            )
            for report in prepared.reports
        ]
        blocking = [warning for warning in prepared.warnings if warning.blocking]
        if blocking and not acknowledge_losses:
            raise LossAcknowledgementRequiredError(blocking, reports=reports)
        artifact = self.artifacts.publish(
            prepared.data,
            prepared.filename,
            prepared.media_type,
        )
        self.session.commit()
        return BatchExportRead(
            artifact=self.artifacts.response(artifact, filename=prepared.filename),
            scope=scope,
            source_revision=source_revision,
            format=prepared.format,
            mode=prepared.mode,
            reports=reports,
        )

    def artifact(self, artifact_id: str) -> tuple[Artifact, bytes]:
        return self.artifacts.read(artifact_id)

    def _entry(self, project_id: str, entry_id: str) -> StructureEntry:
        project = self.session.get(Project, project_id)
        if project is None:
            raise ProjectNotFoundError(project_id)
        entry = self.session.scalar(
            select(StructureEntry).where(
                StructureEntry.project_id == project_id,
                StructureEntry.id == entry_id,
            )
        )
        if entry is None:
            raise EntryNotFoundError(entry_id)
        return entry

    def _registry(self) -> AdapterRegistry:
        # RDKit adapter objects are created in the thread where parsing runs.
        return self.registry or create_default_registry()
