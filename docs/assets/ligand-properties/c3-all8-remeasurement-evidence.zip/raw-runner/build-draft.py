"""Static unsealed native11 scaffold only; no preparation, collection or execution."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json

ROOT=Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
OUT=Path(__file__).resolve().parent
OLD=OUT.parent/'native-probe10-all8'
WORKER=ROOT/'.issue-11-evidence/issue159-bulk-validation-correction1'
TRANSPORT=ROOT/'.issue-11-evidence/issue159-full43-transport-identity-correction1/transport.py'
TRANSPORT_CHECK=ROOT/'.issue-11-evidence/issue159-full43-transport-identity-validation1/synthetic-controls.json'


def sha(body): return hashlib.sha256(body).hexdigest()
def encoded(value): return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
def write(name,body):
    with (OUT/name).open('xb') as stream: stream.write(body)


handoff=json.loads((WORKER/'handoff.json').read_bytes())
assert sha((WORKER/'handoff.json').read_bytes())=='44c08aecd52d1b18a557e8870ed4742ae75a61c7374ba7c9eecb00c91793b5c0'
subjects=handoff['subjects']
sources=json.loads((OLD/'expected-sources.json').read_bytes())
methods=json.loads((OLD/'expected-methods.json').read_bytes())
previous_sources=dict(sources);previous_methods=dict(methods)
for name,digest in subjects.items():
    assert sha((ROOT/name).read_bytes())==digest
    sources[name]=digest
methods['tests/e2e/ligand-properties-performance.spec.ts']=subjects['tests/e2e/ligand-properties-performance.spec.ts']
methods['tests/e2e/support/bulk-property-validation.ts']=subjects['tests/e2e/support/bulk-property-validation.ts']
compact=sha(json.dumps(sources,sort_keys=True,separators=(',',':')).encode())
spaced=sha(json.dumps(sources,sort_keys=True).encode())
method_digest=sha(json.dumps(methods,sort_keys=True).encode())
assert len(sources)==1130 and len(methods)==51
assert compact=='b2d49ff2c807b6634d7830a1d331c4df5380571d86daf77efb3a95ed869040af'
added=sorted(set(sources)-set(previous_sources))
changed=sorted(name for name in previous_sources if sources[name]!=previous_sources[name])
assert added==['apps/web/src/test/ligand-property-bulk-validation.test.ts','tests/e2e/support/bulk-property-validation.ts']
assert changed==['tests/e2e/ligand-properties-performance.spec.ts']
assert set(methods)-set(previous_methods)=={'tests/e2e/support/bulk-property-validation.ts'}
assert [name for name in previous_methods if methods[name]!=previous_methods[name]]==['tests/e2e/ligand-properties-performance.spec.ts']
assert methods['tests/e2e/support/consumer-heartbeat.ts']=='fabdfc7b91fe414571cf5dc6c43af0ce96f566b75a156e60c3dca563bdc48124'
write('expected-sources.json',encoded(sources));write('expected-methods.json',encoded(methods))
write('current-source-delta.json',encoded({'scope':'Actual current declared static sources; not a committed checkpoint or qualification',
    'parent':'060c0fa0e06f156df253ffe55473fcaeb007242a','source_count':1130,
    'source_digest_compact':compact,'source_digest_spaced':spaced,'method_count':51,
    'method_digest_spaced':method_digest,'added':added,'changed':changed,'removed':[],
    'old49other_methods_unchanged':True,'production_scientific_TTL_API_schema_versions_unchanged':True,
    'method_change':'One import, four pointwise matcher statements replaced by one batch matcher; exact predicate equivalence, not unchanged167/334 matcher ASTs.'}))

source=(OLD/'runner.py').read_text()
tree=ast.parse(source)
root_function=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='validate_root_qualification')
replacement='''def validate_root_qualification(source, methods, pins, checkpoint) -> None:
    """Bind the actual oracle checkpoint and retain native10's failed outcome."""
    assert len(source) == 1130 and source_map_digest(source) == EXPECTED_DIGEST
    assert map_digest(source) == EXPECTED_SOURCE_SPACED_DIGEST
    assert len(methods) == 51 and map_digest(methods) == EXPECTED_METHOD_DIGEST
    assert checkpoint['checkpoint'] == PARENT_CANDIDATE
    assert checkpoint['parent'] == '060c0fa0e06f156df253ffe55473fcaeb007242a'
    assert checkpoint['source_count'] == 1130 and checkpoint['clean_owned_tree'] is True
    assert checkpoint['source_digest_compact_json'] == EXPECTED_DIGEST
    assert checkpoint['method_count'] == 51 and checkpoint['method_digest_spaced_json'] == EXPECTED_METHOD_DIGEST
    assert checkpoint['scoped_architecture'] == checkpoint['scoped_performance'] == 'PASS'
    assert checkpoint['complete_intended_diff_and_newfiles_self_review'] == 'PASS'
    assert checkpoint['new_final_ALL8_success_receipt_created'] is False
    keys = pins['keys']
    previous = json.loads((ROOT/keys['prior_sources']).read_text())
    previous_methods = json.loads((ROOT/keys['prior_methods']).read_text())
    assert len(previous) == 1128 and len(previous_methods) == 50
    assert source_map_digest(previous) == 'f1d5e6179433cc40f3da613a97beaf3081296ce586d71681794372800545ac97'
    assert map_digest(previous_methods) == 'bb085d13b027770a939db61e9638c7c329a18a758cb53c293cd801904ccaa63d'
    assert set(source)-set(previous) == {'apps/web/src/test/ligand-property-bulk-validation.test.ts',
                                         'tests/e2e/support/bulk-property-validation.ts'}
    assert not set(previous)-set(source)
    assert {name for name in previous if previous[name] != source[name]} == {'tests/e2e/ligand-properties-performance.spec.ts'}
    assert set(methods)-set(previous_methods) == {'tests/e2e/support/bulk-property-validation.ts'}
    assert not set(previous_methods)-set(methods)
    assert {name for name in previous_methods if previous_methods[name] != methods[name]} == {'tests/e2e/ligand-properties-performance.spec.ts'}
    assert methods['tests/e2e/support/consumer-heartbeat.ts'] == 'fabdfc7b91fe414571cf5dc6c43af0ce96f566b75a156e60c3dca563bdc48124'
    worker = json.loads((ROOT/keys['worker_handoff']).read_text())
    assert worker['combined_focused_result']['total'] == 16
    assert worker['combined_focused_result']['failed_skipped_flaky_retries'] == 0
    assert all(item['exit_code'] == 0 for item in worker['checks'].values())
    assert all(source[name] == digest for name,digest in worker['subjects'].items())
    assert worker['independent_negative_controls']['total_predicate_fault_batches'] == 641
    assert worker['independent_negative_controls']['changed_or_reordered_source_batches'] == 4
    assert worker['no_production_science_TTL_API_schema_dependency_version_changes'] is True
    semantic = json.loads((ROOT/keys['predicate_preservation']).read_text())
    assert file_sha(ROOT/keys['predicate_preservation']) == worker['source_preservation_proof']['sha256']
    assert semantic['spec_entire_body_exact_except_one_import_four_repeated_matchers_and_one_batch_matcher'] is True
    assert semantic['original_ordered_source_assertion_exact_and_once'] is True
    assert semantic['unchanged_original_method_bodies'] == 49 and semantic['next_method_subject_count'] == 51
    assert semantic['existing_heartbeat_helper_exact'] is True
    assert all(source[name] == digest for name,digest in semantic['subjects'].items())
    prior = json.loads((ROOT/keys['prior_receipt']).read_text())
    terminal = json.loads((ROOT/keys['prior_terminal']).read_text())
    assert prior['binding']['HEAD'] == '060c0fa0e06f156df253ffe55473fcaeb007242a'
    assert prior['source_before'] == prior['source_after'] == previous
    assert prior['methods_before'] == prior['methods_after'] == previous_methods
    assert prior['exit_code'] == terminal['actual_runner_wait_exit'] == 1
    assert terminal['actual_transport_terminal'] is True
    assert terminal['transport_state'] == 'ERROR' and terminal['transport_identity_complete'] is False
    assert prior['browser_stats']['expected'] == 3 and prior['browser_stats']['unexpected'] == 1
    assert prior['browser_stats']['skipped'] == 4 and prior['browser_stats']['flaky'] == 0
    assert prior['cleanup']['complete'] and prior['source_unchanged'] and prior['runner_observation_complete']
    assert prior['database_byte_archive_error'] is None and prior['complete_source_guard_error'] is None
    preserved = json.loads((ROOT/keys['prior_failure_preservation']).read_text())
    assert preserved['preservation_package_actual_exit'] == 0
    assert preserved['input_roots'] == 7 and preserved['input_regular_files'] == 3407
    assert preserved['all_regular_bodies_CRC_and_exact_union_verified'] is True
    assert preserved['final_ALL8_qualification'] is False and preserved['publication_pending'] is True
    assert preserved['original_transport']['state'] == 'ERROR' and preserved['original_transport']['identity_complete'] is False
    versions = json.loads((OUT/'protected-version-bindings.json').read_text())
    assert set(versions['five_application_versions'].values()) == {'0.37.0'}
    assert all(source[name] == previous[name] == digest for name,digest in versions['bodies'].items())
    fixtures = json.loads((OUT/'fixture-controls-reuse-proof.json').read_text())
    assert fixtures['fixture_count'] == 44 and fixtures['old49other_methods_unchanged'] is True
    assert fixtures['current_method_count'] == 51 and fixtures['current_method_digest'] == EXPECTED_METHOD_DIGEST
    assert all(source[name] == digest for name,digest in fixtures['scientific_subjects'].items())
'''
lines=source.splitlines(keepends=True)
lines[root_function.lineno-1:root_function.end_lineno]=replacement.splitlines(keepends=True)
source=''.join(lines)
source=source.replace('native-probe10-all8','native-probe11-all8').replace('/tmp/neistra159-performance-native10-all8','/tmp/neistra159-performance-native11-all8')
source=source.replace("DRAFT_HOLD = False  # Actual checkpoint supplied; runtime still requires a separate root GO.","DRAFT_HOLD = True  # Unsealed scaffold: actual checkpoint/receipt/pins not supplied.")
source=source.replace("PARENT_CANDIDATE = '060c0fa0e06f156df253ffe55473fcaeb007242a'",'PARENT_CANDIDATE = None')
source=source.replace("EXPECTED_DIGEST = 'f1d5e6179433cc40f3da613a97beaf3081296ce586d71681794372800545ac97'",f"EXPECTED_DIGEST = '{compact}'")
source=source.replace("EXPECTED_SOURCE_SPACED_DIGEST = 'c477666c808ab117ab4638bdb162356663465b4fb6ae0d9b211342c7c89808cd'",f"EXPECTED_SOURCE_SPACED_DIGEST = '{spaced}'")
source=source.replace("EXPECTED_METHOD_DIGEST = 'bb085d13b027770a939db61e9638c7c329a18a758cb53c293cd801904ccaa63d'",f"EXPECTED_METHOD_DIGEST = '{method_digest}'")
for node in ast.parse(source).body:
    if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in {'ROOT_PINS_SHA','ROOT_RECEIPT_SHA'}:
        original=ast.get_source_segment(source,node)
        source=source.replace(original,node.targets[0].id+' = None')
source=source.replace('PORTS = (8520,8521,5520)','PORTS = (8530,8531,5530)')
for old,new in [('8520','8530'),('8521','8531'),('5520','5530')]:source=source.replace("'"+old+"'","'"+new+"'")
source=source.replace('assert len(source)==1128 and','assert len(source)==1130 and').replace('assert len(methods)==50 and','assert len(methods)==51 and')
source=source.replace('complete source/50method postguard','complete source/51method postguard')
compile(source,str(OUT/'runner.py'),'exec');write('runner.py',source.encode())
write('source_guard.py',(OLD/'source_guard.py').read_bytes())
write('protected-version-bindings.json',(OLD/'protected-version-bindings.json').read_bytes())

assert sha(TRANSPORT.read_bytes())=='bef28d5e4792d93c3a1741d0b6058a22b64eeb8a7c2b0a2194d76b802f4d3b4d'
transport_text=TRANSPORT.read_text()
helper_node=next(node for node in ast.parse(transport_text).body if isinstance(node,ast.FunctionDef) and node.name=='observe_identity')
helper=ast.get_source_segment(transport_text,helper_node)
supervisor=(OLD/'supervisor.py').read_text()
assert supervisor.count('def reviewed_runner():')==1
supervisor=supervisor.replace('def reviewed_runner():',helper+'\n\n\ndef reviewed_runner():')
old_launch='''        try:
            result["supervisor_identity"] = identity(process.pid, command)
'''
new_launch='''        result["supervisor_identity_observations"] = []
        try:
            result["supervisor_identity"] = observe_identity(
                process, command, parent_pid=os.getpid(), pgid=process.pid,
                session=process.pid, observations=result["supervisor_identity_observations"])
'''
old_runner='''            try:
                state["runner_identity"] = identity(process.pid, command)
                state["identity_complete"] = True
'''
new_runner='''            state["runner_identity_observations"] = []
            try:
                state["runner_identity"] = observe_identity(
                    process, command, parent_pid=os.getpid(), pgid=os.getpgrp(),
                    session=os.getsid(0), observations=state["runner_identity_observations"])
                state["identity_complete"] = True
'''
assert supervisor.count(old_launch)==supervisor.count(old_runner)==1
supervisor=supervisor.replace(old_launch,new_launch).replace(old_runner,new_runner)
compile(supervisor,str(OUT/'supervisor.py'),'exec');write('supervisor.py',supervisor.encode())

fixture=json.loads((OLD/'fixture-controls-reuse-proof.json').read_bytes())
assert len(fixture['scientific_subjects'])==157
assert all(sources[name]==digest for name,digest in fixture['scientific_subjects'].items())
assert len([name for name in methods if name.endswith('.sdf')])==44
write('fixture-controls-reuse-proof.json',encoded({'scope':'Static exact scientific/fixture reuse; no scientific/runtime work',
    'prior_fixture_proof':str((OLD/'fixture-controls-reuse-proof.json').relative_to(ROOT)),
    'prior_proof_sha256':sha((OLD/'fixture-controls-reuse-proof.json').read_bytes()),
    'fixture_count':44,'fixture_originals':fixture['fixture_originals'],
    'scientific_subject_count':157,'scientific_subjects':fixture['scientific_subjects'],
    'old49other_methods_unchanged':True,'changed_old_method':'tests/e2e/ligand-properties-performance.spec.ts',
    'new_method_dependency':'tests/e2e/support/bulk-property-validation.ts',
    'current_method_count':51,'current_method_digest':method_digest,
    'limit':'Predicate/exact-byte equivalence after matcher substitution, not an all167/334 AST-identity or same-method timing claim.'}))
functions=lambda text:{node.name:node for node in ast.parse(text).body if isinstance(node,ast.FunctionDef)}
old_functions,new_functions=functions((OLD/'runner.py').read_text()),functions(source)
changed_runner=sorted(name for name in old_functions if ast.dump(old_functions[name],include_attributes=False)!=ast.dump(new_functions[name],include_attributes=False))
assert changed_runner==['environment','pinned_inputs','prepare','validate_root_qualification']
old_super,new_super=functions((OLD/'supervisor.py').read_text()),functions(supervisor)
assert set(new_super)-set(old_super)=={'observe_identity'}
assert ast.dump(new_super['observe_identity'],include_attributes=False)==ast.dump(helper_node,include_attributes=False)
changed_super=sorted(name for name in old_super if ast.dump(old_super[name],include_attributes=False)!=ast.dump(new_super[name],include_attributes=False))
assert changed_super==['launch','supervise']


class Normalize(ast.NodeTransformer):
    def visit_Assign(self,node):
        if len(node.targets)==1 and isinstance(node.targets[0],ast.Subscript) and isinstance(node.targets[0].slice,ast.Constant) and node.targets[0].slice.value in {'runner_identity_observations','supervisor_identity_observations'}:
            assert isinstance(node.value,ast.List) and not node.value.elts
            return None
        return self.generic_visit(node)
    def visit_Call(self,node):
        if isinstance(node.func,ast.Name) and node.func.id=='observe_identity':
            return ast.Call(func=ast.Name(id='identity',ctx=ast.Load()),args=[ast.Attribute(value=ast.Name(id='process',ctx=ast.Load()),attr='pid',ctx=ast.Load()),copy.deepcopy(node.args[1])],keywords=[])
        return self.generic_visit(node)


for name in changed_super:
    assert ast.dump(Normalize().visit(copy.deepcopy(new_super[name])),include_attributes=False)==ast.dump(old_super[name],include_attributes=False)
control=json.loads(TRANSPORT_CHECK.read_bytes())
assert control['exit_code']==0 and control['transport_sha256']==sha(TRANSPORT.read_bytes())
for name,before,after in [('runner', (OLD/'runner.py').read_text(),source),('supervisor',(OLD/'supervisor.py').read_text(),supervisor)]:
    delta=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='native10/'+name+'.py',tofile='native11/'+name+'.py'))
    write(name+'-delta.patch',delta.encode())
proof={'scope':'UNSEALED HOLD native11 static scaffold only; no preparation/collection/controls/native execution',
    'expected_source_count':1130,'source_digest_compact':compact,'source_digest_spaced':spaced,
    'expected_method_count':51,'method_digest_spaced':method_digest,
    'unchanged_runner_function_ASTs':[name for name in old_functions if name not in changed_runner],
    'changed_runner_functions':changed_runner,'source_guard_byte_exact_native10':True,
    'supervisor_added_helper':'observe_identity','supervisor_helper_AST_exact_tested_full43_helper':True,
    'supervisor_changed_functions':changed_super,'supervisor_changed_functions_normalize_exactly_to_native10_after_only_capture_substitution':True,
    'existing_supervisor_functions_unchanged':[name for name in old_super if name not in changed_super],
    'closed_helper_synthetic_validation':{'path':str(TRANSPORT_CHECK.relative_to(ROOT)),'sha256':sha(TRANSPORT_CHECK.read_bytes()),'exit_code':0},
    'new_supervisor_callsite_controls_executed':False,
    'worker_handoff_sha256':sha((WORKER/'handoff.json').read_bytes()),
    'predicate_equivalence':{'independent_fault_batches':641,'changed_or_reordered_source_batches':4,'all_other_benchmark_bytes_exact':True,'ordered_source_check_unchanged':True},
    'obsolete_all167_334_AST_unchanged_claim':False,
    'future_workspace':'/tmp/neistra159-performance-native11-all8','future_ports':[8530,8531,5530],
    'actual_checkpoint_rootreceipt_rootpins_prepared_GO_collection_workspace_created':False,
    'draft_constants_unbound':['PARENT_CANDIDATE','ROOT_PINS_SHA','ROOT_RECEIPT_SHA'],
    'native10_spent_bytes_modified':False}
write('draft-proof.json',encoded(proof))
print(json.dumps(proof))
