"""Strict no-emit TypeScript check; no browser/service/workload invocation."""
from pathlib import Path
import json
import runpy
import subprocess
import time
OUT=Path(__file__).resolve().parent
r=runpy.run_path(str(OUT/'runner.py'),run_name='strict_static_only')
before=r['source_audit']()
assert not r['WORKSPACE'].exists() and not (OUT/'go.json').exists()
cmd=['./node_modules/.bin/tsc','--strict','--noEmit','--target','ES2022','--module','ESNext',
     '--moduleResolution','Bundler','--lib','ES2022,DOM,DOM.Iterable','--typeRoots','node_modules/@types',
     '--types','node','--skipLibCheck','../../tests/e2e/ligand-properties-performance.spec.ts']
started=time.monotonic()
with (OUT/'strict-ts.log').open('xb') as log:
    result=subprocess.run(cmd,cwd=r['ROOT']/'apps/web',stdout=log,stderr=subprocess.STDOUT)
after=r['source_audit']()
assert before==after
assert not r['WORKSPACE'].exists() and not r['owned_processes']() and all(r['ports']().values())
record={'scope':'Strict static no-emit TypeScript only; no services/browser/workflows/performance',
 'command':cmd,'cwd':str(r['ROOT']/'apps/web'),'exit_code':result.returncode,'seconds':time.monotonic()-started,
 'source_count':after['source_count'],'source_digest':after['source_digest'],'full_source_before_after_exact':before==after,
 'method_count':after['method_count'],'method_digest':after['method_digest'],'log_sha256':r['file_sha'](OUT/'strict-ts.log'),
 'workspace_exists':r['WORKSPACE'].exists(),'owned_processes':r['owned_processes'](),'ports_unused':r['ports']()}
(OUT/'strict-ts-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(result.returncode)
