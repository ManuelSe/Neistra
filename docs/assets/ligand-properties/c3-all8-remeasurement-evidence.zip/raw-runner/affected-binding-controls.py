"""Bounded changed-binding controls; process/network/signal work is prohibited."""
from pathlib import Path
import json
import os
import runpy
import socket
import subprocess
import time
import zipfile

OUT = Path(__file__).resolve().parent
started = time.monotonic()
attempts = []


def prohibited(*args, **kwargs):
    attempts.append('process_network_signal_attempt')
    raise AssertionError('Offline binding controls prohibit process/network/signal work')


subprocess.Popen = subprocess.run = subprocess.call = subprocess.check_call = subprocess.check_output = prohibited
socket.socket = socket.create_connection = prohibited
os.system = os.kill = os.killpg = prohibited
r = runpy.run_path(str(OUT/'runner.py'), run_name='offline_binding_controls')
before = r['source_audit']()
assert before['source_count'] == 1130 and before['method_count'] == 51
checks = ['current995e_complete1130_sources51methods_actual_checkpoint_and_failed_native10_binding_accepted']


def reject(name, operation):
    try:
        operation()
    except (AssertionError, FileNotFoundError, OSError, ValueError):
        checks.append(name)
    else:
        raise AssertionError('Negative binding control accepted: '+name)


pins = json.loads((OUT/'canonical-root-pins.json').read_text())
checkpoint = json.loads((r['ROOT']/pins['root_receipt']).read_text())
for field, value in [('checkpoint', 'wrong synthetic identity'), ('source_count',1129),
                     ('method_count',50), ('clean_owned_tree',False),
                     ('scoped_architecture','CHANGES_REQUIRED'),
                     ('combined_focused_tests',0), ('independent_predicate_fault_batches',640),
                     ('independent_source_fault_batches',0),
                     ('native10_actual_runner_wait_exit',0),
                     ('new_final_ALL8_success_receipt_created',True)]:
    reject('reject_stale_or_false_checkpoint_'+field, lambda field=field,value=value:
           r['validate_root_qualification'](before['sources'],before['methods'],pins,
                                            {**checkpoint,field:value}))
head_function = r['pinned_inputs'].__globals__['authoritative_head']
try:
    r['pinned_inputs'].__globals__['authoritative_head'] = lambda: {
        **head_function(),'commit':'wrong synthetic identity'}
    reject('reject_wrong_actual_current_HEAD', r['pinned_inputs'])
finally:
    r['pinned_inputs'].__globals__['authoritative_head'] = head_function
for name in ('canonical-root-pins.json','expected-sources.json','expected-methods.json','supervisor.py'):
    path = OUT/name
    body = path.read_bytes()
    try:
        path.write_bytes(body+b'\n ')
        reject('reject_private_binding_byte_drift_'+name,r['pinned_inputs'])
    finally:
        path.write_bytes(body)
read_text = Path.read_text


def changed_closed_json(key, field, value):
    path = r['ROOT']/pins['keys'][key]
    original = json.loads(read_text(path))
    def intercepted(current, *args, **kwargs):
        if current == path:
            return json.dumps({**original,field:value})
        return read_text(current,*args,**kwargs)
    try:
        Path.read_text = intercepted
        reject('reject_changed_failed_native10_'+key+'_'+field,lambda:
               r['validate_root_qualification'](before['sources'],before['methods'],pins,checkpoint))
    finally:
        Path.read_text = read_text


changed_closed_json('prior_receipt','exit_code',0)
changed_closed_json('prior_terminal','actual_runner_wait_exit',0)
changed_closed_json('prior_failure_preservation','final_ALL8_qualification',True)
changed_closed_json('prior_terminal','transport_state','TERMINAL')
changed_closed_json('worker_handoff','combined_focused_result',{'total':0,'failed_skipped_flaky_retries':0})
changed_closed_json('predicate_preservation','spec_entire_body_exact_except_one_import_four_repeated_matchers_and_one_batch_matcher',False)
assert r['source_audit']() == before
assert not r['WORKSPACE'].exists() and not (OUT/'go.json').exists()
assert not (OUT/'native').exists() and all(r['ports']().values()) and not r['owned_processes']()
checks.append('full_current_sources_tools_restored_and_reverified_after_controls')
r['prepare']()
prepared = json.loads((OUT/'prepared.json').read_text())
with zipfile.ZipFile(OUT/'source-preparation.zip') as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(before['sources'])
    assert len(archive.namelist()) == 1130
    for name,expected in before['sources'].items():
        assert r['sha'](archive.read(name)) == expected
checks.append('offline_preparation_source_archive_all1130_bodies_CRC_exact_union_no_exclusions')
reject('reject_missing_real_GO',r['validate_go'])
try:
    def unauthorized(current,*args,**kwargs):
        if current == OUT/'go.json':
            return json.dumps({'authorized':False,'binding':prepared['binding'],
                               'prepared_sha256':r['file_sha'](OUT/'prepared.json')})
        return read_text(current,*args,**kwargs)
    Path.read_text = unauthorized
    reject('reject_unauthorized_GO_in_memory_no_file_created',r['validate_go'])
finally:
    Path.read_text = read_text
assert not attempts and r['source_audit']() == before
assert not r['WORKSPACE'].exists() and not (OUT/'go.json').exists() and not (OUT/'native').exists()
report={'scope':'Changed binding/offline preparation only; no apps/tests/native/browser/SQL/process/network/signal',
        'checks':checks,'count':len(checks),'all_passed':True,'prohibited_attempts':attempts,
        'candidate':r['PARENT_CANDIDATE'],'source_count':1130,'method_count':51,
        'source_digest':before['source_digest'],'method_digest':before['method_digest'],
        'prepared_sha256':r['file_sha'](OUT/'prepared.json'),
        'runner_sha256':r['file_sha'](OUT/'runner.py'),'source_archive':prepared['source_archive'],
        'actual_GO_created':False,'runtime_workspace_created':False,'seconds':time.monotonic()-started}
with (OUT/'affected-binding-controls.json').open('x') as stream:
    json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps({key:value for key,value in report.items() if key != 'checks'}))
