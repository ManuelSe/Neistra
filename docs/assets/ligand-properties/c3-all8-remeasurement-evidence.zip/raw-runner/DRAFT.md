# Native11 scaffold — unsealed HOLD

Only this new private kit was written. No actual checkpoint/receipt placeholder,
root pins, preparation, source archive, GO, collection, runtime workspace, tests,
process controls, applications, browser workflows, services, chemistry, SQL or Git
changes were made. Native10 spent bytes remain immutable.

Future workspace `/tmp/neistra159-performance-native11-all8`; ports8530/8531/5530.
The actual future checkpoint is unbound: `PARENT_CANDIDATE`, `ROOT_PINS_SHA` and
`ROOT_RECEIPT_SHA` remain unset, with explicit `DRAFT_HOLD=True` before pin access.

Static declared maps equal the root's current canonical maps and every declared
body was rehashed:

-1130sources, compact `b2d49ff2c807b6634d7830a1d331c4df5380571d86daf77efb3a95ed869040af`;
 spaced `341bc40579eef1150c7c1a145c0550702ab6385a5fa47700942bbb408279a48a`.
-51methods, spaced `dceb6a3202e1d378e051e8e3efa1f3ce0ed257793732a4c26df46c86d6346d07`.
- Only the old spec changes; the new bulk-validation dependency is added.
 All49other methods, including the heartbeat helper,44frozen originals and
157scientific subjects remain exact. Five0.37.0version bindings are reused.

The oracle correction replaces four repeated matcher statements with one batch
matcher and adds its import; all other spec bytes and the ordered-source assertion
remain exact. Closed16focused cases and641independent predicate-fault batches plus
four source/order faults establish semantic equivalence. There is deliberately
**no all167/334 matcher-AST identity claim**. The benchmark method/cost changed;
deterministic instrumented work reduction is not an application latency speedup.
Original budgets, waits, deadlines, inputs, work/fairness/scientific/resource bounds,
the20s serial heartbeat lane/60s lease/five200-entry owners and retries0 remain.

Runner execution/source/ownership/resource/sourceZIP/rawcopy/cleanup logic remains
unchanged:23function ASTs match native10. Only environment ports, root qualification,
pin counts/path and preparation51-method metadata change. Sourceguard is byte-exact.
Qualification compares the real future checkpoint with FAILED native10 (060c,
exit1/3PASS1FAIL4unrun, originalERROR/identityfalse) and its complete preserved raw
packet. No earlier failure or success is relabelled as native11qualification.

The supervisor adds exactly one `observe_identity` helper, copied AST-exact from
the closed tested private transport correction. Only its two capture call sites
change. Removing the observation-list assignments and substituting their original
identity calls restores both original function ASTs exactly. All seven other
supervisor functions, reservations/registration, raw stdout and actual wait remain.
The observer stays on the SAME Popen PID with pinned start/expected parent/group/
session/argv, records initial mismatches/errors, and stops on replacement/exit/
deadline without restart. The closed full43 helper's8methods/14scenario controls
are source-qualified reuse evidence; **new native11 integration controls have not
run**. Tiny actual/affected controls remain for primary coordination.

Before preparation, primary must provide the actual committed checkpoint and
receipt, align common receipt fields to that real artifact, finalize root/file
pins and runtime hashes, and review complete `runner-delta.patch` and
`supervisor-delta.patch`. Key inputs include actual prior10sources/methods/receipt,
terminal proof and failed-preservation handoff, plus `worker_handoff` and
`predicate_preservation` from the closed oracle correction. Preserve scoped
architecture/performance/self-review evidence and actual failure identities.

Then run bounded affected binding/transport controls and coordinated strict TS/
original8case collection as required, source-bound preparation and independent
primary/architecture review. Real exact root GO is a later separate action.
No readiness or native workflow PASS is inferred from this scaffold.
