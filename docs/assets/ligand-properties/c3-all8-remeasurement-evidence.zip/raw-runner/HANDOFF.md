# Native11 prepared — HOLD for primary/architecture review

Preparation binds actual checkpoint995e80f8e59bac4265ecc7b70ced04277ecb7550,
parent060c, and actual local receipt SHA256
`9ff8c3477ec945c33a59334bd668afc5b8fced4f9d815d22f2e906e842e4248e`.
Historical `DRAFT.md` records the earlier unsealed stage. This final handoff is
preparation only; no real GO or runtime workflow has been created/executed.

Actual checks:

-12affected supervisor test methods PASS: same-PID delayed argv, parent/group/
 session checks, token replacement, initial errors, bounded timeout, identity read
 crossing deadline, registration deadline with no child launch, both capture
 sites, exact early0/7/-15 wait retention and one-shot refusal. Two real tiny owned
 Python children exit0/7 with exact positive identity and retained raw stdout.
 All other transport fixtures are explicitly synthetic, retained under the kit.
-26current root/checkpoint/method/predicate/failure binding controls PASS, including
 rejecting normalized old transport state, a false16-test result and false
 predicate-preservation proof. Complete1130-source ZIP bodies/CRC/exact union pass.
- Fresh strict benchmark TypeScript exits0; original complete8-case collection
 exits0 with both profiles/four bulk cohorts, original spec, retries0 and no
 grep/project/private-config filtering. Both checks preserve full1130/51audits.
- Current source/HEAD readback remains clean995e. Ports8530/8531/5530 are unused;
 no positively owned runtime process, native output, raw runtime log or native11
 workspace exists. The GO template is authorizedfalse; real `go.json` is absent.

One initial shell redirection used a nonexistent wrapper-log directory and stopped
before launching the strict check; its tool exit is recorded in the actual-check
receipt. The corrected actual strict command passes. No control/test failure or
source correction was hidden.

Source compact digest:
`b2d49ff2c807b6634d7830a1d331c4df5380571d86daf77efb3a95ed869040af`.
51-method spaced digest:
`dceb6a3202e1d378e051e8e3efa1f3ce0ed257793732a4c26df46c86d6346d07`.

23runner function ASTs and sourceguard remain unchanged. Seven existing supervisor
functions remain unchanged; the tested bounded observer is copied once and only
two capture sites use it. Both normalize exactly to old function ASTs after the
capture substitution. Reservations, registration, actual wait, raw stdout, source
ZIP, ownership/resource/cleanup/rawcopy logic remain. No process restart, retry,
deadline extension or actual-exit normalization is introduced.

The new predicate collector is qualified by16closed focused cases,641predicate
fault batches and four source/order faults. The original ordered-source assertion,
all other spec bytes, budgets/waits/deadlines, scientific/work/resource/fairness
requirements, serial20s heartbeat/60s lease/five200-entry owners remain. This is
semantic/exact-byte equivalence after changing four matcher sites; it is **not** an
all167/334 matcher-AST claim.49other methods,44fixtures and157scientific bodies
remain byte-exact. No application latency speedup or same-method comparison follows.

Failed native10 remains exit1/3PASS1FAIL4unrun with originalERROR/identityfalse and
its complete verified forensic evidence. Both committed43-command recipes are
hash-bound, but no complete43gate ran in this task.

Primary should independently inspect actual receipts/raw logs, complete deltas,
root/pin/source bindings, source ZIP and this sealed capsule; architecture review
remains pending. After acceptance, primary can author the exact real GO and use
the detached supervisor launch entry. Launcher0 means acceptance only. Actual
supervisor wait, all8outcomes and complete source/resource/worker/cleanup/raw proofs
remain mandatory before any workflow qualification claim. Keep source/pins/runtime
bytes immutable after GO. Preserve spent failures rather than restarting them.

Future runtime workspace `/tmp/neistra159-performance-native11-all8`; ports8530/
8531/5530. No application imports, services, browsers, molecular calculations, SQL,
public/source/Git mutations or release actions were performed by this preparation.
