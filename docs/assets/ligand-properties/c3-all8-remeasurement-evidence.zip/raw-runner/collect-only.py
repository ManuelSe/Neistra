"""Actual original eight-case collection only; no runtime workflow or private config."""
from pathlib import Path
import json
import runpy
import subprocess
import time

OUT=Path(__file__).resolve().parent
r=runpy.run_path(str(OUT/'runner.py'),run_name='original_all8_collection_only')
before=r['source_audit']()
env,overrides,unset=r['environment']()
env['PLAYWRIGHT_JSON_OUTPUT_FILE']=str(OUT/'collection.json')
command=r['command']()+['--list']
assert not r['WORKSPACE'].exists() and not (OUT/'go.json').exists()
assert not (OUT/'native').exists() and not (OUT/'raw.log').exists()
started=time.monotonic()
with (OUT/'collection.log').open('xb') as output:
    result=subprocess.run(command,cwd=r['ROOT'],env=env,stdout=output,stderr=subprocess.STDOUT)
after=r['source_audit']()
assert before==after and not r['WORKSPACE'].exists()
assert not r['owned_processes']() and all(r['ports']().values())
assert not (OUT/'native').exists() and not (OUT/'raw.log').exists()
assert result.returncode==0


def cases(value):
    output=[]
    for spec in value.get('specs',[]):
        output += [(test['projectName'],spec['title']) for test in spec['tests']]
    for suite in value.get('suites',[]):output += cases(suite)
    return output


actual=cases(json.loads((OUT/'collection.json').read_text()))
prior=cases(json.loads((OUT.parent/'native-probe10-all8/collection.json').read_text()))
assert len(actual)==len(set(actual))==8 and sorted(actual)==sorted(prior)
assert {profile for profile,title in actual}=={'chromium','mobile-chromium'}
assert len([title for profile,title in actual if '1000-entry' in title])==4
assert '--grep' not in command and '--project' not in command and '--config' not in command
receipt={'scope':'Actual complete8 static collection only; no service/browser/native workflow',
         'candidate':r['PARENT_CANDIDATE'],'command':command,'exit_code':result.returncode,
         'seconds':time.monotonic()-started,'selected_cases':actual,
         'exact_original_all8_both_profiles_four_bulk_cohorts':True,
         'source_count':1130,'source_digest':after['source_digest'],
         'method_count':51,'method_digest':after['method_digest'],
         'source_guard_before_after_equal':True,'runtime_workspace_exists':False,
         'actual_GO_exists':False,'runtime_native_exists':False,'raw_runtime_log_exists':False,
         'ports_unused':r['ports'](),'positive_owned_processes':r['owned_processes'](),
         'grep_or_project_filter_present':False,'private_config_or_fixture':False,
         'log_sha256':r['file_sha'](OUT/'collection.log'),'json_sha256':r['file_sha'](OUT/'collection.json')}
with (OUT/'collection-receipt.json').open('x') as stream:
    json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps(receipt))
