"""Observe native11's original registered handles; never restart or infer PASS."""
from pathlib import Path
from datetime import datetime, timezone
import json
import runpy

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
BASE = ROOT / '.issue-11-evidence/issue159-performance/native-probe11-all8'
state = json.loads((BASE / 'transport-status.json').read_text())
ns = runpy.run_path(str(BASE / 'supervisor.py'), run_name='primary_native11_observation')
identities = {}
for key in ('supervisor', 'runner_identity'):
    expected = state.get(key)
    if expected is None:
        identities[key] = {'registered': False}
        continue
    try:
        actual = ns['identity'](expected['pid'], expected['command'])
        exact = all(actual[n] == expected[n] for n in ('pid', 'start_token', 'pgid', 'session', 'command'))
        if key == 'runner_identity':
            raw = (Path('/proc') / str(actual['pid']) / 'stat').read_text()
            fields = raw[raw.rindex(')') + 2:].split()
            exact = exact and int(fields[1]) == state['supervisor']['pid']
        identities[key] = {'live': exact, 'pid': actual['pid'], 'start_token': actual['start_token']}
    except (OSError, AssertionError, ValueError) as error:
        identities[key] = {'live': False, 'observation_error': type(error).__name__}
row = {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'state': state['state'],
       'terminal': state['terminal'], 'actual_runner_returncode': state['actual_runner_returncode'],
       'transport_identity_complete': state['identity_complete'], 'positive_same_process_identities': identities,
       'scope': 'Registered live handle or actual terminal observation only; no workflow PASS inference'}
with (BASE / 'primary-live-observations.jsonl').open('a') as stream:
    stream.write(json.dumps(row) + '\n')
print(json.dumps(row))
log = BASE / 'runner-output.log'
if log.exists():
    print(log.read_text(errors='replace')[-1500:])
