"""Closed ALL8 metadata adaptation; requires actual terminal proof before run inputs.

No application imports, database connections, profiling, processes or networking.
Analysis is limited to closed native11 inputs after independently verified terminal proof.
"""
from pathlib import Path
import argparse
import collections
import datetime
import hashlib
import json
import math
import statistics
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BASE = ROOT/'.issue-11-evidence/issue159-performance/native-probe11-all8'
WORKSPACE = Path('/tmp/neistra159-performance-native11-all8')
BASELINE = ROOT/'.issue-11-evidence/issue159-performance/native-probe8-all8'
INPUTS = {}
HEAD = '995e80f8e59bac4265ecc7b70ced04277ecb7550'
SOURCE = 'b2d49ff2c807b6634d7830a1d331c4df5380571d86daf77efb3a95ed869040af'
METHOD = 'dceb6a3202e1d378e051e8e3efa1f3ce0ed257793732a4c26df46c86d6346d07'


def path_checked(path):
    path = Path(path)
    if not path.is_absolute(): path = ROOT/path
    assert path.is_file() and not path.is_symlink() and path.resolve() == path, path
    assert path.is_relative_to(ROOT) or path.is_relative_to(WORKSPACE), path
    return path


def fingerprint(path, *, register=True):
    path = path_checked(path)
    before = path.stat(); digest = hashlib.sha256(); size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block); size += len(block)
    after = path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns) == (
        after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns), path
    value = {'bytes':size,'sha256':digest.hexdigest()}
    if register:
        key = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
        assert key not in INPUTS or INPUTS[key] == value, f'Closed input changed: {path}'
        INPUTS[key] = value
    return value


def sha(path): return fingerprint(path)['sha256']


def load(path):
    path = path_checked(path)
    expected = fingerprint(path)
    body = path.read_bytes()
    assert len(body) == expected['bytes'] and hashlib.sha256(body).hexdigest() == expected['sha256']
    return json.loads(body)


def jsonl(path):
    path = path_checked(path); fingerprint(path)
    with path.open('rb') as stream:
        for line in stream:
            assert line.endswith(b'\n'), f'Incomplete closed JSONL: {path}'
            value = json.loads(line); assert isinstance(value,dict)
            yield value


def dist(values, limit=None):
    # Same median/nearest-rank p95 and target-miss semantics as closed baseline.
    values = sorted(values)
    assert values and all(type(v) in (int,float) and math.isfinite(v) and v >= 0 for v in values)
    result = {'n':len(values),'median':statistics.median(values),
              'p95_nearest_rank':values[math.ceil(.95*len(values))-1],
              'min':values[0],'max':values[-1]}
    if limit is not None: result.update(limit=limit,misses=sum(v>limit for v in values))
    return result


def strict_zero(value): assert type(value) is int and value == 0


def bound(description, expected_path):
    path = path_checked(description['path'])
    assert path == expected_path
    assert fingerprint(path)['sha256'] == description['sha256']
    return path


def browser_cases(document, *, passed):
    output = []
    def walk(suite):
        for spec in suite.get('specs',[]):
            for test in spec['tests']:
                if passed:
                    assert len(test['results']) == 1
                    result = test['results'][0]
                    assert result['status'] == 'passed'
                    strict_zero(result['retry'])
                output.append((test['projectName'],spec['title']))
        for child in suite.get('suites',[]): walk(child)
    walk(document)
    assert len(output) == len(set(output)) == 8
    assert {profile for profile,title in output} == {'chromium','mobile-chromium'}
    assert len([title for profile,title in output if '1000-entry' in title]) == 4
    if passed:
        assert document.get('errors',[]) == []
        assert document['stats']['expected'] == 8
        for field in ('skipped','unexpected','flaky'): strict_zero(document['stats'][field])
    return output


def validate_terminal_metadata(proof,status,launch,acceptance):
    strict_zero(proof['actual_runner_wait_exit'])
    assert proof['candidate'] == HEAD
    assert proof['all8_single_attempt_cases_passed'] is True
    assert proof['complete_source_method_cleanup_raw_verified'] is True
    assert proof['actual_transport_terminal'] is True
    assert proof['transport_identity_complete'] is True
    assert proof['source_count'] == 1130 and proof['method_count'] == 51
    assert proof['source_compact_digest'] == SOURCE and proof['method_digest'] == METHOD
    strict_zero(proof['skips_failures_flakes_retries'])
    assert status['terminal'] is True and status['state'] == 'TERMINAL'
    assert status['identity_complete'] is True
    assert status.get('runner_identity_error') is None and status.get('error') is None
    strict_zero(status['actual_runner_returncode'])
    assert status['finished']['monotonic_ns'] >= status['started']['monotonic_ns']
    assert launch['candidate'] == HEAD and launch['accepted'] is True
    strict_zero(launch['actual_launcher_exit'])
    assert launch['positive_PID_start_command_group_session_parent_verified'] is True
    assert launch['transport_identity_complete'] is True
    assert acceptance['accepted'] is True
    assert status['reservation_id'] == launch['reservation_id'] == acceptance['reservation_id']
    expected = {'supervisor':(4082928,'183989474'),'runner_identity':(4082929,'183989478')}
    keys = ('pid','start_token','pgid','session','command')
    for role,(pid,token) in expected.items():
        item = status[role]
        assert type(item['pid']) is int and item['pid'] == pid and item['start_token'] == token
        assert item['pgid'] == item['session'] == 4082928
        launch_role = 'supervisor_identity' if role == 'supervisor' else role
        assert all(launch[launch_role][key] == item[key] for key in keys)
    assert status['runner_pid'] == status['runner_identity']['pid']
    assert status['runner_identity']['ppid'] == launch['runner_PPID'] == 4082928
    assert status['runner_command'] == status['runner_identity']['command'] == [
        str(ROOT/'.venv/bin/python'),'-B',str(BASE/'runner.py'),'execute']
    assert status['supervisor']['command'] == [str(ROOT/'.venv/bin/python'),'-B',
        str(BASE/'supervisor.py'),'supervise',status['reservation_id']]
    assert acceptance['supervisor_pid'] == 4082928
    assert all(acceptance['supervisor_identity'][key] == status['supervisor'][key] for key in keys)
    observed = [item for item in status['runner_identity_observations'] if item['event'] == 'observed']
    assert len(observed) == 1
    assert all(observed[0]['actual'][key] == status['runner_identity'][key] for key in keys)
    assert observed[0]['kernel']['ppid'] == 4082928
    return expected


def terminal_identity(proof):
    status = load(BASE/'transport-status.json')
    assert sha(BASE/'transport-status.json') == proof['transport_status_sha256']
    launch = load(BASE/'actual-enclosing-root-launch.json')
    acceptance = load(BASE/'transport-launch.json')
    expected = validate_terminal_metadata(proof,status,launch,acceptance)
    assert launch['GO_sha256'] == sha(BASE/'go.json')
    both=set(); rows=errors=terminal_rows=0
    for row in jsonl(BASE/'primary-live-observations.jsonl'):
        rows+=1
        assert row['transport_identity_complete'] is True
        identities=row.get('positive_same_process_identities',{})
        for role,(pid,token) in expected.items():
            item=identities.get(role,{})
            if isinstance(item,dict) and item.get('live') is True:
                assert item['pid']==pid and item['start_token']==token
        if all(isinstance(identities.get(role),dict) and identities[role].get('live') is True for role in expected):
            both.add(row['recorded_utc'])
        if row['terminal'] is True:
            assert row['state']=='TERMINAL'
            strict_zero(row['actual_runner_returncode']);terminal_rows+=1
        errors+=int('observation_error' in row or any('observation_error' in value
                    for value in identities.values() if isinstance(value,dict)))
    assert len(both)>=2 and terminal_rows==1
    return {'original_state':status['state'],'original_identity_complete':True,
            'actual_runner_returncode':0,'source_and_candidate_binding_verified':True,
            'primary_observation_rows':rows,'both_positive_distinct_observations':len(both),
            'terminal_observation_rows':terminal_rows,'unavailable_observation_rows':errors,
            'same_original_PID_start_parent_argv_group_session_verified':True,
            'limits':'Discrete positive observations, not continuous sampling. Terminal missing process handles are retained as unavailable observations; actual wait is independent.'}


def source_and_raw_guards(runtime):
    assert runtime['complete'] is True and runtime['runner_observation_complete'] is True
    strict_zero(runtime['exit_code'])
    assert runtime['qualification_status'] == 'ORDINARY_COMPLETION' and not runtime['interrupted']
    assert runtime['source_before'] == runtime['source_after'] == load(BASE/'expected-sources.json')
    assert runtime['methods_before'] == runtime['methods_after'] == load(BASE/'expected-methods.json')
    sources,methods = runtime['source_before'],runtime['methods_before']
    assert len(sources) == 1130 and len(methods) == 51
    assert hashlib.sha256(json.dumps(sources,sort_keys=True,separators=(',',':')).encode()).hexdigest() == SOURCE
    assert hashlib.sha256(json.dumps(methods,sort_keys=True).encode()).hexdigest() == METHOD
    assert all(sources[name] == value for name,value in methods.items())
    assert runtime['authoritative_HEAD_before']['commit'] == runtime['authoritative_HEAD_after']['commit'] == HEAD
    assert runtime['binding']['HEAD'] == HEAD and runtime['binding']['environment_overrides']['NEISTRA_PERFORMANCE'] == '0'
    command = runtime['binding']['command']
    assert '--retries=0' in command and '--workers=1' in command and '--max-failures=1' in command
    assert not any(arg in command for arg in ('--grep','--project','--config'))
    assert runtime['binding']['selected_cases'] == 8 and runtime['binding']['bulk_1000_entry_cohorts'] == 4
    prepared = load(BASE/'prepared.json'); go = load(BASE/'go.json')
    assert prepared['binding'] == go['binding'] == runtime['binding'] and go['authorized'] is True
    assert go['prepared_sha256'] == sha(BASE/'prepared.json')
    assert sha(BASE/'runner.py') == runtime['binding']['runner_sha256']
    assert sha(BASE/'source_guard.py') == runtime['binding']['guard_sha256']
    for name in ('source-preparation.zip','source-after.zip'):
        fingerprint(BASE/name)
        with zipfile.ZipFile(BASE/name) as archive:
            assert archive.testzip() is None
            assert len(archive.namelist()) == len(sources) and set(archive.namelist()) == set(sources)
            assert all(hashlib.sha256(archive.read(path)).hexdigest() == digest for path,digest in sources.items())
    cleanup = runtime['cleanup']; raw = runtime['database_byte_archive']
    assert cleanup == load(BASE/'cleanup-before-store-archive.json') and cleanup['complete'] is True
    assert cleanup['positively_owned_processes_remaining'] == []
    assert set(cleanup['ports_unused']) == {'8530','8531','5530'} and all(cleanup['ports_unused'].values())
    assert runtime['database_byte_archive_error'] is None and runtime['complete_source_guard_error'] is None
    assert raw == load(BASE/'database-byte-archive.json') and raw['originals_retained'] is True
    assert raw['started_monotonic_ns'] >= cleanup['monotonic_ns']
    assert runtime['canonical_database_exists'] is True and runtime['legacy_database_exists'] is False
    for name,item in raw['files'].items():
        original = WORKSPACE/'e2e'/name
        assert type(item['exists']) is bool
        if item['exists']:
            copy_path = path_checked(item['copy'])
            assert copy_path == BASE/'post-cleanup-database-bytes'/name
            expected = {key:item[key] for key in ('bytes','sha256')}
            assert fingerprint(copy_path) == fingerprint(original) == expected
        else: assert not original.exists()
    assert raw['files']['neistra.db']['exists'] is True
    assert sha(BASE/'raw.log') == runtime['raw_log_sha256']
    assert runtime['resource_observer']['complete'] is True and runtime['resource_observer_alive'] is False
    assert runtime['worker_trace_exists'] is True and runtime['worker_trace_incomplete'] is False
    trace = WORKSPACE/'e2e/qualification/worker-turns.jsonl'
    trace_fp = fingerprint(trace); assert trace_fp['bytes'] <= 128*1024*1024
    count = max_turn = 0; header = None
    for row in jsonl(trace):
        count += 1; assert row['record'] == count
        if count == 1:
            header = row; assert row['event'] == 'header' and row['format_version'] == 1
        if row['turn'] is not None: max_turn = max(max_turn,row['turn'])
    assert count <= 200_000 and max_turn <= 100_000 and header
    inventory = load(trace.parent/header['sources'])
    assert hashlib.sha256(json.dumps(inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest() == header['source_digest']
    assert len(inventory) == header['source_count']
    assert all(sources.get(name) == digest for name,digest in inventory.items())
    return {'full_source_ZIPs_all1130_CRC_and_exact_union_verified':True,
            'closed_raw_DB_WAL_SHM_receipts_originals_and_copies_exact':True,
            'worker_trace':{**trace_fp,'records':count,'max_turn':max_turn,'source_inventory_count':len(inventory)},
            'SQL_opened':False}


def renewal_traffic(data):
    owners = {row['id']:row for row in data['owners']}
    updates = data['consumerUpdates']; groups = collections.defaultdict(list)
    for row in updates:
        assert row['owner'] in owners and row['status'] == 200
        assert row['kind'] in {'allocate','demand','same-sequence-heartbeat'}
        groups[row['kind']].append(row)
    assert len(owners) == 5 and len(groups['allocate']) == len(groups['demand']) == 5
    assert {row['owner'] for row in groups['allocate']} == {row['owner'] for row in groups['demand']} == set(owners)
    assert all(row['sequence'] == 0 and row['entries'] == 0 for row in groups['allocate'])
    assert all(row['sequence'] == 1 and row['entries'] == 200 for row in groups['demand'])
    heartbeat = groups['same-sequence-heartbeat']
    assert len(heartbeat) <= 5*math.ceil(1_200_000/20_000)
    by_owner = collections.defaultdict(list); body_sizes = []
    previous_response = None
    latest = {row['owner']:row['at']+row['elapsedMs'] for row in groups['demand']}
    for row in heartbeat:
        assert row['sequence'] == 1 and row['entries'] == 200
        assert row['responseAt'] >= row['at'] and row['elapsedMs'] == row['responseAt']-row['at']
        assert row['at']-latest[row['owner']] >= 20_000
        if previous_response is not None: assert row['at'] >= previous_response
        previous_response = row['responseAt']; latest[row['owner']] = row['responseAt']
        assert isinstance(row['responseBody'],str)
        decoded = json.loads(row['responseBody'])
        assert row['expiresAt'] == decoded['expires_at']
        datetime.datetime.fromisoformat(row['expiresAt'].replace('Z','+00:00'))
        body_sizes.append(len(row['responseBody'].encode('utf-8')))
        by_owner[row['owner']].append(row)
    assert all(len(rows) <= math.ceil(1_200_000/20_000) for rows in by_owner.values())
    return {'all_consumer_updates':len(updates),'kinds':dict(collections.Counter(row['kind'] for row in updates)),
            'heartbeat_calls':len(heartbeat),'cadence_derived_per_case_count_cap':300,
            'heartbeat_count_per_owner':{owner:len(by_owner[owner]) for owner in owners},
            'heartbeat_header_response_ms':dist([row['elapsedMs'] for row in heartbeat]) if heartbeat else None,
            'heartbeat_full_response_body_UTF8_bytes':dist(body_sizes) if body_sizes else None,'heartbeat_full_response_body_UTF8_bytes_total':sum(body_sizes),
            'heartbeat_requests_overlap_in_recorded_header_intervals':False,'same_sequence_payload_entries':200,
            'scope':'Independent serial20s maintenance traffic is included in actual workload. Full response strings are preserved; responseAt is before text/JSON consumption, so body-read/parse latency is not separately timestamped. Count cap is derived from the unchanged20min case deadline and20s cadence, not a new performance target.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-proof',required=True,type=Path)
    args = parser.parse_args()
    for name in ('assessment.json','comparison-samples.json','input-identities.json'):
        assert not (OUT/name).exists(), 'Preserve previous analysis; do not overwrite reports'
    # No current metrics/observer/resource/store is read before this real proof
    # and independently verified normal terminal metadata checks succeed.
    proof = load(args.terminal_proof)
    strict_zero(proof['actual_runner_wait_exit'])
    assert proof['all8_single_attempt_cases_passed'] is True
    assert proof['complete_source_method_cleanup_raw_verified'] is True
    identity = terminal_identity(proof)
    assert sha(BASE/'actual-receipt.json') == proof['runner_receipt_sha256']
    assert sha(BASE/'browser.json') == proof['browser_report_sha256']
    runtime = load(BASE/'actual-receipt.json'); browser = load(BASE/'browser.json')
    results = browser_cases(browser,passed=True)
    assert sorted(results) == sorted(browser_cases(load(BASE/'collection.json'),passed=False))
    raw_proof = source_and_raw_guards(runtime)
    root = {'HEAD':HEAD,'completed_case_metrics':[]}
    directories = runtime['new_harness_directories']
    assert len(directories) == len(set(directories)) == 8
    for directory in directories:
        case = Path(directory)
        assert case.parent == BASE.parent and case.is_dir() and not case.is_symlink()
        paths = list(case.glob('native-*-performance.json'))
        assert len(paths) == 1
        root['completed_case_metrics'].append({'path':str(paths[0])})
    inputs = INPUTS
    exact_inputs = {}
    edits={};cancellations=[];bulks=[];observers=[];targets=collections.defaultdict(list);allcold=[];allwarm=[];cold_compares=[]
    for item in root["completed_case_metrics"]:
     path=Path(item["path"]);assert path.is_relative_to(ROOT)
     case=path.parent;data=load(path);obs=load(case/"worker-observation.json");assert data.get("failures",[])==[]
     assert obs["complete"] and obs["sources_unchanged"] and obs["sources_before"]==obs["sources_after"]
     assert all(runtime["source_before"].get(n)==h for n,h in obs["sources_before"].items())
     assert obs["max_running_property_jobs"]<=1
     retained=obs["retained"];assert retained["content_bytes"]<=16*1024*1024 and retained["ligand_property_content"]<=2048 and retained["ligand_property_proofs"]<=4096 and retained["ligand_property_executions"]<=33
     for name in [path.name,"worker-observation.json","work-order-observed.jsonl","observer.stop","observer.log"]:
      f=case/name
      if f.is_file():inputs[str(f.relative_to(ROOT))]={"bytes":f.stat().st_size,"sha256":sha(f)}
     tracepath=case/"work-order-observed.jsonl"
     assert sha(tracepath)==obs["work_order"]["observed_sha256"] and obs["work_order"]["complete"]
     for target in data["targets"]:
      assert target["enforced"] is False and math.isfinite(target["actual"]) and target["actual"]>=0
      assert target["withinTarget"]==(target["actual"]<=target["limit"])
      targets[target["label"]].append(target)
     private=[j for j in obs["jobs"].values() if j.get("execution_id")];completed=[j for j in private if j["status"]=="completed"]
     maxima={"capture_verified_bytes":0,"capture_source_reads":0,"capture_byte_cap":0,"publication_verified_bytes":0,"publication_reads":0,"publication_byte_cap":0,"materialized_verified_bytes":0,"envelope_bytes":0,"batch_sources":0,"child_stage_capture_bytes":0}
     totals={"capture_verified_bytes":0,"capture_source_reads":0,"publication_verified_bytes":0,"publication_reads":0,"materialized_verified_bytes":0}
     for job in completed:
      p=job["provenance"];cap=p["source_capture"];pub=p["publication_verification"];material=p["input_materialization"]
      assert cap["coordinator_native_preparations"]==0 and 0<cap["source_proofs"]<=8 and cap["verified_bytes"]<=64*1024*1024 and cap["source_read_calls"]<=16 and cap["source_read_byte_cap"]<=64*1024*1024+16
      assert pub["verified_bytes"]<=64*1024*1024 and pub["source_reads"]<=16 and pub["read_byte_cap"]<=64*1024*1024+16
      assert material["verified_bytes"]<=64*1024*1024 and material["envelope_bytes"]<=96*1024*1024
      stages=job["result_values"]["stage_timings"];assert 0<len(stages)<=8
      assert all(stage["capture_bytes"]>0 and stage["capture_bytes"]<=96*1024*1024 for stage in stages)
      assert all(all(math.isfinite(stage[k]) and stage[k]>=0 for k in ("raw_proof_seconds","prepare_seconds","calculate_seconds")) for stage in stages)
      assert all(job["reaped"] for job in completed)
      vals={"capture_verified_bytes":cap["verified_bytes"],"capture_source_reads":cap["source_read_calls"],"capture_byte_cap":cap["source_read_byte_cap"],"publication_verified_bytes":pub["verified_bytes"],"publication_reads":pub["source_reads"],"publication_byte_cap":pub["read_byte_cap"],"materialized_verified_bytes":material["verified_bytes"],"envelope_bytes":material["envelope_bytes"],"batch_sources":cap["source_proofs"],"child_stage_capture_bytes":max(x["capture_bytes"] for x in stages)}
      for k,v in vals.items():maxima[k]=max(maxima[k],v)
      for k in totals:totals[k]+=vals[k]
     observer={"case":str(case.relative_to(ROOT)),"samples":obs["samples"],"observed_jobs":len(obs["jobs"]),"private_jobs_observed":len(private),"completed_private_jobs":len(completed),"private_statuses":dict(collections.Counter(j["status"] for j in private)),"completed_private_all_reaped":all(j["reaped"] for j in completed),"max_running_property_jobs":obs["max_running_property_jobs"],"retained_at_case_close":retained,"peak_child_rss_bytes":max(obs.get("peak_child_rss_bytes",{}).values(),default=0),"peak_worker_parent_rss_bytes":max(obs.get("peak_worker_parent_rss_bytes",{}).values(),default=0),"per_completed_private_job_maxima":maxima,"per_case_observed_job_totals":totals}
     observers.append(observer)
     if "edit-performance" in path.name:
      pairs=[r for r in data["records"] if r["kind"]=="paired-edit"];prefix=[r for r in data["records"] if r["kind"]=="fresh-browser-context-cold-start"]
      assert len(pairs)==20 and len(prefix)==5 and len(data["pageClocks"])==25
      assert all(r["matchingQualifiedResultReadyBeforeViewOpen"] and r["warmNewJobs"]==0 for r in pairs)
      profile=data["profile"]
      exact_inputs[profile]=[(r["index"],r["heavyAtoms"],r["firstInputHash"],r["changedInputHash"]) for r in pairs]
      entry={"path":str(path.relative_to(ROOT)),"cold_edit_ms":dist([r["cold"]["networkCurrentMs"] for r in pairs],2000),"cold_context_first_five_network_ms":dist([r["timing"]["networkCurrentMs"] for r in prefix],2000),"cold_context_first_five_visible_ms":data["coldStarts"],"warm_visible_including_command_and_view_open_ms":dist([r["warm"]["currentMs"] for r in pairs]),"warm_automatic_READY_ms":dist([r["warm"]["networkCurrentMs"] for r in pairs]),"matching_cache_projection_ms":dist([r["cachedProjectionMs"] for r in pairs],100),"cold_click_feedback_ms":dist([r["cold"]["feedbackMs"] for r in pairs],100),"warm_click_feedback_ms":dist([r["warm"]["feedbackMs"] for r in pairs],100),"warm_new_jobs":sum(r["warmNewJobs"] for r in pairs),"page_clock_count":len(data["pageClocks"])}
      if profile.startswith("mobile"):
       assert all(r["warm"]["presentationOpened"]>r["warmAutomaticReady"]["observedAt"] for r in pairs)
       entry["mobile_deliberate_presentation_open_after_READY_ms"]=dist([r["warm"]["presentationOpened"]-r["warmAutomaticReady"]["observedAt"] for r in pairs])
      edits[profile]=entry;allcold.extend(r["cold"]["networkCurrentMs"] for r in pairs);allwarm.extend(r["cachedProjectionMs"] for r in pairs)
      for pair in pairs:
       s=pair["changedSource"];req=[q for q in pair["requests"] if q.get("sources")==[s] and pair["cold"]["started"]<=q["at"]<=pair["automaticReady"]["requestAt"]]
       warmreq=[q for q in pair["requests"] if q.get("sources")==[pair["oldSource"]] and pair["warm"]["started"]<=q["at"]<=pair["warmAutomaticReady"]["requestAt"]]
       cold_compares.append({"warm_exact_source_READs":sum(q["method"]=="POST" and q["path"].endswith("/read") for q in warmreq),"warm_exact_source_demand_PUTs":sum(q["method"]=="PUT" for q in warmreq),"profile":profile,"index":pair["index"],"heavy_atoms":pair["heavyAtoms"],"cold_ms":pair["cold"]["networkCurrentMs"],"matching_cache_projection_ms":pair["cachedProjectionMs"],"cold_feedback_ms":pair["cold"]["feedbackMs"],"warm_feedback_ms":pair["warm"]["feedbackMs"],"exact_changed_source_READs":sum(q["method"]=="POST" and q["path"].endswith("/read") for q in req),"exact_changed_source_demand_PUTs":sum(q["method"]=="PUT" for q in req),"warm_new_jobs":pair["warmNewJobs"]})
     elif "cancellation" in path.name:
      assert sum(q["method"]=="PUT" for q in data["requests"])==1
      cancellations.append({"profile":data["profile"],"path":str(path.relative_to(ROOT)),"feedback_ms":data["cancellation"]["currentMs"],"recorded_pre_Retry_requests":len(data["requests"]),"recorded_pre_Retry_demand_PUTs":1,"source":data["source"],"scope":data["scope"],"functional_evidence":"Actual passing case asserts accepted late reply stays cancelled after reopen/quiet period and explicitRetry subsequently works; not worker-kill latency."})
     else:
      assert data["hardWorkOrderStatus"]=="passed" and data["readyCount"]==1000 and len(data["finalBindings"])==1000
      assert len(data["owners"])==5 and all(x["entries"]==200 for x in data["owners"])
      assert all(x["entries"]==200 and x["status"]==200 for x in data["aggregateReads"])
      assert data["qualifiedDistinctInputHashes"]==(1 if data["kind"]=="repeated" else 1000)
      hard=data["hardWorkOrder"];assert hard["ordinary"]["productiveDerivedTurnsBeforeClaim"]<=4 and len(hard["active"]["productiveBulkFairnessTurnsBeforeAdmission"])<=1
      assert hard["active"]["source"]==data["changedSource"] and hard["active"]["inputHash"]==data["changedInputHash"]
      if data["kind"]=="distinct":assert hard["active"]["priorityOverlapExercised"]
      assert hard["trace"]["sha256"]==sha(tracepath)
      trace=list(jsonl(tracepath));byid={r["record"]:r for r in trace}
      actor=hard["active"];bind=byid[actor["publicationRecord"]];mat=byid[actor["admissionRecord"]];seen=byid[actor["observedRecord"]]
      assert bind["event"]=="bind_return" and bind["input_hash"]==data["changedInputHash"]
      turnend=next(r for r in trace if r["event"]=="turn_end" and r["turn"]==bind["turn"]);assert turnend["worked"]
      s=data["changedSource"];current=[q for q in data["activeRequests"] if q.get("sources")==[s]];demand=next(q for q in current if q["method"]=="PUT");reads=[q for q in current if q["method"]=="POST" and q["path"].endswith("/read")];ready=reads[-1]
      assert ready["results"][0]["status"]=="ready" and ready["results"][0]["inputHash"]==data["changedInputHash"]
      ack=next(q for q in data["activeRequests"] if q["path"].endswith("/model-edits"));active=data["active"];origin=active["timeOrigin"]
      assert all(q["timeOrigin"]==origin for q in current)
      stage={"click_to_ACK_ms":ack["finished"]-active["started"],"ACK_to_first_current_READ_ms":reads[0]["at"]-ack["finished"],"first_current_READ_http_ms":reads[0]["finished"]-reads[0]["at"],"demand_http_ms":demand["finished"]-demand["at"],"demand_response_to_final_READY_READ_start_ms":ready["at"]-demand["finished"],"demand_response_to_successful_turn_end_ms":turnend["epoch_us"]/1000-origin-demand["finished"],"publication_to_READY_READ_start_lower_ms":origin+ready["at"]-turnend["epoch_us"]/1000,"publication_to_READY_READ_start_upper_ms":origin+ready["at"]-bind["epoch_us"]/1000,"active_owner_observed_to_materialize_return_ms":(mat["epoch_us"]-seen["epoch_us"])/1000}
      pending_gaps=[{"status":q["results"][0]["status"],"READ_start_after_demand_response_ms":q["at"]-demand["finished"],"http_ms":q["finished"]-q["at"]} for q in reads[1:]]
      bulks.append({"profile":data["profile"],"kind":data["kind"],"path":str(path.relative_to(ROOT)),"active_READY_ms":active["networkCurrentMs"],"target_ms":5000,"target_missed":active["networkCurrentMs"]>5000,"click_feedback_ms":active["feedbackMs"],"visible_including_presentation_ms":active["currentMs"],"hard_work_order_passed":True,"ordinary_productive_derived_turns_before_claim":hard["ordinary"]["productiveDerivedTurnsBeforeClaim"],"ordinary_warm_progress_turns":hard["ordinary"]["warmProgressTurnsBeforeClaim"],"productive_bulk_fairness_turns_before_active_admission":len(hard["active"]["productiveBulkFairnessTurnsBeforeAdmission"]),"post_acceptance_bulk_bindings":hard["active"]["actualPostAcceptanceBulkBindings"],"priority_overlap_exercised":hard["active"]["priorityOverlapExercised"],"ready_bulk_entries":1000,"distinct_qualified_input_hashes":data["qualifiedDistinctInputHashes"],"bulk_owner_count":5,"bulk_owner_entries":200,"aggregate_READ_calls":len(data["aggregateReads"]),"aggregate_READ_entry_operations":sum(q["entries"] for q in data["aggregateReads"]),"aggregate_READ_http_ms":dist([q["elapsedMs"] for q in data["aggregateReads"]]),"consumer_update_calls":len(data["consumerUpdates"]),"consumer_update_kinds":dict(collections.Counter(q["kind"] for q in data["consumerUpdates"])),"all_App_requests":len(data["allAppRequests"]),"App_changed_source_READs":len(reads),"App_changed_source_demand_PUTs":1,"post_demand_READ_sequence":pending_gaps,"observed_jobs":len(data["actualOrder"]),"observed_private_jobs":sum(bool(q["execution_id"]) for q in data["actualOrder"]),"private_job_count_limit":129,"private_jobs_all_reaped":all(q["reaped"] for q in data["actualOrder"] if q["execution_id"]),"phase_metrics_ms":stage,"retained_at_close":retained})
      assert sum(bool(q["execution_id"]) for q in data["actualOrder"])<=129
      assert all(q["reaped"] for q in data["actualOrder"] if q["execution_id"])
      bulks[-1]["renewal_traffic"]=renewal_traffic(data)
      bulks[-1]["changed_input_hash"]=data["changedInputHash"]

    assert set(edits)=={'chromium','mobile-chromium'}
    assert len(allcold)==len(allwarm)==40 and len(cancellations)==2 and len(bulks)==4
    assert {row['profile'] for row in cancellations}==set(edits)
    assert {(row['profile'],row['kind']) for row in bulks}=={
        (profile,kind) for profile in edits for kind in ('repeated','distinct')}
    job_children=set()
    for case in observers:
        saved=load(ROOT/case['case']/'worker-observation.json')
        job_children.update((job.get('child_pid'),str(job.get('child_start_token')))
            for job in saved['jobs'].values() if job.get('child_pid') and job.get('child_start_token'))
    resource_file=BASE/'owned-resource-samples.jsonl'; resource_count=0
    load_values=[]; rss_peaks=collections.defaultdict(int); cpus={}; complete_totals=[]
    missing_rss=missing_cpu=0
    for row in jsonl(resource_file):
        resource_count+=1;load_values.append(row['load_average'][0])
        if all('rss_bytes' in process for process in row['owned']):
            complete_totals.append(sum(process['rss_bytes'] for process in row['owned']))
        for process in row['owned']:
            command=process['command'];key=(process['pid'],process['start_token'])
            if key in job_children:role='positively_joined_property_child'
            elif 'tests.support.ligand_property_performance_qualification' in command and 'worker' in command:role='worker'
            elif 'tests.support.ligand_property_performance_qualification' in command and 'observe' in command:role='test_observer'
            elif 'tests.support.ligand_property_performance_qualification' in command and 'fixture-preflight' in command:role='fixture_preflight'
            elif 'neistra_api.main:app' in command:role='API'
            elif any('vite/bin/vite.js' in item or '/esbuild' in item for item in command):role='web_dev_server'
            elif any('playwright/' in item or '@playwright/test/cli.js' in item for item in command):role='playwright_harness'
            else:role='unclassified_owned_helper'
            if 'rss_bytes' in process:rss_peaks[role]=max(rss_peaks[role],process['rss_bytes'])
            else:missing_rss+=1
            if 'user_cpu_ticks' in process and 'system_cpu_ticks' in process:
                ticks=process['user_cpu_ticks']+process['system_cpu_ticks']
                saved=cpus.setdefault(key,{'min':ticks,'max':ticks,'role':role})
                saved['min']=min(saved['min'],ticks);saved['max']=max(saved['max'],ticks)
            else:missing_cpu+=1
    assert type(runtime['resource_observer']['records']) is int
    assert resource_count==runtime['resource_observer']['records'] and 0<resource_count<=200_000
    resource_fp=fingerprint(resource_file)
    assert resource_fp['bytes']==runtime['resource_observer']['bytes'] and resource_fp['bytes']<=128*1024*1024
    resource={'saved_wrapper_samples':resource_count,'saved_wrapper_bytes':resource_fp['bytes'],
        'one_minute_load_during_saved_samples':dist(load_values),
        'max_complete_sample_owned_total_RSS_bytes':max(complete_totals) if complete_totals else None,
        'max_sampled_per_process_RSS_by_role_bytes':dict(rss_peaks),
        'unavailable_RSS_measurements':missing_rss,'unavailable_CPU_measurements':missing_cpu,
        'sampled_CPU_seconds_by_role':{role:sum(value['max']-value['min'] for value in cpus.values()
            if value['role']==role)/runtime['host_before']['clock_ticks_per_second'] for role in {value['role'] for value in cpus.values()}},
        'scope':'Saved PID/starttoken joined sample deltas only; incomplete browser/GPU/short-lived process accounting. Missing observations are unavailable, not zero CPU/RSS. Case-close retention is not an every-instant memory ceiling.'}
    combined={'all40_cold_actual_edits_ms':dist(allcold,2000),
        'all40_matching_cache_projection_ms':dist(allwarm,100),
        'cancellation_feedback_ms':dist([row['feedback_ms'] for row in cancellations],100),
        'four_bulk_active_ms':dist([row['active_READY_ms'] for row in bulks],5000),
        'four_bulk_click_feedback_ms':dist([row['click_feedback_ms'] for row in bulks],100)}
    alltargets={label:{**dist([item['actual'] for item in values],values[0]['limit']),'enforced':False}
                for label,values in targets.items()}
    baseline_root=load(BASELINE/'actual-enclosing-root.json')
    baseline_runtime=load(BASELINE/'actual-receipt.json')
    strict_zero(baseline_runtime['exit_code'])
    assert baseline_root['all8single_attempt_cases_passed'] is True
    assert sha(BASELINE/'actual-receipt.json')==baseline_root['actual_receipt_sha256']
    assert sha(BASELINE/'browser.json')==baseline_root['browser_report_sha256']
    assert sorted(browser_cases(load(BASELINE/'browser.json'),passed=True))==sorted(results)
    assert baseline_runtime['source_before']==baseline_runtime['source_after']
    assert baseline_runtime['methods_before']==baseline_runtime['methods_after']
    assert len(baseline_runtime['source_before'])==1125 and len(baseline_runtime['methods_before'])==49
    previous_methods=baseline_runtime['methods_before'];current_methods=runtime['methods_before']
    assert set(current_methods)-set(previous_methods)=={'tests/e2e/support/consumer-heartbeat.ts','tests/e2e/support/bulk-property-validation.ts'}
    assert {name for name in previous_methods if current_methods[name]!=previous_methods[name]}=={'tests/e2e/ligand-properties-performance.spec.ts'}
    baseline_pairs={};baseline_bulk={}
    for item in baseline_root['completed_case_metrics']:
        data=load(item['path'])
        if 'records' in data:
            baseline_pairs[data['profile']]=[(row['index'],row['heavyAtoms'],row['firstInputHash'],row['changedInputHash'])
                for row in data['records'] if row['kind']=='paired-edit']
        elif 'kind' in data:baseline_bulk[(data['profile'],data['kind'])]=data['changedInputHash']
    assert baseline_pairs==exact_inputs
    assert all(row['changed_input_hash']==baseline_bulk[(row['profile'],row['kind'])] for row in bulks)
    baseline_summary=load(ROOT/'.issue-11-evidence/issue159-all8-baseline-assessment1/baseline-measurements.json')
    assert baseline_summary['workflow_passes']==8 and baseline_summary['source_count']==1125 and baseline_summary['method_count']==49
    baseline_inputs=load(ROOT/'.issue-11-evidence/issue159-all8-baseline-assessment1/input-identities.json')
    for path,expected in baseline_inputs.items():assert fingerprint(ROOT/path)==expected
    summary={'scope':'Closed completeALL8 portable metadata assessment only; not final feature/release acceptance',
        'candidate':HEAD,'workflow_cases':results,'workflow_passes':8,'skips_failures_flakes_retries':0,
        'source_count':1130,'method_count':51,'source_digest_compact':SOURCE,'method_digest_spaced':METHOD,
        'source_raw_guards':raw_proof,'transport_identity':identity,
        'combined':combined,'profiles':edits,'cancellations':cancellations,'bulk_cases':bulks,
        'all_timing_annotation_groups':alltargets,'closed_observers':observers,'saved_resources':resource,
        'host_before':runtime['host_before'],'host_after':runtime['host_after'],
        'descriptive_baseline_comparison':{'baseline_candidate':baseline_root['HEAD'],
            'baseline_source_count':1125,'baseline_method_count':49,'baseline_combined':baseline_summary['combined'],
            'baseline_host_before':baseline_runtime['host_before'],'baseline_host_after':baseline_runtime['host_after'],
            'baseline_saved_resources':baseline_summary['saved_resources'],
            'all40_initial_changed_scientific_hash_pairs_and4bulk_changed_hashes_equal':True,
            'method_change':'Old spec changed; independent heartbeat and pure complete-batch validator dependencies added;48other original methods unchanged. Additional renewal/full-body work and reduced matcher reporting included. Scientific predicates remain complete; method identity differs.',
            'limits':'One observation per source revision on a shared host; descriptive only. No controlled A/B, causal speedup/regression, same-method or strict-reference timing certification.'},
        'policy':'D148 retains100ms feedback/cache,2000ms cold and5000ms bulk targets/misses; portable work/resource/scientific/cancellation/deadline bounds mandatory. Absolute targets are opt-in strict reference-host qualification.',
        'no_SQL_apps_services_browser_profile_or_chemistry_execution':True,
        'final_feature_release_qualification':False}
    # Recheck all consumed closed inputs before writing any success analysis.
    for path,expected in list(INPUTS.items()):
        actual=Path(path) if Path(path).is_absolute() else ROOT/path
        assert fingerprint(actual,register=False)==expected, f'Closed input drift: {actual}'
    outputs={'assessment.json':summary,'comparison-samples.json':{'cold_samples':cold_compares},
             'input-identities.json':dict(sorted(INPUTS.items()))}
    for name,value in outputs.items():
        with (OUT/name).open('x') as stream:
            json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'scope':summary['scope'],'candidate':HEAD,'workflow_passes':8,
                      'input_files':len(INPUTS),'combined':combined,'transport_original_state':identity['original_state']}))


if __name__=='__main__': main()

