"""Reproduce closed metadata controls without application or SQL execution."""
from pathlib import Path
import copy
import hashlib
import json
import runpy

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
ns=runpy.run_path(str(OUT/'analyze.py'),run_name='metadata_controls')
BASE=ROOT/'.issue-11-evidence/issue159-performance/native-probe11-all8'
subjects=[ROOT/'.issue-11-evidence/issue159-native11-primary-terminal-readback1/readback.json',BASE/'transport-status.json',BASE/'actual-enclosing-root-launch.json',BASE/'transport-launch.json']
actual=[json.loads(p.read_text()) for p in subjects]
validator=ns['validate_terminal_metadata']
validator(*actual)
mutations=[('boolean_wait',0,('actual_runner_wait_exit',),False),('float_wait',0,('actual_runner_wait_exit',),0.0),('failed_wait',0,('actual_runner_wait_exit',),1),('candidate_mismatch',0,('candidate',),'0'*40),('source_digest_mismatch',0,('source_compact_digest',),'0'*64),('method_digest_mismatch',0,('method_digest',),'0'*64),('source_count_mismatch',0,('source_count',),1128),('method_count_mismatch',0,('method_count',),50),('incomplete_raw',0,('complete_source_method_cleanup_raw_verified',),False),('not_all8',0,('all8_single_attempt_cases_passed',),False),('proof_identity_incomplete',0,('transport_identity_complete',),False),('terminal_error',1,('state',),'ERROR'),('not_terminal',1,('terminal',),False),('identity_incomplete',1,('identity_complete',),False),('boolean_actual_wait',1,('actual_runner_returncode',),False),('actual_failure',1,('actual_runner_returncode',),1),('reservation_mismatch',1,('reservation_id',),'other'),('runner_PID_changed',1,('runner_identity','pid'),1),('runner_start_changed',1,('runner_identity','start_token'),'replacement'),('runner_parent_changed',1,('runner_identity','ppid'),1),('runner_argv_changed',1,('runner_command',),['other']),('supervisor_session_changed',1,('supervisor','session'),1),('launcher_not_accepted',3,('accepted',),False)]
results=[{'name':'actual_normal_terminal_metadata','accepted':True}]
for name,index,path,value in mutations:
    changed=copy.deepcopy(actual)
    target=changed[index]
    for key in path[:-1]:target=target[key]
    target[path[-1]]=value
    try:validator(*changed)
    except (AssertionError,KeyError,TypeError,ValueError):results.append({'name':name,'rejected':True})
    else:raise AssertionError('Mutation incorrectly accepted: '+name)
proof={'scope':'Closed normal-terminal metadata controls; no metrics/SQL/apps/services/browser/chemistry execution','analyzer_sha256':hashlib.sha256((OUT/'analyze.py').read_bytes()).hexdigest(),'cases':results,'subjects':{str(p.relative_to(ROOT)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in subjects},'passed':len(results)}
assert proof==json.loads((OUT/'terminal-controls.json').read_text())
print(json.dumps({'controls_passed':len(results),'existing_results_exactly_reproduced':True,'analyzer_sha256':proof['analyzer_sha256']}))
