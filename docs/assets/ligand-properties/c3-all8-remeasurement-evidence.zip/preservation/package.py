"""Preserve the closed current eight-case run; no application, SQL or publication."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import runpy
import stat
import zipfile

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-159-live-ligand-properties')
OUT = ROOT / '.issue-11-evidence/issue159-native11-all8-packet1'
RUN = ROOT / '.issue-11-evidence/issue159-performance/native-probe11-all8'
TERMINAL = ROOT / '.issue-11-evidence/issue159-native11-primary-terminal-readback1'
HEAD = '995e80f8e59bac4265ecc7b70ced04277ecb7550'
TERMINAL_SHA = '6450117ebec48e2d82fa731560e636d1c9d549bd0b25a8ccf36135ba7958a320'


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def write(name, value):
    path = OUT / name
    with path.open('xb') as stream:
        stream.write(encoded(value))
    return path


def fingerprint(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def inventory(roots):
    files, directories, aliases, empty, counts = {}, {}, [], [], {}
    for label, root in roots.items():
        assert root.is_dir() and not root.is_symlink(), root
        count = total = 0
        for current, children, names in os.walk(root, followlinks=False):
            directory = Path(current)
            relative = directory.relative_to(root).as_posix()
            key = label if relative == '.' else f'{label}/{relative}'
            metadata = directory.lstat()
            directories[key] = {'mode': stat.S_IMODE(metadata.st_mode),
                                'uid': metadata.st_uid, 'gid': metadata.st_gid,
                                'mtime_ns': metadata.st_mtime_ns}
            for name in list(children):
                if (directory / name).is_symlink():
                    children.remove(name)
                    names.append(name)
            if not children and not names:
                empty.append(key)
            for name in sorted(names):
                path = directory / name
                key = f'{label}/{path.relative_to(root).as_posix()}'
                metadata = path.lstat()
                ownership = {'mode': stat.S_IMODE(metadata.st_mode), 'uid': metadata.st_uid,
                             'gid': metadata.st_gid, 'mtime_ns': metadata.st_mtime_ns,
                             'nlink': metadata.st_nlink}
                if stat.S_ISLNK(metadata.st_mode):
                    aliases.append({'path': key, 'target': os.readlink(path),
                                    'active': False, 'ownership': ownership})
                    continue
                assert stat.S_ISREG(metadata.st_mode), key
                value = fingerprint(path)
                files[key] = {**value, 'ownership': ownership}
                count += 1
                total += value['bytes']
        counts[label] = {'original_root': str(root), 'regular_files': count, 'bytes': total}
    return {'roots': counts, 'files': files, 'directories': directories,
            'empty_directories': sorted(empty), 'inert_alias_descriptions': aliases}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis-root', required=True, type=Path)
    parser.add_argument('--review-root', required=True, type=Path)
    args = parser.parse_args()
    terminal = json.loads((TERMINAL / 'readback.json').read_bytes())
    assert fingerprint(TERMINAL / 'readback.json')['sha256'] == TERMINAL_SHA
    assert type(terminal['actual_runner_wait_exit']) is int and terminal['actual_runner_wait_exit'] == 0
    assert terminal['all8_single_attempt_cases_passed'] is True
    assert terminal['complete_source_method_cleanup_raw_verified'] is True
    assert terminal['transport_identity_complete'] is True
    assert terminal['candidate'] == HEAD
    runtime = json.loads((RUN / 'actual-receipt.json').read_bytes())
    assert fingerprint(RUN / 'actual-receipt.json')['sha256'] == terminal['runner_receipt_sha256']
    assert fingerprint(RUN / 'browser.json')['sha256'] == terminal['browser_report_sha256']
    assert runtime['binding']['HEAD'] == HEAD
    assert runtime['source_before'] == runtime['source_after']
    assert runtime['methods_before'] == runtime['methods_after']
    sources, methods = runtime['source_before'], runtime['methods_after']
    assert len(sources) == 1130 and len(methods) == 51
    assert hashlib.sha256(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == terminal['source_compact_digest']
    assert hashlib.sha256(json.dumps(methods, sort_keys=True).encode()).hexdigest() == terminal['method_digest']
    assert all(fingerprint(ROOT / name)['sha256'] == digest for name, digest in sources.items())
    for filename in ('source-preparation.zip', 'source-after.zip'):
        with zipfile.ZipFile(RUN / filename) as archive:
            assert len(archive.namelist()) == len(sources)
            assert set(archive.namelist()) == set(sources)
            assert archive.testzip() is None
            for name, expected in sources.items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == expected, (filename, name)
    assert runtime['cleanup']['complete'] is True
    assert runtime['cleanup']['positively_owned_processes_remaining'] == []
    assert all(runtime['cleanup']['ports_unused'].values())
    for name, value in runtime['database_byte_archive']['files'].items():
        original = Path(runtime['workspace']) / 'e2e' / name
        if value['exists']:
            expected = {key: value[key] for key in ('bytes', 'sha256')}
            assert fingerprint(original) == fingerprint(Path(value['copy'])) == expected
        else:
            assert not original.exists()
    roots = {'raw-runner': RUN}
    harnesses = list(map(Path, runtime['new_harness_directories']))
    assert len(harnesses) == len(set(harnesses)) == 8
    for number, path in enumerate(harnesses, 1):
        roots[f'workflow-{number:02d}'] = path
    roots.update({
        'workspace': Path(runtime['workspace']),
        'primary-terminal': TERMINAL,
        'primary-prelaunch': ROOT / '.issue-11-evidence/issue159-native11-primary-readback1',
        'architecture-prelaunch': ROOT / '.issue-11-evidence/issue159-native11-architecture',
        'closed-analysis': args.analysis_root.absolute(),
        'performance-assessment': args.review_root.absolute(),
    })
    assert len(set(roots.values())) == len(roots)
    before = inventory(roots)
    write('input-inventory.json', before)
    print(json.dumps({'stage': 'inventory', 'roots': len(roots), 'files': len(before['files']),
                      'bytes': sum(row['bytes'] for row in before['files'].values())}), flush=True)
    context = {
        'scope': 'Closed current eight-case portable performance qualification; full candidate and merged release gates remain separate',
        'candidate': HEAD, 'actual_runner_wait_exit': 0,
        'all8workflow_cases_passed': True, 'skips_failures_flakes_retries': 0,
        'source_count': 1130, 'method_count': 51,
        'source_compact_digest': terminal['source_compact_digest'],
        'method_digest': terminal['method_digest'],
        'strict_reference_host_certification': False,
        'timing_policy': 'D148: retain original 100ms/2000ms/5000ms targets and every measured miss; portable correctness/work/resource bounds mandatory',
        'comparison_limit': 'Changed benchmark method and host conditions; no same-method or causal application speedup claim',
        'SQL_opened': False, 'all_originals_retained': True,
        'directories_and_aliases': 'All directories and inert alias descriptions in input-inventory.json; no active links emitted',
        'terminal_readback_sha256': TERMINAL_SHA,
        'created_utc': datetime.now(timezone.utc).isoformat(),
    }
    write('context.json', context)
    helper = ROOT / 'docs/assets/ligand-properties/release-evidence.py.txt'
    assert fingerprint(helper)['sha256'] == sources[helper.relative_to(ROOT).as_posix()]
    namespace = runpy.run_path(str(helper))
    items = {}
    for name in before['files']:
        label, relative = name.split('/', 1)
        items[name] = roots[label] / relative
    for name in ('input-inventory.json', 'context.json', 'package.py'):
        items[f'preservation/{name}'] = OUT / name
    archive_path = OUT / 'c3-all8-remeasurement-evidence.zip'
    packet = namespace['archive'](items, archive_path)
    with zipfile.ZipFile(archive_path) as archive:
        assert set(archive.namelist()) == set(items) | {'manifest.json'}
        for name, expected in before['files'].items():
            data = archive.read(name)
            assert len(data) == expected['bytes']
            assert hashlib.sha256(data).hexdigest() == expected['sha256'], name
    assert before == inventory(roots), 'Closed originals changed while packaging'
    verification = {
        'scope': context['scope'], 'candidate': HEAD,
        'input_roots': len(roots), 'input_regular_files': len(before['files']),
        'input_bytes': sum(row['bytes'] for row in before['files'].values()),
        'empty_directories': len(before['empty_directories']),
        'inert_alias_descriptions': len(before['inert_alias_descriptions']),
        'all_original_roots_unchanged': True,
        'all_regular_input_bodies_crc_and_exact_union_verified': True,
        'packet': packet,
        'publication_pending': True,
    }
    write('verification.json', verification)
    print(json.dumps(verification), flush=True)


if __name__ == '__main__':
    main()
