"""Reproduce the earlier qualification-only H-boundary findings from saved output."""
import json
from pathlib import Path
root = Path(__file__).resolve().parent
findings = []
for fixture in ["ordinary", "dense"]:
    receipt = json.loads((root / f"candidate-postopt-{fixture}-timing/receipt.json").read_text())
    for row in receipt["results"]:
        for phase in row["phases"]:
            state = phase["state"]
            if state["display"] != "ready" or state["shown"] != state["records"]:
                findings.append({
                    "fixture": fixture, "run": row["run"], "phase": phase["name"],
                    "status": state["display"], "shown": state["shown"],
                    "requested_records": state["records"],
                })
assert findings == [
    {"fixture": "ordinary", "run": 1, "phase": "hydrogenVisibility", "status": "pending", "shown": 0, "requested_records": 79},
    {"fixture": "dense", "run": 0, "phase": "hydrogenVisibility", "status": "pending", "shown": 0, "requested_records": 11970},
], findings
print(json.dumps({
    "scope": "External timing-recipe readiness diagnostics, not an established application defect",
    "findings": findings,
    "disposition": "Earlier H timings are diagnostic; final settled ordinary/dense pair explicitly checks requested H, current source generation and ready receipt/native groups.",
}, indent=2))
