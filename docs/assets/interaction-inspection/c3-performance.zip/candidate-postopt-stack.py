import os, subprocess, pathlib, time, json, signal, urllib.request, socket, sys, hashlib
root=pathlib.Path('/tmp/neistra152-c3-perf')
source=pathlib.Path('/datadisk/dev/neistra-worktrees/issue-152')
for port in [8240,8241,5394]:
 with socket.socket() as sock:
  sock.bind(('127.0.0.1',port))
env=dict(os.environ)
env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=':'.join(str(source/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src']), NEISTRA_DATA_DIR=str(root/'candidate-postopt-data'), NEISTRA_ENABLE_TEST_ROUTES='1', NEISTRA_JOB_WORKER_HEALTH_PORT='8241', VITE_API_TARGET='http://127.0.0.1:8240', NEISTRA_PERFORMANCE='0', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
python=str(source/'.venv/bin/python')
subprocess.run([python,'-m','alembic','upgrade','head'],cwd=source,env=env,check=True,stdout=(root/'candidate-postopt-migration.log').open('w'),stderr=subprocess.STDOUT)
commands=[
 ('api',[python,'-m','uvicorn','neistra_api.main:app','--host','127.0.0.1','--port','8240']),
 ('worker',[python,'-m','neistra_api.worker']),
 ('web',['node',str(source/'apps/web/node_modules/vite/bin/vite.js'),'--config','/tmp/neistra152-c3-perf/candidate.vite.config.mjs','--configLoader','runner','--host','127.0.0.1','--port','5394','--strictPort'])]
processes=[]
receipt={'started':time.time(),'scriptSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'head':'0e60d3dd','source':str(source),'environment':{k:env[k] for k in ['NEISTRA_DATA_DIR','NEISTRA_PERFORMANCE','PYTHONDONTWRITEBYTECODE','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS']},'ports':[8240,8241,5394]}
def stop(*args):
 for name,p in reversed(processes):
  if p.poll() is None: os.killpg(p.pid,signal.SIGTERM)
 for name,p in reversed(processes):
  try:p.wait(10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 receipt['stopped']=time.time();receipt['exit_codes']={name:p.returncode for name,p in processes}
 (root/'candidate-postopt-stack.json').write_text(json.dumps(receipt,indent=2)+'\n')
 sys.exit(0)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
for name,cmd in commands:
 p=subprocess.Popen(cmd,cwd=source/'apps/web' if name=='web' else source,env=env,stdout=(root/('candidate-postopt-'+name+'.log')).open('w'),stderr=subprocess.STDOUT,start_new_session=True)
 processes.append((name,p))
receipt['supervisor_pid']=os.getpid();receipt['pids']={name:p.pid for name,p in processes}
(root/'candidate-postopt-stack.json').write_text(json.dumps(receipt,indent=2)+'\n')
for url in ['http://127.0.0.1:8240/api/v1/health','http://127.0.0.1:8241/health','http://127.0.0.1:5394/']:
 deadline=time.monotonic()+40
 while True:
  try:
   with urllib.request.urlopen(url,timeout=2) as response:
    if response.status==200: break
  except Exception:
   if time.monotonic()>deadline: print('Readiness failed '+url,flush=True);stop()
   if any(p.poll() is not None for _,p in processes): print('Owned process exited',flush=True);stop()
   time.sleep(.2)
receipt['ready']=time.time();(root/'candidate-postopt-stack.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
while True:time.sleep(.5)
