/** Qualification-only exact-expression binding, including a later useMemo wrapper. */
export function bindDisplayKey(text,symbol,expected,measureObject='interactionPerf',label='displayKey.stringify'){
 const pattern=new RegExp('const\\s+'+symbol+'\\s*=','g');
 const declarations=[...text.matchAll(pattern)];
 if(declarations.length!==expected)throw Error('Display-key binding '+symbol+': expected '+expected+', got '+declarations.length);
 if(!expected)return {body:text,bindings:0};
 const start=declarations[0].index+declarations[0][0].length;
 const call=text.indexOf('JSON.stringify(',start);
 const semicolon=text.indexOf(';',start);
 if(call<0||(semicolon>=0&&call>semicolon))throw Error('No original stringify inside '+symbol+' declaration');
 const open=call+'JSON.stringify'.length;
 let depth=0,quote=null,escaped=false,end=-1;
 for(let i=open;i<text.length;i++){
  const character=text[i];
  if(quote){
   if(escaped)escaped=false;
   else if(character==='\\')escaped=true;
   else if(character===quote)quote=null;
  }else if(character==='"'||character==="'"||character.charCodeAt(0)===96)quote=character;
  else if(character==='(')depth++;
  else if(character===')'&&--depth===0){end=i+1;break;}
 }
 if(end<0)throw Error('Unterminated stringify inside '+symbol);
 const expression=text.slice(call,end);
 return {body:text.slice(0,call)+'window.'+measureObject+'.measure('+JSON.stringify(label)+',()=>'+expression+')'+text.slice(end),bindings:1,expression};
}
