import base from '/datadisk/dev/neistra-worktrees/issue-152/apps/web/vite.config.ts';
export default { ...base, root:'/datadisk/dev/neistra-worktrees/issue-152/apps/web', cacheDir:'/tmp/neistra152-c3-perf/candidate-vite-cache',server:{...base.server,host:'127.0.0.1',port:5394,strictPort:true}};
