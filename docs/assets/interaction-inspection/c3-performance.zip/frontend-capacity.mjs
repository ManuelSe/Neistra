import fs from 'node:fs';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import {bindDisplayKey} from './display-key-binding.mjs';
const require=createRequire('/datadisk/dev/neistra-worktrees/issue-152/package.json');
const {chromium,request}=require('@playwright/test');
const options=Object.fromEntries(process.argv.slice(2).map(arg=>{const i=arg.indexOf('=');return [arg.slice(0,i),arg.slice(i+1)];}));
const url=options.url??'http://127.0.0.1:5393';
const out=options.out??'/tmp/neistra152-c3-perf/candidate-frontend-capacity';
fs.mkdirSync(out,{recursive:true});
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const receipt={scope:'Synthetic frontend controller/list only; no chemistry, backend throughput, native installation or GPU capacity claim',url,atoms:100000,records:20000,started:new Date().toISOString(),scriptSha256:sha(fs.readFileSync(new URL(import.meta.url))),bindingScriptSha256:sha(fs.readFileSync(new URL('./display-key-binding.mjs',import.meta.url))),bindings:[],complete:false};
const browser=await chromium.launch({headless:true,args:['--enable-webgl','--ignore-gpu-blocklist','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 const context=await browser.newContext({viewport:{width:1280,height:720}});
 const page=await context.newPage();const errors=[];page.on('pageerror',error=>errors.push(String(error)));
 const requests=[];page.on('request',request=>{if(new URL(request.url()).pathname.startsWith('/api/'))requests.push(request.url());});
 await page.addInitScript(()=>{
  window.capacityTasks=[];
  new PerformanceObserver(list=>window.capacityTasks.push(...list.getEntries().map(entry=>entry.duration))).observe({type:'longtask',buffered:false});
  window.capacityProbe={values:{},measure(name,fn){const start=performance.now();try{const result=fn();const r=this.values[name]??={calls:0,ms:0,characters:0};r.calls++;r.ms+=performance.now()-start;if(typeof result==='string')r.characters+=result.length;return result;}catch(error){throw error;}}};
 });
 await page.route('**/__c3-capacity.html',route=>route.fulfill({contentType:'text/html',body:'<!doctype html><html><head></head><body><div id="capacity-root"></div></body></html>'}));
 await page.route('**/src/interactions/filter.ts*',async route=>{
  const response=await route.fetch(),text=await response.text();if(!/function filterInteractions\(/.test(text))throw Error('filter source mismatch');
  const appended='\nconst capacityFilter=filterInteractions;filterInteractions=function(...args){return window.capacityProbe.measure("filter",()=>capacityFilter.apply(this,args));};';
  receipt.bindings.push({module:'filter',sha256:sha(text),modifiedSha256:sha(text+appended)});await route.fulfill({response,body:text+appended});
 });
 await page.route('**/src/interactions/useInteractionInspection.ts*',async route=>{
  const response=await route.fetch(),text=await response.text();
  const body=bindDisplayKey(text,'displayKey',1,'capacityProbe','displayKey').body;
  receipt.bindings.push({module:'controller',sha256:sha(text),modifiedSha256:sha(body)});await route.fulfill({response,body});
 });
 const api=await request.newContext({baseURL:url});
 const compiled=await (await api.get('/src/workspace.tsx')).text();
 function dep(name){const found=[...compiled.matchAll(/from "([^"]+)"/g)].map(m=>m[1]).find(value=>value.includes(name));if(!found)throw Error('Missing compiled dependency '+name);return found;}
 const buttonCompiled=await (await api.get('/src/components/IconButton.tsx')).text();
 const tooltipUrl=[...buttonCompiled.matchAll(/from "([^"]+)"/g)].map(m=>m[1]).find(value=>value.includes('react-tooltip'));
 if(!tooltipUrl)throw Error('Missing compiled Tooltip dependency');
 const imports={react:dep('/react.js'),dom:dep('/react-dom_client.js'),query:dep('react-query'),tooltip:tooltipUrl};
 receipt.dependencyBindingSha256=sha(compiled);
 await page.goto(url+'/__c3-capacity.html');
 await page.evaluate(async()=>{
  const {default:runtime}=await import('/@react-refresh');runtime.injectIntoGlobalHook(window);
  window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;
 });
 await page.evaluate(async urls=>{
  const [reactModule,domModule,query,Tooltip,fixtures,controller,storeModule,keyModule]=await Promise.all([import(urls.react),import(urls.dom),import(urls.query),import(urls.tooltip),import('/src/test/molecular-fixtures.ts'),import('/src/interactions/useInteractionInspection.ts'),import('/src/store/interactions.ts'),import('/src/interactions/useInteractions.ts')]);
  const React=reactModule.default??reactModule,dom=domModule.default??domModule;
  const {InteractionPanel}=await import('/src/components/InteractionPanel.tsx');await import('/src/styles.css');await import('/src/components/interactions.css');
  const atomsPerEntry=50000;
  const entries=['capacity-a','capacity-b'].map(id=>({...fixtures.molecularEntry(id,id,'protein'),atom_count:atomsPerEntry,atom_ids:Array.from({length:atomsPerEntry},(_,i)=>i+1),residue_count:2,bond_count:0}));
  const project=fixtures.molecularProject(entries);project.id='capacity-project';
  const normalized=fixtures.proteinStructure();
  const structures=entries.map(entry=>{
   const structure={...normalized,atoms:Array.from({length:atomsPerEntry},(_,i)=>({...normalized.atoms[0],id:i+1,source_index:i,name:'C'+(i+1),coordinates:[i*5,0,0]})),bonds:[]};
   return {entryId:entry.id,label:entry.name,normalized:structure,hierarchy:fixtures.componentHierarchy(structure),projection:{format:'mmcif',data:'frontend-capacity-no-native'},atomIds:entry.atom_ids,settings:entry.viewer_settings};
  });
  const projections=new Map(structures.map(s=>[s.entryId,{entry_id:s.entryId,artifact_id:entries.find(e=>e.id===s.entryId).current_artifact_id,structure:s.normalized,hierarchy:s.hierarchy,viewer:s.projection}]));
  const records=Array.from({length:20000},(_,i)=>({kind:'clash',scope:'inter',participants:[[{structure_id:entries[0].id,atom_id:i+1}],[{structure_id:entries[1].id,atom_id:i+1}]],endpoints:[[i*5,0,0],[i*5,1,0]],geometry:{distance:1,overlap:2.4}}));
  const inputs=entries.map(e=>({entry_id:e.id,artifact_id:e.current_artifact_id}));
  const result={profile:'interaction-v1',frame:'workspace-cartesian',inputs,records,coverage:Object.fromEntries(['hydrogen_bond','hydrophobic','pi_pi','cation_pi','salt_bridge','clash'].map(k=>[k,{status:'partial',assessed_atoms:100000,skipped_atoms:0}])),warnings:[],candidate_comparisons:0};
  const store=storeModule.useInteractionStore.getState();store.setProject(project.id);store.toggleType('clash');store.publish(project.id,keyModule.interactionKey(project.id,inputs),result);
  const client=new query.QueryClient({defaultOptions:{queries:{retry:false}}});client.setQueryData(['project',project.id],project);
  const base={project,selection:{schema_version:1,atoms:[],granularity:'atom',source:'inspector'},projections,structures,isolation:null,paused:false,busy:false,viewerReady:false,viewReady:true,viewer:{current:{focusAtoms(){}}},native:null,renderFailure:null,onSelect(){}};
  window.capacityProbe.base=base;window.capacityProbe.records=records;
  function Capacity(){
   const [tick,setTick]=React.useState(0),[open,setOpen]=React.useState(true);
   window.capacityProbe.bump=()=>setTick(n=>n+1);
   window.capacityProbe.open=()=>setOpen(true);
   const state=controller.useInteractionInspection(base);
   window.capacityProbe.last={contacts:state.panel.contacts.length,records:state.displayRecords.length,phase:state.panel.status.phase,tick};
   React.useEffect(()=>{window.capacityProbe.readyTick=tick;},[tick]);
   return React.createElement(InteractionPanel,{...state.panel,open,onOpenChange:setOpen,restoreFocus:false});
  }
  window.capacityProbe.root=dom.createRoot(document.getElementById('capacity-root'));
  window.capacityProbe.root.render(React.createElement(React.StrictMode,null,React.createElement(query.QueryClientProvider,{client},React.createElement(Tooltip.Provider,null,React.createElement(Capacity)))));
 },imports);
 await page.waitForFunction(()=>window.capacityProbe.last?.contacts===20000);
 const initial=await page.evaluate(()=>({state:window.capacityProbe.last,work:window.capacityProbe.values,longestTask:Math.max(0,...window.capacityTasks),tasks:window.capacityTasks,rows:document.querySelectorAll('.interaction-contact-row').length,dom:document.getElementsByTagName('*').length,heap:performance.memory?.usedJSHeapSize??null}));
 await page.locator('.interaction-contacts>summary').click();
 if(await page.locator('.interaction-contact-row').count()!==30)throw Error('Contact DOM not bounded at30');
 await page.getByRole('button',{name:'Next contact page',exact:true}).click();
 if(await page.locator('.interaction-contact-row').count()!==30)throw Error('Next page DOM not bounded at30');
 await page.getByRole('button',{name:'Previous contact page',exact:true}).click();
 await page.evaluate(()=>{window.capacityProbe.values={};window.capacityTasks=[];window.capacityProbe.started=performance.now();});
 for(let i=0;i<30;i++){await page.evaluate(()=>window.capacityProbe.bump());await page.waitForFunction(i=>window.capacityProbe.readyTick===i+1,i);}
 const warm=await page.evaluate(()=>({ms:performance.now()-window.capacityProbe.started,state:window.capacityProbe.last,work:window.capacityProbe.values,longestTask:Math.max(0,...window.capacityTasks),tasks:window.capacityTasks,rows:document.querySelectorAll('.interaction-contact-row').length,dom:document.getElementsByTagName('*').length,heap:performance.memory?.usedJSHeapSize??null}));
 if(!Number.isFinite(warm.ms)||warm.ms<0||!Number.isFinite(warm.longestTask))throw Error('Invalid capacity measurement');
 if(warm.rows!==30||warm.state.contacts!==20000||warm.state.records!==20000)throw Error('Capacity identity/count/bounds failed');
 await page.evaluate(()=>window.capacityProbe.root.unmount());
 const retired=await page.evaluate(()=>({rows:document.querySelectorAll('.interaction-contact-row').length,dialogs:document.querySelectorAll('[role=dialog]').length}));
 if(retired.rows||retired.dialogs)throw Error('Capacity DOM retained afterunmount');
 if(requests.length||errors.length)throw Error('Unexpected API/browser errors '+JSON.stringify({requests,errors}));
 Object.assign(receipt,{complete:true,initial,warm,retired,requests,errors});
 await api.dispose();await context.close();
}catch(error){receipt.error=String(error);throw error;}
finally{receipt.finished=new Date().toISOString();fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');await browser.close();}
