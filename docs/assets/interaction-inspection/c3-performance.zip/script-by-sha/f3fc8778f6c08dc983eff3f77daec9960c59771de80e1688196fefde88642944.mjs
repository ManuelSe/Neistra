import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import {bindDisplayKey} from './display-key-binding.mjs';
const require=createRequire('/datadisk/dev/neistra-worktrees/issue-152/package.json');
const {chromium,request}=require('@playwright/test');
const options=Object.fromEntries(process.argv.slice(2).map(arg=>{const i=arg.indexOf('=');return [arg.slice(0,i),arg.slice(i+1)];}));
const source=options.source ?? '/tmp/neistra152-c3-perf/baseline-source';
const url=options.url ?? 'http://127.0.0.1:5394';
const out=options.out ?? '/tmp/neistra152-c3-perf/baseline-probe';
const fixture=options.fixture ?? 'ordinary';
const instrument=options.instrument==='1';
const runs=Number(options.runs??1);
fs.mkdirSync(out,{recursive:true});
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const evidence={source,url,fixture,instrument,runs,started:new Date().toISOString(),scriptSha256:sha(fs.readFileSync(new URL(import.meta.url))),bindingScriptSha256:sha(fs.readFileSync(new URL('./display-key-binding.mjs',import.meta.url))),fixtureHashes:Object.fromEntries(['tests/fixtures/complex/1stp.pdb','tests/fixtures/interactions/aligned_ethanol.mol'].map(name=>[name,sha(fs.readFileSync(path.join(source,name)))])),routeBindings:[],results:[],policy:0};
function init(){
 const stats={active:false,phase:'idle',values:{},events:[]};
 stats.add=function(name,duration,amount=0){if(!this.active)return;const row=this.values[name]??={calls:0,ms:0,amount:0};row.calls++;row.ms+=duration;row.amount+=amount;};
 stats.measure=function(name,callback){const start=performance.now();try{const value=callback();this.add(name,performance.now()-start,typeof value==='string'?value.length:0);return value;}catch(error){this.add(name,performance.now()-start);throw error;}};
 stats.observeInputs=function(input){
  const fields={structures:input.structures,projections:input.projections,project:input.project,entries:input.project.entries,selection:input.selection,selectedAtoms:input.selection.atoms,isolation:input.isolation,native:input.native,paused:input.paused,viewReady:input.viewReady};
  const previous=this.lastInputs;
  if(previous)for(const [name,value] of Object.entries(fields))if(previous.fields[name]!==value)this.add('inputchange.'+name,0);
  const rows=input.structures.map(structure=>({id:structure.entryId,normalized:structure.normalized,settings:structure.settings,hierarchy:structure.hierarchy,atomIds:structure.atomIds,projection:structure.projection,pockets:structure.pockets}));
  if(previous)for(const row of rows){
   const old=previous.rows.find(value=>value.id===row.id);
   if(old)for(const name of ['normalized','settings','hierarchy','atomIds','projection','pockets'])if(old[name]!==row[name])this.add('structurechange.'+name,0);
  }
  this.lastInputs={fields,rows};
 };
 window.interactionPerf=stats;
 window.interactionTasks=[];
 new PerformanceObserver(list=>{if(stats.active)for(const item of list.getEntries())window.interactionTasks.push(item.duration);}).observe({type:'longtask',buffered:false});
}
function appendWrap(name,label,argsSuffix=''){
 return '\nconst perfOriginal_'+name+'='+name+'; '+name+'=function(...args){return window.interactionPerf.measure('+JSON.stringify(label)+(argsSuffix?'+('+argsSuffix+')':'')+',()=>perfOriginal_'+name+'.apply(this,args));};\n';
}
async function installRoutes(page){
 await page.route('**/src/viewer/MolstarEngine.ts*',async route=>{
  const response=await route.fetch();const original=await response.text();
  let added='\nconst perfMount=MolstarEngine.prototype.mount;MolstarEngine.prototype.mount=async function(target){const value=await perfMount.call(this,target);(window.interactionEngines??=[]).push(this);return value;};\n';
  if(instrument)for(const name of ['setInteractions','applyInteractions','publishInteractionDisplay','invalidateInteractionDisplay']){
   added+='\nif(MolstarEngine.prototype.'+name+'){const perfMethod=MolstarEngine.prototype.'+name+';MolstarEngine.prototype.'+name+'=function(...args){return window.interactionPerf.measure('+JSON.stringify('engine.'+name)+',()=>perfMethod.apply(this,args));};}\n';
  }
  evidence.routeBindings.push({module:'MolstarEngine',originalSha256:sha(original),modifiedSha256:sha(original+added)});
  await route.fulfill({response,body:original+added});
 });
 if(!instrument)return;
 for(const [module,names] of [
  ['interactions/filter.ts',['filterInteractions']],
  ['viewer/interactionGeometry.ts',['interactionLines']],
  ['interactions/presentation.ts',['interactionRecordKey','createInteractionPresentationContext','interactionMetrics']],
  ['interactions/target.ts',['filterTargetInteractions','validateInteractionTarget','resolveInteractionLigands']]
 ]){
  await page.route('**/src/'+module+'*',async route=>{
   const response=await route.fetch();const original=await response.text();let added='';
   for(const name of names){if(!new RegExp('function\\s+'+name+'\\s*\\(').test(original))throw Error('Missing source binding '+module+':'+name);added+=appendWrap(name,module+':'+name,name==='filterInteractions'?'args[4] ? ".native" : ".owner"':'');}
   evidence.routeBindings.push({module,originalSha256:sha(original),modifiedSha256:sha(original+added)});
   await route.fulfill({response,body:original+added});
  });
 }
 for(const module of ['components/StructureViewer.tsx','interactions/useInteractionInspection.ts']){
  await page.route('**/src/'+module+'*',async route=>{
   const response=await route.fetch();let original=await response.text();let body=original;
   const candidate=fs.existsSync(path.join(source,'apps/web/src/interactions/useInteractionInspection.ts'));
   const expected=(candidate?module.includes('useInteractionInspection'):module.includes('StructureViewer'))?1:0;
   const bound=bindDisplayKey(original,module.includes('StructureViewer')?'interactionDisplayKey':'displayKey',expected);
   body=bound.body;
   if(module.includes('useInteractionInspection')){
    if(!/function useInteractionInspection\(/.test(original))throw Error('Missing controller input binding');
    body+='\nconst perfInspection=useInteractionInspection;useInteractionInspection=function(input){window.interactionPerf.observeInputs(input);return perfInspection(input);};\n';
   }
   evidence.routeBindings.push({module,bindings:bound.bindings,originalSha256:sha(original),modifiedSha256:sha(body)});
   await route.fulfill({response,body});
  });
 }
}
async function poll(callback,predicate,description,timeout=45000){
 const start=Date.now();let last;
 while(Date.now()-start<timeout){last=await callback();if(predicate(last))return last;await new Promise(resolve=>setTimeout(resolve,40));}
 throw Error('Timeout '+description+': '+JSON.stringify(last));
}
async function settled(page){
 return page.evaluate(async()=>{const e=window.interactionEngines.at(-1);await e.syncQueue;await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));return {records:e.interactions.length,draw:e.interactionRepresentation.renderObjects.map(o=>o.values.drawCount.ref.value),display:e.interactionDisplayState?.status??null,shown:e.interactionDisplayState?.installedRecordKeys.length??null,generation:e.generation,camera:e.getCamera()};});
}
async function resource(page){
 return page.evaluate(async()=>{const e=window.interactionEngines.at(-1);await e.syncQueue;return {representations:e.plugin.canvas3d.reprCount.value,objects:e.interactionRepresentation.renderObjects.length,buffers:e.interactionRepresentation.renderObjects.map(o=>({draw:o.values.drawCount.ref.value,indexCapacity:o.values.elements.ref.value.length,startCapacity:o.values.aStart.ref.value.length,endCapacity:o.values.aEnd.ref.value.length,groupCapacity:o.values.aGroup.ref.value.length})),listeners:e.interactionDisplayListeners?.size??null,engines:window.interactionEngines.length,contactRows:document.querySelectorAll('.interaction-contact-row').length,warningRows:document.querySelectorAll('.interaction-warning-list>li').length,dom:document.getElementsByTagName('*').length,heap:performance.memory?.usedJSHeapSize??null};});
}
async function snapshot(page,ids){
 return page.evaluate(async entries=>{
  const e=window.interactionEngines.at(-1);await e.syncQueue;
  const names=new Map(entries.map((id,index)=>[id,index]));
  const records=e.interactions.map(r=>({...r,participants:r.participants.map(g=>g.map(a=>({structure_id:names.get(a.structure_id),atom_id:a.atom_id})).sort((a,b)=>a.structure_id-b.structure_id||a.atom_id-b.atom_id))}));
  const normalized=records.map(r=>JSON.stringify(r)).sort();
  const byGroup=new Map();for(const [group,r] of records.entries())byGroup.set(group,{record:JSON.stringify(r),segments:[]});
  for(const object of e.interactionRepresentation.renderObjects){
   const v=object.values,lines=v.drawCount.ref.value/6;
   for(let i=0;i<lines;i++){const vertex=i*4,g=v.aGroup.ref.value[vertex],row=byGroup.get(g);if(!row)throw Error('Unknown native group');row.segments.push([Array.from(v.aStart.ref.value.slice(vertex*3,vertex*3+3)),Array.from(v.aEnd.ref.value.slice(vertex*3,vertex*3+3))]);}
  }
  const geometry=[...byGroup.values()].map(row=>({record:row.record,segments:row.segments.map(v=>JSON.stringify(v)).sort()})).sort((a,b)=>a.record.localeCompare(b.record));
  return {records:normalized,geometry,counts:e.interactions.reduce((v,r)=>(v[r.kind]=(v[r.kind]??0)+1,v),{}),pickable:e.interactionRepresentation.renderObjects.map(o=>o.state.pickable)};
 },ids);
}
async function phase(page,name,operation){
 const beforeCamera=await page.evaluate(()=>window.interactionEngines.at(-1).getCamera());
 await page.evaluate(name=>{const s=window.interactionPerf;s.phase=name;s.values={};window.interactionTasks=[];s.active=true;},name);
 const started=performance.now();await operation();const state=await settled(page);const ms=performance.now()-started;
 if(name.startsWith('camera-')&&JSON.stringify(beforeCamera)===JSON.stringify(state.camera))throw Error('Real camera input did not change pose');
 const measurements=await page.evaluate(()=>{const s=window.interactionPerf;s.active=false;return {work:s.values,tasks:window.interactionTasks,longestTask:Math.max(0,...window.interactionTasks)};});
 return {name,ms,state,...measurements,resources:await resource(page),beforeCamera};
}
const browser=await chromium.launch({headless:true,args:['--enable-webgl','--ignore-gpu-blocklist','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 for(let run=0;run<runs;run++){
  const context=await browser.newContext({viewport:{width:1280,height:720}});
  await context.addInitScript(init);
  const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(String(e)));
  await installRoutes(page);
  const api=await request.newContext({baseURL:url});
  const created=await api.post('/api/v1/projects',{data:{name:'C3 '+fixture+' '+run+' '+Date.now()}});if(!created.ok())throw Error(await created.text());
  const project=await created.json();await page.goto(url);await page.getByRole('button',{name:'Projects',exact:true}).click();
  await page.getByRole('dialog',{name:'Projects',exact:true}).getByRole('button',{name:project.name,exact:false}).click();
  await page.getByRole('button',{name:'Import structures',exact:true}).first().click();
  const imports=page.getByRole('dialog',{name:'Import structures',exact:true});
  const files=fixture==='ordinary'?[path.join(source,'tests/fixtures/complex/1stp.pdb'),path.join(source,'tests/fixtures/interactions/aligned_ethanol.mol')]:Array.from({length:20},(_,i)=>({name:'dense-ethanol-'+i+'.mol',mimeType:'chemical/x-mdl-molfile',buffer:fs.readFileSync(path.join(source,'tests/fixtures/interactions/aligned_ethanol.mol'))}));
  await imports.locator('input[type=file]').setInputFiles(files);
  await imports.getByRole('button',{name:'Import',exact:true}).click();await imports.waitFor({state:'hidden',timeout:45000});
  await poll(()=>page.locator('.viewer-status').textContent(),s=>s.includes(files.length+' visible / '+files.length+' loaded'),'load');
  await poll(()=>page.evaluate(()=>window.interactionEngines?.length??0),n=>n>0,'engine');
  await settled(page);
  await page.getByRole('button',{name:'Fit all visible',exact:true}).click();
  await settled(page);
  const current=await (await api.get('/api/v1/projects/'+project.id)).json();
  const ids=current.entries.map(e=>e.id);const atoms=current.entries.reduce((n,e)=>n+e.atom_count,0);
  const requests={analyses:0,structureGets:0,requestBytes:0};const responses=[];
  page.on('request',req=>{const p=new URL(req.url()).pathname;if(p.endsWith('/interactions')){requests.analyses++;requests.requestBytes+=Buffer.byteLength(req.postData()??'');}if(/\/entries\/[^/]+\/structure$/.test(p))requests.structureGets++;});
  page.on('response',async response=>{if(new URL(response.url()).pathname.endsWith('/interactions'))responses.push({status:response.status(),body:await response.json()});});
  await page.getByRole('button',{name:'Interactions',exact:true}).click();const panel=page.getByRole('dialog',{name:'Interactions',exact:true});
  const phases=[];
  phases.push(await phase(page,'firstDisplay',async()=>{await panel.getByRole('button',{name:'Clashes',exact:true}).click();await poll(()=>settled(page),s=>s.records>0&&s.draw.some(n=>n>0)&&(s.display===null||s.display==='ready'),'first markers');}));
  const initial=await snapshot(page,ids);const initialResource=await resource(page);
  await panel.getByRole('button',{name:'Close interactions',exact:true}).click();
  for(let repeat=0;repeat<3;repeat++){
   phases.push(await phase(page,'camera-'+repeat,async()=>{const box=await page.locator('.molstar-host canvas').first().boundingBox();const x=box.x+box.width*.7,y=box.y+box.height*.6;await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+45,y+12,{steps:8});await page.mouse.up();await new Promise(resolve=>setTimeout(resolve,100));}));
  }
  phases.push(await phase(page,'panelLifecycle',async()=>{for(let i=0;i<5;i++){await page.getByRole('button',{name:'Interactions',exact:true}).click();await panel.getByRole('button',{name:'Close interactions',exact:true}).click();}}));
  await page.getByRole('button',{name:'Interactions',exact:true}).click();
  phases.push(await phase(page,'cachedToggle',async()=>{for(let i=0;i<3;i++){await panel.getByRole('button',{name:'Clashes',exact:true}).click();await settled(page);await panel.getByRole('button',{name:'Clashes',exact:true}).click();await settled(page);}}));
  await panel.getByRole('button',{name:'Close interactions',exact:true}).click();
  await page.getByRole('button',{name:'Open viewer controls',exact:true}).click();
  phases.push(await phase(page,'hydrogenVisibility',async()=>{const h=page.getByRole('checkbox',{name:'Show hydrogens',exact:true});for(let i=0;i<2;i++){await h.click();await settled(page);await h.click();await settled(page);}}));
  await page.getByRole('button',{name:'Close viewer controls',exact:true}).click();
  await page.evaluate(async entry=>{const {useSelectionStore}=await import('/src/store/selection.ts');useSelectionStore.getState().replace({schema_version:1,atoms:entry.atom_ids.map(atom_id=>({structure_id:entry.id,atom_id})),granularity:'atom',source:'inspector'});},current.entries[0]);
  await settled(page);
  await page.getByRole('button',{name:'Open viewer controls',exact:true}).click();
  phases.push(await phase(page,'isolation',async()=>{for(let i=0;i<3;i++){await page.getByRole('button',{name:'Isolate selection',exact:true}).click();await settled(page);await page.getByRole('button',{name:'Show all',exact:true}).click();await settled(page);}}));
  await page.getByRole('button',{name:'Close viewer controls',exact:true}).click();
  const final=await snapshot(page,ids);const finalResource=await resource(page);
  const normalizedAnalysis=responses.map(r=>({status:r.status,profile:r.body.profile,records:r.body.records?.map(record=>({...record,participants:record.participants.map(group=>group.map(ref=>({structure_id:ids.indexOf(ref.structure_id),atom_id:ref.atom_id})))}))}));
  const result={run,atoms,entries:ids.length,phases,requests,initialRecordCount:initial.records.length,initialRecordSha256:sha(JSON.stringify(initial.records)),finalRecordSha256:sha(JSON.stringify(final.records)),initialGeometrySha256:sha(JSON.stringify(initial.geometry)),finalGeometrySha256:sha(JSON.stringify(final.geometry)),initialResource,finalResource,errors,analysis:normalizedAnalysis};
  if(result.initialRecordSha256!==result.finalRecordSha256||result.initialGeometrySha256!==result.finalGeometrySha256)throw Error('Restored records or geometry changed');
  if(errors.length)throw Error('Browser errors '+errors.join('; '));
  fs.writeFileSync(path.join(out,'run-'+run+'.json'),JSON.stringify(result,null,2)+'\n');
  evidence.results.push({...result,analysis:undefined});
  console.log(JSON.stringify({run,fixture,atoms,records:initial.records.length,requests,phases:phases.map(p=>({name:p.name,ms:p.ms,work:p.work}))}));
  await api.dispose();await context.close();
 }
 evidence.complete=true;
}catch(error){evidence.error=String(error);evidence.complete=false;throw error;}
finally{evidence.finished=new Date().toISOString();fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(evidence,null,2)+'\n');await browser.close();}
