"""Sequential bounded case runner; all outputs remain in the owned temporary tree."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from time import perf_counter, sleep

ROOT = Path(__file__).resolve().parent
WORKER = ROOT / "worker.py"
PYTHON = Path("/datadisk/dev/neistra-worktrees/issue-11-ligand-information/.venv/bin/python")
cases = []

def add(name, fixture, methods=("baseline", "prototype"), cutoff=2.0, minimum=0.5, raw=20_000_000):
    cases.append(dict(name=name, fixture=str(fixture), methods=methods,
                      cutoff=cutoff, minimum=minimum, raw=raw))

base = ROOT / "baseline/tests/fixtures"
add("ethanol3", base / "formats/ethanol.mol", cutoff=3)
for cutoff in [2, 3, 10]:
    add(f"1stp1001-cut{cutoff}", base / "complex/1stp.pdb", cutoff=cutoff)
for n in [100, 500, 1000]:
    add(f"coincident{n}", ROOT / f"fixtures/coincident-{n}.json")
for n in [100, 1000, 10000, 100000]:
    add(f"sparse{n}", ROOT / f"fixtures/sparse-{n}.json")
for n in [100, 1000, 10000]:
    add(f"grid{n}", ROOT / f"fixtures/grid-{n}.json",
        methods=("baseline", "prototype") if n <= 1001 else ("prototype",))
for cutoff in [2, 3]:
    add(f"prepared-protein2272-cut{cutoff}", base / "minimization/1stp-protein.normalized.json",
        methods=("prototype",), cutoff=cutoff)
    add(f"1aon-cut{cutoff}", base / "surfaces/1aon.cif", methods=("prototype",), cutoff=cutoff)
add("coincident5000-raw-refusal", ROOT / "fixtures/coincident-5000.json",
    methods=("prototype",), raw=2_000_000)
manifest = {"worker_sha256": hashlib.sha256(WORKER.read_bytes()).hexdigest(),
            "prototype_sha256": hashlib.sha256((ROOT / "contact_prototype.py").read_bytes()).hexdigest(),
            "repeats": 3, "case_definitions": cases, "run_profile": "Portable isolated-process exploration; shared host, warm OS file cache, default scientific import environment. No reference-host qualification."}
(ROOT / "run-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
all_results = []
for repeat in range(1, 4):
    for case in cases:
        for method in case["methods"]:
            tag = case["name"] + f"-r{repeat}"
            logbase = ROOT / "results" / (tag + "-" + method)
            command = [str(PYTHON), str(WORKER), "--case", tag, "--method", method,
                       "--fixture", case["fixture"], "--cutoff", str(case["cutoff"]),
                       "--minimum", str(case["minimum"]), "--raw-limit", str(case["raw"])]
            started = perf_counter()
            with logbase.with_suffix(".stdout").open("wb") as out, logbase.with_suffix(".stderr").open("wb") as err:
                child = subprocess.Popen(command, stdout=out, stderr=err, cwd=ROOT)
                observed_rss = 0
                killed = None
                while child.poll() is None:
                    try:
                        text = Path(f"/proc/{child.pid}/status").read_text()
                        rss = int(next(line.split()[1] for line in text.splitlines() if line.startswith("VmRSS:"))) * 1024
                        observed_rss = max(observed_rss, rss)
                        if rss > 2 * 1024**3:
                            killed = "parent2GiBRSSguard"
                    except (FileNotFoundError, StopIteration):
                        pass
                    if perf_counter() - started > 70:
                        killed = "parent70secondlifetimeguard"
                    if killed:
                        child.kill()
                        break
                    sleep(0.02)
                exit_code = child.wait()
            outer = perf_counter() - started
            lines = logbase.with_suffix(".stdout").read_text().splitlines()
            report = json.loads(lines[-1]) if lines else {"status": "missing_worker_report"}
            report.update(case_definition=case["name"], repeat=repeat, process_exit_code=exit_code,
                          parent_wall_seconds=outer, parent_observed_peak_rss_bytes=observed_rss,
                          parent_kill_reason=killed, exact_command=command)
            if "worker_wall_seconds" in report:
                report["spawn_and_standard_import_residual_seconds"] = outer - report["worker_wall_seconds"]
            logbase.with_suffix(".json").write_text(json.dumps(report, indent=2) + "\n")
            all_results.append(report)
            (ROOT / "results.json").write_text(json.dumps(all_results, indent=2) + "\n")
            print(json.dumps({"case": tag, "method": method, "status": report.get("status"),
                              "N": report.get("input_atoms"), "core_s": report.get("phases_seconds", {}).get("core_total_including_sort"),
                              "wall_s": outer, "peak_kib": report.get("peak_rss_kib"),
                              "results": report.get("retained_results"), "refusal": report.get("refusal_reason")}), flush=True)
            if exit_code or killed or report.get("status") == "experiment_failure":
                raise SystemExit("Consequential experiment failure; stop and investigate without relaxing guards")
print("COMPLETE " + str(len(all_results)), flush=True)
