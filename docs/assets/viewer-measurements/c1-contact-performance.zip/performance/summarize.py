"""Audit the exploratory outputs and summarize measured bounds and tradeoffs."""
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
rows = json.loads((ROOT / "results.json").read_text()) + json.loads((ROOT / "transport-results.json").read_text()) + json.loads((ROOT / "capacity-results.json").read_text())
assert len(rows) == 117
assert all(r["process_exit_code"] == 0 and r["parent_kill_reason"] is None for r in rows)
assert all(r["status"] in {"complete_success", "complete_refusal"} for r in rows)
expected_proto = "0d911355dcb17353cdd565203754c7cb9261892869f040255fbde568a5a41698"
assert hashlib.sha256((ROOT / "contact_prototype.py").read_bytes()).hexdigest() == expected_proto
assert all(r.get("prototype_sha256") == expected_proto for r in rows if r["method"] == "prototype")
for row in rows:
    if row["status"] != "complete_success":
        assert "response" not in row
        continue
    response = row["response"]
    p = Path(response["path"])
    assert p.stat().st_size == response["bytes"]
    assert hashlib.sha256(p.read_bytes()).hexdigest() == response["sha256"]

comparisons = []
lookup = {(r["case_definition"], r["repeat"], r["method"]): r for r in rows}
for baseline in rows:
    if baseline["method"] != "baseline":
        continue
    candidate = lookup[(baseline["case_definition"], baseline["repeat"], "prototype")]
    old = json.loads(Path(baseline["response"]["path"]).read_text())
    new = json.loads(Path(candidate["response"]["path"]).read_text())
    def index(values):
        return {(v["atom_1"]["atom_id"], v["atom_2"]["atom_id"]): v["distance"] for v in values}
    old_map, new_map = index(old), index(new)
    assert len(old_map) == len(old) and len(new_map) == len(new)
    assert old_map.keys() == new_map.keys(), baseline["case_definition"]
    differences = [abs(old_map[key] - new_map[key]) for key in old_map]
    max_difference = max(differences, default=0.0)
    assert max_difference <= 1e-12
    comparisons.append({"case": baseline["case_definition"], "repeat": baseline["repeat"],
        "complete_pair_membership_equal": True, "contacts": len(old_map),
        "max_distance_absolute_difference_angstrom": max_difference,
        "changed_distance_last_bits": sum(old_map[key] != new_map[key] for key in old_map),
        "same_distance_sorted_pair_order": list(old_map) == list(new_map),
        "scope": "Whole-output baseline/prototype comparison on supported representative inputs. Tiny independent oracle qualifies the NEW declared distance predicate; old last bits are not its authority."})

def stats(values):
    return {"samples": len(values), "min": min(values), "median": statistics.median(values),
            "p95_linear_inclusive": statistics.quantiles(values, n=20, method="inclusive")[18], "max": max(values)}

groups = defaultdict(list)
for row in rows:
    groups[(row["case_definition"], row["method"])].append(row)
summaries = []
for (case, method), group in groups.items():
    assert len(group) == 3
    r = group[0]
    assert len({(x["status"], x.get("retained_results"), x.get("response", {}).get("sha256"),
                 x["kernel_metrics"].get("raw_visits"), x.get("refusal_reason")) for x in group}) == 1
    summary = {"case": case, "method": method, "status": r["status"], "input_atoms": r["input_atoms"],
        "source_bytes": r["fixture"]["bytes"], "recorded_bonds": r["recorded_bonds"],
        "cutoff": r["cutoff"], "minimum_distance": r["minimum_distance"],
        "core_seconds": stats([x["phases_seconds"]["core_total_including_sort"] for x in group]),
        "cold_worker_process_wall_seconds": stats([x["parent_wall_seconds"] for x in group]),
        "peak_rss_kib": stats([x["peak_rss_kib"] for x in group]),
        "retained_results": r.get("retained_results"), "response_bytes": r.get("response", {}).get("bytes"),
        "kernel_work": {k: v for k, v in r["kernel_metrics"].items() if not k.endswith("_seconds")},
        "refusal_reason": r.get("refusal_reason"), "repeated_result_bytes_and_work_deterministic": True,
        "phase_seconds": {key: stats([x["phases_seconds"][key] for x in group]) for key in r["phases_seconds"]}}
    summaries.append(summary)

tiny = json.loads((ROOT / "tiny-correctness-clean.json").read_text())
assert tiny["all_passed"] and tiny["successful_stream_runs"] == 132 and tiny["explicit_refusal_controls"] == 8
report = {"scope": "Exploratory pre-implementation measurements; recommendations need scientific/architecture agreement and actual service qualification.",
    "baseline_commit": "4b8ae716f382d67efe0823c007a079a6a278ddce", "prototype_sha256": expected_proto,
    "isolated_process_runs": len(rows), "complete_successes": sum(r["status"] == "complete_success" for r in rows),
    "complete_capacity_refusals": sum(r["status"] == "complete_refusal" for r in rows),
    "unexpected_errors_timeouts_memory_kills": 0,
    "response_serializer": {"shape": "list[{atom_1:{structure_id,atom_id},atom_2:{structure_id,atom_id},distance}]",
        "structure_id": "00000000-0000-0000-0000-000000000157", "structure_id_characters": 36,
        "json": "stdlib json.dumps per record, separators=(',',':'), allow_nan=False; brackets/commas charged; exact incremental size guard before write; no full DTO list materialization in harness"},
    "whole_output_comparisons": comparisons, "maximum_old_new_distance_delta_angstrom": max(x["max_distance_absolute_difference_angstrom"] for x in comparisons),
    "summaries": summaries,
    "tiny_oracle_evidence": {"path": str(ROOT / "tiny-correctness-clean.json"), "sha256": hashlib.sha256((ROOT / "tiny-correctness-clean.json").read_bytes()).hexdigest(),
        "successful_runs": 132, "refusals": 8, "maximum_sites": 20, "author": "Scientific implementation specialist; reused after exact prototype hash verification, not rerun by performance specialist."},
    "recommendations_not_selected_product_defaults": {
        "max_input_atoms": 100000, "max_source_bytes": 64 * 1024**2, "max_raw_returned_neighbors": 2000000,
        "max_retained_results": 250000, "max_serialized_response_bytes": 64 * 1024**2,
        "whole_operation_deadline_seconds": 15, "candidate_child_peak_rss_bytes_for_service_qualification": 1024**3,
        "memory_note": "RSS observation is not a hard allocation cap or an RLIMIT_AS recommendation. Check actual child virtual mappings and whole API parent parsing/Pydantic/response memory before selecting/enforcing policy; 1GiB is a measured-headroom qualification target, not established safety for every admitted source."},
    "required_followup": [
        "Science and architecture agreement before adopting numeric defaults.",
        "Qualify actual immutable normalized-file worker and API parent, including byte/SHA verification, schema/domain conversion, bounded result parsing and response-model serialization.",
        "Measure cancellation/reaping and health responsiveness while real service work is held; the array prototype does not implement them.",
        "Exact/one-over input, source-byte, raw-visit, result and serialized-byte controls before corresponding allocations; held-child timeout/memory refusal with admission retained through reaping.",
        "The fully populated100k/near64MiB metadata-padding control passes, but does not certify every bond/annotation/metadata shape or API-parent allocation permitted by64MiB source admission."]}
(ROOT / "performance-summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: report[k] for k in ["isolated_process_runs", "complete_successes", "complete_capacity_refusals", "unexpected_errors_timeouts_memory_kills", "maximum_old_new_distance_delta_angstrom"]}))
print("Whole-output comparisons", len(comparisons), "all pair memberships equal; phase/work/byte/RSS summaries written.")
