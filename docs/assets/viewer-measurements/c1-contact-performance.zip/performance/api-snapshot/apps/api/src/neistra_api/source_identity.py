"""Strict, best-effort original-file evidence shared by edits and calculations."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import TYPE_CHECKING

from neistra_core.adapters.base import ImportOptions
from neistra_core.adapters.defaults import create_default_registry
from neistra_core.hydrogen_protection import AtomProtection, protection_facts, recover_protection
from neistra_core.molecular import NormalizedStructureV1

if TYPE_CHECKING:
    from neistra_api.import_export import ArtifactService
    from neistra_api.models import StructureEntry
    from neistra_api.settings import Settings


@dataclass(frozen=True)
class VerifiedOriginalIdentity:
    structure: NormalizedStructureV1
    original_artifact_id: str
    sha256: str
    atoms: tuple[AtomProtection, ...]


def recover_original_identity(
    entry: StructureEntry,
    before: NormalizedStructureV1,
    artifacts: ArtifactService,
    settings: Settings,
    *,
    atom_ids: set[int] | None = None,
) -> VerifiedOriginalIdentity | None:
    try:
        existing = protection_facts(before)
        needed = {a.id for a in before.atoms} if atom_ids is None else atom_ids
        missing = needed - existing.keys()
        if not missing or not entry.original_artifact_id:
            return None
        record = artifacts.get(entry.original_artifact_id)
        if record.size > settings.max_structure_file_bytes:
            return None
        _, data = artifacts.read(record.id)
        return recover_original_bytes(
            before,
            data,
            record.id,
            record.sha256,
            record.size,
            max_file_bytes=settings.max_structure_file_bytes,
            atom_limit=settings.atom_hard_limit,
            atom_ids=atom_ids,
        )
    except (ValueError, RuntimeError, OverflowError, OSError, LookupError):
        return None


def recover_original_bytes(
    before: NormalizedStructureV1,
    data: bytes,
    artifact_id: str,
    sha256: str,
    size: int,
    *,
    max_file_bytes: int,
    atom_limit: int,
    atom_ids: set[int] | None = None,
) -> VerifiedOriginalIdentity | None:
    """Recover evidence from verified immutable bytes without database capability."""
    try:
        existing = protection_facts(before)
        needed = {a.id for a in before.atoms} if atom_ids is None else atom_ids
        missing = needed - existing.keys()
        if not missing or size > max_file_bytes:
            return None
        if len(data) != size or hashlib.sha256(data).hexdigest() != sha256:
            return None
        parsed = (
            create_default_registry()
            .for_format(before.source.format)
            .parse(
                data, before.source.filename, ImportOptions(generate_3d=False, infer_bonds=False)
            )
        )
        for original in parsed.structures:
            if original.source.record_index != before.source.record_index:
                continue
            if len(original.atoms) > atom_limit:
                return None
            restored = recover_protection(before, original, atom_ids=atom_ids)
            facts = protection_facts(restored)
            recovered = tuple(facts[i] for i in sorted(missing) if i in facts)
            if recovered:
                return VerifiedOriginalIdentity(restored, artifact_id, sha256, recovered)
            return None
    except (ValueError, RuntimeError, OverflowError, OSError, LookupError):
        # An absent/invalid original never proves ordinary identity. Existing
        # unknown, protected, conflicting and malformed facts remain authoritative.
        return None
    return None
