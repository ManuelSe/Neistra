"""Conservative site typing; supplied molecular data remains immutable."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, cast

from rdkit import Chem
from rdkit.Chem import Lipinski

from neistra_core.adapters.rdkit_common import normalized_to_mol
from neistra_core.interactions import AnalysisInput, InteractionWarning, Site, _template_bonds

# Explicit site registry. Backbone amide N is never an acceptor; proline N is
# not a donor. Histidine requires observed tautomer evidence, not assumed charge.
SIDE_DONORS = {
    "ASP": {"OD1", "OD2"},
    "GLU": {"OE1", "OE2"},
    "ARG": {"NE", "NH1", "NH2"},
    "ASN": {"ND2"},
    "GLN": {"NE2"},
    "LYS": {"NZ"},
    "SER": {"OG"},
    "THR": {"OG1"},
    "TYR": {"OH"},
    "TRP": {"NE1"},
    "CYS": {"SG"},
    "HIS": {"ND1", "NE2"},
}
SIDE_ACCEPTORS = {
    "ASN": {"OD1"},
    "GLN": {"OE1"},
    "ASP": {"OD1", "OD2"},
    "GLU": {"OE1", "OE2"},
    "SER": {"OG"},
    "THR": {"OG1"},
    "TYR": {"OH"},
    "MET": {"SD"},
    "CYS": {"SG"},
    "HIS": {"ND1", "NE2"},
}


@dataclass
class Chemistry:
    typed: set[int] = field(default_factory=set)
    donors: dict[int, list[int]] = field(default_factory=dict)
    acceptors: set[int] = field(default_factory=set)
    hydrophobic: set[int] = field(default_factory=set)
    validated_molecules: list[tuple[Any, list[int]]] = field(default_factory=list)
    protein_residues: list[tuple[str, str, dict[str, int]]] = field(default_factory=list)
    missing_hydrogens: set[int] = field(default_factory=set)


def type_sites(
    inputs: list[AnalysisInput], sites: list[Site], warnings: list[InteractionWarning]
) -> Chemistry:
    chemistry = Chemistry()
    indices = {
        (site.reference.structure_id, site.atom.id): index for index, site in enumerate(sites)
    }
    templates = _template_bonds()
    for source in inputs:
        structure, entry = source.structure, source.identity.entry_id
        residues = {residue.id: residue for residue in structure.residues}
        residue_atoms: dict[int | None, list[int]] = defaultdict(list)
        for atom in structure.atoms:
            index = indices.get((entry, atom.id))
            if index is not None:
                residue_atoms[atom.residue_id].append(index)
        templated: set[int] = set()
        for residue in structure.residues:
            members = residue_atoms.get(residue.id, [])
            if not members:
                continue
            names = {sites[index].atom.name: index for index in members}
            if residue.component_type == "water":
                oxygen = [index for index in members if sites[index].atom.element == "O"]
                if (
                    len(oxygen) == 1
                    and all(
                        sites[index].atom.element in {"H", "O"}
                        and sites[index].atom.formal_charge in {None, 0}
                        for index in members
                    )
                    and sum(sites[index].atom.element == "H" for index in members) <= 2
                ):
                    chemistry.typed.update(members)
                    chemistry.acceptors.update(oxygen)
                    templated.update(members)
                else:
                    warnings.append(
                        InteractionWarning(
                            entry_id=entry,
                            code="contradictory_water_chemistry",
                            message=(
                                "Water identity contradicts observed charge/composition; "
                                "typing is skipped."
                            ),
                            atom_ids=[sites[index].atom.id for index in members],
                        )
                    )
                # Invalid source water must not fall through to ligand assumptions.
                templated.update(members)
                continue
            if residue.component_type != "polymer" or residue.name not in templates:
                continue
            expected = defaultdict(set)
            for first, second in templates[residue.name]:
                if first.startswith(("-", "+")) or second.startswith(("-", "+")):
                    continue
                expected[first].add(second)
                expected[second].add(first)
            valid: dict[str, int] = {}
            disulfides: set[int] = set()
            acid_names = {"ASP": {"OD1", "OD2"}, "GLU": {"OE1", "OE2"}}.get(
                residue.name, set()
            )
            acid_sites = [index for name, index in names.items() if name in acid_names]
            conflicting_acid = any(
                (sites[index].atom.formal_charge or 0) < 0 for index in acid_sites
            ) and any(
                sites[neighbor].atom.element == "H"
                for index in acid_sites
                for neighbor in sites[index].neighbors
            )
            if conflicting_acid:
                warnings.append(
                    InteractionWarning(
                        entry_id=entry,
                        code="conflicting_protonation",
                        message=(
                            f"Observed {residue.name} acid H conflicts with supplied negative "
                            "side-chain charge; affected ionic and H-bond sites are skipped."
                        ),
                        atom_ids=sorted(sites[index].atom.id for index in acid_sites),
                    )
                )
            histidine_evidence = any(
                sites[neighbor].atom.element == "H"
                for atom_name in ("ND1", "NE2")
                if atom_name in names
                for neighbor in sites[names[atom_name]].neighbors
            )
            if residue.name == "HIS" and not histidine_evidence:
                warnings.append(
                    InteractionWarning(
                        entry_id=entry,
                        code="unresolved_histidine_tautomer",
                        message=(
                            "Histidine acceptor nitrogens lack observed tautomer evidence; "
                            "their H-bond typing is skipped."
                        ),
                        atom_ids=sorted(
                            sites[names[name]].atom.id
                            for name in ("ND1", "NE2")
                            if name in names
                        ),
                    )
                )
            for name, index in names.items():
                if name not in expected or (conflicting_acid and name in acid_names):
                    continue
                atom = sites[index].atom
                # Missing heavy neighbors prevent defensible chemistry assignment.
                required = {
                    neighbor
                    for neighbor in expected[name]
                    if not neighbor.startswith("H") and neighbor != "OXT"
                }
                expected_element = "H" if name.startswith("H") else name[0]
                neighbors = sites[index].neighbors
                conflicts = any(
                    sites[neighbor].reference.structure_id == entry
                    and sites[neighbor].atom.residue_id == residue.id
                    and sites[neighbor].atom.name not in expected[name]
                    for neighbor in neighbors
                )
                external = [
                    neighbor
                    for neighbor in neighbors
                    if sites[neighbor].atom.residue_id != residue.id
                ]
                heavy_external = [
                    neighbor for neighbor in external if sites[neighbor].atom.element != "H"
                ]
                peptide = disulfide = False
                if len(heavy_external) == 1:
                    other = sites[heavy_external[0]].atom
                    other_residue = residues.get(other.residue_id or -1)
                    canonical_other = (
                        other_residue is not None
                        and other_residue.component_type == "polymer"
                        and other_residue.name in templates
                        and other.element == other.name[:1]
                    )
                    peptide = canonical_other and (name, other.name) in {("N", "C"), ("C", "N")}
                    disulfide = (
                        canonical_other
                        and residue.name == "CYS"
                        and name == "SG"
                        and other_residue is not None
                        and other_residue.name == "CYS"
                        and other.name == "SG"
                    )
                conflicts |= bool(heavy_external) and not (peptide or disulfide)
                conflicts |= len(external) != len(heavy_external)
                conflicts |= disulfide and any(
                    sites[neighbor].atom.element == "H" for neighbor in neighbors
                )
                if disulfide:
                    disulfides.add(index)
                if (
                    name not in expected
                    or atom.element != expected_element
                    or not required.issubset(names)
                    or any(
                        sites[names[neighbor]].atom.element != neighbor[:1]
                        for neighbor in required
                        if neighbor in names
                    )
                    or conflicts
                ):
                    continue
                valid[name] = index
                chemistry.typed.add(index)
                templated.add(index)
                if name == "O" or name in SIDE_ACCEPTORS.get(residue.name, set()):
                    if (atom.formal_charge or 0) <= 0:
                        # Protonated histidine N and carboxylic OH are not acceptors.
                        has_h = any(sites[neighbor].atom.element == "H" for neighbor in neighbors)
                        if not (has_h and residue.name in {"HIS", "ASP", "GLU"}) and (
                            residue.name != "HIS" or histidine_evidence
                        ):
                            chemistry.acceptors.add(index)
            chemistry.protein_residues.append((entry, residue.name, valid))
            missing = [sites[index].atom.id for index in members if index not in templated]
            if missing:
                warnings.append(
                    InteractionWarning(
                        entry_id=entry,
                        code="incomplete_template_sites",
                        message=(
                            f"{residue.name} has incomplete or contradictory observed sites; "
                            "affected typing is skipped."
                        ),
                        atom_ids=missing,
                    )
                )
            for name, index in valid.items():
                if index in disulfides:
                    continue  # Disulfide sulfur is not an unprepared thiol donor.
                if name in SIDE_DONORS.get(residue.name, set()) or (
                    name == "N" and residue.name != "PRO"
                ):
                    hydrogens = [
                        neighbor
                        for neighbor in sites[index].neighbors
                        if sites[neighbor].atom.element == "H" and neighbor in chemistry.typed
                    ]
                    if hydrogens:
                        chemistry.donors[index] = sorted(hydrogens)
                    else:
                        chemistry.missing_hydrogens.add(index)
        # Each supplied connected graph is validated independently: unknown protein
        # bond orders cannot poison or silently supply defaults for a typed ligand.
        protein_members = {
            index
            for residue in structure.residues
            if residue.component_type == "polymer"
            for index in residue_atoms.get(residue.id, [])
        }
        pending = (
            {index for (owner, _), index in indices.items() if owner == entry}
            - templated
            - protein_members
        )
        while pending:
            first_index = min(pending)
            component, frontier = {first_index}, {first_index}
            while frontier:
                frontier = {
                    neighbor for index in frontier for neighbor in sites[index].neighbors
                } - component
                component.update(frontier)
            pending.difference_update(component)
            if component & templated:
                continue
            ids = {sites[index].atom.id for index in component}
            atoms = [atom for atom in structure.atoms if atom.id in ids]
            bonds = [
                bond for bond in structure.bonds if bond.atom_1_id in ids and bond.atom_2_id in ids
            ]
            if any(atom.formal_charge is None for atom in atoms) or any(
                bond.order not in {1, 1.5, 2, 3} and not bond.aromatic for bond in bonds
            ):
                warnings.append(
                    InteractionWarning(
                        entry_id=entry,
                        code="unknown_chemistry",
                        message=(
                            "Unassigned bond orders or formal charges prevent interaction "
                            "typing. Prepare the structure; raw PDB/mmCIF ligands are not "
                            "assigned from names or distances."
                        ),
                        atom_ids=sorted(ids),
                    )
                )
                continue
            positions = [i for i, atom in enumerate(structure.atoms) if atom.id in ids]
            subset = structure.model_copy(
                update={
                    "atoms": atoms,
                    "bonds": bonds,
                    "conformers": [
                        conformer.model_copy(
                            update={"coordinates": [conformer.coordinates[i] for i in positions]}
                        )
                        for conformer in structure.conformers
                    ],
                }
            )
            try:
                mol = normalized_to_mol(subset)
                Chem.SanitizeMol(mol)
                mapped = [indices[(entry, atom.id)] for atom in atoms]
                chemistry.typed.update(mapped)
                chemistry.validated_molecules.append((mol, mapped))
                for match in mol.GetSubstructMatches(cast(Any, Lipinski).HAcceptorSmarts):
                    index = match[0]
                    if mol.GetAtomWithIdx(index).GetFormalCharge() <= 0:
                        chemistry.acceptors.add(mapped[index])
                for match in mol.GetSubstructMatches(cast(Any, Lipinski).HDonorSmarts):
                    donor = mapped[match[0]]
                    hydrogens = [
                        neighbor
                        for neighbor in sites[donor].neighbors
                        if sites[neighbor].atom.element == "H"
                    ]
                    if hydrogens:
                        chemistry.donors[donor] = sorted(hydrogens)
                    else:
                        chemistry.missing_hydrogens.add(donor)
            except (ValueError, RuntimeError):
                warnings.append(
                    InteractionWarning(
                        entry_id=entry,
                        code="invalid_chemistry",
                        message=(
                            "Supplied molecular chemistry fails RDKit validation; affected "
                            "sites are skipped."
                        ),
                        atom_ids=sorted(ids),
                    )
                )
        for index in chemistry.typed:
            site = sites[index]
            if site.reference.structure_id != entry:
                continue
            if (
                site.atom.element == "C"
                and (site.atom.formal_charge or 0) == 0
                and site.neighbors
                and all(
                    sites[neighbor].atom.element in {"C", "H"} and neighbor in chemistry.typed
                    for neighbor in site.neighbors
                )
            ):
                chemistry.hydrophobic.add(index)
        # Explicitly connected water hydrogens are the only water donor evidence.
        for index in chemistry.acceptors:
            if sites[index].reference.structure_id != entry:
                continue
            water_residue = next(
                (r for r in structure.residues if r.id == sites[index].atom.residue_id), None
            )
            if water_residue and water_residue.component_type == "water":
                hydrogens = [
                    neighbor
                    for neighbor in sites[index].neighbors
                    if sites[neighbor].atom.element == "H"
                ]
                if hydrogens:
                    chemistry.donors[index] = sorted(hydrogens)
                else:
                    chemistry.missing_hydrogens.add(index)
        if any(
            sites[index].reference.structure_id == entry for index in chemistry.missing_hydrogens
        ):
            warnings.append(
                InteractionWarning(
                    entry_id=entry,
                    code="explicit_hydrogens_required",
                    message=(
                        "Some donors lack explicit hydrogens: hydrogen bonds require supplied "
                        "explicit H atoms. Use existing hydrogen preparation tools."
                    ),
                    atom_ids=sorted(
                        sites[index].atom.id
                        for index in chemistry.missing_hydrogens
                        if sites[index].reference.structure_id == entry
                    ),
                )
            )
    return chemistry
