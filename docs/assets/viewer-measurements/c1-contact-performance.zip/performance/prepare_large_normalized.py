"""Bounded full-representation/source-size capacity fixture, not chemistry."""
from pathlib import Path
import hashlib
import json
import sys
from time import perf_counter

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "baseline/packages/neistra_core/src"))
from neistra_core.molecular import NormalizedStructureV1

started = perf_counter()
source = ROOT / "fixtures/sparse-100000.json"
structure = NormalizedStructureV1.from_bytes(source.read_bytes())
full = structure.to_bytes()
metadata = {"capacity_padding": ""}
empty_padded = structure.model_copy(update={"metadata": metadata}).to_bytes()
target_bytes = 64 * 1024**2 - 1024
padding = target_bytes - len(empty_padded)
assert padding > 0
structure = structure.model_copy(update={"metadata": {"capacity_padding": "x" * padding}})
data = structure.to_bytes()
assert len(data) == target_bytes
destination = ROOT / "fixtures/sparse-full100000-near64MiB.json"
destination.write_bytes(data)
receipt = {"path": str(destination), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
    "atoms": len(structure.atoms), "fully_populated_normalized_bytes_before_padding": len(full),
    "padding_metadata_bytes": padding, "coordinate_spacing": 4.0, "expected_contacts_cutoff2": 0,
    "scope": "Synthetic sparse capacity input with legal metadata padding, not representative chemistry; tests parsing/memory headroom near proposed64MiB source policy.",
    "preparation_wall_seconds": perf_counter() - started}
(ROOT / "large-normalized-fixture.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
