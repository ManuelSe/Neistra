from pathlib import Path
import sys,json,hashlib,shutil
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent; SNAP=ROOT/'api-snapshot'
for name in ['packages/neistra_demo_plugin/src','packages/neistra_core/src','apps/api/src']:
    sys.path.insert(0,str(SNAP/name))
from neistra_api.database import Base,create_database_engine,create_session_factory
from neistra_api.models import Project,StructureEntry,Artifact
from neistra_api.project_service import project_state,_is_dirty

name=sys.argv[1];fixture=Path(sys.argv[2]);store=ROOT/('api-store-'+name);store.mkdir()
engine=create_database_engine('sqlite:///'+str(store/'store.sqlite'));Base.metadata.create_all(engine)
factory=create_session_factory(engine);data=fixture.read_bytes();molecule=json.loads(data)
digest=hashlib.sha256(data).hexdigest();relative='artifacts/'+digest
(store/'artifacts').mkdir();shutil.copyfile(fixture,store/relative)
project_id='10000000-0000-0000-0000-000000000157';entry_id='20000000-0000-0000-0000-000000000157';artifact_id='30000000-0000-0000-0000-000000000157'
with factory() as session:
    artifact=Artifact(id=artifact_id,sha256=digest,size=len(data),media_type='application/json',filename=fixture.name,relative_path=relative)
    project=Project(id=project_id,name=name,description=None,revision=7,checkpoint_revision=7)
    entry=StructureEntry(id=entry_id,project=project,name=molecule['title'],structure_type=molecule['structure_type'],
        original_filename=fixture.name,source_format='normalized',normalized_data=molecule,
        atom_count=len(molecule['atoms']),atom_ids=[a['id'] for a in molecule['atoms']],bond_count=len(molecule['bonds']),
        residue_count=len(molecule.get('residues',[])),conformer_count=len(molecule['conformers']),warnings=molecule.get('warnings',[]),
        created_at=datetime.now(timezone.utc).replace(tzinfo=None),modified_at=datetime.now(timezone.utc).replace(tzinfo=None),
        next_atom_id=max(a['id'] for a in molecule['atoms'])+1,next_bond_id=max((b['id'] for b in molecule['bonds']),default=0)+1,
        viewer_settings={},visible=True,locked=False,user_metadata={},dirty=False,job_links=[],generated_results=[],
        original_artifact_id=artifact_id,current_artifact_id=artifact_id)
    session.add_all([artifact,project,entry]);session.flush();project.checkpoint_state=project_state(project);session.commit()
    assert not _is_dirty(project)
engine.dispose()
receipt={'fixture':str(fixture),'source_bytes':len(data),'source_sha256':digest,'atoms':len(molecule['atoms']),
    'bonds':len(molecule['bonds']),'project_id':project_id,'entry_id':entry_id,'artifact_id':artifact_id,'store':str(store),
    'project_revision':7,'checkpoint_revision':7,'project_dirty_at_setup':False,'entry_dirty_at_setup':False,
    'original_current_alias':'Synthetic canonical normalized transport fixture; original/current same immutable artifact. Frozen scientific original files remain separately retained.'}
(ROOT/('api-setup-'+name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
