"""Reproduce the primitive experiment's fixed synthetic inputs without overwrites.

Pass a fresh output directory. Real input fixtures come from baseline commit4b8
and their exact hashes are recorded in baseline-receipt.json. This generator
contains no contact-search implementation.
"""
from pathlib import Path
import json
import sys

out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=False)
for mode, sizes in [
    ("sparse", [100, 1000, 10000, 100000]),
    ("grid", [100, 1000, 10000]),
    ("coincident", [100, 500, 1000, 5000]),
]:
    for n in sizes:
        width = round(n ** (1 / 3)) + 1
        coordinates = [
            [i * 4.0, 0.0, 0.0] if mode == "sparse" else
            [(i % width) * 1.5, ((i // width) % width) * 1.5,
             (i // (width * width)) * 1.5] if mode == "grid" else
            [0.0, 0.0, 0.0]
            for i in range(n)
        ]
        data = {
            "schema_version": 1,
            "title": f"Fixed {mode} geometric capacity fixture {n}; not a chemistry model",
            "structure_type": "unknown",
            "source": {"filename": f"{mode}-{n}.json", "format": "normalized",
                       "facts": {"synthetic_capacity_fixture": True}},
            "atoms": [{"id": i + 1, "name": f"C{i + 1}", "element": "C",
                       "coordinates": point, "source_index": i}
                      for i, point in enumerate(coordinates)],
            "bonds": [],
            "conformers": [{"id": 1, "name": "Observed synthetic frame",
                            "coordinates": coordinates}],
        }
        (out / f"{mode}-{n}.json").write_text(json.dumps(data, separators=(",", ":")))
