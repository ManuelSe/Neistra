"""Experimental bounded contact stream; not application implementation.

Uses caller-qualified active coordinates, atom IDs and recorded bond endpoints.
It does not implement source-warning/artifact/API/lifecycle qualification. Limits
are mandatory experimental inputs, not selected product defaults. Returned-neighbor
visits do not bound internal tree traversal; run experiments in a terminable process.
"""

from __future__ import annotations

import math
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from itertools import pairwise
from numbers import Integral
from time import perf_counter

import numpy as np
from numpy.typing import NDArray
from scipy.spatial import cKDTree


@dataclass(frozen=True, slots=True)
class ExperimentalLimits:
    max_input_atoms: int
    max_raw_visits: int
    max_results: int

    def __post_init__(self) -> None:
        for value in (self.max_input_atoms, self.max_raw_visits, self.max_results):
            if isinstance(value, bool) or not isinstance(value, Integral) or value < 0:
                raise ValueError("Experimental limits must be non-negative integers")


@dataclass(frozen=True, slots=True)
class Contact:
    atom_1_id: int
    atom_2_id: int
    distance: float


@dataclass(slots=True)
class SearchStats:
    input_atoms: int = 0
    query_count: int = 0
    max_neighbor_list: int = 0
    raw_visits: int = 0
    retained_results: int = 0
    coordinate_and_bond_seconds: float = 0.0
    tree_seconds: float = 0.0
    query_seconds: float = 0.0
    filter_seconds: float = 0.0
    sort_seconds: float = 0.0
    total_seconds: float = 0.0


@dataclass(frozen=True, slots=True)
class SearchResult:
    contacts: list[Contact]
    stats: SearchStats


class PrototypeRefusal(ValueError):
    def __init__(self, reason: str, message: str, stats: SearchStats) -> None:
        super().__init__(message)
        self.reason = reason
        self.stats = stats


def stream_contacts(
    coordinates: Sequence[Sequence[float]] | NDArray[np.float64],
    atom_ids: Sequence[int],
    recorded_bonds: Iterable[tuple[int, int]],
    *,
    cutoff: float,
    minimum_distance: float,
    limits: ExperimentalLimits,
    leafsize: int = 16,
) -> SearchResult:
    """Return the entire declared contact result or raise without a partial list.

    Coordinates are copied into owned contiguous float64 storage. Sparse atom IDs
    must already be strictly increasing; no ID sorting or molecular reordering is
    performed. All raw neighbors are charged, including self/reverse/bonded/minimum-
    excluded entries. The response contains instrumentation and is not an API DTO.
    """
    started = perf_counter()
    stats = SearchStats(input_atoms=len(atom_ids))

    def refuse(reason: str, message: str) -> None:
        stats.total_seconds = perf_counter() - started
        raise PrototypeRefusal(reason, message, stats)

    if not math.isfinite(cutoff) or cutoff <= 0:
        refuse("query", "Cutoff must be positive and finite")
    if not math.isfinite(minimum_distance) or minimum_distance < 0 or minimum_distance >= cutoff:
        refuse("query", "Minimum must be finite and satisfy 0 <= minimum < cutoff")
    if isinstance(leafsize, bool) or not isinstance(leafsize, Integral) or leafsize < 1:
        refuse("query", "Leaf size must be a positive integer")
    n = stats.input_atoms
    if n > limits.max_input_atoms:
        refuse("capacity.input", "Experimental input-atom limit exceeded")
    if len(coordinates) != n:
        refuse("geometry", "Coordinate count must equal atom count")
    if any(isinstance(v, bool) or not isinstance(v, Integral) or v < 1 for v in atom_ids):
        refuse("identity", "Atom IDs must be positive integers")
    ids = tuple(int(v) for v in atom_ids)
    if any(first >= second for first, second in pairwise(ids)):
        refuse("identity", "Atom IDs must already be strictly increasing")
    try:
        points = np.array(coordinates, dtype=np.float64, copy=True, order="C")
    except (TypeError, ValueError, OverflowError) as error:
        refuse("geometry", f"Coordinates cannot be represented as float64: {error}")
    if n == 0 and points.shape == (0,):
        points = points.reshape((0, 3))
    if points.shape != (n, 3) or not np.isfinite(points).all():
        refuse("geometry", "Coordinates must be finite float64 (N, 3)")
    # Refuse extents outside representable component arithmetic before a tree
    # tracker can overflow. These are finite source coordinates, not bad chemistry.
    if n:
        for axis in range(3):
            span = float(points[:, axis].max()) - float(points[:, axis].min())
            if not math.isfinite(span):
                refuse("numerical", "Coordinate extent exceeds float64 search range")
    points.flags.writeable = False
    known_ids = set(ids)
    bonded: set[tuple[int, int]] = set()
    for first, second in recorded_bonds:
        if first not in known_ids or second not in known_ids or first == second:
            refuse("identity", "Recorded bond must reference distinct input atoms")
        bonded.add((min(first, second), max(first, second)))
    stats.coordinate_and_bond_seconds = perf_counter() - started
    if n < 2:
        stats.total_seconds = perf_counter() - started
        return SearchResult([], stats)

    tree_started = perf_counter()
    try:
        tree = cKDTree(points, leafsize=int(leafsize), copy_data=False, boxsize=None)
    except ValueError as error:
        refuse("numerical", f"Tree cannot represent this coordinate extent: {error}")
    stats.tree_seconds = perf_counter() - tree_started
    contacts: list[Contact] = []
    for first_index in range(n):
        if stats.raw_visits >= limits.max_raw_visits:
            refuse("capacity.raw", "Experimental raw-neighbor limit exhausted")
        query_started = perf_counter()
        stats.query_count += 1
        try:
            neighbors = tree.query_ball_point(
                points[first_index],
                cutoff,
                p=np.inf,
                eps=0.0,
                workers=1,
                return_sorted=False,
            )
        except ValueError as error:
            refuse("numerical", f"Tree query exceeds its numerical range: {error}")
        stats.query_seconds += perf_counter() - query_started
        count = len(neighbors)
        stats.max_neighbor_list = max(stats.max_neighbor_list, count)
        stats.raw_visits += count
        if stats.raw_visits > limits.max_raw_visits:
            refuse("capacity.raw", "Experimental raw-neighbor limit exceeded")
        filter_started = perf_counter()
        first_id = ids[first_index]
        first = points[first_index]
        for second_index in neighbors:
            if second_index <= first_index:
                continue
            second_id = ids[second_index]
            if (first_id, second_id) in bonded:
                continue
            second = points[second_index]
            dx = float(first[0]) - float(second[0])
            dy = float(first[1]) - float(second[1])
            dz = float(first[2]) - float(second[2])
            separation = max(math.hypot(dx, dy, dz), abs(dx), abs(dy), abs(dz))
            if not math.isfinite(separation):
                refuse("numerical", "Contact separation exceeds float64 range")
            if not minimum_distance <= separation <= cutoff:
                continue
            if len(contacts) >= limits.max_results:
                refuse("capacity.results", "Experimental retained-result limit exceeded")
            contacts.append(Contact(first_id, second_id, separation))
            stats.retained_results += 1
        stats.filter_seconds += perf_counter() - filter_started
    sort_started = perf_counter()
    contacts.sort(key=lambda contact: (contact.distance, contact.atom_1_id, contact.atom_2_id))
    stats.sort_seconds = perf_counter() - sort_started
    stats.total_seconds = perf_counter() - started
    return SearchResult(contacts, stats)
