# Actual contact API resource qualification — scoped C1 evidence

PASS for the measured API resource scope. This is not final157feature approval.

The actual working API/core was copied BEFORE imports into api-snapshot:209source/config files, including uncommitted production changes. Receipt SHA256 c530d0f7f9de412abd1f943e670a2afbbe6b6e808119e0aa0a5989b4b5f3a69c. Every frozen byte remains unchanged; critical parent/child import origins point inside this snapshot. This is not qualification of HEAD4b8 alone.

Twelve fresh corrected ASGI HTTP operations complete under the unchanged candidate default policy: nine HTTP200 and three expected whole-operation HTTP413capacity refusals. Three repetitions per case, fresh APIparent+spawned child per repetition, hot filesystem cache. Setup creates canonical normalized artifact and matching SQLite entry/checkpoint in a separate process, avoiding a full molecular model in the APIparent. Original/current point to the same immutable normalized transport fixture; original scientific input files remain separately retained. This matrix does not replace import/export/original-upload workflow qualification.

| Actual API case | Complete rows / response bytes | HTTP request seconds min / median / max | Parent response peak | Child peak |
|---|---|---|---|---|
|1STP1001,10Å|67465 /12732967|1.147 /1.151 /1.173|203.55MiB|169.58MiB|
|1AON58870,3Å|128466 /24810069|2.858 /2.866 /2.962|216.61MiB|564.97MiB|
|100k sparse,67107840-byte source|0 /2|1.708 /1.745 /1.983|192.55MiB|591.84MiB|
|1AON58870,10Å|whole413 /98-byte error|1.948 /2.057 /2.066|192.97MiB|564.72MiB|

All successful bodies match the independently frozen prototype's COMPLETE atom-pair and exact-distance outputs after measurement. Every reference contains the real36-character entry UUID and the actual typed producer determines encoding. Count, range, strict sorting, health before/after, wholeDB SHA, revision/checkpoint/dirty/history/artifact rows, and immutable file hashes verify. Every child is reaped; operation directories are removed and admission is released before return. The expected refusal publishes no partial list.

For1AON3Å the child spends approximately0.025s verifying source bytes/SHA,0.403–0.410s parsing/domain validation,1.104–1.152s in the core including sorting, and0.574–0.580s in typed row validation/incremental JSON/fsync. Spawn/import, coordinator and cleanup are included in the total HTTP request. Parent metadata sessions, verified output read, recheck and reaping are timed separately in api-summary.json; capture-total includes capture invoked during recheck, so these subphases overlap.

Actual APIparent baseline is approximately189–190MiB. Its peak reaches216.61MiB for the24.81MB body and192.55MiB for the near64MiB input producing an empty body: the parent does not load its full normalized SQLite JSON or decode/revalidate a whole response model. Post-request CLIENT JSON decoding raises1AON parent/client high water to342.93MiB, separately attributed; loading an additional expected-output list for semantic comparison occurs later still. No such client-memory cost is folded into the API response phase.

The first twelve operations were functionally successful but a benchmark precheck using SQLite LENGTH on large JSON/checkpoint columns raised parent VmHWM before the request. Preserve api-results-prebaseline-correction.json, scripts, logs and api-baseline-correction.json. The final fresh twelve remove that LOB query, use minimal metadata columns plus a bounded-buffer wholeDB hash, and capture baseline AFTER invariance checking. No production change or limit increase resolved this instrumentation confound.

The observed maximum child RSS is591.84MiB, leaving approximately1.73times headroom under the1GiB RSS policy. Peak virtual mapping approaches1.94GiB:1GiB RSS must not become a1GiB address-space ceiling. The maximum successful request is2.962s against15s lifetime. These results support retaining candidate100katoms/64MiBsource/2Mraw/250kresults/64MiBresponse/15s/1GiBRSS for scientific/architecture reconciliation; no policy was relaxed. They are not guarantees for every permitted source shape, host or concurrent application load. RSS monitoring is not a formal hard allocation bound.

The sole later backend difference was independently inspected: contact_service._capture now maps malformed immutable descriptor construction to typed422. It preserves all valid-input paths measured here. Scoped performance evidence remains applicable to that correction; final source reconciliation is still required. Current frontend changes are outside this API snapshot and assessment.

Limits: ASGI transport runs in-process, so TCP/browser buffering is unmeasured; no native/presented-frame or strict reference-host timing claim. Three samples do not establish robust tail latency. Held-operation health/cancellation/busy/repeated-reaping behavior is separately tested by root, not established by this success/capacity matrix. Broader157application behavior, exact/one-over production tests, complete release gates and seven-role final-candidate approval remain required. No repository edits or sub-agents were used.
