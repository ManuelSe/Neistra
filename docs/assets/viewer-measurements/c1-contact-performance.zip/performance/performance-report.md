# Contact capacity exploration — issue157

This is pre-implementation measurement, not application verification or selection of product defaults. The frozen baseline is4b8ae716f382d67efe0823c007a079a6a278ddce. The independently prepared scientific prototype is frozen at SHA0d911355dcb17353cdd565203754c7cb9261892869f040255fbde568a5a41698. No repository source/docs or host settings were changed.

117 isolated processes complete:111 successful complete results and6 intended complete capacity refusals, zero unexpected errors, timeouts or memory kills. Three repetitions per case/method. All45 complete baseline/prototype comparisons have identical pair membership; maximum distance difference is1.7763568394002505e-15Å, consistent with the explicitly declared stable-distance refinement. The scientific specialist's exact-source tiny oracle receipt independently records132 successful checks+8 refusal controls, maximum20sites; it is reused, not rerun by this reviewer. Every successful response size/hash verifies. Repeated result bytes/work are deterministic.

| Prototype workload | Raw returned neighbors / maximum list | Results / exact API JSON bytes | Median core / whole cold process | Maximum process RSS |
|---|---|---|---|---|
|1STP1001,cutoff10Å|221793 /414|67465 /12732967|0.160s /0.851s|142.75MiB|
|1AON58870,current normalized,cutoff2Å|268012 /10|203 /39327|0.492s /1.686s|486.23MiB|
|1AON58870,current normalized,cutoff3Å|668568 /24|128466 /24810069|0.915s /2.615s|503.00MiB|
|1000coincident,minimum0.5Å|1000000 /1000|0 /2|0.307s /0.648s|72.74MiB|
|100000sparse,minimal normalized|100000 /1|0 /2|0.592s /1.541s|377.17MiB|
|100000sparse,full normalized+metadata near64MiB|100000 /1|0 /2|0.580s /1.644s|513.02MiB|

These are portable observations on a shared Ryzen7 8845HS/Linux host with other applications active, NumPy2.4.6/SciPy1.18.0/Python3.12.3. Cold means a fresh process/imports; OS file cache is warm. The JSON summary retains min/median/p95/max and every phase for each three-sample group; n=3 is not a robust tail-latency estimate. No presented-frame or strict reference-host claim.

The response serializer uses the actual successful /contacts list shape with two nested atom refs, each carrying a36-character entry UUID, and distance; compact stdlib JSON, allow_nan=False. It charges brackets/commas and each encoded record before write without materializing a complete DTO list. Its exact bytes are not tuple/short-ID estimates. Actual API parent parsing/Pydantic/response-model allocations are NOT represented by this harness.

The old dense1000 path allocates499500global pairs/7992000ndarray bytes before minimum exclusion, median1.025s core/max80.31MiB process RSS; streaming retains at most1000neighbors at once, median0.307s/max72.74MiB. Conversely, sparse100k baseline core is0.0282s while streaming is0.592s. Streaming trades per-point overhead for unconditional bounded candidate storage; do not claim a universal speedup.

Whole-refusal controls:5000coincident points with an experimental2M raw limit refuse after400queries/2M raw visits, zero retained results, median1.116s core. Actual current-normalized1AON at10Å with experimental250k result limit refuses after2917queries/773577raw visits/250000 retained internal records, median0.763s core/1.970s process; no successful response or partial list is published. Do not claim all cutoffs complete. The current normalized1AON source is30039539bytes; the full100k metadata-padding fixture is67107840bytes, explicitly synthetic source/memory stress.

Recommendations for science/architecture agreement, NOT accepted defaults:

- Input100000atoms and immutable source64MiB: admit before coordinate/tree allocation; actual source parsing must remain memory-bounded. Both the sparse100k and near64MiB full-representation case complete; these do not certify every bond/annotation/metadata shape.
- Charge at most2000000raw returned neighbors before exclusions, with each single list bounded by admitted inputN; this does not bound internal tree traversal.
- Retain at most250000results and serialize at most64MiB incrementally. Actual128466/24.81MB ordinary3Å output rules out a100k/20k result ceiling without capacity reduction. Result and response limits are independent.
- Whole-operation deadline15s as a candidate production lifetime policy, with admission held through termination/reaping/cleanup. It leaves about5.6times the observed worst current-normalized1AON3Å whole-process time; it is not an all-hardware latency guarantee.
- Qualify a1GiB child RSS target: measured maximum is513.02MiB, approximately2times headroom. RSS supervision is not a hard allocation guarantee or an RLIMIT_AS recommendation. Inspect actual child virtual mappings and service parent/worker memory before selecting enforcement; repeated cancellation/shutdown must reap before releasing admission.

Before accepting these values, qualify the actual immutable-file worker and API parent through size/SHA verification, normalized parsing, result transport validation, Pydantic/response serialization, health responsiveness, concurrent busy refusal and repeated cancellation. Metadata/bond complexity can dominate beyond the atom array, and the parent may hold several output representations simultaneously.

Exact/one-over test plan: parameterized tiny policy instances should prove3atoms admit vs4refuse before coordinate allocation; exact source bytes vsone extra byte refuse before a whole read; dense1000exact1M raw visits admit vs999999 refuse as a whole; one known result with cap1admits vs0refuses; exact serialized DTO byte count admits vsone byte less refuses before publication; response file overflow cleans owned partial output. Exercise a held worker at deadline and bounded memory stress, verifying no partial success, admission retained through reaping, exact error type and restored health. These failure paths remain production implementation work, not established by the array prototype.
