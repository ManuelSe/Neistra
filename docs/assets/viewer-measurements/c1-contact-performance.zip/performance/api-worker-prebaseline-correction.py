"""Real frozen ASGI API qualification, with narrow timing wrappers only."""
from time import perf_counter
START=perf_counter()
import asyncio,json,hashlib,os,sqlite3,sys,threading,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent; SNAP=ROOT/'api-snapshot'
for name in ['packages/neistra_demo_plugin/src','packages/neistra_core/src','apps/api/src']:
    sys.path.insert(0,str(SNAP/name))

def rss(pid=None,field='VmRSS'):
    try:return int(next(x.split()[1] for x in Path('/proc/'+str(pid or os.getpid())+'/status').read_text().splitlines() if x.startswith(field+':')))*1024
    except (FileNotFoundError,StopIteration,ProcessLookupError):return 0

def digest_file(path):
    result=hashlib.sha256()
    with path.open('rb') as stream:
        while data:=stream.read(65536):result.update(data)
    return result.hexdigest()

def instrumented_child(connection,directory,snapshot_json):
    started=perf_counter(); phases={}
    import neistra_api.contact_execution_worker as worker
    real_send=worker._send
    def timed(name,function):
        def wrapper(*args,**kwargs):
            tick=perf_counter()
            try:return function(*args,**kwargs)
            finally:phases[name]=phases.get(name,0)+perf_counter()-tick
        return wrapper
    worker.read_immutable_input=timed('verify_source_read_sha',worker.read_immutable_input)
    real_model=worker.NormalizedStructureV1
    class StructureProxy:
        model_validate_json=staticmethod(timed('normalized_parse_and_domain_validation',real_model.model_validate_json))
    worker.NormalizedStructureV1=StructureProxy
    worker.close_contacts=timed('core_including_coordinate_tree_filter_sort',worker.close_contacts)
    worker.write_contact_response=timed('typed_validation_incremental_json_fsync',worker.write_contact_response)
    def send(channel,message):
        snapshot=json.loads(snapshot_json)
        report={'pid':os.getpid(),'phases_seconds':phases,'total_child_target_to_control_seconds':perf_counter()-started,
            'peak_rss_bytes':rss(field='VmHWM'),'rss_at_control_bytes':rss(),'vm_peak_bytes':rss(field='VmPeak'),
            'completion':message.model_dump(),'origins':{name:module.__file__ for name,module in sys.modules.copy().items()
                if name in ['neistra_api.contact_execution_worker','neistra_api.contact_execution_data','neistra_api.schemas','neistra_core.contacts','neistra_core.molecular']}}
        (ROOT/('api-child-'+snapshot['operation_id']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
        return real_send(channel,message)
    worker._send=send
    worker.run_contact_child(connection,directory,snapshot_json)

def state(store):
    with sqlite3.connect(store/'store.sqlite') as db:
        project=db.execute('select id,revision,checkpoint_revision,length(checkpoint_state) from projects').fetchall()
        entry=db.execute('select id,atom_count,dirty,current_artifact_id,original_artifact_id,length(normalized_data) from structure_entries').fetchall()
        counts={table:db.execute('select count(*) from '+table).fetchone()[0] for table in ['projects','structure_entries','artifacts','command_records','measurements','jobs']}
        artifacts=db.execute('select id,sha256,size,relative_path from artifacts').fetchall()
    files={str(p.relative_to(store)):digest_file(p) for p in (store/'artifacts').rglob('*') if p.is_file()}
    return {'project':project,'entry':entry,'row_counts':counts,'artifact_rows':artifacts,'canonical_files':files,
            'database_sha256':digest_file(store/'store.sqlite')}

async def measure(name,cutoff):
    setup=json.loads((ROOT/('api-setup-'+name+'.json')).read_text());store=Path(setup['store'])
    os.environ['NEISTRA_DATA_DIR']=str(store);os.environ['NEISTRA_DATABASE_URL']='sqlite:///'+str(store/'store.sqlite')
    tick=perf_counter()
    import httpx
    import neistra_api.main as main
    import neistra_api.contact_service as service
    from neistra_api.settings import Settings
    imports=perf_counter()-tick
    app=main.create_app(Settings(data_dir=store,database_url='sqlite:///'+str(store/'store.sqlite')))
    report={'name':name,'cutoff':cutoff,'api_import_seconds':imports,'setup':setup,'parent_pid':os.getpid(),
        'snapshot_receipt_sha256':digest_file(ROOT/'api-snapshot-receipt.json'),'phases_seconds':{},
        'policy':app.state.contact_reads.policy.model_dump(),'parent_baseline_rss_bytes':rss(),
        'parent_baseline_high_water_bytes':rss(field='VmHWM')}
    phases=report['phases_seconds'];coordinator=app.state.contact_reads
    service.run_contact_child=instrumented_child
    for attr,key in [('_capture','capture_metadata_sessions'),('_recheck','recheck_metadata_sessions')]:
        original=getattr(coordinator,attr)
        def wrapper(*a,_original=original,_key=key,**kw):
            t=perf_counter()
            try:return _original(*a,**kw)
            finally:phases[_key]=phases.get(_key,0)+perf_counter()-t
        setattr(coordinator,attr,wrapper)
    original_read=service.read_verified_file
    def verified_read(*a,**kw):
        t=perf_counter()
        try:return original_read(*a,**kw)
        finally:phases['parent_verified_response_read_sha']=perf_counter()-t
    service.read_verified_file=verified_read
    original_cleanup=coordinator._cleanup
    async def cleanup(*a,**kw):
        t=perf_counter()
        try:return await original_cleanup(*a,**kw)
        finally:phases['cleanup_reap_remove']=perf_counter()-t
    coordinator._cleanup=cleanup
    before=state(store);report['state_before']=before
    stop=threading.Event();samples=[];pids=set()
    def monitor():
        while not stop.wait(.01):
            active=coordinator._active;pid=None
            try:pid=active.process.pid if active and active.process else None
            except ValueError:pass
            if pid:pids.add(pid)
            samples.append({'seconds':perf_counter(),'parent_rss':rss(),'child_pid':pid,'child_rss':rss(pid) if pid else 0})
    monitoring=threading.Thread(target=monitor,daemon=True)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://api-test') as client:
            assert (await client.get('/api/v1/health')).status_code==200
            monitoring.start();t=perf_counter()
            response=await client.post('/api/v1/projects/'+setup['project_id']+'/contacts',json={
                'entry_id':setup['entry_id'],'expected_artifact_id':setup['artifact_id'],'cutoff':cutoff,'minimum_distance':.5})
            phases['complete_asgi_http_request_to_bytes']=perf_counter()-t
            report['http_status']=response.status_code;report['response_bytes']=len(response.content)
            report['response_sha256']=hashlib.sha256(response.content).hexdigest()
            report['parent_response_phase_high_water_bytes']=rss(field='VmHWM')
            stop.set();monitoring.join()
            report['parent_response_phase_sampled_peak_bytes']=max([x['parent_rss'] for x in samples]+[report['parent_baseline_rss_bytes']])
            report['child_sampled_peak_bytes']=max([x['child_rss'] for x in samples]+[0])
            report['child_pids']=sorted(pids)
            report['staging_dirs_after']=list(map(str,store.glob('contact-read-*')))
            report['admission_released_after']=coordinator._active is None
            report['child_pid_reaped_after']={str(pid):not Path('/proc/'+str(pid)).exists() for pid in pids}
            t=perf_counter();rows=response.json();phases['post_measure_client_json_semantics']=perf_counter()-t
            report['parent_after_client_json_high_water_bytes']=rss(field='VmHWM')
            if response.status_code==200:
                expected={'1aon':128466,'1stp':67465,'sparse64':0}[name]
                assert len(rows)==expected
                previous=None
                for row in rows:
                    assert len(row['atom_1']['structure_id'])==36 and row['atom_1']['structure_id']==setup['entry_id']==row['atom_2']['structure_id']
                    assert row['atom_1']['atom_id']<row['atom_2']['atom_id']
                    assert .5<=row['distance']<=cutoff
                    key=(row['distance'],row['atom_1']['atom_id'],row['atom_2']['atom_id'])
                    assert previous is None or previous<key;previous=key
                report['semantic_count']=len(rows);report['first_last_rows']=rows[:1]+rows[-1:]
                expected_name={'1aon':'1aon-normalized-cut3-r1-prototype.json','1stp':'1stp1001-cut10-r1-prototype.json','sparse64':'sparse-full100000-near64MiB-r1-prototype.json'}[name]
                t=perf_counter();expected_rows=json.loads((ROOT/'responses'/expected_name).read_text())
                assert len(expected_rows)==len(rows)
                for observed,expected_row in zip(rows,expected_rows):
                    assert observed['atom_1']['atom_id']==expected_row['atom_1']['atom_id']
                    assert observed['atom_2']['atom_id']==expected_row['atom_2']['atom_id']
                    assert observed['distance']==expected_row['distance']
                report['complete_expected_pair_distance_parity']=True
                phases['post_measure_expected_output_parity']=perf_counter()-t
                report['parent_after_extra_parity_client_high_water_bytes']=rss(field='VmHWM')
                del expected_rows
            else:
                assert response.status_code==413;report['refusal']=rows
            del rows
            report['health_after']=(await client.get('/api/v1/health')).status_code
    after=state(store);report['state_after']=after;assert before==after
    report['project_dirty_revision_history_artifacts_unchanged']=True
    report['origins']={name:module.__file__ for name,module in sys.modules.copy().items()
        if name in ['neistra_api.main','neistra_api.contact_service','neistra_api.contact_execution_worker','neistra_api.contact_execution_data','neistra_core.contacts','neistra_core.molecular']}
    assert all(str(SNAP) in p for p in report['origins'].values())
    report['parent_process_wall_seconds']=perf_counter()-START
    print(json.dumps(report),flush=True)

if __name__=='__main__':asyncio.run(measure(sys.argv[1],float(sys.argv[2])))
