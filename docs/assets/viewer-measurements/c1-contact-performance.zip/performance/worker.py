"""Isolated exploratory measurement; no application implementation or defaults."""
from time import perf_counter
START = perf_counter()
import argparse
import builtins
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "baseline/packages/neistra_core/src"))
parser = argparse.ArgumentParser()
parser.add_argument("--case", required=True)
parser.add_argument("--method", choices=["baseline", "prototype"], required=True)
parser.add_argument("--fixture", required=True)
parser.add_argument("--cutoff", type=float, default=2.0)
parser.add_argument("--minimum", type=float, default=0.5)
parser.add_argument("--raw-limit", type=int, default=20_000_000)
parser.add_argument("--result-limit", type=int, default=500_000)
parser.add_argument("--input-limit", type=int, default=100_000)
parser.add_argument("--response-limit", type=int, default=268_435_456)
args = parser.parse_args()
phases = {}
report = {"case": args.case, "method": args.method, "cutoff": args.cutoff,
          "minimum_distance": args.minimum, "experiment_limits_not_product_defaults": {
              "input_atoms": args.input_limit, "raw_visits": args.raw_limit,
              "results": args.result_limit, "response_bytes": args.response_limit,
              "kernel_wall_seconds": 30, "parent_peak_rss_stop_bytes": 2 * 1024**3},
          "pid": os.getpid(), "phases_seconds": phases}
INITIAL_USAGE = resource.getrusage(resource.RUSAGE_SELF)

def resident_kib(field="VmHWM"):
    return int(next(line.split()[1] for line in Path("/proc/self/status").read_text().splitlines()
                    if line.startswith(field + ":")))

report["initial_peak_rss_kib"] = resident_kib()

def timeout(signum, frame):
    raise TimeoutError("Experimental kernel exceeded 30-second wall bound")

def record_report():
    report["worker_wall_seconds"] = perf_counter() - START
    report["peak_rss_kib"] = resident_kib()
    report["resource_ru_maxrss_kib"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    report["cpu_seconds_since_standard_imports"] = (resource.getrusage(resource.RUSAGE_SELF).ru_utime
        + resource.getrusage(resource.RUSAGE_SELF).ru_stime - INITIAL_USAGE.ru_utime - INITIAL_USAGE.ru_stime)
    print(json.dumps(report, allow_nan=False, sort_keys=True), flush=True)

try:
    t = perf_counter()
    import numpy as np
    import scipy
    import neistra_core.contacts as base
    from neistra_core.molecular import NormalizedStructureV1
    phases["cold_scientific_imports"] = perf_counter() - t
    report["versions"] = {"python": sys.version.split()[0], "numpy": np.__version__, "scipy": scipy.__version__}
    fixture = Path(args.fixture)
    t = perf_counter()
    data = fixture.read_bytes()
    report["fixture"] = {"path": str(fixture), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    phases["source_read_and_sha"] = perf_counter() - t
    t = perf_counter()
    if fixture.suffix == ".json":
        structure = NormalizedStructureV1.from_bytes(data)
    else:
        from neistra_core.adapters.base import ImportOptions
        from neistra_core.adapters.defaults import create_default_registry
        parsed = create_default_registry().for_filename(fixture.name).parse(data, fixture.name, ImportOptions())
        if len(parsed.structures) != 1:
            raise ValueError("Expected exactly one normalized structure")
        structure = parsed.structures[0]
    phases["parse_including_adapter_import_if_needed"] = perf_counter() - t
    report["input_atoms"] = len(structure.atoms)
    report["recorded_bonds"] = len(structure.bonds)
    report["warnings"] = [warning.code for warning in structure.warnings]
    report["active_conformer_id"] = structure.active_conformer_id
    report["rss_after_parse_kib"] = resident_kib()
    if len(structure.atoms) > args.input_limit:
        raise ValueError("Experiment input guard before kernel")
    signal.signal(signal.SIGALRM, timeout)
    if args.method == "baseline":
        # Dense old global allocation is allowed only through N=1001. Larger
        # frozen sparse fixtures have an analytically empty 2A candidate set.
        if len(structure.atoms) > 1001 and not (fixture.name.startswith("sparse-") and args.cutoff < 4):
            raise ValueError("Unsafe baseline experiment refused before query_pairs")
        metrics = {"tree_seconds": 0.0, "query_pairs_seconds": 0.0, "sort_seconds": 0.0}
        native_tree = base.cKDTree
        class MeasuredTree:
            def __init__(self, *a, **kw):
                tick = perf_counter()
                self.tree = native_tree(*a, **kw)
                metrics["tree_seconds"] += perf_counter() - tick
            def query_pairs(self, *a, **kw):
                tick = perf_counter()
                pairs = self.tree.query_pairs(*a, **kw)
                metrics["query_pairs_seconds"] += perf_counter() - tick
                metrics["candidate_pairs_before_filters"] = len(pairs)
                metrics["global_pair_array_bytes"] = pairs.nbytes
                return pairs
        def measured_sorted(values, *a, **kw):
            if isinstance(values, list) and (not values or isinstance(values[0], base.Contact)):
                tick = perf_counter()
                answer = builtins.sorted(values, *a, **kw)
                metrics["sort_seconds"] += perf_counter() - tick
                return answer
            return builtins.sorted(values, *a, **kw)
        base.cKDTree = MeasuredTree
        base.sorted = measured_sorted
        signal.setitimer(signal.ITIMER_REAL, 30)
        t = perf_counter()
        contacts = base.close_contacts(structure, args.cutoff, minimum_distance=args.minimum)
        phases["core_total_including_sort"] = perf_counter() - t
        signal.setitimer(signal.ITIMER_REAL, 0)
        phases.update({"core_" + k: v for k, v in metrics.items() if k.endswith("_seconds")})
        phases["core_other_validation_coordinate_bond_filter"] = phases["core_total_including_sort"] - sum(v for k, v in metrics.items() if k.endswith("_seconds"))
        report["kernel_metrics"] = metrics
    else:
        t = perf_counter()
        import contact_prototype as prototype
        phases["prototype_module_import"] = perf_counter() - t
        report["prototype_sha256"] = hashlib.sha256(Path(prototype.__file__).read_bytes()).hexdigest()
        t = perf_counter()
        ids = [atom.id for atom in structure.atoms]
        bonds = [(bond.atom_1_id, bond.atom_2_id) for bond in structure.bonds]
        coordinates = structure.active_coordinates
        phases["extract_qualified_geometry_interface"] = perf_counter() - t
        signal.setitimer(signal.ITIMER_REAL, 30)
        t = perf_counter()
        try:
            outcome = prototype.stream_contacts(coordinates, ids, bonds, cutoff=args.cutoff,
                minimum_distance=args.minimum, limits=prototype.ExperimentalLimits(
                    args.input_limit, args.raw_limit, args.result_limit))
        except prototype.PrototypeRefusal as error:
            report.update(status="complete_refusal", refusal_reason=error.reason,
                          refusal_message=str(error), kernel_metrics=dataclasses.asdict(error.stats))
            phases["core_total_including_sort"] = perf_counter() - t
            signal.setitimer(signal.ITIMER_REAL, 0)
            record_report()
            sys.exit(0)
        phases["core_total_including_sort"] = perf_counter() - t
        signal.setitimer(signal.ITIMER_REAL, 0)
        contacts = outcome.contacts
        report["kernel_metrics"] = dataclasses.asdict(outcome.stats)
    report["retained_results"] = len(contacts)
    report["rss_after_core_kib"] = resident_kib()
    t = perf_counter()
    # Stream exact successful API shape without first materializing all DTOs or
    # a full JSON value. The byte guard is experimental harness protection.
    destination = ROOT / "responses" / (args.case + "-" + args.method + ".json")
    partial = destination.with_suffix(".partial")
    source_id = "00000000-0000-0000-0000-000000000157"
    total_bytes = 2
    digest = hashlib.sha256()
    with partial.open("wb") as output:
        output.write(b"["); digest.update(b"[")
        for index, contact in enumerate(contacts):
            item = {"atom_1": {"structure_id": source_id, "atom_id": contact.atom_1_id},
                    "atom_2": {"structure_id": source_id, "atom_id": contact.atom_2_id},
                    "distance": contact.distance}
            encoded = (b"," if index else b"") + json.dumps(item, separators=(",", ":"), allow_nan=False).encode()
            if total_bytes + len(encoded) > args.response_limit:
                raise OverflowError("Experimental serialized response-byte limit exceeded")
            total_bytes += len(encoded)
            output.write(encoded); digest.update(encoded)
        output.write(b"]"); digest.update(b"]")
    partial.replace(destination)
    phases["incremental_api_shape_json_serialization"] = perf_counter() - t
    report["response"] = {"path": str(destination), "bytes": total_bytes, "sha256": digest.hexdigest()}
    report["status"] = "complete_success"
    record_report()
except BaseException as error:
    if isinstance(error, SystemExit):
        raise
    signal.setitimer(signal.ITIMER_REAL, 0)
    report.update(status="experiment_failure", exception=type(error).__name__, error=str(error))
    record_report()
    sys.exit(2)
