"""Prepare current-normalized transport inputs from the frozen fixture parser."""
from pathlib import Path
import hashlib
import json
import resource
import sys
from time import perf_counter

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "baseline/packages/neistra_core/src"))
from neistra_core.adapters.base import ImportOptions
from neistra_core.adapters.defaults import create_default_registry

receipts = []
for relative in ["complex/1stp.pdb", "surfaces/1aon.cif"]:
    source = ROOT / "baseline/tests/fixtures" / relative
    start = perf_counter()
    data = source.read_bytes()
    result = create_default_registry().for_filename(source.name).parse(data, source.name, ImportOptions())
    assert len(result.structures) == 1
    structure = result.structures[0]
    parsed = perf_counter()
    payload = structure.to_bytes()
    destination = ROOT / "fixtures" / (source.stem + "-current.normalized.json")
    destination.write_bytes(payload)
    receipts.append({"source": str(source), "source_sha256": hashlib.sha256(data).hexdigest(),
        "normalized_fixture": str(destination), "normalized_bytes": len(payload),
        "normalized_sha256": hashlib.sha256(payload).hexdigest(), "atoms": len(structure.atoms),
        "bonds": len(structure.bonds), "parse_seconds": parsed - start,
        "normalize_and_write_seconds": perf_counter() - parsed,
        "preparation_peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "scope": "One-time test preparation; raw scientific originals remain frozen and unchanged."})
    print(json.dumps(receipts[-1]), flush=True)
    del result, structure, payload
(ROOT / "normalized-transport-fixtures.json").write_text(json.dumps(receipts, indent=2) + "\n")
