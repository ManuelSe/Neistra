from pathlib import Path
import subprocess,json,hashlib,time

ROOT=Path(__file__).resolve().parent
PYTHON='/datadisk/dev/neistra-worktrees/issue-11-ligand-information/.venv/bin/python'
manifest={'worker_sha256':hashlib.sha256((ROOT/'api-worker.py').read_bytes()).hexdigest(),
    'snapshot_receipt_sha256':hashlib.sha256((ROOT/'api-snapshot-receipt.json').read_bytes()).hexdigest(),
    'repeats':3,'cases':[('1stp',10),('1aon',3),('sparse64',2),('1aon',10)],
    'scope':'Actual frozen production ASGI API path under unchanged default candidate policy; instrumentation-only narrow timing wrappers. Client semantic decoding occurs after timed response.'}
(ROOT/'api-run-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
reports=[]
for repeat in range(1,4):
    for name,cutoff in manifest['cases']:
        tag=f'api-qualified-{name}-cut{cutoff}-r{repeat}'
        before_children=set(ROOT.glob('api-child-*.json'))
        with (ROOT/(tag+'.stdout')).open('wb') as out,(ROOT/(tag+'.stderr')).open('wb') as err:
            started=time.perf_counter()
            child=subprocess.Popen([PYTHON,str(ROOT/'api-worker.py'),name,str(cutoff)],stdout=out,stderr=err,cwd=ROOT)
            exit_code=child.wait(timeout=60)
        stdout=(ROOT/(tag+'.stdout')).read_text().splitlines()
        if exit_code or not stdout:
            raise SystemExit(f'Failed realAPI qualification {tag},exit{exit_code}; preserve logs, do not raise policy limits')
        report=json.loads(stdout[-1]);report['repeat']=repeat;report['parent_launch_to_exit_seconds']=time.perf_counter()-started
        profiles=set(ROOT.glob('api-child-*.json'))-before_children
        assert len(profiles)==1
        profile_path=profiles.pop();profile=json.loads(profile_path.read_text());assert profile['pid'] in report['child_pids']
        report['child_profile']=profile;report['child_profile_path']=str(profile_path)
        assert report['http_status']==(413 if name=='1aon' and cutoff==10 else 200)
        assert not report['staging_dirs_after'] and report['admission_released_after']
        assert all(report['child_pid_reaped_after'].values()) and report['health_after']==200
        assert report['project_dirty_revision_history_artifacts_unchanged']
        reports.append(report);(ROOT/'api-results.json').write_text(json.dumps(reports,indent=2)+'\n')
        print(json.dumps({'case':tag,'status':report['http_status'],'response_bytes':report['response_bytes'],
            'count':report.get('semantic_count'),'request_seconds':report['phases_seconds']['complete_asgi_http_request_to_bytes'],
            'parent_baseline_rss':report['parent_baseline_rss_bytes'],'parent_response_peak':report['parent_response_phase_high_water_bytes'],
            'child_peak':profile['peak_rss_bytes'],'child_vm_peak':profile['vm_peak_bytes'],
            'child_phases':profile['phases_seconds']}),flush=True)
print('COMPLETE '+str(len(reports)),flush=True)
