from pathlib import Path
import hashlib,json,os,runpy,socket,subprocess,time
root=Path.cwd();out=root/'.issue-11-evidence/issue157-c3-mobile-framing-correction1';out.mkdir(exist_ok=False)
policy=runpy.run_path(str(root/'docs/assets/viewer-measurements/qualification.py.txt'))
state={'scope':'Focused explicit framing and native incomplete-aromatic-draft picking; not fullreleasegate','source_before':policy['current_identities'](root),'steps':[]}
commands=[('lint',['corepack','pnpm','--dir','apps/web','lint']),('types',['corepack','pnpm','--dir','apps/web','typecheck']),('native',['corepack','pnpm','exec','playwright','test','tests/e2e/direct-molecular-modeling.spec.ts','--workers=1','--retries=0','--max-failures=1','--output='+str(out/'native')])]
env=dict(os.environ);env.update({'PLAYWRIGHT_BROWSERS_PATH':'/datadisk/dev/neistra/.playwright','NEISTRA_AMBERTOOLS_PREFIX':'/datadisk/dev/.neistra-tools/ambertools-24.8','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','NEISTRA_PERFORMANCE':'0','NEISTRA_E2E_API_PORT':'8260','NEISTRA_E2E_WORKER_PORT':'8261','NEISTRA_E2E_WEB_PORT':'5415','NEISTRA_E2E_DATA_DIR':str(out/'data')})
for key in ['NEISTRA_DATA_DIR','NEISTRA_DATABASE_URL','MOLWEAVE_DATA_DIR','MOLWEAVE_DATABASE_URL','DATABASE_URL']:env.pop(key,None)
for label,command in commands:
 if label=='native':
  for port in [8260,8261,5415]:
   with socket.socket() as s:assert s.connect_ex(('127.0.0.1',port))!=0,port
 log=out/(label+'.log');start=time.monotonic()
 with log.open('xb') as f:
  process=subprocess.Popen(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  code=process.wait()
 state['steps'].append({'label':label,'argv':command,'exit':code,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'isolated_child_pid':process.pid,'child_session_id':process.pid})
 (out/'results.json').write_text(json.dumps(state,indent=2)+'\n');print(label,code,flush=True)
 if code:raise SystemExit(code if code>0 else 128-code)
assert policy['current_identities'](root)==state['source_before'];state.update(complete=True,sources_unchanged=True);(out/'results.json').write_text(json.dumps(state,indent=2)+'\n');print('ALL_COMPLETE',len(state['source_before']),flush=True)
