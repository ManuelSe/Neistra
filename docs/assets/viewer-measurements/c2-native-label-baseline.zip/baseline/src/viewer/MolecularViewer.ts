import type { SurfaceChannel } from "./surface/protocol";
import type { SurfaceIdentity } from "./surface/objects";
import type { InteractionDisplayOptions, InteractionDisplayState, InteractionRecord } from "../interactions/types";
import type { SurfaceStatus } from "./surface/runtime";
import type { MovementView } from "../coordinates/interactiveTransform";
import type { ViewerPick } from "../selection/gestures";
import type { SessionCamera } from "../workspacePresentation/types";
import type {
  MolecularProposalGeometry,
  AtomReference,
  CameraState,
  ComponentHierarchy,
  CoordinatePatch,
  Measurement,
  NormalizedStructure,
  SelectionGranularity,
  SelectionMode,
  StructureProjection,
  SurfaceAppearance,
  ViewerSettings,
} from "../api/types";

export interface ResolvedPocket {
  radius: number;
  seeds: { reference: AtomReference; coordinates: [number, number, number] }[];
  dependencyKey: string;
  unavailable?: string;
}

export interface ViewerStructure {
  pockets?: Readonly<Record<string, ResolvedPocket>>;
  entryId: string;
  artifactId?: string;
  label: string;
  projection: StructureProjection["viewer"];
  atomIds: number[];
  normalized: NormalizedStructure;
  hierarchy: ComponentHierarchy;
  settings: ViewerSettings;
}

export interface ViewerAtomHover {
  reference: AtomReference;
  source: ViewerStructure;
  sceneGeneration: number;
}

export interface ViewerSelectionEvent {
  atoms: AtomReference[];
  granularity: SelectionGranularity;
  mode: SelectionMode;
  pick?: ViewerPick;
}

export type MovementInteraction = "inactive" | "transform" | "camera";

export interface PresentationPointer { x: number; y: number }

export interface PresentationCapture {
  stream: MediaStream;
  /** Request a native draw so an unchanged scene supplies its first frame. */
  refresh(): void;
  subscribeAvailability?(listener: (available: boolean) => void): () => void;
  subscribePointer?(listener: (point: PresentationPointer | null) => void): () => void;
}

export interface MolecularViewer {
  capturePresentation?(): PresentationCapture;
  mount(target: HTMLElement): Promise<void>;
  setBackgroundColor(cssColor: string): void;
  syncStructures(structures: ViewerStructure[]): Promise<void>;
  replaceStructure(structure: ViewerStructure): Promise<void>;
  applyCoordinatePatch(
    patch: CoordinatePatch,
    mode: "preview" | "commit",
  ): Promise<void>;
  clearCoordinatePreview(entryId: string): Promise<void>;
  /** Yield until prior rendering releases preview buffers; never changes molecular state. */
  prepareCoordinatePreview?(signal: AbortSignal): Promise<void>;
  setModelPreview?: (preview: MolecularProposalGeometry | null) => Promise<void>;
  setSelection(atoms: AtomReference[]): void;
  setPickingGranularity(granularity: SelectionGranularity): void;
  setMeasurements(measurements: ViewerMeasurement[]): Promise<void>;
  setInteractions(interactions: InteractionRecord[], options?: InteractionDisplayOptions): Promise<void>;
  subscribeInteractionDisplay?(listener: (state: InteractionDisplayState) => void): () => void;
  setIsolation(atoms: AtomReference[] | null): Promise<void>;
  getCamera(): CameraState | null;
  getSessionCamera(): SessionCamera | null;
  setSessionCamera(camera: SessionCamera): void;
  /** Accepted navigation only; no initial/default or restoration emission. */
  subscribeSessionCamera(listener: (camera: SessionCamera) => void): () => void;
  subscribeSessionCameraFailure?(listener: (camera: SessionCamera) => void): () => void;
  /** Actual committed native geometry, distinct from intended atom targets. */
  subscribeDrawable(listener: (drawable: boolean) => void): () => void;
  getMovementView(): MovementView | null;
  getRenderedAtomReferences(): AtomReference[];
  setMovementMode(interaction: MovementInteraction): void;
  setCamera(camera: CameraState): void;
  setCameraMode(mode: CameraState["mode"]): void;
  zoom(factor: number): void;
  focusAtoms(atoms: AtomReference[]): void;
  fitVisible(): void;
  subscribeCamera(listener: (camera: CameraState) => void): () => void;
  getAtomHover?(): ViewerAtomHover | null;
  subscribeAtomHover?(listener: (event: ViewerAtomHover | null) => void): () => void;
  subscribeSelection(listener: (event: ViewerSelectionEvent) => void): () => void;
  subscribeSurfaces(listener: (statuses: SurfaceStatus[]) => void): () => void;
  previewSurfaceAppearance(identity: SurfaceIdentity, appearance: SurfaceAppearance | null): Promise<void>;
  cancelSurface(entryId: string, channel?: SurfaceChannel, surfaceId?: string): void;
  retrySurface(entryId: string, channel?: SurfaceChannel, surfaceId?: string): void;
  resize(): void;
  dispose(): void;
}

export interface ViewerMeasurement extends Measurement {
  label: string;
}

export type MolecularViewerFactory = () => MolecularViewer;
