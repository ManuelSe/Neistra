from pathlib import Path
import hashlib,itertools,json,math,random
from neistra_core.contacts import close_contacts, ContactGeometryError
from neistra_core.molecular import Atom,Bond,Conformer,NormalizedStructureV1,SourceFacts
rng=random.Random(157173)
def model(points):
 ids=[3+11*i for i in range(len(points))]
 return NormalizedStructureV1(title='Independent numeric oracle',structure_type='ligand',source=SourceFacts(filename='oracle.xyz',format='xyz'),atoms=[Atom(id=i,name=f'C{i}',element='C',coordinates=p,source_index=n) for n,(i,p) in enumerate(zip(ids,points,strict=True))],bonds=[Bond(id=n+1,atom_1_id=ids[n],atom_2_id=ids[n+1],order=None,inferred=True) for n in range(len(ids)-1) if n%3==0],conformers=[Conformer(id=1,name='Other',coordinates=[(9.,9.,9.)]*len(points)),Conformer(id=7,name='Current',coordinates=points)],active_conformer_id=7)
def oracle(s,minimum,cutoff):
 blocked={frozenset((b.atom_1_id,b.atom_2_id)) for b in s.bonds};rows=[]
 for i,j in itertools.combinations(range(len(s.atoms)),2):
  a,b=s.atoms[i],s.atoms[j];d=math.dist(a.coordinates,b.coordinates)
  if frozenset((a.id,b.id)) not in blocked and minimum<=d<=cutoff:rows.append((a.id,b.id,d))
 return sorted(rows,key=lambda r:(r[2],r[0],r[1]))
queries=0;distances=0;max_relative=0.
for scale in [1e-310,1e-7,.125,1.,1e5,1e150]:
 for case in range(12):
  points=[tuple(rng.randint(-15,15)*scale for _ in range(3)) for n in range(12)];points[-1]=points[0]
  s=model(points);before=s.to_bytes()
  for minimum,cutoff in [(0.,2*scale),(0.,6*scale),(2*scale,10*scale),(5*scale,20*scale),(0.,60*scale),(25*scale,60*scale)]:
   expected=oracle(s,minimum,cutoff);actual=[(r.atom_1_id,r.atom_2_id,r.distance) for r in close_contacts(s,cutoff,minimum_distance=minimum)]
   assert [r[:2] for r in actual]==[r[:2] for r in expected],(scale,case,minimum,cutoff,actual,expected)
   for a,e in zip(actual,expected,strict=True):
    assert math.isclose(a[2],e[2],rel_tol=3e-15,abs_tol=math.ulp(0.0));distances+=1
    if e[2]:max_relative=max(max_relative,abs(a[2]-e[2])/e[2])
   queries+=1
  assert s.to_bytes()==before
# Independent axis distances give exact membership at adjacent float thresholds.
axis_cases=0
for value in [math.ulp(0.),1e-310,.5,2.,1e5,1e150]:
 s=model([(0.,0.,0.),(value,0.,0.)]).model_copy(update={'bonds':[]})
 for cutoff,included in [(math.nextafter(value,0.),False),(value,True),(math.nextafter(value,math.inf),True)]:
  if cutoff==0.:continue
  rows=close_contacts(s,cutoff);assert bool(rows)==included
  if rows:assert rows[0].distance==value
  axis_cases+=1
# Accepted-schema basis drift must fail even with only a single atom.
rejections=0
for count,axis,direction in itertools.product([1,2,4],range(3),[-math.inf,math.inf]):
 s=model([(float(n),0.,0.) for n in range(count)])
 payload=s.model_dump();p=list(payload['atoms'][-1]['coordinates']);p[axis]=math.nextafter(p[axis],direction);payload['atoms'][-1]['coordinates']=p
 drift=NormalizedStructureV1.model_validate(payload);before=drift.to_bytes()
 try:close_contacts(drift,5.)
 except ContactGeometryError as e:assert 'atom coordinates and active conformer disagree' in str(e);rejections+=1
 else:raise AssertionError('ambiguous frame accepted')
 assert drift.to_bytes()==before
zero=model([]);assert close_contacts(zero,2.)==[]
signed=model([(0.,-0.,0.),(3.,0.,0.)]).model_copy(update={'bonds':[]});cs=list(signed.conformers);cs[1]=cs[1].model_copy(update={'coordinates':[(-0.,0.,-0.),(3.,-0.,-0.)]});signed=signed.model_copy(update={'conformers':cs});assert close_contacts(signed,3.)[0].distance==3.
result={'independent_all_pairs_queries':queries,'distances_compared':distances,'max_relative_error':max_relative,'analytic_nextafter_axis_cases':axis_cases,'accepted_schema_basis_rejections':rejections,'nondefault_active_conformer':7,'sparse_ids':True,'recorded_bond_exclusions':True,'coincident_sites':True,'immutable_sources':True,'empty_and_signed_zero_controls':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
