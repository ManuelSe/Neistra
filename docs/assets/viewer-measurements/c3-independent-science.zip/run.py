from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/datadisk/dev/neistra-worktrees/issue-11-ligand-information');out=Path(__file__).parent
paths=['packages/neistra_core/src/neistra_core/contacts.py','apps/api/src/neistra_api/contact_execution_data.py','apps/api/src/neistra_api/contact_execution_worker.py','apps/api/src/neistra_api/contact_service.py','apps/api/src/neistra_api/async_work.py','apps/api/src/neistra_api/edit_execution_data.py','apps/web/src/measurements/geometry.ts','apps/web/src/viewer/MolstarEngine.ts','apps/web/src/viewer/savedMeasurementGeometry.ts','apps/web/src/measurements/session.ts','apps/web/src/components/ViewerMeasurements.tsx','apps/web/src/App.tsx']
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
state={'scope':'Read-only independent scientific implementation checks; no release-gate claim','candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_before':hashes(),'steps':[]}
env=dict(os.environ);env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',NEISTRA_PERFORMANCE='0')
command=[str(root/'.venv/bin/python'),'-m','pytest','tests/unit/test_contacts.py','tests/scientific/test_contact_streaming.py','tests/unit/test_contact_transport.py','tests/unit/test_verified_file_transport.py','tests/integration/test_contact_execution.py','tests/integration/test_contact_socket_disconnect.py','tests/integration/test_measurement_persistence.py','-q']
log=out/'python.log';started=time.monotonic()
with log.open('xb') as stream:code=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
state['steps'].append({'argv':command,'exit':code,'seconds':time.monotonic()-started,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});state['sources_unchanged']=hashes()==state['source_before'];(out/'checks.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({'output':str(out),'exit':code,'sources_unchanged':state['sources_unchanged']}));print(log.read_text()[-2500:]);raise SystemExit(code)
