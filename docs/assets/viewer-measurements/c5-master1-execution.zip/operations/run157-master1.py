"""Run all candidate phases, retaining real child exits independently."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
root=Path.cwd();assets=root/'docs/assets/viewer-measurements';receipt=root/'.issue-11-evidence/issue157-c5-master1-wrapper.json'
assert not receipt.exists();assert not subprocess.check_output(['git','status','--porcelain'],text=True)
merged=os.environ['NEISTRA_RELEASE_MERGE_COMMIT'];assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==merged;subprocess.run(['git','merge-base','--is-ancestor',merged,'origin/master'],check=True)
python=str(root/'.venv/bin/python');state={'scope':'Complete fresh42-command exact merged-master qualification plus independent summary/recursivepackaging','candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'started_utc':datetime.datetime.now(datetime.UTC).isoformat(),'phases':[]}
commands=[('qualification',[python,str(assets/'qualification.py.txt'),str(assets/'c5-master1-recipe.json')]),('independent_summary',[python,str(assets/'qualification-summary.py.txt'),'c5-master1']),('complete_packaging',[python,str(assets/'release-evidence.py.txt'),'gate','--root',str(root),'--label','c5-master1','--output-dir',str(assets)])]
for phase,command in commands:
 log=root/'.issue-11-evidence'/('issue157-c5-master1-'+phase+'.log');print('START',phase,flush=True)
 with log.open('xb') as f:process=subprocess.Popen(command,cwd=root,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);code=process.wait()
 state['phases'].append({'phase':phase,'command':command,'exit':code,'log':str(log.relative_to(root)),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'isolated_child_pid':process.pid,'finished_utc':datetime.datetime.now(datetime.UTC).isoformat()});receipt.write_text(json.dumps(state,indent=2)+'\n');print('PHASE_EXIT',phase,code,flush=True)
 if code:sys.exit(code if code>0 else 128-code)
state['complete']=True;receipt.write_text(json.dumps(state,indent=2)+'\n');print('ALL_PHASES_COMPLETE',flush=True)
