from pathlib import Path
from argparse import Namespace
import contextlib,copy,hashlib,io,json,runpy,urllib.request
root=Path.cwd();base=root/'.issue-11-evidence/release-v0.35.0/forensic-negative-controls2';base.mkdir(exist_ok=False)
module=runpy.run_path(str(root/'tools/verify_measurement_forensics.py'));validate=module['validate_index'];verify=module['verify'];index_path=root/'docs/assets/viewer-measurements/c3-forensics-index.json';index=json.loads(index_path.read_text());controls={}
for name,mutate in [('duplicate_asset',lambda d:d['runs'][1]['parts'][0].update(asset_name=d['runs'][0]['parts'][0]['asset_name'])),('bad_ordinal',lambda d:d['runs'][0]['parts'][0].update(ordinal=2)),('oversize_part',lambda d:d['runs'][0]['parts'][0].update(bytes=80*1024*1024)),('false_qualification',lambda d:d['runs'][0].update(qualification_complete=True)),('duplicate_run',lambda d:d['runs'][1].update(label=d['runs'][0]['label'],extraction_root=d['runs'][0]['extraction_root'])),('boolean_ordinal',lambda d:d['runs'][0]['parts'][0].update(ordinal=True))]:
 data=copy.deepcopy(index);mutate(data)
 try:validate(data)
 except AssertionError:controls[name]='rejected'
 else:raise RuntimeError(name+' accepted')
actual_plan=json.loads((root/'.issue-11-evidence/release-v0.35.0/forensic-upload-plan.json').read_text());wrong=copy.deepcopy(index);wrong['runs'][0]['parts'][0]['sha256']='0'*64;bad_index=base/'wrong-body-index.json';bad_index.write_text(json.dumps(wrong));plan=copy.deepcopy(actual_plan);plan['index_sha256']=hashlib.sha256(bad_index.read_bytes()).hexdigest();plan['assets'][0]['sha256']='0'*64;bad_plan=base/'wrong-body-plan.json';bad_plan.write_text(json.dumps(plan))
try:verify(Namespace(root=root,index=str(bad_index.relative_to(root)),mode='local',plan=bad_plan,output=base/'wrong-body-output.json'))
except AssertionError:controls['actual_body_hash_mismatch']='rejected_before_decompression'
else:raise RuntimeError('Wrong body accepted')
parts=[part for run in index['runs'] for part in run['parts']]
release={'scope':'SIMULATEDmetadata only; no remote release or network availability claimed','tag_name':'v0.35.0','draft':False,'prerelease':False,'assets':[{'name':part['asset_name'],'id':i+1,'size':part['bytes'],'digest':'sha256:'+part['sha256'],'state':'uploaded','browser_download_url':'https://github.com/ManuelSe/Neistra/releases/download/v0.35.0/'+part['asset_name']} for i,part in enumerate(parts)]}
network=[];original=urllib.request.urlopen
def forbidden(*args,**kwargs):
 network.append('unexpected');raise RuntimeError('Network must not be attempted in metadata refusal control')
urllib.request.urlopen=forbidden
try:
 for name,field,value in [('wrong_server_digest','digest','sha256:'+'0'*64),('wrong_public_url_host','browser_download_url','https://example.invalid/forensic.zip')]:
  data=copy.deepcopy(release);data['assets'][0][field]=value;fixture=base/(name+'-simulated.json');fixture.write_text(json.dumps(data))
  try:verify(Namespace(root=root,index=str(index_path.relative_to(root)),mode='anonymous',remote_assets=fixture,downloads=base/(name+'-downloads'),output=base/(name+'-output.json')))
  except AssertionError:controls[name]='rejected_before_network'
  else:raise RuntimeError(name+' accepted')
finally:urllib.request.urlopen=original
assert not network
receipt={'scope':'Verifier corruption controls; metadata fixtures are simulated, NO real anonymous download or publication claim','controls':controls,'network_attempts':len(network),'verifier_sha256':hashlib.sha256((root/'tools/verify_measurement_forensics.py').read_bytes()).hexdigest(),'index_sha256':hashlib.sha256(index_path.read_bytes()).hexdigest()};(base/'results.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
