from __future__ import annotations
import math
import pytest
from neistra_core.contacts import ContactGeometryError, close_contacts
from neistra_core.molecular import NormalizedStructureV1
from neistra_core.artifacts import LocalArtifactStore
from neistra_api.import_export import NORMALIZED_MEDIA_TYPE, ArtifactService
from neistra_api.models import Artifact, StructureEntry
from tests.scientific.test_contact_streaming import molecular_input, contact_rows
from tests.integration.test_contact_execution import coordinator, canonical_files, query_for
from tests.integration.test_viewer_state import import_ligand
from tests.support.api_client import ApiClient


@pytest.mark.parametrize("count", [1, 2])
@pytest.mark.parametrize("axis", [0, 1, 2])
def test_disagreeing_atom_coordinate_basis_refuses_even_singletons(count: int, axis: int) -> None:
    source = molecular_input([(0.0, 0.0, 0.0), (0.0, 0.0, 3.0)][:count])
    point = list(source.atoms[-1].coordinates)
    point[axis] = math.nextafter(point[axis], math.inf)
    atoms = [*source.atoms[:-1], source.atoms[-1].model_copy(update={"coordinates": tuple(point)})]
    # This disagreement passes the canonical schema and can occur in retained data.
    source = NormalizedStructureV1.model_validate(source.model_dump() | {"atoms": atoms})
    snapshot = source.to_bytes()
    with pytest.raises(
        ContactGeometryError, match="atom coordinates and active conformer disagree"
    ):
        close_contacts(source, 4.0)
    assert source.to_bytes() == snapshot

@pytest.mark.parametrize("value", [float("nan"), float("inf"), -float("inf")])
def test_finite_active_frame_does_not_qualify_nonfinite_atom_coordinates(value: float) -> None:
    source = molecular_input([(0, 0, 0)])
    atom = source.atoms[0].model_copy(update={"coordinates": (value, 0, 0)})
    source = source.model_copy(update={"atoms": [atom]})
    snapshot = source.to_bytes()
    with pytest.raises(
        ContactGeometryError, match="Atom coordinates must be finite float64 3D points"
    ):
        close_contacts(source, 2.0)
    assert source.to_bytes() == snapshot

@pytest.mark.parametrize("point", [(0, 0), (0, 0, 0, 0)])
def test_atom_coordinate_shape_is_qualified_before_singleton_empty_result(
    point: tuple[int, ...],
) -> None:
    source = molecular_input([(0, 0, 0)])
    atom = source.atoms[0].model_copy(update={"coordinates": point})
    source = source.model_copy(update={"atoms": [atom]})
    with pytest.raises(
        ContactGeometryError, match="Atom coordinates must be finite float64 3D points"
    ):
        close_contacts(source, 2.0)

def test_coordinate_basis_agreement_allows_signed_zero_without_mutation() -> None:
    source = molecular_input([(0.0, -0.0, 0.0), (0.0, 0.0, 3.0)], ids=[2, 17])
    frame = source.conformers[0].model_copy(
        update={"coordinates": [(-0.0, 0.0, -0.0), (-0.0, -0.0, 3.0)]}
    )
    source = source.model_copy(update={"conformers": [frame]})
    snapshot = source.to_bytes()
    assert contact_rows(close_contacts(source, 3.0)) == [(2, 17, 3.0)]
    assert source.to_bytes() == snapshot

def test_conflicting_coordinate_basis_returns_geometry_reason_without_mutation(
    client: ApiClient,
) -> None:
    project = import_ligand(client)
    service = coordinator(client)
    entry = project["entries"][0]
    path = f"/api/v1/projects/{project['id']}"
    original_path = f"{path}/entries/{entry['id']}/original"
    original = client.get(original_path).content
    with service.factory() as session:
        artifacts = ArtifactService(session, LocalArtifactStore(service.settings.data_dir))
        _, payload = artifacts.read(entry["current_artifact_id"])
        data = NormalizedStructureV1.from_bytes(payload).model_dump()
        data["atoms"][0]["coordinates"] = (9.0, 0.0, 0.0)
        # Publish a legitimate immutable canonical payload: its hash/size are valid,
        # and the schema itself does not require atom/active-frame agreement.
        conflicting = NormalizedStructureV1.model_validate(data)
        published = artifacts.publish(
            conflicting.to_bytes(), "conflicting-basis.normalized.json", NORMALIZED_MEDIA_TYPE
        )
        row = session.get(StructureEntry, entry["id"])
        assert row is not None
        row.current_artifact_id = published.id
        session.commit()
    persisted_before = client.get(path).json()
    before_files = canonical_files(service)
    with service.factory() as session:
        before_artifacts = [
            (artifact.id, artifact.sha256, artifact.size, artifact.relative_path)
            for artifact in session.query(Artifact).order_by(Artifact.id)
        ]
    response = client.post(
        f"{path}/contacts", json=query_for(persisted_before).model_dump()
    )
    assert response.status_code == 422, response.text
    assert response.json()["detail"] == {
        "code": "contacts_geometry",
        "message": "Current atom coordinates and active conformer disagree",
    }
    assert client.get(path).json() == persisted_before
    assert canonical_files(service) == before_files
    assert client.get(original_path).content == original
    with service.factory() as session:
        assert [
            (artifact.id, artifact.sha256, artifact.size, artifact.relative_path)
            for artifact in session.query(Artifact).order_by(Artifact.id)
        ] == before_artifacts
    assert not list(service.settings.data_dir.glob("contact-read-*"))
