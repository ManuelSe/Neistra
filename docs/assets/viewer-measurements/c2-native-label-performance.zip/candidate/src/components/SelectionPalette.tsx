import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { IconButton } from "./IconButton";

/** Non-modal workspace tool: outside interactions belong to the workspace. */
export function SelectionPalette({ open, onOpenChange, children, count, restoreFocus = true }: {
  open: boolean;
  count: number;
  restoreFocus?: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
}) {
  const content = useRef<HTMLDivElement>(null);
  const returnFocus = useRef<HTMLElement | null>(null);
  const anchor = useRef<Element | null>(null);
  const [anchorNode, setAnchorNode] = useState<Element | null>(null);
  const position = useCallback(() => {
    const panel = content.current;
    if (!panel) return;
    const box = anchor.current?.getBoundingClientRect();
    const left = Math.max(8, Math.min(box?.left ?? 10, window.innerWidth - 352));
    const naturalHeight = panel.scrollHeight + 2 * panel.clientTop;
    const controls = anchor.current?.closest(".structure-viewer")?.querySelector(".viewer-controls > .icon-button")?.getBoundingClientRect();
    // A tall workspace palette can scroll; it must not cover its sibling launcher.
    const minimumTop = controls ? controls.bottom + 2 : 8;
    const top = Math.max(minimumTop, Math.min((box?.bottom ?? 50) + 8, window.innerHeight - naturalHeight - 12));
    panel.style.setProperty("--palette-left", `${left}px`);
    panel.style.setProperty("--palette-top", `${top}px`);
  }, []);
  useEffect(() => {
    if (!open) return;
    window.addEventListener("resize", position);
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(position);
    if (anchorNode) {
      observer?.observe(anchorNode);
      if (anchorNode.parentElement) observer?.observe(anchorNode.parentElement);
    }
    // Observe content changes without observing our own constrained panel height.
    for (const child of Array.from(content.current?.children ?? [])) observer?.observe(child);
    return () => { window.removeEventListener("resize", position); observer?.disconnect(); };
  }, [open, position, anchorNode]);
  return <Dialog.Root open={open} onOpenChange={onOpenChange} modal={false}>
    <Dialog.Portal><Dialog.Content ref={content} className="dialog-content selection-palette"
      aria-describedby={undefined}
      onInteractOutside={(event) => event.preventDefault()}
      onEscapeKeyDown={(event) => {
        if (!content.current?.contains(document.activeElement)) event.preventDefault();
      }}
      onOpenAutoFocus={(event) => {
        returnFocus.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
        anchor.current = returnFocus.current?.closest(".structure-viewer")?.querySelector(".viewer-toolbar") ?? null;
        setAnchorNode(anchor.current);
        position();
        event.preventDefault();
        const first = content.current?.querySelector<HTMLElement>(
          '.selection-style-option:not(:disabled), .selection-style-dialog input:not(:disabled)',
        );
        (first ?? content.current)?.focus();
      }}
      onCloseAutoFocus={(event) => {
        event.preventDefault();
        if (restoreFocus && returnFocus.current?.isConnected) returnFocus.current.focus();
      }}>
      <div className="dialog-heading">
        <div><Dialog.Title>Style selection</Dialog.Title>
          <span className="selection-style-summary">{count} {count === 1 ? "atom" : "atoms"}</span></div>
        <Dialog.Close asChild><IconButton label="Close dialog"><X size={18} /></IconButton></Dialog.Close>
      </div>
      {children}
    </Dialog.Content></Dialog.Portal>
  </Dialog.Root>;
}
