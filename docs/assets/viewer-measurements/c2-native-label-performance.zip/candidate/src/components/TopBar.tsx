import {
  FolderTree,
  FileOutput,
  History,
  Moon,
  PanelRight,
  Redo2,
  Save,
  Sun,
  Undo2,
  Upload,
  BriefcaseBusiness,
} from "lucide-react";
import type { Project } from "../api/types";
import type { Theme } from "../store/workspace";
import { IconButton } from "./IconButton";
import { Brand } from "./Brand";

interface TopBarProps {
  project: Project | undefined;
  theme: Theme;
  busy: boolean;
  readBusy?: boolean;
  compact: boolean;
  onProjects: () => void;
  onSave: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onImport: () => void;
  onExport: () => void;
  onJobs: () => void;
  onTheme: () => void;
  onMobilePanel: (panel: "projects" | "inspector" | "history") => void;
}

export function TopBar({
  project,
  theme,
  busy,
  readBusy = busy,
  compact,
  onProjects,
  onSave,
  onUndo,
  onRedo,
  onImport,
  onExport,
  onJobs,
  onTheme,
  onMobilePanel,
}: TopBarProps) {
  return (
    <header className="topbar">
      <button type="button" className="brand" onClick={onProjects} aria-label="Projects">
        <Brand variant="lockup" className="brand-desktop" />
        <Brand variant="icon" className="brand-compact" />
        <span className="sr-only">Neistra</span>
      </button>
      <button type="button" className="project-switcher" onClick={onProjects}>
        <span className="project-switcher-label">{project?.name ?? "No project open"}</span>
        {project?.has_uncheckpointed_changes ? (
          <span className="dirty-indicator" aria-label="Unsaved changes" />
        ) : null}
      </button>

      <div className="topbar-actions">
        {compact ? (
          <>
            <IconButton label="Project browser" onClick={() => onMobilePanel("projects")}>
              <FolderTree size={18} />
            </IconButton>
            <IconButton label="History" onClick={() => onMobilePanel("history")}>
              <History size={18} />
            </IconButton>
            <IconButton label="Inspector" onClick={() => onMobilePanel("inspector")}>
              <PanelRight size={18} />
            </IconButton>
          </>
        ) : null}
        <IconButton label="Import structures" disabled={!project || busy} onClick={onImport}>
          <Upload size={18} />
        </IconButton>
        <IconButton
          label="Export"
          disabled={!project?.entries.length || readBusy}
          onClick={onExport}
        >
          <FileOutput size={18} />
        </IconButton>
        <IconButton label="Jobs" disabled={!project || readBusy} onClick={onJobs}>
          <BriefcaseBusiness size={18} />
        </IconButton>
        <span className="toolbar-separator" />
        <IconButton
          label={project?.history.undo_description ? `Undo: ${project.history.undo_description}` : "Undo"}
          disabled={!project?.history.can_undo || busy}
          onClick={onUndo}
        >
          <Undo2 size={18} />
        </IconButton>
        <IconButton
          label={project?.history.redo_description ? `Redo: ${project.history.redo_description}` : "Redo"}
          disabled={!project?.history.can_redo || busy}
          onClick={onRedo}
        >
          <Redo2 size={18} />
        </IconButton>
        <IconButton
          label="Save checkpoint"
          disabled={!project?.has_uncheckpointed_changes || busy}
          onClick={onSave}
        >
          <Save size={18} />
        </IconButton>
        <span className="toolbar-separator" />
        <IconButton
          label={theme === "light" ? "Use dark theme" : "Use light theme"}
          onClick={onTheme}
        >
          {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
        </IconButton>
      </div>
    </header>
  );
}
