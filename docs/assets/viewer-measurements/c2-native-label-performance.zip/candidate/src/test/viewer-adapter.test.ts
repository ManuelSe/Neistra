import { beforeEach, describe, expect, it, vi } from "vitest";
import type { ViewerAtomHover, ViewerStructure } from "../viewer/MolecularViewer";
import type { SessionCamera } from "../workspacePresentation/types";
import { WorkspacePresentationController } from "../workspacePresentation/controller";
import {
  componentHierarchy,
  proteinStructure,
  viewerSettings,
} from "./molecular-fixtures";

const calls = vi.hoisted(() => ({
  mount: vi.fn(),
  cancelSurface: vi.fn(),
  retrySurface: vi.fn(),
  background: vi.fn(),
  sync: vi.fn(),
  selection: vi.fn(),
  surfacePreview: vi.fn(),
  granularity: vi.fn(),
  movement: vi.fn(),
  subscribe: vi.fn((listener: unknown) => {
    void listener;
    return () => undefined;
  }),
  resize: vi.fn(),
  dispose: vi.fn(),
  measurements: vi.fn(),
  interactions: vi.fn(),
  isolation: vi.fn(),
  focus: vi.fn(),
  fit: vi.fn(),
  cameraSubscribe: vi.fn((listener: unknown) => {
    void listener;
    return () => undefined;
  }),
  sessionSet: vi.fn(),
  sessionGet: vi.fn<() => SessionCamera | null>(() => null),
  sessionSubscribe: vi.fn((listener: unknown) => { void listener; return vi.fn(); }),
  atomHoverGet: vi.fn<() => ViewerAtomHover | null>(() => null),
  atomHoverSubscribe: vi.fn((listener: (value: ViewerAtomHover | null) => void) => { listener(null); return vi.fn(); }),
  drawableSubscribe: vi.fn((listener: (value: boolean) => void) => { listener(false); return vi.fn(); }),
}));

vi.mock("../viewer/MolstarEngine", () => ({
  MolstarEngine: class {
    mount(target: HTMLElement) {
      return Promise.resolve(calls.mount(target));
    }

    setBackgroundColor(cssColor: string) {
      calls.background(cssColor);
    }

    syncStructures(structures: ViewerStructure[]) {
      calls.sync(structures);
      return Promise.resolve();
    }

    setSelection(atoms: unknown[]) {
      calls.selection(atoms);
    }
    previewSurfaceAppearance(identity: unknown, appearance: unknown) { calls.surfacePreview(identity, appearance); return Promise.resolve(); }

    setPickingGranularity(granularity: string) {
      calls.granularity(granularity);
    }

    subscribeSelection(listener: unknown) {
      return calls.subscribe(listener);
    }

    setMeasurements(value: unknown) {
      calls.measurements(value);
      return Promise.resolve();
    }

    setInteractions(value: unknown) {
      calls.interactions(value);
      return Promise.resolve();
    }

    setIsolation(value: unknown) {
      calls.isolation(value);
      return Promise.resolve();
    }

    getCamera() {
      return null;
    }
    getSessionCamera() { return calls.sessionGet(); }
    setSessionCamera(camera: SessionCamera) { calls.sessionSet(camera); }
    subscribeSessionCamera(listener: unknown) { return calls.sessionSubscribe(listener); }
    getAtomHover() { return calls.atomHoverGet(); }
    subscribeAtomHover(listener: (value: ViewerAtomHover | null) => void) { return calls.atomHoverSubscribe(listener); }
    subscribeDrawable(listener: (value: boolean) => void) { return calls.drawableSubscribe(listener); }

    getMovementView() { return null; }
    getRenderedAtomReferences() { return []; }
    setMovementMode(value: string) { calls.movement(value); }

    cancelSurface(id: string, channel: string) { calls.cancelSurface(id, channel); }
    retrySurface(id: string, channel: string) { calls.retrySurface(id, channel); }

    setCamera() {}
    setCameraMode() {}
    zoom() {}
    focusAtoms(atoms: unknown[]) {
      calls.focus(atoms);
    }

    fitVisible() {
      calls.fit();
    }

    subscribeCamera(listener: unknown) {
      return calls.cameraSubscribe(listener);
    }

    resize() {
      calls.resize();
    }

    dispose() {
      calls.dispose();
    }
  },
}));

describe("MolecularViewer Molstar adapter", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    calls.sessionGet.mockReturnValue(null);
    calls.atomHoverGet.mockReturnValue(null);
  });

  it("binds atom feedback after lazy mount and refuses held callbacks after unsubscribe/dispose", async () => {
    const { createMolstarViewer } = await import("../viewer/MolstarViewer");
    const viewer = createMolstarViewer(), listener = vi.fn();
    const release = viewer.subscribeAtomHover!(listener);
    expect(listener).toHaveBeenCalledExactlyOnceWith(null);
    await viewer.mount(document.createElement("div"));
    const native = calls.atomHoverSubscribe.mock.calls[0][0];
    const structure = proteinStructure();
    const source = { entryId: "entry", artifactId: "a", label: "Entry", normalized: structure,
      atomIds: structure.atoms.map(atom => atom.id), hierarchy: componentHierarchy(structure),
      projection: { format: "mmcif" as const, data: "" }, settings: viewerSettings() };
    const event = { reference: { structure_id: "entry", atom_id: 1 }, source, sceneGeneration: 1 };
    calls.atomHoverGet.mockReturnValue(event); native(event);
    expect(listener).toHaveBeenLastCalledWith(event);
    const beforeRetirement = listener.mock.calls.length;
    calls.atomHoverGet.mockReturnValue(null); native(event);
    expect(listener).toHaveBeenCalledTimes(beforeRetirement);
    // A held old clear cannot erase newer atom feedback either.
    calls.atomHoverGet.mockReturnValue(event); native(null);
    expect(listener).toHaveBeenCalledTimes(beforeRetirement);
    const count = listener.mock.calls.length;
    release(); native(event);
    expect(listener).toHaveBeenCalledTimes(count);
    const second = vi.fn(); viewer.subscribeAtomHover!(second);
    const held = calls.atomHoverSubscribe.mock.calls[1][0];
    viewer.dispose();
    expect(second).toHaveBeenLastCalledWith(null);
    const stopped = second.mock.calls.length;
    held(event); expect(second).toHaveBeenCalledTimes(stopped);
    expect(calls.atomHoverSubscribe.mock.results.every(result => result.type === "return"
      && result.value.mock.calls.length === 1)).toBe(true);
  });

  it("does not bind a retired pre-mount atom consumer or a disposed viewer", async () => {
    const { createMolstarViewer } = await import("../viewer/MolstarViewer");
    const viewer = createMolstarViewer();
    viewer.subscribeAtomHover!(vi.fn())();
    await viewer.mount(document.createElement("div"));
    expect(calls.atomHoverSubscribe).not.toHaveBeenCalled();
    viewer.dispose();
    const late = vi.fn(); viewer.subscribeAtomHover!(late);
    expect(late).toHaveBeenCalledExactlyOnceWith(null);
    expect(calls.atomHoverSubscribe).not.toHaveBeenCalled();
  });

  it("buffers the latest complete camera through lazy mount without initial navigation or lost FOV", async () => {
    const { createMolstarViewer } = await import("../viewer/MolstarViewer");
    const viewer = createMolstarViewer();
    const camera: SessionCamera = { mode: "orthographic", position: [10, 7, 25], target: [1, 2, 3], up: [1, 1, 0], radius: 0.001, fov: 0.55 };
    const listener = vi.fn(), release = viewer.subscribeSessionCamera(listener);
    viewer.setSessionCamera({ ...camera, fov: 0.8 });
    viewer.setSessionCamera(camera);
    expect(viewer.getSessionCamera()).toEqual(camera);
    await viewer.mount(document.createElement("div"));
    expect(calls.sessionSet).toHaveBeenCalledExactlyOnceWith(camera);
    expect(listener).not.toHaveBeenCalled();
    expect(calls.sessionSubscribe).toHaveBeenCalledOnce();
    release();
    const subscription = calls.sessionSubscribe.mock.results[0];
    if (subscription.type !== "return") throw new Error("Missing native camera subscription.");
    const released = subscription.value;
    expect(released).toHaveBeenCalledOnce();
    viewer.dispose();
    expect(released).toHaveBeenCalledOnce();
  });

  it("drops a retired pre-mount camera subscription before the engine exists", async () => {
    const { createMolstarViewer } = await import("../viewer/MolstarViewer");
    const viewer = createMolstarViewer();
    viewer.subscribeSessionCamera(vi.fn())();
    await viewer.mount(document.createElement("div"));
    expect(calls.sessionSubscribe).not.toHaveBeenCalled();
    viewer.dispose();
  });

  it("reports deferred viewport restoration refusal without preventing scene startup or navigation binding", async () => {
    const { createMolstarViewer } = await import("../viewer/MolstarViewer");
    const viewer = createMolstarViewer();
    const saved: SessionCamera = { mode: "perspective", position: [0, 0, 20], target: [0, 0, 0], up: [0, 1, 0], radius: 2, fov: 1e-307 };
    const fallback = { ...saved, fov: Math.PI / 4 };
    calls.sessionGet.mockReturnValue(fallback);
    calls.sessionSet.mockImplementationOnce(() => { throw new Error("Viewport projection overflow"); });
    const api = { read: vi.fn(() => Promise.resolve({ schema_version: 1 as const, revision: 1, camera: saved, updated_at: "2026-11-14T00:00:00Z" })), write: vi.fn() };
    const controller = new WorkspacePresentationController({ api, storage: { getItem: () => null, setItem: vi.fn() } });
    await controller.hydrate();
    const release = controller.bind(viewer);
    await expect(viewer.mount(document.createElement("div"))).resolves.toBeUndefined();
    expect(controller.getSnapshot()).toMatchObject({ camera: fallback, problem: "display" });
    expect(calls.sessionSubscribe).toHaveBeenCalledOnce();
    await viewer.syncStructures([]);
    expect(calls.sync).toHaveBeenCalledExactlyOnceWith([]);
    expect(api.write).not.toHaveBeenCalled();
    release(); viewer.dispose(); controller.stop();
  });

  it("forwards transient surface appearance and cancellation independently from canonical sync", async () => {
    const { createMolstarViewer } = await import("../viewer/MolstarViewer");
    const viewer = createMolstarViewer();
    await viewer.mount(document.createElement("div"));
    const identity = { entryId: "entry", surfaceId: "surface" };
    const appearance = { color_by: "custom" as const, custom_color: "#00ff00", opacity: 0.3, mode: "solid" as const, inherit_atom_colors: false };
    await viewer.previewSurfaceAppearance(identity, appearance);
    await viewer.previewSurfaceAppearance(identity, null);
    expect(calls.surfacePreview.mock.calls).toEqual([[identity, appearance], [identity, null]]);
    expect(calls.sync).not.toHaveBeenCalled();
    viewer.dispose();
    await viewer.previewSurfaceAppearance(identity, appearance);
    expect(calls.surfacePreview).toHaveBeenCalledTimes(2);
  });

  it("buffers only the latest pre-mount appearance and drops retired object identities", async () => {
    const { createMolstarViewer } = await import("../viewer/MolstarViewer");
    const viewer = createMolstarViewer();
    const identity = { entryId: "entry", surfaceId: "surface" };
    const appearance = { color_by: "element" as const, custom_color: "#00ff00", opacity: 0.3, mode: "solid" as const, inherit_atom_colors: false };
    await viewer.previewSurfaceAppearance({ entryId: "retired", surfaceId: "old" }, appearance);
    for (let i = 1; i <= 1000; i++) await viewer.previewSurfaceAppearance(identity, { ...appearance, opacity: i / 1000 });
    await viewer.mount(document.createElement("div"));
    const normalized = proteinStructure();
    await viewer.syncStructures([{ entryId: "entry", label: "Entry", normalized, hierarchy: componentHierarchy(normalized),
      projection: { format: "mmcif", data: "projection" }, atomIds: normalized.atoms.map(atom => atom.id),
      settings: { ...viewerSettings(), surface_objects: [{ id: "surface", name: "Surface", visible: true, source: { kind: "entry" }, appearance }] },
    }]);
    expect(calls.surfacePreview).toHaveBeenCalledExactlyOnceWith(identity, { ...appearance, opacity: 1 });
    viewer.dispose();
  });

  it("releases a native engine whose asynchronous mount completes after disposal", async () => {
    let finish!: () => void;
    calls.mount.mockReturnValueOnce(new Promise<void>(resolve => { finish = resolve; }));
    const { createMolstarViewer } = await import("../viewer/MolstarViewer");
    const viewer = createMolstarViewer();
    viewer.subscribeCamera(vi.fn());
    const mounting = viewer.mount(document.createElement("div"));
    await vi.waitFor(() => expect(calls.mount).toHaveBeenCalledOnce());
    viewer.dispose();
    finish();
    await mounting;
    expect(calls.dispose).toHaveBeenCalledTimes(2);
    expect(calls.cameraSubscribe).not.toHaveBeenCalled();
    expect(calls.granularity).not.toHaveBeenCalled();
  });

  it("loads Molstar lazily and forwards only application viewer concepts", async () => {
    const { createMolstarViewer } = await import("../viewer/MolstarViewer");
    const target = document.createElement("div");
    const protein = proteinStructure();
    const ligand = { ...proteinStructure(), structure_type: "ligand" as const };
    const structures: ViewerStructure[] = [
      {
        entryId: "protein",
        label: "Receptor",
        projection: { format: "mmcif", data: "protein data" },
        atomIds: [10, 11],
        normalized: protein,
        hierarchy: componentHierarchy(protein),
        settings: viewerSettings("cartoon"),
      },
      {
        entryId: "ligand",
        label: "Ligand",
        projection: { format: "sdf", data: "ligand data" },
        atomIds: [20],
        normalized: ligand,
        hierarchy: componentHierarchy(ligand),
        settings: viewerSettings(),
      },
    ];
    const viewer = createMolstarViewer();
    const listener = vi.fn();

    expect(calls.mount).not.toHaveBeenCalled();
    viewer.setBackgroundColor("#11191b");
    viewer.setPickingGranularity("chain");
    viewer.setSelection([{ structure_id: "protein", atom_id: 10 }]);
    viewer.subscribeSelection(listener);
    await viewer.mount(target);
    viewer.setBackgroundColor("#eef2f1");
    await viewer.syncStructures(structures);
    await viewer.setInteractions([]);
    viewer.focusAtoms([{ structure_id: "protein", atom_id: 10 }]);
    viewer.fitVisible();
    viewer.resize();
    viewer.dispose();

    expect(calls.mount).toHaveBeenCalledWith(target);
    expect(calls.background.mock.calls).toEqual([["#11191b"], ["#eef2f1"]]);
    expect(calls.background.mock.invocationCallOrder[0]).toBeLessThan(
      calls.mount.mock.invocationCallOrder[0],
    );
    expect(calls.granularity).toHaveBeenCalledWith("chain");
    expect(calls.selection).toHaveBeenCalledWith([
      { structure_id: "protein", atom_id: 10 },
    ]);
    expect(calls.subscribe).toHaveBeenCalledWith(listener);
    expect(calls.sync).toHaveBeenCalledWith(structures);
    expect(calls.interactions).toHaveBeenCalledWith([]);
    expect(calls.focus).toHaveBeenCalledWith([
      { structure_id: "protein", atom_id: 10 },
    ]);
    expect(calls.fit).toHaveBeenCalledOnce();
    expect(calls.resize).toHaveBeenCalledOnce();
    expect(calls.dispose).toHaveBeenCalledOnce();
  });
});

it("buffers typed movement ownership and forwards camera transitions without remounting", async () => {
  vi.clearAllMocks();
  const { createMolstarViewer } = await import("../viewer/MolstarViewer");
  const viewer = createMolstarViewer();
  viewer.setMovementMode("transform");
  await viewer.mount(document.createElement("div"));
  expect(calls.movement).toHaveBeenLastCalledWith("transform");
  viewer.setMovementMode("camera");
  expect(calls.movement).toHaveBeenLastCalledWith("camera");
  viewer.setMovementMode("transform");
  viewer.setMovementMode("inactive");
  expect(calls.movement).toHaveBeenLastCalledWith("inactive");
  expect(calls.mount).toHaveBeenCalledOnce();
  viewer.dispose();
});

it("forwards surface channel identity through the lazy adapter for Cancel and Retry", async () => {
  const { createMolstarViewer } = await import("../viewer/MolstarViewer");
  const viewer = createMolstarViewer();
  await viewer.mount(document.createElement("div"));
  viewer.cancelSurface("receptor", "pocket");
  viewer.retrySurface("receptor", "pocket");
  expect(calls.cancelSurface).toHaveBeenLastCalledWith("receptor", "pocket");
  expect(calls.retrySurface).toHaveBeenLastCalledWith("receptor", "pocket");
  viewer.cancelSurface("receptor");
  viewer.retrySurface("receptor");
  expect(calls.cancelSurface).toHaveBeenLastCalledWith("receptor", "fragment");
  expect(calls.retrySurface).toHaveBeenLastCalledWith("receptor", "fragment");
  viewer.dispose();
});
