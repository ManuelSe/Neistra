/** Test-only renderer harness; never imported by the application entry point. */
import type { PluginUIContext } from "molstar/lib/mol-plugin-ui/context";
import { StructureElement, Structure } from "molstar/lib/mol-model/structure";
import { SortedArray } from "molstar/lib/mol-data/int";
import { ElementSymbolColorThemeProvider } from "molstar/lib/mol-theme/color/element-symbol";
import { MolstarEngine } from "../viewer/MolstarEngine";
import type { ViewerStructure, ViewerSelectionEvent } from "../viewer/MolecularViewer";
import { SurfaceCalculator } from "../viewer/surface/client";
import { SelectionSurfaceProvider, surfaceInput, surfaceDisplayGeometry, attachSurfaceGeometry } from "../viewer/surface/visual";
import type { SurfaceObject, SurfaceSource } from "../api/types";
import type { SurfaceStatus } from "../viewer/surface/runtime";
import type { SurfaceChannel, SurfaceGeometry } from "../viewer/surface/protocol";

export async function mountSurfaceHarness(container: HTMLElement, source: ViewerStructure) {
  const engine = new MolstarEngine();
  await engine.mount(container);
  // No inherited geometry: render and pick ONLY the worker-generated surface.
  await engine.syncStructures([{ ...source, settings: { ...source.settings, representations: [] } }]);
  const internals = engine as unknown as { plugin: PluginUIContext; loaded: Map<string, {
    structure: Structure; structureRef: string; atomIds: number[];
  }> };
  const { plugin } = internals;
  const loaded = internals.loaded.get(source.entryId)!;
  const component = await plugin.builders.structure.tryCreateComponent(loaded.structureRef, {
    type: { name: "bundle", params: StructureElement.Bundle.fromLoci(Structure.toStructureElementLoci(loaded.structure)) },
    nullIfEmpty: true, label: "Test selection surface",
  }, "surface-test");
  if (!component?.obj) throw new Error("Missing test component");
  const calculator = new SurfaceCalculator();
  const started = performance.now();
  const input = surfaceInput(component.obj.data, loaded.atomIds);
  let unitId = 0;
  const partitioned = Structure.create(component.obj.data.units.flatMap((unit) => {
    const mid = Math.ceil(unit.elements.length / 2);
    return [Array.from(unit.elements).slice(0, mid), Array.from(unit.elements).slice(mid)].filter((ids) => ids.length)
      .map((ids) => { const id = unitId++; return unit.getChild(SortedArray.ofSortedArray(ids)).getCopy(id, id, id); });
  }));
  const partitionInput = surfaceInput(partitioned, loaded.atomIds);
  const partitionInvariant = (["atomIds", "x", "y", "z", "radii"] as const)
    .every((key) => input[key].every((v, i) => v === partitionInput[key][i]));
  const longTasks: number[] = [];
  const observer = new PerformanceObserver((list) => list.getEntries().forEach((e) => longTasks.push(e.duration)));
  observer.observe({ type: "longtask", buffered: false });
  const geometry = await calculator.compute(input, new AbortController().signal);
  const display = await surfaceDisplayGeometry(component.obj.data, loaded.atomIds, geometry, new AbortController().signal, () => {});
  attachSurfaceGeometry(component.obj.data, display.geometry);
  // This unregistered geometry-ownership probe uses an opaque diagnostic visual
  // so its native group IDs can be inspected at the normal molecular threshold.
  // Production managed surfaces retain their own passive state and appearance.
  const representation = await plugin.builders.structure.representation.addRepresentation(component, {
    type: SelectionSurfaceProvider, typeParams: { alpha: 1 }, color: ElementSymbolColorThemeProvider,
  });
  await new Promise((resolve) => setTimeout(resolve, 100));
  observer.disconnect();
  const events: ViewerSelectionEvent[] = [];
  engine.subscribeSelection((event) => events.push(event));
  engine.fitVisible();
  return {
    engine, calculator, events, geometry, input,
    readyMs: performance.now() - started,
    units: component.obj.data.units.length, partitionUnits: partitioned.units.length, partitionInvariant,
    longestSurfaceTaskMs: Math.max(0, ...longTasks),
    representation,
    dispose() { calculator.dispose(); engine.dispose(); },
  };
}

/** Exercise production integration; inspection is test-only, without application globals. */
export async function mountProductionSurfaceHarness(container: HTMLElement, source: ViewerStructure, settleMs = 12_000) {
  const originalWorker = window.Worker;
  const workers = { created: 0, terminated: 0, active: 0, maximum: 0 };
  window.Worker = class extends originalWorker {
    private ended = false;
    constructor(url: string | URL, options?: WorkerOptions) {
      super(url, options);
      workers.created++; workers.active++;
      workers.maximum = Math.max(workers.maximum, workers.active);
    }
    terminate() {
      if (!this.ended) { workers.terminated++; workers.active--; this.ended = true; }
      super.terminate();
    }
  };
  const engine = new MolstarEngine();
  await engine.mount(container);
  const internal = engine as unknown as {
    plugin: PluginUIContext; syncQueue: Promise<void>; measurementRefs: string[]; labelRefs: string[]; pendingSelection: ViewerSelectionEvent["atoms"];
    loaded: Map<string, { structure: Structure; atomIds: number[] }>;
    surfaceBindings: Map<string, { representationRef?: string; installedGeometry?: SurfaceGeometry }>; surfaceRefs: Map<string, string>;
    surfaces: { statuses(): SurfaceStatus[];
      requests: Map<string, { geometry?: SurfaceGeometry }> };
  };
  const wait = async () => {
    await internal.syncQueue;
    const deadline = performance.now() + settleMs;
    while (internal.surfaces.statuses().some((s) => ["queued", "rendering"].includes(s.state))) {
      if (performance.now() > deadline) throw new Error("Production surface did not settle.");
      await new Promise((resolve) => setTimeout(resolve, 10));
    }
    await internal.syncQueue;
  };
  const sync = async (sources: ViewerStructure[]) => { await engine.syncStructures(sources); await wait(); };
  const inspect = () => ({ statuses: internal.surfaces.statuses(),
    meshes: [...internal.surfaceBindings].filter(([, binding]) => binding.representationRef && binding.installedGeometry).map(([key]) => key),
    components: internal.surfaceRefs.size, measurements: [...internal.measurementRefs],
    workers: { ...workers }, camera: engine.getCamera(),
    threshold: internal.plugin.canvas3d?.props.renderer.pickingAlphaThreshold,
    geometry: [...internal.surfaces.requests].map(([id, r]) => ({ id, atomIds: r.geometry ? [...r.geometry.atomIds] : [],
      vertices: r.geometry ? [...r.geometry.vertices] : [], groups: r.geometry ? [...new Set(r.geometry.groups)] : [] })) });
  await sync([source]);
  await new Promise(requestAnimationFrame);
  await new Promise(requestAnimationFrame);
  return { engine, source, workers, wait, sync, inspect,
    details: () => ({ labels: internal.labelRefs.length, measurements: internal.measurementRefs.length,
      selection: structuredClone(internal.pendingSelection),
      representations: [...internal.plugin.state.data.cells.values()].flatMap((cell) => {
        const tags = cell.transform.tags?.filter((tag) => tag.startsWith("neistra-representation-")) ?? [];
        if (!tags.length) return [];
        const repr = (cell.obj?.data as { repr?: { renderObjects: { type: string; values: unknown }[] } } | undefined)?.repr;
        return repr ? [{ tags, objects: repr.renderObjects.map((object) => {
          const values = object.values as Record<string, { ref: { value: unknown } }>;
          const attributes: Record<string, number[]> = {};
          for (const key of ["aPosition", "aNormal", "aStart", "aEnd", "aGroup"]) {
            const value = values[key]?.ref.value;
            if (ArrayBuffer.isView(value) && !(value instanceof DataView)) {
              attributes[key] = Array.from(value as Float32Array);
            }
          }
          return { type: object.type, drawCount: values.drawCount?.ref.value as number, attributes };
        }) }] : [];
      }),
    }),
    geometry: (id: string, channel: SurfaceChannel = "fragment") => internal.surfaces.requests.get(`${channel}:${id}`)?.geometry,
    input: (id: string, channel: SurfaceChannel = "fragment") => {
      const loaded = internal.loaded.get(id)!;
      const component = internal.surfaceRefs.get(`${channel}:${id}`);
      const structure = component ? internal.plugin.state.data.cells.get(component)?.obj?.data as Structure : loaded.structure;
      // Pocket qualification compares the uncropped complete-context field.
      return surfaceInput(structure, loaded.atomIds, channel === "entry" ? "entry" : "fragment");
    },
    failRepresentations(count: number) {
      const builder = internal.plugin.builders.structure.representation;
      const original = builder.addRepresentation.bind(builder);
      builder.addRepresentation = async (...args: Parameters<typeof original>) => {
        if (count-- > 0) throw new Error("Injected representation upload failure.");
        return original(...args);
      };
      return () => { builder.addRepresentation = original; };
    },
    dispose() { engine.dispose(); window.Worker = originalWorker; } };
}

/** Fixture definitions use production schema 2; no legacy writable authority. */
export function fixtureSurface(source: SurfaceSource, inherit = true): SurfaceObject {
  return { id: source.kind, name: `Test ${source.kind}`, visible: true, source,
    appearance: { color_by: "element", custom_color: "#3b82f6", opacity: 0.45, mode: "solid", inherit_atom_colors: inherit } };
}
