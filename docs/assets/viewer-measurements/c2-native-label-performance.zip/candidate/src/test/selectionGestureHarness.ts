import { Vec2 } from "molstar/lib/mol-math/linear-algebra";
import { Camera } from "molstar/lib/mol-canvas3d/camera";
import type { Loci } from "molstar/lib/mol-model/loci";
import type { PluginUIContext } from "molstar/lib/mol-plugin-ui/context";
import type { AtomReference } from "../api/types";
import type { MolstarEngine } from "../viewer/MolstarEngine";

interface ProjectionJitterEvidence {
  updates: boolean[];
  cameraEvents: number;
  before: Camera.Snapshot;
  after: Camera.Snapshot;
}
const projectionJitter = new WeakMap<MolstarEngine, ProjectionJitterEvidence>();

/** Real projection-only camera updates between native clicks and dblclick. */
export function installProjectionJitterOnDoubleClick(engine: MolstarEngine, canvas: HTMLCanvasElement) {
  const native = engine as unknown as { plugin: PluginUIContext };
  canvas.addEventListener("dblclick", () => {
    const camera = native.plugin.canvas3d!.camera;
    const saved = { ...camera.viewOffset };
    const evidence: ProjectionJitterEvidence = { updates: [], cameraEvents: 0,
      before: camera.getSnapshot(), after: camera.getSnapshot() };
    projectionJitter.set(engine, evidence);
    const subscription = camera.changed.subscribe(() => { evidence.cameraEvents++; });
    try {
      Camera.setViewOffset(camera.viewOffset, camera.viewport.width, camera.viewport.height,
        0.25, 0, camera.viewport.width, camera.viewport.height);
      camera.viewOffset.enabled = true;
      evidence.updates.push(camera.update());
    } finally {
      Object.assign(camera.viewOffset, saved);
      evidence.updates.push(camera.update());
      evidence.after = camera.getSnapshot();
      subscription.unsubscribe();
    }
  }, { capture: true, once: true });
}

export function projectionJitterEvidence(engine: MolstarEngine) { return projectionJitter.get(engine); }

/** Read the real native pick raster near a projected atom after viewport resize.
 * A floating projected center need not be a pickable raster sample. This only
 * chooses a confirmed pixel within four CSS pixels; the test still sends a
 * trusted native click and independently checks exact application selection.
 */
export function atomPickPixel(engine: MolstarEngine, projected: { x: number; y: number }, expected: AtomReference) {
  const native = engine as unknown as { plugin: PluginUIContext; referencesFromLoci: (loci: Loci) => AtomReference[] };
  const canvas = native.plugin.canvas3d!;
  for (let radius = 0; radius <= 4; radius++) {
    for (let dx = -radius; dx <= radius; dx++) for (let dy = -radius; dy <= radius; dy++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== radius) continue;
      const x = Math.round(projected.x) + dx, y = Math.round(projected.y) + dy;
      const hit = canvas.identify(Vec2.create(x, y));
      const atoms = native.referencesFromLoci(canvas.getLoci(hit?.id).loci);
      if (atoms.length === 1 && atoms[0].structure_id === expected.structure_id && atoms[0].atom_id === expected.atom_id) return { x, y };
    }
  }
  throw new Error(`No native pixel for ${expected.structure_id}:${expected.atom_id} within four CSS pixels of its projection`);
}


/** UI query counts can precede committed native geometry. Observe drawable
 * content and a stable camera before projecting test targets.
 * No application selection, molecular state, camera or visibility is changed.
 */
export async function settleSelectionScene(engine: MolstarEngine, expected: AtomReference): Promise<void> {
  const native = engine as unknown as { plugin: PluginUIContext; syncQueue: Promise<void>;
    generation: number; boundGeneration: number; rebuilding: boolean };
  await native.syncQueue;
  const deadline = performance.now() + 5000;
  let drawable = false;
  const unsubscribe = engine.subscribeDrawable(value => { drawable = value; });
  let previous = "", stable = 0;
  try {
    while (performance.now() < deadline) {
      await new Promise<void>(resolve => requestAnimationFrame(() => resolve()));
      const ready = drawable && !native.rebuilding && native.boundGeneration === native.generation
        && engine.getRenderedAtomReferences().some(atom => atom.structure_id === expected.structure_id && atom.atom_id === expected.atom_id)
        && !native.plugin.canvas3d!.camera.transition.inTransition;
      const camera = JSON.stringify(engine.getCamera());
      stable = ready && camera === previous ? stable + 1 : 0;
      previous = camera;
      if (stable >= 3) return;
    }
    throw new Error("Native selection scene/camera did not become ready within five seconds");
  } finally { unsubscribe(); }
}
