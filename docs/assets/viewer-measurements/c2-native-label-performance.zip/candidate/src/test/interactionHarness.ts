import { Vec3, Vec4 } from "molstar/lib/mol-math/linear-algebra";
import type { MolstarEngine } from "../viewer/MolstarEngine";
import type { createInteractionRepresentation } from "../viewer/interactionGeometry";
import type { PluginUIContext } from "molstar/lib/mol-plugin-ui/context";
import type { LinesValues } from "molstar/lib/mol-gl/renderable/lines";
import type { InteractionDisplayState, InteractionRecord } from "../interactions/types";

/** Qualification-only native inspection; production never imports this module. */
export async function inspectInteractions(engine: MolstarEngine, options: { allowQueueError?: boolean } = {}) {
  const native = engine as unknown as {
    syncQueue: Promise<void>;
    interactionRepresentation: ReturnType<typeof createInteractionRepresentation>;
    interactions: InteractionRecord[];
    interactionDisplayKey: string;
    generation: number;
    interactionDisplayState: InteractionDisplayState;
    coordinatePreviews: Map<string, unknown>;
    plugin?: PluginUIContext;
  };
  let queueError: string | null = null;
  let queueErrorCode: string | null = null;
  try { await native.syncQueue; }
  catch (error: unknown) {
    if (!options.allowQueueError) throw error;
    queueError = error instanceof Error ? error.message : String(error);
    queueErrorCode = error && typeof error === "object" && "code" in error && typeof error.code === "string" ? error.code : null;
  }
  return {
    queueError,
    queueErrorCode,
    records: native.interactions,
    requestedDisplayKey: native.interactionDisplayKey,
    sceneGeneration: native.generation,
    display: structuredClone(native.interactionDisplayState),
    projectedEndpoints: native.interactions.map(record => record.endpoints.map(point =>
      native.plugin?.canvas3d?.camera.project(Vec4(), Vec3.create(...point)).slice(0, 2) ?? [])),
    objects: native.interactionRepresentation.renderObjects.map(object => {
      const values = object.values as LinesValues;
      const count = values.drawCount.ref.value;
      const vertices = count / 6 * 4;
      return { type: object.type, installed: native.plugin?.canvas3d?.getRenderObjects().some(current => current.id === object.id) ?? false,
        pickable: object.state.pickable, drawCount: count,
        indexCapacity: values.elements.ref.value.length,
        starts: Array.from(values.aStart.ref.value.slice(0, vertices * 3)),
        ends: Array.from(values.aEnd.ref.value.slice(0, vertices * 3)),
        groups: Array.from(values.aGroup.ref.value.slice(0, vertices)),
        colors: Array.from(values.tColor.ref.value.array),
        sizeType: values.dSizeType.ref.value,
        uniformSize: values.uSize.ref.value,
        sizeFactor: values.uSizeFactor.ref.value,
        sizes: Array.from(values.tSize.ref.value.array),
      };
    }),
    representations: native.plugin?.canvas3d?.reprCount.value ?? 0,
    previews: native.coordinatePreviews.size,
    camera: engine.getCamera(),
  };
}
