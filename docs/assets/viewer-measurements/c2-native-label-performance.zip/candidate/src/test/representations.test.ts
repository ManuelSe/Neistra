import { describe, expect, it } from "vitest";
import type { ViewerSettings } from "../api/types";
import type { ViewerStructure } from "../viewer/MolecularViewer";
import { representationLayers } from "../viewer/representationProjection";
import {
  addRepresentation,
  colorSchemes,
  hydrogenDisplayMode,
  molstarRepresentationProfile,
  removeRepresentation,
  representationStyles,
} from "../viewer/settings";
import {
  surfaceObject,
  componentHierarchy,
  proteinStructure,
} from "./molecular-fixtures";

const settings: ViewerSettings = {
  representations: [
    {
      id: "primary",
      style: "cartoon",
      color_by: "element",
      custom_color: "#3b82f6",
      opacity: 1,
    },
  ],
  selection_representations: [],
    selection_colors: [],
    selection_nonpolar_hydrogens: [],
    schema_version: 2, surface_objects: [], selection_hidden_atoms: [],
  components: {
    hydrogens: true,
    nonpolar_hydrogens: true,
    solvent: true,
    ions: true,
    ligands: true,
    protein: true,
  },
  labels: { atoms: false, residues: false, chains: false, structure: false },
};

describe("representation settings", () => {
  it("exposes every required representation and color scheme", () => {
    expect(representationStyles).toEqual([
      "cartoon",
      "backbone",
      "line",
      "stick",
      "thick-stick",
      "ball-and-stick",
      "space-filling",
      "surface",
    ]);
    expect(colorSchemes).toEqual([
      "element",
      "chain",
      "residue",
      "secondary-structure",
      "structure",
      "custom",
    ]);
  });

  it("supports independent ordinary representations and permits removing the last one", () => {
    const expanded = addRepresentation(settings, "stick", "detail");
    expect(expanded.representations.map((item) => item.style)).toEqual([
      "cartoon",
      "stick",
    ]);
    expect(removeRepresentation(expanded, "detail").representations).toHaveLength(1);
    expect(removeRepresentation(settings, "primary").representations).toEqual([]);
  });

  it("projects inherited and exact selection channels independently", () => {
    const normalized = proteinStructure();
    const structure: ViewerStructure = {
      entryId: "protein",
      label: "Protein",
      projection: { format: "mmcif", data: "projection" },
      atomIds: [1, 2, 3],
      normalized,
      hierarchy: componentHierarchy(normalized),
      settings: {
        ...settings,
        representations: [
          settings.representations[0],
          {
            id: "detail",
            style: "ball-and-stick",
            color_by: "custom",
            custom_color: "#ff0000",
            opacity: 0.5,
          },
        ],
        surface_objects: [surfaceObject("surface", { kind: "entry" }, { color_by: "chain", opacity: 0.25 })],
        selection_representations: [
          { style: "stick", atom_ids: [1, 2] },
          { style: "cartoon", atom_ids: [1, 2] },
        ],
      },
    };
    expect(representationLayers(structure)).toEqual([
      expect.objectContaining({ id: "inherited-primary", atomIds: [3] }),
      expect.objectContaining({ id: "inherited-detail", atomIds: [3] }),
      expect.objectContaining({
        id: "surface-surface",
        atomIds: [1, 2, 3],
        opacity: 0.25,
      }),
      expect.objectContaining({
        id: "selection-stick",
        atomIds: [1, 2],
        colorBy: "element",
        opacity: 1,
        exactTarget: true,
      }),
      expect.objectContaining({
        id: "selection-cartoon",
        atomIds: [1, 2],
        exactTarget: true,
      }),
    ]);
  });

  it("intersects exact targets with hydrogen visibility and isolation", () => {
    const normalized = proteinStructure();
    normalized.atoms[1] = { ...normalized.atoms[1], element: "H" };
    const structure: ViewerStructure = {
      entryId: "protein",
      label: "Protein",
      projection: { format: "mmcif", data: "projection" },
      atomIds: [1, 2, 3],
      normalized,
      hierarchy: componentHierarchy(normalized),
      settings: {
        ...settings,
        components: { ...settings.components, hydrogens: false },
        selection_representations: [
          { style: "space-filling", atom_ids: [1, 2, 3] },
        ],
      },
    };
    expect(
      representationLayers(structure, new Set([1, 2])).find(
        (layer) => layer.id === "selection-space-filling",
      )?.atomIds,
    ).toEqual([1]);
    expect(representationLayers(structure, new Set())).toEqual([]);

    const polarOnly = {
      ...structure,
      settings: {
        ...structure.settings,
        components: {
          ...structure.settings.components,
          hydrogens: true,
          nonpolar_hydrogens: false,
        },
      },
    };
    expect(
      representationLayers(polarOnly, new Set([1, 2])).find(
        (layer) => layer.id === "selection-space-filling",
      )?.atomIds,
    ).toEqual([1, 2]);
    const restoredAll = {
      ...polarOnly,
      settings: {
        ...polarOnly.settings,
        components: {
          ...polarOnly.settings.components,
          nonpolar_hydrogens: true,
        },
      },
    };
    expect(
      representationLayers(restoredAll, new Set([1, 2])).find(
        (layer) => layer.id === "selection-space-filling",
      )?.atomIds,
    ).toEqual([1, 2]);
  });

  it("does not invent atoms for hydrogen-free structures in any mode", () => {
    const normalized = proteinStructure();
    const structure: ViewerStructure = {
      entryId: "hydrogen-free",
      label: "Hydrogen-free",
      projection: { format: "mmcif", data: "projection" },
      atomIds: normalized.atoms.map((atom) => atom.id),
      normalized,
      hierarchy: componentHierarchy(normalized),
      settings,
    };

    for (const components of [
      settings.components,
      { ...settings.components, nonpolar_hydrogens: false },
      {
        ...settings.components,
        hydrogens: false,
        nonpolar_hydrogens: false,
      },
    ]) {
      structure.settings = { ...settings, components };
      expect(representationLayers(structure)[0]?.atomIds).toEqual(
        normalized.atoms.map((atom) => atom.id),
      );
    }
  });

  it("uses distinct stick profiles and prevents parent bonds for exact targets", () => {
    const thin = molstarRepresentationProfile("stick", {
      opacity: 1,
      hydrogenMode: "all",
      exactTarget: true,
    });
    const thick = molstarRepresentationProfile("thick-stick", {
      opacity: 1,
      hydrogenMode: "all",
      exactTarget: true,
    });
    expect(thin.type).toBe("ball-and-stick");
    expect(thick.type).toBe("ball-and-stick");
    for (const profile of [thin, thick]) {
      expect(profile.size).toBe("uniform");
      expect(profile.sizeParams).toEqual({ value: 1 });
      expect(profile.typeParams.sizeAspectRatio).toBe(1);
    }
    expect(thin.typeParams.includeParent).toBe(false);
    expect(thick.typeParams.includeParent).toBe(false);
    expect(thick.typeParams.sizeFactor).toBeGreaterThan(
      thin.typeParams.sizeFactor ?? 0,
    );
    expect(thin.typeParams.sizeFactor).toBe(0.22);
    expect(thick.typeParams.sizeFactor).toBe(0.36);
    for (const style of ["ball-and-stick", "space-filling"] as const) {
      const physical = molstarRepresentationProfile(style, {
        opacity: 1, hydrogenMode: "all", exactTarget: true,
      });
      expect(physical.size).toBeUndefined();
      expect(physical.sizeParams).toBeUndefined();
    }
    expect(
      molstarRepresentationProfile("surface", {
        opacity: 0.3,
        hydrogenMode: "none",
        exactTarget: false,
      }).typeParams.includeParent,
    ).toBeUndefined();
  });

  it("maps the durable settings to one effective Molstar hydrogen mode", () => {
    expect(hydrogenDisplayMode(settings.components)).toBe("all");
    expect(
      hydrogenDisplayMode({
        ...settings.components,
        nonpolar_hydrogens: false,
      }),
    ).toBe("polar-only");
    expect(
      hydrogenDisplayMode({
        ...settings.components,
        hydrogens: false,
        nonpolar_hydrogens: false,
      }),
    ).toBe("none");

    for (const style of [
      "line",
      "stick",
      "thick-stick",
      "ball-and-stick",
      "space-filling",
      "surface",
    ] as const) {
      const all = molstarRepresentationProfile(style, {
        opacity: 1,
        hydrogenMode: "all",
        exactTarget: false,
      });
      const polarOnly = molstarRepresentationProfile(style, {
        opacity: 1,
        hydrogenMode: "polar-only",
        exactTarget: false,
      });
      const none = molstarRepresentationProfile(style, {
        opacity: 1,
        hydrogenMode: "none",
        exactTarget: false,
      });

      expect(all.typeParams.ignoreHydrogens).toBe(false);
      expect(all.typeParams.ignoreHydrogensVariant).toBeUndefined();
      expect(polarOnly.typeParams.ignoreHydrogens).toBe(true);
      expect(polarOnly.typeParams.ignoreHydrogensVariant).toBe("non-polar");
      expect(none.typeParams.ignoreHydrogens).toBe(true);
      expect(none.typeParams.ignoreHydrogensVariant).toBe("all");
    }

    for (const style of ["cartoon", "backbone"] as const) {
      expect(
        molstarRepresentationProfile(style, {
          opacity: 1,
          hydrogenMode: "polar-only",
          exactTarget: false,
        }).type,
      ).toBe(style);
    }
  });
});

it("applies full-projection nonpolar classification to all layers with visibility upper bounds", () => {
  const normalized = proteinStructure();
  normalized.atoms[1].element = "H";
  normalized.atoms[2].element = "H";
  const structure: ViewerStructure = {
    entryId: "protein", label: "Protein", projection: { format: "mmcif", data: "projection" },
    atomIds: [1, 2, 3], normalized, hierarchy: componentHierarchy(normalized),
    settings: { ...settings,
      representations: [], surface_objects: [surfaceObject("surface", { kind: "entry" })],
      selection_representations: [{ style: "space-filling", atom_ids: [1, 2, 3] }],
      components: { ...settings.components, nonpolar_hydrogens: false },
      selection_nonpolar_hydrogens: [{ show: true, atom_ids: [2] }, { show: false, atom_ids: [3] }],
    },
  };
  // Atom 2 is classified nonpolar on the full graph; polar atom 3 is unaffected by local Hide.
  const classified = new Set([2]);
  for (const layer of representationLayers(structure, null, classified)) expect(layer.atomIds).toEqual([1, 2, 3]);
  structure.settings.selection_nonpolar_hydrogens = [{ show: false, atom_ids: [2] }];
  structure.settings.components.nonpolar_hydrogens = true;
  for (const layer of representationLayers(structure, null, classified)) expect(layer.atomIds).toEqual([1, 3]);
  structure.settings.components.hydrogens = false;
  structure.settings.selection_nonpolar_hydrogens = [{ show: true, atom_ids: [2] }];
  for (const layer of representationLayers(structure, null, classified)) expect(layer.atomIds).toEqual([1]);
  expect(representationLayers(structure, new Set([2]), classified)).toEqual([]);
});

it("hides atomic layers after assignment while preserving polymer and surface context", () => {
  const normalized = proteinStructure();
  const source: ViewerStructure = { entryId: "protein", label: "Protein", normalized,
    hierarchy: componentHierarchy(normalized), atomIds: [1, 2, 3], projection: { format: "mmcif", data: "" },
    settings: { ...settings, representations: (["line", "cartoon", "backbone"] as const)
      .map((style) => ({ ...settings.representations[0], id: style, style })),
    surface_objects: [surfaceObject("surface", { kind: "entry" })], selection_representations: [{ style: "stick", atom_ids: [2] }], selection_hidden_atoms: [] } };
  const before = representationLayers(source);
  const assignments = structuredClone(source.settings.selection_representations);
  source.settings.selection_hidden_atoms = [1, 2];
  const hidden = representationLayers(source);
  expect(hidden.find((layer) => layer.style === "stick")).toBeUndefined();
  expect(hidden.find((layer) => layer.style === "line")).toMatchObject({ atomIds: [3], exactTarget: true });
  for (const style of ["cartoon", "backbone", "surface"]) {
    expect(hidden.find((layer) => layer.style === style)).toEqual(before.find((layer) => layer.style === style));
  }
  expect(source.settings.selection_representations).toEqual(assignments);
  source.settings.selection_hidden_atoms = [1, 2, 3];
  expect(representationLayers(source).map((layer) => layer.style)).toEqual(["cartoon", "backbone", "surface"]);
  source.settings.selection_hidden_atoms = [];
  expect(representationLayers(source)).toEqual(before);
  source.settings.components.protein = false;
  expect(representationLayers(source)).toEqual([]);
  source.settings.components.protein = true;
  expect(representationLayers(source, new Set([3])).every((layer) => layer.atomIds.every((id) => id === 3))).toBe(true);
});
