import { act, cleanup, render, screen } from "@testing-library/react";
import * as Tooltip from "@radix-ui/react-tooltip";
import userEvent from "@testing-library/user-event";
import { useState, type ComponentProps } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { Selection, SelectionColorMode, StructureProjection } from "../api/types";
import { SelectionStyleDialog as ProductionSelectionStyleDialog } from "../components/SelectionStyleDialog";
import { SelectionColorControls } from "../components/SelectionColorControls";
import { SelectionHydrogenControls } from "../components/SelectionHydrogenControls";
import {
  molecularEntry,
  proteinProjection,
} from "./molecular-fixtures";

afterEach(cleanup);

type SelectionStyleDialogProps = ComponentProps<typeof ProductionSelectionStyleDialog>;
type TestSelectionStyleDialogProps = Omit<
  SelectionStyleDialogProps,
  "selectionColorMode" | "onSelectionColorModeChange"
> & Partial<Pick<
  SelectionStyleDialogProps,
  "selectionColorMode" | "onSelectionColorModeChange"
>>;

function SelectionStyleDialog({
  selectionColorMode: controlledMode,
  onSelectionColorModeChange: controlledChange,
  ...props
}: TestSelectionStyleDialogProps) {
  const [mode, setMode] = useState<SelectionColorMode>("carbon");
  return <ProductionSelectionStyleDialog {...props}
    selectionColorMode={controlledMode ?? mode}
    onSelectionColorModeChange={controlledChange ?? setMode} />;
}

function Harness({
  selection,
  structures,
  onAction,
}: {
  selection: Selection;
  structures: Map<string, StructureProjection>;
  onAction: (
    action: "apply" | "reset",
    style?: "line" | "stick" | "thick-stick" | "ball-and-stick" | "space-filling" | "backbone" | "cartoon",
  ) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  return (
    <Tooltip.Provider delayDuration={0}>
      <button type="button" onClick={() => setOpen(true)}>
        Style selection
      </button>
      <SelectionStyleDialog
        open={open}
        selection={selection}
        entries={[molecularEntry("protein", "Receptor", "protein")]}
        structures={structures}
        eligibilityBusy={false}
        busy={false}
        onOpenChange={setOpen}
        onAction={onAction}
      />
    </Tooltip.Provider>
  );
}

const completeResidue: Selection = {
  schema_version: 1,
  atoms: [
    { structure_id: "protein", atom_id: 1 },
    { structure_id: "protein", atom_id: 2 },
  ],
  granularity: "residue",
  source: "inspector",
};

describe("selection style dialog", () => {
  it("shows channel defaults and sends independently scoped resets", async () => {
    const onAction = vi.fn().mockResolvedValue(undefined);
    const user = userEvent.setup();
    render(<Harness selection={completeResidue} structures={new Map([["protein", proteinProjection()]])} onAction={onAction} />);
    await user.click(screen.getByRole("button", { name: "Style selection" }));
    expect(screen.getByLabelText("Atom detail state")).toHaveTextContent("Entry default: None");
    expect(screen.getByLabelText("Polymer state")).toHaveTextContent("Entry default: Cartoon");
    expect(screen.getByRole("button", { name: "Backbone trace" })).toBeEnabled();
    await user.click(screen.getByRole("button", { name: "Reset atom detail" }));
    expect(onAction).toHaveBeenLastCalledWith("reset", undefined, "atomic");
    await user.click(screen.getByRole("button", { name: "Reset polymer representation" }));
    expect(onAction).toHaveBeenLastCalledWith("reset", undefined, "polymer");
    await user.click(screen.getByRole("button", { name: "Reset representation" }));
    expect(onAction).toHaveBeenLastCalledWith("reset");
  });

  it("previews complete-residue scope and changes selection only on explicit acceptance", async () => {
    const partial = { ...completeResidue, atoms: [completeResidue.atoms[0]], granularity: "atom" as const };
    const onExpandResidues = vi.fn();
    const onAction = vi.fn().mockResolvedValue(undefined);
    render(<Tooltip.Provider><SelectionStyleDialog open selection={partial}
      entries={[molecularEntry("protein", "Receptor", "protein")]}
      structures={new Map([["protein", proteinProjection()]])} eligibilityBusy={false}
      busy={false} onOpenChange={vi.fn()} onAction={onAction} onExpandResidues={onExpandResidues} /></Tooltip.Provider>);
    expect(screen.getByText("Expand to 2 atoms in 1 residue.")).toBeVisible();
    expect(screen.getByRole("button", { name: "Cartoon" })).toBeDisabled();
    expect(onExpandResidues).not.toHaveBeenCalled();
    await userEvent.setup().click(screen.getByRole("button", { name: "Expand to complete residues" }));
    expect(onExpandResidues).toHaveBeenCalledExactlyOnceWith(completeResidue);
    expect(onAction).not.toHaveBeenCalled();
    expect(partial.atoms).toHaveLength(1);
  });

  it("shows mixed colors and applies or resets only the requested property", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn().mockResolvedValue(undefined);
    const onModeChange = vi.fn();
    const entry = molecularEntry("protein", "Receptor", "protein");
    entry.viewer_settings.selection_colors = [{ color: "#ff0000", atom_ids: [1] }];
    const props = { selection: completeResidue, entries: [entry], busy: false, onChange, onModeChange };
    const view = render(<SelectionColorControls {...props} mode="carbon" />);
    expect(screen.getByText("Mixed")).toBeVisible();
    expect(screen.getByRole("button", { name: "Carbon only" })).toHaveAttribute("aria-pressed", "true");
    expect(screen.getByText(/Other selected atoms use element colors/)).toBeVisible();
    await user.click(screen.getByRole("button", { name: "Apply blue color" }));
    expect(onChange).toHaveBeenCalledWith({ property: "color", action: "set", color: "#3b82f6", color_mode: "carbon" });
    await user.click(screen.getByRole("button", { name: "All atoms" }));
    expect(onModeChange).toHaveBeenCalledExactlyOnceWith("all");
    expect(onChange).toHaveBeenCalledTimes(1);
    view.rerender(<SelectionColorControls {...props} mode="all" />);
    await user.click(screen.getByRole("button", { name: "Apply blue color" }));
    expect(onChange).toHaveBeenLastCalledWith({ property: "color", action: "set", color: "#3b82f6" });
    await user.click(screen.getByRole("button", { name: "Reset color" }));
    expect(onChange).toHaveBeenLastCalledWith({ property: "color", action: "reset" });
    expect(completeResidue.atoms).toHaveLength(2);
  });
  it("groups styles, applies and resets without changing the selection, and restores focus", async () => {
    const user = userEvent.setup();
    const onAction = vi.fn().mockResolvedValue(undefined);
    render(
      <Harness
        selection={completeResidue}
        structures={new Map([["protein", proteinProjection()]])}
        onAction={onAction}
      />,
    );
    const launcher = screen.getByRole("button", { name: "Style selection" });
    await user.click(launcher);

    expect(screen.getByRole("dialog", { name: "Style selection" })).toBeVisible();
    expect(screen.getByRole("group", { name: "Atom detail" })).toBeVisible();
    expect(screen.getByRole("group", { name: "Polymer" })).toBeVisible();
    expect(screen.getByText("2 atoms")).toBeVisible();
    expect(screen.getByRole("button", { name: "Cartoon" })).toBeEnabled();

    await user.click(screen.getByRole("button", { name: "Thin sticks" }));
    expect(onAction).toHaveBeenCalledWith("apply", "stick");
    expect(await screen.findByRole("status")).toHaveTextContent(
      "Applied Thin sticks.",
    );

    await user.click(screen.getByRole("button", { name: "Reset representation" }));
    expect(onAction).toHaveBeenLastCalledWith("reset");
    expect(completeResidue.atoms).toHaveLength(2);

    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(launcher).toHaveFocus();
  });

  it("keeps atomic actions available and explains an incompatible polymer target", async () => {
    const user = userEvent.setup();
    const onAction = vi.fn().mockResolvedValue(undefined);
    render(
      <Harness
        selection={{ ...completeResidue, atoms: [completeResidue.atoms[0]] }}
        structures={new Map([["protein", proteinProjection()]])}
        onAction={onAction}
      />,
    );
    await user.click(screen.getByRole("button", { name: "Style selection" }));
    await user.click(screen.getByText("Why unavailable?"));
    expect(screen.getByText(/require every atom in each selected residue/i)).toBeVisible();
    expect(screen.getByRole("button", { name: "Cartoon" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Line" })).toBeEnabled();
    await user.click(screen.getByRole("button", { name: "Line" }));
    expect(onAction).toHaveBeenCalledWith("apply", "line");
  });
});

it("shows mixed effective hydrogen preferences with an icon toggle and separate reset", async () => {
  const user = userEvent.setup();
  const onChange = vi.fn().mockResolvedValue(undefined);
  const entry = molecularEntry("protein", "Receptor", "protein");
  const projection = proteinProjection();
  projection.structure.atoms[0].element = "H";
  projection.structure.atoms[1].element = "H";
  entry.viewer_settings.selection_nonpolar_hydrogens = [{ show: false, atom_ids: [1] }];
  entry.viewer_settings.components.hydrogens = false;
  const props = { selection: completeResidue, entries: [entry],
    structures: new Map([["protein", projection]]), busy: false, onChange };
  const view = render(<Tooltip.Provider><SelectionHydrogenControls {...props} /></Tooltip.Provider>);
  const toggle = screen.getByRole("button", { name: "Show non-polar hydrogens" });
  expect(screen.queryByRole("combobox")).not.toBeInTheDocument();
  expect(toggle).toHaveAttribute("aria-pressed", "mixed");
  expect(screen.getByText(/Show hydrogens is off/)).toBeVisible();
  expect(onChange).not.toHaveBeenCalled();
  const target = { schema_version: 1, atoms: completeResidue.atoms, granularity: "atom", source: "inspector" };
  await user.click(toggle);
  expect(onChange).toHaveBeenLastCalledWith({ property: "nonpolar_hydrogens", action: "set", show: true }, target);
  expect(toggle).toHaveFocus();
  await user.click(screen.getByRole("button", { name: "Use entry hydrogen setting" }));
  expect(onChange).toHaveBeenLastCalledWith({ property: "nonpolar_hydrogens", action: "reset" }, target);
  const resetEntry = structuredClone(entry);
  resetEntry.viewer_settings.selection_nonpolar_hydrogens = [];
  view.rerender(<Tooltip.Provider><SelectionHydrogenControls {...props} entries={[resetEntry]} /></Tooltip.Provider>);
  expect(toggle).toHaveAttribute("aria-pressed", "true");
  expect(screen.getByRole("button", { name: "Use entry hydrogen setting" })).toHaveAttribute("aria-disabled", "true");
  await user.click(toggle);
  expect(onChange).toHaveBeenLastCalledWith({ property: "nonpolar_hydrogens", action: "set", show: false }, target);
});

it("does not misreport failed or pending structure loads as hydrogen-free selections", () => {
  const onChange = vi.fn().mockResolvedValue(undefined);
  const entry = molecularEntry("protein", "Receptor", "protein");
  const view = render(<Tooltip.Provider><SelectionHydrogenControls selection={completeResidue} entries={[entry]}
    structures={new Map()} busy loading onChange={onChange} /></Tooltip.Provider>);
  expect(screen.getByText(/Checking existing hydrogen targets/)).toBeVisible();
  expect(screen.queryByText("No existing hydrogens in this target.")).not.toBeInTheDocument();
  expect(screen.getByRole("button", { name: "Show non-polar hydrogens" })).toHaveAttribute("aria-disabled", "true");
  view.unmount();
  render(<Tooltip.Provider><SelectionStyleDialog open selection={completeResidue} entries={[entry]}
    structures={new Map()} eligibilityBusy={false} eligibilityError="Could not load selection structures."
    busy={false} onHydrogenAppearance={onChange} onOpenChange={() => {}} onAction={vi.fn().mockResolvedValue(undefined)} /></Tooltip.Provider>);
  expect(screen.getByRole("alert")).toHaveTextContent("Could not load selection structures");
  expect(screen.getByRole("button", { name: "Show non-polar hydrogens" })).toHaveAttribute("aria-disabled", "true");
});


it("keeps workspace interaction available, suppresses old feedback and disables empty targets", async () => {
  const user = userEvent.setup();
  let finish = () => {};
  const onAction = vi.fn(() => new Promise<void>((resolve) => { finish = resolve; }));
  const props = { open: true, selection: completeResidue,
    entries: [molecularEntry("protein", "Receptor", "protein")],
    structures: new Map([["protein", proteinProjection()]]), eligibilityBusy: false,
    busy: false, onAction, onOpenChange: vi.fn() };
  const view = render(<Tooltip.Provider><button>Workspace selection</button><SelectionStyleDialog {...props} /></Tooltip.Provider>);
  const dialog = screen.getByRole("dialog");
  expect(dialog).not.toHaveAttribute("aria-modal", "true");
  await user.click(screen.getByRole("button", { name: "Thin sticks" }));
  expect(screen.getByRole("button", { name: "Line" })).toBeDisabled();
  await user.click(screen.getByRole("button", { name: "Workspace selection" }));
  expect(screen.getByRole("button", { name: "Workspace selection" })).toHaveFocus();
  await user.keyboard("{Escape}");
  expect(props.onOpenChange).not.toHaveBeenCalled();
  view.rerender(<Tooltip.Provider><button>Workspace selection</button><SelectionStyleDialog {...props}
    selection={{ ...completeResidue, atoms: [] }} /></Tooltip.Provider>);
  await act(async () => { finish(); await Promise.resolve(); });
  expect(screen.queryByRole("status")).not.toBeInTheDocument();
  expect(screen.getByRole("button", { name: "Thin sticks" })).toBeDisabled();
  expect(screen.getByRole("button", { name: "Reset representation" })).toBeDisabled();
  expect(dialog).toBeVisible();
});


it("uses one action status, blocks overlapping properties, and preserves errors across selection changes", async () => {
  const user = userEvent.setup();
  let reject = (_error: Error) => { void _error; };
  const onAppearance = vi.fn(() => new Promise<void>((_resolve, fail) => { reject = fail; }));
  const props = { open: true, selection: completeResidue,
    entries: [molecularEntry("protein", "Receptor", "protein")],
    structures: new Map([["protein", proteinProjection()]]), eligibilityBusy: false,
    busy: false, onAction: vi.fn().mockResolvedValue(undefined), onAppearance, onOpenChange: vi.fn() };
  const view = render(<Tooltip.Provider><SelectionStyleDialog {...props} /></Tooltip.Provider>);
  await user.click(screen.getByRole("button", { name: "Carbon only" }));
  expect(onAppearance).not.toHaveBeenCalled();
  await user.click(screen.getByRole("button", { name: "Apply red color" }));
  expect(onAppearance).toHaveBeenCalledExactlyOnceWith({ property: "color", action: "set", color: "#ef4444", color_mode: "carbon" });
  expect(screen.getByRole("button", { name: "Line" })).toBeDisabled();
  expect(screen.getByRole("button", { name: "Reset color" })).toBeDisabled();
  expect(screen.getAllByRole("status")).toHaveLength(1);
  view.rerender(<Tooltip.Provider><SelectionStyleDialog {...props}
    selection={{ ...completeResidue, atoms: [completeResidue.atoms[0]] }} /></Tooltip.Provider>);
  await act(async () => { reject(new Error("Revision changed")); await Promise.resolve(); });
  expect(screen.getByRole("alert")).toHaveTextContent("Previous selection: Revision changed");
  expect(screen.getByRole("button", { name: "Apply red color" })).toBeEnabled();
});

it("shows mixed style membership, remembers coloring mode, and resets panel-local draft controls when reopened", async () => {
  const user = userEvent.setup();
  const entry = molecularEntry("protein", "Receptor", "protein");
  entry.viewer_settings.selection_representations = [{ style: "stick", atom_ids: [1] }];
  const props = { open: true, selection: completeResidue, entries: [entry],
    structures: new Map([["protein", proteinProjection()]]), eligibilityBusy: false,
    busy: false, onAction: vi.fn().mockResolvedValue(undefined),
    onAppearance: vi.fn().mockResolvedValue(undefined), onOpenChange: vi.fn() };
  const view = render(<Tooltip.Provider><SelectionStyleDialog {...props} /></Tooltip.Provider>);
  expect(screen.getByRole("button", { name: "Thin sticks" })).toHaveAttribute("aria-pressed", "mixed");
  await user.click(screen.getByRole("button", { name: "All atoms" }));
  await user.click(screen.getByText("Custom…"));
  expect(screen.getByLabelText("Custom selection color")).toBeVisible();
  view.rerender(<Tooltip.Provider><SelectionStyleDialog {...props} open={false} /></Tooltip.Provider>);
  view.rerender(<Tooltip.Provider><SelectionStyleDialog {...props} /></Tooltip.Provider>);
  expect(screen.getByRole("button", { name: "All atoms" })).toHaveAttribute("aria-pressed", "true");
  expect(screen.getByLabelText("Custom selection color")).not.toBeVisible();
  expect(props.onAppearance).not.toHaveBeenCalled();
  expect(screen.getByRole("button", { name: "Thin sticks" })).toHaveAttribute("aria-pressed", "mixed");
});

it("opens the shared surface chooser and management independently of molecular styles", async () => {
  const user = userEvent.setup();
  const entry = molecularEntry("protein", "Receptor", "protein");
  const onCreateSurface = vi.fn().mockResolvedValue(undefined), onManageSurfaces = vi.fn();
  render(<Tooltip.Provider><SelectionStyleDialog open selection={completeResidue} entries={[entry]}
    structures={new Map([["protein", proteinProjection()]])} eligibilityBusy={false} busy={false}
    onCreateSurface={onCreateSurface} onManageSurfaces={onManageSurfaces} onOpenChange={() => {}} onAction={vi.fn().mockResolvedValue(undefined)} /></Tooltip.Provider>);
  await user.click(screen.getByRole("button", { name: "Create surface" }));
  expect(onCreateSurface).toHaveBeenCalledOnce();
  await user.click(screen.getByRole("button", { name: "Manage surfaces (0)" }));
  expect(onManageSurfaces).toHaveBeenCalledOnce();
  await user.click(screen.getByLabelText("About surfaces"));
  expect(screen.getByText(/Cut boundaries can create artificial faces/)).toBeVisible();
});

it.each([
  { ids: [], label: "Hide atom detail", action: "hide", mixed: false },
  { ids: [1], label: "Hide atom detail (mixed visibility)", action: "hide", mixed: true },
  { ids: [1, 2], label: "Show atom detail", action: "show", mixed: false },
])("offers the exact visibility action for $ids", async ({ ids, label, action, mixed }) => {
  const user = userEvent.setup();
  const entry = molecularEntry("protein", "Protein", "protein");
  entry.viewer_settings.selection_hidden_atoms = ids;
  const onAtomVisibility = vi.fn().mockResolvedValue(undefined);
  render(<Tooltip.Provider><SelectionStyleDialog open selection={completeResidue} entries={[entry]}
    structures={new Map()} eligibilityBusy={false} busy={false} onOpenChange={() => {}}
    onAction={vi.fn()} onAtomVisibility={onAtomVisibility} /></Tooltip.Provider>);
  const button = screen.getByRole("button", { name: label });
  expect(button.dataset.mixed === "true").toBe(mixed);
  await user.click(button);
  expect(onAtomVisibility).toHaveBeenCalledWith(action);
  expect(screen.getByRole("dialog", { name: "Style selection" })).toHaveFocus();
  expect(completeResidue.atoms.map((atom) => atom.atom_id)).toEqual([1, 2]);
});

it("disables atom visibility without a selection", () => {
  render(<Tooltip.Provider><SelectionStyleDialog open selection={{ ...completeResidue, atoms: [] }}
    entries={[]} structures={new Map()} eligibilityBusy={false} busy={false} onOpenChange={() => {}}
    onAction={vi.fn()} onAtomVisibility={vi.fn()} /></Tooltip.Provider>);
  expect(screen.getByRole("button", { name: "Hide atom detail" })).toBeDisabled();
});
