import { createServer } from "vite";
import react from "@vitejs/plugin-react";
import { chromium, expect } from "/datadisk/dev/neistra-worktrees/issue-11-ligand-information/node_modules/@playwright/test/index.mjs";
import fs from "node:fs/promises";
import crypto from "node:crypto";
const dir = new URL('.', import.meta.url).pathname;
const sourcePaths = ["apps/web/src/components/MeasurementTool.tsx","apps/web/src/test/measurement-tool.test.tsx"];
const digest = data => crypto.createHash("sha256").update(data).digest("hex");
const identities = async () => Object.fromEntries(await Promise.all(sourcePaths.map(async path => [path,digest(await fs.readFile("/datadisk/dev/neistra-worktrees/issue-11-ligand-information/"+path))])));
const before = await identities();
const server = await createServer({root:dir,configFile:false,plugins:[react()],cacheDir:dir+".vite",resolve:{dedupe:["react","react-dom"]},server:{host:"127.0.0.1",port:5447,strictPort:true,fs:{allow:[dir,"/datadisk/dev/neistra-worktrees/issue-11-ligand-information"]}}});
await server.listen();let browser;const cases=[];const errors=[];
try {
 browser=await chromium.launch({headless:true});const context=await browser.newContext({viewport:{width:320,height:700},hasTouch:true});const page=await context.newPage();page.on("pageerror",e=>errors.push(e.message));await page.goto("http://127.0.0.1:5447");
 await page.getByRole("button",{name:"Saved measurements 1",exact:true}).click();
 const actions=page.getByRole("group",{name:"Actions for Ordered angle",exact:true});
 for(const theme of ["light","dark"]){
  await page.evaluate(theme=>document.documentElement.dataset.theme=theme,theme);
  for(const [phase,reason,paused] of [["undefined","Measurement geometry is undefined or outside numerical limits.",false],["failed-source","Target atom information could not be loaded. Close and reopen this record to retry.",false],["preview","Retired source failure.",true]]){
   await page.evaluate(({reason,paused})=>window.showSavedReason(reason,paused),{reason,paused});const text=paused?"Geometry unavailable during preview.":reason;
   const note=actions.getByText(text,{exact:true});await expect(note).toBeVisible();await note.scrollIntoViewIfNeeded();await expect(page.getByRole("status")).toHaveCount(1);
   const bounds=await note.evaluate(node=>{const b=node.getBoundingClientRect();return {left:b.left,right:b.right,top:b.top,bottom:b.bottom,innerWidth,scrollWidth:node.scrollWidth,clientWidth:node.clientWidth};});
   if(bounds.left<0||bounds.right>320||bounds.scrollWidth>bounds.clientWidth)throw Error("Saved reason overflow: "+JSON.stringify(bounds));
   await page.screenshot({path:dir+theme+"-"+phase+".png"});cases.push({theme,phase,text,bounds,politeStatusCount:1});
  }
  await page.evaluate(()=>window.showSavedReason(null));await expect(actions.getByText("Geometry unavailable during preview.",{exact:true})).toHaveCount(0);await expect(page.getByText("Angle · 90.0°",{exact:true})).toBeVisible();cases.push({theme,phase:"ready-restored",explanationRemoved:true});
 }
 await context.close();
} finally {await browser?.close();await server.close();}
const after=await identities();if(JSON.stringify(before)!==JSON.stringify(after))throw Error("Owned presentation sources changed");if(errors.length)throw Error(errors.join("\n"));
await fs.writeFile(dir+"receipt.json",JSON.stringify({scope:"Controlled saved-reason presentation at320px with actual current CSS/theme; noApp/native/scientific computation qualification",sourceBefore:before,sourceAfter:after,cases,pageErrors:errors,ownedServerClosed:true},null,2)+"\n");console.log(JSON.stringify({directory:dir,cases:cases.length,pageErrors:errors.length,sourceUnchanged:true}));
