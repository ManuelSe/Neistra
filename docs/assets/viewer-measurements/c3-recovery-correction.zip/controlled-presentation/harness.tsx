import React from "react";
import { createRoot } from "react-dom/client";
import { MeasurementTool, type MeasurementToolProps } from "/@fs//datadisk/dev/neistra-worktrees/issue-11-ligand-information/apps/web/src/components/MeasurementTool.tsx";
import { themeStyles } from "/@fs//datadisk/dev/neistra-worktrees/issue-11-ligand-information/apps/web/src/theme.ts";
import "/@fs//datadisk/dev/neistra-worktrees/issue-11-ligand-information/apps/web/src/styles.css";
const style = document.createElement("style"); style.textContent = themeStyles(); document.head.appendChild(style);
const root = createRoot(document.getElementById("root")!);
const targets = [3,1,2].map(atom_id => ({structure_id:"entry", atom_id}));
const measurement = {id:"saved",name:"Ordered angle",kind:"angle" as const,atom_references:targets,visible:true,warnings:[],created_at:"2026-11-17T00:00:00Z",modified_at:"2026-11-17T00:00:00Z"};
const none = () => {};
function render(reason: string | null, paused = false) {
const props: MeasurementToolProps = {
 draft:{session:1,open:true,kind:"distance",slots:[null,null],activeSlot:null,name:"",saving:false,acquiring:false,notice:null},
 entries:[],structures:new Map(),selection:{schema_version:1,atoms:[],granularity:"atom",source:"inspector"},inspectionOrder:null,
 paused,busy:false,value:null,unavailableReason:null,onClose:none,onCancelAcquisition:none,onKind:none,onActiveSlot:none,onRemove:none,onChooseTarget:none,onUseSelection:none,onName:none,onReset:none,onSave:none,
 measurements:[measurement],savedValues:new Map([[measurement.id,reason || paused ? null : 90]]),expandedId:measurement.id,
 expandedInspection:reason ? {status:"unavailable",kind:"angle",targets,reason} : {status:"ready",kind:"angle",targets,value:90},
 onExpand:none,onUpdate:none,onDelete:none,onSelectParticipants:none,onFocusParticipants:none,canFocus:()=>false,onLoadEntry:()=>Promise.resolve(),contactsOpen:false,onContactsOpenChange:none,contactsContent:null,
}; root.render(<MeasurementTool {...props}/>);
}
Object.assign(window,{showSavedReason:render});render("Measurement geometry is undefined or outside numerical limits.");
