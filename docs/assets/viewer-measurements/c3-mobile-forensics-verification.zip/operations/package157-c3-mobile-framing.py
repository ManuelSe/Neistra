"""Preserve the complete closed candidate6 and completed focused correction locally."""

from pathlib import Path
import gzip
import hashlib
import json
import runpy
import zipfile

root = Path.cwd()
assets = root / 'docs/assets/viewer-measurements'
private = root / '.issue-11-evidence'
helper = runpy.run_path(str(assets / 'release-evidence.py.txt'))
sha = lambda data: hashlib.sha256(data).hexdigest()
label = 'c3-candidate6'
index_path = assets / 'c3-forensics-index.json'
index_original = index_path.read_bytes()
index = json.loads(index_original)
original_runs = json.dumps(index['runs'], indent=2)
plan_path = private / 'release-v0.35.0/forensic-upload-plan.json'
plan = json.loads(plan_path.read_text())
assert plan['index_sha256'] == sha(index_original)
assert index['asset_count'] == len(plan['assets']) == 25
assert label not in {run['label'] for run in index['runs']}
gate = json.loads((assets / (label + '-gate.json')).read_text())
recipe = assets / (label + '-recipe.json')
assert not gate['complete'] and len(gate['steps']) == 16
assert [step['exit_code'] for step in gate['steps']] == [0] * 15 + [1]
assert gate['source_before'] == gate['source_after'] and len(gate['source_before']) == 931
assert gate['preceding_source_before'] == gate['preceding_source_after'] == gate['preceding_source_expected']
assert len(gate['preceding_source_before']) == 885
assert gate['source_unchanged'] and gate['preceding_source_unchanged']
assert helper['fingerprint'](recipe)['sha256'] == gate['recipe_sha256']
assert helper['fingerprint'](assets / 'qualification.py.txt')['sha256'] == gate['runner_sha256']
for step in gate['steps']:
    assert sha(gzip.decompress((root / step['log']).read_bytes())) == step['log_sha256']
wrapper = json.loads((private / 'issue157-c3-candidate6-wrapper.json').read_text())
assert len(wrapper['phases']) == 1 and wrapper['phases'][0]['exit'] == 1
assert wrapper['candidate'] == gate['commit']
phase = wrapper['phases'][0]
assert helper['fingerprint'](root / phase['log'])['sha256'] == phase['log_sha256']
focused = private / 'issue157-c3-mobile-framing-correction1'
result = json.loads((focused / 'results.json').read_text())
assert result.get('complete') is True, 'Focused correction is still running; do not snapshot it'
assert result['sources_unchanged']
assert all(step['exit'] == 0 for step in result['steps'])
for name, digest in result['source_before'].items():
    assert helper['fingerprint'](root / name)['sha256'] == digest, name
for step in result['steps']:
    assert helper['fingerprint'](focused / (step['label'] + '.log'))['sha256'] == step['log_sha256']
items = {}
def collect(directory, prefix):
    assert directory.is_dir() and not directory.is_symlink(), directory
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            name = prefix + '/' + path.relative_to(directory).as_posix()
            assert name not in items
            items[name] = path

collect(focused, 'focused')
native = assets / (label + '-native')
retained = private / (label + '-native')
assert not retained.exists()
collect(native, 'failed-candidate6/native')
owned = Path('/tmp/neistra157-c3-candidate6')
collect(owned, 'failed-candidate6/owned-run')
for path in sorted(assets.glob(label + '-*')):
    if path.is_file():
        items['failed-candidate6/' + path.name] = path
for name in [
    'issue157-c3-candidate6-wrapper.json',
    'issue157-c3-candidate6-qualification.log',
    'run157-candidate6.py',
    'run157-c3-mobile-framing-correction1.py',
    'issue157-c3-mobile-framing-test.diff',
    'package157-c3-mobile-framing.py',
]:
    items['operations/' + name] = private / name
canonical = {name: helper['fingerprint'](path) for name, path in sorted(items.items())}
print('CANONICAL', len(canonical), sum(row['bytes'] for row in canonical.values()), flush=True)
batches = []
batch = {}
size = 0
limit = index['part_max_bytes_exclusive']
for ordinal, (name, path) in enumerate(sorted(items.items())):
    estimate = helper['compressed_size'](path) + len(name.encode()) * 2 + 512
    assert estimate < limit, (name, estimate)
    if batch and size + estimate > limit:
        batches.append(batch)
        batch, size = {}, 0
    batch[name] = path
    size += estimate
    if ordinal % 500 == 0:
        print('ESTIMATED', ordinal, flush=True)
if batch:
    batches.append(batch)
output = private / 'release-v0.35.0/forensics'
output.mkdir(exist_ok=True)
parts = []
union = {}
archives = []
for ordinal, batch in enumerate(batches, 1):
    target = output / f'c3-mobile-framing-diagnostic-{ordinal:02}.zip'
    print('ARCHIVE', ordinal, len(batch), flush=True)
    archive = helper['archive'](batch, target)
    archives.append(archive)
    assert archive['bytes'] < limit
    with zipfile.ZipFile(target) as zipped:
        rows = json.loads(zipped.read('manifest.json'))
    assert not union.keys() & rows.keys()
    union.update(rows)
    parts.append({
        'ordinal': ordinal,
        'asset_name': target.name,
        'bytes': archive['bytes'],
        'sha256': archive['sha256'],
        'manifest_entries': archive['outer_manifest_entries'],
        'recursive_verification': archive['verification_counts'],
        'repository_path': None,
    })
    plan['assets'].append({
        'run': label, 'asset_name': target.name, 'local_path': str(target),
        'bytes': archive['bytes'], 'sha256': archive['sha256'],
    })
assert union == canonical
# Re-read every original raw file after packaging: no disappearing or changed bytes.
assert canonical == {name: helper['fingerprint'](path) for name, path in sorted(items.items())}
body = json.dumps({
    'format_version': 1, 'run': label,
    'scope': 'Exact raw closed-run snapshot; recomputed against every finalized part manifest before relocation',
    'files': canonical,
}, sort_keys=True, separators=(',', ':')).encode()
inventory = assets / ('c3-forensics-inventory-' + label + '.json.gz')
assert not inventory.exists()
inventory.write_bytes(gzip.compress(body, mtime=0))
new_run = {
    'label': label, 'failed_candidate': gate['commit'], 'qualification_complete': False,
    'failed_step': gate['steps'][-1]['label'], 'source_count': len(gate['source_before']),
    'source_digest': sha(json.dumps(gate['source_before'], sort_keys=True).encode()),
    'source_unchanged': gate['source_unchanged'],
    'preceding_source_count': len(gate['preceding_source_before']),
    'preceding_source_unchanged': gate['preceding_source_unchanged'],
    'recipe': {'path': str(recipe.relative_to(root)), 'sha256': gate['recipe_sha256']},
    'lossless_logs': [{'label': step['label'], 'path': step['log'], 'uncompressed_sha256': step['log_sha256']} for step in gate['steps']],
    'files': len(canonical), 'raw_bytes': sum(row['bytes'] for row in canonical.values()),
    'extraction_root': 'forensics/' + label,
    'inventory': {'path': str(inventory.relative_to(root)), **helper['fingerprint'](inventory), 'uncompressed_sha256': sha(body)},
    'parts': parts, 'local_exact_union_and_recursive_verification': True,
}
index['runs'].append(new_run)
assert json.dumps(index['runs'][:-1], indent=2) == original_runs
index['asset_count'] = len(plan['assets'])
index['total_asset_bytes'] = sum(part['bytes'] for run in index['runs'] for part in run['parts'])
assert len({part['asset_name'] for run in index['runs'] for part in run['parts']}) == index['asset_count'] < 1000
assert index_path.read_bytes() == index_original
index_path.write_text(json.dumps(index, indent=2) + '\n')
plan['index_sha256'] = sha(index_path.read_bytes())
plan_path.write_text(json.dumps(plan, indent=2) + '\n')
native_files = [path for path in native.rglob('*') if path.is_file()]
native_bytes = sum(path.stat().st_size for path in native_files)
native.rename(retained)
compaction = {
    'scope': 'Lossless failed candidate6 raw output relocation after exact canonical inventory/part union and recursive verification',
    'original': str(native.relative_to(root)), 'retained': str(retained.relative_to(root)),
    'files': len(native_files), 'bytes': native_bytes, 'all_bytes_and_hashes_verified': True,
    'raw_owned_run': '/tmp/neistra157-c3-candidate6 retained; all files also indexed',
    'forensic_index': str(index_path.relative_to(root)),
    'inventory': str(inventory.relative_to(root)), 'failed_gate_remains_unqualified': True,
}
(assets / 'c3-mobile-framing-compaction.json').write_text(json.dumps(compaction, indent=2) + '\n')
receipt = {
    'scope': 'Local preservation only; failed candidate6 remains unqualified and no remote publication asserted',
    'run': new_run, 'archives': archives, 'focused_complete': True,
    'original_runs_unchanged': True, 'old_assets_unchanged': True,
    'index_sha256': sha(index_path.read_bytes()), 'source_count': 931,
    'preceding_source_count': 885, 'lossless_log_count': 16,
}
(private / 'issue157-c3-mobile-framing-package.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('REGISTERED', len(parts), 'NEW_PARTS', index['asset_count'], 'TOTAL_PARTS', 'INDEX', sha(index_path.read_bytes()), flush=True)
