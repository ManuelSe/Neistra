from pathlib import Path
import subprocess,json,hashlib,datetime,runpy
r=Path.cwd();out=r/".issue-11-evidence/issue158-jobs-progress-frontend-after4";assert not out.exists();out.mkdir();tools=runpy.run_path(str(r/"docs/assets/ligand-designation/qualification.py.txt"));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=tools["current_identities"](r);d={"scope":"JobsPanelcoalescing+confirmedcancelpublicationbarrierfinalfrontendchecks; initialtest-onlyES2022/JobEventnumericID/RTLlocatoroptionerrorscorrected;earlierfailedreceiptsretained","source_before":before,"steps":[],"complete":False}
for label,cmd in [("focused",["corepack","pnpm","--dir","apps/web","exec","vitest","run","src/test/jobs.test.tsx"]),("lint",["corepack","pnpm","--dir","apps/web","lint"]),("types",["corepack","pnpm","--dir","apps/web","typecheck"]),("web",["corepack","pnpm","--dir","apps/web","test"]),("build",["corepack","pnpm","--dir","apps/web","build"])]:
 log=out/(label+".log");print("START",label,flush=True)
 with log.open("wb") as stream:p=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
 d["steps"].append({"label":label,"command":cmd,"exit_code":p.returncode,"log_sha256":sha(log)});(out/"receipt.json").write_text(json.dumps(d,indent=2)+"\n");print(log.read_text()[-1800:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
after=tools["current_identities"](r);d.update(source_after=after,source_unchanged=before==after,complete=before==after,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());assert before==after;(out/"receipt.json").write_text(json.dumps(d,indent=2)+"\n");print("COMPLETE",flush=True)
