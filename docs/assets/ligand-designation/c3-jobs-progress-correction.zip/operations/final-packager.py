"""Refresh one correction packet after the independently reproduced ACK-order defect."""
from pathlib import Path
import datetime
import json
import runpy
import zipfile

root=Path.cwd();a=root/'docs/assets/ligand-designation';p=root/'.issue-11-evidence'
out=p/'issue158-jobs-progress-packet/final-ack-order';assert not out.exists();out.mkdir()
h=runpy.run_path(str(a/'release-evidence.py.txt'));q=runpy.run_path(str(a/'qualification.py.txt'))
digest=lambda value:h['sha'](json.dumps(value,sort_keys=True).encode())
before=q['current_identities'](root);assert len(before)==1005
keys=['apps/web/src/components/JobsPanel.tsx','apps/web/src/test/jobs.test.tsx']
current={keys[0]:'88f32f413de045414e381c404924cb96d6b65be58bb9a7b7de5c0c5ef3ab6f0d',keys[1]:'05ee8183221f43c85214c2159a624ba69a56742fd5c3e1d1ae4c5a83bd4f49e7'}
assert all(before[name]==value for name,value in current.items())
old=json.loads(Path('/tmp/neistra158-reader-0350-source.json').read_text());expected_old=old['files']
old_before=q['extracted_identities'](Path(old['root']),expected_old);assert len(old_before)==931 and old_before==expected_old
draft=p/'issue158-jobs-progress-packet/prior-candidate-first-draft'
old_zip=draft/'c3-jobs-progress-correction.zip';old_checkpoint=draft/'c3-jobs-progress-checkpoint.json'
assert h['fingerprint'](old_zip)['sha256']=='b90838bdb60fae382d5240b6127954020f39146f7322e56956173782a86b6850'
assert h['fingerprint'](old_checkpoint)['sha256']=='f0e9ec592249eedbcef1d79063c7b08fe344b9fbc70a608dc55113efd4394210'
prior=json.loads(old_checkpoint.read_text())
with zipfile.ZipFile(old_zip) as archive:
    old_manifest=json.loads(archive.read('manifest.json'));original={name:archive.read(name) for name in old_manifest}
assert all(h['fingerprint'](original[name])==identity for name,identity in old_manifest.items())
assert len(original)==77
items={};old_mapping={}
renames={'source-proof.json':'prior-candidate/source-proof.json','correction-context.json':'prior-candidate/correction-context.json','operations/packager.py':'operations/prior-candidate-packager.py'}
for name,body in original.items():
    target=renames.get(name,name);h['add'](items,target,body);old_mapping[name]=target
h['add'](items,'prior-candidate/checkpoint.json',old_checkpoint)
h['add'](items,'prior-candidate/status.json',p/'issue158-jobs-progress-packet/prior-candidate-status.json')
independent_dir=p/'issue158-jobs-invalidation-architecture1'
before_assessment=draft/'independent-ack-order'
for path in sorted(before_assessment.iterdir()):
    assert path.is_file() and not path.is_symlink();h['add'](items,'independent-architecture-before/'+path.name,path)
after_assessment=independent_dir/'correction-reassessment-after.json'
assert h['fingerprint'](after_assessment)['sha256']=='6395decc04d805cda1e83ce8f0caabac0ad903cc879fb7edbc5b0e941fe596bb'
assessment=json.loads(after_assessment.read_text())
assert assessment['verdict']=='PASS' and not assessment['findings'] and assessment['reviewed_source_files']==current
assert assessment['independent_probe']['actual_tool_session']==50523 and assessment['independent_probe']['actual_exit']==0 and assessment['independent_probe']['tests']==3
h['add'](items,'independent-architecture-after/correction-reassessment-after.json',after_assessment)
for name,identity in assessment['proof_files'].items():
    path=independent_dir/name;assert h['fingerprint'](path)['sha256']==identity
    h['add'](items,'independent-architecture-after/'+name,path)
negative_dir=p/'issue158-jobs-ack-before1';negative=json.loads((negative_dir/'receipt.json').read_text())
assert negative['exit_code']==1 and negative['source_before']==negative['source_after']
assert negative['source_before'][keys[0]]==prior['final_source_identities'][keys[0]]
assert negative['source_before'][keys[1]]==current[keys[1]]
assert h['fingerprint'](negative_dir/'raw.log')['sha256']==negative['log_sha256']
front_dir=p/'issue158-jobs-progress-frontend-after5';front=json.loads((front_dir/'receipt.json').read_text())
assert front['complete'] and front['source_before']==front['source_after']==before and front['source_unchanged']
assert [step['label'] for step in front['steps']]==['focused','lint','types','web','build']
for step in front['steps']:
    assert step['exit_code']==0 and h['fingerprint'](front_dir/(step['label']+'.log'))['sha256']==step['log_sha256']
front_actual=json.loads((front_dir/'actual-enclosing.json').read_text())
assert front_actual['actual_session']==97335 and front_actual['actual_exit']==0 and front_actual['focused_jobs']==11 and front_actual['full_web_tests']==1310 and front_actual['full_web_suites']==122
assert front_actual['receipt_sha256']==h['fingerprint'](front_dir/'receipt.json')['sha256']==assessment['root_frontend_receipt_sha256']
native_dir=p/'issue158-jobs-progress-native-after4';native=json.loads((native_dir/'receipt.json').read_text())
assert native['exit_code']==0 and native['source_before']==native['source_after']==before and native['source_unchanged']
assert h['fingerprint'](native_dir/'raw.log')['sha256']==native['log_sha256']
report=json.loads((native_dir/'browser.json').read_text());stats=report['stats']
assert (stats['expected'],stats['skipped'],stats['unexpected'],stats['flaky'])==(2,2,0,0) and not report['errors']
native_actual=json.loads((native_dir/'actual-enclosing.json').read_text())
assert native_actual['actual_session']==75251 and native_actual['actual_exit']==0
assert native_actual['receipt_sha256']==h['fingerprint'](native_dir/'receipt.json')['sha256']==assessment['root_native_receipt_sha256']
def cases(suites):
    result=[]
    for suite in suites:
        for spec in suite.get('specs',[]):result.extend((spec,test) for test in spec.get('tests',[]))
        result.extend(cases(suite.get('suites',[])))
    return result
tests=cases(report['suites']);assert len(tests)==4
assert all(len(t['results'])==1 and t['results'][0]['retry']==0 for _,t in tests)
skips=[dict(file=s['file'],title=s['title'],project=t['projectName'],annotations=t['annotations']) for s,t in tests if t['expectedStatus']=='skipped']
assert skips==prior['unchanged_native_exclusions']
assert before['tests/e2e/demonstration-job.spec.ts']==expected_old['tests/e2e/demonstration-job.spec.ts']
retained={}
for directory in [negative_dir,front_dir,native_dir]:
    count,excluded=h['add_reader_workspace'](items,directory,'closed-evidence/'+directory.name);assert not excluded;retained[directory.name]=count
store=Path('/tmp/neistra158-jobs-progress-native-after4')
count,excluded=h['add_reader_workspace'](items,store,'owned-stores/'+store.name);assert not excluded;retained[store.name]=count
for name,member in [(keys[0],'source-versions/JobsPanel-terminal-ack-final.tsx'),(keys[1],'source-versions/jobs-test-terminal-ack-final.tsx')]:
    assert h['fingerprint'](root/name)['sha256']==current[name];h['add'](items,member,root/name)
reconstruction=dict(scope='Current terminal-ACK test body binds both the new before-failure receipt and final passing receipts by exact SHA; no guessed historical body is asserted',new_before_test_matches_current_final_test=current[keys[1]],new_before_production_matches_preserved_prior_production=negative['source_before'][keys[0]],prior_exact_versions_retained='source-versions/reconstruction-controls.json',prior_candidate_changed_required='independent-architecture-before/correction-reassessment.json')
h['add'](items,'terminal-ack-reconstruction-controls.json',h['encoded'](reconstruction))
h['add'](items,'operations/final-packager.py',Path(__file__))
h['add'](items,'operations/issue158-jobs-progress-after5-run.py',p/'issue158-jobs-progress-after5-run.py')
after=q['current_identities'](root);old_after=q['extracted_identities'](Path(old['root']),expected_old)
assert before==after and old_before==old_after==expected_old
proof=dict(scope='Current packet identity proof only; not whole release qualification',current_before=before,current_after=after,current_count=1005,current_digest=digest(before),current_unchanged=True,preceding_expected=expected_old,preceding_before=old_before,preceding_after=old_after,preceding_count=931,preceding_tag=old['tag'],preceding_commit=old['commit'],preceding_unchanged=True,prior_candidate_current_digest=prior['current_source_digest'],changed_from_prior_candidate=sorted(k for k in before if before[k]!=json.loads(original['source-proof.json'])['current_before'][k]))
assert proof['changed_from_prior_candidate']==keys
h['add'](items,'source-proof.json',h['encoded'](proof))
facts=dict(scope='Terminal-ACK-corrected jobs progress checkpoint; focused validation and scoped architecture review only, not all-seven readiness or full release qualification',decision='D189',current_source_identities=current,current_source_count=1005,current_source_digest=digest(before),preceding_source_count=931,current_and_preceding_sources_unchanged=True,
    correction='Coalesce both event-driven list/event refreshes with cancelRefetch:false; cancel the old returned-project list refresh before publishing cancellation ACK, while preserving any already observed terminal cancelled/completed/failed result against an older nonterminal ACK, including cache cancellation rollback.',
    prior_candidate=dict(source_identities=prior['final_source_identities'],focused_frontend_passed=8,full_web_passed=1307,native_passed=2,historical_native_exclusions=2,status='CHANGES_REQUIRED after independent ACK-order reproduction; earlier passing checks do not establish final approval',immutable_private_archive_sha256=h['fingerprint'](old_zip)['sha256'],immutable_private_checkpoint_sha256=h['fingerprint'](old_checkpoint)['sha256'],all_original_payloads_retained_directly=True,original_payload_count=len(original),renamed_metadata=renames,no_prior_zip_nested=True),
    new_negative_control=dict(root_observed_session=82198,root_observed_exit=1,failed_terminal_cases=3,other_cases_filtered_not_release_exclusions=True,scenario='A newer GET publishes cancelled/completed/failed before an older legitimate running+cancellation_requested cancellation ACK; prior implementation regresses terminal state.'),
    final_frontend=dict(actual_enclosing=front_actual,focused_passed=11,full_web_passed=1310,web_suites=122,lint='PASS',types='PASS',build='PASS',source_maps_unchanged=True),
    final_native=dict(actual_enclosing=native_actual,passed=2,unchanged_historical_exclusions=2,failed=0,flaky=0,retries=0,source_maps_unchanged=True,original_native_test_parameters_deadlines_retries_unchanged=True),
    independent_scoped_architecture=dict(verdict='PASS',receipt_sha256=h['fingerprint'](after_assessment)['sha256'],source_identities=current,actual_probe_session=50523,actual_probe_exit=0,independent_cases=3,scope='Changed jobs progress and cancellation publication only; excludes final complete feature/readiness gate'),
    all_prior_source_reconstructions_exact_hash_bound=True,prior_attempts_retained='All earlier source versions, failed frontend/native checks, complete three earlier native stores and incomplete candidate finding remain direct payloads. Historical final-labelled source filenames refer to that prior candidate; current bodies are terminal-ack-final filenames.',new_retained=retained,
    no_raw_c8_native_or_supplemental_forensic_parts_rebundled=True,all_focused_passes_remain_distinct_from_complete_gate=True,
    required_next=['Fresh complete C9all42, independent summary, recursive packaging and actual enclosing readback; no pooled partial gates','Final integrated same-candidate all-seven specialist assessment and normal protected PR/merge','Fresh exact-master qualification, remotely verified release assets and anonymous supplemental forensic readback before child closeout/program continuation'])
h['add'](items,'correction-context.json',h['encoded'](facts))
artifact=out/'c3-jobs-progress-correction.zip';packet=h['archive'](items,artifact)
with zipfile.ZipFile(artifact) as archive:
    manifest=json.loads(archive.read('manifest.json'))
    assert all(manifest[target]==old_manifest[name] and archive.read(target)==original[name] for name,target in old_mapping.items())
assert q['current_identities'](root)==before and q['extracted_identities'](Path(old['root']),expected_old)==expected_old
assert h['fingerprint'](old_zip)['sha256']=='b90838bdb60fae382d5240b6127954020f39146f7322e56956173782a86b6850'
record=dict(**facts,archive=artifact.name,archive_bytes=packet['bytes'],archive_sha256=packet['sha256'],outer_manifest_entries=packet['outer_manifest_entries'],recursive_verification=packet['verification_counts'],all_payload_hashes_recursive_crcs_and_old_payload_retention_verified=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
local_checkpoint=out/'c3-jobs-progress-checkpoint.json';local_checkpoint.write_text(json.dumps(record,indent=2)+'\n')
# Preserve immutable private originals and replace only the two authorized public
# names atomically; raw source/store evidence stays intact at its owned paths.
for src,target in [(artifact,a/artifact.name),(local_checkpoint,a/local_checkpoint.name)]:
    temp=target.with_name(target.name+'.terminal-ack-part');assert not temp.exists();temp.write_bytes(src.read_bytes());temp.replace(target)
(out/'packager-result.json').write_text(json.dumps(dict(archive=packet,checkpoint=h['fingerprint'](a/local_checkpoint.name),old77_payloads_verified=True,current1005_preceding931_unchanged=True,source_digest=digest(before)),indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
