"""Retain closed jobs progress/cancellation corrections and exact historical sources."""
from pathlib import Path
import datetime
import json
import runpy
import zipfile

root=Path.cwd();a=root/'docs/assets/ligand-designation';p=root/'.issue-11-evidence'
out=p/'issue158-jobs-progress-packet';assert out.is_dir() and not (out/'packager-result.json').exists()
h=runpy.run_path(str(a/'release-evidence.py.txt'));q=runpy.run_path(str(a/'qualification.py.txt'))
sha=h['sha'];digest=lambda x:sha(json.dumps(x,sort_keys=True).encode())
before=q['current_identities'](root);assert len(before)==1005
old=json.loads(Path('/tmp/neistra158-reader-0350-source.json').read_text());expected_old=old['files']
old_before=q['extracted_identities'](Path(old['root']),expected_old);assert len(old_before)==931 and old_before==expected_old
keys=['apps/web/src/components/JobsPanel.tsx','apps/web/src/test/jobs.test.tsx']
final_expected={keys[0]:'b8347f42e62782225e8f78e7871daf4719917400bbda77fb0b6c54221cb29831',keys[1]:'8e6bc22aa172753792e99065982d18975923928475719c6256a7bb0dd0929165'}
assert all(before[n]==v for n,v in final_expected.items())
versions=out/'source-versions';controls=json.loads((versions/'reconstruction-controls.json').read_text())
assert controls['root_supplied_exact_transformations_confirmed']
for name,row in controls['files'].items():assert h['fingerprint'](versions/name)=={k:row[k] for k in ['bytes','sha256']}
def read_receipt(name):return json.loads((p/name/'receipt.json').read_text())
def subset_matches(receipt,prod,test):
    assert receipt['source_before'][keys[0]]==h['fingerprint'](versions/prod)['sha256']
    assert receipt['source_before'][keys[1]]==h['fingerprint'](versions/test)['sha256']
def verify_frontend(name,expected_complete):
    directory=p/name;r=read_receipt(name)
    for step in r['steps']:assert h['fingerprint'](directory/(step['label']+'.log'))['sha256']==step['log_sha256']
    assert r['complete'] is expected_complete
    if expected_complete:assert r['source_before']==r['source_after'] and r['source_unchanged']
    return r
front={}
for number in [1,2,3,4]:front[number]=verify_frontend('issue158-jobs-progress-frontend-after'+str(number),number>=3)
assert front[1]['steps'][-1]['label']=='lint' and front[1]['steps'][-1]['exit_code']==1
assert front[2]['steps'][-1]['label']=='types' and front[2]['steps'][-1]['exit_code']!=0
assert all(s['exit_code']==0 for n in [3,4] for s in front[n]['steps'])
assert front[4]['source_before']==front[4]['source_after']==before
for n,test in [(1,'jobs-test-before-and-after1.tsx'),(2,'jobs-test-after2.tsx'),(3,'jobs-test-after3.tsx'),(4,'jobs-test-final.tsx')]:
    subset_matches(front[n],'JobsPanel-final.tsx' if n==4 else 'JobsPanel-progress-only.tsx',test)
negative={}
for name,prod,test in [('issue158-jobs-progress-before1','JobsPanel-C8.tsx','jobs-test-before-and-after1.tsx'),('issue158-jobs-cancel-before1','JobsPanel-progress-only.tsx','jobs-test-final.tsx')]:
    r=read_receipt(name);assert r['exit_code']==1 and r['source_before']==r['source_after']
    assert h['fingerprint'](p/name/'raw.log')['sha256']==r['log_sha256']
    subset_matches(r,prod,test);negative[name]=r
native={};reports={};enclosing={}
for number in [1,2,3]:
    name='issue158-jobs-progress-native-after'+str(number);directory=p/name;r=read_receipt(name)
    assert r['source_before']==r['source_after'] and r['source_unchanged'] and len(r['source_before'])==1005
    assert h['fingerprint'](directory/'raw.log')['sha256']==r['log_sha256']
    report=json.loads((directory/'browser.json').read_text())
    native[number]=r;reports[number]=report
    actual=json.loads((directory/'actual-enclosing.json').read_text());assert actual['receipt_sha256']==h['fingerprint'](directory/'receipt.json')['sha256']
    assert actual['actual_exit']==r['exit_code'];enclosing[number]=actual
    subset_matches(r,'JobsPanel-final.tsx' if number==3 else 'JobsPanel-progress-only.tsx','jobs-test-final.tsx' if number==3 else 'jobs-test-after3.tsx')
assert native[1]['exit_code']==1 and reports[1]['stats']['unexpected']==1
assert native[1]['source_before']==native[2]['source_before']==front[3]['source_after']
assert native[3]['source_before']==before
def cases(suites):
    result=[]
    for suite in suites:
        for spec in suite.get('specs',[]):
            result.extend((spec,test) for test in spec.get('tests',[]))
        result.extend(cases(suite.get('suites',[])))
    return result
skips={}
for number in [2,3]:
    report=reports[number];stats=report['stats'];assert stats['expected']==2 and stats['skipped']==2 and stats['unexpected']==stats['flaky']==0 and not report['errors']
    tests=cases(report['suites']);assert len(tests)==4
    assert all(len(test['results'])==1 and test['results'][0]['retry']==0 for _,test in tests)
    skipped=[dict(file=spec['file'],title=spec['title'],project=test['projectName'],annotations=test['annotations']) for spec,test in tests if test['expectedStatus']=='skipped']
    assert len(skipped)==2;skips[number]=skipped
assert skips[2]==skips[3]
test_name='tests/e2e/demonstration-job.spec.ts';assert before[test_name]==expected_old[test_name]
final_actual=json.loads((p/'issue158-jobs-progress-frontend-after4/actual-enclosing.json').read_text())
assert final_actual['actual_session']==75792 and final_actual['actual_exit']==0
assert final_actual['receipt_sha256']==h['fingerprint'](p/'issue158-jobs-progress-frontend-after4/receipt.json')['sha256']
c8=json.loads((a/'c4-candidate8-gate.json').read_text());assert sorted(k for k in before if before[k]!=c8['source_before'][k])==keys
assert h['fingerprint'](versions/'JobsPanel-C8.tsx')['sha256']==c8['source_before'][keys[0]]
assert h['fingerprint'](versions/'jobs-test-C8.tsx')['sha256']==c8['source_before'][keys[1]]
trace_path=next((p/'issue158-jobs-progress-native-after1/native').rglob('trace.zip'))
submissions=[];cancels=[]
with zipfile.ZipFile(trace_path) as trace:
    for name in trace.namelist():
        if not name.endswith('.network'):continue
        for line in trace.read(name).splitlines():
            row=json.loads(line).get('snapshot',{});request=row.get('request',{});response=row.get('response',{})
            if request.get('method')!='POST' or not request.get('url','').endswith(('/jobs','/cancel')):continue
            content=request.get('postData',{});key=content.get('_sha1');body=json.loads(trace.read('resources/'+key)) if key else None
            if body and body.get('parameters',{}).get('step_count')==100 and body['parameters'].get('delay_ms')==50:
                submissions.append(dict(url=request['url'],at_ms=row['_monotonicTime'],parameters=body['parameters']))
            if request.get('url','').endswith('/cancel'):
                key=response.get('content',{}).get('_sha1');body=json.loads(trace.read('resources/'+key)) if key else None
                cancels.append(dict(url=request['url'],at_ms=row['_monotonicTime'],status=response['status'],body=body))
assert len(submissions)==len(cancels)==1 and cancels[0]['status']==409
assert cancels[0]['body']['detail']['message']=='Job is already completed'
timing=dict(scope='Exact HTTP trace readback; concurrency attribution remains an inference',submission=submissions[0],cancel=cancels[0],submission_to_cancel_ms=cancels[0]['at_ms']-submissions[0]['at_ms'],nominal_configured_step_delays_ms=5000,running_assertion_reached=True,limitation='Trace establishes completed-before-cancel timing, not that one particular concurrent workload exclusively caused it. No job parameter, deadline, retry or test source was changed.')
(out/'native-after1-timing.json').write_text(json.dumps(timing,indent=2)+'\n')
items={};retained={}
names=['issue158-jobs-progress-before1','issue158-jobs-cancel-before1']+['issue158-jobs-progress-frontend-after'+str(n) for n in [1,2,3,4]]+['issue158-jobs-progress-native-after'+str(n) for n in [1,2,3]]
for name in names:
    count,excluded=h['add_reader_workspace'](items,p/name,'closed-evidence/'+name);assert not excluded;retained[name]=count
for number in [1,2,3]:
    name='neistra158-jobs-progress-native-after'+str(number)
    count,excluded=h['add_reader_workspace'](items,Path('/tmp')/name,'owned-stores/'+name);assert not excluded;retained[name]=count
h['add_tree'](items,'source-versions',versions)
h['add'](items,'native-after1-timing.json',out/'native-after1-timing.json')
for name in ['issue158-jobs-progress-native-run.py','issue158-jobs-progress-after2-run.py','issue158-jobs-progress-after3-run.py','issue158-jobs-progress-after4-run.py']:
    h['add'](items,'operations/'+name,p/name)
h['add'](items,'operations/packager.py',Path(__file__))
after=q['current_identities'](root);old_after=q['extracted_identities'](Path(old['root']),expected_old)
assert before==after and old_before==old_after==expected_old
proof=dict(scope='Packet source identity proof; no complete release gate claimed',current_before=before,current_after=after,current_count=1005,current_digest=digest(before),current_unchanged=True,preceding_expected=expected_old,preceding_before=old_before,preceding_after=old_after,preceding_count=931,preceding_tag=old['tag'],preceding_commit=old['commit'],preceding_unchanged=True,only_changed_sources_from_c8=keys)
h['add'](items,'source-proof.json',h['encoded'](proof))
references={name:h['fingerprint'](a/name) for name in ['c3-forensics-index.json','c3-forensics-verification4.json','c3-forensics-verification4.zip']}
facts=dict(scope='Jobs progress and cancellation correction checkpoint; focused passing evidence only, not complete release qualification or final push readiness',decision='D189',final_source_identities=final_expected,current_source_count=1005,current_source_digest=digest(before),preceding_source_count=931,current_and_preceding_sources_unchanged=True,
    correction='Coalesce both progress-triggered list/event refreshes with cancelRefetch:false. On successful cancellation, cancel the old list refresh for the returned job.project_id before publishing its ACK into that same cache; late old responses must not overwrite confirmed cancellation.',
    exact_source_reconstructions=dict(files=controls['files'],all_recorded_source_versions_bound=True,method='Only byte-for-byte SHA matches to recorded receipts are retained; exact root-supplied reverse transformations independently confirm the reconstructions.'),
    permanent_negative_controls=dict(progress=dict(root_observed_session=32848,root_observed_exit=1,failed=2,observation='Repeated progress notifications start five fetches where the held response should remain one; exact before1test and C8production source retained.'),cancel=dict(root_observed_session=4852,root_observed_exit=1,failed=1,observation='Held old running refresh rewrites the confirmed cancelled ACK without the publication barrier; exact final regression and progress-only production source retained.')),
    frontend_attempts=dict(after1='Focused passes but lint fails unsupported ES2023 findLast typing; receipt has start-map only.',after2='Focused/lint pass but types reject string JobEvent ID and unsupported RTL exact option; receipt has start-map only.',after3='Progress-only source passes seven focused cases and1306full frontend cases plus lint/types/build with frozen source maps; predates cancellation guard.',after4=dict(actual_enclosing=final_actual,focused_passed=8,full_frontend_passed=1307,frontend_suites=122,lint='PASS',types='PASS',build='PASS',source_maps_unchanged=True)),
    native_attempts=dict(after1=dict(actual_enclosing=enclosing[1],failure='Running state is reached; server cancellation returns409 because the job has already completed',trace_readback=timing,report_skipped_or_not_run=3),after2=dict(actual_enclosing=enclosing[2],passed=2,unchanged_historical_skips=2,failed=0,flaky=0,retries=0,source_identical_to_after1=True,scope='Quiet unchanged progress-only source; predates cancellation barrier'),after3=dict(actual_enclosing=enclosing[3],passed=2,unchanged_historical_skips=2,failed=0,flaky=0,retries=0,scope='Final cancellation-barrier source',source_maps_unchanged=True)),
    unchanged_native_exclusions=skips[3],all_original_native_test_source_and_parameters_deadlines_retries_unchanged=True,retained=retained,prior_independent_actual_component_proof_references=references,no_raw_c8_native_or_forensic_parts_rebundled=True,
    specialist_scope='Independent specialist assessments and final same-candidate all-seven gate are coordinated separately by root; this packet claims neither.',
    required_next=['Fresh complete C9all42, independent summary, recursive packaging and actual enclosing readback; no pooled partial gates','Final integrated same-candidate all-seven assessment and normal protected PR/merge','Fresh exact-master gate, verified release assets including anonymous forensic readback, child closeout and program continuation'])
h['add'](items,'correction-context.json',h['encoded'](facts))
archive=h['archive'](items,a/'c3-jobs-progress-correction.zip')
assert q['current_identities'](root)==before and q['extracted_identities'](Path(old['root']),expected_old)==expected_old
record=dict(**facts,archive=archive['file'],archive_bytes=archive['bytes'],archive_sha256=archive['sha256'],outer_manifest_entries=archive['outer_manifest_entries'],recursive_verification=archive['verification_counts'],all_payload_hashes_and_recursive_crcs_verified=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
target=a/'c3-jobs-progress-checkpoint.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
(out/'packager-result.json').write_text(json.dumps(dict(archive=archive,checkpoint=h['fingerprint'](target),source_digest=digest(before),current1005_preceding931_unchanged=True),indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
