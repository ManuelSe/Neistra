import { QueryClient, QueryClientProvider } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/node_modules/@tanstack/react-query";
import * as Tooltip from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/node_modules/@radix-ui/react-tooltip";
import { act, cleanup, render, screen, waitFor } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/node_modules/@testing-library/react";
import userEvent from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/node_modules/@testing-library/user-event";
import type { ReactElement } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/node_modules/react";
import { afterEach, describe, expect, it, vi } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/node_modules/vitest";
import { ApiError, jobApi } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/src/api/client";
import type { Job, JobDefinition, JobEvent } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/src/api/types";
import { JobSubmitDialog } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/src/components/JobSubmitDialog";
import { JobsPanel } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/src/components/JobsPanel";
import { molecularProject } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/src/test/molecular-fixtures";

const definition: JobDefinition = {
  plugin_name: "molweave.demo",
  job_type: "molweave.demo.structure_statistics",
  implementation_version: "1.0.0",
  label: "Structure statistics",
  description: "Calculate statistics and return a translated copy.",
  parameter_schema: {
    properties: {
      step_count: { type: "integer", title: "Steps", default: 5, minimum: 1, maximum: 100 },
      delay_ms: { type: "integer", title: "Delay per step (ms)", default: 100 },
      fail_at_step: { title: "Fail at step", default: null, anyOf: [] },
      translation: { type: "array", title: "Result translation", default: [0, 0, 0] },
    },
  },
  input_roles: [
    {
      role: "structure",
      label: "Structures",
      minimum: 1,
      maximum: 2,
      structure_types: ["protein", "ligand", "complex", "solvent", "unknown"],
    },
  ],
  result_roles: [
    {
      role: "structure",
      label: "Structure copy",
      media_types: ["application/vnd.molweave.normalized-structure+json"],
      importable_structure: true,
    },
  ],
};

function job(status: Job["status"] = "completed"): Job {
  return {
    id: "job-1",
    project_id: "project-1",
    plugin_name: "molweave.demo",
    job_type: definition.job_type,
    implementation_version: "1.0.0",
    status,
    parameters: { step_count: 2, delay_ms: 0 },
    progress: status === "completed" ? 100 : 35,
    status_message: status === "failed" ? "Demonstration failure" : "Statistics completed",
    result_values: { atom_count: 3 },
    warnings: [],
    error: status === "failed" ? { code: "plugin_execution_failed", message: "Configured failure" } : null,
    provenance: {},
    cancellation_requested: false,
    inputs: [
      {
        id: "input-1",
        ordinal: 0,
        role: "structure",
        entry_id: "ligand",
        entry_name: "Ligand",
        structure_type: "ligand",
        artifact_id: "artifact-input",
        artifact_sha256: "a".repeat(64),
        artifact_size: 100,
        media_type: "application/json",
        filename: "ligand.json",
      },
    ],
    results: status === "completed" ? [
      {
        id: "result-1",
        role: "structure",
        filename: "result.normalized.json",
        media_type: "application/vnd.molweave.normalized-structure+json",
        metadata: {},
        importable_structure: true,
        imported_entry_ids: [],
        created_at: "2026-07-31T10:00:01Z",
        artifact: {
          id: "artifact-result",
          filename: "result.normalized.json",
          media_type: "application/vnd.molweave.normalized-structure+json",
          sha256: "b".repeat(64),
          size: 2048,
          download_url: "/api/v1/artifacts/artifact-result",
        },
      },
    ] : [],
    created_at: "2026-07-31T10:00:00Z",
    started_at: "2026-07-31T10:00:00Z",
    completed_at: status === "running" ? null : "2026-07-31T10:00:01Z",
    modified_at: "2026-07-31T10:00:01Z",
  };
}

function renderWithQuery(element: ReactElement) {
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });
  return render(
    <QueryClientProvider client={client}>
      <Tooltip.Provider>{element}</Tooltip.Provider>
    </QueryClientProvider>,
  );
}


afterEach(()=> {cleanup();vi.restoreAllMocks();vi.unstubAllGlobals();});
it.each(["running","cancelled"] as const)("independent old-project %s cancellation ack fences old refresh without changing replacement cache",async(status)=>{
 vi.stubGlobal("WebSocket",class{onmessage=null;close(){}});
 const user=userEvent.setup(), client=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity}}});
 const a=job("running"), b={...job("completed"),id:"replacement-job",project_id:"project-b"};
 const ack={...job(status),cancellation_requested:true};
 client.setQueryData(["jobs",a.project_id],[a]);client.setQueryData(["jobs",b.project_id],[b]);
 let releaseA!:(value:Job[])=>void;let releaseCancel!:(value:Job)=>void;
 const list=vi.spyOn(jobApi,"list").mockImplementation(id=>id===a.project_id?new Promise(resolve=>{releaseA=resolve;}):new Promise(()=>{}));
 vi.spyOn(jobApi,"events").mockResolvedValue([]);vi.spyOn(jobApi,"cancel").mockImplementation(()=>new Promise(resolve=>{releaseCancel=resolve;}));
 const tree=(id:string)=><QueryClientProvider client={client}><Tooltip.Provider><JobsPanel project={{...molecularProject(),id}} onNewJob={()=>{}} onProjectUpdate={()=>{}} onNotice={()=>{}}/></Tooltip.Provider></QueryClientProvider>;
 const ui=render(tree(a.project_id));
 try{
  await waitFor(()=>expect(list).toHaveBeenCalledTimes(1));await user.click(screen.getByRole("button",{name:/^Cancel$/}));await user.click(screen.getByRole("button",{name:"Cancel job"}));
  ui.rerender(tree(b.project_id));await waitFor(()=>expect(list).toHaveBeenCalledTimes(2));
  await act(async()=>{releaseCancel(ack);await Promise.resolve();});
  await waitFor(()=>expect(client.getQueryData<Job[]>(["jobs",a.project_id])?.[0]).toEqual(ack));
  await act(async()=>{releaseA([a]);await Promise.resolve();});
  expect(client.getQueryData<Job[]>(["jobs",a.project_id])).toEqual([ack]);expect(client.getQueryData<Job[]>(["jobs",b.project_id])).toEqual([b]);
  expect(ui.container.querySelector(".job-detail-header")).toHaveTextContent(b.id);
 }finally{ui.unmount();client.clear();}
});

it("independent held running cancellation acknowledgment cannot replace a newer observed terminal result",async()=>{
 vi.stubGlobal("WebSocket",class{onmessage=null;close(){}});
 const user=userEvent.setup(),client=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity}}});
 const running=job("running"),ack={...running,cancellation_requested:true},terminal={...job("cancelled"),cancellation_requested:true,modified_at:"2026-07-31T10:00:02Z"};
 client.setQueryData(["jobs",running.project_id],[running]);
 let releaseList!:(value:Job[])=>void;let releaseCancel!:(value:Job)=>void;
 const list=vi.spyOn(jobApi,"list").mockImplementation(()=>new Promise(resolve=>{releaseList=resolve;}));
 vi.spyOn(jobApi,"events").mockResolvedValue([]);vi.spyOn(jobApi,"cancel").mockImplementation(()=>new Promise(resolve=>{releaseCancel=resolve;}));
 const ui=render(<QueryClientProvider client={client}><Tooltip.Provider><JobsPanel project={molecularProject()} onNewJob={()=>{}} onProjectUpdate={()=>{}} onNotice={()=>{}}/></Tooltip.Provider></QueryClientProvider>);
 try{
  await waitFor(()=>expect(list).toHaveBeenCalledTimes(1));await user.click(screen.getByRole("button",{name:/^Cancel$/}));await user.click(screen.getByRole("button",{name:"Cancel job"}));
  await act(async()=>{releaseList([terminal]);await Promise.resolve();});
  await waitFor(()=>expect(client.getQueryData<Job[]>(["jobs",running.project_id])?.[0].status).toBe("cancelled"));
  await act(async()=>{releaseCancel(ack);await Promise.resolve();});
  await waitFor(()=>expect(client.getQueryData<Job[]>(["jobs",running.project_id])?.[0].status).toBe("cancelled"));
 }finally{ui.unmount();client.clear();}
});
