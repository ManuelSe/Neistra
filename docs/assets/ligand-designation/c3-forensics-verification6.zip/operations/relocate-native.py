from pathlib import Path
import datetime,hashlib,json,runpy
root=Path.cwd();e=root/'.issue-11-evidence/forensics/c10-extension';h=runpy.run_path(str(root/'docs/assets/ligand-designation/release-evidence.py.txt'));local=json.loads((e/'local-verification.json').read_text());assert local['complete'] and local['all_indexed_assets_verified'] and local['asset_count']==52;raw=json.loads((e/'raw-union-readback.json').read_text());assert raw['all_originals_remain_in_place']
original=root/'docs/assets/ligand-designation/c4-candidate10-native';retained=root/'.issue-11-evidence/issue158-c4-candidate10-native-retained';assert original.is_dir() and not original.is_symlink() and not retained.exists();prefix='interrupted-candidate10/tracked/c4-candidate10-native/';canonical=json.loads((e/'input-inventory.json').read_text())['files'];expected={n.removeprefix(prefix):v for n,v in canonical.items() if n.startswith(prefix)}
def identity(d):
 rows={}
 for f in d.rglob('*'):
  assert not f.is_symlink()
  if f.is_file():rows[f.relative_to(d).as_posix()]=h['fingerprint'](f)
 return rows
before=identity(original);assert before==expected and len(before)==410
original.rename(retained);after=identity(retained);assert before==after and not original.exists()
r=dict(scope='Parent-authorized C10native relocation after complete52part verifier and fresh raw exactunion readback; no deletion',authorization='Explicit bounded task allowed relocation only after complete byte/hash proof with original logical paths retained; no/tmprelocation',logical_original=str(original),physical_retained=str(retained),canonical_member_prefix=prefix,files=len(before),bytes=sum(v['bytes'] for v in before.values()),filewise_sha_manifest_sha256=hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),all_filewise_identities=before,filewise_before_after_equal=True,all_tmp_and_other_raw_originals_preserved=True,payloads_deleted=False,qualification_complete=False,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(e/'native-relocation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='all_filewise_identities'},indent=2))
