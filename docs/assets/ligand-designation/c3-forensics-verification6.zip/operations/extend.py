"""Append C10 interrupted raw evidence without altering earlier forensic snapshots."""
from pathlib import Path
import base64,collections,datetime,gzip,hashlib,io,json,os,runpy,subprocess,zipfile
root=Path.cwd();a=root/'docs/assets/ligand-designation';p=root/'.issue-11-evidence';e=p/'forensics/c10-extension';h=runpy.run_path(str(a/'release-evidence.py.txt'));q=runpy.run_path(str(a/'qualification.py.txt'));sha=lambda b:hashlib.sha256(b).hexdigest()
def new(path,value):
 assert not path.exists(),path
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n')
index_path=a/'c3-forensics-index.json';plan_path=p/'release-v0.36.0/forensic-upload-plan.json';old_bytes=index_path.read_bytes();old_plan_bytes=plan_path.read_bytes();old=json.loads(old_bytes);plan=json.loads(old_plan_bytes)
assert old['asset_count']==50 and len(old['runs'])==6 and sha(old_bytes)=='c5777a87ba18f088ac56f22f75b68862a2f7ed916a0870237c5b2fcf1a6ac063' and plan['index_sha256']==sha(old_bytes)
old_paths=[a/f'c3-forensics-verification{n}.{s}' for n in ('','2','3','4','5') for s in ('json','zip')]+[root/r['inventory']['path'] for r in old['runs']]+[Path(x['local_path']) for x in plan['assets']]
old_ids={f.relative_to(root).as_posix():h['fingerprint'](f) for f in old_paths};backup=e/'previous';backup.mkdir();(backup/'c3-forensics-index.json').write_bytes(old_bytes);(backup/'forensic-upload-plan.json').write_bytes(old_plan_bytes);new(backup/'unchanged-identities.json',old_ids)
tools=['tools/verify_ligand_forensics.py','tests/unit/test_ligand_forensic_verifier.py','docs/assets/ligand-designation/release-evidence.py.txt'];tool_ids={n:h['fingerprint'](root/n) for n in tools};assert tool_ids[tools[0]]['sha256']=='d3fe296aed0038ee7bea58a4aa616157f9048c6fac3c42ee40ae30c3c9b6b9b0' and tool_ids[tools[1]]['sha256']=='a4d2f7aa2d06c51a6e455271a48c5c09e79003440e9f7dab1ce36fb46cf89275'
label='c4-candidate10';gate=json.loads((a/(label+'-gate.json')).read_text());report=json.loads((a/(label+'-browser.json')).read_text());wrapper=json.loads((p/'issue158-c4-candidate10-wrapper.json').read_text());interrupt=p/'issue158-c10-source-race-interruption';request=json.loads((interrupt/'request.json').read_text());actual=json.loads((interrupt/'actual-enclosing.json').read_text());probe=p/'issue158-architecture-held-source-probe1';independent=json.loads((probe/'independent-receipt.json').read_text())
assert gate['commit']=='246efa69f493d14a55fb7d21dc82ff978832c836' and gate['complete'] is False and gate['source_before']==gate['source_after'] and gate['source_unchanged'] and len(gate['source_before'])==1005
assert gate['preceding_source_before']==gate['preceding_source_after']==gate['preceding_source_expected'] and gate['preceding_source_unchanged'] and len(gate['preceding_source_before'])==931
old_root=Path(gate['preceding_reader']['root']);assert q['extracted_identities'](old_root,gate['preceding_source_before'])==gate['preceding_source_before']
assert len(gate['steps'])==16 and all(x['exit_code']==0 for x in gate['steps'][:-1]) and gate['steps'][-1]['label']=='browser' and gate['steps'][-1]['exit_code']==130
for s in gate['steps']:assert sha(gzip.decompress((root/s['log']).read_bytes()))==s['log_sha256']
assert sha((a/(label+'-recipe.json')).read_bytes())==gate['recipe_sha256'] and subprocess.check_output(['git','show',gate['commit']+':docs/assets/ligand-designation/'+label+'-recipe.json'])==(a/(label+'-recipe.json')).read_bytes()
assert wrapper['complete'] is False and len(wrapper['steps'])==1 and wrapper['steps'][0]['exit_code']==130 and wrapper['steps'][0]['log_sha256']==h['fingerprint'](Path(wrapper['steps'][0]['log']))['sha256']
assert actual['actual_enclosing_tool_session']==70976 and actual['observed_exit_code']==130 and actual['outcome']=='INTERRUPTED_SOURCE_CORRECTION_REQUIRED' and actual['no_summary_or_packaging_executed'] and not actual['positively_owned_processes_remaining'] and all(actual['ports_unused_after'].values())
assert request['wrapper_tool_session']==70976 and request['candidate']==gate['commit'] and request['reproducer_observed_exit']==1 and 'SIGINT' in request['signal']
assert h['fingerprint'](probe/'independent-receipt.json')['sha256']=='9ae3f35cd5d818a51d190cddb47db3c476bdf4575ecaadb31eb44e233bb249e0'
assert independent['head']==gate['commit'] and independent['actual_tool_session']==49521 and independent['actual_exit']==1 and independent['verdict']=='CHANGES_REQUIRED' and independent['assertion_failures']==1
assert h['fingerprint'](probe/'repro.log')['sha256']==independent['log_sha256'] and h['fingerprint'](probe/'held-source.test.tsx')['sha256']==independent['repro_test_sha256'] and gate['source_before']['apps/web/src/components/LigandDesignationControls.tsx']==independent['affected_sha256']
# Classify actual results, keeping interruption and absent results separate from declared exclusions.
rows=[];counts=collections.Counter();profiles={}
def visit(suites):
 for suite in suites:
  for spec in suite.get('specs',[]):
   for t in spec.get('tests',[]):
    results=t.get('results',[]);statuses=[r['status'] for r in results];assert all(r['retry']==0 for r in results)
    if statuses==['passed']:kind='passed';assert t['status']=='expected' and t['expectedStatus']=='passed'
    elif statuses==['skipped']:kind='encountered_historical_exclusion';assert t['expectedStatus']=='skipped' and any(x['type']=='skip' for x in t['annotations'])
    elif statuses==['interrupted']:kind='interrupted';assert t['status']=='skipped' and t['expectedStatus']=='passed'
    elif not results:kind='not_run';assert t['status']=='skipped'
    else:raise AssertionError((t['projectName'],spec['title'],statuses))
    counts[kind]+=1;profiles.setdefault(t['projectName'],collections.Counter())[kind]+=1
    rows.append(dict(file=spec['file'],title=spec['title'],project=t['projectName'],classification=kind,reported_status=t['status'],expected_status=t['expectedStatus'],result_statuses=statuses,annotations=t['annotations'],results=results))
  visit(suite.get('suites',[]))
visit(report['suites']);assert dict(counts)==dict(passed=293,encountered_historical_exclusion=9,interrupted=1,not_run=299) and len(rows)==602 and report['stats']['expected']==293 and report['stats']['skipped']==309 and report['stats']['unexpected']==report['stats']['flaky']==0 and not report['errors']
classification=dict(scope='Actual602case native classification, never309historicalskips; retained interrupted assertion context does not change explicitSIGINT outcome into functionalfailure or timeout',stats=report['stats'],counts=dict(counts),profiles={n:dict(v) for n,v in profiles.items()},cases=rows);new(e/'browser-classification.json',classification)
# Immutable historical current sources from Git, and actual extracted old-reader source bytes.
specs=[gate['commit']+':'+n for n in sorted(gate['source_before'])];blob=subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(specs)+'\n').encode());stream=io.BytesIO(blob);historical={}
for n in sorted(gate['source_before']):
 header=stream.readline().decode().strip().split();assert header[1]=='blob';body=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(body)==gate['source_before'][n],n;historical[n]=body
assert not stream.read();preceding={n:(old_root/n).read_bytes() for n in sorted(gate['preceding_source_before'])};assert all(sha(body)==gate['preceding_source_before'][n] for n,body in preceding.items())
allowlist=['apps/web/src/components/LigandDesignationControls.tsx','apps/web/src/ligands/inventoryQualification.ts','apps/web/src/test/ligand-designation-controls.test.tsx']
def audit_live():
 current=q['current_identities'](root);changes=sorted(n for n in set(current)|set(gate['source_before']) if current.get(n)!=gate['source_before'].get(n));assert set(changes)<=set(allowlist),changes
 return dict(scope='Concurrent author workspace identity audit only, not C10historical source or a qualified corrective candidate',source_count=len(current),changed_paths=changes,allowed_paths=allowlist,all_other_historical_sources_unchanged=True)
source_proof=dict(scope='Exact interrupted-C10source bodies:1005Git246efa blobs and931oldreader extracted files; no live correction source snapshots',candidate=gate['commit'],source_count=1005,source_digest=sha(json.dumps(gate['source_before'],sort_keys=True).encode()),source_identities=gate['source_before'],all_historical_blobs_sha256_match=True,preceding_reader=gate['preceding_reader'],preceding_source_count=931,preceding_source_identities=gate['preceding_source_before'],all_preceding_reader_bodies_sha256_match=True,live_workspace_before=audit_live());new(e/'historical-source-provenance.json',source_proof)
items={};retained={};links=[];native=a/(label+'-native')
def collect(directory,prefix):
 assert directory.is_dir() and not directory.is_symlink();count=0
 for f in sorted(directory.rglob('*')):
  n=prefix+'/'+f.relative_to(directory).as_posix()
  if f.is_symlink():links.append(dict(member=n,raw_link_text=os.readlink(f),raw_link_bytes_base64=base64.b64encode(os.fsencode(os.readlink(f))).decode(),lstat_mode=f.lstat().st_mode,followed=False));continue
  if f.is_file():h['add'](items,n,f,reader_workspace=True);count+=1
 return count
retained['native']=collect(native,'interrupted-candidate10/tracked/'+native.name)
for f in sorted(a.glob(label+'-*')):
 if f.is_file():h['add'](items,'interrupted-candidate10/tracked/'+f.name,f)
for f in sorted(p.glob('issue158-c4-candidate10-*')):
 if f.is_file():h['add'](items,'interrupted-candidate10/private/'+f.name,f)
retained['neistra158-c4-candidate10']=collect(Path('/tmp/neistra158-c4-candidate10'),'retained-workspaces/neistra158-c4-candidate10')
retained[interrupt.name]=collect(interrupt,'interruption/'+interrupt.name);retained[probe.name]=collect(probe,'independent-failing-probe/'+probe.name)
for n,b in historical.items():h['add'](items,'historical-C10-source/'+n,b)
for n,b in preceding.items():h['add'](items,'preceding-reader-source/'+n,b)
# Capture installed query implementation with its license as a packaging-time reference.
# The independent execution receipt did not hash installed bodies: do not invent that binding.
react=(root/'apps/web/node_modules/@tanstack/react-query').resolve();core=(react.parent/'query-core').resolve();libraries={}
for label_,directory,names in [('query-core',core,['src/query.ts','src/queryClient.ts','src/queryObserver.ts','package.json','LICENSE']),('react-query',react,['src/useBaseQuery.ts','src/useQuery.ts','package.json','LICENSE'])]:
 assert directory.is_relative_to(root/'node_modules')
 for n in names:
  f=directory/n;assert f.is_file() and not f.is_symlink();body=f.read_bytes();member='installed-query-reference/'+label_+'/'+n;h['add'](items,member,body);libraries[member]=dict(path=str(f),**h['fingerprint'](body))
lib_proof=dict(scope='Installed implementation and exact licenses observed at packaging, not retrospectively claimed as execution-time body hashes; independent actualQueryClient reproduction is retained separately',files=libraries,historical_lock_sha256=gate['source_before']['pnpm-lock.yaml'],current_lock_identical=sha((root/'pnpm-lock.yaml').read_bytes())==gate['source_before']['pnpm-lock.yaml']);assert lib_proof['current_lock_identical'];new(e/'captured-library-licenses.json',lib_proof)
for n in ['historical-source-provenance.json','browser-classification.json','captured-library-licenses.json']:h['add'](items,n,e/n)
h['add'](items,'owned-links.json',h['encoded'](dict(scope='Exact link metadata only; no active archive links or following',links=links)))
canonical={n:h['fingerprint'](b) for n,b in sorted(items.items())};new(e/'input-inventory.json',dict(scope='Entire interrupted C10native/store/raw logs/recipe/cleanup/independent failingprobe plus all1005+931historicalsource bodies; not a qualification',files=canonical,retained=retained,link_metadata_count=len(links)))
parts=[];current={};used=0;budget=76*1024*1024
for num,(n,b) in enumerate(sorted(items.items()),1):
 estimate=h['compressed_size'](b);assert estimate<budget,n
 if current and used+estimate>budget:parts.append(current);current={};used=0
 current[n]=b;used+=estimate
 if num%1000==0:print('SIZED',num,flush=True)
if current:parts.append(current)
print('PARTITION_PLAN',len(parts),'FILES',len(canonical),'RAW',sum(v['bytes'] for v in canonical.values()),flush=True)
union={};records=[];new_upload=[];packets=[]
for num,part in enumerate(parts,1):
 target=p/'forensics'/('c3-candidate10-native-interrupted-part%02d.zip'%num);packet=h['archive'](part,target);assert packet['bytes']<old['part_max_bytes_exclusive']
 with zipfile.ZipFile(target) as z:rows_=json.loads(z.read('manifest.json'));assert not union.keys()&rows_.keys();union.update(rows_)
 records.append(dict(ordinal=num,asset_name=target.name,bytes=packet['bytes'],sha256=packet['sha256'],manifest_entries=len(rows_),recursive_verification=packet['verification_counts'],repository_path=None));new_upload.append(dict(run=label,asset_name=target.name,local_path=str(target),bytes=packet['bytes'],sha256=packet['sha256']));packets.append(packet);print('PACKED',num,len(rows_),packet['bytes'],flush=True)
assert union==canonical and {n:h['fingerprint'](b) for n,b in sorted(items.items())}==canonical
new(e/'parts.json',dict(archives=packets,files=len(canonical),raw_bytes=sum(v['bytes'] for v in canonical.values()),retained=retained,all_originals_retained_in_place=True))
body=json.dumps(dict(format_version=1,run=label,scope='Interrupted C10 exact canonical inventory; not functionaltestfailure, timeout or passingqualification',files=canonical),sort_keys=True,separators=(',',':')).encode();inventory=a/('c3-forensics-inventory-'+label+'.json.gz');assert not inventory.exists();inventory.write_bytes(gzip.compress(body,mtime=0))
run=dict(label=label,failed_candidate=gate['commit'],qualification_complete=False,failed_step='browser',termination=dict(kind='interrupted',exit_code=130,signal='root-requested SIGINT',reason='Independently reproduced consequential source-failure race; correction required',actual_root_tool_session=70976),source_count=1005,source_digest=source_proof['source_digest'],source_unchanged=True,preceding_source_count=931,preceding_source_unchanged=True,recipe=dict(path=(a/(label+'-recipe.json')).relative_to(root).as_posix(),sha256=gate['recipe_sha256']),lossless_logs=[dict(label=s['label'],path=s['log'],uncompressed_sha256=s['log_sha256']) for s in gate['steps']],browser_outcomes=dict(counts),files=len(canonical),raw_bytes=sum(v['bytes'] for v in canonical.values()),extraction_root='forensics/'+label,inventory=dict(path=inventory.relative_to(root).as_posix(),**h['fingerprint'](inventory),uncompressed_sha256=sha(body)),parts=records,local_exact_union_and_recursive_verification=True)
index=json.loads(old_bytes);index['runs'].append(run);index['asset_count']+=len(records);index['total_asset_bytes']+=sum(x['bytes'] for x in records);assert index['runs'][:len(old['runs'])]==old['runs'];index_bytes=(json.dumps(index,indent=2)+'\n').encode();newplan=json.loads(old_plan_bytes);newplan['assets'].extend(new_upload);newplan['index_sha256']=sha(index_bytes);assert newplan['assets'][:old['asset_count']]==plan['assets']
for n,v in old_ids.items():assert h['fingerprint'](root/n)==v,n
assert index_path.read_bytes()==old_bytes and plan_path.read_bytes()==old_plan_bytes and {n:h['fingerprint'](root/n) for n in tools}==tool_ids
assert q['extracted_identities'](old_root,gate['preceding_source_before'])==gate['preceding_source_before']
new(e/'publication-transaction.json',dict(scope='Atomic per-file extension of local index/uploadplan after full raw union proof; no public publication',old_index_sha256=sha(old_bytes),new_index_sha256=sha(index_bytes),old_plan_sha256=sha(old_plan_bytes),old_asset_count=old['asset_count'],new_assets=len(records),new_asset_count=index['asset_count'],old_records_preserved=True,source_identities=tool_ids,live_workspace_after=audit_live(),originals_relocated=False,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
for path,b in [(index_path,index_bytes),(plan_path,(json.dumps(newplan,indent=2)+'\n').encode())]:
 temp=path.with_suffix('.json.c10-extension-part');assert not temp.exists();temp.write_bytes(b);temp.replace(path)
print('ALL_EXTENDED',len(records),index['asset_count'],len(canonical),run['raw_bytes'],index['total_asset_bytes'],flush=True)
