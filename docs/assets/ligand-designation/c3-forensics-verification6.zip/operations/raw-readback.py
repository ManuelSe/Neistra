from pathlib import Path
import datetime,hashlib,json,runpy
root=Path.cwd();e=root/'.issue-11-evidence/forensics/c10-extension';a=root/'docs/assets/ligand-designation';h=runpy.run_path(str(a/'release-evidence.py.txt'));q=runpy.run_path(str(a/'qualification.py.txt'));canonical=json.loads((e/'input-inventory.json').read_text())['files'];proof=json.loads((e/'historical-source-provenance.json').read_text());gate=json.loads((a/'c4-candidate10-gate.json').read_text())
roots={
'interrupted-candidate10/tracked/c4-candidate10-native':a/'c4-candidate10-native',
'retained-workspaces/neistra158-c4-candidate10':Path('/tmp/neistra158-c4-candidate10'),
'interruption/issue158-c10-source-race-interruption':root/'.issue-11-evidence/issue158-c10-source-race-interruption',
'independent-failing-probe/issue158-architecture-held-source-probe1':root/'.issue-11-evidence/issue158-architecture-held-source-probe1'}
compared={}
for prefix,d in roots.items():
 rows={}
 for f in d.rglob('*'):
  assert not f.is_symlink(),f
  if f.is_file():rows[prefix+'/'+f.relative_to(d).as_posix()]=h['fingerprint'](f)
 assert rows=={n:v for n,v in canonical.items() if n.startswith(prefix+'/')};compared[str(d)]=dict(files=len(rows),bytes=sum(v['bytes'] for v in rows.values()),exact_union=True)
for n,v in canonical.items():
 f=None
 if n.startswith('interrupted-candidate10/tracked/') and not n.startswith('interrupted-candidate10/tracked/c4-candidate10-native/'):f=a/n.removeprefix('interrupted-candidate10/tracked/')
 elif n.startswith('interrupted-candidate10/private/'):f=root/'.issue-11-evidence'/n.removeprefix('interrupted-candidate10/private/')
 elif n.startswith('preceding-reader-source/'):f=Path(gate['preceding_reader']['root'])/n.removeprefix('preceding-reader-source/')
 if f is not None:assert h['fingerprint'](f)==v,n
for n,v in json.loads((e/'captured-library-licenses.json').read_text())['files'].items():assert h['fingerprint'](Path(v['path']))=={k:v[k] for k in ['bytes','sha256']}==canonical[n]
old=json.loads((e/'previous/unchanged-identities.json').read_text())
for n,v in old.items():assert h['fingerprint'](root/n)==v,n
live=q['current_identities'](root);delta=sorted(n for n in set(live)|set(proof['source_identities']) if live.get(n)!=proof['source_identities'].get(n));assert set(delta)<=set(proof['live_workspace_before']['allowed_paths'])
assert q['extracted_identities'](Path(gate['preceding_reader']['root']),gate['preceding_source_before'])==gate['preceding_source_before']
r=dict(scope='Fresh exact interrupted raw/original retention readback after partition proof; not a native or full qualification rerun',canonical_files=len(canonical),canonical_raw_bytes=sum(v['bytes'] for v in canonical.values()),owned_roots=compared,all931old_source_originals_equal=True,all1005historical_git_blobs_bound_to_gate=True,old50parts_six_run_records_inventories_verification1through5_unchanged=True,all_originals_remain_in_place=True,live_corrective_source_delta=delta,allowed_corrective_source_paths=proof['live_workspace_before']['allowed_paths'],all_other_live_sources_unchanged=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(e/'raw-union-readback.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
