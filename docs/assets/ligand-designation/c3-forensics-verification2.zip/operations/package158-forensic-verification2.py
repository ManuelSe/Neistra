"""Record appended C6 forensic retention without rewriting prior verification."""
from pathlib import Path
import datetime
import json
import runpy

root=Path.cwd();assets=root/'docs/assets/ligand-designation';private=root/'.issue-11-evidence'
extension=private/'forensics/c6-extension'
helper=runpy.run_path(str(assets/'release-evidence.py.txt'))
def new(path,value):
    assert not path.exists(),path
    path.write_text(json.dumps(value,indent=2)+'\n')
previous=json.loads((extension/'previous/c3-forensics-index.json').read_text())
index=json.loads((assets/'c3-forensics-index.json').read_text())
old_identities=json.loads((extension/'previous/unchanged-identities.json').read_text())
assert index['runs'][:2]==previous['runs'] and len(index['runs'])==3
for name,identity in old_identities.items():assert helper['fingerprint'](root/name)==identity,name
local_path=extension/'local-verification.json';local=json.loads(local_path.read_text())
assert local['complete'] and local['all_indexed_assets_verified'] and local['asset_count']==index['asset_count']
assert len(local['runs'])==3 and all(r['exact_manifest_union'] for r in local['runs'])
source_paths=['tools/verify_ligand_forensics.py','tests/unit/test_ligand_forensic_verifier.py']
source_ids={name:helper['fingerprint'](root/name) for name in source_paths}
transaction=json.loads((extension/'publication-transaction.json').read_text())
assert all(transaction['source_identities'][name]==source_ids[name] for name in source_paths)
original_verification=json.loads((assets/'c3-forensics-verification.json').read_text())
assert original_verification['offline_controls']==64 and original_verification['offline_control_network_requests']==0
items={}
for name in source_paths:helper['add'](items,'source/'+name,root/name)
for name in ['c3-forensics-index.json','c3-forensics-inventory-c4-candidate6.json.gz']:
    helper['add'](items,'indexed-contract/'+name,assets/name)
for name in ['c3-forensics-index.json','unchanged-identities.json']:
    helper['add'](items,'previous-contract/'+name,extension/'previous'/name)
for name in ['input-inventory.json','parts.json','publication-transaction.json','native-relocation.json','local-verification.json','local-verification.log','actual-enclosing.json']:
    helper['add'](items,'operations/'+name,extension/name)
for name in ['extend158-forensics-candidate6.py','extend158-forensics-candidate6.log','package158-forensic-verification2.py']:
    helper['add'](items,'operations/'+name,private/name)
for p in sorted((private/'issue158-candidate6-failure').iterdir()):
    assert p.is_file() and not p.is_symlink(),p
    helper['add'](items,'diagnosis/'+p.name,p)
# Keep small original lossless logs, recipes and historical source maps in the
# primary packet. Full failed native/store/probe payloads stay supplemental only.
for p in sorted(assets.glob('c4-candidate6-*')):
    if p.is_file():helper['add'](items,'historical-provenance/'+p.relative_to(root).as_posix(),p)
for name in ['actual-enclosing.json','receipt.json','raw.log','browser.json']:
    helper['add'](items,'recovery-probe/'+name,private/'issue158-interaction-network-probe1'/name)
helper['add'](items,'recovery-probe/runner.py',private/'issue158-interaction-network-run.py')
reference=dict(scope='Byte-identical source/control evidence reused; no repeated or invented control run',historical_verification_json=dict(path='docs/assets/ligand-designation/c3-forensics-verification.json',**helper['fingerprint'](assets/'c3-forensics-verification.json')),historical_verification_zip=dict(path='docs/assets/ligand-designation/c3-forensics-verification.zip',**helper['fingerprint'](assets/'c3-forensics-verification.zip')),offline_controls=64,real_network_requests=0,source_identities=source_ids,all_sources_unchanged=True)
helper['add'](items,'unchanged-source-controls.json',helper['encoded'](reference))
archive=helper['archive'](items,assets/'c3-forensics-verification2.zip')
for name,identity in old_identities.items():assert helper['fingerprint'](root/name)==identity,name
assert {name:helper['fingerprint'](root/name) for name in source_paths}==source_ids
run=index['runs'][-1]
record=dict(scope='Third failed-run forensic retention extension and full local readback; not application qualification or public availability',archive=archive['file'],files=len(items),archive_bytes=archive['bytes'],archive_sha256=archive['sha256'],recursive_verification=archive['verification_counts'],index_sha256=helper['fingerprint'](assets/'c3-forensics-index.json')['sha256'],previous_index_sha256=helper['fingerprint'](extension/'previous/c3-forensics-index.json')['sha256'],previous_two_runs_unchanged=True,previous18parts_and_inventories_unchanged=True,previous_verification_json_and_zip_unchanged=True,local_all_parts_verified=index['asset_count'],local_new_parts_verified=len(run['parts']),new_run=dict(label=run['label'],failed_candidate=run['failed_candidate'],qualification_complete=False,files=run['files'],raw_bytes=run['raw_bytes'],source_count=run['source_count'],source_digest=run['source_digest']),total_asset_bytes=index['total_asset_bytes'],total_canonical_files=sum(r['files'] for r in index['runs']),total_raw_bytes=sum(r['raw_bytes'] for r in index['runs']),all_parts_below80MiB=True,exact_disjoint_unions_and_recursive_crcs=True,source_control_reference=reference,
    observed_failure='Dependent dynamic-module requests failed with ERR_NETWORK_CHANGED; the expected instrumentation response was fulfilled. Underlying host cause remains unknown.',
    independent_diagnosis='Scoped read-only performance verdict PASS: no consequential application correction established; does not qualify the failed gate.',
    unchanged_probe='Eight actual native cases pass both profiles with zero failures, skips, retries or flakes and unchanged1005sources. This is a scoped diagnostic probe, not pooled full-gate evidence.',
    retention='All owned stores/raw originals retained; C6 native tree relocated only after exact archive union verification and complete before/after file hashes; no deletion.',
    required_next=['Independent review of extended forensic contract and integrated final candidate','Fresh complete C7 all42, independent summary, recursive packaging and actual enclosing readback; no pooled passing segments','Normal final review/PR/merge and complete exact-master gate','Publish all indexed supplemental assets only with verified release and run full anonymous tracked-verifier readback before child closeout'],observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
new(assets/'c3-forensics-verification2.json',record)
print(json.dumps(record,indent=2),flush=True)
