const {QueryClient,isCancelledError}=require('../../node_modules/.pnpm/@tanstack+query-core@5.87.1/node_modules/@tanstack/query-core/build/modern/index.cjs');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const defer=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return{promise,resolve,reject}};
const key=(page=0,project='p',entry='e',artifact='a',original='o')=>['ligand-candidates','ligand-instance-v3',project,entry,artifact,original,'ligand-exact-representation-v2','ligand-occurrence-v1','designation',page,12];
const source=k=>k[0]==='ligand-candidates'&&k[1]==='ligand-instance-v3'&&k[6]==='ligand-exact-representation-v2'&&k[7]==='ligand-occurrence-v1'?JSON.stringify(k.slice(2,6)):null;
const body=(k,value)=>({project_id:k[2],entry_id:k[3],artifact_id:k[4],resolver_version:'ligand-instance-v3',value});
(async()=>{
 const client=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity}}}),facts=new Map(),starts=new WeakMap(),events=[],signals=new Map();
 const release=client.getQueryCache().subscribe(event=>{
  if(event.type!=='updated')return;const q=event.query,s=source(q.queryKey);if(!s)return;
  if(event.action.type==='fetch'){starts.set(q,facts.get(s)?.generation??0);events.push({kind:'fetch',key:q.queryKey,generation:starts.get(q)});}
  if(event.action.type==='error'&&!isCancelledError(event.action.error)){
   const generation=(facts.get(s)?.generation??0)+1;facts.set(s,{generation,blocked:true});events.push({kind:'failure',source:s,generation});
   void client.cancelQueries({predicate:other=>source(other.queryKey)===s&&other.state.fetchStatus!=='idle'});
  }
  if(event.action.type==='success'&&!event.action.manual&&facts.get(s)?.blocked){const fact=facts.get(s);const accepted=starts.get(q)===fact.generation;events.push({kind:'success',start:starts.get(q),generation:fact.generation,accepted});if(accepted)fact.blocked=false;}
 });
 const run=(k,request)=>{const pending=client.fetchQuery({queryKey:k,staleTime:0,queryFn:({signal})=>{signals.set(JSON.stringify(k),signal);events.push({kind:'function',key:k});return request.promise;}});pending.catch(()=>{});return pending;};
 const old=defer(),failure=defer();client.setQueryData(key(),body(key(),'baseline'));
 const older=run(key(),old);const failing=run(key(12),failure);
 const independent=[key(0,'other-project'),key(0,'p','other-entry'),key(0,'p','e','other-artifact'),key(0,'p','e','a','other-original')].map(k=>({k,request:defer()}));
 const unrelated=independent.map(item=>run(item.k,item.request));
 failure.reject(new Error('New exact-source integrity failure'));await failing.catch(()=>{});
 assert.equal(facts.get(source(key())).blocked,true);assert.equal(signals.get(JSON.stringify(key())).aborted,true);
 independent.forEach(item=>assert.equal(signals.get(JSON.stringify(item.k)).aborted,false));
 const beforeLate=events.filter(e=>e.kind==='success').length;
 client.setQueryData(key(),body(key(),'manual after failure'));assert.equal(facts.get(source(key())).blocked,true);
 old.resolve(body(key(),'late old response'));await older.catch(()=>{});await Promise.resolve();
 assert.equal(events.filter(e=>e.kind==='success').length,beforeLate);assert.equal(facts.get(source(key())).blocked,true);
 const retry=defer(),secondFailure=defer();const retryWork=run(key(),retry),second=run(key(12),secondFailure);
 assert.equal(starts.get(client.getQueryCache().find({queryKey:key()})),1);
 secondFailure.reject(new Error('Another failure while Retry is pending'));await second.catch(()=>{});
 assert.equal(facts.get(source(key())).generation,2);assert.equal(signals.get(JSON.stringify(key())).aborted,true);
 retry.resolve(body(key(),'retired Retry'));await retryWork.catch(()=>{});assert.equal(facts.get(source(key())).blocked,true);
 // Exercise the generation guard independently of cancellation with the installed
 // public nonmanual cache publication API and its recorded earlier fetch start.
 client.getQueryCache().find({queryKey:key()}).setData(body(key(),'earlier-start cache publication'));
 assert.equal(facts.get(source(key())).blocked,true);assert.equal(events.at(-1).accepted,false);
 const fresh=defer(),freshWork=run(key(),fresh);fresh.resolve(body(key(),'fresh post-failure check'));await freshWork;
 assert.equal(facts.get(source(key())).blocked,false);assert.equal(client.getQueryData(key()).value,'fresh post-failure check');
 for(const item of independent)item.request.resolve(body(item.k,'unrelated completed'));await Promise.all(unrelated);
 const fetchEvents=events.filter(e=>e.kind==='fetch');for(const event of fetchEvents){const functionIndex=events.findIndex((e,i)=>i>events.indexOf(event)&&e.kind==='function'&&JSON.stringify(e.key)===JSON.stringify(event.key));assert.ok(functionIndex>events.indexOf(event));}
 const receipt={library:'@tanstack/query-core5.87.1',checks:['fetch action precedes actual query function','synchronous exact-source cancellation aborts held signal','ignored-signal late result cannot publish after cancellation','manual success does not recover','repeated failure retires pending Retry','earlier-start nonmanual publication cannot recover','actual fresh post-failure fetch recovers','other project/entry/current/original queries remain live'],events,passed:true};
 fs.writeFileSync(path.join(__dirname,'query-control-receipt.json'),JSON.stringify(receipt,null,2)+'\n');release();client.clear();console.log(JSON.stringify({passed:true,checks:receipt.checks.length,eventCount:events.length}));
})().catch(error=>{console.error(error);process.exitCode=1});
