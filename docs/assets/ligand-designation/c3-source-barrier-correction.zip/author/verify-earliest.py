from pathlib import Path
import datetime,json,hashlib,subprocess,zipfile,difflib,sys
root=Path.cwd();out=root/'.issue-11-evidence/issue158-inventory-source-barrier-author'
owned=['apps/web/src/components/LigandDesignationControls.tsx','apps/web/src/ligands/inventoryQualification.ts','apps/web/src/test/ligand-designation-controls.test.tsx']
def hashes(paths):return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=hashes(owned);webpaths=[str(p.relative_to(root)) for p in sorted((root/'apps/web/src').rglob('*')) if p.is_file()];webbefore=hashes(webpaths)
(out/'earliest-source-before.json').write_text(json.dumps({'owned':before,'all_web':webbefore},indent=2)+'\n')
with zipfile.ZipFile(out/'earliest-source.zip','w',compression=zipfile.ZIP_DEFLATED) as a:
 for p in owned:a.write(root/p,p)
old=json.loads((out/'before.json').read_text());diff=''
with zipfile.ZipFile(out/'source-before.zip') as a:
 original=a.read(owned[2]);assert (root/owned[2]).read_bytes().startswith(original),'Original75 tests changed'
 for p in owned:
  text=a.read(p).decode().splitlines(keepends=True) if p in old else []
  diff+=''.join(difflib.unified_diff(text,(root/p).read_text().splitlines(keepends=True),fromfile='before/'+p if p in old else '/dev/null',tofile='after/'+p))
(out/'earliest.diff').write_text(diff)
commands=[('lint',['corepack','pnpm','--filter','@neistra/web','exec','eslint','src/components/LigandDesignationControls.tsx','src/ligands/inventoryQualification.ts','src/test/ligand-designation-controls.test.tsx','--max-warnings','0']),('types',['npm','--prefix','apps/web','run','typecheck']),('focused',['corepack','pnpm','--filter','@neistra/web','exec','vitest','run','src/test/ligand-designation-controls.test.tsx'])]
checks=[]
for label,command in commands:
 print('START',label,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True);log=out/f'earliest-{label}.log'
 with log.open('w') as stream:result=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 checks.append({'label':label,'command':command,'exit_code':result.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});print('END',label,'exit',result.returncode,flush=True)
 if result.returncode:break
after=hashes(owned);webafter=hashes(webpaths);receipt={'scope':'Earliest158 author correction frozen before propagation; no complete gate/native/review claim.','owned_before':before,'owned_after':after,'owned_stable':before==after,'all_web_count':len(webbefore),'all_web_stable':webbefore==webafter,'original75_test_bytes_preserved':True,'checks':checks,'passed':len(checks)==len(commands) and all(c['exit_code']==0 for c in checks),'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(out/'earliest-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');assert before==after and webbefore==webafter;sys.exit(0 if receipt['passed'] else 1)
