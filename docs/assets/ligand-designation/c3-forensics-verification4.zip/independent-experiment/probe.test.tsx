import { QueryClient, QueryClientProvider } from "../../apps/web/node_modules/@tanstack/react-query";
import * as Tooltip from "../../apps/web/node_modules/@radix-ui/react-tooltip";
import { act, cleanup, render, waitFor } from "../../apps/web/node_modules/@testing-library/react";
import { afterEach, expect, it, vi } from "../../apps/web/node_modules/vitest";
import { writeFileSync } from "node:fs";
import { JobsPanel } from "../../apps/web/src/components/JobsPanel";
import { jobApi } from "../../apps/web/src/api/client";
import { molecularProject } from "../../apps/web/src/test/molecular-fixtures";
import wire from "./wire-fixture.json";
const sockets: Socket[] = [];
class Socket { onmessage: (() => void) | null = null; closed=false; constructor(..._args: unknown[]) { sockets.push(this); } close() { this.closed=true; } }
const results: unknown[] = [];
afterEach(() => { cleanup(); vi.restoreAllMocks(); vi.unstubAllGlobals(); sockets.length=0; });
for (const coalesce of [false,true]) it(`actual JobsPanel progress publication with coalescing=${coalesce}`,async()=> {
  vi.stubGlobal("WebSocket",Socket);
  const client=new QueryClient({defaultOptions:{queries:{retry:false},mutations:{retry:false}}});
  client.setQueryData(["jobs",wire.projectId],wire.initial);
  if(coalesce) { const original=client.invalidateQueries.bind(client);vi.spyOn(client,"invalidateQueries").mockImplementation((filters,options)=>original(filters,{...options,cancelRefetch:false})); }
  const pending: {resolve:(value: typeof wire.running)=>void}[]=[];
  vi.spyOn(jobApi,"list").mockImplementation(()=>new Promise(resolve=>pending.push({resolve})) as never);
  vi.spyOn(jobApi,"events").mockResolvedValue([]);
  const ui=render(<QueryClientProvider client={client}><Tooltip.Provider><JobsPanel project={{...molecularProject(),id:wire.projectId}} onNewJob={()=>{}} onProjectUpdate={()=>{}} onNotice={()=>{}} /></Tooltip.Provider></QueryClientProvider>);
  await waitFor(()=>expect(pending).toHaveLength(1));
  const observations=[];
  for(let n=0;n<4;n++) {
    const held=pending.at(-1)!; const count=pending.length;
    await act(async()=> { sockets.findLast(s=>!s.closed)!.onmessage!(); await Promise.resolve(); });
    if(!coalesce) await waitFor(()=>expect(pending.length).toBe(count+1));
    await act(async()=> {held.resolve(wire.running);await Promise.resolve();await Promise.resolve();});
    const data=client.getQueryData<typeof wire.running>(["jobs",wire.projectId]);
    observations.push({event:n+1,requests:pending.length,targetStatus:data?.find(j=>j.id===wire.target)?.status??null,runningDOM:ui.container.querySelectorAll(".job-status.running").length});
    if(coalesce) {await waitFor(()=>expect(ui.container.querySelectorAll(".job-status.running").length).toBeGreaterThan(0));observations.at(-1)!.runningDOM=ui.container.querySelectorAll(".job-status.running").length;break;}
    expect(data?.some(j=>j.id===wire.target)).toBe(false);
    expect(ui.container.querySelectorAll(".job-status.running")).toHaveLength(0);
  }
  await act(async()=> {pending.at(-1)!.resolve(wire.completed);await Promise.resolve();});
  if(!coalesce) await waitFor(()=>expect(client.getQueryData<typeof wire.completed>(["jobs",wire.projectId])?.find(j=>j.id===wire.target)?.status).toBe("completed"));
  results.push({coalesce,observations});
  writeFileSync("/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/.issue-11-evidence/issue158-jobs-invalidation-architecture1/results.json",JSON.stringify({scope:"Independent actual JobsPanel + installed QueryClient + real C8 wire DTOs. Controlled event/deferred-response ordering, not a native C8 causality proof.",results},null,2));
  client.clear();
});
