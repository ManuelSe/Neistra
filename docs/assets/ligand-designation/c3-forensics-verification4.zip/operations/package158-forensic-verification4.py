"""Record appended C8 forensic retention without rewriting prior verification."""
from pathlib import Path
import datetime
import json
import runpy

root=Path.cwd();assets=root/'docs/assets/ligand-designation';private=root/'.issue-11-evidence'
extension=private/'forensics/c8-extension'
helper=runpy.run_path(str(assets/'release-evidence.py.txt'))
def new(path,value):
    assert not path.exists(),path
    path.write_text(json.dumps(value,indent=2)+'\n')
previous=json.loads((extension/'previous/c3-forensics-index.json').read_text())
index=json.loads((assets/'c3-forensics-index.json').read_text())
old_identities=json.loads((extension/'previous/unchanged-identities.json').read_text())
assert index['runs'][:4]==previous['runs'] and len(index['runs'])==5
for name,identity in old_identities.items():assert helper['fingerprint'](root/name)==identity,name
local_path=extension/'local-verification.json';local=json.loads(local_path.read_text())
assert local['complete'] and local['all_indexed_assets_verified'] and local['asset_count']==index['asset_count']
assert len(local['runs'])==5 and all(r['exact_manifest_union'] for r in local['runs'])
source_paths=['tools/verify_ligand_forensics.py','tests/unit/test_ligand_forensic_verifier.py']
source_ids={name:helper['fingerprint'](root/name) for name in source_paths}
transaction=json.loads((extension/'publication-transaction.json').read_text())
assert all(transaction['source_identities'][name]==source_ids[name] for name in source_paths)
original_verification=json.loads((assets/'c3-forensics-verification.json').read_text())
assert original_verification['offline_controls']==64 and original_verification['offline_control_network_requests']==0
items={}
for name in source_paths:helper['add'](items,'source/'+name,root/name)
for name in ['c3-forensics-index.json','c3-forensics-inventory-c4-candidate8.json.gz']:
    helper['add'](items,'indexed-contract/'+name,assets/name)
for name in ['c3-forensics-index.json','unchanged-identities.json']:
    helper['add'](items,'previous-contract/'+name,extension/'previous'/name)
for name in ['input-inventory.json','parts.json','publication-transaction.json','native-relocation.json','local-verification.json','local-verification.log','actual-enclosing.json','historical-source-provenance.json','failed-gate-readback.json']:
    helper['add'](items,'operations/'+name,extension/name)
for name in ['extend158-forensics-candidate8.py','extend158-forensics-candidate8.log','complete158-c8-library-license.py','complete158-c8-library-license.log','package158-forensic-verification4.py']:
    helper['add'](items,'operations/'+name,private/name)
snapshot=json.loads((extension/'input-inventory.json').read_text())['files']
prefix='focused/issue158-candidate8-failure/'
for name in sorted(n.removeprefix(prefix) for n in snapshot if n.startswith(prefix)):
    p=private/'issue158-candidate8-failure'/name
    assert helper['fingerprint'](p)==snapshot[prefix+name]
    helper['add'](items,'diagnosis/'+name,p)
# Keep small original lossless logs, recipes and historical source maps in the
# primary packet. Full failed native/store/probe payloads stay supplemental only.
for p in sorted(assets.glob('c4-candidate8-*')):
    if p.is_file():helper['add'](items,'historical-provenance/'+p.relative_to(root).as_posix(),p)
# Keep exactly the closed independent experiment snapshot, including retained
# setup/source/output-path attempts. Correction probes are separate root work.
prefix='focused/issue158-jobs-invalidation-architecture1/'
for name in sorted(n.removeprefix(prefix) for n in snapshot if n.startswith(prefix)):
    p=private/'issue158-jobs-invalidation-architecture1'/name
    assert helper['fingerprint'](p)==snapshot[prefix+name]
    helper['add'](items,'independent-experiment/'+name,p)
import zipfile
plan=json.loads((private/'release-v0.36.0/forensic-upload-plan.json').read_text())
source_members=[n for n in snapshot if n.startswith(('historical-C8-source/','installed-query-library-source/'))]
found={}
for part in plan['assets']:
    if part['run']!='c4-candidate8':continue
    with zipfile.ZipFile(part['local_path']) as z:
        for name in source_members:
            if name in z.namelist():
                assert name not in found;found[name]=z.read(name)
assert set(found)==set(source_members) and len(found)==5
for name,body in found.items():
    assert helper['fingerprint'](body)==snapshot[name]
    helper['add'](items,name,body)
reference=dict(scope='Byte-identical source/control evidence reused; no repeated or invented control run',historical_verification_json=dict(path='docs/assets/ligand-designation/c3-forensics-verification.json',**helper['fingerprint'](assets/'c3-forensics-verification.json')),historical_verification_zip=dict(path='docs/assets/ligand-designation/c3-forensics-verification.zip',**helper['fingerprint'](assets/'c3-forensics-verification.zip')),previous_extension_json=dict(path='docs/assets/ligand-designation/c3-forensics-verification2.json',**helper['fingerprint'](assets/'c3-forensics-verification2.json')),previous_extension_zip=dict(path='docs/assets/ligand-designation/c3-forensics-verification2.zip',**helper['fingerprint'](assets/'c3-forensics-verification2.zip')),previous_third_run_extension_json=dict(path='docs/assets/ligand-designation/c3-forensics-verification3.json',**helper['fingerprint'](assets/'c3-forensics-verification3.json')),previous_third_run_extension_zip=dict(path='docs/assets/ligand-designation/c3-forensics-verification3.zip',**helper['fingerprint'](assets/'c3-forensics-verification3.zip')),offline_controls=64,real_network_requests=0,source_identities=source_ids,all_sources_unchanged=True)
helper['add'](items,'license-correction-receipt.json',extension/'license-correction/correction-receipt.json')
helper['add'](items,'unchanged-source-controls.json',helper['encoded'](reference))
archive=helper['archive'](items,assets/'c3-forensics-verification4.zip')
for name,identity in old_identities.items():assert helper['fingerprint'](root/name)==identity,name
assert {name:helper['fingerprint'](root/name) for name in source_paths}==source_ids
run=index['runs'][-1]
record=dict(scope='Fifth failed-run forensic retention extension and full local readback; not application qualification or public availability',archive=archive['file'],files=len(items),archive_bytes=archive['bytes'],archive_sha256=archive['sha256'],recursive_verification=archive['verification_counts'],index_sha256=helper['fingerprint'](assets/'c3-forensics-index.json')['sha256'],previous_index_sha256=helper['fingerprint'](extension/'previous/c3-forensics-index.json')['sha256'],previous_four_runs_unchanged=True,previous43parts_and_inventories_unchanged=True,previous_verification1through3_json_and_zips_unchanged=True,local_all_parts_verified=index['asset_count'],local_new_parts_verified=len(run['parts']),new_run=dict(label=run['label'],failed_candidate=run['failed_candidate'],qualification_complete=False,files=run['files'],raw_bytes=run['raw_bytes'],source_count=run['source_count'],source_digest=run['source_digest']),total_asset_bytes=index['total_asset_bytes'],total_canonical_files=sum(r['files'] for r in index['runs']),total_raw_bytes=sum(r['raw_bytes'] for r in index['runs']),all_parts_below80MiB=True,installed_query_source_license_included=True,unpublished_first_draft_and_first_local_readback_retained_privately=True,exact_disjoint_unions_and_recursive_crcs=True,source_control_reference=reference,
    failed_gate_readback=json.loads((extension/'failed-gate-readback.json').read_text()),observed_failure='The C8 HTTP trace records queued, running and completed job states, while the expected running DOM state was not observed by the failing native case. The exact job transition audit is retained; exclusive causality is not established.',
    independent_diagnosis='An independent experiment with the actual installed query client, actual historical jobs component and exact C8 HTTP DTOs demonstrates a reachable invalidation/publication starvation defect. Event/refetch coalescing preserves publication in the controlled experiment. This establishes a logical P2 issue, not an exclusive explanation for the C8 failure.',
    focused_proof='Independent closed experiment: actual72486exit0, two cases, exact source and proof-file hashes retained. Earlier private setup/output-path corrections remain distinct evidence. Root permanent regression and production corrections and their new probes are excluded and require separate evidence.',
    retention='All owned stores/raw originals retained; C8 native tree relocated only after exact archive union verification and complete before/after file hashes; no deletion.',
    required_next=['Independent review of extended forensic contract and integrated final candidate','Fresh complete C9 all42, independent summary, recursive packaging and actual enclosing readback; no pooled passing segments','Normal final review/PR/merge and complete exact-master gate','Publish all indexed supplemental assets only with verified release and run full anonymous tracked-verifier readback before child closeout'],observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
new(assets/'c3-forensics-verification4.json',record)
print(json.dumps(record,indent=2),flush=True)
