"""Complete the unpublished C8 source snapshot with its exact package license."""
from pathlib import Path
import gzip
import json
import runpy
import zipfile

root=Path.cwd();a=root/'docs/assets/ligand-designation';p=root/'.issue-11-evidence'
e=p/'forensics/c8-extension';backup=e/'license-correction/first-draft';assert not backup.exists();backup.mkdir(parents=True)
h=runpy.run_path(str(a/'release-evidence.py.txt'))
index_path=a/'c3-forensics-index.json';plan_path=p/'release-v0.36.0/forensic-upload-plan.json'
index=json.loads(index_path.read_text());plan=json.loads(plan_path.read_text())
assert index['asset_count']==44 and len(index['runs'])==5
assert h['fingerprint'](index_path)['sha256']==plan['index_sha256']
part=index['runs'][-1]['parts'][0];assert len(index['runs'][-1]['parts'])==1
part_path=Path(plan['assets'][-1]['local_path'])
assert part_path.name==part['asset_name'] and h['fingerprint'](part_path)=={k:part[k] for k in ['bytes','sha256']}
with zipfile.ZipFile(part_path) as z:
    manifest=json.loads(z.read('manifest.json'))
    items={n:z.read(n) for n in manifest}
assert all(h['fingerprint'](items[n])==v for n,v in manifest.items())
license_name='node_modules/.pnpm/@tanstack+query-core@5.87.1/node_modules/@tanstack/query-core/LICENSE'
license_body=(root/license_name).read_bytes();assert b'MIT License' in license_body and b'Permission is hereby granted' in license_body
(backup.parent/'LICENSE').write_bytes(license_body)
saved=[index_path,plan_path,part_path,a/'c3-forensics-inventory-c4-candidate8.json.gz',a/'c3-forensics-verification4.json',a/'c3-forensics-verification4.zip',e/'input-inventory.json',e/'parts.json',e/'historical-source-provenance.json',e/'local-verification.json',e/'local-verification.log',e/'actual-enclosing.json']
identities={str(x):h['fingerprint'](x) for x in saved}
for x in saved:
    target=backup/x.name;assert not target.exists()
    if x in [a/'c3-forensics-verification4.json',a/'c3-forensics-verification4.zip',e/'local-verification.json',e/'local-verification.log',e/'actual-enclosing.json']:
        x.rename(target)
    else:target.write_bytes(x.read_bytes())
(backup/'identities.json').write_text(json.dumps(identities,indent=2)+'\n')
items['installed-query-library-source/LICENSE']=license_body
provenance=json.loads((backup/'historical-source-provenance.json').read_text())
provenance[license_name]=dict(member='installed-query-library-source/LICENSE',**h['fingerprint'](license_body),scope='Unmodified installed package copyright and license notice retained alongside copied library source')
provenance_bytes=(json.dumps(provenance,indent=2)+'\n').encode()
(e/'historical-source-provenance.json').write_bytes(provenance_bytes)
items['historical-source-provenance.json']=provenance_bytes
canonical={n:h['fingerprint'](b) for n,b in sorted(items.items())}
completed_path=part_path.with_name(part_path.stem+'-license-completed.zip');assert not completed_path.exists()
packet=h['archive'](items,completed_path);assert packet['bytes']<80*1024*1024
completed_path.replace(part_path);packet.update(file=part_path.name,path=str(part_path))
with zipfile.ZipFile(part_path) as z:assert json.loads(z.read('manifest.json'))==canonical
inventory_path=a/'c3-forensics-inventory-c4-candidate8.json.gz'
body=json.dumps(dict(format_version=1,run='c4-candidate8',scope='Closed failed C8 and independent experiment snapshot, including exact installed-library license; qualification remains false',files=canonical),sort_keys=True,separators=(',',':')).encode()
inventory_path.write_bytes(gzip.compress(body,mtime=0))
old_part_bytes=part['bytes']
part.update(bytes=packet['bytes'],sha256=packet['sha256'],manifest_entries=len(canonical),recursive_verification=packet['verification_counts'])
run=index['runs'][-1]
run.update(files=len(canonical),raw_bytes=sum(v['bytes'] for v in canonical.values()),inventory=dict(path=inventory_path.relative_to(root).as_posix(),**h['fingerprint'](inventory_path),uncompressed_sha256=h['sha'](body)))
index['total_asset_bytes']+=packet['bytes']-old_part_bytes
previous=json.loads((e/'previous/c3-forensics-index.json').read_text());assert index['runs'][:4]==previous['runs']
old_plan=json.loads((e/'previous/forensic-upload-plan.json').read_text());assert plan['assets'][:43]==old_plan['assets']
index_bytes=(json.dumps(index,indent=2)+'\n').encode()
plan['assets'][-1].update(bytes=packet['bytes'],sha256=packet['sha256']);plan['index_sha256']=h['sha'](index_bytes)
for path,body in [(index_path,index_bytes),(plan_path,(json.dumps(plan,indent=2)+'\n').encode())]:
    temp=path.with_suffix('.json.license-part');assert not temp.exists();temp.write_bytes(body);temp.replace(path)
original_input=json.loads((backup/'input-inventory.json').read_text());original_input['files']=canonical
(e/'input-inventory.json').write_text(json.dumps(original_input,indent=2)+'\n')
old_parts=json.loads((backup/'parts.json').read_text());old_parts.update(archives=[packet],files=len(canonical),raw_bytes=run['raw_bytes'])
(e/'parts.json').write_text(json.dumps(old_parts,indent=2)+'\n')
record=dict(scope='Necessary license completion for an unpublished forensic source-copy draft; not application or scientific modification',license=dict(original_installed_path=license_name,member='installed-query-library-source/LICENSE',**h['fingerprint'](license_body)),prior43asset_records_and4run_records_unchanged=True,first_draft_preserved=str(backup.relative_to(root)),only_payload_changes=['Added unmodified installed package LICENSE','Linked the license identity in historical-source-provenance.json'],new_part=packet,new_index_sha256=h['sha'](index_bytes),source_count=1005,preceding_source_count=931,no_application_changes=True)
(backup.parent/'correction-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(files=run['files'],raw_bytes=run['raw_bytes'],part_bytes=packet['bytes'],part_sha256=packet['sha256'],asset_count=index['asset_count'],total_asset_bytes=index['total_asset_bytes'],index_sha256=h['sha'](index_bytes)),indent=2),flush=True)
