"""Append closed failed candidate8 without changing earlier forensic snapshots."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import runpy
import zipfile

root=Path.cwd();assets=root/'docs/assets/ligand-designation';private=root/'.issue-11-evidence'
extension=private/'forensics/c8-extension';assert not extension.exists();extension.mkdir()
helper=runpy.run_path(str(assets/'release-evidence.py.txt'))
sha=lambda data:hashlib.sha256(data).hexdigest()
def new(path,value):
    assert not path.exists(),path
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n')
def collect(items,directory,prefix):
    assert directory.is_dir() and not directory.is_symlink(),directory
    count=0
    # Explicit failed-run retention keeps incomplete browser traces. The normal
    # completed-gate scanner is unchanged and retains its strict policy.
    for p in sorted(directory.rglob('*')):
        assert not p.is_symlink(),p
        if p.is_file():
            helper['add'](items,prefix+'/'+p.relative_to(directory).as_posix(),p,reader_workspace=True)
            count+=1
    return count
index_path=assets/'c3-forensics-index.json';plan_path=private/'release-v0.36.0/forensic-upload-plan.json'
old_index_bytes=index_path.read_bytes();old_plan_bytes=plan_path.read_bytes()
old_index=json.loads(old_index_bytes);old_plan=json.loads(old_plan_bytes)
assert old_index['asset_count']==43 and [r['label'] for r in old_index['runs']]==['c4-candidate4','c4-candidate5','c4-candidate6','c4-candidate7']
assert old_plan['index_sha256']==sha(old_index_bytes)
old_paths=[assets/'c3-forensics-verification.json',assets/'c3-forensics-verification.zip',assets/'c3-forensics-verification2.json',assets/'c3-forensics-verification2.zip',assets/'c3-forensics-verification3.json',assets/'c3-forensics-verification3.zip']
old_paths.extend(root/r['inventory']['path'] for r in old_index['runs'])
old_paths.extend(Path(p['local_path']) for p in old_plan['assets'])
old_identities={p.relative_to(root).as_posix():helper['fingerprint'](p) for p in old_paths}
backup=extension/'previous';backup.mkdir()
(backup/'c3-forensics-index.json').write_bytes(old_index_bytes)
(backup/'forensic-upload-plan.json').write_bytes(old_plan_bytes)
new(backup/'unchanged-identities.json',old_identities)
source_paths=['tools/verify_ligand_forensics.py','tests/unit/test_ligand_forensic_verifier.py','docs/assets/ligand-designation/release-evidence.py.txt']
source_before={p:helper['fingerprint'](root/p) for p in source_paths}
assert source_before[source_paths[0]]['sha256']=='d3fe296aed0038ee7bea58a4aa616157f9048c6fac3c42ee40ae30c3c9b6b9b0'
assert source_before[source_paths[1]]['sha256']=='a4d2f7aa2d06c51a6e455271a48c5c09e79003440e9f7dab1ce36fb46cf89275'
label='c4-candidate8';gate=json.loads((assets/(label+'-gate.json')).read_text())
assert gate['commit']=='0beff59082133ae8c3d717471a8c2dcbb328f026'
assert gate['complete'] is False and gate['source_before']==gate['source_after'] and gate['source_unchanged']
assert len(gate['source_before'])==1005 and len(gate['preceding_source_before'])==931
assert gate['preceding_source_expected']==gate['preceding_source_before']==gate['preceding_source_after'] and gate['preceding_source_unchanged']
assert len(gate['steps'])==16 and gate['steps'][-1]['label']=='browser' and gate['steps'][-1]['exit_code']==1
assert all(s['exit_code']==0 for s in gate['steps'][:-1])
proof_dir=private/'issue158-jobs-invalidation-architecture1'
proof_path=proof_dir/'receipt.json';proof=json.loads(proof_path.read_text())
assert sha(proof_path.read_bytes())=='00b17b7c59e5cff8c38942dd9e62acf8921f72289aebfe0b2db98fb959deb2ac'
assert proof['candidate']==gate['commit'] and proof['actual_exit']==0 and proof['actual_tool_session']==72486 and proof['tests']==2
assert proof['source_matches_C8'] and proof['repository_application_changes'] is False
for name,digest in proof['proof_files'].items():assert sha((proof_dir/name).read_bytes())==digest,name
import subprocess
historical_sources={};historical_provenance={}
for name,digest in proof['source_files'].items():
    if name.startswith('node_modules/'):
        p=root/name;assert p.is_file() and not p.is_symlink()
        body=p.read_bytes()
        member='installed-query-library-source/'+p.name
        assert member not in historical_sources
        historical_sources[member]=body
        historical_provenance[name]=dict(sha256=sha(body),member=member,scope='Installed library source used by the independent actual-component proof')
    else:
        assert gate['source_before'][name]==digest
        body=subprocess.check_output(['git','show',gate['commit']+':'+name])
        member='historical-C8-source/'+name
        historical_sources[member]=body
        historical_provenance[name]=dict(sha256=sha(body),member=member,commit=gate['commit'])
        if name=='apps/web/src/components/JobsPanel.tsx':
            preceding=subprocess.check_output(['git','show','b038e4e6cdb30cf4a296ca4dcd218a7ab5ced881:'+name])
            assert sha(preceding)==digest
            historical_provenance[name]['same_as_preceding_delivery_master']=True
    assert sha(body)==digest,name
new(extension/'historical-source-provenance.json',historical_provenance)
items={};retained={};native=assets/(label+'-native')
retained['native']=collect(items,native,'failed-candidate8/tracked/'+native.name)
for p in sorted(assets.glob(label+'-*')):
    if p.is_file():helper['add'](items,'failed-candidate8/tracked/'+p.name,p)
for p in sorted(private.glob('issue158-c4-candidate8-*')):
    if p.is_file():helper['add'](items,'failed-candidate8/private/'+p.name,p)
for name in ['issue158-candidate8-failure','issue158-jobs-invalidation-architecture1']:
    retained[name]=collect(items,private/name,'focused/'+name)
for name,body in historical_sources.items():helper['add'](items,name,body)
helper['add'](items,'historical-source-provenance.json',extension/'historical-source-provenance.json')
for name in ['neistra158-c4-candidate8']:
    retained[name]=collect(items,Path('/tmp')/name,'retained-workspaces/'+name)
canonical={name:helper['fingerprint'](p) for name,p in sorted(items.items())}
new(extension/'input-inventory.json',dict(scope='Closed failed C8 and closed independent jobs-invalidation experiment snapshot; neither substitutes for complete fresh gate',files=canonical,retained=retained))
parts=[];current={};used=0;budget=76*1024*1024
for number,(name,p) in enumerate(sorted(items.items()),1):
    estimate=helper['compressed_size'](p);assert estimate<budget,name
    if current and used+estimate>budget:parts.append(current);current={};used=0
    current[name]=p;used+=estimate
    if number%5000==0:print('SIZED',number,flush=True)
if current:parts.append(current)
packets=[];rows_union={};records=[];new_uploads=[]
for number,part in enumerate(parts,1):
    path=private/'forensics'/('c3-candidate8-native-failure-part%02d.zip'%number)
    packet=helper['archive'](part,path);assert packet['bytes']<old_index['part_max_bytes_exclusive']
    with zipfile.ZipFile(path) as z:
        rows=json.loads(z.read('manifest.json'));assert not rows_union.keys()&rows.keys();rows_union.update(rows)
    records.append(dict(ordinal=number,asset_name=path.name,bytes=packet['bytes'],sha256=packet['sha256'],manifest_entries=len(rows),recursive_verification=packet['verification_counts'],repository_path=None))
    new_uploads.append(dict(run=label,asset_name=path.name,local_path=str(path),bytes=packet['bytes'],sha256=packet['sha256']))
    packets.append(packet);print('PACKED',number,len(rows),packet['bytes'],flush=True)
assert rows_union==canonical
assert {name:helper['fingerprint'](p) for name,p in sorted(items.items())}==canonical
new(extension/'parts.json',dict(archives=packets,files=len(canonical),raw_bytes=sum(v['bytes'] for v in canonical.values()),retained=retained))
body=json.dumps(dict(format_version=1,run=label,scope='Closed failed C8 and closed independent jobs-invalidation experiment inventory; complete gate remains failed',files=canonical),sort_keys=True,separators=(',',':')).encode()
inventory=assets/('c3-forensics-inventory-'+label+'.json.gz');assert not inventory.exists();inventory.write_bytes(gzip.compress(body,mtime=0))
run=dict(label=label,failed_candidate=gate['commit'],qualification_complete=False,failed_step='browser',source_count=len(gate['source_before']),source_digest=sha(json.dumps(gate['source_before'],sort_keys=True).encode()),source_unchanged=True,preceding_source_count=931,preceding_source_unchanged=True,
    recipe=dict(path=(assets/(label+'-recipe.json')).relative_to(root).as_posix(),sha256=gate['recipe_sha256']),lossless_logs=[dict(label=s['label'],path=s['log'],uncompressed_sha256=s['log_sha256']) for s in gate['steps']],files=len(canonical),raw_bytes=sum(v['bytes'] for v in canonical.values()),extraction_root='forensics/'+label,inventory=dict(path=inventory.relative_to(root).as_posix(),**helper['fingerprint'](inventory),uncompressed_sha256=sha(body)),parts=records,local_exact_union_and_recursive_verification=True)
index=json.loads(old_index_bytes);index['runs'].append(run);index['asset_count']+=len(records);index['total_asset_bytes']+=sum(p['bytes'] for p in records)
assert index['runs'][:4]==old_index['runs']
index_bytes=(json.dumps(index,indent=2)+'\n').encode()
plan=json.loads(old_plan_bytes);plan['assets'].extend(new_uploads);plan['index_sha256']=sha(index_bytes)
assert plan['assets'][:43]==old_plan['assets']
for name,identity in old_identities.items():assert helper['fingerprint'](root/name)==identity,name
assert index_path.read_bytes()==old_index_bytes and plan_path.read_bytes()==old_plan_bytes
assert {p:helper['fingerprint'](root/p) for p in source_paths}==source_before
new(extension/'publication-transaction.json',dict(scope='Atomic per-file index/plan extension after verified parts; prior exact bytes retained',old_index_sha256=sha(old_index_bytes),new_index_sha256=sha(index_bytes),old_plan_sha256=sha(old_plan_bytes),new_assets=len(records),old_records_preserved=True,source_identities=source_before,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
index_temp=index_path.with_suffix('.json.c8-extension-part');plan_temp=plan_path.with_suffix('.json.c8-extension-part')
assert not index_temp.exists() and not plan_temp.exists()
with index_temp.open('xb') as out:out.write(index_bytes)
with plan_temp.open('xb') as out:out.write((json.dumps(plan,indent=2)+'\n').encode())
index_temp.replace(index_path);plan_temp.replace(plan_path)
# Only relocate the native tree after archive union and source bytes are proven.
native_before={p.relative_to(native).as_posix():helper['fingerprint'](p) for p in sorted(native.rglob('*')) if p.is_file()}
destination=private/'issue158-c4-candidate8-native-retained';assert not destination.exists();native.rename(destination)
native_after={p.relative_to(destination).as_posix():helper['fingerprint'](p) for p in sorted(destination.rglob('*')) if p.is_file()}
assert native_before==native_after
new(extension/'native-relocation.json',dict(scope='Hash-verified native relocation after complete failed-run part verification; no deletion',original=str(native),retained=str(destination),files=len(native_before),bytes=sum(v['bytes'] for v in native_before.values()),manifest_sha256=sha(json.dumps(native_before,sort_keys=True).encode()),all_original_and_retained_hashes_verified=True,payloads_deleted=False,qualification_complete=False))
print('ALL_EXTENDED',len(records),index['asset_count'],len(canonical),run['raw_bytes'],index['total_asset_bytes'],flush=True)
