from __future__ import annotations

import hashlib
import importlib.util
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd().resolve()
folder = root / '.issue-11-evidence/issue158-source-producer-science'
author = root / '.issue-11-evidence/issue158-source-producer'
freeze_path, map_path = author / 'frozen-pre-gate.json', author / 'frozen-source-map.json'
assert hashlib.sha256(freeze_path.read_bytes()).hexdigest() == '97a61039b7c617e1045824fc2f7e18ee3358b701ba31f0c735a5a91936da61e1'
freeze = json.loads(freeze_path.read_text())
assert hashlib.sha256(map_path.read_bytes()).hexdigest() == '2dd5c6ab34b13b01de47dde3cdde56b805dbe6a7ade8252833e9c05f87b2318f'
expected = json.loads(map_path.read_text()); assert len(expected) == 1013
spec = importlib.util.spec_from_file_location('independent_release_selected_source_guard', author / 'source_guard.py')
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
private_files = [folder/'independent_read_matrix.py',folder/'independent_write_matrix.py',folder/'independent-source-write.test.tsx',folder/'vitest.config.mts',author/'source_guard.py']
pins = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in private_files}
def guard():
    assert all(hashlib.sha256((root/name).read_bytes()).hexdigest() == d for name,d in pins.items())
    observed = module.audit(root, expected, {})
    assert observed['source_digest'] == freeze['source_digest']
    return {'count': observed['source_count'], 'digest': observed['source_digest'], 'added_selected_detection': True}

kind = sys.argv[1]
if kind == 'backend1':
    command = [str(root/'.venv/bin/python'),'-m','pytest','-q',str(folder/'independent_read_matrix.py'),str(folder/'independent_write_matrix.py'),'--basetemp=/tmp/neistra158-source-science-backend1']
elif kind == 'app1':
    command = ['corepack','pnpm','--filter','@neistra/web','exec','vitest','run','--config',str(folder/'vitest.config.mts')]
else:
    raise AssertionError(kind)
before = guard(); start = time.time()
with (folder/f'{kind}.log').open('w') as output:
    completed = subprocess.run(command,cwd=root,stdout=output,stderr=subprocess.STDOUT,check=False)
after = guard()
receipt = {'scope':'Independent scientific source qualification controls; not whole-feature delivery gate','stage':kind,'command':command,'exit':completed.returncode,'seconds':time.time()-start,'before':before,'after':after,'private_pins':pins,'log_sha256':hashlib.sha256((folder/f'{kind}.log').read_bytes()).hexdigest(),'freeze_sha256':hashlib.sha256(freeze_path.read_bytes()).hexdigest(),'no_source_edits':True,'spawned_services':0,'browser_runs':0}
(folder/f'{kind}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
sys.exit(completed.returncode)
