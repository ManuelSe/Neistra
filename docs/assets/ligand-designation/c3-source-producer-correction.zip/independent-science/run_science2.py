from __future__ import annotations

import hashlib
import importlib.util
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd().resolve()
folder = root / '.issue-11-evidence/issue158-source-producer-science'
author = root / '.issue-11-evidence/issue158-source-producer'
freeze_path, map_path = author / 'freeze2-pre-gate.json', author / 'freeze2-source-map.json'
assert hashlib.sha256(freeze_path.read_bytes()).hexdigest() == 'dcc124a14dd8dd3b70fbf5be29e8cc7cece8b9dd534614529127bc9aa84166c9'
freeze = json.loads(freeze_path.read_text())
assert hashlib.sha256(map_path.read_bytes()).hexdigest() == '2395af0eec031c23cac125250f18dc20562deb805c05a64c5444f36f46d8f55d'
expected = json.loads(map_path.read_text()); assert len(expected) == 1013
spec = importlib.util.spec_from_file_location('independent_release_selected_source_guard', author / 'source_guard.py')
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
private_files = [folder/'independent_read_matrix.py',folder/'independent_write_matrix.py',folder/'independent-source-write.test.tsx',folder/'vitest.config.mts',author/'source_guard.py']
pins = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in private_files}
def guard():
    assert all(hashlib.sha256((root/name).read_bytes()).hexdigest() == d for name,d in pins.items())
    observed = module.audit(root, expected, {})
    assert observed['source_digest'] == freeze['source_digest']
    return {'count': observed['source_count'], 'digest': observed['source_digest'], 'added_selected_detection': True}

kind = sys.argv[1]
if kind == 'backend2':
    command = [str(root/'.venv/bin/python'),'-m','pytest','-q',str(folder/'independent_read_matrix.py'),str(folder/'independent_write_matrix.py'),'--basetemp=/tmp/neistra158-source-science-backend2']
elif kind == 'app2':
    command = ['corepack','pnpm','--filter','@neistra/web','exec','vitest','run','--config',str(folder/'vitest.config.mts')]
else:
    raise AssertionError(kind)
before = guard(); start = time.time()
with (folder/f'{kind}.log').open('w') as output:
    completed = subprocess.run(command,cwd=root,stdout=output,stderr=subprocess.STDOUT,check=False)
after = guard()
receipt = {'scope':'Independent scientific source qualification controls; not whole-feature delivery gate','stage':kind,'command':command,'exit':completed.returncode,'seconds':time.time()-start,'before':before,'after':after,'private_pins':pins,'log_sha256':hashlib.sha256((folder/f'{kind}.log').read_bytes()).hexdigest(),'freeze_sha256':hashlib.sha256(freeze_path.read_bytes()).hexdigest(),'no_source_edits':True,'spawned_services':0,'browser_runs':0}
(folder/f'{kind}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
sys.exit(completed.returncode)
