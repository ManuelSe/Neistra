import userEvent from "@testing-library/user-event";
import { ViewerMeasurements } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/components/ViewerMeasurements";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { act, cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { StrictMode, type ComponentProps } from "react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import App from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/App";
import { ApiError, projectApi, workspacePresentationApi } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/api/client";
import type { CoordinateTransform, Project } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/api/types";
import type * as LigandControlsModule from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/components/LigandDesignationControls";
import type { LigandDesignationControls } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/components/LigandDesignationControls";
import type { ProjectInspector } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/components/ProjectInspector";
import type { WorkspaceCanvas } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/components/WorkspaceCanvas";
import { ligandApi } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/ligands/api";
import type { LigandCandidatesRead } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/ligands/types";
import { useMinimizationStore } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/minimization/store";
import { useEditingStore } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/store/editing";
import { useNavigationStore } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/store/navigation";
import { useSelectionStore } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/store/selection";
import { useWorkspaceStore } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/store/workspace";
import { structureQueryKey } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/structures/query";
import { molecularEntry, molecularProject, proteinProjection } from "/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/test/molecular-fixtures";

type Controls = ComponentProps<typeof LigandDesignationControls>;
const seen = vi.hoisted(() => ({ renderMeasurements: false, controls: null as Controls | null,
  inspector: null as ComponentProps<typeof ProjectInspector> | null,
  workspace: null as ComponentProps<typeof WorkspaceCanvas> | null }));
vi.mock("/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/components/LigandDesignationControls", async importOriginal => {
  const actual = await importOriginal<typeof LigandControlsModule>();
  return { LigandDesignationControls: (props: Controls) => {
    seen.controls = props; return <actual.LigandDesignationControls {...props} />;
  } };
});
vi.mock("/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/components/ProjectInspector", () => ({ ProjectInspector: (props: ComponentProps<typeof ProjectInspector>) => {
  seen.inspector = props; return props.ligandControls;
} }));
vi.mock("/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/components/WorkspaceCanvas", () => ({ WorkspaceCanvas: (props: ComponentProps<typeof WorkspaceCanvas>) => {
  seen.workspace = props;
  const session = props.measurementSession;
  return seen.renderMeasurements && session && props.project ? <ViewerMeasurements session={session} project={props.project}
    sceneAvailable={false} busy={false} inspection={{ projectId: props.project.id, viewer: undefined, sources: [],
      selection: props.selection, order: null, structures: new Map(), entries: props.project.entries, paused: false, onOrder: () => undefined }}
    onUpdate={() => Promise.resolve()} onDelete={() => Promise.resolve()} onSelect={() => undefined}
    onReturnFocus={() => undefined} /> : null;
} }));
vi.mock("/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/components/LowerPanel", () => ({ LowerPanel: () => null }));
const clients: QueryClient[] = [];
beforeEach(() => {
  localStorage.clear(); vi.restoreAllMocks(); seen.renderMeasurements = false; seen.controls = null; seen.inspector = null; seen.workspace = null;
  useSelectionStore.getState().setProject(null); useEditingStore.getState().setProject(null);
  useMinimizationStore.getState().setProject(null); useNavigationStore.getState().setProject(null);
  vi.spyOn(workspacePresentationApi, "read").mockResolvedValue({ schema_version: 1, revision: 0, camera: null, updated_at: null });
});
afterEach(() => { cleanup(); clients.splice(0).forEach(client => client.clear()); vi.restoreAllMocks(); });
function deferred<T>() {
  let resolve!: (value: T) => void, reject!: (error: Error) => void;
  const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
function inventory(project: Project): LigandCandidatesRead {
  const entry = project.entries[0];
  return { project_id: project.id, entry_id: entry.id, artifact_id: entry.current_artifact_id,
    designation: entry.ligand_designation, input_hash: "inventory", resolver_version: "ligand-instance-v3",
    total: 1, offset: 0, limit: 12, designated_candidate: null, warnings: [], selectable_candidate_keys: ["candidate"],
    candidates: [{ candidate_key: "candidate", atom_ids: [1, 2], residue_ids: [1], component_ids: ["LIG"],
      label: "Exact instance", locations: [], boundary_status: "qualified", potential_ligand: true,
      reason_codes: [], provenance: [], heavy_atom_count: 2, formal_charge: 0, formula: "C2H6",
      molecular_weight: 30, chemistry_status: "qualified", chemistry_reason: null, chemical_input_hash: "chemistry",
      occurrence_count: null, occurrence_basis: null, occurrence_reason: "occurrence_count_not_qualified" }] };
}
async function setup(legacy = false, strict = false) {
  const entry = molecularEntry("protein", "Entry", "protein");
  if (!legacy) entry.ligand_designation = { ...entry.ligand_designation, status: "selection_required" };
  const project = molecularProject([entry]); project.has_uncheckpointed_changes = false;
  const other = { ...molecularProject([]), id: "other", name: "Other" };
  const query = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: Infinity }, mutations: { retry: false } } });
  clients.push(query); query.setQueryData(["project", project.id], project); query.setQueryData(["project", other.id], other);
  query.setQueryData(structureQueryKey(project.id, entry.id, entry.current_artifact_id), proteinProjection());
  vi.spyOn(globalThis, "fetch").mockImplementation(input => {
    const path = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    return Promise.resolve(Response.json(path.endsWith(`/projects/${project.id}`) ? project
      : path.endsWith(`/projects/${other.id}`) ? other
        : path === "/api/v1/projects" ? [project, other].map(value => ({ ...value, entry_count: value.entries.length })) : []));
  });
  vi.spyOn(ligandApi, "candidates").mockResolvedValue(inventory(project));
  vi.spyOn(ligandApi, "depiction").mockResolvedValue({ entry_id: entry.id, artifact_id: entry.current_artifact_id,
    candidate_key: "candidate", status: "unavailable", reason: "not_qualified", input_hash: null,
    cache_key: null, artifact: null, implementation: "ligand-2d-v1", library_version: "pinned",
    formula: null, molecular_weight: null, formal_charge: null, provenance: null });
  useWorkspaceStore.setState({ activeProjectId: project.id, mobilePanel: null });
  const content = <QueryClientProvider client={query}><App /></QueryClientProvider>;
  render(strict ? <StrictMode>{content}</StrictMode> : content);
  await waitFor(() => expect(useSelectionStore.getState().projectId).toBe(project.id));
  act(() => useNavigationStore.getState().inspect(project.id, entry.id));
  if (!window.matchMedia("(max-width: 840px)").matches) {
    await waitFor(() => expect(seen.controls?.entryId).toBe(entry.id));
  }
  return { entry, project, other, query };
}
function leaveAndReturn(other: Project, project: Project) {
  useWorkspaceStore.getState().setActiveProjectId(other.id);
  useWorkspaceStore.getState().setActiveProjectId(project.id);
}

it.each(["artifact_integrity_error","artifact_not_found"])("withholds cached source facts after actual App Use rejects with %s", async code => {
 const f=await setup();
 vi.mocked(ligandApi.depiction).mockResolvedValue({entry_id:f.entry.id,artifact_id:f.entry.current_artifact_id,candidate_key:"candidate",status:"ready",reason:null,input_hash:"chemistry",cache_key:"drawing-key",artifact:{id:"drawing",filename:"ligand.svg",media_type:"image/svg+xml",sha256:"digest",size:100,download_url:"/artifact/drawing.svg"},implementation:"ligand-2d-v1",library_version:"pinned",formula:"C2H6",molecular_weight:30,formal_charge:0,provenance:"source"});
 const command=vi.spyOn(ligandApi,"designate").mockRejectedValue(new ApiError(code==="artifact_not_found"?404:409,code,"Controlled molecular input verification failure"));
 await userEvent.click(screen.getByRole("button",{name:"Choose"}));const dialog=screen.getByRole("dialog");
 expect(await within(dialog).findByText("C2H6",{exact:true})).toBeVisible();expect(await within(dialog).findByRole("img",{name:/2D depiction/})).toBeVisible();
 await userEvent.click(within(dialog).getByRole("radio"));await userEvent.click(within(dialog).getByRole("button",{name:"Use ligand"}));
 await waitFor(()=>expect(command).toHaveBeenCalledTimes(1));
 console.log(JSON.stringify({code,formulaRetained:!!within(dialog).queryByText("C2H6",{exact:true}),drawingRetained:!!within(dialog).queryByRole("img",{name:/2D depiction/}),useEnabled:!within(dialog).getByRole<HTMLButtonElement>("button",{name:"Use ligand"}).disabled,candidateReads:vi.mocked(ligandApi.candidates).mock.calls.length,designationCalls:command.mock.calls.length}));
 expect(within(dialog).queryByText("C2H6",{exact:true})).toBeNull();expect(within(dialog).queryByRole("img",{name:/2D depiction/})).toBeNull();expect(within(dialog).getByRole("button",{name:"Use ligand"})).toBeDisabled();
});

it.each([
  [409, "structure_artifact_conflict", "The ligand candidate inventory changed"],
  [503, "request_failed", "Controlled temporary transport failure"],
] as const)("preserves qualified composition for semantic/transport Use rejection %s/%s", async (status, code, message) => {
  const f = await setup();
  vi.mocked(ligandApi.depiction).mockResolvedValue({ entry_id: f.entry.id, artifact_id: f.entry.current_artifact_id,
    candidate_key: "candidate", status: "ready", reason: null, input_hash: "chemistry", cache_key: "drawing-key",
    artifact: { id: "drawing", filename: "ligand.svg", media_type: "image/svg+xml", sha256: "digest", size: 100, download_url: "/artifact/drawing.svg" },
    implementation: "ligand-2d-v1", library_version: "pinned", formula: "C2H6", molecular_weight: 30, formal_charge: 0, provenance: "source" });
  vi.spyOn(ligandApi, "designate").mockRejectedValue(new ApiError(status, code, message));
  await userEvent.click(screen.getByRole("button", { name: "Choose" }));
  const dialog = screen.getByRole("dialog");
  expect(await within(dialog).findByText("C2H6", { exact: true })).toBeVisible();
  expect(await within(dialog).findByRole("img", { name: /2D depiction/ })).toBeVisible();
  await userEvent.click(within(dialog).getByRole("radio"));
  await userEvent.click(within(dialog).getByRole("button", { name: "Use ligand" }));
  expect(await within(dialog).findByText(message, { exact: true })).toBeVisible();
  expect(within(dialog).getByText("C2H6", { exact: true })).toBeVisible();
  expect(within(dialog).getByRole("img", { name: /2D depiction/ })).toBeVisible();
  expect(within(dialog).getByRole("button", { name: "Use ligand" })).toBeEnabled();
  expect(ligandApi.candidates).toHaveBeenCalledTimes(1);
});

it("records a held source failure after closing the chooser and leaving its project", async () => {
  const f = await setup(), failure = deferred<Project>();
  vi.spyOn(ligandApi, "designate").mockReturnValue(failure.promise);
  await userEvent.click(screen.getByRole("button", { name: "Choose" }));
  const dialog = screen.getByRole("dialog");
  expect(await within(dialog).findByText("C2H6", { exact: true })).toBeVisible();
  await userEvent.click(within(dialog).getByRole("radio"));
  await userEvent.click(within(dialog).getByRole("button", { name: "Use ligand" }));
  await waitFor(() => expect(ligandApi.designate).toHaveBeenCalledTimes(1));
  await userEvent.click(within(dialog).getByRole("button", { name: "Close ligand choices" }));
  act(() => useWorkspaceStore.getState().setActiveProjectId(f.other.id));
  const { getLigandInventoryOwner, inventorySourceKey } = await import("/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification/apps/web/src/ligands/inventoryQualification");
  const owner = getLigandInventoryOwner(f.query), sourceKey = inventorySourceKey(f.project, f.entry);
  expect(owner.qualification(sourceKey).blocked).toBe(false);
  await act(async () => { failure.reject(new ApiError(409, "artifact_integrity_error", "Controlled late original input failure"));
    await failure.promise.catch(() => undefined); });
  await waitFor(() => expect(owner.qualification(sourceKey).blocked).toBe(true));
  expect(useWorkspaceStore.getState().activeProjectId).toBe(f.other.id);
  expect(screen.queryByRole("dialog")).toBeNull();
});
