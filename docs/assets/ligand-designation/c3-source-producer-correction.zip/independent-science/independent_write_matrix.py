from __future__ import annotations

import hashlib
from pathlib import Path

import pytest
from neistra_api.import_export import ArtifactService
from neistra_api.models import Artifact, StructureEntry
from neistra_core.ligands.models import LigandDesignationV1

from independent_read_matrix import damage, isolated_client, observe, setup


def exact_source(project, entry):
    return {'project_id': project['id'], 'entry_id': entry['id'],
            'current_artifact_id': entry['current_artifact_id'],
            'original_artifact_id': entry['original_artifact_id']}


def defaults(client, project, entries):
    with client.app.state.session_factory() as session:
        for entry in entries:
            session.get(StructureEntry, entry['id']).ligand_designation = LigandDesignationV1().model_dump(mode='json')
        session.commit()
    return client.get(f"/api/v1/projects/{project['id']}").json()


def invoke(client, project, entry, operation, candidate_key, input_hash=None, **changes):
    if operation == 'candidates':
        return client.get(f"/api/v1/projects/{project['id']}/entries/{entry['id']}/ligand-candidates",
                          params={'expected_artifact_id': entry['current_artifact_id']})
    if operation == 'depiction':
        return client.get(f"/api/v1/projects/{project['id']}/entries/{entry['id']}/ligand-candidates/{candidate_key}/depiction",
                          params={'expected_artifact_id': entry['current_artifact_id']})
    if operation == 'resolve':
        return client.post(f"/api/v1/projects/{project['id']}/ligand-designations/resolve",
                           json={'expected_revision': project['revision'], 'entry_ids': [entry['id']]})
    command = {'expected_revision': project['revision'], 'expected_artifact_id': entry['current_artifact_id'],
               'candidate_key': candidate_key, **({'expected_input_hash': input_hash} if input_hash else {}), **changes}
    return client.request('PUT', f"/api/v1/projects/{project['id']}/entries/{entry['id']}/ligand-designation", json=command)


def cold(client, operation):
    project, entry, url, params, _ = setup(client, 'cold')
    page = client.get(url.rsplit('/', 2)[0], params=params).json()
    key = page['candidates'][0]['candidate_key']
    if operation == 'resolve':
        project = defaults(client, project, [entry])
        entry = project['entries'][0]
    return project, entry, key, page['input_hash']


@pytest.mark.parametrize('operation', ['designate', 'resolve'])
@pytest.mark.parametrize('role', ['current', 'original'])
@pytest.mark.parametrize('kind', ['bytes', 'file', 'row'])
def test_write_source_failures_identify_the_exact_failed_input(isolated_client, operation, role, kind):
    client = isolated_client
    project, entry, key, digest = cold(client, operation)
    with damage(client, entry[f'{role}_artifact_id'], kind):
        response = invoke(client, project, entry, operation, key, digest)
        detail = observe(f'write/{operation}/{role}/{kind}', response)
        assert response.status_code == (404 if kind == 'row' else 409), response.text
        assert detail['code'] == ('artifact_not_found' if kind == 'row' else 'artifact_integrity_error')
        assert detail.get('source_verification') == role, detail
        assert detail.get('source_identity') == exact_source(project, entry), detail
    assert client.get(f"/api/v1/projects/{project['id']}").json() == project


@pytest.mark.parametrize('operation', ['candidates', 'depiction', 'designate', 'resolve'])
@pytest.mark.parametrize('invalid', ['media', 'normalized'])
def test_molecular_source_validation_conflicts_are_typed_at_every_producer(isolated_client, operation, invalid):
    client = isolated_client
    project, entry, key, digest = cold(client, operation)
    with client.app.state.session_factory() as session:
        artifact = session.get(Artifact, entry['current_artifact_id'])
        path = client.app.state.settings.data_dir / artifact.relative_path
        original, old_size, old_digest, old_media = path.read_bytes(), artifact.size, artifact.sha256, artifact.media_type
        if invalid == 'media':
            artifact.media_type = 'image/svg+xml'
        else:
            payload = b'{"schema_version":1,"atoms":"invalid-actual-normalized-input"}'
            path.write_bytes(payload)
            artifact.size, artifact.sha256 = len(payload), hashlib.sha256(payload).hexdigest()
        session.commit()
    try:
        response = invoke(client, project, entry, operation, key, digest)
        detail = observe(f'validation/{operation}/{invalid}', response)
        assert response.status_code == 409, response.text
        assert detail['code'] == ('structure_artifact_conflict' if invalid == 'media' else 'artifact_integrity_error')
        assert detail.get('source_verification') == 'current', detail
        assert detail.get('source_identity') == exact_source(project, entry), detail
    finally:
        path.write_bytes(original)
        with client.app.state.session_factory() as session:
            artifact = session.get(Artifact, entry['current_artifact_id'])
            artifact.size, artifact.sha256, artifact.media_type = old_size, old_digest, old_media
            session.commit()


@pytest.mark.parametrize('mode', ['hash', 'candidate', 'revision'])
def test_semantic_command_rejections_are_not_physical_source_facts(isolated_client, mode):
    client = isolated_client
    project, entry, key, digest = cold(client, 'designate')
    response = invoke(client, project, entry, 'designate', 'absent-candidate' if mode == 'candidate' else key,
                      '0' * 64 if mode == 'hash' else digest,
                      **({'expected_revision': project['revision'] + 1} if mode == 'revision' else {}))
    detail = observe(f'positive/semantic/{mode}', response)
    assert response.status_code == (422 if mode == 'candidate' else 409), response.text
    assert detail['code'] == {'hash': 'structure_artifact_conflict', 'candidate': 'invalid_project_operation', 'revision': 'revision_conflict'}[mode]
    assert 'source_verification' not in detail and 'source_identity' not in detail, detail
    assert client.get(f"/api/v1/projects/{project['id']}").json() == project


@pytest.mark.parametrize('role', ['current', 'original'])
def test_manual_same_candidate_noop_still_checks_sources(isolated_client, role):
    client = isolated_client
    project, entry, key, digest = cold(client, 'designate')
    first = invoke(client, project, entry, 'designate', key, digest)
    assert first.status_code == 200, first.text
    project = client.get(f"/api/v1/projects/{project['id']}").json(); entry = project['entries'][0]
    assert entry['ligand_designation']['origin'] == 'manual'
    with damage(client, entry[f'{role}_artifact_id'], 'bytes'):
        response = invoke(client, project, entry, 'designate', key, digest)
        detail = observe(f'write/manual-noop/{role}', response)
        assert response.status_code == 409, response.text
        assert detail.get('source_verification') == role and detail.get('source_identity') == exact_source(project, entry), detail
    assert client.get(f"/api/v1/projects/{project['id']}").json() == project


def test_clear_noop_and_no_input_do_not_fabricate_read_proof(isolated_client, monkeypatch):
    client = isolated_client
    project, entry, key, digest = cold(client, 'designate')
    def forbidden(*args, **kwargs):
        raise AssertionError('Clear must not manufacture a molecular source check')
    monkeypatch.setattr(ArtifactService, 'read_verified_bytes', forbidden)
    command = {'expected_revision': project['revision'], 'expected_artifact_id': entry['current_artifact_id'], 'clear': True}
    endpoint = f"/api/v1/projects/{project['id']}/entries/{entry['id']}/ligand-designation"
    response = client.request('PUT', endpoint, json=command)
    assert response.status_code == 200, response.text
    project = client.get(f"/api/v1/projects/{project['id']}").json(); command['expected_revision'] = project['revision']
    assert project['entries'][0]['ligand_designation']['status'] == 'cleared'
    again = client.request('PUT', endpoint, json=command)
    assert again.status_code == 200 and again.json() == project, again.text
    with client.app.state.session_factory() as session:
        stored = session.get(StructureEntry, entry['id'])
        stored.current_artifact_id = None
        stored.ligand_designation = LigandDesignationV1().model_dump(mode='json')
        session.commit()
    command['expected_artifact_id'] = None
    empty = client.request('PUT', endpoint, json=command)
    assert empty.status_code == 200 and empty.json()['entries'][0]['ligand_designation']['status'] == 'cleared', empty.text


@pytest.mark.parametrize('role', ['current', 'original'])
@pytest.mark.parametrize('kind', ['bytes', 'file', 'row'])
def test_batch_failure_names_only_second_entry_and_rolls_back_first(isolated_client, role, kind):
    client = isolated_client
    project, first, _, _ = cold(client, 'designate')
    reply = client.post(f"/api/v1/projects/{project['id']}/imports",
                        data={'expected_revision': project['revision'], 'generate_3d': 'true'},
                        files=[('files', ('second.smi', b'CCN second\n', 'chemical/x-daylight-smiles'))])
    assert reply.status_code == 201, reply.text
    project = client.get(f"/api/v1/projects/{project['id']}").json()
    second = next(e for e in project['entries'] if e['id'] != first['id'])
    assert second['current_artifact_id'] != first['current_artifact_id']
    assert second['original_artifact_id'] != first['original_artifact_id']
    project = defaults(client, project, project['entries'])
    first = next(e for e in project['entries'] if e['id'] == first['id'])
    second = next(e for e in project['entries'] if e['id'] == second['id'])
    with damage(client, second[f'{role}_artifact_id'], kind):
        response = client.post(f"/api/v1/projects/{project['id']}/ligand-designations/resolve",
                               json={'expected_revision': project['revision'], 'entry_ids': [first['id'], second['id']]})
        detail = observe(f'write/batch-second/{role}/{kind}', response, requested=[first['id'], second['id']])
        assert response.status_code == (404 if kind == 'row' else 409), response.text
        assert detail.get('source_verification') == role and detail.get('source_identity') == exact_source(project, second), detail
        assert detail['source_identity']['entry_id'] != first['id']
    assert client.get(f"/api/v1/projects/{project['id']}").json() == project


def test_resolve_skips_assigned_sources_without_fabricating_checks(isolated_client, monkeypatch):
    client = isolated_client
    project, entry, key, digest = cold(client, 'designate')
    assert entry['ligand_designation']['status'] == 'resolved'
    def forbidden(*args, **kwargs):
        raise AssertionError('An assigned entry is outside legacy recognition work')
    monkeypatch.setattr(ArtifactService, 'read_verified_bytes', forbidden)
    response = invoke(client, project, entry, 'resolve', key, digest)
    assert response.status_code == 200 and response.json() == project, response.text
