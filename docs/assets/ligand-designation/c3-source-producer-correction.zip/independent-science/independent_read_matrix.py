from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import pytest
from neistra_api.database import Base
from neistra_api.main import create_app
from neistra_api.models import Artifact, LigandDepictionBinding
from neistra_api.settings import Settings
from sqlalchemy import delete

from tests.integration.test_ligand_designation import candidates, imported
from tests.support.api_client import ApiClient

EVIDENCE = Path(__file__).resolve().parent
RESULTS: list[dict[str, Any]] = []


@pytest.fixture
def isolated_client(tmp_path: Path):
    settings = Settings(data_dir=tmp_path, database_url=f"sqlite:///{tmp_path / 'test.db'}",
                        auto_create_schema=True, enable_test_routes=True)
    app = create_app(settings)
    Base.metadata.create_all(app.state.engine)
    yield ApiClient(app)
    app.state.engine.dispose()
    (EVIDENCE / 'backend-observations.json').write_text(json.dumps(RESULTS, indent=2) + '\n')


def setup(client: ApiClient, mode: str):
    project = imported(client)
    entry = project['entries'][0]
    inventory = candidates(client, project)
    url = (f"/api/v1/projects/{project['id']}/entries/{entry['id']}/ligand-candidates/"
           f"{inventory['candidates'][0]['candidate_key']}/depiction")
    params = {'expected_artifact_id': entry['current_artifact_id']}
    ready = None
    if mode != 'cold':
        response = client.get(url, params=params)
        assert response.status_code == 200, response.text
        ready = response.json()
        assert ready['status'] == 'ready' and ready['formula'] == 'C2H6O', ready
        if mode == 'content-only':
            with client.app.state.session_factory() as session:
                session.execute(delete(LigandDepictionBinding))
                session.commit()
    return project, entry, url, params, ready


@contextmanager
def damage(client: ApiClient, artifact_id: str, kind: str):
    with client.app.state.session_factory() as session:
        artifact = session.get(Artifact, artifact_id)
        assert artifact is not None
        source_path = client.app.state.settings.data_dir / artifact.relative_path
    original = source_path.read_bytes()
    database = client.app.state.settings.data_dir / 'test.db'
    row = None
    if kind == 'bytes':
        assert original
        source_path.write_bytes(bytes([original[0] ^ 1]) + original[1:])
    elif kind == 'file':
        source_path.unlink()
    elif kind == 'row':
        # Simulate missing immutable metadata in this disposable corrupted store.
        # Keep FK checks enabled in the actual application; external corruption is explicit.
        with sqlite3.connect(database) as connection:
            connection.row_factory = sqlite3.Row
            row = dict(connection.execute('SELECT * FROM artifacts WHERE id=?', (artifact_id,)).fetchone())
            connection.execute('DELETE FROM artifacts WHERE id=?', (artifact_id,))
    else:
        raise AssertionError(kind)
    try:
        yield
    finally:
        if kind in ('bytes', 'file'):
            source_path.write_bytes(original)
        elif row is not None:
            with sqlite3.connect(database) as connection:
                columns = list(row)
                connection.execute('INSERT INTO artifacts (' + ','.join(columns) + ') VALUES ('
                                   + ','.join('?' for _ in columns) + ')',
                                   [row[column] for column in columns])
        assert source_path.read_bytes() == original


def observe(label: str, response, **extra):
    item = {'case': label, 'status': response.status_code, 'body': response.json(), **extra}
    RESULTS.append(item)
    return response.json().get('detail', {})


@pytest.mark.parametrize('mode', ['warm', 'cold'])
@pytest.mark.parametrize('role', ['current', 'original'])
@pytest.mark.parametrize('kind', ['bytes', 'file', 'row'])
def test_actual_molecular_source_failures_have_exact_typed_provenance(isolated_client, mode, role, kind):
    client = isolated_client
    project, entry, url, params, ready = setup(client, mode)
    artifact_id = entry[f'{role}_artifact_id']
    assert artifact_id
    with damage(client, artifact_id, kind):
        response = client.get(url, params=params)
        detail = observe(f'source/{mode}/{role}/{kind}', response, artifact_id=artifact_id)
        assert response.status_code == (404 if kind == 'row' else 409), response.text
        assert detail['code'] == ('artifact_not_found' if kind == 'row' else 'artifact_integrity_error')
        assert detail.get('source_verification') == role, detail
        assert detail.get('source_identity') == {'project_id': project['id'], 'entry_id': entry['id'], 'current_artifact_id': entry['current_artifact_id'], 'original_artifact_id': entry['original_artifact_id']}, detail
    recovered = client.get(url, params=params)
    assert recovered.status_code == 200 and recovered.json()['status'] == 'ready', recovered.text
    if ready is not None:
        assert recovered.json() == ready
    assert client.get(f"/api/v1/projects/{project['id']}").json() == project


@pytest.mark.parametrize('mode', ['warm', 'content-only'])
@pytest.mark.parametrize('kind', ['bytes', 'file', 'row'])
def test_actual_derived_svg_failures_never_masquerade_as_source_failure(isolated_client, mode, kind):
    client = isolated_client
    _, entry, url, params, ready = setup(client, mode)
    assert ready is not None
    derived_id = ready['artifact']['id']
    assert derived_id not in (entry['current_artifact_id'], entry['original_artifact_id'])
    with damage(client, derived_id, kind):
        response = client.get(url, params=params)
        detail = observe(f'derived/{mode}/{kind}', response, artifact_id=derived_id)
        assert response.status_code == (404 if kind == 'row' else 409), response.text
        assert detail['code'] == ('artifact_not_found' if kind == 'row' else 'artifact_integrity_error')
        assert 'source_verification' not in detail, detail
    recovered = client.get(url, params=params)
    assert recovered.status_code == 200 and recovered.json() == ready, recovered.text


@pytest.mark.parametrize('mode', ['warm', 'cold'])
def test_actual_expected_artifact_conflict_is_unambiguous(isolated_client, mode):
    client = isolated_client
    _, entry, url, _, _ = setup(client, mode)
    response = client.get(url, params={'expected_artifact_id': 'different-immutable-source'})
    detail = observe(f'conflict/{mode}', response, actual_current=entry['current_artifact_id'])
    assert response.status_code == 409 and detail['code'] == 'structure_artifact_conflict', detail
    assert detail.get('source_verification') == 'current', detail
    assert 'source_identity' not in detail, detail


def test_invalid_normalized_molecular_payload_has_current_provenance(isolated_client):
    client = isolated_client
    project, entry, url, params, _ = setup(client, 'cold')
    with client.app.state.session_factory() as session:
        artifact = session.get(Artifact, entry['current_artifact_id'])
        assert artifact is not None
        path = client.app.state.settings.data_dir / artifact.relative_path
        original, old_size, old_digest = path.read_bytes(), artifact.size, artifact.sha256
        invalid = b'{"schema_version": 1, "atoms": "invalid-normalized-payload"}'
        path.write_bytes(invalid)
        artifact.size, artifact.sha256 = len(invalid), hashlib.sha256(invalid).hexdigest()
        session.commit()
    try:
        response = client.get(url, params=params)
        detail = observe('source/cold/current/invalid-normalized-with-matching-digest', response)
        assert response.status_code == 409 and detail['code'] == 'artifact_integrity_error', detail
        assert detail.get('source_verification') == 'current', detail
        assert detail.get('source_identity') == {'project_id': project['id'], 'entry_id': entry['id'], 'current_artifact_id': entry['current_artifact_id'], 'original_artifact_id': entry['original_artifact_id']}, detail
    finally:
        path.write_bytes(original)
        with client.app.state.session_factory() as session:
            artifact = session.get(Artifact, entry['current_artifact_id'])
            artifact.size, artifact.sha256 = old_size, old_digest
            session.commit()
