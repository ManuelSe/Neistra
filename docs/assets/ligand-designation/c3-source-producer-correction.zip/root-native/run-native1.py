"""One guarded four-case native observation; never publishes or edits sources."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path('/datadisk/dev/neistra-worktrees/issue-158-source-producer-qualification')
OUT = ROOT / '.issue-11-evidence/issue158-source-producer-native/native1'
AUTHOR = ROOT / '.issue-11-evidence/issue158-source-producer'
DATA = Path('/tmp/neistra158-source-producer-native1')
PORTS = (8260, 8261, 5414)
MAP_SHA = '2395af0eec031c23cac125250f18dc20562deb805c05a64c5444f36f46d8f55d'
FREEZE_SHA = 'dcc124a14dd8dd3b70fbf5be29e8cc7cece8b9dd534614529127bc9aa84166c9'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name, data): (OUT / name).write_text(json.dumps(data, indent=2) + '\n')
def sources():
    assert sha(AUTHOR / 'freeze2-pre-gate.json') == FREEZE_SHA
    assert sha(AUTHOR / 'freeze2-source-map.json') == MAP_SHA
    expected = json.loads((AUTHOR / 'freeze2-source-map.json').read_text())
    assert len(expected) == 1013
    actual = runpy.run_path(str(ROOT / 'docs/assets/ligand-designation/qualification.py.txt'), run_name='native_source_readback')['current_identities'](ROOT)
    assert actual == expected, 'Complete selected-source inventory changed'
    return actual
def ports():
    listening = set()
    for name in ('tcp', 'tcp6'):
        for line in Path('/proc/net', name).read_text().splitlines()[1:]:
            fields = line.split()
            if fields[3] == '0A': listening.add(int(fields[1].split(':')[-1], 16))
    return {str(p): p not in listening for p in PORTS}
def owned():
    expected = ('NEISTRA_E2E_DATA_DIR=' + str(DATA)).encode(); rows = []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            if expected not in (p / 'environ').read_bytes().split(b'\0'): continue
            raw = (p / 'stat').read_text(); fields = raw[raw.rindex(')') + 2:].split()
            if fields[0] != 'Z': rows.append({'pid': int(p.name), 'start_token': fields[19]})
        except (OSError, ValueError): pass
    return rows

assert sys.argv[1:] == ['execute'], 'Explicit primary execute argument required'
assert Path.cwd() == ROOT
before = sources()
assert not DATA.exists() and not owned() and all(ports().values())
assert not OUT.exists(); OUT.mkdir()
state = {'scope': 'Actual four-case native source-write correctness, not complete release qualification',
         'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'complete': False, 'source_count': 1013, 'source_before': before,
         'source_map_sha256': MAP_SHA, 'freeze_sha256': FREEZE_SHA,
         'runner_sha256': sha(Path(__file__)), 'data_dir': str(DATA),
         'preflight_ports_unused': ports(), 'preflight_owned_pids': owned()}
unset = [key for key in os.environ if key.startswith(('NEISTRA_', 'MOLWEAVE_')) or key == 'DATABASE_URL']
env = {key: value for key, value in os.environ.items() if key not in unset}
overrides = {'PYTHONPATH': ':'.join(str(ROOT / p) for p in ['apps/api/src', 'packages/neistra_core/src', 'packages/neistra_demo_plugin/src', '.']),
             'NEISTRA_E2E_DATA_DIR': str(DATA), 'NEISTRA_E2E_API_PORT': '8260',
             'NEISTRA_E2E_WORKER_PORT': '8261', 'NEISTRA_E2E_WEB_PORT': '5414',
             'NEISTRA_PERFORMANCE': '0', 'PLAYWRIGHT_BROWSERS_PATH': '/datadisk/dev/neistra/.playwright',
             'PLAYWRIGHT_JSON_OUTPUT_FILE': str(OUT / 'browser.json')}
env.update(overrides)
command = ['corepack', 'pnpm', 'exec', 'playwright', 'test', 'tests/e2e/ligand-source-write-recovery.spec.ts',
           '--workers=1', '--retries=0', '--max-failures=1', '--reporter=list,json', '--output', str(OUT / 'native')]
state.update({'command': command, 'environment_overrides': overrides, 'unset_environment_keys': sorted(unset)})
with zipfile.ZipFile(OUT / 'sources-before.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(before): archive.write(ROOT / name, name)
state['source_archive_sha256'] = sha(OUT / 'sources-before.zip'); save('actual-receipt.json', state)
with (OUT / 'native.log').open('xb') as log:
    child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    state['actual_child_pid'] = child.pid; save('actual-receipt.json', state)
    print('Native four-case START', child.pid, flush=True); code = child.wait()
state['actual_child_exit'] = code; state['native_log_sha256'] = sha(OUT / 'native.log')
for _ in range(60):
    if not owned() and all(ports().values()): break
    time.sleep(0.25)
state['cleanup_owned_pids'] = owned(); state['cleanup_ports_unused'] = ports()
save('actual-receipt.json', state)
assert not state['cleanup_owned_pids'] and all(state['cleanup_ports_unused'].values()), 'Owned cleanup incomplete; preserve stores'
raw = OUT / 'post-cleanup-database-bytes'; raw.mkdir(); snapshots = {}
for name in ('neistra.db', 'neistra.db-wal', 'neistra.db-shm'):
    original = DATA / name
    if not original.exists(): snapshots[name] = {'exists': False}; continue
    assert original.is_file() and not original.is_symlink()
    stat_before = original.stat(); copy = raw / name
    with original.open('rb') as src, copy.open('xb') as dst: shutil.copyfileobj(src, dst)
    stat_after = original.stat(); assert (stat_before.st_size, stat_before.st_mtime_ns) == (stat_after.st_size, stat_after.st_mtime_ns)
    assert sha(original) == sha(copy)
    snapshots[name] = {'exists': True, 'bytes': copy.stat().st_size, 'sha256': sha(copy)}
state['raw_database_snapshot_before_any_diagnostic_SQL'] = snapshots
save('actual-receipt.json', state)
state['source_after'] = sources(); state['source_unchanged'] = state['source_after'] == before
if (OUT / 'browser.json').exists(): state['browser_stats'] = json.loads((OUT / 'browser.json').read_text())['stats']
state['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save('actual-receipt.json', state)
if code == 0:
    assert snapshots['neistra.db']['exists']
    stats = state['browser_stats']; assert stats['expected'] == 4 and all(stats[k] == 0 for k in ['unexpected', 'flaky', 'skipped'])
state['complete'] = code == 0 and state['source_unchanged']; save('actual-receipt.json', state)
print('Native four-case EXIT', code, 'sources fixed / owned cleanup retained', flush=True)
raise SystemExit(code)
