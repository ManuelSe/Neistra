import datetime,hashlib,json,pathlib,runpy,subprocess,sys
root=pathlib.Path.cwd();e=root/'.issue-11-evidence/issue158-source-producer';expected=json.loads((e/'freeze2-source-map.json').read_text());guard=runpy.run_path(str(e/'source_guard.py'),run_name='frozen_gate_guard')
def audit():return guard['audit'](root,expected,{})
assert audit()['source_count']==1013
receipt={'scope':'Isolated earliest158 fourproducer correction scoped author gate, not fullrelease/featurecompletion','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_count':1013,'source_map_sha256':hashlib.sha256((e/'freeze2-source-map.json').read_bytes()).hexdigest(),'steps':[],'complete':False}
def save():(e/'gate2-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
focused=['src/test/ligand-source-producer-api.test.ts','src/test/ligand-source-producer-owner.test.ts','src/test/ligand-source-producer-app.test.tsx','src/test/ligand-designation-controls.test.tsx','src/test/ligand-inventory-owner.test.ts','src/test/ligand-app-owner.test.tsx']
stages=[('backend',['.venv/bin/uv','run','pytest','-q','tests/integration/test_ligand_depiction_source_verification.py','tests/integration/test_ligand_source_producers.py','tests/integration/test_ligand_designation.py','tests/integration/test_ligand_query_qualification.py','tests/integration/test_ligand_depiction_bounds.py','tests/integration/test_ligand_occurrence_reads.py'],None),('ruff',['.venv/bin/uv','run','ruff','check','.'],None),('new-test-format',['.venv/bin/uv','run','ruff','format','--check','tests/integration/test_ligand_depiction_source_verification.py','tests/integration/test_ligand_source_producers.py'],None),('changed-boundary-format',['.venv/bin/uv','run','ruff','format','--check','--stdin-filename','apps/api/src/neistra_api/ligand_service.py','-'],(e/'changed-source-boundary-format.py.txt').read_bytes()),('mypy',['.venv/bin/uv','run','mypy','apps/api','packages/neistra_core','packages/neistra_demo_plugin'],None),('focused',['corepack','pnpm','--filter','@neistra/web','exec','vitest','run']+focused,None),('lint',['corepack','pnpm','--filter','@neistra/web','lint'],None),('types',['corepack','pnpm','--filter','@neistra/web','typecheck'],None),('web',['corepack','pnpm','--filter','@neistra/web','test'],None),('build',['corepack','pnpm','--filter','@neistra/web','build'],None)]
prior=json.loads((e/'gate1-receipt.json').read_text());oldmap=json.loads((e/'frozen-source-map.json').read_text())
changed={p for p in expected if expected[p]!=oldmap.get(p)}
assert changed=={'apps/web/src/test/ligand-source-producer-app.test.tsx'}
receipt['prior_gate']={'path':str((e/'gate1-receipt.json').relative_to(root)),'sha256':hashlib.sha256((e/'gate1-receipt.json').read_bytes()).hexdigest(),'actual_outer_exit':1,'global_source_maps_identical':False,'exact_delta':str((e/'freeze2-intervening.diff').relative_to(root)),'scope_basis':'Only a new TypeScript unit-test unsupported locatoroption was removed; Python/config/formatterinputs all byte-exact. Reuse first5 scoped Python/static steps; all affectedfrontend steps fresh.'}
assert [step['name'] for step in prior['steps'][:5]]==['backend','ruff','new-test-format','changed-boundary-format','mypy']
for step in prior['steps'][:5]:
 assert step['exit_code']==0
 assert hashlib.sha256((root/step['log']).read_bytes()).hexdigest()==step['log_sha256']
 receipt['steps'].append({**step,'reused_verified_unchanged_scope':True})
save()
for label,cmd,stdin in stages[5:]:
 assert audit()['sources']==expected
 with (e/('gate2-'+label+'.log')).open('wb') as log:result=subprocess.run(cmd,cwd=root,input=stdin,stdout=log,stderr=subprocess.STDOUT)
 receipt['steps'].append({'name':label,'command':cmd,'exit_code':result.returncode,'stdin_sha256':hashlib.sha256(stdin).hexdigest() if stdin else None,'log':str((e/('gate2-'+label+'.log')).relative_to(root)),'log_sha256':hashlib.sha256((e/('gate2-'+label+'.log')).read_bytes()).hexdigest()});save();print(label,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
receipt['sources_unchanged']=audit()['sources']==expected;receipt['complete']=receipt['sources_unchanged'];receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('1013complete-selected sources fixed, complete',receipt['complete'],flush=True);sys.exit(0 if receipt['complete'] else 3)
