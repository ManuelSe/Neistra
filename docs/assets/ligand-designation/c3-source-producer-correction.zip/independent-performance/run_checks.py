from pathlib import Path
import datetime,hashlib,json,subprocess,sys,zipfile
root=Path.cwd(); out=root/".issue-11-evidence/issue158-performance-source-producer-review"; author=root/".issue-11-evidence/issue158-source-producer"
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
expected=json.loads((author/"freeze2-source-map.json").read_text()); before=json.loads((author/"before-sources.json").read_text())
def audit():
 bad=[p for p,h in expected.items() if not (root/p).is_file() or sha((root/p).read_bytes())!=h]
 assert not bad,bad
 return {"count":len(expected),"map_sha256":sha((author/"freeze2-source-map.json").read_bytes()),"all_match":True}
receipt={"scope":"Independent performance CODE review checks only; no native, service, timing or release qualification", "started_utc":now(),"before":audit(),"author_handoff_sha256":sha((author/"handoff.json").read_bytes()),"checks":[],"complete":False}
with zipfile.ZipFile(author/"before1007-sources.zip") as z:
 assert z.testzip() is None
 assert all(sha(z.read(p))==h for p,h in before.items())
receipt["archived_before"]={"count":len(before),"all_member_hashes_match":True}
receipt["delta"]={"changed":[p for p in before if expected.get(p)!=before[p]],"new":[p for p in expected if p not in before],"removed":[p for p in before if p not in expected]}
files=["src/test/ligand-source-producer-api.test.ts","src/test/ligand-source-producer-owner.test.ts","src/test/ligand-source-producer-app.test.tsx","src/test/ligand-designation-controls.test.tsx","src/test/ligand-inventory-owner.test.ts","src/test/ligand-app-owner.test.tsx"]
cmd=["corepack","pnpm","--filter","@neistra/web","exec","vitest","run"]+files
step={"command":cmd,"cwd":str(root),"started_utc":now(),"log":"focused-180.log"}
with (out/step["log"]).open("wb") as log: step["exit_code"]=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
step["finished_utc"]=now();step["log_sha256"]=sha((out/step["log"]).read_bytes());receipt["checks"].append(step)
receipt["after"]=audit();receipt["complete"]=step["exit_code"]==0;receipt["finished_utc"]=now()
(out/"checks.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"receipt":str(out/"checks.json"),"receipt_sha256":sha((out/"checks.json").read_bytes()),"exit":step["exit_code"],"source_count":len(expected),"delta":receipt["delta"]},indent=2))
print((out/step["log"]).read_text()[-2500:]);sys.exit(step["exit_code"])
