from __future__ import annotations
import ast,datetime,hashlib,json,runpy,zipfile
from pathlib import Path
from types import SimpleNamespace as NS
root=Path.cwd();out=root/".issue-11-evidence/issue158-performance-source-producer-review";author=root/".issue-11-evidence/issue158-source-producer";prior=root.parent/"issue-158-durable-ligand-designation"
sha=lambda b:hashlib.sha256(b).hexdigest()
expected=json.loads((author/"freeze2-source-map.json").read_text());oldmap=json.loads((author/"before-sources.json").read_text());handoff=json.loads((author/"handoff.json").read_text())
guard=runpy.run_path(str(author/"source_guard.py"),run_name="review_guard");verified=guard["audit"](root,expected,{})
assert verified["source_digest"]=="203238cad1841395df87599d94c45aab79331513ce3f810272618c19efe92617"
assert all(sha((prior/p).read_bytes())==h for p,h in oldmap.items())
manifest=handoff["files"]
for p,info in manifest.items():
 b=(author/p).read_bytes();assert len(b)==info["bytes"] and sha(b)==info["sha256"],p
zips=[]
for p in manifest:
 if p.endswith(".zip"):
  with zipfile.ZipFile(author/p) as z:assert z.testzip() is None
  zips.append(p)
service="apps/api/src/neistra_api/ligand_service.py"
with zipfile.ZipFile(author/"before1007-sources.zip") as z: old=z.read(service).decode()
new=(root/service).read_text()
def methods(source):
 tree=ast.parse(source); cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="LigandService")
 return {m.name:m for m in cls.body if isinstance(m,ast.FunctionDef)}
om,nm=methods(old),methods(new)
unchanged=[name for name in om if ast.get_source_segment(old,om[name])==ast.get_source_segment(new,nm[name])]
assert sorted(unchanged)==sorted(["__init__","_inputs","_occurrences","_request_key","candidates","depiction","designate","resolve"])
class Artifacts:
 def __init__(self):self.calls=[]
 def load_normalized(self,key):self.calls.append(["load_normalized",key]);return NS()
 def read_verified_bytes(self,key):self.calls.append(["read_verified_bytes",key]);return b"input"
 def get(self,key):self.calls.append(["get",key]);return NS()
 def response(self,value):self.calls.append(["response"]);return NS()
def run(source):
 ms=methods(source); selected=[ms[n] for n in ["_load_inputs","_cached","_source_read"] if n in ms]
 cls=ast.ClassDef(name="ControlledService",bases=[],keywords=[],body=selected,decorator_list=[],type_params=[])
 module=ast.Module(body=[ast.ImportFrom(module="__future__",names=[ast.alias(name="annotations")],level=0),cls],type_ignores=[])
 namespace={"_LigandInputs":lambda *v:NS(structure=v[0],original=v[1],inventory=v[2]),"assess_mmcif_source":lambda *v:None,"prepare_chemistry":lambda *a,**kw:None,"resolve_candidates":lambda *a,**kw:NS(),"LigandSourceIdentity":NS(capture=lambda e:NS(project_id=e.project_id,entry_id=e.id,current_artifact_id=e.current_artifact_id,original_artifact_id=e.original_artifact_id)),"LigandDepictionRead":lambda **kw:NS(**kw),"LigandDepictionBinding":object(),"LigandDepictionCache":object(),"ArtifactIntegrityError":type("ArtifactIntegrityError",(Exception,),{}),"ArtifactNotFoundError":type("ArtifactNotFoundError",(Exception,),{}),"StructureArtifactConflictError":type("StructureArtifactConflictError",(Exception,),{})}
 exec(compile(ast.fix_missing_locations(module),"<exact-production-methods-controlled-dependencies>","exec"),namespace)
 service=namespace["ControlledService"]();service.artifacts=Artifacts();entry=NS(id="entry",project_id="project",current_artifact_id="current",original_artifact_id="original")
 result={}
 for chemistry in [False,True]:
  service.artifacts.calls=[];service._load_inputs(entry,with_chemistry=chemistry);result["cold_chemistry_"+str(chemistry)]=list(service.artifacts.calls)
 binding=NS(cache_key="cache",summary={});cache=NS(artifact_id="svg",input_hash="hash",cache_key="cache",implementation="implementation",library_version="library")
 service.session=NS(get=lambda kind,key:binding if kind is namespace["LigandDepictionBinding"] else cache)
 service.artifacts.calls=[];service._cached(entry,"candidate","request");result["warm_depiction"]=list(service.artifacts.calls)
 return result
oldcalls,newcalls=run(old),run(new);assert oldcalls==newcalls
freeze=json.loads((prior/".issue-11-evidence/issue158-occurrence-performance/frozen-production-sources.json").read_text())
measured={p:{"measured":h,"current":sha((root/p).read_bytes()),"unchanged":h==sha((root/p).read_bytes())} for p,h in freeze["files"].items()}
assert sum(v["unchanged"] for v in measured.values())==7
assert oldmap[service]==freeze["files"][service]
for file in ["gate1-receipt.json","gate2-receipt.json"]:
 receipt=json.loads((author/file).read_text())
 for step in receipt["steps"]:assert sha((root/step["log"]).read_bytes())==step["log_sha256"]
result={"scope":"Read-only source/evidence audit and exact production-method call-shape control using fake downstream artifacts/chemistry; not actual molecular API timing, allocation or scientific correctness benchmark","observed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"complete_discovery":{"count":verified["source_count"],"digest":verified["source_digest"],"no_added_or_missing_selected_files":True},"prior_D197_1007_tree_all_hashes_match":True,"author_manifest_files":len(manifest),"author_zip_CRC_count":len(zips),"author_zip_names":zips,"unchanged_service_methods_byte_exact":unchanged,"source_read_control_before":oldcalls,"source_read_control_after":newcalls,"prior_measured_files":measured,"all_author_gate_raw_log_hashes_verified":True}
(out/"source-and-read-audit.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
