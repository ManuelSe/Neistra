from pathlib import Path
import datetime,json,hashlib,subprocess,zipfile,difflib,sys
root=Path.cwd();out=root/'.issue-11-evidence/issue158-owner-budget-author'
owned=['apps/web/src/ligands/inventoryQualification.ts','apps/web/src/components/LigandDesignationControls.tsx','apps/web/src/test/ligand-designation-controls.test.tsx','apps/web/src/test/ligand-inventory-owner.test.ts']
def hashes(paths):return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
def webmap():
 paths=[p for p in (root/'apps/web/src').rglob('*') if p.is_file()]
 public=root/'apps/web/public'
 if public.exists():paths.extend(p for p in public.rglob('*') if p.is_file())
 paths.extend(root/p for p in ['apps/web/package.json','apps/web/index.html','apps/web/vite.config.ts','apps/web/eslint.config.js','apps/web/tsconfig.app.json','apps/web/tsconfig.node.json','apps/web/tsconfig.json','package.json','pnpm-lock.yaml'] if (root/p).exists())
 return hashes(sorted(str(p.relative_to(root)) for p in paths))
before=hashes(owned);webbefore=webmap();(out/'final-source-before.json').write_text(json.dumps({'owned':before,'complete_web_sources_and_config':webbefore},indent=2)+'\n')
with zipfile.ZipFile(out/'final-source.zip','w',compression=zipfile.ZIP_DEFLATED) as a:
 for p in owned:a.write(root/p,p)
originals=json.loads((out/'source-before.json').read_text());diff=''
with zipfile.ZipFile(out/'source-before.zip') as a:
 old80=a.read('apps/web/src/test/ligand-designation-controls.test.tsx');assert (root/'apps/web/src/test/ligand-designation-controls.test.tsx').read_bytes().startswith(old80)
 for p in owned:
  old=a.read(p).decode() if p in originals else ''
  diff+=''.join(difflib.unified_diff(old.splitlines(keepends=True),(root/p).read_text().splitlines(keepends=True),fromfile='before/'+p if old else '/dev/null',tofile='after/'+p))
(out/'implementation.diff').write_text(diff)
commands=[('lint',['npm','--prefix','apps/web','run','lint']),('types',['npm','--prefix','apps/web','run','typecheck']),('focused',['corepack','pnpm','--filter','@neistra/web','exec','vitest','run','src/test/ligand-designation-controls.test.tsx','src/test/ligand-inventory-owner.test.ts']),('all-web',['npm','--prefix','apps/web','run','test']),('build',['npm','--prefix','apps/web','run','build'])]
checks=[]
for label,command in commands:
 print('START',label,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True);log=out/f'final-{label}.log'
 with log.open('w') as stream:result=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 checks.append({'label':label,'command':command,'cwd':str(root),'exit_code':result.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});print('END',label,'exit',result.returncode,flush=True)
 if result.returncode:break
after=hashes(owned);webafter=webmap();receipt={'scope':'D197 bounded earliest158 author candidate; web checks only, no complete42/native/final review/release claim.','owned_before':before,'owned_after':after,'owned_stable':before==after,'complete_web_before':webbefore,'complete_web_after':webafter,'complete_web_stable':webbefore==webafter,'original80_exact_prefix':True,'original80_prefix_bytes':len(old80),'checks':checks,'passed':len(checks)==len(commands) and all(c['exit_code']==0 for c in checks),'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(out/'final-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');assert before==after and webbefore==webafter;sys.exit(0 if receipt['passed'] else 1)
