const fs = require('node:fs'), path = require('node:path'), Module = require('node:module');
const req = Module.createRequire(path.resolve('apps/web/package.json')), ts = req('typescript');
// The retained control transpiles its entry module. Register the same installed
// compiler for its new real local TypeScript dependency; no module is stubbed.
require.extensions['.ts'] = (module, filename) => module._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText, filename);
require(path.resolve('.issue-11-evidence/issue158-owner-retention/independent-original-control.cjs'));
