import subprocess,json,datetime,hashlib,sys
from pathlib import Path
root=Path.cwd();out=root/'.issue-11-evidence';label='c4-candidate11';assets=root/'docs/assets/ligand-designation';receipt=out/'issue158-c4-candidate11-wrapper.json';assert not receipt.exists();assert not subprocess.check_output(['git','status','--porcelain'],text=True)
commands=[('qualification',[str(root/'.venv/bin/python'),str(assets/'qualification.py.txt'),str(assets/(label+'-recipe.json'))]),('summary',[str(root/'.venv/bin/python'),str(assets/'qualification-summary.py.txt'),label]),('packaging',[str(root/'.venv/bin/python'),str(assets/'release-evidence.py.txt'),'gate','--root',str(root),'--label',label,'--output-dir',str(assets)])]
state={'scope':'Actual sequential candidate qualification, independent summary and recursive packaging; not publication','label':label,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'complete':False}
def save():receipt.write_text(json.dumps(state,indent=2)+'\n')
save()
for phase,cmd in commands:
 log=out/f'issue158-{label}-{phase}.log';print('PHASE START',phase,flush=True);p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
 with log.open('wb') as stream:
  for line in p.stdout:
   stream.write(line);stream.flush();s=line.decode(errors='replace').strip()
   if s.startswith(('START ','PASS ','FAIL ','COMPLETE ','[')) or phase!='qualification':print(s,flush=True)
 code=p.wait();state['steps'].append({'phase':phase,'command':cmd,'actual_child_pid':p.pid,'exit_code':code,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});save();print('PHASE EXIT',phase,code,flush=True)
 if code:raise SystemExit(code)
state['complete']=True;state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('ENCLOSING COMPLETE',receipt,flush=True)
