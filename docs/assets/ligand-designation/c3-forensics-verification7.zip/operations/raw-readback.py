from pathlib import Path
import datetime,hashlib,json,runpy
root=Path.cwd();e=root/'.issue-11-evidence/forensics/c11-extension';a=root/'docs/assets/ligand-designation';h=runpy.run_path(str(a/'release-evidence.py.txt'));q=runpy.run_path(str(a/'qualification.py.txt'));canonical=json.loads((e/'input-inventory.json').read_text())['files'];proof=json.loads((e/'historical-source-provenance.json').read_text());gate=json.loads((a/'c4-candidate11-gate.json').read_text())
roots={
'interrupted-candidate11/tracked/c4-candidate11-native':a/'c4-candidate11-native',
'retained-workspaces/neistra158-c4-candidate11':Path('/tmp/neistra158-c4-candidate11'),
'interruption/issue158-c11-resource-interruption':root/'.issue-11-evidence/issue158-c11-resource-interruption',
'retention-control/issue158-owner-retention':root/'.issue-11-evidence/issue158-owner-retention'}
compared={}
for prefix,d in roots.items():
 rows={}
 for f in d.rglob('*'):
  assert not f.is_symlink(),f
  if f.is_file():rows[prefix+'/'+f.relative_to(d).as_posix()]=h['fingerprint'](f)
 assert rows=={n:v for n,v in canonical.items() if n.startswith(prefix+'/')};compared[str(d)]=dict(files=len(rows),bytes=sum(v['bytes'] for v in rows.values()),exact_union=True)
for n,v in canonical.items():
 f=None
 if n.startswith('interrupted-candidate11/tracked/') and not n.startswith('interrupted-candidate11/tracked/c4-candidate11-native/'):f=a/n.removeprefix('interrupted-candidate11/tracked/')
 elif n.startswith('interrupted-candidate11/private/'):f=root/'.issue-11-evidence'/n.removeprefix('interrupted-candidate11/private/')
 elif n.startswith('preceding-reader-source/'):f=Path(gate['preceding_reader']['root'])/n.removeprefix('preceding-reader-source/')
 if f is not None:assert h['fingerprint'](f)==v,n
for n,v in json.loads((e/'captured-library-licenses.json').read_text())['files'].items():assert h['fingerprint'](Path(v['path']))=={k:v[k] for k in ['bytes','sha256']}==canonical[n]
old=json.loads((e/'previous/unchanged-identities.json').read_text())
for n,v in old.items():assert h['fingerprint'](root/n)==v,n
live=q['current_identities'](root);delta=sorted(n for n in set(live)|set(proof['source_identities']) if live.get(n)!=proof['source_identities'].get(n))
assert q['extracted_identities'](Path(gate['preceding_reader']['root']),gate['preceding_source_before'])==gate['preceding_source_before']
r=dict(scope='Fresh exact interrupted raw/original retention readback after partition proof; not a native or full qualification rerun',canonical_files=len(canonical),canonical_raw_bytes=sum(v['bytes'] for v in canonical.values()),owned_roots=compared,all931old_source_originals_equal=True,all1006historical_git_blobs_bound_to_gate=True,old52parts_seven_run_records_inventories_verification1through6_unchanged=True,all_originals_remain_in_place=True,live_corrective_source_delta=delta,historical_snapshot_independent_of_live_correction=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(e/'raw-union-readback.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
