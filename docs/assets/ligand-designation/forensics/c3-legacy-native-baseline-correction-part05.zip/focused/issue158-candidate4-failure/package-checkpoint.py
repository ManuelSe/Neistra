import json,runpy,hashlib,datetime
from pathlib import Path
root=Path.cwd();assets=root/'docs/assets/ligand-designation';evidence=root/'.issue-11-evidence';h=runpy.run_path(str(assets/'release-evidence.py.txt'));items={};retained={}
for name in ['issue158-candidate4-failure','issue158-legacy-assessment-before1','issue158-legacy-assessment-after1','issue158-legacy-assessment-after2']:
 count,excluded=h['add_reader_workspace'](items,evidence/name,'focused/'+name);retained[name]={'files':count,'excluded_named_caches':excluded}
for path in sorted(evidence.glob('issue158-c4-candidate4-*')):
 if path.is_file():h['add'](items,'failed-candidate4/private/'+path.name,path)
h['add'](items,'focused/diagnostic-runner.py',evidence/'issue158-legacy-assessment-run.py')
for path in sorted(assets.glob('c4-candidate4-*')):
 if path.is_dir():
  # This is explicitly failed-run forensic retention, not a completed gate.
  # Keep unfinished browser artifacts losslessly; the generic finished-gate
  # scanner continues to reject these directories.
  assert path.name=='c4-candidate4-native' and not path.is_symlink();count=0
  for member in sorted(path.rglob('*')):
   assert not member.is_symlink(),member
   if not member.is_file():continue
   h['add'](items,'failed-candidate4/tracked/'+path.name+'/'+member.relative_to(path).as_posix(),member,reader_workspace=True);count+=1
  retained[path.name]={'files':count,'excluded_named_caches':[],'policy':'Explicitfailedrunforensics retainallincompletebrowserartifacts; completegatepackagerunchanged'}
 elif path.is_file():h['add'](items,'failed-candidate4/tracked/'+path.name,path)
for name in ['neistra158-c4-candidate4','neistra158-legacy-assessment-before1','neistra158-legacy-assessment-after1','neistra158-legacy-assessment-after2']:
 directory=Path('/tmp')/name;count,excluded=h['add_reader_workspace'](items,directory,'retained-workspaces/'+name);retained[name]={'files':count,'excluded_named_caches':excluded}
result=json.loads((evidence/'issue158-candidate4-failure/correction-result.json').read_text());ids=runpy.run_path(str(assets/'qualification.py.txt'))['current_identities'](root);assert ids==result['source'];gate=json.loads((assets/'c4-candidate4-gate.json').read_text());assert gate['source_before']==gate['source_after'] and gate['source_unchanged'] and gate['preceding_source_unchanged'];assert len(gate['steps'])==16 and gate['steps'][-1]['label']=='browser' and gate['steps'][-1]['exit_code']==1
assert all(s['exit_code']==0 for s in gate['steps'][:-1]);changed=sorted(k for k in ids if ids[k]!=gate['source_before'][k]);assert changed==['tests/e2e/hydrogen-membership.spec.ts'];assert len(ids)==1003
# Independent manifest-bearing ZIPs keep every file within Git/release limits.
# Estimate compressed payload before partitioning and reserve manifest overhead.
partitions=[];current={};used=0;budget=78*1024*1024
for name,member in sorted(items.items()):
 estimate=h['compressed_size'](member);assert estimate<budget,name
 if current and used+estimate>budget:partitions.append(current);current={};used=0
 current[name]=member;used+=estimate
if current:partitions.append(current)
packets=[]
for index,part in enumerate(partitions,1):
 archive=assets/f'c3-legacy-native-baseline-correction-part{index:02d}.zip';assert not archive.exists();packet=h['archive'](part,archive);assert packet['bytes']<95*1024*1024;packets.append(packet)
assert sum(p['outer_manifest_entries'] for p in packets)==len(items)
record={'scope':'Passing nativelegacyassessment oracle correction checkpoint; notcompletequalification orpushreadiness','base':'cd6715d3c5b458eefeb5d24e0305e0da69567dc3','source_count':len(ids),'source_digest':hashlib.sha256(json.dumps(ids,sort_keys=True).encode()).hexdigest(),'source_identities':ids,'changed_selected_sources':changed,'production_science_api_frontend_migrations_verificationtools_unchanged':True,'checked_archives':packets,'archive_partition_policy':'EachindependentZIPhascompleteownmanifest/CRC; disjointunionretainsallrawfailedandcorrectedfiles; under95MiB each','retained_workspaces':retained,'actual_failed_candidate4':{'session':73200,'exit':1,'python_passed':2976,'frontend_passed':1304,'frontend_suites':122,'supervisor_passed':14,'native_passed':53,'native_failed':1,'old_skips_encountered':2,'not_run':546,'current1003_and_old931_unchanged':True},'root_cause':'LegacyarchivefirstUIopen deliberatelycompletesuntoucheddefaultassessment andrevision1to2; oldnativeassertcomparedwithpreassessmentbaseline','correction':'Testseparatelyprovesexactoneassessment/currentcomplete20atommembership/source/origin/historyunchanged; checkpointsdirtyfalse-to-trueandtimestampslegitimate; allotherentryfieldsunchanged; thenretainsoriginalnativecomponent/orphanH/pick/editability/sourceassertionsandaddscompleteproject/originalbytesunchangedagainstpostassessmentbaseline','validation':{'before1_failed':2,'before1_actual_session':75909,'before1_actual_exit':1,'after1_failed':2,'after1_actual_session':72016,'after1_actual_exit':1,'after1_reason':'Newaddedoraclewronglyrequiredcomputeddirtyunchanged; actualproject_readcomparestountouchedcheckpoint','after2_passed':2,'after2_actual_session':5043,'after2_actual_exit':0,'all_focused_sources_unchanged':True,'no_deadline_retry_skip_exclusion_or_production_change':True},'no_partial_gate_pooling':True,'remaining':['scopedarchitecturefinaltestreassessment','checkpointcommit andfreshcandidate5all42summarypackagingactualenclosing','C5recipe/finalmetadata/all7samecandidatefinalapproval','normalPRreviewmerge/freshactualM42/releasecloseoutcleanup','remaining159through163/finalparentcloseout'],'single_parent_goal_active':True,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=assets/'c3-legacy-native-baseline-checkpoint.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'archives':packets,'source_count':len(ids),'source_digest':record['source_digest']},indent=2))
