"""Keep supplemental forensic verification source and provenance in primary evidence."""
from pathlib import Path
import datetime
import hashlib
import json
import runpy

root=Path.cwd();assets=root/'docs/assets/ligand-designation';private=root/'.issue-11-evidence'
helper=runpy.run_path(str(assets/'release-evidence.py.txt'))
def write_new(path,value):
    assert not path.exists(),path
    path.write_text(json.dumps(value,indent=2)+'\n')
sources=['tools/verify_ligand_forensics.py','tests/unit/test_ligand_forensic_verifier.py']
identity={name:helper['fingerprint'](root/name) for name in sources}
author=json.loads((private/'issue158-forensic-verifier/results.json').read_text())
assert author['source_unchanged'] and all(identity[name]['sha256']==author['source_after'][name] for name in sources)
local_path=private/'forensics/verification/local-verification.json'
local=json.loads(local_path.read_text());assert local['complete'] and local['all_indexed_assets_verified'] and local['asset_count']==18
offline_path=private/'forensics/verification/offline-controls-receipt.json'
offline=json.loads(offline_path.read_text());assert offline['source_unchanged'] and all(check['exit_code']==0 for check in offline['checks'])
enclosing=dict(scope='Packaging worker actual tool exit readback, not an application release gate',actual_tool_sessions=[dict(session=57369,exit_code=0,phase='registration and recursive packaging'),dict(session=13146,exit_code=0,phase='tracked local verifier'),dict(session=1506,exit_code=0,phase='offline controls, Ruff and mypy')],source_identities=identity,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
write_new(private/'forensics/verification/actual-enclosing.json',enclosing)
items={}
for name in sources:helper['add'](items,'source/'+name,root/name)
for path in sorted((private/'issue158-forensic-verifier').iterdir()):
    if path.is_file():helper['add'](items,'author-controls/'+path.name,path)
for path in sorted((private/'forensics/verification').iterdir()):
    if path.is_file():helper['add'](items,'packaging-controls/'+path.name,path)
for name in ['register158-forensics.py','register158-forensics.log','package158-forensic-verification.py']:
    helper['add'](items,'operations/'+name,private/name)
for name in ['registration-actual-enclosing.json','c4-candidate5-native-relocation.json','c4-candidate5-parts.json','c4-candidate5-input-inventory.json']:
    helper['add'](items,'operations/'+name,private/'forensics'/name)
for name in ['issue158-entry-locator-before1','issue158-selection-locator-before1','issue158-locator-combined-after1']:
    path=private/name/'actual-enclosing.json'
    assert path.is_file()
    helper['add'](items,'later-enclosing-readback/'+name+'/actual-enclosing.json',path)
for name in ['c3-forensics-index.json','c3-forensics-inventory-c4-candidate4.json.gz','c3-forensics-inventory-c4-candidate5.json.gz']:
    helper['add'](items,'indexed-contract/'+name,assets/name)
# Retain small historical recipes/source maps/lossless logs directly in primary
# evidence too. Raw failed native/store payloads remain supplemental parts only.
for label in ['c4-candidate4','c4-candidate5']:
    for path in sorted(assets.glob(label+'-*')):
        if path.is_file():helper['add'](items,'historical-provenance/'+path.relative_to(root).as_posix(),path)
archive=helper['archive'](items,assets/'c3-forensics-verification.zip')
assert {name:helper['fingerprint'](root/name) for name in sources}==identity
index=json.loads((assets/'c3-forensics-index.json').read_text())
record=dict(scope='Local supplemental forensic retention and verifier checkpoint; not public availability, application qualification, or final specialist readiness',archive=archive['file'],files=len(items),archive_bytes=archive['bytes'],archive_sha256=archive['sha256'],recursive_verification=archive['verification_counts'],index_sha256=helper['fingerprint'](assets/'c3-forensics-index.json')['sha256'],verifier_sha256=identity[sources[0]]['sha256'],tests_sha256=identity[sources[1]]['sha256'],local_parts_verified=local['asset_count'],canonical_files=sum(run['files'] for run in index['runs']),raw_bytes=sum(run['raw_bytes'] for run in index['runs']),part_bytes=index['total_asset_bytes'],all_recursive_crcs_and_exact_disjoint_inventory_unions=True,offline_controls=64,offline_control_network_requests=0,ruff='PASS',mypy='PASS2files',source_identities_unchanged=True,actual_enclosing_readback=enclosing['actual_tool_sessions'],raw_native_relocation='Verified filewise before/after; all original owned stores retained and no payload deleted',snapshot_boundary='C5 plus closed before1/after1 raw snapshots; actual enclosing receipts written afterwards are retained separately in this verification ZIP. Corrected after2/after3 belong to a separate root checkpoint.',failed_gates_remain_unqualified=True,
    required_remaining=['Independent specialist assessment of current verifier/index/parts and integrated final candidate','Fresh complete candidate and exact merged-master gates with source maps including verifier and offline controls','Primary packet includes this small source/control ZIP and indexed metadata, without nesting raw /forensics part payloads','Publish all18 indexed supplemental assets only from verified release; read server identities and full anonymous bodies with tracked verifier','Verify all public hashes, recursive CRCs, provenance and exact disjoint unions before child closeout'])
write_new(assets/'c3-forensics-verification.json',record)
print(json.dumps(record,indent=2),flush=True)
