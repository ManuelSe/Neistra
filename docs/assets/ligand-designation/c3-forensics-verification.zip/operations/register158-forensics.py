"""Register closed failed-run supplemental assets without application qualification."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import runpy
import zipfile

root = Path.cwd()
assets = root / 'docs/assets/ligand-designation'
private = root / '.issue-11-evidence'
helper = runpy.run_path(str(assets / 'release-evidence.py.txt'))
sha = lambda data: hashlib.sha256(data).hexdigest()
def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + '\n')
def collect(items, directory, prefix):
    assert directory.is_dir() and not directory.is_symlink(), directory
    count = 0
    # Failed-run forensics explicitly keep unfinished browser artifacts. This
    # private enumerator does not alter the completed-gate scanner or its policy.
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file(): continue
        helper['add'](items, prefix + '/' + path.relative_to(directory).as_posix(), path, reader_workspace=True)
        count += 1
    return count

index = dict(format_version=1,
    scope='Immutable expected failed-run forensic asset identities; verification does not qualify a failed gate',
    repository='ManuelSe/Neistra', issue=158, parent=11, release_version='0.36.0',
    publication_contract='Primary qualification ZIP and sidecars retain complete passing gates, readers, logs and source proofs. Every indexed supplemental forensic asset must be locally and anonymously verified before child closeout; the later publication receipt records actual IDs and public URLs.',
    extraction_policy='Each run has its own extraction_root. Never merge distinct runs; within each run manifests must form the exact disjoint union of its canonical inventory.',
    part_max_bytes_exclusive=80*1024*1024, runs=[])
uploads = []

def register(label, packets, canonical):
    union = {}; parts = []
    for ordinal, packet in enumerate(packets, 1):
        path = Path(packet['path'])
        assert helper['fingerprint'](path) == {key: packet[key] for key in ('bytes','sha256')}
        assert packet['bytes'] < index['part_max_bytes_exclusive']
        counts = helper['verify_layers'](path, path.name)
        assert counts == packet['verification_counts']
        with zipfile.ZipFile(path) as archive:
            rows = json.loads(archive.read('manifest.json'))
            assert len(rows) == packet['outer_manifest_entries']
            assert not union.keys() & rows.keys()
            union.update(rows)
        part = dict(ordinal=ordinal, asset_name=path.name, bytes=packet['bytes'], sha256=packet['sha256'], manifest_entries=len(rows), recursive_verification=counts,
                    repository_path=path.relative_to(root).as_posix() if label == 'c4-candidate4' else None)
        parts.append(part)
        uploads.append(dict(run=label, asset_name=path.name, local_path=str(path), bytes=packet['bytes'], sha256=packet['sha256']))
    assert union == canonical
    body = json.dumps(dict(format_version=1,run=label,scope='Exact closed-run inventory; failed-run qualification remains false',files=canonical),sort_keys=True,separators=(',',':')).encode()
    inventory = assets / ('c3-forensics-inventory-' + label + '.json.gz')
    assert not inventory.exists()
    inventory.write_bytes(gzip.compress(body,mtime=0))
    gate = json.loads((assets/(label+'-gate.json')).read_text())
    assert gate['source_before'] == gate['source_after'] and gate['source_unchanged'] and gate['preceding_source_unchanged']
    assert not gate['complete'] and gate['steps'][-1]['exit_code'] == 1
    index['runs'].append(dict(label=label,failed_candidate=gate['commit'],qualification_complete=False,failed_step=gate['steps'][-1]['label'],source_count=len(gate['source_before']),source_digest=sha(json.dumps(gate['source_before'],sort_keys=True).encode()),source_unchanged=True,preceding_source_count=len(gate['preceding_source_before']),preceding_source_unchanged=True,
        recipe=dict(path=(assets/(label+'-recipe.json')).relative_to(root).as_posix(),sha256=gate['recipe_sha256']),
        lossless_logs=[dict(label=step['label'],path=step['log'],uncompressed_sha256=step['log_sha256']) for step in gate['steps']],
        files=len(canonical),raw_bytes=sum(v['bytes'] for v in canonical.values()),extraction_root='forensics/'+label,
        inventory=dict(path=inventory.relative_to(root).as_posix(),**helper['fingerprint'](inventory),uncompressed_sha256=sha(body)),parts=parts,local_exact_union_and_recursive_verification=True))
    print('REGISTERED_RUN',label,len(canonical),len(parts),flush=True)

# Existing C4 parts have already been qualified locally as exact raw retention.
# Recheck every payload and its corresponding still-retained raw file now.
checkpoint_path = assets/'c3-legacy-native-baseline-checkpoint.json'
checkpoint = json.loads(checkpoint_path.read_text())
c4canonical = {}; c4packets = []
for packet in checkpoint['checked_archives']:
    old = Path(packet['path']); target = assets/'forensics'/packet['file']
    assert old.is_file() and not target.exists()
    assert helper['fingerprint'](old) == {key:packet[key] for key in ('bytes','sha256')}
    with zipfile.ZipFile(old) as archive:
        rows = json.loads(archive.read('manifest.json'))
        assert not c4canonical.keys() & rows.keys()
        c4canonical.update(rows)
        for name, identity in rows.items():
            if name.startswith('failed-candidate4/tracked/c4-candidate4-native/'):
                actual = private/'issue158-c4-candidate4-native-retained'/name.removeprefix('failed-candidate4/tracked/c4-candidate4-native/')
            elif name.startswith('failed-candidate4/tracked/'):
                actual = assets/name.removeprefix('failed-candidate4/tracked/')
            elif name.startswith('failed-candidate4/private/'):
                actual = private/name.removeprefix('failed-candidate4/private/')
            elif name == 'focused/diagnostic-runner.py':
                actual = private/'issue158-legacy-assessment-run.py'
            elif name.startswith('focused/'):
                actual = private/name.removeprefix('focused/')
            elif name.startswith('retained-workspaces/'):
                actual = Path('/tmp')/name.removeprefix('retained-workspaces/')
            else: raise AssertionError(name)
            observed = helper['fingerprint'](actual)
            if observed != identity:
                # Accepted historical partition v2 archived its v1 script; this
                # sole difference is explicitly recorded in the old checkpoint.
                assert name == 'focused/issue158-candidate4-failure/package-checkpoint.py'
                assert checkpoint['partition_union']['only_changed_payload_between_packaging_versions'] == [name]
                assert helper['fingerprint'](archive.read(name)) == identity
    target.parent.mkdir(exist_ok=True)
    old.rename(target)
    packet.update(path=str(target),repository_path=target.relative_to(root).as_posix())
    c4packets.append(packet)
assert len(c4canonical) == 8966
register('c4-candidate4',c4packets,c4canonical)
checkpoint['archive_partition_policy'] = 'Each independent ZIP has its own manifest and recursive CRC verification. Exact disjoint raw union; each existing unchanged part is below80MiB and is a supplemental release asset, not nested in the primary packet.'
checkpoint['supplemental_forensic_index'] = 'docs/assets/ligand-designation/c3-forensics-index.json'
checkpoint['part_payloads_unchanged_on_relocation'] = True
checkpoint_path.write_text(json.dumps(checkpoint,indent=2)+'\n')
retention_path = assets/'c3-legacy-native-baseline-retention.json'
retention = json.loads(retention_path.read_text())
retention.update(archive_repository_directory='docs/assets/ligand-designation/forensics',supplemental_forensic_index='docs/assets/ligand-designation/c3-forensics-index.json',part_payloads_unchanged_on_relocation=True)
retention_path.write_text(json.dumps(retention,indent=2)+'\n')

# All C5 snapshots here are closed before this task; no live trace/store is read.
items = {}; retained = {}
native = assets/'c4-candidate5-native'
retained['native'] = collect(items,native,'failed-candidate5/tracked/c4-candidate5-native')
for path in sorted(assets.glob('c4-candidate5-*')):
    if path.is_file(): helper['add'](items,'failed-candidate5/tracked/'+path.name,path)
for path in sorted(private.glob('issue158-c4-candidate5-*')):
    if path.is_file(): helper['add'](items,'failed-candidate5/private/'+path.name,path)
for name in ['issue158-entry-locator-before1','issue158-selection-locator-before1','issue158-locator-combined-after1']:
    retained[name] = collect(items,private/name,'focused/'+name)
for name in ['issue158-entry-locator-run.py','issue158-selection-locator-run.py','issue158-locator-combined-run.py']:
    helper['add'](items,'focused/'+name,private/name)
for name in ['neistra158-c4-candidate5','neistra158-entry-locator-before1','neistra158-selection-locator-before1','neistra158-locator-combined-after1']:
    retained[name] = collect(items,Path('/tmp')/name,'retained-workspaces/'+name)
canonical = {name:helper['fingerprint'](member) for name,member in sorted(items.items())}
dump(private/'forensics/c4-candidate5-input-inventory.json',dict(files=canonical,retained=retained))
parts = []; current = {}; used = 0; budget = 76*1024*1024
for number,(name,member) in enumerate(sorted(items.items()),1):
    estimate = helper['compressed_size'](member)
    assert estimate < budget,name
    if current and used+estimate > budget:
        parts.append(current);current={};used=0
    current[name]=member;used+=estimate
    if number % 5000 == 0: print('SIZED',number,flush=True)
if current:parts.append(current)
packets = []
for number,part in enumerate(parts,1):
    target = private/'forensics'/('c3-candidate5-native-failure-part%02d.zip'%number)
    packet = helper['archive'](part,target)
    assert packet['bytes'] < index['part_max_bytes_exclusive']
    packets.append(packet)
    print('PACKED',number,len(part),packet['bytes'],flush=True)
dump(private/'forensics/c4-candidate5-parts.json',dict(archives=packets,files=len(canonical),raw_bytes=sum(v['bytes'] for v in canonical.values()),retained=retained))
register('c4-candidate5',packets,canonical)
index['asset_count']=len(uploads)
index['total_asset_bytes']=sum(row['bytes'] for row in uploads)
dump(assets/'c3-forensics-index.json',index)
dump(private/'release-v0.36.0/forensic-upload-plan.json',dict(scope='Private paths only; immutable tracked index is the publication authority',index='docs/assets/ligand-designation/c3-forensics-index.json',index_sha256=sha((assets/'c3-forensics-index.json').read_bytes()),assets=uploads))
# Filewise source before/after hashes prove relocation, after all part bodies have
# been recursively checked and their disjoint union compared with the inventory.
native_before = {p.relative_to(native).as_posix():helper['fingerprint'](p) for p in sorted(native.rglob('*')) if p.is_file()}
destination = private/'issue158-c4-candidate5-native-retained'
assert not destination.exists()
native.rename(destination)
native_after = {p.relative_to(destination).as_posix():helper['fingerprint'](p) for p in sorted(destination.rglob('*')) if p.is_file()}
assert native_before == native_after
dump(private/'forensics/c4-candidate5-native-relocation.json',dict(scope='Lossless relocation after exact inventory/recursive part verification',original=str(native),retained=str(destination),files=len(native_before),bytes=sum(v['bytes'] for v in native_before.values()),manifest_sha256=sha(json.dumps(native_before,sort_keys=True).encode()),all_original_and_retained_hashes_verified=True,payloads_deleted=False,qualification_complete=False,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print('ALL_REGISTERED',len(uploads),index['total_asset_bytes'],flush=True)
