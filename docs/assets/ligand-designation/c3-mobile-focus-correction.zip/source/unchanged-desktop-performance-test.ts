test("keeps representative-project interactions responsive and projection-scoped", async ({
  page,
  request,
}, testInfo) => {
  test.skip(testInfo.project.name !== "chromium", "Performance budgets use desktop Chromium.");
  test.setTimeout(120_000);
  await page.addInitScript(() => {
    const durations: number[] = [];
    Object.defineProperty(window, "__molweaveLongTasks", {
      configurable: true,
      value: durations,
    });
    new PerformanceObserver((entries) => {
      durations.push(...entries.getEntries().map((entry) => entry.duration));
    }).observe({ type: "longtask", buffered: true });
  });
  await createAndOpenProject(page, request, testInfo);

  const importStarted = Date.now();
  await page.getByRole("button", { name: "Import structures" }).first().click();
  const dialog = page.getByRole("dialog", { name: "Import structures" });
  await dialog
    .locator('input[type="file"]')
    .setInputFiles(resolve("tests/fixtures/complex/1stp.pdb"));
  await dialog.getByRole("button", { name: "Import", exact: true }).click();
  await expect(dialog).toBeHidden({ timeout: 30_000 });
  await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded", {
    timeout: 45_000,
  });
  const importAndViewerMs = Date.now() - importStarted;
  performanceBudget(importAndViewerMs, 30_000, "importAndViewerMs");

  await page.evaluate(() => {
    (window as Window & { __molweaveLongTasks: number[] }).__molweaveLongTasks.length = 0;
  });
  const structureRequests: string[] = [];
  page.on("request", (outgoing) => {
    if (/\/entries\/[^/]+\/structure$/.test(new URL(outgoing.url()).pathname)) {
      structureRequests.push(outgoing.url());
    }
  });

  const interactionStarted = Date.now();
  await page.locator(".entry-select").click();
  await page.getByRole("button", { name: "Open viewer controls" }).click();
  const navigation = page.getByLabel("Viewer navigation");
  await navigation.getByRole("button", { name: "Zoom in" }).click();
  await navigation.getByRole("button", { name: "Zoom out" }).click();
  await page.getByRole("button", { name: "Close viewer controls" }).click();
  await page.getByRole("button", { name: "Fit all visible" }).click();
  await page.getByRole("button", { name: "Open viewer controls" }).click();
  await page.getByLabel(/Representation style for/).selectOption("line");
  await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded");
  await page.waitForTimeout(750);
  const interactionMs = Date.now() - interactionStarted;
  performanceBudget(interactionMs, 5_000, "interactionMs");
  expect(structureRequests).toEqual([]);

  const longTasks = await page.evaluate(
    () => (window as Window & { __molweaveLongTasks: number[] }).__molweaveLongTasks,
  );
  const maxInteractionLongTaskMs = Math.max(0, ...longTasks);
  performanceBudget(maxInteractionLongTaskMs, 750, "maxInteractionLongTaskMs");
  await testInfo.attach("performance-profile.json", {
    body: JSON.stringify(
      {
        fixture: "RCSB PDB 1STP",
        atoms: 1001,
        importAndViewerMs,
        interactionMs,
        maxInteractionLongTaskMs,
        repeatedStructureRequests: structureRequests.length,
      },
      null,
      2,
    ),
    contentType: "application/json",
  });
});
