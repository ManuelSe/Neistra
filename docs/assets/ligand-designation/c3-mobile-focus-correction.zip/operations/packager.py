"""Closed native focus correction evidence only; no app or release qualification changes."""
from pathlib import Path
import datetime,difflib,hashlib,json,runpy,subprocess,zipfile
root=Path.cwd();p=root/'.issue-11-evidence';out=p/'issue158-mobile-focus-packet';a=root/'docs/assets/ligand-designation';h=runpy.run_path(str(a/'release-evidence.py.txt'));q=runpy.run_path(str(a/'qualification.py.txt'));sha=lambda b:hashlib.sha256(b).hexdigest()
before=q['current_identities'](root);digest=sha(json.dumps(before,sort_keys=True).encode());assert len(before)==1005 and digest=='f014f32d0671a3a229dae723a79d6935fec1231cb38d06bf03113dd6b50a630d'
gate=json.loads((a/'c4-candidate9-gate.json').read_text());assert gate['commit']=='f024e5e208988227181630f6c60331e81c3b2b0e' and gate['complete'] is False and gate['source_before']==gate['source_after']
path='tests/e2e/release-hardening.spec.ts';delta=[n for n,v in before.items() if gate['source_before'].get(n)!=v];assert set(before)==set(gate['source_before']) and delta==[path]
diagnosis=p/'issue158-c9-mobile-focus-diagnosis';native=p/'issue158-mobile-focus-after1';store=Path('/tmp/neistra158-mobile-focus-after1');receipt=json.loads((native/'receipt.json').read_text());actual=json.loads((native/'actual-enclosing.json').read_text());report=json.loads((native/'browser.json').read_text())
assert actual['actual_session']==91833 and actual['actual_exit']==0 and actual['receipt_sha256']=='dd244747dc2995f5a8fc41e7a920adc5caa06de27ed5048307cf10594fec3c0a'==h['fingerprint'](native/'receipt.json')['sha256']
assert actual['browser_sha256']=='e1aec2470a3c2057f993841943fdb323e8c85d3be368e710eb8613f452eb4c49'==h['fingerprint'](native/'browser.json')['sha256']
assert receipt['exit_code']==0 and receipt['source_unchanged'] and receipt['source_before']==receipt['source_after']==before
assert receipt['old_reader_unchanged'] and receipt['old_reader_before']==receipt['old_reader_after']==gate['preceding_source_before'] and len(receipt['old_reader_before'])==931
assert q['tagged_identities']('v0.35.0')==receipt['old_reader_before'] and q['extracted_identities'](Path(gate['preceding_reader']['root']),receipt['old_reader_before'])==receipt['old_reader_before']
assert h['fingerprint'](native/'raw.log')['sha256']==receipt['log_sha256'];stats=report['stats'];assert (stats['expected'],stats['unexpected'],stats['skipped'],stats['flaky'])==(5,0,1,0) and not report['errors']
result_counts={'passed':0,'skipped':0,'retries':0}
def inspect(suites):
 for suite in suites:
  for spec in suite.get('specs',[]):
   for test in spec.get('tests',[]):
    assert test['status'] in {'expected','skipped'}
    for r in test.get('results',[]):
     assert r['retry']==0 and r['status'] in {'passed','skipped'};result_counts[r['status']]+=1
  inspect(suite.get('suites',[]))
inspect(report['suites']);assert result_counts=={'passed':5,'skipped':1,'retries':0}
oldtest=(diagnosis/'before-release-hardening.spec.ts').read_bytes();newtest=(root/path).read_bytes();correction=json.loads((diagnosis/'test-correction.json').read_text());assert sha(oldtest)==gate['source_before'][path]==correction['before_sha256'] and sha(newtest)==before[path]==correction['after_sha256']
assert subprocess.check_output(['git','show',gate['commit']+':'+path])==oldtest
addition=b'''    const entryChoice = drawer.getByRole("region", { name: "Ligand of interest", exact: true })
      .getByRole("combobox", { name: "Entry", exact: true });
    await expect(entryChoice).toBeEnabled();
    await expect(entryChoice).toBeFocused();
    await expect(entryChoice).toHaveValue("");
    await page.keyboard.press("Tab");
'''
assert newtest.count(addition)==1 and newtest.replace(addition,b'',1)==oldtest
marker=b'test("keeps representative-project interactions responsive and projection-scoped",';assert oldtest.count(marker)==newtest.count(marker)==1
oldperf=oldtest[oldtest.index(marker):];newperf=newtest[newtest.index(marker):];assert oldperf==newperf
policy=(diagnosis/'unchanged-mobile-focus-policy.txt').read_bytes();assert policy and sha(policy)=='e6a7da4ae236a585bdbeace0c91d99b00e86366d030910a7ea3441eeb7029fd2'
app='apps/web/src/App.tsx';app_versions={'current':(root/app).read_bytes(),'failed-C9':subprocess.check_output(['git','show',gate['commit']+':'+app]),'preceding-delivery-base':subprocess.check_output(['git','show','b038e4e6cdb30cf4a296ca4dcd218a7ab5ced881:'+app]),'actual-v0.35.0':subprocess.check_output(['git','show',gate['preceding_reader']['commit']+':'+app])}
assert all(body.count(policy)==1 for body in app_versions.values()) and sha(app_versions['current'])==before[app]==gate['source_before'][app]
index_path=a/'c3-forensics-index.json';index=json.loads(index_path.read_text());assert index['asset_count']==50 and h['fingerprint'](index_path)['sha256']=='c5777a87ba18f088ac56f22f75b68862a2f7ed916a0870237c5b2fcf1a6ac063'
v5=json.loads((a/'c3-forensics-verification5.json').read_text());assert v5['index_sha256']==h['fingerprint'](index_path)['sha256'] and v5['local_all_parts_verified']==50
items={};retention={};originals={}
def collect(directory,prefix):
 rows={}
 for f in sorted(directory.rglob('*')):
  assert not f.is_symlink(),f
  if f.is_file():
   n=prefix+'/'+f.relative_to(directory).as_posix();h['add'](items,n,f,reader_workspace=True);rows[n]=h['fingerprint'](f);originals[n]=dict(path=str(f),**rows[n])
 retention[str(directory)]=dict(files=len(rows),bytes=sum(v['bytes'] for v in rows.values()),exact_all_regular_files=True,links=0)
collect(native,'focused-output');collect(store,'owned-store');collect(diagnosis,'failed-C9-diagnosis')
h['add'](items,'operations/issue158-mobile-focus-run.py',p/'issue158-mobile-focus-run.py');h['add'](items,'operations/packager.py',Path(__file__))
h['add'](items,'source/after-release-hardening.spec.ts',newtest);h['add'](items,'source/before-release-hardening.spec.ts',oldtest);h['add'](items,'source/unchanged-desktop-performance-test.ts',oldperf)
for version,body in app_versions.items():h['add'](items,'source/'+version+'/App.tsx',body)
h['add'](items,'source/native-test.diff',''.join(difflib.unified_diff(oldtest.decode().splitlines(True),newtest.decode().splitlines(True),fromfile='failed-C9/release-hardening.spec.ts',tofile='corrected/release-hardening.spec.ts')).encode())
proof=dict(scope='Focused correction source relation to failedC9; no pooled gate qualification',historical_candidate=gate['commit'],historical_source_count=1005,historical_source_digest=sha(json.dumps(gate['source_before'],sort_keys=True).encode()),historical_source_identities=gate['source_before'],current_count=1005,current_digest=digest,current_before=before,current_after=q['current_identities'](root),only_changed_selected_source=delta,preceding_reader_sources=receipt['old_reader_before'],preceding_reader_count=931,preceding_reader_fixed=True,exact_inserted_six_lines_only=True,complete_desktop_performance_body_byte_identical=True,desktop_performance_body_sha256=sha(oldperf),app_policy_sha256=sha(policy),app_policy_byte_identical_in_all_four_versions=True,app_version_sha256={n:sha(b) for n,b in app_versions.items()},captured_originals=originals)
assert proof['current_before']==proof['current_after'];h['add'](items,'source-proof.json',h['encoded'](proof));h['add'](items,'raw-retention.json',h['encoded'](retention))
references=dict(scope='Metadata references only; no raw forensic parts or prior verification ZIP payloads embedded',index=dict(path=index_path.relative_to(root).as_posix(),**h['fingerprint'](index_path)),asset_count=50,total_asset_bytes=index['total_asset_bytes'],verification5_json=dict(path='docs/assets/ligand-designation/c3-forensics-verification5.json',**h['fingerprint'](a/'c3-forensics-verification5.json')),verification5_zip=dict(path='docs/assets/ligand-designation/c3-forensics-verification5.zip',**h['fingerprint'](a/'c3-forensics-verification5.zip')),C9_remains_failed=True,focused_and_full_gates_are_separate=True)
h['add'](items,'forensic-references.json',h['encoded'](references))
facts=dict(scope='Closed focused mobile initial-focus native assertion correction only; no application focus-policy change, final performance claim or complete42step qualification',repository='ManuelSe/Neistra',issue=158,parent=11,source_count=1005,source_digest=digest,old_reader_sources=931,only_selected_change=path,before_test_sha256=sha(oldtest),after_test_sha256=sha(newtest),actual_focused_enclosing=actual,passed=5,failed=0,flaky=0,retries=0,unchanged_historical_mobile_performance_exclusions=1,preserved_assertions='Added exact Entry enabled/focused/empty and trusted Tab to Selection. Exact six-line insertion removes no original assertion; project/export focus, selectedtab/ArrowRight/Inspect, Escape/drawer/launcher/tooltip, clipping/viewport/Axe and the complete desktop performance test body are unchanged.',unchanged_app_policy=proof['app_version_sha256'],app_focus_block_sha256=sha(policy),source_maps_stable=True,all_owned_outputs_and_store_retained=retention,forensic_references=references,limitations='C9 remains failed with438PASS1FAIL56encountered historical exclusions107notrun and no summary/package. Focused5PASS1historical exclusion is not combined with C9 or a future gate. Allsevenfinal samecandidate, fresh complete candidate42step and actualmaster42step qualification, protectedmerge and publication remain pending.',required_next=['Root independently verify C10recipe fresh resources and commit coherent local correction checkpoint','Run complete fresh C10gate/summary/package with observed enclosing exit0','Obtain allsevenfinalsamecandidate assessments/protectedmerge and fresh exactactualmaster qualification','Regenerate final primary publication inventory after actualM and verify every publicasset before closeout'])
h['add'](items,'checkpoint-context.json',h['encoded'](facts));assert sum(h['compressed_size'](v) for v in items.values())<76*1024*1024
archive=h['archive'](items,a/'c3-mobile-focus-correction.zip');assert archive['bytes']<80*1024*1024
assert q['current_identities'](root)==before and q['tagged_identities']('v0.35.0')==receipt['old_reader_before'] and all(h['fingerprint'](Path(v['path']))=={k:v[k] for k in ['bytes','sha256']} for v in originals.values())
record=dict(**facts,archive=archive['file'],archive_bytes=archive['bytes'],archive_sha256=archive['sha256'],outer_manifest_entries=archive['outer_manifest_entries'],recursive_verification=archive['verification_counts'],observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());target=a/'c3-mobile-focus-checkpoint.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n');(out/'packager-result.json').write_text(json.dumps(dict(archive=archive,checkpoint=h['fingerprint'](target),all1005sources_and_old931_stable=True,raw_retention=retention),indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
