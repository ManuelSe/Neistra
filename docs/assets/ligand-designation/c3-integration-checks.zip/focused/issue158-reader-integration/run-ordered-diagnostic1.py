import datetime, hashlib, json, os, runpy, subprocess, sys, time
from pathlib import Path
root=Path.cwd(); old=Path('/tmp/neistra158-reader-0350'); out=root/'.issue-11-evidence/issue158-reader-integration/ordered-diagnostic1'; run=Path('/tmp/neistra158-ordered-integration1')
assert not out.exists() and not run.exists(), 'Preserve prior attempts'
out.mkdir();run.mkdir(); wrapper=root/'tests/support/measurement_reader_qualification.py'; python=root/'.venv/bin/python'
helpers=runpy.run_path(str(root/'docs/assets/ligand-designation/qualification.py.txt')); before=helpers['current_identities'](root); old_before=helpers['extracted_identities'](old,helpers['tagged_identities']('v0.35.0')); assert len(old_before)==931
state={'scope':'Seven fresh ordered-measurement reader commands only; not full release qualification','current_version':'0.36.0','previous_version':'0.35.0','previous_commit':'7542d1a19e80afe166d965c6321cda60839e4e5b','source_before':before,'preceding_source_before':old_before,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'complete':False}
def save(): (out/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
def env(implementation,data):
 result={k:v for k,v in os.environ.items() if k not in {'NEISTRA_DATA_DIR','NEISTRA_DATABASE_URL','MOLWEAVE_DATA_DIR','MOLWEAVE_DATABASE_URL','DATABASE_URL'}}
 result.update(PYTHONPATH=':'.join(str(implementation/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src','.']), NEISTRA_DATA_DIR=str(data), NEISTRA_DATABASE_URL=f'sqlite:///{data}/molweave.db', MOLWEAVE_DATA_DIR=str(data), MOLWEAVE_DATABASE_URL=f'sqlite:///{data}/molweave.db', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
 return result
def execute(label,command,implementation,data):
 started=time.monotonic();log=out/(label+'.log');print('Starting '+label,flush=True)
 with log.open('wb') as handle:r=subprocess.run([str(x) for x in command],cwd=implementation,env=env(implementation,data),stdout=handle,stderr=subprocess.STDOUT)
 state['steps'].append({'label':label,'command':[str(x) for x in command],'cwd':str(implementation),'data_dir':str(data),'exit_code':r.returncode,'seconds':time.monotonic()-started,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});save();assert r.returncode==0,(label,r.returncode,str(log));print('Completed '+label,flush=True)
def command(mode,implementation,data,label):
 return [python,'-B',wrapper,mode,'--data-dir',data,'--implementation-root',implementation,'--expected-version','0.36.0' if implementation==root else '0.35.0','--evidence',out/(label+'.json'),'--expect-ordered-measurements']
current=run/'measurements-current';previous=run/'measurements-previous';refused=run/'measurements-refusal'
save()
try:
 execute('current-migration',[python,'-m','alembic','upgrade','head'],root,current)
 execute('current-produce',command('produce',root,current,'current-produce'),root,current)
 prepare="import pathlib,shutil,subprocess,sys; source,copied=map(pathlib.Path,sys.argv[1:3]); assert source.is_dir() and not copied.exists(); shutil.copytree(source,copied); subprocess.run([sys.executable,'-m','alembic','upgrade','head'],check=True)"
 execute('previous-migration-and-copy',[python,'-c',prepare,current,refused],old,previous)
 execute('previous-refuse-current',[*command('refuse',old,previous,'previous-refuse-current'),'--refusal-data',refused,'--archives-dir',current],old,previous)
 execute('previous-produce',command('produce',old,previous,'previous-produce'),old,previous)
 execute('current-read-previous',[*command('read',root,previous,'current-read-previous'),'--schema-boundary'],root,previous)
 execute('current-reopen',command('read',root,current,'current-reopen'),root,current)
 state['complete']=True
finally:
 state['source_after']=helpers['current_identities'](root);state['source_unchanged']=state['source_before']==state['source_after'];state['preceding_source_after']=helpers['extracted_identities'](old,old_before);state['preceding_source_unchanged']=old_before==state['preceding_source_after'];state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
assert state['preceding_source_unchanged']
print(json.dumps({'complete':state['complete'],'steps':len(state['steps']),'current_source_unchanged':state['source_unchanged'],'preceding931unchanged':state['preceding_source_unchanged'],'receipt':str(out/'receipt.json')},indent=2))
