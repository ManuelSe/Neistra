from __future__ import annotations
import itertools
from pathlib import Path
from rdkit import Chem
from neistra_core.adapters.rdkit_common import mol_to_normalized
from neistra_core.adapters.macromolecular import MmcifAdapter, PdbAdapter
from neistra_core.adapters.base import ImportOptions

def make_case(root: Path, case: str, *, normalize: bool = True):
    name, text_n=case.split(':'); n=int(text_n)
    if name=='source':
        mapping='data_occurrences\nloop_\n_entity.id\n_entity.type\n1 non-polymer\nloop_\n_struct_asym.id\n_struct_asym.entity_id\n'+''.join(f'X{i} 1\n' for i in range(n))
        fields=['group_PDB','id','type_symbol','label_atom_id','label_alt_id','label_comp_id','label_asym_id','label_entity_id','label_seq_id','Cartn_x','Cartn_y','Cartn_z','occupancy','B_iso_or_equiv','auth_seq_id','auth_asym_id','auth_atom_id','auth_comp_id','pdbx_PDB_ins_code','pdbx_PDB_model_num']
        header='loop_\n'+''.join('_atom_site.'+x+'\n' for x in fields)
        rows=''.join(f'HETATM {2*i+1} C C1 . LIG X{i} 1 . {3*i} 0 0 1 10 1 X{i} C1 LIG ? 1\nHETATM {2*i+2} O O1 . LIG X{i} 1 . {3*i+1} 0 0 1 10 1 X{i} O1 LIG ? 1\n' for i in range(n))
        original=(mapping+header+rows).encode()
        if not normalize:return None,original,'source-counts.cif'
        return MmcifAdapter().parse(original,'source-counts.cif',ImportOptions(generate_3d=False)).structures[0],original,'source-counts.cif'
    if name in {'repeat','varied','larger','mixed','atomcap'}:
        if name=='repeat': pieces=['CCO']*n
        elif name=='atomcap': pieces=['C'*50]*n
        elif name=='mixed': pieces=['CCO.O.[Na+]']*n
        elif name=='larger':
            mol=Chem.MolFromMolFile(str(root/'tests/fixtures/minimization/1stp-biotin-prepared.mol'),removeHs=False)
            pieces=[Chem.MolToSmiles(mol,isomericSmiles=True,allHsExplicit=True)]*n
        else:
            unique=set()
            for sequence in itertools.product('CNOS',repeat=6):
                mol=Chem.MolFromSmiles(''.join(sequence))
                if mol is not None: unique.add(Chem.MolToSmiles(mol))
                if len(unique)>=n: break
            assert len(unique)==n; pieces=sorted(unique)
        text='.'.join(pieces); original=(text+' synthetic\n').encode()
        if not normalize:return None,original,'synthetic.smi'
        mol=Chem.MolFromSmiles(text);assert mol is not None
        return mol_to_normalized(mol,filename='synthetic.smi',format_name='smiles'), original, 'synthetic.smi'
    path=root/('tests/fixtures/complex/1stp.pdb' if name=='complex' else 'tests/fixtures/surfaces/1aon.cif')
    original=path.read_bytes()
    if not normalize:return None,original,path.name
    adapter=PdbAdapter() if name=='complex' else MmcifAdapter()
    return adapter.parse(original,path.name,ImportOptions(generate_3d=False)).structures[0],original,path.name
