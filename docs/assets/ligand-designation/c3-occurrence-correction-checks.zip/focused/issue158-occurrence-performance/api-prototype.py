from __future__ import annotations
import collections, dataclasses, gc, hashlib, json, os, platform, resource, subprocess, sys, tempfile, time, tracemalloc
from pathlib import Path
sys.path[:0]=[str(Path.cwd()/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src','.']]
from workloads import make_case
ROOT=Path.cwd();OUT=ROOT/'.issue-11-evidence/issue158-occurrence-performance'

def source_hashes():
    paths=[ROOT/p for p in ['apps/api/src/neistra_api/ligand_service.py', 'apps/api/src/neistra_api/ligand_occurrence_cache.py', 'apps/api/src/molweave_api/ligand_occurrence_cache.py', 'packages/neistra_core/src/neistra_core/ligands/models.py', 'packages/neistra_core/src/neistra_core/ligands/occurrences.py', 'packages/neistra_core/src/neistra_core/ligands/candidates.py', 'packages/neistra_core/src/neistra_core/ligands/chemistry.py', 'packages/neistra_core/src/neistra_core/ligands/source_evidence.py']]
    paths+=list((ROOT/'apps/api/src/neistra_api').glob('*occurrence*.py'))
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}
def rss():return int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024

def cache_snapshot(module):
    # Final cache seam is supplied by the integrating author. Record only
    # deliberately exposed stats; never retain a native scientific context.
    for name in ('_OCCURRENCE_CACHE','OCCURRENCE_CACHE'):
        cache=getattr(module,name,None)
        if cache is not None:
            stats=getattr(cache,'snapshot',None)
            if callable(stats):
                value=stats();report=dataclasses.asdict(value) if dataclasses.is_dataclass(value) else dict(value)
                seen=set();objects=0;native=0
                from collections.abc import Mapping
                from types import MappingProxyType
                def size(item):
                    nonlocal objects,native
                    identity=id(item)
                    if identity in seen:return 0
                    seen.add(identity);objects+=1;total=sys.getsizeof(item)
                    if type(item).__module__.startswith('rdkit'):
                        native+=1;return total
                    if isinstance(item,MappingProxyType):
                        return total+sum(size(x) for x in gc.get_referents(item))
                    if dataclasses.is_dataclass(item):
                        if hasattr(item,'__dict__'):return total+size(vars(item))
                        return total+sum(size(getattr(item,f.name)) for f in dataclasses.fields(item))
                    if isinstance(item,Mapping):return total+sum(size(k)+size(v) for k,v in item.items())
                    if isinstance(item,(tuple,list,set,frozenset)):return total+sum(size(x) for x in item)
                    return total
                with cache._lock: report['retained_summary_python_bytes']=size(cache._entries)
                report['retained_summary_object_count']=objects;report['retained_native_molecules']=native
                assert native==0
                return report
    return None

def child(case):
    from neistra_api.main import create_app
    from neistra_api.database import Base
    from neistra_api.settings import Settings
    from neistra_api.models import Artifact
    from tests.support.api_client import ApiClient
    import neistra_api.ligand_service as service
    import neistra_core.ligands.chemistry as chemistry
    import neistra_core.ligands.occurrences as occurrences
    from sqlalchemy import select
    from rdkit import rdBase
    before_sources=source_hashes();structure,original,filename=make_case(ROOT,case,normalize=False)
    # Use actual parsing/command/publication, with 3D generation explicitly off.
    directory=Path(tempfile.mkdtemp(prefix='neistra158-occurrence-api-',dir='/tmp'))
    settings=Settings(data_dir=directory,database_url=f'sqlite:///{directory}/test.db',auto_create_schema=True,enable_test_routes=True)
    app=create_app(settings);Base.metadata.create_all(app.state.engine);client=ApiClient(app)
    created=client.post('/api/v1/projects',json={'name':'Occurrence performance fixture'});assert created.status_code==201,created.text;project=created.json()
    imported=client.post(f"/api/v1/projects/{project['id']}/imports",data={'expected_revision':project['revision'],'generate_3d':'false'},files=[('files',(filename,original,'application/octet-stream'))]);assert imported.status_code==201,imported.text
    before=client.get(f"/api/v1/projects/{project['id']}").json();entry=before['entries'][0];endpoint=f"/api/v1/projects/{project['id']}/entries/{entry['id']}/ligand-candidates"
    def artifact_snapshot():
        with app.state.session_factory() as session: rows=[tuple(row) for row in session.execute(select(Artifact.id,Artifact.sha256,Artifact.size).order_by(Artifact.id)).all()]
        return {'rows':rows,'files':{str(p.relative_to(directory)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (directory/'artifacts').rglob('*') if p.is_file()}}
    artifacts_before=artifact_snapshot();counts=collections.Counter();real_init=chemistry.PreparedLigandChemistry.__init__;real_original=chemistry._original_molecules;real_qualify=chemistry._qualify_prepared;real_key=occurrences.qualified_representation_key;real_build=occurrences.build_occurrence_index
    def init(self,*args,**kwargs):counts['prepare']+=1;real_init(self,*args,**kwargs)
    def original_iter(*args,**kwargs):counts['original_parse']+=1;yield from real_original(*args,**kwargs)
    def qualify(*args,**kwargs):counts['qualify']+=1;return real_qualify(*args,**kwargs)
    def key(*args,**kwargs):counts['signature']+=1;return real_key(*args,**kwargs)
    def build(*args,**kwargs):counts['index_build']+=1;return real_build(*args,**kwargs)
    chemistry.PreparedLigandChemistry.__init__=init;chemistry._original_molecules=original_iter;chemistry._qualify_prepared=qualify;occurrences.qualified_representation_key=key
    for module in list(sys.modules.values()):
        if module is not None and getattr(module,'__name__','').startswith(('neistra_api.','neistra_core.ligands.')) and getattr(module,'build_occurrence_index',None) is real_build:setattr(module,'build_occurrence_index',build)
    samples=[];start_rss=rss()
    for label,offset in [('cold_page0',0),('warm_page12',12),('warm_page0',0)]:
        counts.clear();started=time.perf_counter();reply=client.get(endpoint,params={'expected_artifact_id':entry['current_artifact_id'],'offset':offset,'limit':12});elapsed=time.perf_counter()-started;assert reply.status_code==200,reply.text;body=reply.json()
        samples.append({'label':label,'seconds':elapsed,'work':dict(counts),'offset':offset,'total_candidates':body['total'],'candidates':[{'key':x['candidate_key'],'count':x.get('occurrence_count'),'basis':x.get('occurrence_basis'),'reason':x.get('occurrence_reason')} for x in body['candidates']],'cache_stats':cache_snapshot(service)})
    retained=peak_py=None;gc.collect()
    after=client.get(f"/api/v1/projects/{project['id']}").json();assert before==after;assert artifacts_before==artifact_snapshot();assert source_hashes()==before_sources
    result={'case':case,'actual_entry_atoms':entry['atom_count'],'source_fixture_atoms':None,'samples':samples,'project_history_original_and_normalized_artifacts_unchanged':True,'source_files_unchanged':True,'source_files':before_sources,'retained_store':str(directory),'resident_before_bytes':start_rss,'resident_after_bytes':rss(),'process_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'traced_python_current_bytes':retained,'traced_python_peak_bytes':peak_py,'tracemalloc_enabled':False,'rdkit_version':rdBase.rdkitVersion}
    app.state.engine.dispose();print(json.dumps(result))

def main():
    if len(sys.argv)>1:child(sys.argv[1]);return
    result=OUT/'api-prototype-results.json';assert not result.exists();state={'scope':'Actual ASGI candidate metadata cold/warm count index; isolated synthetic stores, no3Dgeneration; diagnostictracemalloc instrumentation','source_before':source_hashes(),'samples':[],'complete':False,'load_before':Path('/proc/loadavg').read_text().strip()}
    env=os.environ.copy();env.update(PYTHONPATH=':'.join(str(ROOT/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src','.']),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    for case in ['repeat:25','repeat:1000','varied:1000','larger:100','mixed:25','largecomplex:1']:
        for repeat in range(3):
            p=subprocess.run([sys.executable,str(Path(__file__).resolve()),case],capture_output=True,env=env,timeout=240);(OUT/f'api-prototype-{case.replace(":","-")}-{repeat+1}.stderr.log').write_bytes(p.stderr)
            if p.returncode:
                state['failed']={'case':case,'repeat':repeat+1,'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')};result.write_text(json.dumps(state,indent=2)+'\n');raise SystemExit(p.returncode)
            row=json.loads(p.stdout);row['repeat']=repeat+1;state['samples'].append(row);result.write_text(json.dumps(state,indent=2)+'\n');print(case,repeat+1,[(x['label'],round(x['seconds'],4),x['work']) for x in row['samples']],flush=True)
    state['source_after']=source_hashes();assert state['source_before']==state['source_after'];state['load_after']=Path('/proc/loadavg').read_text().strip();state['complete']=True;result.write_text(json.dumps(state,indent=2)+'\n');print('COMPLETE',result)
if __name__=='__main__':main()
