from __future__ import annotations
import dataclasses, gc, hashlib, json, resource, sys, time
from collections.abc import Mapping
from pathlib import Path
sys.path[:0]=[str(Path.cwd()/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src','.']]
from threading import BoundedSemaphore
from types import MappingProxyType
from neistra_api.ligand_occurrence_cache import OccurrenceCacheKey, OccurrenceSummaryCache
from neistra_core.ligands.occurrences import OCCURRENCE_POLICY, OccurrenceCount, OccurrenceIndex
from rdkit import rdBase
ROOT=Path.cwd();OUT=ROOT/'.issue-11-evidence/issue158-occurrence-performance'
def hashes():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/p for p in ['apps/api/src/neistra_api/ligand_service.py', 'apps/api/src/neistra_api/ligand_occurrence_cache.py', 'apps/api/src/molweave_api/ligand_occurrence_cache.py', 'packages/neistra_core/src/neistra_core/ligands/models.py', 'packages/neistra_core/src/neistra_core/ligands/occurrences.py', 'packages/neistra_core/src/neistra_core/ligands/candidates.py', 'packages/neistra_core/src/neistra_core/ligands/chemistry.py', 'packages/neistra_core/src/neistra_core/ligands/source_evidence.py']]}
def deep_size(value):
    seen=set();native=0;objects=0
    def size(item):
        nonlocal native,objects
        if id(item) in seen:return 0
        seen.add(id(item));objects+=1;total=sys.getsizeof(item)
        if type(item).__module__.startswith('rdkit'):native+=1;return total
        if isinstance(item,MappingProxyType):return total+sum(size(x) for x in gc.get_referents(item))
        if dataclasses.is_dataclass(item):
            if hasattr(item,'__dict__'):return total+size(vars(item))
            return total+sum(size(getattr(item,f.name)) for f in dataclasses.fields(item))
        if isinstance(item,Mapping):return total+sum(size(k)+size(v) for k,v in item.items())
        if isinstance(item,(list,tuple,set,frozenset)):return total+sum(size(x) for x in item)
        return total
    return {'python_recursive_shallow_bytes':size(value),'objects':objects,'native_molecule_objects':native}
def summary(case,n):
    values={hashlib.sha256(f'{case}:{i}'.encode()).hexdigest():OccurrenceCount(n,'qualified_representation_v1',None) for i in range(n)}
    return OccurrenceIndex(MappingProxyType(values),OccurrenceCount(None,None,'occurrence_not_applicable'),n,n*3,n,True,True)
def key(case):
    return OccurrenceCacheKey('/tmp/occurrence-retention-synthetic',hashlib.sha256(str(case).encode()).hexdigest(),'smiles',0,'ligand-instance-v3','ligand-exact-representation-v2',OCCURRENCE_POLICY,rdBase.rdkitVersion,1024,8192,1024)
def main():
    output=OUT/'cache-retention-repeat2.json';assert not output.exists();before=hashes();slots=BoundedSemaphore(2);cache=OccurrenceSummaryCache(slots);started=time.perf_counter();built=[];stats=[]
    for i in range(70):
        index=summary(i,1000);value=cache.get_or_build(key(i),frozenset(index.by_candidate),lambda index=index:index);assert value is not None;built.append(i);stats.append(dataclasses.asdict(cache.snapshot()))
    del index,value;gc.collect();retention=deep_size(cache._entries);assert retention['native_molecule_objects']==0
    assert all(x['entries']<=64 and x['encoded_bytes']<=8*1024*1024 and x['in_flight']==0 for x in stats)
    retained_ids={x.inventory for x in cache._entries};assert key(0).inventory not in retained_ids and key(69).inventory in retained_ids
    calls=0
    def unexpected():
        nonlocal calls
        calls+=1
        return summary('unexpected',1000)
    assert slots.acquire(blocking=False) and slots.acquire(blocking=False)
    cached_keys=frozenset(cache._entries[key(69)][0].by_candidate)
    assert cache.get_or_build(key(69),cached_keys,unexpected) is not None
    assert cache.get_or_build(key('miss'),frozenset(),unexpected) is None
    assert calls==0
    slots.release();slots.release()
    oversized=OccurrenceSummaryCache(BoundedSemaphore(2));index=summary('oversized',3000);returned=oversized.get_or_build(dataclasses.replace(key('oversized'),max_candidates=4096,max_atoms=16384),frozenset(index.by_candidate),lambda:index);assert returned is not None and oversized.snapshot().entries==0
    after=hashes();assert before==after
    result={'scope':'Synthetic immutable summary storage/admission measurement only; no chemical-equivalence assertion from fabricated summaries','entries_offered':70,'candidate_records_per_summary':1000,'stats_over_insertions':stats,'final_stats':dataclasses.asdict(cache.snapshot()),'retained_summary_python_objects':retention,'whole_process_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'seconds':time.perf_counter()-started,'retained_cache_hit_works_with_both_slots_busy':True,'busy_miss_builder_calls':calls,'oversized_summary_returned_but_not_retained':True,'source_before':before,'source_after':after,'source_unchanged':True,'python_size_scope':'Recursive sys.getsizeof over retained key/value objects and mapping referents; excludes allocator/OS/native effects; not a hard heap/RSS cap.'};output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='stats_over_insertions'},indent=2))
if __name__=='__main__':main()
