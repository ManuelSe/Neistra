from __future__ import annotations
import collections, hashlib, itertools, json, os, platform, resource, statistics, subprocess, sys, time
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'.issue-11-evidence/issue158-occurrence-performance'

def rss():
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith('VmRSS:'): return int(line.split()[1])*1024

def child(case):
    from rdkit import Chem, rdBase
    from neistra_core.adapters.rdkit_common import mol_to_normalized
    from neistra_core.adapters.macromolecular import MmcifAdapter, PdbAdapter
    from neistra_core.adapters.base import ImportOptions
    import neistra_core.ligands.chemistry as chemistry
    from neistra_core.ligands.candidates import resolve_candidates
    name, n = case.split(':'); n=int(n)
    started=time.perf_counter()
    if name in {'repeat','varied','larger'}:
        if name=='repeat': smiles=['CCO']*n
        elif name=='larger':
            molecule=Chem.MolFromMolFile(str(ROOT/'tests/fixtures/minimization/1stp-biotin-prepared.mol'),removeHs=False)
            item=Chem.MolToSmiles(molecule,isomericSmiles=True,allHsExplicit=True)
            smiles=[item]*n
        else:
            unique=set()
            for sequence in itertools.product('CNOS',repeat=6):
                mol=Chem.MolFromSmiles(''.join(sequence))
                if mol is not None: unique.add(Chem.MolToSmiles(mol))
                if len(unique)>=n: break
            assert len(unique)==n
            smiles=sorted(unique)
        text='.'.join(smiles); original=(text+' synthetic\n').encode()
        mol=Chem.MolFromSmiles(text); assert mol is not None
        structure=mol_to_normalized(mol,filename='synthetic.smi',format_name='smiles')
    else:
        path=ROOT/('tests/fixtures/complex/1stp.pdb' if name=='complex' else 'tests/fixtures/surfaces/1aon.cif')
        original=path.read_bytes(); adapter=PdbAdapter() if name=='complex' else MmcifAdapter()
        structure=adapter.parse(original,path.name,ImportOptions(generate_3d=False)).structures[0]
    fixture_s=time.perf_counter()-started
    source=structure.to_bytes(); source_sha=hashlib.sha256(source).hexdigest(); original_sha=hashlib.sha256(original).hexdigest()
    counters=collections.Counter(); real_originals=chemistry._original_molecules; real_qualify=chemistry._qualify_prepared
    def original_iter(*a,**kw):
        counters['original_parse']+=1
        yield from real_originals(*a,**kw)
    def qualify(*a,**kw):
        counters['qualify']+=1
        return real_qualify(*a,**kw)
    chemistry._original_molecules=original_iter; chemistry._qualify_prepared=qualify
    initial_rss=rss(); t=time.perf_counter(); inventory=resolve_candidates(structure,original_bytes=original); inventory_s=time.perf_counter()-t
    potential=[c for c in inventory.candidates if c.potential_ligand and c.boundary_status!='ineligible']
    phases=[]
    def run(label, candidates, prepared=None):
        counters.clear(); before=rss(); peak_before=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024; t=time.perf_counter()
        if prepared is None:
            prepared=chemistry.prepare_chemistry(structure,original_bytes=original); counters['prepare']=1
        statuses=collections.Counter(); reasons=collections.Counter(); signatures=[]
        for candidate in candidates:
            q=prepared.qualify(candidate.atom_ids); statuses[q.status]+=1
            if q.reason: reasons[q.reason]+=1
            # Only existing qualification cost is being measured. This is not
            # an approved chemical-equivalence index or grouping assertion.
            signatures.append((candidate.candidate_key,q.input_hash,q.status,q.reason))
        elapsed=time.perf_counter()-t
        phases.append({'label':label,'seconds':elapsed,'candidates':len(candidates),'candidate_atoms':sum(len(c.atom_ids) for c in candidates),'counters':dict(counters),'statuses':dict(statuses),'reasons':dict(reasons),'resident_before_bytes':before,'resident_after_bytes':rss(),'process_peak_before_bytes':peak_before,'process_peak_after_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'summary_json_bytes':len(json.dumps(signatures,separators=(',',':')).encode())})
        return prepared
    run('page12_cold_request',potential[:12]); prepared=run('complete_inventory_cold_request',potential);run('page12_reusing_prepared_context',potential[:12],prepared);run('next_page12_fresh_request',potential[12:24])
    assert structure.to_bytes()==source and hashlib.sha256(original).hexdigest()==original_sha
    result={'case':case,'atoms':len(structure.atoms),'all_candidates':len(inventory.candidates),'potential_candidates':len(potential),'source_bytes':len(source),'source_sha256':source_sha,'original_bytes':len(original),'original_sha256':original_sha,'fixture_generation_seconds':fixture_s,'inventory_seconds':inventory_s,'resident_before_inventory_bytes':initial_rss,'phases':phases,'rdkit_version':rdBase.rdkitVersion,'input_unchanged':True,'linux_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
    print(json.dumps(result))

def main():
    if len(sys.argv)>1: child(sys.argv[1]);return
    output=OUT/'baseline-results.json';assert not output.exists()
    metadata={'scope':'Read-only existing inventory/qualification stage measurements; no proposed equivalence-index or API latency claim','head_at_assignment':'bb46b1cf30fb0e65757fb711148e29cc54bd926b','platform':platform.platform(),'python':sys.version,'load_before':Path('/proc/loadavg').read_text().strip(),'cpu_model':next(x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),'source_files':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['apps/api/src/neistra_api/ligand_service.py','packages/neistra_core/src/neistra_core/ligands/chemistry.py','packages/neistra_core/src/neistra_core/ligands/candidates.py']},'samples':[]}
    env=os.environ.copy();env.update(PYTHONPATH=':'.join(str(ROOT/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src','.']),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    for case in ['repeat:25','repeat:100','repeat:1000','varied:1000','larger:100','complex:1','largecomplex:1']:
        for repeat in range(3):
            started=time.perf_counter();p=subprocess.run([sys.executable,str(Path(__file__).resolve()),case],capture_output=True,env=env,timeout=180)
            log=OUT/f'baseline-{case.replace(":","-")}-{repeat+1}.stderr.log';log.write_bytes(p.stderr)
            if p.returncode:
                metadata['failed']={'case':case,'repeat':repeat,'exit':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':str(log)};output.write_text(json.dumps(metadata,indent=2)+'\n');raise SystemExit(p.returncode)
            row=json.loads(p.stdout);row['repeat']=repeat+1;row['fresh_process_elapsed_seconds']=time.perf_counter()-started;metadata['samples'].append(row);output.write_text(json.dumps(metadata,indent=2)+'\n');print(case,repeat+1,'full',row['phases'][1]['seconds'],'rss',row['linux_peak_rss_bytes'],flush=True)
    metadata['load_after']=Path('/proc/loadavg').read_text().strip();metadata['complete']=True;output.write_text(json.dumps(metadata,indent=2)+'\n')
    summary=[]
    for case in sorted({x['case'] for x in metadata['samples']}):
        rows=[x for x in metadata['samples'] if x['case']==case];summary.append({'case':case,'atoms':rows[0]['atoms'],'potential':rows[0]['potential_candidates'],'inventory_s':[x['inventory_seconds'] for x in rows],'page12_s':[x['phases'][0]['seconds'] for x in rows],'full_s':[x['phases'][1]['seconds'] for x in rows],'peak_mib':[x['linux_peak_rss_bytes']/1024/1024 for x in rows],'summary_bytes':rows[0]['phases'][1]['summary_json_bytes'],'statuses':rows[0]['phases'][1]['statuses'],'work_counts':rows[0]['phases'][1]['counters']})
    (OUT/'baseline-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
