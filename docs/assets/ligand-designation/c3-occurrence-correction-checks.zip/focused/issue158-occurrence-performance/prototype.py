from __future__ import annotations
import collections, dataclasses, hashlib, json, os, platform, resource, subprocess, sys, time
from pathlib import Path
sys.path[:0]=[str(Path.cwd()/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src','.']]
from workloads import make_case
ROOT=Path.cwd();OUT=ROOT/'.issue-11-evidence/issue158-occurrence-performance'
FILES=['apps/api/src/neistra_api/ligand_service.py', 'apps/api/src/neistra_api/ligand_occurrence_cache.py', 'apps/api/src/molweave_api/ligand_occurrence_cache.py', 'packages/neistra_core/src/neistra_core/ligands/models.py', 'packages/neistra_core/src/neistra_core/ligands/occurrences.py', 'packages/neistra_core/src/neistra_core/ligands/candidates.py', 'packages/neistra_core/src/neistra_core/ligands/chemistry.py', 'packages/neistra_core/src/neistra_core/ligands/source_evidence.py']
def hashes(): return {f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in FILES}
def rss():
    return int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024

def child(case):
    import neistra_core.ligands.chemistry as chemistry
    import neistra_core.ligands.candidates as candidates
    import neistra_core.ligands.occurrences as occurrences
    from neistra_core.ligands.source_evidence import assess_mmcif_source
    from rdkit import rdBase
    before_sources=hashes();started=time.perf_counter();structure,original,_=make_case(ROOT,case);fixture_s=time.perf_counter()-started
    source=structure.to_bytes();original_hash=hashlib.sha256(original).hexdigest();counts=collections.Counter()
    real_init=chemistry.PreparedLigandChemistry.__init__;real_original=chemistry._original_molecules;real_qualify=chemistry._qualify_prepared;real_key=occurrences.qualified_representation_key
    def init(self,*args,**kwargs): counts['prepare']+=1;real_init(self,*args,**kwargs)
    def originals(*args,**kwargs): counts['original_parse']+=1;yield from real_original(*args,**kwargs)
    def qualify(*args,**kwargs): counts['qualify']+=1;return real_qualify(*args,**kwargs)
    def key(*args,**kwargs): counts['signature']+=1;return real_key(*args,**kwargs)
    chemistry.PreparedLigandChemistry.__init__=init;chemistry._original_molecules=originals;chemistry._qualify_prepared=qualify;occurrences.qualified_representation_key=key
    start_rss=rss();started=time.perf_counter();source_inventory=assess_mmcif_source(structure,original);source_s=time.perf_counter()-started
    started=time.perf_counter();prepared=chemistry.prepare_chemistry(structure,original_bytes=original);inventory=candidates.resolve_candidates(structure,original_bytes=original,source_inventory=source_inventory,prepared_chemistry=prepared);inventory_s=time.perf_counter()-started
    inventory_counts=dict(counts);counts.clear();started=time.perf_counter();index=occurrences.build_occurrence_index(structure,inventory,prepared,limits=occurrences.OccurrenceLimits(1024,8192),source_inventory=source_inventory,deadline=time.monotonic()+2.0);index_s=time.perf_counter()-started;index_counts=dict(counts)
    def record(value):return {'count':value.count,'basis':value.basis,'reason':value.reason}
    payload={'by_candidate':{k:record(v) for k,v in index.by_candidate.items()},'default':record(index.default),'complete':index.complete,'chemical_complete':index.chemical_complete,'policy':index.policy,'potential_candidates':index.potential_candidates,'potential_atoms':index.potential_atoms,'qualified_candidates':index.qualified_candidates}
    encoded=json.dumps(payload,sort_keys=True,separators=(',',':')).encode();counts.clear();started=time.perf_counter()
    potential=[c for c in inventory.candidates if c.potential_ligand and c.boundary_status!='ineligible'];page_status=collections.Counter()
    for candidate in (potential[:12] if not case.startswith('atomcap:') else []):page_status[prepared.qualify(candidate.atom_ids).status]+=1
    page_s=time.perf_counter()-started;page_counts=dict(counts)
    counts.clear();started=time.perf_counter()
    for candidate in potential[12:24]:index.for_candidate(candidate.candidate_key)
    lookup_s=time.perf_counter()-started;lookup_counts=dict(counts)
    assert structure.to_bytes()==source and hashlib.sha256(original).hexdigest()==original_hash
    assert hashes()==before_sources
    print(json.dumps({'case':case,'atoms':len(structure.atoms),'all_candidates':len(inventory.candidates),'potential':len(potential),'source_sha256':hashlib.sha256(source).hexdigest(),'original_sha256':original_hash,'fixture_s':fixture_s,'source_assessment_s':source_s,'inventory_s':inventory_s,'inventory_counts':inventory_counts,'index_s':index_s,'index_counts':index_counts,'page12_reuse_s':page_s,'page12_counts':page_counts,'warm_summary_lookup_s':lookup_s,'warm_lookup_counts':lookup_counts,'index':payload,'summary_encoded_bytes':len(encoded),'summary_sha256':hashlib.sha256(encoded).hexdigest(),'resident_before_bytes':start_rss,'resident_after_bytes':rss(),'process_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'input_unchanged':True,'source_files_unchanged':True,'sources':before_sources,'rdkit_version':rdBase.rdkitVersion}))

def main():
    if len(sys.argv)>1:child(sys.argv[1]);return
    result=OUT/'prototype-results.json';assert not result.exists();state={'scope':'Frozen approved occurrence prototype stage measurements; not API/browser or all-host timing','samples':[],'source_before':hashes(),'platform':platform.platform(),'load_before':Path('/proc/loadavg').read_text().strip(),'complete':False}
    env=os.environ.copy();env.update(PYTHONPATH=':'.join(str(ROOT/p) for p in ['apps/api/src','packages/neistra_core/src','packages/neistra_demo_plugin/src','.']),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    for case in ['repeat:25','repeat:1025','repeat:1000','varied:1000','larger:100','mixed:25','largecomplex:1','atomcap:200']:
        for repeat in range(3):
            p=subprocess.run([sys.executable,str(Path(__file__).resolve()),case],capture_output=True,env=env,timeout=180);(OUT/f'prototype-{case.replace(":","-")}-{repeat+1}.stderr.log').write_bytes(p.stderr)
            if p.returncode:
                state['failed']={'case':case,'repeat':repeat+1,'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')};result.write_text(json.dumps(state,indent=2)+'\n');raise SystemExit(p.returncode)
            row=json.loads(p.stdout);row['repeat']=repeat+1;state['samples'].append(row);result.write_text(json.dumps(state,indent=2)+'\n');print(case,repeat+1,'index',row['index_s'],'complete',row['index']['complete'],'countwork',row['index_counts'],flush=True)
    state['source_after']=hashes();assert state['source_after']==state['source_before'];state['complete']=True;state['load_after']=Path('/proc/loadavg').read_text().strip();result.write_text(json.dumps(state,indent=2)+'\n');print('COMPLETE',result)
if __name__=='__main__':main()
