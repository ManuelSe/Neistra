import datetime
import hashlib
import json
import runpy
from pathlib import Path

root=Path.cwd(); assets=root/'docs/assets/ligand-designation'; evidence=root/'.issue-11-evidence'
h=runpy.run_path(str(assets/'release-evidence.py.txt')); items={}; retained={}
for name in ['issue158-occurrence-science','issue158-occurrence-api','issue158-occurrence-frontend','issue158-count-recovery-frontend','issue158-occurrence-performance','issue158-occurrence-integrated']:
    if name=='issue158-occurrence-performance':
        count,excluded=h['add_reader_workspace'](items,evidence/name,'focused/'+name)
        retained[name]={'files':count,'excluded_named_caches':excluded}
    else:
        h['add_tree'](items,'focused/'+name,evidence/name)
for name in ['run-combined-native3.py','combined-native3-0.log','combined-native3-browser.json','combined-native3.json','combined-native3-enclosing.json']:
    h['add'](items,'native/'+name,evidence/'issue158-integration-root'/name)
for path in sorted(evidence.glob('issue158-c4-candidate1-*')):
    h['add'](items,'stopped-candidate1/'+path.name,path)
for path in sorted(assets.glob('c4-candidate1-*')):
    h['add'](items,'stopped-candidate1/tracked/'+path.name,path)
workspaces=[Path('/tmp/neistra158-c4-candidate1'),Path('/tmp/neistra158-c3-combined-native3')]
def stores(value):
    if isinstance(value,dict):
        for key,item in value.items():
            if key=='retained_store': yield Path(item)
            else: yield from stores(item)
    elif isinstance(value,list):
        for item in value: yield from stores(item)
for name in ['api-prototype-results.json','verified-source-probe-results.json']:
    workspaces.extend(stores(json.loads((evidence/'issue158-occurrence-performance'/name).read_text())))
for path in sorted(set(workspaces)):
    assert path.name.startswith(('neistra158-c4-candidate1','neistra158-c3-combined-native3','neistra158-occurrence-api-'))
    count,excluded=h['add_reader_workspace'](items,path,'retained-workspaces/'+path.name)
    retained[str(path)]={'files':count,'excluded_named_caches':excluded}
ids=runpy.run_path(str(assets/'qualification.py.txt'))['current_identities'](root)
native=json.loads((evidence/'issue158-integration-root/combined-native3.json').read_text())
assert native['complete'] and native['source_unchanged'] and native['source_after']==ids
browser=json.loads((evidence/'issue158-integration-root/combined-native3-browser.json').read_text()); assert browser['stats']['expected']==22 and not any(browser['stats'][k] for k in ['unexpected','flaky','skipped'])
assert json.loads((evidence/'issue158-integration-root/combined-native3-enclosing.json').read_text())['exit_code']==0
checks=json.loads((evidence/'issue158-occurrence-integrated/checks1.json').read_text());assert checks['complete'] and all(s['exit_code']==0 for s in checks['steps'])
p=assets/'c3-occurrence-correction-checks.zip';assert not p.exists();packet=h['archive'](items,p)
record={'scope':'Passing occurrence-count correction checkpoint; focused validation, not full42 gate, final all-seven approval or push readiness','integration_head':'bb46b1cf30fb0e65757fb711148e29cc54bd926b','comparison_base':'b038e4e6cdb30cf4a296ca4dcd218a7ab5ced881','source_count':len(ids),'source_digest':hashlib.sha256(json.dumps(ids,sort_keys=True).encode()).hexdigest(),'source_identities':ids,'checked_archive':packet,'retained_workspaces':retained,'validation':{'focused_python':263,'frontend_tests':1295,'frontend_suites':122,'supervisor':14,'global_ruff':'PASS','api_core_plugin_mypy_sources':249,'frontend_lint_types_build':'PASS','native_cases':22,'native_failures_flakes_retries_skips':0,'source_unchanged':True,'actual_native_enclosing_session':28053,'actual_native_enclosing_exit':0},'policy':'D176 measured numeric bounds adopted; immutable derived summary only; no migration/dependency change','failed_attempt':'candidate1 intentional stop, eight priorpasses and partialPython/actual enclosing143 retained; neverpooled into freshcompletegate','remaining':['fresh42candidate2/summary/recursivepackaging/actualenclosing','allseven final samecandidate assessments','normalPR/review/merge','fresh exactmerged42gate','annotatedtag/publishedrelease/anonymousassets','issuecloseout/terminaldocs/ownedcleanup','159through163andparentcloseout'],'single_parent_goal_active':True,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=assets/'c3-occurrence-correction-checkpoint.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'archive':packet,'retained_workspaces':len(retained),'source_count':len(ids),'source_digest':record['source_digest']},indent=2))
