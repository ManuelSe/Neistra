import subprocess,json,os,datetime,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent;env=os.environ.copy()
for k in ['NEISTRA_DATA_DIR','NEISTRA_DATABASE_URL','MOLWEAVE_DATA_DIR','MOLWEAVE_DATABASE_URL','DATABASE_URL']:env.pop(k,None)
commands=[('ruff',['.venv/bin/uv','run','ruff','check','.']),('mypy',['.venv/bin/uv','run','mypy','apps/api','packages/neistra_core','packages/neistra_demo_plugin']),('python',['.venv/bin/uv','run','pytest','tests/scientific/test_ligand_occurrences.py','tests/scientific/test_ligand_instances.py','tests/scientific/test_ligand_source_boundaries.py','tests/scientific/test_ligand_qualification_boundaries.py','tests/scientific/test_ligand_fragment_h_recovery.py','tests/integration/test_ligand_occurrence_reads.py','tests/integration/test_ligand_designation.py','tests/integration/test_ligand_depiction_bounds.py','tests/integration/test_ligand_query_qualification.py','tests/integration/test_ligand_archives.py','tests/integration/test_ligand_migrations.py','tests/unit/test_ligand_occurrence_cache.py','tests/unit/test_namespace_compatibility.py']),('lint',['corepack','pnpm','--dir','apps/web','lint']),('types',['corepack','pnpm','--dir','apps/web','typecheck']),('web',['corepack','pnpm','--dir','apps/web','test']),('supervisor',['corepack','pnpm','test:dev']),('build',['corepack','pnpm','--dir','apps/web','build'])]
r={'scope':'Integratedfocusedoccurrencecheckpoint;notcomplete42gate','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'complete':False};receipt=out/'checks1.json'
for label,cmd in commands:
 print('START',label,flush=True);log=out/(label+'1.log')
 with log.open('wb') as f:c=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 r['steps'].append({'label':label,'command':cmd,'exit_code':c.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});receipt.write_text(json.dumps(r,indent=2)+'\n');print('EXIT',label,c.returncode,log.read_text()[-8000:],flush=True)
 if c.returncode:raise SystemExit(c.returncode)
r['complete']=True;r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt.write_text(json.dumps(r,indent=2)+'\n');print('COMPLETE',receipt,flush=True)
