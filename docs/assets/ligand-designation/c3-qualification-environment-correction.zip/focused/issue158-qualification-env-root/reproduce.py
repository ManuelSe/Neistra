import datetime,hashlib,json,os,subprocess
from pathlib import Path
root=Path.cwd();out=root/'.issue-11-evidence/issue158-qualification-env-root';run=Path('/tmp/neistra158-migration-env-repro1');assert not run.exists();run.mkdir()
recipe=json.loads((root/'docs/assets/ligand-designation/c4-candidate3-recipe.json').read_text());keys=recipe['unset_environment'];env={k:v for k,v in os.environ.items() if k not in keys};env.update(recipe['environment']);env['NEISTRA_MINIMIZATION_EVIDENCE_DIR']=str(run/'native')
shared=run/'shared';shared.mkdir();env.update({'NEISTRA_DATA_DIR':str(shared),'NEISTRA_DATABASE_URL':f'sqlite:///{shared}/molweave.db','MOLWEAVE_DATA_DIR':str(shared),'MOLWEAVE_DATABASE_URL':f'sqlite:///{shared}/molweave.db'})
protected=['tests/integration/test_migrations.py','tests/support/legacy_project_models.py','apps/api/src/neistra_api/settings.py','packages/neistra_core/src/neistra_core/configuration.py',*[str(p) for p in sorted(Path('apps/api/migrations/versions').glob('*.py'))]]
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in protected}
r={'scope':'Realhistoricalmigrationfixture injectedcanonicalenvfail vssanitizedenvpass; no application/assertion changes; notfullgate','protected_before':hashes(),'steps':[],'complete':False,'run':str(run),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def phase(name,cmd,environment):
 log=out/(name+'.log');print('START',name,flush=True)
 with log.open('wb') as stream:p=subprocess.run(cmd,env=environment,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 r['steps'].append({'name':name,'command':cmd,'exit_code':p.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});r['protected_after']=hashes();assert r['protected_after']==r['protected_before'];(out/'reproduction1.json').write_text(json.dumps(r,indent=2)+'\n');print('EXIT',name,p.returncode,log.read_text()[-1400:],flush=True);return p.returncode
assert phase('prepare', [str(root/'.venv/bin/uv'),'run','alembic','upgrade','head'],env)==0
node='tests/integration/test_migrations.py::test_0008_migrates_live_checkpoint_and_scene_settings'
command=[str(root/'.venv/bin/uv'),'run','pytest',node]
assert phase('injected-before',command+['--basetemp',str(run/'injected-tests')],env)==1
isolated={k:v for k,v in env.items() if k not in keys}
assert phase('sanitized-after',command+['--basetemp',str(run/'sanitized-tests')],isolated)==0
r['complete']=True;r['result']='SameunchangedtestfailswithgateDBaliases/passessanitized; historicalstoreisolated';r['sanitized_aliases']=keys;r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'reproduction1.json').write_text(json.dumps(r,indent=2)+'\n');print('COMPLETE',out/'reproduction1.json',flush=True)
