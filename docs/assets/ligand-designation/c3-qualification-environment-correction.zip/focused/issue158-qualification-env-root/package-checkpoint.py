import datetime,hashlib,json,runpy
from pathlib import Path
root=Path.cwd();assets=root/'docs/assets/ligand-designation';evidence=root/'.issue-11-evidence';h=runpy.run_path(str(assets/'release-evidence.py.txt'));items={};retained={}
for name in ['issue158-qualification-env-root','issue158-qualification-env-correction','issue158-candidate3-python-failure','issue158-correction-review-ac4786d1']:
 count,excluded=h['add_reader_workspace'](items,evidence/name,'focused/'+name);retained[name]={'files':count,'excluded_named_caches':excluded}
for path in sorted(evidence.glob('issue158-c4-candidate3-*')):h['add'](items,'failed-candidate3/'+path.name,path)
for path in sorted(assets.glob('c4-candidate3-*')):h['add'](items,'failed-candidate3/tracked/'+path.name,path)
for name in ['neistra158-c4-candidate3','neistra158-migration-env-repro1','neistra158-migration-env-module1']:
 directory=Path('/tmp')/name;prefix='retained-workspaces/'+name
 if name=='neistra158-c4-candidate3':
  count,excluded=h['add_reader_workspace'](items,directory,prefix);retained[name]={'files':count,'excluded_named_caches':excluded}
 else:
  # Pytest's internal `*current` aliases have no independent payload. Preserve
  # every real file and record only proven within-owner convenience links;
  # never follow or publish a filesystem symlink in the evidence ZIP.
  count=0;excluded=[];links=[]
  for path in sorted(directory.rglob('*')):
   relative=path.relative_to(directory)
   if path.is_symlink():
    target=path.resolve(strict=True);assert path.name.endswith('current') and target.is_relative_to(directory) and target.is_dir(),path
    links.append({'path':relative.as_posix(),'target':target.relative_to(directory).as_posix(),'kind':'pytest-internal-convenience-alias','target_payload_retained':True});continue
   if not path.is_file():continue
   assert path.resolve().is_relative_to(directory) and not h['EXCLUDED_PARTS'].intersection(relative.parts),path
   if h['CACHE_PARTS'].intersection(relative.parts) or path.suffix in {'.pyc','.pyo'}:excluded.append(relative.as_posix());continue
   h['add'](items,prefix+'/'+relative.as_posix(),path,reader_workspace=True);count+=1
  h['add'](items,prefix+'/pytest-convenience-links.json',h['encoded'](links));retained[name]={'files':count,'excluded_named_caches':excluded,'pytest_internal_aliases':links,'alias_policy':'Allactualpayloadsretained; originalsymlinksondiskunchanged; ZIPrecordslinkmapwithoutfilesystemlinks'}
ids=runpy.run_path(str(assets/'qualification.py.txt'))['current_identities'](root);old=json.loads((assets/'c3-complete-review-corrections-checkpoint.json').read_text());changed=sorted(k for k in ids if ids[k]!=old['source_identities'].get(k));assert changed==['docs/assets/ligand-designation/release-recipe.py.txt','tests/unit/test_ligand_release_recipe.py'];assert len(ids)==len(old['source_identities'])==1003
repro=json.loads((evidence/'issue158-qualification-env-root/reproduction1.json').read_text());assert repro['complete'] and [s['exit_code'] for s in repro['steps']]==[0,1,0] and repro['protected_before']==repro['protected_after']
module=json.loads((evidence/'issue158-qualification-env-root/migration-module1.json').read_text());assert module['exit_code']==0 and module['protected_unchanged'] and module['allfive_database_aliases_absent']
result=json.loads((evidence/'issue158-qualification-env-correction/result.json').read_text());assert result['focused_after']['recipe_tests_passed']==17
p=assets/'c3-qualification-environment-correction.zip';assert not p.exists();packet=h['archive'](items,p)
r={'scope':'Passingqualificationenvironmentcorrection checkpoint; notcomplete42gate orfinalreadiness','base':'ac4786d1da386c6504d0d4dad865c7304df5ae10','source_count':len(ids),'source_digest':hashlib.sha256(json.dumps(ids,sort_keys=True).encode()).hexdigest(),'source_identities':ids,'changed_selected_sources':changed,'all_application_scientific_api_frontend_native_sources_unchanged':True,'checked_archive':packet,'retained_workspaces':retained,'failed_full_candidate3':'8priorpasses;2844Pythonpass132failallhistoricalmigrations;actualenclosing71290exit1;1003current931oldunchangedduringrun;notpooled','root_cause':'CanonicalDBaliasesinjectedbyPythonphaseoverrodelegacytemporarymigrationfixturealiases; unchangedactualtestfailsinjected/passes sanitized','correction':'Onlypyteststepstopssupplying sharedDB; per-step inherited5DBalias sanitization remains anddedicatedAlembic/readers/versions/CLIkeepexplicitownedstores','validation':{'real_unchanged_case_injected_exit':1,'real_unchanged_case_sanitized_exit':0,'reproduction_actual_enclosing_session':23682,'reproduction_actual_enclosing_exit':0,'complete_historical_migration_module_passed':133,'module_actual_enclosing_session':23430,'module_actual_enclosing_exit':0,'recipe_tests_passed':17,'recipe_ruff_and_compile':'PASS','migration_logic_tests_assertions_precedence_timeouts_exclusions_unchanged':True},'unaffected_evidence':'Prior187focused/1304frontend/build/fresh26native proof validforbyte-identicalapplication; newverificationsourcesqualifyfocusedchecks andmustenterfreshcompletecandidate4','remaining':['checkpointcommit/currentcodeverdictreconfirmation','fresh42candidate4/summary/package/actualenclosing','finalmetadata/C5recipe/all7samecandidatefinalapproval','normalPRmerge/exactmergedfresh42/releasecloseoutcleanup','159through163parentcloseout'],'single_parent_goal_active':True,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=assets/'c3-qualification-environment-checkpoint.json';assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'archive':packet,'source_count':len(ids),'source_digest':r['source_digest'],'changed':changed},indent=2))
