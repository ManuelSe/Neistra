import type { MolstarEngine } from "/datadisk/dev/neistra-worktrees/issue-158-durable-ligand-designation/apps/web/src/viewer/MolstarEngine";
declare global { interface Window { interactionEngines: MolstarEngine[] } }
export {};
