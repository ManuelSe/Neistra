"""Package the closed legacy minimization fixture correction and consumer proof."""
from pathlib import Path
import datetime
import json
import re
import runpy

root=Path.cwd();assets=root/'docs/assets/ligand-designation';private=root/'.issue-11-evidence'
out=private/'issue158-minimization-baseline-packet';assert not out.exists();out.mkdir()
h=runpy.run_path(str(assets/'release-evidence.py.txt'))
q=runpy.run_path(str(assets/'qualification.py.txt'))
before=q['current_identities'](root);assert len(before)==1005
old_receipt=json.loads(Path('/tmp/neistra158-reader-0350-source.json').read_text())
old_expected=old_receipt['files'];assert len(old_expected)==931
old_before=q['extracted_identities'](Path(old_receipt['root']),old_expected);assert old_before==old_expected
key='tests/e2e/support/minimization.ts';expected='57d75c0da967528ddb1af803590987b219e8358151ede842d149f038feb5f081'
assert before[key]==expected
consumer_dir=private/'issue158-minimization-consumers-all1';receipt=json.loads((consumer_dir/'receipt.json').read_text())
assert receipt['exit_code']==0 and receipt['source_unchanged'] and receipt['source_before']==receipt['source_after']==before
assert h['fingerprint'](consumer_dir/'raw.log')['sha256']==receipt['log_sha256']
report=json.loads((consumer_dir/'browser.json').read_text());stats=report['stats']
assert stats['expected']==17 and stats['skipped']==1 and stats['unexpected']==stats['flaky']==0 and not report['errors']
tests=[]
def walk(suites):
    for suite in suites:
        for spec in suite.get('specs',[]):
            for test in spec.get('tests',[]):tests.append((spec,test))
        walk(suite.get('suites',[]))
walk(report['suites']);assert len(tests)==18
assert all(len(t['results'])==1 and t['results'][0]['retry']==0 for _,t in tests)
skips=[(s,t) for s,t in tests if t['expectedStatus']=='skipped'];assert len(skips)==1
assert all(t['expectedStatus']=='passed' and t['results'][0]['status']=='passed' for _,t in tests if t['expectedStatus']!='skipped')
assert skips[0][1]['results'][0]['status']=='skipped'
skip_spec,skip_test=skips[0]
assert skip_spec['file']=='minimization-accessibility.spec.ts' and skip_test['projectName']=='mobile-chromium'
unchanged_skip_file='tests/e2e/minimization-accessibility.spec.ts'
assert before[unchanged_skip_file]==old_expected[unchanged_skip_file]
assert skip_test['annotations'][0]['description']=='Native desktop browser zoom qualified separately from mobile touch.'
readback=json.loads((consumer_dir/'root-readback.json').read_text())
assert readback['original_tool_enclosing_exit_observed'] is False and readback['native_child_exit']==0 and readback['assertions_passed']
assert readback['receipt_sha256']==h['fingerprint'](consumer_dir/'receipt.json')['sha256']
assert readback['browser_sha256']==h['fingerprint'](consumer_dir/'browser.json')['sha256']
failed_types=private/'issue158-candidate7-failure/helper-types';passed_types=private/'issue158-helper-types2'
first=json.loads((failed_types/'receipt.json').read_text());second=json.loads((passed_types/'receipt.json').read_text())
assert first['exit_code']==2 and second['exit_code']==0
assert all(r['source_before']==r['source_after']==expected and r['source_unchanged'] for r in [first,second])
for directory,typed in [(failed_types,first),(passed_types,second)]:
    assert h['fingerprint'](directory/'tsconfig.json')['sha256']==typed['config_sha256']
    assert h['fingerprint'](directory/'raw.log')['sha256']==typed['log_sha256']
initial_config=json.loads((failed_types/'tsconfig.json').read_text());final_config=json.loads((passed_types/'tsconfig.json').read_text())
assert initial_config['files']==final_config['files']
assert all(final_config['compilerOptions'][k]==v for k,v in initial_config['compilerOptions'].items())
assert set(final_config['compilerOptions'])-set(initial_config['compilerOptions'])=={'allowImportingTsExtensions','typeRoots','types'}
assert final_config['compilerOptions']['strict'] and final_config['compilerOptions']['noEmit']
codes=set(re.findall(r'error TS([0-9]+):',(failed_types/'raw.log').read_text()))
assert codes=={'2307','2580','5097'}
c7=json.loads((assets/'c4-candidate7-gate.json').read_text())
assert c7['preceding_source_expected']==old_expected
assert sorted(k for k in before if before[k]!=c7['source_before'][k])==[key]
old_helper=private/'issue158-candidate7-failure/minimization-helper-before.ts'
assert h['fingerprint'](old_helper)['sha256']==c7['source_before'][key]
prior=assets/'c3-forensics-verification3.json';prior_data=json.loads(prior.read_text())
assert prior_data['new_run']['label']=='c4-candidate7' and prior_data['new_run']['qualification_complete'] is False
items={};retained={}
retained['consumer-output']=h['add_tree'](items,'consumer-probe',consumer_dir)
count,excluded=h['add_reader_workspace'](items,Path('/tmp/neistra158-minimization-consumers-all1'),'owned-consumer-store')
assert not excluded;retained['owned-consumer-store']=count
for directory,label in [(failed_types,'failed-helper-types'),(passed_types,'passing-helper-types')]:
    retained[label]=h['add_tree'](items,label,directory)
for name in ['issue158-candidate7-failure/actual-enclosing.json','issue158-candidate7-failure/independent-architecture-diagnosis.json','issue158-candidate7-failure/remaining-native-baseline-audit.json','issue158-candidate7-failure/before-probe-actual-enclosing.json','issue158-candidate7-failure/after1-actual-enclosing.json']:
    h['add'](items,'diagnosis/'+Path(name).name,private/name)
for label in ['before1','after1']:
    for name in ['receipt.json','browser.json','raw.log']:
        h['add'](items,'focused-baseline/'+label+'/'+name,private/('issue158-selection-baseline-'+label)/name)
h['add'](items,'source/minimization-helper-before.ts',old_helper)
h['add'](items,'source/'+key,root/key)
h['add'](items,'operations/consumer-runner.py',private/'issue158-minimization-consumers-run.py')
h['add'](items,'operations/baseline-runner.py',private/'issue158-selection-baseline-run.py')
h['add'](items,'operations/packager.py',Path(__file__))
prior_refs={p.relative_to(root).as_posix():h['fingerprint'](p) for p in [prior,assets/prior_data['archive'],assets/'c3-forensics-index.json',assets/'c4-candidate7-gate.json']}
facts=dict(scope='Closed helper-consumer diagnostic checkpoint; not complete application qualification or final readiness',helper_sha256=expected,
    consumer_probe=dict(native_child_exit=0,original_session=27894,original_tool_enclosing_exit_observed=False,source_maps_unchanged=True,passed=17,historical_skipped=1,failed=0,flaky=0,retries=0,root_fresh_readback=dict(tool_chunk='3f5e5d',exit_code=0,evidence='consumer-probe/root-readback.json',scope='Fresh closed-evidence validation only; no native rerun and no claim about unavailable original tool completion')),
    strict_helper_types=dict(actual_parent_observed_session=48114,actual_exit=0,scope='Changed helper only with actual Vite mapping, Node declarations, existing browser globals and TypeScript-extension imports; not whole legacy native TypeScript coverage',initial_config_exit=2,configuration_only_added_options=['allowImportingTsExtensions','typeRoots','types'],helper_source_unchanged=True,initial_config_receipt_and_log_retained=True),
    old_native_failure='First controlled assessment legitimately advances revision before minimization capture. The old helper returned its earlier pre-assessment project baseline; calculation itself preserves captured revision.',
    correction='Observe actual successful assessment batches, prove exact project/history/source/entry invariants and complete all initial entries before returning the asserted baseline; retain all original readonly/preview/Apply/Undo/Redo checks.',
    earlier_probes=dict(before_actual_session=95983,before_failed=2,before_actual_exit=1,after_actual_session=15970,after_passed=2,after_actual_exit=0),
    retained=retained,prior_forensic_references=prior_refs,no_raw_c7native_or_forensic_part_rebundling=True,
    specialist_scope='Independent architecture assessment is coordinated separately by root; this packet does not claim final specialist approval.',required_next='Scoped independent reassessment, fresh complete C8 all42, independent summary/recursive packaging/actual enclosing readback, final all-seven review and normal delivery; no pooled gates')
h['add'](items,'correction-facts.json',h['encoded'](facts))
after=q['current_identities'](root);old_after=q['extracted_identities'](Path(old_receipt['root']),old_expected)
assert before==after and old_before==old_after==old_expected
source_proof=dict(current_count=len(before),current_digest=h['sha'](json.dumps(before,sort_keys=True).encode()),current_before=before,current_after=after,current_unchanged=True,preceding_tag=old_receipt['tag'],preceding_commit=old_receipt['commit'],preceding_count=len(old_before),preceding_expected=old_expected,preceding_before=old_before,preceding_after=old_after,preceding_unchanged=True)
h['add'](items,'source-proof.json',h['encoded'](source_proof))
archive=h['archive'](items,assets/'c3-minimization-baseline-correction.zip')
assert q['current_identities'](root)==before
assert q['extracted_identities'](Path(old_receipt['root']),old_expected)==old_expected
record=dict(**facts,archive=archive['file'],archive_bytes=archive['bytes'],archive_sha256=archive['sha256'],outer_manifest_entries=archive['outer_manifest_entries'],recursive_verification=archive['verification_counts'],source_count=1005,source_digest=source_proof['current_digest'],preceding_source_count=931,current_and_preceding_sources_unchanged=True,only_changed_selected_source_from_failed_c7=key,all_packet_payload_hashes_and_recursive_crcs_verified=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
target=assets/'c3-minimization-baseline-checkpoint.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
private_receipt=out/'packager-result.json';private_receipt.write_text(json.dumps(dict(archive=archive,checkpoint=h['fingerprint'](target),source_proof=dict(current_digest=source_proof['current_digest'],current_count=1005,preceding_count=931,unchanged=True)),indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
