"""Read-only core work-count probe; run from the issue-158 checkout."""
import hashlib
import json
import platform
import time
from pathlib import Path
from unittest.mock import patch
from rdkit import Chem, rdBase
from neistra_core.adapters.rdkit_common import mol_to_normalized
from neistra_core.ligands import candidates, chemistry

class CountList(list):
    def __init__(self, values):
        super().__init__(values)
        self.visits = self.passes = 0
    def __iter__(self):
        self.passes += 1
        for value in super().__iter__():
            self.visits += 1
            yield value

def specimen(fragment, copies):
    smiles = '.'.join([fragment] * copies)
    structure = mol_to_normalized(Chem.MolFromSmiles(smiles), filename='profile.smi', format_name='smiles')
    atoms, bonds = CountList(structure.atoms), CountList(structure.bonds)
    return structure.model_copy(update={'atoms': atoms, 'bonds': bonds}), smiles.encode()

def measure(label, fragment, copies, page=False):
    structure, raw = specimen(fragment, copies)
    if page:
        inventory = candidates.resolve_candidates(structure, original_bytes=raw)
        structure.atoms.visits = structure.atoms.passes = 0
        structure.bonds.visits = structure.bonds.passes = 0
    counters = {'original_parses': 0, 'original_normalizations': 0, 'normalized_source_atoms': 0}
    old_parse, old_normalize = chemistry._original_molecules, chemistry.mol_to_normalized
    def parsing(*args, **kwargs):
        counters['original_parses'] += 1
        return old_parse(*args, **kwargs)
    def normalizing(*args, **kwargs):
        counters['original_normalizations'] += 1
        counters['normalized_source_atoms'] += args[0].GetNumAtoms()
        return old_normalize(*args, **kwargs)
    started = time.perf_counter()
    with patch.object(chemistry, '_original_molecules', parsing), patch.object(chemistry, 'mol_to_normalized', normalizing):
        if page:
            values = [chemistry.qualify_chemistry(structure, c.atom_ids, original_bytes=raw) for c in inventory.candidates[:12]]
            result = [{'status': v.status, 'formula': v.formula, 'charge': v.formal_charge, 'hash': v.input_hash} for v in values]
        else:
            inventory = candidates.resolve_candidates(structure, original_bytes=raw)
            result = inventory.model_dump(mode='json')
    return {'label': label, 'copies': copies, 'atoms': len(structure.atoms), 'bonds': len(structure.bonds), 'candidates': len(inventory.candidates), 'page_candidates': len(values) if page else None, 'milliseconds': round((time.perf_counter()-started)*1000, 3), 'atom_visits': structure.atoms.visits, 'atom_passes': structure.atoms.passes, 'bond_visits': structure.bonds.visits, 'bond_passes': structure.bonds.passes, **counters, 'semantic_sha256': hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()}

rows = [measure('ethanol_inventory', 'CCO', n) for n in (10,100,500)]
rows += [measure('water_inventory', 'O', n) for n in (5,25,100)]
rows += [measure('individual_page_qualification', 'CCO', n, page=True) for n in (10,50,200)]
source_files = [Path(m.__file__) for m in (candidates,chemistry)]
print(json.dumps({'python': platform.python_version(), 'platform': platform.platform(), 'rdkit': rdBase.rdkitVersion, 'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}, 'measurements': rows, 'scope': 'Single local samples and deterministic work counts; no strict-host timing, speedup or actual API cache qualification. Individual page calls deliberately reproduce the current nonshared API; a new explicit shared-context API requires its own companion probe.'}, indent=2))
