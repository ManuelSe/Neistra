"""Read-only companion probe for one request-owned chemistry context."""
import hashlib
import json
import time
from pathlib import Path
from unittest.mock import patch
from rdkit import Chem
from neistra_core.adapters.rdkit_common import mol_to_normalized
from neistra_core.ligands import candidates, chemistry

class CountList(list):
    def __init__(self, values):
        super().__init__(values)
        self.visits = self.passes = 0
    def __iter__(self):
        self.passes += 1
        for value in super().__iter__():
            self.visits += 1
            yield value

rows=[]
for copies in [10,50,200]:
    smiles='.'.join(['CCO']*copies)
    raw=smiles.encode()
    source=mol_to_normalized(Chem.MolFromSmiles(smiles),filename='profile.smi',format_name='smiles')
    inventory=candidates.resolve_candidates(source,original_bytes=raw)
    atoms,bonds=CountList(source.atoms),CountList(source.bonds)
    source=source.model_copy(update={'atoms':atoms,'bonds':bonds})
    counts={'original_parses':0,'original_normalizations':0,'add_h_calls':0}
    parse,normalize,add_h=chemistry._original_molecules,chemistry.mol_to_normalized,Chem.AddHs
    def parsing(*a,**kw):
        counts['original_parses']+=1
        return parse(*a,**kw)
    def normalizing(*a,**kw):
        counts['original_normalizations']+=1
        return normalize(*a,**kw)
    def hydrogens(*a,**kw):
        counts['add_h_calls']+=1
        return add_h(*a,**kw)
    started=time.perf_counter()
    with patch.object(chemistry,'_original_molecules',parsing),patch.object(chemistry,'mol_to_normalized',normalizing),patch.object(Chem,'AddHs',hydrogens):
        prepared=chemistry.prepare_chemistry(source,original_bytes=raw)
        qualified=[prepared.qualify(c.atom_ids) for c in inventory.candidates[:12]]
    elapsed=(time.perf_counter()-started)*1000
    result=[{'status':v.status,'formula':v.formula,'charge':v.formal_charge,'hash':v.input_hash} for v in qualified]
    digest=hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest()
    baseline=json.loads(Path('/tmp/neistra-158-performance-assessment/baseline.json').read_text())
    expected=next(row for row in baseline['measurements'] if row['label']=='individual_page_qualification' and row['copies']==copies)
    assert digest==expected['semantic_sha256']
    with patch.object(chemistry,'_original_molecules',side_effect=AssertionError('cache-key parsed source')),patch.object(chemistry.rdDepictor,'Compute2DCoords',side_effect=AssertionError('cache-key generated layout')):
        keys=[chemistry.depiction_cache_key(qualified[0].input_hash) for _ in range(1000)]
    rows.append({'copies':copies,'source_atoms':len(atoms),'page_candidates':len(qualified),'atom_visits':atoms.visits,'bond_visits':bonds.visits,**counts,'milliseconds':round(elapsed,3),'semantic_sha256':digest,'baseline_semantic_equal':True,'1000_cache_keys_stable':len(set(keys))==1})
# A fresh, over-limit call must not prepare source indices or invoke the parser.
atoms,bonds=CountList(source.atoms),CountList(source.bonds)
source=source.model_copy(update={'atoms':atoms,'bonds':bonds})
with patch.object(chemistry,'_original_molecules',side_effect=AssertionError('oversized candidate parsed source')):
    refused=chemistry.qualify_chemistry(source,list(range(1,1026)),original_bytes=raw)
assert refused.reason=='depiction_atom_limit' and atoms.visits==bonds.visits==0
print(json.dumps({'shared_pages':rows,'oversize_admission':{'reason':refused.reason,'atom_visits':atoms.visits,'bond_visits':bonds.visits},'scope':'Deterministic work counts; single elapsed samples are diagnostic only. Actual API cache path remains unqualified.'},indent=2))
