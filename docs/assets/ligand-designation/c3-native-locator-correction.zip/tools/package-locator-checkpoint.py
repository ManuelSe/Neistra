import datetime
import hashlib
import json
import runpy
from pathlib import Path

root = Path.cwd()
assets = root / 'docs/assets/ligand-designation'
private = root / '.issue-11-evidence'
helpers = runpy.run_path(str(assets / 'release-evidence.py.txt'))
ids = runpy.run_path(str(assets / 'qualification.py.txt'))['current_identities'](root)
receipt = json.loads((private / 'issue158-locator-combined-after3/receipt.json').read_text())
assert receipt['exit_code'] == 0 and receipt['source_before'] == receipt['source_after'] == ids
items = {}
retained = {}
for name in ('issue158-locator-combined-after2', 'issue158-locator-combined-after3',
             'issue158-locator-source-versions', 'issue158-locator-static'):
    count, excluded = helpers['add_reader_workspace'](items, private / name, 'focused/' + name)
    retained[name] = {'files': count, 'excluded_named_caches': excluded}
for name in ('neistra158-locator-combined-after2', 'neistra158-locator-combined-after3'):
    count, excluded = helpers['add_reader_workspace'](items, Path('/tmp') / name, 'owned-stores/' + name)
    retained[name] = {'files': count, 'excluded_named_caches': excluded}
for name in ('issue158-locator-combined-run.py', 'package-locator-checkpoint.py'):
    helpers['add'](items, 'tools/' + name, private / name)
for relative in ('tests/e2e/project-lifecycle.spec.ts', 'tests/e2e/selection-appearance.spec.ts'):
    helpers['add'](items, 'source/' + relative, root / relative)
report = json.loads((private / 'issue158-locator-combined-after3/browser.json').read_text())
assert report['stats']['expected'] == 11 and report['stats']['skipped'] == 3
assert report['stats']['unexpected'] == report['stats']['flaky'] == 0
packet = helpers['archive'](items, assets / 'c3-native-locator-correction.zip')
assert packet['bytes'] < 80 * 1024 * 1024
record = {
    'scope': 'Passing existing native locator/picking oracle correction; not a complete gate or final readiness',
    'base': '5d34a29be9cddff1b47289341725ee7c616e52b8',
    'source_count': len(ids),
    'source_digest': hashlib.sha256(json.dumps(ids, sort_keys=True).encode()).hexdigest(),
    'source_identities': ids,
    'test_changes': ['tests/e2e/project-lifecycle.spec.ts', 'tests/e2e/selection-appearance.spec.ts'],
    'additional_selected_sources': ['tools/verify_ligand_forensics.py', 'tests/unit/test_ligand_forensic_verifier.py'],
    'application_scientific_api_frontend_migrations_unchanged': True,
    'checked_archive': packet,
    'retained_workspaces': retained,
    'failed_full_gate': {'candidate': '5d34a29be9cddff1b47289341725ee7c616e52b8', 'actual_session': 97110,
                         'actual_exit': 1, 'native_passed': 157, 'native_failed': 1,
                         'encountered_historical_skips': 3, 'not_run': 441,
                         'source_unchanged': 1003, 'preceding_source_unchanged': 931,
                         'reason': 'Global Receptor text also matches the newly exposed Entry option'},
    'focused_before': [
        {'actual_session': 98037, 'exit': 1, 'reason': 'Exact entry-name locator is ambiguous'},
        {'actual_session': 92196, 'exit': 1, 'reason': 'Global Clear targets selection and ligand designation'},
    ],
    'focused_intermediate': [
        {'actual_session': 66832, 'exit': 1, 'passed': 10, 'failed': 1, 'historical_skips': 3,
         'reason': 'Old guessed canvas fractions miss actual visible atom centers'},
        {'actual_session': 94576, 'exit': 1, 'passed': 10, 'failed': 1, 'historical_skips': 3,
         'reason': 'Projected trusted click succeeds atom2; newly added viewer-event assertion used entry_id instead of structure_id'},
    ],
    'focused_final': {'actual_session': 73803, 'actual_exit': 0, 'passed': 11, 'failed': 0,
                      'flaky': 0, 'retries': 0, 'historical_skips_unchanged': 3,
                      'all_selected_sources_unchanged': True,
                      'native_click': 'Read-only actual camera projection; unobstructed canvas center; trusted click; exact structure_id/atom_id event; all original palette/edit/orbit/durability assertions'},
    'scoped_architecture': {'agent': '/root/issue156_architecture_review7', 'verdict': 'PENDING',
                            'scope': 'Two existing native oracles and independent new verifier assessment; final all7 still required'},
    'remaining': ['fresh candidate6 all42/summary/package/actual enclosing',
                  'samefinalcandidate all7/protected delivery/exactmerged qualification',
                  'verified release assets/child closeout/cleanup;159–163 and parent'],
    'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(assets / 'c3-native-locator-checkpoint.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'archive': packet, 'source_count': len(ids), 'source_digest': record['source_digest']}, indent=2))
