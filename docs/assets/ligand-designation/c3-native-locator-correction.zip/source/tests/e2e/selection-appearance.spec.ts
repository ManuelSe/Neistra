import AxeBuilder from "@axe-core/playwright";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { expect, test, type APIRequestContext, type Page } from "@playwright/test";
import type { Project, Selection, StructureProjection } from "../../apps/web/src/api/types";
import { observe } from "./support/modeling";
import type { MolstarEngine } from "../../apps/web/src/viewer/MolstarEngine";
import type { observeEditPicks } from "../../apps/web/src/test/molecularEditHarness";

declare global { interface Window {
  interactionEngines: MolstarEngine[];
  editingPicks: Awaited<ReturnType<typeof observeEditPicks>>;
} }

const ETHANOL = resolve("tests/fixtures/formats/ethanol.mol");

function escapeRegex(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function createImportedProject(
  request: APIRequestContext,
  name: string,
): Promise<Project> {
  const created = await request.post("/api/v1/projects", { data: { name } });
  expect(created.status()).toBe(201);
  const project = await created.json() as Project;
  const imported = await request.post(`/api/v1/projects/${project.id}/imports`, {
    multipart: {
      expected_revision: String(project.revision),
      generate_3d: "true",
      infer_bonds: "true",
      files: {
        name: "ethanol.mol",
        mimeType: "chemical/x-mdl-molfile",
        buffer: readFileSync(ETHANOL),
      },
    },
  });
  expect(imported.status()).toBe(201);
  return await (await request.get(`/api/v1/projects/${project.id}`)).json() as Project;
}

async function switchToProject(page: Page, name: string): Promise<void> {
  await page.getByRole("button", { name: "Projects", exact: true }).click();
  await page.getByRole("dialog", { name: "Projects" })
    .getByRole("button", { name: new RegExp(`^${escapeRegex(name)}`) }).click();
  await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded", { timeout: 30_000 });
}

async function selectCurrentEntry(page: Page): Promise<void> {
  await page.locator(".entry-row .entry-select").click();
  await expect(page.locator(".viewer-status")).toContainText("/ 3 selected");
}

test("remembers coloring mode across panels and projects until reload", async ({ page, request }, info) => {
  test.setTimeout(90_000);
  test.skip(info.project.name !== "chromium", "Application-session preference is covered once in desktop Chromium.");
  const stamp = Date.now();
  const first = await createImportedProject(request, `Color mode A ${stamp}`);
  const second = await createImportedProject(request, `Color mode B ${stamp}`);
  let appearanceRequests = 0;
  page.on("request", (outgoing) => {
    if (new URL(outgoing.url()).pathname.endsWith("/selection-appearance")) appearanceRequests++;
  });

  await page.goto("/");
  await switchToProject(page, first.name);
  await selectCurrentEntry(page);
  const launcher = page.getByRole("button", { name: "Style selection", exact: true });
  const dialog = page.getByRole("dialog", { name: "Style selection" });
  await launcher.click();
  await expect(dialog.getByRole("button", { name: "Carbon only" })).toHaveAttribute("aria-pressed", "true");
  await dialog.getByRole("button", { name: "All atoms" }).click();
  await expect(dialog.getByRole("button", { name: "All atoms" })).toHaveAttribute("aria-pressed", "true");
  expect(appearanceRequests).toBe(0);
  await page.keyboard.press("Escape");
  await launcher.click();
  await expect(dialog.getByRole("button", { name: "All atoms" })).toHaveAttribute("aria-pressed", "true");
  await page.keyboard.press("Escape");

  await switchToProject(page, second.name);
  await selectCurrentEntry(page);
  await launcher.click();
  await expect(dialog.getByRole("button", { name: "All atoms" })).toHaveAttribute("aria-pressed", "true");
  await dialog.getByRole("button", { name: "Carbon only" }).click();
  await expect(dialog.getByRole("button", { name: "Carbon only" })).toHaveAttribute("aria-pressed", "true");
  await page.keyboard.press("Escape");

  await switchToProject(page, first.name);
  await selectCurrentEntry(page);
  await launcher.click();
  await expect(dialog.getByRole("button", { name: "Carbon only" })).toHaveAttribute("aria-pressed", "true");
  await dialog.getByRole("button", { name: "All atoms" }).click();
  expect(appearanceRequests).toBe(0);
  expect((await (await request.get(`/api/v1/projects/${first.id}`)).json() as Project).revision).toBe(first.revision);
  expect((await (await request.get(`/api/v1/projects/${second.id}`)).json() as Project).revision).toBe(second.revision);

  await page.reload();
  await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded", { timeout: 30_000 });
  await selectCurrentEntry(page);
  await page.getByRole("button", { name: "Style selection", exact: true }).click();
  await expect(page.getByRole("dialog", { name: "Style selection" })
    .getByRole("button", { name: "Carbon only" })).toHaveAttribute("aria-pressed", "true");
  expect(appearanceRequests).toBe(0);
});

test("expands from styling across hidden entries without durable changes", async ({ page, request }, info) => {
  test.setTimeout(90_000);
  test.skip(info.project.name !== "chromium", "Project-wide fixture setup uses desktop panels.");
  await page.setViewportSize({ width: 1366, height: 768 });
  const created = await request.post("/api/v1/projects", {
    data: { name: `Selection appearance ${Date.now()}` },
  });
  expect(created.status()).toBe(201);
  let project: Project = await created.json();
  await page.route("**/src/viewer/MolstarEngine.ts*", async route => {
    const response = await route.fetch();
    await route.fulfill({ response, body: `${await response.text()}\nconst selectionStyleMount = MolstarEngine.prototype.mount;\nMolstarEngine.prototype.mount = async function(target) { await selectionStyleMount.call(this,target); (window.interactionEngines ??= []).push(this); };` });
  });
  await page.goto("/");
  await page.getByRole("button", { name: "Projects", exact: true }).click();
  await page.getByRole("dialog", { name: "Projects" })
    .getByRole("button", { name: new RegExp(`^${project.name}`) }).click();
  await page.getByRole("button", { name: "Import structures" }).first().click();
  const upload = page.getByRole("dialog", { name: "Import structures" });
  await upload.locator('input[type="file"]').setInputFiles(resolve("tests/fixtures/formats/ethanol.mol"));
  await upload.getByRole("button", { name: "Import", exact: true }).click();
  await expect(upload).toBeHidden({ timeout: 30_000 });
  await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded", { timeout: 45_000 });
  await page.getByRole("button", { name: "Fit all visible", exact: true }).click();
  project = await (await request.get(`/api/v1/projects/${project.id}`)).json();
  const original = project.entries[0];
  const row = page.locator(`.entry-row[data-entry-id="${original.id}"]`);
  await row.getByRole("button", { name: /actions/i }).click();
  await page.getByRole("menuitem", { name: /duplicate/i }).click();
  await expect(page.locator(".entry-row")).toHaveCount(2);
  project = await (await request.get(`/api/v1/projects/${project.id}`)).json();
  const duplicate = project.entries.find((entry) => entry.id !== original.id)!;
  const copyRow = page.locator(`.entry-row[data-entry-id="${duplicate.id}"]`);
  await copyRow.getByRole("button", { name: /hide/i }).click();
  await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded");
  await row.locator(".entry-select").click();
  await expect(page.locator(".viewer-status")).toContainText(`/ ${original.atom_count} selected`);
  const before = await (await request.get(`/api/v1/projects/${project.id}`)).json();
  await page.getByRole("button", { name: "Style selection", exact: true }).click();
  const dialog = page.getByRole("dialog", { name: "Style selection" });
  await expect(dialog.getByRole("button", { name: "Carbon only" })).toHaveAttribute("aria-pressed", "true");
  await dialog.getByRole("button", { name: "All atoms" }).click();
  await expect(dialog.getByRole("button", { name: "All atoms" })).toHaveAttribute("aria-pressed", "true");
  await expect(dialog.getByRole("button", { name: "Apply blue color" })).toBeInViewport();
  expect(await dialog.evaluate((el) => el.scrollHeight <= el.clientHeight + 1)).toBe(true);
  await page.screenshot({ path: info.outputPath("selection-palette-desktop.png") });
  await dialog.getByText("Expand by distance", { exact: true }).click();
  await expect(dialog.getByLabel("Distance (Å)")).toHaveValue("4");
  await dialog.getByRole("button", { name: "Expand selection", exact: true }).click();
  await expect(dialog.locator(".selection-style-summary")).toContainText(String(original.atom_count * 2));
  await expect(page.locator(".viewer-status")).toContainText(`/ ${original.atom_count * 2} selected`);
  await dialog.getByLabel("Expand to").selectOption("residue");
  await dialog.getByLabel("Distance (Å)").fill("0.1");
  await dialog.getByRole("button", { name: "Expand selection", exact: true }).click();
  await expect(dialog.getByRole("button", { name: "Expand selection", exact: true })).toBeEnabled();
  expect(await (await request.get(`/api/v1/projects/${project.id}`)).json()).toEqual(before);
  expect((await new AxeBuilder({ page }).include('[role="dialog"]').analyze()).violations).toEqual([]);
  await dialog.getByText("Custom…", { exact: true }).click();
  await dialog.getByLabel("Custom selection color").fill("#ff00ff");
  await dialog.getByRole("button", { name: "Apply color", exact: true }).click();
  await expect(dialog.getByRole("status").filter({ hasText: "Selection color applied" })).toBeVisible();
  const colored: Project = await (await request.get(`/api/v1/projects/${project.id}`)).json();
  for (const entry of colored.entries) {
    expect(entry.viewer_settings.selection_colors).toEqual([{ color: "#ff00ff", atom_ids: entry.atom_ids }]);
    expect(entry.viewer_settings.selection_representations).toEqual([]);
  }
  await page.keyboard.press("Escape");
  await expect(page.getByRole("button", { name: "Style selection", exact: true })).toBeFocused();
  await page.getByRole("tabpanel", { name: "selection", exact: true }).getByRole("button", { name: "Clear", exact: true }).click();
  const colorPixels = (channel: "magenta" | "red") => page.locator(".molstar-host canvas").first().evaluate((canvas: HTMLCanvasElement, channel: "magenta" | "red") => {
    const gl = canvas.getContext("webgl2") ?? canvas.getContext("webgl");
    if (!gl) return 0;
    gl.finish();
    const width = Math.floor(canvas.width * 0.6);
    const height = Math.floor(canvas.height * 0.6);
    const pixels = new Uint8Array(width * height * 4);
    gl.readPixels(Math.floor(canvas.width * 0.2), Math.floor(canvas.height * 0.2),
      width, height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    let count = 0;
    for (let i = 0; i < pixels.length; i += 4) {
      if (pixels[i] > 100 && pixels[i + 1] < 70
        && (channel === "magenta" ? pixels[i + 2] > 100 : pixels[i + 2] < 70)) count++;
    }
    return count;
  }, channel);
  const magentaPixels = () => colorPixels("magenta");
  await expect.poll(magentaPixels).toBeGreaterThan(100);
  await row.locator(".entry-select").click();
  await page.getByRole("button", { name: "Style selection", exact: true }).click();
  await dialog.getByRole("button", { name: "Carbon only", exact: true }).click();
  await dialog.getByText("Custom…", { exact: true }).click();
  await dialog.getByLabel("Custom selection color").fill("#ff00ff");
  await dialog.getByRole("button", { name: "Apply color", exact: true }).click();
  await expect(dialog.getByRole("status")).toHaveText("Selection color applied.");
  const carbon: Project = await (await request.get(`/api/v1/projects/${project.id}`)).json();
  expect(carbon.entries.find((entry) => entry.id === original.id)!.viewer_settings.selection_colors)
    .toEqual([{ color: "#ff00ff", atom_ids: [1, 2] }, { color: "element", atom_ids: [3] }]);
  expect(carbon.entries.find((entry) => entry.id === duplicate.id)!.viewer_settings)
    .toEqual(colored.entries.find((entry) => entry.id === duplicate.id)!.viewer_settings);
  await page.keyboard.press("Escape");
  await page.getByRole("tabpanel", { name: "selection", exact: true }).getByRole("button", { name: "Clear", exact: true }).click();
  await expect.poll(magentaPixels).toBeGreaterThan(100);
  await expect.poll(() => colorPixels("red")).toBeGreaterThan(100);
  const settings = carbon.entries.find((entry) => entry.id === original.id)!.viewer_settings;
  const themed = await request.put(`/api/v1/projects/${project.id}/entries/${original.id}/viewer-settings`, {
    data: { expected_revision: carbon.revision, settings: { ...settings,
      representations: settings.representations.map((item) => ({ ...item, color_by: "custom", custom_color: "#00ff00" })),
    } },
  });
  expect(themed.status()).toBe(200);
  await page.reload();
  await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded", { timeout: 30_000 });
  await expect.poll(magentaPixels).toBeGreaterThan(100);
  await expect.poll(() => colorPixels("red")).toBeGreaterThan(100);
  await row.locator(".entry-select").click();
  await page.getByRole("button", { name: "Style selection", exact: true }).click();
  await expect(dialog.getByRole("button", { name: "Carbon only" })).toHaveAttribute("aria-pressed", "true");
  await dialog.getByRole("button", { name: "Reset color" }).click();
  await expect(dialog.getByRole("status")).toHaveText("Selection color reset.");
  await page.keyboard.press("Escape");
  await page.getByRole("tabpanel", { name: "selection", exact: true }).getByRole("button", { name: "Clear", exact: true }).click();
  await expect.poll(magentaPixels).toBe(0);
  const reset: Project = await (await request.get(`/api/v1/projects/${project.id}`)).json();
  expect(reset.entries.find((entry) => entry.id === duplicate.id)!.viewer_settings.selection_colors).toHaveLength(1);

  // Keep the palette open while real canvas picking changes its canonical target.
  await row.locator(".entry-select").click();
  const launcher = page.getByRole("button", { name: "Style selection", exact: true });
  await launcher.click();
  const canvas = page.locator(".molstar-host canvas").first();
  const box = (await canvas.boundingBox())!;
  await observe(page);
  const projection = await (await request.get(`/api/v1/projects/${project.id}/entries/${original.id}/structure`)).json() as StructureProjection;
  let pickedAtom: number | undefined;
  for (const atom of projection.structure.atoms) {
    const point = await page.evaluate(coordinates => window.editingPicks.point(coordinates), atom.coordinates);
    const unobstructed = await canvas.evaluate((node, position) => {
      const bounds = node.getBoundingClientRect();
      return position.x > 0 && position.x < bounds.width && position.y > 0 && position.y < bounds.height
        && document.elementFromPoint(bounds.x + position.x, bounds.y + position.y) === node;
    }, point);
    if (!unobstructed) continue;
    await canvas.click({ position: point });
    await expect.poll(() => page.evaluate(() => window.editingPicks.events
      .filter(event => event.selection).at(-1)?.selection?.atoms)).toEqual([{ structure_id: original.id, atom_id: atom.id }]);
    pickedAtom = atom.id;
    break;
  }
  expect(pickedAtom).toBeDefined();
  await expect(dialog.locator(".selection-style-summary")).toHaveText("1 atom");
  await expect(dialog).toBeVisible();
  const saveCamera = async (name: string) => {
    await page.getByRole("button", { name: "Open viewer controls" }).click();
    await page.getByPlaceholder("Scene name").fill(name);
    await page.getByRole("button", { name: "Save current scene" }).click();
    await expect(page.getByRole("button", { name, exact: true })).toBeVisible();
    await page.getByRole("button", { name: "Close viewer controls" }).click();
    const current: Project = await (await request.get(`/api/v1/projects/${project.id}`)).json();
    return current.scenes.find((scene) => scene.name === name)!.camera;
  };
  const beforeOrbit = await saveCamera("Before palette orbit");
  await page.mouse.move(box.x + box.width * 0.8, box.y + box.height * 0.6);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width * 0.85, box.y + box.height * 0.7, { steps: 8 });
  await page.mouse.up();
  const afterOrbit = await saveCamera("After palette orbit");
  expect(afterOrbit.position).not.toEqual(beforeOrbit.position);
  await expect(dialog.locator(".selection-style-summary")).toHaveText("1 atom");

  let releaseRequest = () => {};
  await dialog.getByRole("button", { name: "All atoms" }).click();
  await expect(dialog.getByRole("button", { name: "All atoms" })).toHaveAttribute("aria-pressed", "true");
  const held = new Promise<void>((resolve) => { releaseRequest = resolve; });
  let submitted: Selection | undefined;
  await page.route(`**/projects/${project.id}/selection-appearance`, async (route) => {
    submitted = (route.request().postDataJSON() as { selection: Selection }).selection;
    await held;
    await route.continue();
  }, { times: 1 });
  try {
    await dialog.getByRole("button", { name: "Apply blue color" }).click();
    await expect.poll(() => submitted?.atoms.length).toBe(1);
    await expect(dialog.getByRole("button", { name: "Line", exact: true })).toBeDisabled();
    // A second target is legal while the first target's command is in flight.
    await row.locator(".entry-select").click();
    await expect(dialog.locator(".selection-style-summary")).toHaveText("3 atoms");
    await page.keyboard.press("Escape");
    await expect(dialog).toBeVisible();
  } finally { releaseRequest(); }
  await expect(dialog.getByRole("button", { name: "Apply blue color" })).toBeEnabled();
  await expect(dialog.getByRole("status")).toHaveCount(0);
  const applied: Project = await (await request.get(`/api/v1/projects/${project.id}`)).json();
  expect(applied.entries.find((entry) => entry.id === original.id)!.viewer_settings.selection_colors)
    .toEqual([{ color: "#3b82f6", atom_ids: submitted!.atoms.map((atom) => atom.atom_id) }]);
  expect(applied.entries.find((entry) => entry.id === duplicate.id)!.viewer_settings)
    .toEqual(reset.entries.find((entry) => entry.id === duplicate.id)!.viewer_settings);
  await page.getByRole("tabpanel", { name: "selection", exact: true }).getByRole("button", { name: "Clear", exact: true }).click();
  await expect(dialog.locator(".selection-style-summary")).toHaveText("0 atoms");
  await expect(dialog.getByRole("button", { name: "Apply blue color" })).toBeDisabled();
  await launcher.click();
  await expect(dialog).toBeHidden();


});

for (const theme of ["light", "dark"]) {
  test(`integrated selection appearance is durable and accessible in ${theme}`, async ({ page, request }, info) => {
    test.setTimeout(90_000);
    const created = await request.post("/api/v1/projects", { data: { name: `Appearance ${theme} ${info.project.name} ${Date.now()}` } });
    let project: Project = await created.json();
    await page.goto("/");
    if (theme === "dark") await page.getByRole("button", { name: "Use dark theme" }).click();
    await page.getByRole("button", { name: "Projects", exact: true }).click();
    await page.getByRole("dialog", { name: "Projects" }).getByRole("button", { name: new RegExp(`^${project.name}`) }).click();
    const structureRequests: string[] = [];
    page.on("request", (outgoing) => {
      if (/\/entries\/[^/]+\/structure$/.test(new URL(outgoing.url()).pathname)) structureRequests.push(outgoing.url());
    });
    await page.getByRole("button", { name: "Import structures" }).first().click();
    const upload = page.getByRole("dialog", { name: "Import structures" });
    await upload.locator('input[type="file"]').setInputFiles(resolve("tests/fixtures/hydrogens/polar_hydrogens_ligand.mol"));
    await upload.getByRole("button", { name: "Import", exact: true }).click();
    await expect(upload).toBeHidden({ timeout: 30_000 });
    await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded", { timeout: 30_000 });
    project = await (await request.get(`/api/v1/projects/${project.id}`)).json();
    const entry = project.entries[0];
    const path = `/api/v1/projects/${project.id}/entries/${entry.id}`;
    const structure = await (await request.get(`${path}/structure`)).json();
    const original = await (await request.get(`${path}/original`)).body();
    const mobile = info.project.name === "mobile-chromium";
    if (mobile) await page.getByRole("button", { name: "Project browser", exact: true }).click();
    await page.locator(`.entry-row[data-entry-id="${entry.id}"] .entry-select`).click();
    if (mobile) {
      await page.keyboard.press("Escape");
      await expect(page.getByRole("dialog", { name: "Project browser panel" })).toBeHidden();
      await expect(page.getByRole("button", { name: "Project browser", exact: true })).toBeFocused();
    }
    await expect(page.locator(".viewer-status")).toContainText("/ 4 selected");
    const launcher = page.getByRole("button", { name: "Style selection", exact: true });
    await expect(launcher).toBeEnabled();
    await launcher.focus();
    await expect(launcher).toBeFocused();
    await page.keyboard.press("Enter");
    const dialog = page.getByRole("dialog", { name: "Style selection" });
    await expect(dialog).toBeVisible();
    await expect(dialog.getByRole("button", { name: "Carbon only" })).toHaveAttribute("aria-pressed", "true");
    await page.screenshot({ path: info.outputPath(`selection-palette-${theme}.png`) });
    if (mobile) {
      for (const control of await dialog.locator("button:visible, select:visible, summary:visible").all()) {
        const bounds = (await control.boundingBox())!;
        expect(bounds.height, await control.getAttribute("aria-label") ?? await control.textContent() ?? "control").toBeGreaterThanOrEqual(44);
        expect(bounds.width).toBeGreaterThanOrEqual(44);
      }
    }
    await dialog.getByText("Expand by distance", { exact: true }).click();
    await dialog.getByRole("button", { name: "Expand selection", exact: true }).click();
    await expect(dialog.locator(".selection-style-summary")).toContainText("4");
    await dialog.getByRole("button", { name: "Line", exact: true }).focus();
    await page.keyboard.press("Enter");
    await expect(dialog.getByRole("status").filter({ hasText: "Applied Line" })).toBeVisible();
    await dialog.getByText("Custom…", { exact: true }).click();
    await dialog.getByLabel("Custom selection color").fill("#ff00ff");
    await dialog.getByRole("button", { name: "Carbon only", exact: true }).click();
    await page.route(`**/projects/${project.id}/selection-appearance`, async (route) => {
      await route.fulfill({ status: 409, contentType: "application/json", body: JSON.stringify({ detail: { code: "revision_conflict", message: "The project changed. Retry the selection action." } }) });
    }, { times: 1 });
    await dialog.getByRole("button", { name: "Apply color" }).click();
    await expect(dialog.getByRole("alert")).toContainText("project changed");
    expect((await (await request.get(`/api/v1/projects/${project.id}`)).json()).entries[0].viewer_settings.selection_colors).toEqual([]);
    await dialog.getByRole("button", { name: "Apply color" }).click();
    await expect(dialog.getByRole("status").filter({ hasText: "Selection color applied" })).toBeVisible();
    const hydrogenToggle = dialog.getByRole("button", { name: "Show non-polar hydrogens", exact: true });
    await expect(hydrogenToggle).toHaveAttribute("aria-pressed", "true");
    await hydrogenToggle.click();
    await expect(hydrogenToggle).toHaveAttribute("aria-pressed", "false");
    await expect(dialog.getByRole("status").filter({ hasText: "Selection hydrogen visibility stored" })).toBeVisible();
    expect((await new AxeBuilder({ page }).include('[role="dialog"]').analyze()).violations).toEqual([]);
    for (const control of await dialog.locator("button:visible, input:visible, select:visible").all()) {
      await control.scrollIntoViewIfNeeded();
      const box = await control.boundingBox();
      const size = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
      expect(box!.x).toBeGreaterThanOrEqual(0);
      expect(box!.x + box!.width).toBeLessThanOrEqual(size.width + 1);
      expect(box!.y + box!.height).toBeLessThanOrEqual(size.height + 1);
    }
    await page.keyboard.press("Escape");
    await expect(launcher).toBeFocused();
    await expect(page.locator(".viewer-status")).toContainText("/ 4 selected");
    const changed: Project = await (await request.get(`/api/v1/projects/${project.id}`)).json();
    expect(changed.entries[0].viewer_settings.selection_representations).toEqual([{ style: "line", atom_ids: [1, 2, 3, 4] }]);
    expect(changed.entries[0].viewer_settings.selection_colors).toEqual([{ color: "#ff00ff", atom_ids: [1] }, { color: "element", atom_ids: [2, 3, 4] }]);
    expect(changed.entries[0].viewer_settings.selection_nonpolar_hydrogens).toEqual([{ show: false, atom_ids: [2, 4] }]);
    expect(await (await request.get(`${path}/structure`)).json()).toEqual(structure);
    expect(await (await request.get(`${path}/original`)).body()).toEqual(original);
    expect(structureRequests).toHaveLength(1);
    await page.reload();
    await expect(page.locator(".viewer-status")).toContainText("1 visible / 1 loaded", { timeout: 30_000 });
    expect((await (await request.get(`/api/v1/projects/${project.id}`)).json()).entries[0].viewer_settings).toEqual(changed.entries[0].viewer_settings);
  });
}
