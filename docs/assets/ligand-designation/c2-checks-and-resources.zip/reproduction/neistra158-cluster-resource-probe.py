"""Read-only source ownership / reconciliation work counts on authored graphs."""
import hashlib,json
from pathlib import Path
from neistra_core.adapters.macromolecular import MmcifAdapter
from neistra_core.molecular import Atom,Bond,NormalizedStructureV1
from neistra_core.ligands.candidates import resolve_candidates
from neistra_core.ligands.source_evidence import assess_mmcif_source
from neistra_core.ligands.reconcile import initial_designation,reconcile_designation
from tests.scientific.test_ligand_instances import cif
class CountList(list):
    def __init__(self,values):super().__init__(values);self.visits=self.passes=0
    def __iter__(self):
        self.passes+=1
        for value in super().__iter__():self.visits+=1;yield value
    def reset(self):self.visits=self.passes=0
raw=cif();before=MmcifAdapter().parse(raw,'base.cif').structures[0]
old=initial_designation(resolve_candidates(before,original_bytes=raw),'before')
assert old.status=='resolved'
rows=[]
for n in [16,64,256]:
    new=[Atom(id=i+4,name=f'Cnew{i}',element='C',coordinates=(3,float(i+1),0),residue_id=2,formal_charge=0,source_index=i+3) for i in range(n)]
    bonds=[Bond(id=i+1,atom_1_id=2,atom_2_id=i+4,order=1.0) for i in range(n)]
    model=before.model_dump();model.update(atoms=[*before.atoms,*new],bonds=bonds,conformers=[c.model_copy(update={'coordinates':[*c.coordinates,*(a.coordinates for a in new)]}) for c in before.conformers])
    current=NormalizedStructureV1.model_validate(model)
    atoms,edges=CountList(current.atoms),CountList(current.bonds);current=current.model_copy(update={'atoms':atoms,'bonds':edges})
    source=assess_mmcif_source(current,raw);assert source.status=='qualified'
    measured={'new_clusters':n,'current_atoms':len(atoms),'source_ownership':{'atom_visits':atoms.visits,'bond_visits':edges.visits}}
    atoms.reset();edges.reset();inventory=resolve_candidates(current,original_bytes=raw)
    measured['inventory']={'atom_visits':atoms.visits,'bond_visits':edges.visits}
    atoms.reset();edges.reset();result=reconcile_designation(old,before,current,inventory,'current')
    assert result.status=='resolved' and result.instance_id==old.instance_id and len(result.atom_ids)==n+2
    measured['reconciliation']={'atom_visits':atoms.visits,'bond_visits':edges.visits,'membership':len(result.atom_ids)}
    rows.append(measured)
files=[Path('packages/neistra_core/src/neistra_core/ligands')/name for name in ['candidates.py','source_evidence.py','reconcile.py']]
print(json.dumps({'measurements':rows,'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'scope':'Deterministic work counts for independent one-atom additions with known bonds to one original heavy owner; no throughput/scientific quality claim.'},indent=2))
