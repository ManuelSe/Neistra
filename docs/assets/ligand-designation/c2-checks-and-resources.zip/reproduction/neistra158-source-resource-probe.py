"""Read-only allocation/work counter for current raw-source qualification."""
import hashlib,inspect,json,sys
from pathlib import Path
import gemmi
from neistra_core.adapters.macromolecular import MmcifAdapter
from neistra_core.ligands import source_evidence as module
FALLBACK_LINES={i for i,line in enumerate(Path(module.__file__).read_text().splitlines(),start=1) if '(columns["pdbx_PDB_ins_code"] or [""] * count)[index]' in line}

class Scheme(dict):
    def __init__(self,values):
        super().__init__(values);self.nonempty_default_calls=0;self.default_slots=0
    def get(self,key,default=None):
        if isinstance(default,list) and default:
            self.nonempty_default_calls+=1;self.default_slots+=len(default)
        return super().get(key,default)
class MissingColumn(list):
    def __init__(self):super().__init__();self.missing_uses=0;self.direct_function_uses=0
    def __bool__(self):
        self.missing_uses+=1
        if sys._getframe(1).f_code.co_filename==module.__file__ and sys._getframe(1).f_lineno in FALLBACK_LINES:self.direct_function_uses+=1
        return False

def evidence(n,*,unique=False,patterns=False,missing_insertion=False):
    asym=[f'W{i}' if unique else 'W' for i in range(n)]
    s=Scheme({'asym_id':asym,'entity_id':['2']*n,'mon_id':['HOH']*n,'ndb_seq_num':[str(i+1) for i in range(n)],'pdb_seq_num':[str(i+1) for i in range(n)],'pdb_mon_id':['HOH']*n,'pdb_strand_id':asym,'pdb_ins_code':['']*n})
    nulls={k:['']*n for k in s}
    if patterns:
        for bit,name in enumerate(['pdb_seq_num','pdb_mon_id','pdb_strand_id','pdb_ins_code']):
            nulls[name]=['' if i%16 & (1<<bit) else '?' for i in range(n)]
    insertion=MissingColumn() if missing_insertion else ['']*n
    return {'nonpoly_scheme':s,'nonpoly_scheme_nulls':nulls,'entities':[['2','water']],'asymmetries':[[a,'2'] for a in dict.fromkeys(asym)],'atom_site':{'id':[str(i+1) for i in range(n)],'label_entity_id':['2']*n,'label_comp_id':['HOH']*n,'auth_seq_id':[str(i+1) for i in range(n)],'auth_comp_id':['HOH']*n,'auth_asym_id':asym,'pdbx_PDB_ins_code':insertion,'label_asym_id':asym,'pdbx_PDB_model_num':['1']*n}}

allocation=[]
for n in [100,400,1000]:
    ev=evidence(n,missing_insertion=True);s=ev['nonpoly_scheme'];col=ev['atom_site']['pdbx_PDB_ins_code']
    assert module._consistent_scheme(ev)
    allocation.append({'rows':n,'discarded_nonempty_get_defaults':s.nonempty_default_calls,'eager_default_slots':s.default_slots,'missing_coordinate_insertion_fallback_uses':col.missing_uses,'missing_coordinate_insertion_slots':col.missing_uses*n})

source_lines,start=inspect.getsourcelines(module._consistent_scheme)
index_line=next(start+i for i,line in enumerate(source_lines) if '].append(coordinate)' in line)
build_line=next(start+i for i,line in enumerate(source_lines) if 'lookups[mask] = dict(lookup)' in line)
pattern_rows=[]
for n in [32,128,256]:
    counters={'lookup_builds':0,'indexed_observations':0}
    def trace(frame,event,arg):
        if event=='line' and frame.f_code is module._consistent_scheme.__code__:
            if frame.f_lineno==index_line:counters['indexed_observations']+=1
            elif frame.f_lineno==build_line:counters['lookup_builds']+=1
        return trace
    sys.settrace(trace)
    try:assert module._consistent_scheme(evidence(n,unique=True,patterns=True))
    finally:sys.settrace(None)
    pattern_rows.append({'rows':n,**counters})

def raw(n):
    header='data_water\nloop_\n_entity.id\n_entity.type\n2 water\nloop_\n_struct_asym.id\n_struct_asym.entity_id\nW 2\nloop_\n'+''.join('_atom_site.'+x+'\n' for x in ['group_PDB','id','type_symbol','label_atom_id','label_alt_id','label_comp_id','label_asym_id','label_entity_id','label_seq_id','Cartn_x','Cartn_y','Cartn_z','auth_seq_id','auth_asym_id','auth_atom_id','auth_comp_id'])
    return (header+''.join(f'HETATM {i} O O . HOH W 2 . {i*3} 0 0 {i} W O HOH\n' for i in range(1,n+1))).encode()
raw_rows=[]
for n in [40,160]:
    original=raw(n);structure=MmcifAdapter().parse(original,'water.cif').structures[0]
    assert module.assess_mmcif_source(structure,original).status=='qualified'
    block=gemmi.cif.read_string(original.decode()).sole_block();ev=module._source_tables(block,original)
    insertion=MissingColumn();ev['atom_site']['pdbx_PDB_ins_code']=insertion
    result=module._match_mmcif_inventory(structure,block,ev)
    assert result is not None and len(result)==n
    raw_rows.append({'rows':n,'insertion_fallback_uses':insertion.missing_uses,'per_atom_missing_insertion_fallback_uses':insertion.direct_function_uses,'per_atom_missing_insertion_slots':n*insertion.direct_function_uses})
p=Path(module.__file__)
print(json.dumps({'source':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scheme_allocations':allocation,'sixteen_pattern_index_work':pattern_rows,'legitimate_raw_missing_optional_columns':raw_rows,'scope':'Deterministic operation/allocation counters on valid synthetic inputs. No latency, throughput or peak-memory claim; source remains unchanged.'},indent=2))
