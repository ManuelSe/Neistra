"""Independent, isolated ASGI work-count probe. Mutates only its temp store."""
from __future__ import annotations
import hashlib,json,tempfile,time
from collections import Counter
from contextlib import ExitStack,contextmanager
from pathlib import Path
from unittest.mock import patch
from threading import BoundedSemaphore
from neistra_api.database import Base
from neistra_api.main import create_app
from neistra_api.settings import Settings
from neistra_api.import_export import ArtifactService,NORMALIZED_MEDIA_TYPE
from neistra_api.models import Artifact,LigandDepictionCache,LigandDepictionBinding,StructureEntry
from neistra_api import ligand_service as service
from neistra_core.ligands import chemistry
from neistra_core.artifacts import LocalArtifactStore
from tests.support.api_client import ApiClient
from sqlalchemy import select,func,event

store=Path(tempfile.mkdtemp(prefix='neistra-158-api-perf-'))
app=create_app(Settings(data_dir=store,database_url=f'sqlite:///{store / "probe.db"}',auto_create_schema=True,enable_test_routes=True))
Base.metadata.create_all(app.state.engine)
client=ApiClient(app)
project=client.post('/api/v1/projects',json={'name':'Bounded candidate API work'}).json()
smiles='.'.join(['CCO']*25)
r=client.post(f'/api/v1/projects/{project["id"]}/imports',data={'expected_revision':project['revision'],'generate_3d':'false'},files=[('files',('repeated.smi',(smiles+' repeated\n').encode(),'chemical/x-daylight-smiles'))]);assert r.status_code==201,r.text
project=client.get(f'/api/v1/projects/{project["id"]}').json(); entry=project['entries'][0]
base=f'/api/v1/projects/{project["id"]}/entries/{entry["id"]}'
params={'expected_artifact_id':entry['current_artifact_id']}

@contextmanager
def counting():
 counters=Counter(); sizes=Counter(); original={n:getattr(service,n) for n in ['prepare_chemistry','resolve_candidates','depict_qualified']}
 verified=ArtifactService.read_verified_bytes;qualify=chemistry.PreparedLigandChemistry.qualify;parse=chemistry._original_molecules
 def counted(name,fn):
  def call(*a,**kw):counters[name]+=1;return fn(*a,**kw)
  return call
 def reads(self,artifact_id):
  value=verified(self,artifact_id);counters['verified_artifact_reads']+=1;sizes[artifact_id]+=len(value);return value
 def sql(conn,cursor,statement,parameters,context,executemany):counters['sql_'+statement.split()[0].upper()]+=1
 event.listen(app.state.engine,'before_cursor_execute',sql)
 with ExitStack() as stack:
  for name,fn in original.items():stack.enter_context(patch.object(service,name,counted(name,fn)))
  stack.enter_context(patch.object(ArtifactService,'read_verified_bytes',reads))
  stack.enter_context(patch.object(chemistry.PreparedLigandChemistry,'qualify',counted('qualify_calls',qualify)))
  stack.enter_context(patch.object(chemistry,'_original_molecules',counted('original_parse_requests',parse)))
  start=time.perf_counter()
  try:yield counters,sizes
  finally:
   counters['elapsed_microseconds']=round((time.perf_counter()-start)*1e6)
   event.remove(app.state.engine,'before_cursor_execute',sql)

def counts(c,s):return {'calls':dict(c),'verified_bytes':sum(s.values()),'unique_verified_artifacts':len(s)}
def retained():
 with app.state.session_factory() as session:
  row={name:session.scalar(select(func.count()).select_from(model)) for name,model in [('artifacts',Artifact),('content',LigandDepictionCache),('bindings',LigandDepictionBinding)]}
 row['files']=sum(p.is_file() for p in (store/'artifacts').rglob('*'))
 row['project']=client.get(f'/api/v1/projects/{project["id"]}').json()
 return row

out={'store':str(store),'workload':{'copies':25,'atoms':entry['atom_count'],'page_size':12},'measurements':{}}
with counting() as (c,s):
 r=client.get(base+'/ligand-candidates',params=params);assert r.status_code==200,r.text
page=r.json();assert len(page['candidates'])==12 and page['total']==25
out['measurements']['page12']=counts(c,s)
urls=[base+'/ligand-candidates/'+x['candidate_key']+'/depiction' for x in page['candidates']]
before=retained()
with counting() as (c,s):
 cold=[client.get(url,params=params) for url in urls]
 assert all(r.status_code==200 and r.json()['status']=='ready' for r in cold)
out['measurements']['cold12']=counts(c,s)
after=retained();assert after['project']==before['project']==project
out['retention_after_cold']={k:v for k,v in after.items() if k!='project'}
with counting() as (c,s):
 warm=[client.get(url,params=params) for url in urls]
 assert [r.json() for r in warm]==[r.json() for r in cold]
out['measurements']['warm12']=counts(c,s)
assert c['prepare_chemistry']==c['resolve_candidates']==c['depict_qualified']==c['qualify_calls']==0
assert retained()==after
# All slots occupied: existing source hits remain ready, unknown input is busy.
for _ in range(2):assert service._DEPICTION_WORK.acquire(blocking=False)
try:
 with counting() as (c,s):
  busy=client.get(base+'/ligand-candidates/not-current/depiction',params=params)
  hit=client.get(urls[0],params=params)
 assert busy.status_code==200 and busy.json()['status']=='busy'
 assert hit.json()==cold[0].json()
 out['measurements']['busy_plus_cache_hit']=counts(c,s)
finally:
 for _ in range(2):service._DEPICTION_WORK.release()
assert retained()==after
# Cached SVG is verified, including on the no-chemistry fast path.
with app.state.session_factory() as session:
 artifact=session.get(Artifact,cold[0].json()['artifact']['id']);path=store/artifact.relative_path
original_svg=path.read_bytes();path.write_bytes(original_svg+b'corrupt')
try:
 bad=client.get(urls[0],params=params)
 out['corrupted_svg_http_status']=bad.status_code
 assert bad.status_code>=400,bad.text
finally:path.write_bytes(original_svg)
assert client.get(urls[0],params=params).json()==cold[0].json()
# Synthetic unit publication changes only coordinates; cache content can remain.
with app.state.session_factory() as session:
 artifacts=ArtifactService(session,LocalArtifactStore(store));live=session.get(StructureEntry,entry['id'])
 source=artifacts.load_normalized(live.current_artifact_id)
 changed=source.model_copy(update={'atoms':[a.model_copy(update={'coordinates':tuple(v+1 for v in a.coordinates)}) for a in source.atoms]})
 artifact=artifacts.publish(changed.to_bytes(),'translated.json',NORMALIZED_MEDIA_TYPE)
 live.current_artifact_id=artifact.id;session.commit();new_id=artifact.id
new_params={'expected_artifact_id':new_id}
with counting() as (c,s):
 stale=client.get(urls[0],params=params)
 rebound=client.get(urls[0],params=new_params)
assert stale.status_code==409 and rebound.status_code==200 and rebound.json()['status']=='ready'
assert rebound.json()['artifact_id']==new_id and rebound.json()['cache_key']==cold[0].json()['cache_key']
out['measurements']['stale_refusal_plus_coordinate_rebind']=counts(c,s)
assert c['depict_qualified']==0
# Low metadata cap exercises FIFO without changing the production constant.
with patch.object(service,'MAX_SOURCE_BINDINGS',3):
 for index in range(5):
  with app.state.session_factory() as session:
   artifacts=ArtifactService(session,LocalArtifactStore(store));live=session.get(StructureEntry,entry['id'])
   source=artifacts.load_normalized(live.current_artifact_id)
   source=source.model_copy(update={'atoms':[a.model_copy(update={'coordinates':tuple(v+1 for v in a.coordinates)}) for a in source.atoms]})
   artifact=artifacts.publish(source.to_bytes(),f'revision-{index}.json',NORMALIZED_MEDIA_TYPE)
   live.current_artifact_id=artifact.id;session.commit();current_id=artifact.id
  r=client.get(urls[0],params={'expected_artifact_id':current_id});assert r.status_code==200 and r.json()['status']=='ready',r.text
  with app.state.session_factory() as session:
   assert session.scalar(select(func.count()).select_from(LigandDepictionBinding))==3
with app.state.session_factory() as session:
 out['bindings_after_fifo']=session.scalar(select(func.count()).select_from(LigandDepictionBinding))
 out['content_after_fifo']=session.scalar(select(func.count()).select_from(LigandDepictionCache))
 out['first_source_binding_retained']=session.get(LigandDepictionBinding,service.LigandService._request_key(StructureEntry(current_artifact_id=entry['current_artifact_id'],original_artifact_id=entry['original_artifact_id']),page['candidates'][0]['candidate_key'])) is not None
out['source_hashes']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(service.__file__),Path(chemistry.__file__),Path('apps/api/src/neistra_api/ligand_schemas.py')]}
out['limits']={'content':service.MAX_CONTENT_CACHE,'bindings':service.MAX_SOURCE_BINDINGS,'svg_bytes':service.MAX_DEPICTION_BYTES,'aggregate_bytes':service.MAX_RETAINED_DEPICTION_BYTES,'workers':2}
out['scope']='Independent in-process ASGI temp store. Unit coordinate-rebinding bypasses history only to isolate cache identity; parent separately qualifies real commands/history. Single elapsed samples are diagnostic; no strict timing or application speedup claim.'
print(json.dumps(out,indent=2))
app.state.engine.dispose()
