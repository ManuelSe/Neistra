from pathlib import Path
import datetime, hashlib, json, os, runpy
root=Path.cwd();e=root/'.issue-11-evidence/forensics/c9-extension';h=runpy.run_path(str(root/'docs/assets/ligand-designation/release-evidence.py.txt'));q=runpy.run_path(str(root/'docs/assets/ligand-designation/qualification.py.txt'));snapshot=json.loads((e/'input-inventory.json').read_text());canonical=snapshot['files'];comparisons={};prefixes={
 'failed-candidate9/tracked/c4-candidate9-native':root/'docs/assets/ligand-designation/c4-candidate9-native',
 'retained-workspaces/neistra158-c4-candidate9':Path('/tmp/neistra158-c4-candidate9'),
 'diagnosis/issue158-c9-mobile-focus-diagnosis':root/'.issue-11-evidence/issue158-c9-mobile-focus-diagnosis'}
for prefix,directory in prefixes.items():
 rows={};links=[]
 for p in sorted(directory.rglob('*')):
  if p.is_symlink():links.append(p.relative_to(directory).as_posix());continue
  if p.is_file():rows[prefix+'/'+p.relative_to(directory).as_posix()]=h['fingerprint'](p)
 expected={n:v for n,v in canonical.items() if n.startswith(prefix+'/')};assert rows==expected and not links
 comparisons[str(directory)]=dict(files=len(rows),bytes=sum(v['bytes'] for v in rows.values()),exact_owned_file_union=True,links=len(links))
for n,v in canonical.items():
 p=None
 if n.startswith('failed-candidate9/tracked/') and not n.startswith('failed-candidate9/tracked/c4-candidate9-native/'):p=root/'docs/assets/ligand-designation'/n.removeprefix('failed-candidate9/tracked/')
 elif n.startswith('failed-candidate9/private/'):p=root/'.issue-11-evidence'/n.removeprefix('failed-candidate9/private/')
 if p is not None:assert h['fingerprint'](p)==v
old=json.loads((e/'previous/unchanged-identities.json').read_text())
for n,v in old.items():assert h['fingerprint'](root/n)==v
proof=json.loads((e/'historical-source-provenance.json').read_text());working=q['current_identities'](root);assert set(working)==set(proof['source_identities']) and all(working[n]==v for n,v in proof['source_identities'].items() if n!=proof['allowed_concurrent_correction_path'])
gate=json.loads((root/'docs/assets/ligand-designation/c4-candidate9-gate.json').read_text());assert q['extracted_identities'](Path(gate['preceding_reader']['root']),gate['preceding_source_before'])==gate['preceding_source_before']
facts=dict(scope='Fresh exact raw/original retention readback after partition proof; not a qualification rerun',canonical_files=len(canonical),canonical_raw_bytes=sum(v['bytes'] for v in canonical.values()),root_comparisons=comparisons,source1005_historical_blobs_bound_to_gate=True,current_other1004_sources_fixed=True,allowed_concurrent_test=proof['allowed_concurrent_correction_path'],old931_reader_fixed=True,old44parts_inventories_and_verification1to4_unchanged=True,all_originals_remain_in_place=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(e/'raw-union-readback.json').write_text(json.dumps(facts,indent=2)+'\n');print(json.dumps(facts,indent=2))
