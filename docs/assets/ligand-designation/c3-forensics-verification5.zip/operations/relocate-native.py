from pathlib import Path
import datetime, hashlib, json, runpy
root=Path.cwd();e=root/'.issue-11-evidence/forensics/c9-extension';h=runpy.run_path(str(root/'docs/assets/ligand-designation/release-evidence.py.txt'));local=json.loads((e/'local-verification.json').read_text());assert local['complete'] and local['all_indexed_assets_verified'] and local['asset_count']==50
raw=json.loads((e/'raw-union-readback.json').read_text());assert raw['all_originals_remain_in_place']
original=root/'docs/assets/ligand-designation/c4-candidate9-native';retained=root/'.issue-11-evidence/issue158-c4-candidate9-native-retained';assert original.is_dir() and not original.is_symlink() and not retained.exists()
canonical=json.loads((e/'input-inventory.json').read_text())['files'];prefix='failed-candidate9/tracked/c4-candidate9-native/';expected={n.removeprefix(prefix):v for n,v in canonical.items() if n.startswith(prefix)}
def identity(directory):
 rows={}
 for p in sorted(directory.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():rows[p.relative_to(directory).as_posix()]=h['fingerprint'](p)
 return rows
before=identity(original);assert before==expected and len(before)==19841
original.rename(retained)
after=identity(retained);assert before==after==expected and not original.exists()
record=dict(scope='Parent-authorized relocation after full50part tracked verifier and complete raw union readback; no deletion',authorization='Parent message authorized relocation only of owned native tree after full verification, preserving every /tmp and other raw original',logical_original=str(original),physical_retained=str(retained),canonical_member_prefix=prefix,files=len(before),bytes=sum(v['bytes'] for v in before.values()),filewise_sha_manifest_sha256=hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),filewise_before_after_equal=True,all_filewise_identities=before,all_tmp_data_and_other_raw_originals_unchanged=True,payloads_deleted=False,qualification_complete=False,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(e/'native-relocation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='all_filewise_identities'},indent=2))
