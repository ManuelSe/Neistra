"""Record the sixth closed failed forensic run without changing older verification snapshots."""
from pathlib import Path
import datetime, json, runpy, zipfile
root=Path.cwd();a=root/'docs/assets/ligand-designation';p=root/'.issue-11-evidence';e=p/'forensics/c9-extension';h=runpy.run_path(str(a/'release-evidence.py.txt'))
previous=json.loads((e/'previous/c3-forensics-index.json').read_text());index=json.loads((a/'c3-forensics-index.json').read_text());old=json.loads((e/'previous/unchanged-identities.json').read_text());assert index['runs'][:5]==previous['runs'] and len(index['runs'])==6
for n,v in old.items():assert h['fingerprint'](root/n)==v,n
local=json.loads((e/'local-verification.json').read_text());assert local['complete'] and local['all_indexed_assets_verified'] and local['asset_count']==index['asset_count'] and len(local['runs'])==6 and all(r['exact_manifest_union'] for r in local['runs'])
source_paths=['tools/verify_ligand_forensics.py','tests/unit/test_ligand_forensic_verifier.py'];sources={n:h['fingerprint'](root/n) for n in source_paths};transaction=json.loads((e/'publication-transaction.json').read_text());assert all(transaction['source_identities'][n]==sources[n] for n in source_paths)
original=json.loads((a/'c3-forensics-verification.json').read_text());assert original['offline_controls']==64 and original['offline_control_network_requests']==0
reference=dict(scope='Reused original64offline controls with exact verifier/test hashes; no repeated or invented controls',offline_controls=64,real_network_requests=0,source_identities=sources,all_sources_unchanged=True,historical_verification_snapshots={f'c3-forensics-verification{n}.{suffix}':h['fingerprint'](a/f'c3-forensics-verification{n}.{suffix}') for n in ('','2','3','4') for suffix in ('json','zip')})
items={}
for n in source_paths:h['add'](items,'source/'+n,root/n)
for n in ['c3-forensics-index.json','c3-forensics-inventory-c4-candidate9.json.gz']:h['add'](items,'indexed-contract/'+n,a/n)
for n in ['c3-forensics-index.json','unchanged-identities.json']:h['add'](items,'previous-contract/'+n,e/'previous'/n)
for n in ['input-inventory.json','parts.json','publication-transaction.json','local-verification.json','local-verification.log','actual-enclosing.json','historical-source-provenance.json','failed-gate-readback.json','extend.py','extend2.log','package-verification5.py','raw-union-readback.json','raw-readback.py','raw-readback.log','relocate-native.py','native-relocation.log']:
 h['add'](items,'operations/'+n,e/n)
if (e/'native-relocation.json').exists():h['add'](items,'operations/native-relocation.json',e/'native-relocation.json')
for d in [e/'attempt1-reader-path']:
 for f in sorted(d.rglob('*')):
  if f.is_file():h['add'](items,'operations/retained-attempts/'+d.name+'/'+f.relative_to(d).as_posix(),f)
for f in sorted(a.glob('c4-candidate9-*')):
 if f.is_file():h['add'](items,'historical-provenance/'+f.relative_to(root).as_posix(),f)
for f in sorted(p.glob('issue158-c4-candidate9-*')):
 if f.is_file():h['add'](items,'historical-provenance/private/'+f.name,f)
snapshot=json.loads((e/'input-inventory.json').read_text())['files'];prefix='diagnosis/issue158-c9-mobile-focus-diagnosis/'
for n in sorted(n for n in snapshot if n.startswith(prefix)):
 f=p/'issue158-c9-mobile-focus-diagnosis'/n.removeprefix(prefix);assert h['fingerprint'](f)==snapshot[n];h['add'](items,n,f)
h['add'](items,'unchanged-source-controls.json',h['encoded'](reference))
# Prior captured query-library source and its license are preserved exactly in v4.
# This packet introduces no newly copied installed-library source. Raw traces stay lossless.
license_ref=dict(scope='No new installed-library source copied. Earlier installed-query-source capture and its exact license remain byte-identical in verification4; raw native trace captures remain lossless supplemental payloads.',verification4=h['fingerprint'](a/'c3-forensics-verification4.zip'),prior_license_correction=h['fingerprint'](p/'forensics/c8-extension/license-correction/correction-receipt.json'))
h['add'](items,'captured-library-license-reference.json',h['encoded'](license_ref))
archive=h['archive'](items,a/'c3-forensics-verification5.zip')
for n,v in old.items():assert h['fingerprint'](root/n)==v,n
assert {n:h['fingerprint'](root/n) for n in source_paths}==sources
run=index['runs'][-1];record=dict(scope='Sixth failed-run forensic retention extension and full local readback; no application qualification, focused correction acceptance or public availability',archive=archive['file'],files=len(items),archive_bytes=archive['bytes'],archive_sha256=archive['sha256'],recursive_verification=archive['verification_counts'],index_sha256=h['fingerprint'](a/'c3-forensics-index.json')['sha256'],previous_index_sha256=h['fingerprint'](e/'previous/c3-forensics-index.json')['sha256'],previous_five_runs_unchanged=True,previous44parts_and_inventories_unchanged=True,previous_verification1through4_unchanged=True,local_all_parts_verified=index['asset_count'],local_new_parts_verified=len(run['parts']),new_run={n:run[n] for n in ['label','failed_candidate','qualification_complete','files','raw_bytes','source_count','source_digest']},total_asset_bytes=index['total_asset_bytes'],total_canonical_files=sum(r['files'] for r in index['runs']),total_raw_bytes=sum(r['raw_bytes'] for r in index['runs']),all_parts_below80MiB=True,exact_disjoint_unions_and_recursive_crcs=True,source_control_reference=reference,failed_gate_readback=json.loads((e/'failed-gate-readback.json').read_text()),root_closed_diagnosis=json.loads((p/'issue158-c9-mobile-focus-diagnosis/actual-enclosing-and-assessments.json').read_text()),all1005_historical_sources_retained=True,old931_reader_hashes_fixed=True,captured_library_licensing=license_ref,
 observed_failure='C9 browser failed at a stale initial-focus native assertion after438passes;56historical exclusions were encountered and107cases notrun. Summary and passing package phases were not executed.',independent_diagnosis='Root-retained independent UI/UX assessments identify the unchanged first-enabled-control focus policy selecting the newly present Entry chooser. Historical App focus block and exact C9 test are retained. Root corrective native test and focused probes are separate and excluded from this failed-run snapshot.',native_relocation=json.loads((e/'native-relocation.json').read_text()) if (e/'native-relocation.json').exists() else None,retention='All owned stores and originals retained. Any native relocation requires parent authorization after exact raw union proof and separate filewise before/after verification; no deletion.',required_next=['Root focused correction and fresh complete next-candidate42step gate, summary, recursive package and observed enclosing exit0','All seven final same-candidate assessments, protected review/merge and complete fresh actual-master gate','Regenerate primary publication bindings and publish every indexed part with full anonymous verification before child closeout'],observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
target=a/'c3-forensics-verification5.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
