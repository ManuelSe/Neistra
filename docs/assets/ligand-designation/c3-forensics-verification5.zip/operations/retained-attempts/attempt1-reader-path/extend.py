"""Append closed failed C9, preserving all older snapshots and originals in place."""
from pathlib import Path
import base64, datetime, gzip, hashlib, io, json, os, runpy, subprocess, zipfile
root=Path.cwd();assets=root/'docs/assets/ligand-designation';private=root/'.issue-11-evidence';extension=private/'forensics/c9-extension'
helper=runpy.run_path(str(assets/'release-evidence.py.txt'));q=runpy.run_path(str(assets/'qualification.py.txt'));sha=lambda b:hashlib.sha256(b).hexdigest()
def new(path,value):
 assert not path.exists(),path
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n')
index_path=assets/'c3-forensics-index.json';plan_path=private/'release-v0.36.0/forensic-upload-plan.json'
old_index_bytes=index_path.read_bytes();old_plan_bytes=plan_path.read_bytes();old_index=json.loads(old_index_bytes);old_plan=json.loads(old_plan_bytes)
assert sha(old_index_bytes)=='d22bb6089dba8063d2283b75b8ad9c474a506df5901cef9e6c75e4a7c65ae06e'
assert old_index['asset_count']==44 and len(old_index['runs'])==5 and old_plan['index_sha256']==sha(old_index_bytes)
old_paths=[assets/(f'c3-forensics-verification{n}.{suffix}') for n in ('','2','3','4') for suffix in ('json','zip')]
old_paths += [root/r['inventory']['path'] for r in old_index['runs']]+[Path(p['local_path']) for p in old_plan['assets']]
old_identities={p.relative_to(root).as_posix():helper['fingerprint'](p) for p in old_paths}
backup=extension/'previous';backup.mkdir();(backup/'c3-forensics-index.json').write_bytes(old_index_bytes);(backup/'forensic-upload-plan.json').write_bytes(old_plan_bytes);new(backup/'unchanged-identities.json',old_identities)
source_paths=['tools/verify_ligand_forensics.py','tests/unit/test_ligand_forensic_verifier.py','docs/assets/ligand-designation/release-evidence.py.txt'];source_before={p:helper['fingerprint'](root/p) for p in source_paths}
assert source_before[source_paths[0]]['sha256']=='d3fe296aed0038ee7bea58a4aa616157f9048c6fac3c42ee40ae30c3c9b6b9b0'
assert source_before[source_paths[1]]['sha256']=='a4d2f7aa2d06c51a6e455271a48c5c09e79003440e9f7dab1ce36fb46cf89275'
label='c4-candidate9';gate=json.loads((assets/(label+'-gate.json')).read_text());report=json.loads((assets/(label+'-browser.json')).read_text());wrapper=json.loads((private/'issue158-c4-candidate9-wrapper.json').read_text())
assert gate['commit']=='f024e5e208988227181630f6c60331e81c3b2b0e' and gate['complete'] is False
assert gate['source_before']==gate['source_after'] and gate['source_unchanged'] and len(gate['source_before'])==1005
assert gate['preceding_source_expected']==gate['preceding_source_before']==gate['preceding_source_after'] and gate['preceding_source_unchanged'] and len(gate['preceding_source_before'])==931
assert q['current_identities'](Path(gate['preceding_reader']['root']))==gate['preceding_source_before']
assert len(gate['steps'])==16 and gate['steps'][-1]['label']=='browser' and gate['steps'][-1]['exit_code']==1 and all(s['exit_code']==0 for s in gate['steps'][:-1])
assert report['stats']['expected']==438 and report['stats']['unexpected']==1 and report['stats']['skipped']==163 and report['stats']['flaky']==0
assert wrapper['complete'] is False and len(wrapper['steps'])==1 and wrapper['steps'][0]['exit_code']==1 and wrapper['steps'][0]['log_sha256']==helper['fingerprint'](Path(wrapper['steps'][0]['log']))['sha256']
# Read immutable historical blobs in one read-only batch; never bind the corrected working test as C9 source.
specs=[gate['commit']+':'+n for n in sorted(gate['source_before'])];data=subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(specs)+'\n').encode());stream=io.BytesIO(data);historical={}
for name in sorted(gate['source_before']):
 header=stream.readline().decode().strip().split();assert header[1]=='blob';size=int(header[2]);body=stream.read(size);assert stream.read(1)==b'\n' and sha(body)==gate['source_before'][name],name;historical[name]=body
assert not stream.read()
working=q['current_identities'](root);allowed='tests/e2e/release-hardening.spec.ts';assert set(working)==set(historical) and all(working[n]==v for n,v in gate['source_before'].items() if n!=allowed)
source_proof=dict(scope='All1005 immutable C9 clean-start blobs reconstructed from exact commit and hash-bound to before/after gate maps; concurrent correction of one native test is not historical source',candidate=gate['commit'],source_count=1005,source_digest=sha(json.dumps(gate['source_before'],sort_keys=True).encode()),source_identities=gate['source_before'],all_historical_blobs_sha256_match=True,preceding_source_count=931,preceding_source_identities=gate['preceding_source_before'],preceding_current_reader_equal=True,allowed_concurrent_correction_path=allowed,working_map_at_snapshot=working)
new(extension/'historical-source-provenance.json',source_proof)
failed=dict(scope='Historical failed C9 readback; actual enclosing86433exit1 is root-reported observation, wrapper/gate/report/log hashes independently validated here; no passing qualification',root_reported_actual_session=86433,root_reported_actual_exit=1,candidate=gate['commit'],first15steps_passed=True,last_step='browser',last_step_exit=1,native_passed=438,native_failed=1,report_skipped_including_unrun=163,encountered_historical_skips_root_reported=56,not_run_root_reported=107,source_count=1005,preceding_source_count=931,source_maps_unchanged=True,preceding_source_maps_unchanged=True,gate_sha256=helper['fingerprint'](assets/(label+'-gate.json'))['sha256'],browser_sha256=helper['fingerprint'](assets/(label+'-browser.json'))['sha256'],wrapper_sha256=helper['fingerprint'](private/'issue158-c4-candidate9-wrapper.json')['sha256'],qualification_raw_log_sha256=wrapper['steps'][0]['log_sha256'],summary_or_package_phase_executed=False)
new(extension/'failed-gate-readback.json',failed)
items={};retained={};links=[];native=assets/(label+'-native')
def collect(directory,prefix):
 assert directory.is_dir() and not directory.is_symlink();count=0
 for p in sorted(directory.rglob('*')):
  name=prefix+'/'+p.relative_to(directory).as_posix()
  if p.is_symlink():
   links.append(dict(member=name,raw_link_text=os.readlink(p),raw_link_bytes_base64=base64.b64encode(os.fsencode(os.readlink(p))).decode(),lstat_mode=p.lstat().st_mode,followed=False));continue
  if p.is_file():
   # Keep ALL ordinary failed output, including incomplete browser artifacts.
   helper['add'](items,name,p,reader_workspace=True);count+=1
 return count
retained['native']=collect(native,'failed-candidate9/tracked/'+native.name)
for p in sorted(assets.glob(label+'-*')):
 if p.is_file():helper['add'](items,'failed-candidate9/tracked/'+p.name,p)
for p in sorted(private.glob('issue158-c4-candidate9-*')):
 if p.is_file():helper['add'](items,'failed-candidate9/private/'+p.name,p)
retained['neistra158-c4-candidate9']=collect(Path('/tmp/neistra158-c4-candidate9'),'retained-workspaces/neistra158-c4-candidate9')
# Closed diagnosis, if supplied before this snapshot; later correction probes remain separate.
diag=private/'issue158-candidate9-failure'
if diag.is_dir():retained[diag.name]=collect(diag,'diagnosis/'+diag.name)
for name,body in historical.items():helper['add'](items,'historical-C9-source/'+name,body)
helper['add'](items,'historical-source-provenance.json',extension/'historical-source-provenance.json');helper['add'](items,'failed-gate-readback.json',extension/'failed-gate-readback.json');helper['add'](items,'owned-links.json',helper['encoded'](dict(scope='Exact link metadata only; no active archive links or following',links=links)))
canonical={name:helper['fingerprint'](p) for name,p in sorted(items.items())};new(extension/'input-inventory.json',dict(scope='Full closed failed C9 native/output/store, lossless raw logs/recipe/wrapper and exact historical sources; no final qualification',files=canonical,retained=retained,link_metadata_count=len(links)))
parts=[];current={};used=0;budget=76*1024*1024
for number,(name,p) in enumerate(sorted(items.items()),1):
 estimate=helper['compressed_size'](p);assert estimate<budget,name
 if current and used+estimate>budget:parts.append(current);current={};used=0
 current[name]=p;used+=estimate
 if number%5000==0:print('SIZED',number,flush=True)
if current:parts.append(current)
print('PARTITION_PLAN',len(parts),'FILES',len(canonical),'RAW',sum(v['bytes'] for v in canonical.values()),flush=True)
packets=[];rows_union={};records=[];new_uploads=[]
for number,part in enumerate(parts,1):
 path=private/'forensics'/('c3-candidate9-native-failure-part%02d.zip'%number);packet=helper['archive'](part,path);assert packet['bytes']<old_index['part_max_bytes_exclusive']
 with zipfile.ZipFile(path) as z:rows=json.loads(z.read('manifest.json'));assert not rows_union.keys()&rows.keys();rows_union.update(rows)
 records.append(dict(ordinal=number,asset_name=path.name,bytes=packet['bytes'],sha256=packet['sha256'],manifest_entries=len(rows),recursive_verification=packet['verification_counts'],repository_path=None));new_uploads.append(dict(run=label,asset_name=path.name,local_path=str(path),bytes=packet['bytes'],sha256=packet['sha256']));packets.append(packet);print('PACKED',number,len(rows),packet['bytes'],flush=True)
assert rows_union==canonical and {name:helper['fingerprint'](p) for name,p in sorted(items.items())}==canonical
new(extension/'parts.json',dict(archives=packets,files=len(canonical),raw_bytes=sum(v['bytes'] for v in canonical.values()),retained=retained,all_originals_retained_in_place=True))
body=json.dumps(dict(format_version=1,run=label,scope='Closed failed C9 exact inventory; complete gate remains failed',files=canonical),sort_keys=True,separators=(',',':')).encode();inventory=assets/('c3-forensics-inventory-'+label+'.json.gz');assert not inventory.exists();inventory.write_bytes(gzip.compress(body,mtime=0))
run=dict(label=label,failed_candidate=gate['commit'],qualification_complete=False,failed_step='browser',source_count=1005,source_digest=source_proof['source_digest'],source_unchanged=True,preceding_source_count=931,preceding_source_unchanged=True,recipe=dict(path=(assets/(label+'-recipe.json')).relative_to(root).as_posix(),sha256=gate['recipe_sha256']),lossless_logs=[dict(label=s['label'],path=s['log'],uncompressed_sha256=s['log_sha256']) for s in gate['steps']],files=len(canonical),raw_bytes=sum(v['bytes'] for v in canonical.values()),extraction_root='forensics/'+label,inventory=dict(path=inventory.relative_to(root).as_posix(),**helper['fingerprint'](inventory),uncompressed_sha256=sha(body)),parts=records,local_exact_union_and_recursive_verification=True)
index=json.loads(old_index_bytes);index['runs'].append(run);index['asset_count']+=len(records);index['total_asset_bytes']+=sum(p['bytes'] for p in records);assert index['runs'][:5]==old_index['runs'];index_bytes=(json.dumps(index,indent=2)+'\n').encode();plan=json.loads(old_plan_bytes);plan['assets'].extend(new_uploads);plan['index_sha256']=sha(index_bytes);assert plan['assets'][:44]==old_plan['assets']
for name,identity in old_identities.items():assert helper['fingerprint'](root/name)==identity,name
assert index_path.read_bytes()==old_index_bytes and plan_path.read_bytes()==old_plan_bytes and {p:helper['fingerprint'](root/p) for p in source_paths}==source_before
assert q['current_identities'](Path(gate['preceding_reader']['root']))==gate['preceding_source_before']
now=q['current_identities'](root);assert set(now)==set(historical) and all(now[n]==v for n,v in gate['source_before'].items() if n!=allowed)
new(extension/'publication-transaction.json',dict(scope='Atomic per-file index/plan extension after exact raw union; prior bytes retained; no public publication',old_index_sha256=sha(old_index_bytes),new_index_sha256=sha(index_bytes),old_plan_sha256=sha(old_plan_bytes),new_assets=len(records),old_records_preserved=True,source_identities=source_before,working_map_after=now,only_allowed_concurrent_correction=allowed,originals_relocated=False,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
for path,content in [(index_path,index_bytes),(plan_path,(json.dumps(plan,indent=2)+'\n').encode())]:
 temporary=path.with_suffix('.json.c9-extension-part');assert not temporary.exists();temporary.write_bytes(content);temporary.replace(path)
print('ALL_EXTENDED',len(records),index['asset_count'],len(canonical),run['raw_bytes'],index['total_asset_bytes'],flush=True)
