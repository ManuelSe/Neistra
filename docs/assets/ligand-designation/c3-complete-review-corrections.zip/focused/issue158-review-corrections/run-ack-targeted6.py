import subprocess,os,json,datetime,runpy,hashlib
from pathlib import Path
root=Path.cwd();out=root/'.issue-11-evidence/issue158-review-corrections';out.mkdir(exist_ok=True);run=Path('/tmp/neistra158-c3-ack-targeted6');assert not run.exists();run.mkdir()
helpers=runpy.run_path(str(root/'docs/assets/ligand-designation/qualification.py.txt'));before=helpers['current_identities'](root)
env=os.environ.copy()
for k in ['NEISTRA_DATA_DIR','NEISTRA_DATABASE_URL','MOLWEAVE_DATA_DIR','MOLWEAVE_DATABASE_URL','DATABASE_URL']:env.pop(k,None)
env.update({'NEISTRA_E2E_DATA_DIR':str(run/'e2e'),'NEISTRA_E2E_API_PORT':'8280','NEISTRA_E2E_WORKER_PORT':'8281','NEISTRA_E2E_WEB_PORT':'5419','PLAYWRIGHT_BROWSERS_PATH':'/datadisk/dev/neistra/.playwright','NEISTRA_AMBERTOOLS_PREFIX':'/datadisk/dev/.neistra-tools/ambertools-24.8','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','NEISTRA_PERFORMANCE':'0','PLAYWRIGHT_JSON_OUTPUT_FILE':str(out/'ack-targeted6-browser.json'),'NEISTRA_MINIMIZATION_EVIDENCE_DIR':str(run/'native')})
commands=[['corepack','pnpm','exec','playwright','test','tests/e2e/ligand-designation-ack.spec.ts','--workers=1','--retries=0','--reporter=line,json','--output',str(run/'browser')]]
receipt={'scope':'Targeted4 actualheldUse/Clear cases after exactUTCserializationoraclecorrection; not fullgate','source_before':before,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'complete':False}
p=out/'ack-targeted6.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
for index,cmd in enumerate(commands):
 log=out/f'ack-targeted6-{index}.log'
 print('START',index,cmd,flush=True)
 with log.open('wb') as stream:r=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 receipt['steps'].append({'command':cmd,'exit_code':r.returncode,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});receipt['source_after']=helpers['current_identities'](root);receipt['source_unchanged']=receipt['source_after']==before;p.write_text(json.dumps(receipt,indent=2)+'\n')
 print('EXIT',index,r.returncode,log.read_text()[-6000:],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 assert receipt['source_unchanged']
receipt['complete']=True;receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(receipt,indent=2)+'\n');print('COMPLETE',p,flush=True)
