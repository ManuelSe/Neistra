import datetime
import hashlib
import json
import re
import runpy
from pathlib import Path

root=Path.cwd();assets=root/'docs/assets/ligand-designation';evidence=root/'.issue-11-evidence'
h=runpy.run_path(str(assets/'release-evidence.py.txt'));items={};retained={}
for name in ['issue158-ack-correction','issue158-architecture-review12','issue158-complete-review','issue158-review-corrections']:
    count,excluded=h['add_reader_workspace'](items,evidence/name,'focused/'+name)
    retained[name]={'files':count,'excluded_named_caches':excluded}
for pattern in ['header-before1*','header-after1*','run-header-before1.py','run-header-after1.py']:
    for path in sorted((evidence/'issue158-integration-root').glob(pattern)):
        h['add'](items,'header-native/'+path.name,path)
for path in sorted(evidence.glob('issue158-c4-candidate2-*')):
    h['add'](items,'stopped-candidate2/'+path.name,path)
for path in sorted(assets.glob('c4-candidate2-*')):
    h['add'](items,'stopped-candidate2/tracked/'+path.name,path)
for name in ['neistra158-header-before1','neistra158-header-after1','neistra158-c4-candidate2','neistra158-c3-combined-native4','neistra158-c3-combined-native5','neistra158-c3-ack-targeted6','neistra158-c3-combined-native7','neistra158-full-science-12da8638-y2swha0q','neistra158-occurrence-independent-5u7ehq9q']:
    path=Path('/tmp')/name
    count,excluded=h['add_reader_workspace'](items,path,'retained-workspaces/'+name)
    retained[name]={'files':count,'excluded_named_caches':excluded}
checks=json.loads((evidence/'issue158-review-corrections/combined-native7.json').read_text());assert checks['complete'] and checks['source_unchanged'] and all(s['exit_code']==0 for s in checks['steps'])
ids=runpy.run_path(str(assets/'qualification.py.txt'))['current_identities'](root);assert checks['source_after']==ids
browser=json.loads((evidence/'issue158-review-corrections/combined-native7-browser.json').read_text());assert browser['stats']['expected']==26 and not any(browser['stats'][k] for k in ['unexpected','flaky','skipped'])
enclosing=json.loads((evidence/'issue158-review-corrections/combined-native7-enclosing.json').read_text());assert enclosing['exit_code']==0
front=json.loads((evidence/'issue158-review-corrections/combined-native4.json').read_text());reuse=json.loads((evidence/'issue158-review-corrections/native7-unaffected-frontend-reuse.json').read_text());assert reuse['changed_selected_sources']==['tests/e2e/ligand-designation-ack.spec.ts'] and reuse['production_frontend_python_tests_tools_configs_identical'];assert all(step['exit_code']==0 for step in front['steps'][:2]);text=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',Path(front['steps'][0]['log']).read_text());web=int(re.search(r'Tests\s+(\d+) passed',text)[1]);suites=int(re.search(r'Test Files\s+(\d+) passed',text)[1])
p=assets/'c3-complete-review-corrections.zip';assert not p.exists();packet=h['archive'](items,p)
r={'scope':'Passing complete-review correction checkpoint; not complete42gate/finalsamecandidateapproval/pushreadiness','candidate_before_corrections':'12da863815e4ea4b55bf76a9ae9cc6c8e4a24e93','comparison_base':'b038e4e6cdb30cf4a296ca4dcd218a7ab5ced881','source_count':len(ids),'source_digest':hashlib.sha256(json.dumps(ids,sort_keys=True).encode()).hexdigest(),'source_identities':ids,'checked_archive':packet,'retained_workspaces':retained,'validation':{'frontend_tests':web,'frontend_suites':suites,'build':'PASS','native_cases':26,'native_failures_flakes_retries_skips':0,'source_unchanged':True,'actual_enclosing':enclosing,'unaffected_frontend_reuse':reuse},'findings':['P2actualouterScrollTop133clipsheader/Close: frameclip/bodyrelative+strongnativeoracles','P2validretiredchangedACKremount/focus: stabledialog/sharedquery/guardedsamepagesourceplaceholder/separateretirement','SDKlastsuccessfulqueryhistorymustnotresurrectknownfailedinputs'], 'earlier_scope':'263focusedPython/scopedscience/performance remainvalid for unchangedscientific/API sources; both prior fullattempts remainpartialfailed, neverpooled','next':['affectedindependentcodereassessments','freshclean42candidate3/summary/package/actualenclosing','finalmetadataandallseven samecandidate assessments','normalPRreviewmerge/exactmergedfresh42','verifiedrelease/issuecloseout/terminaldocs/ownedcleanup','159through163andparentcloseout'],'single_parent_goal_active':True,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=assets/'c3-complete-review-corrections-checkpoint.json';assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'archive':packet,'source_count':len(ids),'source_digest':r['source_digest'],'frontend_tests':web,'native_cases':26},indent=2))
