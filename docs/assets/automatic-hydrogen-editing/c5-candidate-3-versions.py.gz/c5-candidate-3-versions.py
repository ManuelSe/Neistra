import ast,json,subprocess,tomllib
from pathlib import Path
package=tomllib.loads(Path('pyproject.toml').read_text())['project']['version']
lock=tomllib.loads(Path('uv.lock').read_text())
locked=next(p['version'] for p in lock['package'] if p['name']=='molweave-dev')
web=json.loads(Path('apps/web/package.json').read_text())['version']
tree=ast.parse(Path('apps/api/src/molweave_api/main.py').read_text())
api=next(k.value.value for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='FastAPI' for k in node.keywords if k.arg=='version')
tree=ast.parse(Path('apps/api/src/molweave_api/archive_service.py').read_text())
archive=next(node.value.value for node in ast.walk(tree) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='APPLICATION_VERSION' for t in node.targets))
versions=dict(project=package,lock=locked,web=web,api=api,archive=archive)
assert set(versions.values())=={'0.24.0'},versions
base=tomllib.loads(subprocess.check_output(['git','show','54533f10df4d8fff763483356a58c4573a445453:uv.lock'],text=True))
next(p for p in base['package'] if p['name']=='molweave-dev')['version']='0.24.0'
assert lock==base,'No dependency resolution changes are authorized'
print(json.dumps(dict(versions=versions,dependency_resolution_unchanged=True),indent=2))
for asset in Path('apps/web/dist').rglob('*'):
    if asset.is_file() and asset.suffix in {'.js','.html'}:
        content=asset.read_bytes()
        for marker in (b'modelingHarness.ts', b'molecularEditHarness.ts', b'inspectNativeAppearance'):
            assert marker not in content,(str(asset),marker)
print('Production build excludes native observation harnesses')
