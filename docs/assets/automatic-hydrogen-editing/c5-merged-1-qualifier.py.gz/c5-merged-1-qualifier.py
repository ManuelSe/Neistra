"""Sequential release qualification; source identity and exact commands are archived."""
from __future__ import annotations
import argparse
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import socket
import subprocess
import sys
import time
import threading
import tomllib

parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=['candidate', 'merged'])
parser.add_argument('--attempt', type=int, default=1)
args = parser.parse_args()
root = Path.cwd().resolve()
phase = f'{args.phase}-{args.attempt}'
output = root / 'docs/assets/automatic-hydrogen-editing'
task = Path('/tmp') / f'neistra-92-{phase}'
old = Path('/tmp/neistra-92-reader-0230')
assert (old / '.git').is_file()
assert subprocess.check_output(['git', '-C', str(old), 'rev-parse', 'HEAD'], text=True).strip() == '6536e2a3140d0b8b112562ffec580d37830bc217'
assert not task.exists(), 'Use a new attempt number; qualification uses fresh data'
status = subprocess.check_output(['git', 'status', '--porcelain'], text=True).splitlines()
assert not status, status
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
if args.phase == 'merged':
    assert subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip() == 'master'
files = [p for p in subprocess.check_output(['git', 'ls-files'], text=True).splitlines()
         if p.startswith(('apps/', 'packages/', 'tests/', 'tools/', 'migrations/', 'patches/')) or p in {'pyproject.toml', 'uv.lock', 'package.json', 'pnpm-lock.yaml', 'playwright.config.ts'}]
def identity():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in files if (root / p).is_file()}
def debug_identity():
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root / 'debug').rglob('*')) if p.is_file()}
source = identity()
debug = debug_identity()
port_base = 13000 if args.phase == 'candidate' else 13100
for port in (port_base + 10, port_base + 11, port_base + 73):
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', port))
task.mkdir()
output.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env.pop("MOLWEAVE_DATABASE_URL", None)
env.update(MOLWEAVE_DATA_DIR=str(task / "default-data"), MOLWEAVE_MINIMIZATION_MAX_RSS_BYTES=str(4 * 1024**3),
           MOLWEAVE_JOB_PLUGIN_ALLOWLIST="molweave.demo,molweave.minimization",
           MOLWEAVE_JOB_PLUGIN_TARGETS="molweave_demo_plugin.plugin:plugin,molweave_core.minimization.plugin:plugin",
           MOLWEAVE_AMBERTOOLS_PREFIX='/datadisk/dev/.neistra-tools/ambertools-24.8',
           OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', PLAYWRIGHT_BROWSERS_PATH='.playwright',
           MOLWEAVE_E2E_DATA_DIR=str(task / 'browser-data'), MOLWEAVE_E2E_API_PORT=str(port_base + 10),
           MOLWEAVE_E2E_WORKER_PORT=str(port_base + 11), MOLWEAVE_E2E_WEB_PORT=str(port_base + 73),
           MOLWEAVE_MINIMIZATION_EVIDENCE_DIR=str(task / 'native'),
           PLAYWRIGHT_JSON_OUTPUT_NAME=str(task / 'browser.json'))
current_path = ':'.join(str(root / p) for p in ('apps/api/src', 'packages/molweave_core/src', 'packages/molweave_demo_plugin/src'))
old_path = ':'.join(str(old / p) for p in ('apps/api/src', 'packages/molweave_core/src', 'packages/molweave_demo_plugin/src'))
venv = str(root / '.venv/bin/python')
uv = str(root / '.venv/bin/uv')
commands = [
    ('uv', [uv, 'sync', '--frozen'], {}),
    ('pnpm', ['corepack', 'pnpm', 'install', '--frozen-lockfile'], {}),
    ('migration', [uv, 'run', 'alembic', 'upgrade', 'head'], {'MOLWEAVE_DATA_DIR': str(task / 'migration-data')}),
    ('ruff', [uv, 'run', 'ruff', 'check', '.'], {}),
    ('mypy', [uv, 'run', 'mypy', 'apps/api', 'packages/molweave_core'], {}),
    ('python', [uv, 'run', 'pytest'], {}),
    ('lint', ['corepack', 'pnpm', '--dir', 'apps/web', 'lint'], {}),
    ('types', ['corepack', 'pnpm', '--dir', 'apps/web', 'typecheck'], {}),
    ('web-tests', ['corepack', 'pnpm', '--dir', 'apps/web', 'test'], {}),
    ('supervisor', ['corepack', 'pnpm', 'test:dev'], {}),
    ('build', ['corepack', 'pnpm', '--dir', 'apps/web', 'build'], {}),
    ('browser', ['corepack', 'pnpm', 'exec', 'playwright', 'test', '--reporter=list,json'], {}),
    ('forward-migration', [uv, 'run', 'alembic', 'upgrade', 'head'], {'MOLWEAVE_DATA_DIR': str(task / 'forward')}),
    ('automatic-producer', [venv, '-m', 'tests.support.automatic_hydrogen_reader_qualification', 'produce', '--data-dir', str(task / 'forward'), '--reader-root', str(root), '--expected-reader', '0.24.0', '--evidence', str(task / 'automatic-producer.json')], {'PYTHONPATH': current_path}),
    ('old-reader', [venv, '-m', 'tests.support.automatic_hydrogen_reader_qualification', 'read', '--data-dir', str(task / 'forward'), '--reader-root', str(old), '--expected-reader', '0.23.0', '--evidence', str(task / 'old-reader.json')], {'PYTHONPATH': old_path}),
    ('reverse-migration', [uv, 'run', 'alembic', 'upgrade', 'head'], {'MOLWEAVE_DATA_DIR': str(task / 'reverse')}),
    ('old-producer', [venv, '-m', 'tests.support.automatic_hydrogen_reader_qualification', 'produce', '--legacy', '--data-dir', str(task / 'reverse'), '--reader-root', str(old), '--expected-reader', '0.23.0', '--evidence', str(task / 'old-producer.json')], {'PYTHONPATH': old_path}),
    ('current-reader', [venv, '-m', 'tests.support.automatic_hydrogen_reader_qualification', 'read', '--data-dir', str(task / 'reverse'), '--reader-root', str(root), '--expected-reader', '0.24.0', '--evidence', str(task / 'current-reader.json')], {'PYTHONPATH': current_path}),
    ('versions', [venv, '/tmp/neistra-92-versions.py'], {}),
    ('diff', ['git', 'diff', '--check'], {}),
]
def power_state():
    paths = {
        'ac_online': '/sys/class/power_supply/AC0/online',
        'battery_status': '/sys/class/power_supply/BAT0/status',
        'governor': '/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor',
        'energy_preference': '/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference',
    }
    result = {key: Path(path).read_text().strip() for key, path in paths.items() if Path(path).exists()}
    try: result['profile'] = subprocess.check_output(['powerprofilesctl', 'get'], text=True).strip()
    except (OSError, subprocess.CalledProcessError): pass
    return result
metadata = dict(power_at_start=power_state(), commit=base, phase=args.phase, attempt=args.attempt, clean_tracked_at_start=True,
                preserved_untracked_debug=debug, boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                host=platform.node(), platform=platform.platform(),
                qualifier_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                environment={k: env[k] for k in env if k.startswith(('MOLWEAVE_', 'OPENBLAS_', 'OMP_', 'PLAYWRIGHT_'))})
records = []
code = 0
power_log = task / 'power.jsonl'
power_stop = threading.Event()
def monitor_power():
    while not power_stop.is_set():
        observation = {'timestamp': time.time()}
        for key, path in [('ac_online', '/sys/class/power_supply/AC0/online'), ('battery_status', '/sys/class/power_supply/BAT0/status')]:
            if Path(path).exists(): observation[key] = Path(path).read_text().strip()
        with power_log.open('a') as stream: stream.write(json.dumps(observation) + '\n')
        power_stop.wait(15)
power_thread = threading.Thread(target=monitor_power, daemon=True)
power_thread.start()
for label, command, overrides in commands:
    started = time.time()
    started_power = power_state()
    raw = task / f'{label}.log'
    print(f'START {label}', flush=True)
    with raw.open('wb') as stream:
        completed = subprocess.run(command, env={**env, **overrides}, stdout=stream, stderr=subprocess.STDOUT)
    content = raw.read_bytes()
    qualification_error = None
    if label == 'python' and re.search(rb'\b[1-9][0-9]* skipped\b', content):
        qualification_error = 'Configured native Python qualification must not skip tests'
    if label == 'browser' and (task / 'browser.json').exists():
        browser = json.loads((task / 'browser.json').read_text())
        if browser['stats']['unexpected'] or browser['stats']['flaky'] or browser['stats']['skipped'] != 60:
            qualification_error = f"Unexpected browser result or changed exclusions: {browser['stats']}"
    effective_code = completed.returncode or int(qualification_error is not None)
    target = output / f'c5-{phase}-{label}.log.gz'
    target.write_bytes(gzip.compress(content, mtime=0))
    records.append(dict(label=label, command=command, environment_overrides=overrides,
                        power_before=started_power, power_after=power_state(), exit_code=completed.returncode, qualification_error=qualification_error, seconds=round(time.time()-started, 3),
                        log=str(target.relative_to(root)), log_sha256=hashlib.sha256(content).hexdigest()))
    unchanged = source == identity() and debug == debug_identity()
    (output / f'c5-{phase}-gate.json').write_text(json.dumps(dict(**metadata, steps=records, source_unchanged=unchanged,
                       passed=not effective_code and label == commands[-1][0] and unchanged), indent=2)+'\n')
    print(f'END {label} {completed.returncode}', flush=True)
    if label == 'browser':
        if (task / 'browser.json').exists(): shutil.copy2(task / 'browser.json', output / f'c5-{phase}-browser.json')
        for artifact in Path('test-results').rglob('*.json'):
            if artifact.name in {'minimization-performance.json','live-native-timings.json','interactive-transform-performance.json',
                                  'quick-cold-performance.json','quick-repeat-performance.json','quick-live-performance.json'}:
                (output / f'c5-{phase}-{artifact.parent.name}-{artifact.name}.gz').write_bytes(gzip.compress(artifact.read_bytes(), mtime=0))
    if label in {'automatic-producer', 'old-reader', 'old-producer', 'current-reader'}:
        evidence = task / f'{label}.json'
        if evidence.exists(): shutil.copy2(evidence, output / f'c5-{phase}-{label}.json')
    if label == 'python':
        for artifact in (task / 'native').glob('*.json'):
            shutil.copy2(artifact, output / f'c5-{phase}-{artifact.name}')
    if effective_code or not unchanged:
        code = effective_code or 1
        print(content.decode(errors='replace')[-7000:], flush=True)
        if qualification_error: print(qualification_error, flush=True)
        break
(output / f'c5-{phase}-source.json').write_text(json.dumps(dict(commit=base, files=source, unchanged=source == identity()), indent=2)+'\n')
(output / f'c5-{phase}-versions.py.gz').write_bytes(gzip.compress(Path('/tmp/neistra-92-versions.py').read_bytes(), mtime=0))
(output / f'c5-{phase}-qualifier.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
power_stop.set()
power_thread.join(timeout=2)
if power_log.exists():
    power_target = output / f'c5-{phase}-power.jsonl.gz'
    power_target.write_bytes(gzip.compress(power_log.read_bytes(), mtime=0))
    gate_path = output / f'c5-{phase}-gate.json'
    gate_data = json.loads(gate_path.read_text())
    gate_data['power_observations'] = {'log': str(power_target.relative_to(root)), 'raw_sha256': hashlib.sha256(power_log.read_bytes()).hexdigest(), 'interval_seconds': 15}
    gate_path.write_text(json.dumps(gate_data, indent=2) + '\n')
sys.exit(code)
