import { createRequire } from "node:module";
const require = createRequire("/datadisk/dev/neistra-worktrees/issue-11-ligand-information/apps/web/package.json");
const tseslint = require("typescript-eslint");
export default tseslint.config(...tseslint.configs.recommended);
