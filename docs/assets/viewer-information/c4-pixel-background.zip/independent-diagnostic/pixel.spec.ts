import { test, expect } from "/datadisk/dev/neistra-worktrees/issue-11-ligand-information/node_modules/@playwright/test";
import { writeFileSync } from "node:fs";
import { prepare, frameFixture, native } from "/datadisk/dev/neistra-worktrees/issue-11-ligand-information/tests/e2e/support/interactions";
test("diagnoses complete canvas cyan ownership", async ({ page, request }) => {
 test.setTimeout(150000);
 await prepare(page, request, ["tests/fixtures/interactions/hydrogen_pair.mol"], "C7 cyan ownership diagnostic");
 await frameFixture(page);
 await page.evaluate(() => window.interactionEngines.at(-1)!.setCamera({mode:"perspective", position:[5.852234200851856,2.4000893350902706,10.96339258976305],target:[2.3431784340772692,0.06071882390721189,0.05329483805178377],up:[0,1,0],radius:4.476191683966037}));
 const result:any = {};
 const sample=async (label:string) => {
  await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  result[label]={native:await native(page),pixels:await page.locator('.molstar-host canvas').first().evaluate((canvas:HTMLCanvasElement)=>{
   const gl=canvas.getContext('webgl2')??canvas.getContext('webgl'); if(!gl)throw new Error('WebGL required');gl.finish();const buf=new Uint8Array(canvas.width*canvas.height*4);gl.readPixels(0,0,canvas.width,canvas.height,gl.RGBA,gl.UNSIGNED_BYTE,buf);const pixels:number[][]=[];
   for(let i=0;i<buf.length;i+=4) if(buf[i]<90&&buf[i+1]>100&&buf[i+2]>120)pixels.push([(i/4)%canvas.width,Math.floor(i/4/canvas.width),buf[i],buf[i+1],buf[i+2]]);
   return {width:canvas.width,height:canvas.height,count:pixels.length,pixels};
  })};
 };
 await page.getByRole('button',{name:'Interactions',exact:true}).click();const panel=page.getByRole('dialog',{name:'Interactions',exact:true});await panel.getByRole('button',{name:'H bonds',exact:true}).click();await expect.poll(async()=>(await native(page)).records.length).toBe(1);await panel.getByRole('button',{name:'Close interactions'}).click();await sample('overlayOn');
 await page.getByRole('button',{name:'Open viewer controls'}).click();await page.getByRole('checkbox',{name:'Show hydrogens',exact:true}).click();await expect.poll(async()=>(await native(page)).records.length).toBe(0);await sample('hydrogensOff');writeFileSync('/tmp/neistra156-c7-pixel-diagnostic1/ownership-before-axes.json',JSON.stringify(result,null,2));
 await page.evaluate(()=>{const engine=window.interactionEngines.at(-1)! as any;engine.plugin.canvas3d.setProps({camera:{helper:{axes:{name:'off',params:{}}}}});engine.plugin.canvas3d.requestDraw();});await sample('axesOff');
 writeFileSync('/tmp/neistra156-c7-pixel-diagnostic1/ownership.json',JSON.stringify(result,null,2));
 await page.screenshot({path:'/tmp/neistra156-c7-pixel-diagnostic1/axes-off.png'});
});
