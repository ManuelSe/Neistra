import { defineConfig } from "/datadisk/dev/neistra-worktrees/issue-11-ligand-information/node_modules/@playwright/test";
import base from "/datadisk/dev/neistra-worktrees/issue-11-ligand-information/playwright.config";
export default defineConfig({ ...base, testDir: "/tmp/neistra156-c7-pixel-diagnostic1", outputDir: "/tmp/neistra156-c7-pixel-diagnostic1/output", projects: base.projects?.filter(p => p.name === "chromium"), webServer: (base.webServer as any[]).map(server => ({...server, cwd: "/datadisk/dev/neistra-worktrees/issue-11-ligand-information"})), reporter: [["list"]] });
