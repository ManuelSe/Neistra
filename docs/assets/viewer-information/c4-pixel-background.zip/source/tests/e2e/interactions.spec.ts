import { performanceBudget } from "./support/performance";
import { resolve } from "node:path";
import { writeFileSync } from "node:fs";
import { expect, test } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import type { Project, NormalizedStructure } from "../../apps/web/src/api/types";
import { frameFixture, prepare, native, cyanPixelsOutsideBackground, settledCyanBackground } from "./support/interactions";

test("compact interaction control analyzes once and filters cached scopes", async ({ page, request }, info) => {
  test.setTimeout(90_000);
  const created = await request.post("/api/v1/projects", { data: { name: `Interactions ${info.project.name} ${Date.now()}` } });
  const project = await created.json();
  await page.goto("/");
  await page.getByRole("button", { name: "Projects", exact: true }).click();
  await page.getByRole("dialog", { name: "Projects" }).getByRole("button", { name: new RegExp(`^${project.name}`) }).click();
  await page.getByRole("button", { name: "Import structures" }).first().click();
  const imports = page.getByRole("dialog", { name: "Import structures" });
  await imports.locator('input[type="file"]').setInputFiles([resolve("tests/fixtures/formats/ethanol.mol"), resolve("tests/fixtures/formats/ethanol.mol")]);
  await imports.getByRole("button", { name: "Import", exact: true }).click();
  await expect(imports).toBeHidden({ timeout: 20_000 });
  await expect(page.locator(".viewer-status")).toContainText("2 visible / 2 loaded", { timeout: 20_000 });
  let analyses = 0;
  page.on("request", request => { if (request.url().endsWith("/interactions")) analyses++; });
  await page.getByRole("button", { name: "Interactions", exact: true }).click();
  const panel = page.getByRole("dialog", { name: "Interactions", exact: true });
  await expect(panel.getByRole("status")).toHaveText("Choose an interaction type");
  expect(analyses).toBe(0);
  await panel.getByRole("button", { name: "Clashes", exact: true }).click();
  await expect(panel.getByRole("status")).toContainText(/\d+ detected/, { timeout: 20_000 });
  expect(analyses).toBe(1);
  for (const label of ["H bonds", "Hydrophobic", "π–π", "Cation–π", "Salt bridges"]) {
    await panel.getByRole("button", { name: label, exact: true }).click();
    await expect(panel.getByRole("button", { name: label, exact: true })).toHaveAttribute("aria-pressed", "true");
  }
  expect(analyses).toBe(1);
  await panel.getByRole("button", { name: "Intermolecular interactions" }).click();
  await expect(panel.getByRole("status")).toHaveText("Choose Inter or Intra");
  await panel.getByRole("button", { name: "Intramolecular interactions" }).click();
  await expect(panel.getByRole("status")).toContainText("0 detected");
  expect(analyses).toBe(1);
  await panel.getByRole("button", { name: "Close interactions" }).click();
  await expect(panel).toBeHidden();
});

test("qualifies explicit-H marker pixels, visibility, preview Cancel and committed invalidation", async ({ page, request }, info) => {
  test.setTimeout(150_000);
  const project = await prepare(page, request, ["tests/fixtures/interactions/hydrogen_pair.mol"], "Interaction lifecycle");
  await frameFixture(page);
  // The molecule and camera axes also contain cyan edge pixels. Capture each
  // visibility state's settled full-canvas background before any analysis, then
  // test newly drawn pixels rather than treating unrelated objects as markers.
  await expect.poll(async () => (await native(page)).records.length).toBe(0);
  const hydrogenDrawn = () => page.evaluate(entryId => window.interactionEngines.at(-1)!
    .getRenderedAtomReferences().some(atom => atom.structure_id === entryId && atom.atom_id === 2), project.entries[0].id);
  await expect.poll(hydrogenDrawn).toBe(true);
  const shownBackground = await settledCyanBackground(page);
  const pixelCamera = (await native(page)).camera;
  await page.getByRole("button", { name: "Open viewer controls" }).click();
  const hydrogens = page.getByRole("checkbox", { name: "Show hydrogens", exact: true });
  await hydrogens.click(); await expect(hydrogens).not.toBeChecked();
  await expect.poll(hydrogenDrawn).toBe(false);
  await native(page);
  const hiddenBackground = await settledCyanBackground(page);
  expect((await native(page)).camera).toEqual(pixelCamera);
  await hydrogens.click(); await expect(hydrogens).toBeChecked();
  await expect.poll(hydrogenDrawn).toBe(true);
  await page.getByRole("button", { name: "Close viewer controls" }).click();
  await native(page);
  expect(await settledCyanBackground(page)).toEqual(shownBackground);
  expect((await native(page)).camera).toEqual(pixelCamera);
  let analyses = 0, structureGets = 0;
  page.on("request", outgoing => { if (outgoing.url().endsWith("/interactions")) analyses++; if (/\/entries\/[^/]+\/structure$/.test(new URL(outgoing.url()).pathname)) structureGets++; });
  const launcher = page.getByRole("button", { name: "Interactions", exact: true });
  await launcher.click();
  const panel = page.getByRole("dialog", { name: "Interactions", exact: true });
  await panel.getByRole("button", { name: "H bonds", exact: true }).click();
  await expect(panel.getByRole("status")).toContainText("1 detected", { timeout: 20_000 });
  await expect.poll(async () => (await native(page)).records.length).toBe(1);
  const geometry = await native(page);
  expect(geometry.camera).toEqual(pixelCamera);
  expect(geometry.records[0].endpoints).toEqual([[1, 0, 0], [2.8, 0, 0]]);
  expect(geometry.objects[0].starts.slice(0, 3)).toEqual([1, 0, 0]);
  expect(geometry.objects.every(object => !object.pickable && object.drawCount > 0)).toBe(true);
  await panel.getByRole("button", { name: "Close interactions" }).click();
  await expect.poll(() => cyanPixelsOutsideBackground(page, shownBackground)).toBeGreaterThan(10);
  const pixels = await cyanPixelsOutsideBackground(page, shownBackground);
  await page.screenshot({ path: info.outputPath("explicit-h-overlay.png") });
  await page.getByRole("button", { name: "Open viewer controls" }).click();
  await page.getByRole("checkbox", { name: "Show hydrogens", exact: true }).click();
  await expect(page.getByRole("checkbox", { name: "Show hydrogens", exact: true })).not.toBeChecked();
  await expect.poll(async () => (await native(page)).records.length).toBe(0);
  expect((await native(page)).camera).toEqual(pixelCamera);
  await expect.poll(() => cyanPixelsOutsideBackground(page, hiddenBackground)).toBeLessThanOrEqual(10);
  await page.getByRole("checkbox", { name: "Show hydrogens", exact: true }).click();
  await expect(page.getByRole("checkbox", { name: "Show hydrogens", exact: true })).toBeChecked();
  await page.getByRole("button", { name: "Close viewer controls" }).click();
  await expect.poll(() => cyanPixelsOutsideBackground(page, shownBackground)).toBeGreaterThan(10);
  expect((await native(page)).camera).toEqual(pixelCamera);
  expect(analyses).toBe(1); expect(structureGets).toBe(0);
  const mobile = info.project.name === "mobile-chromium";
  if (mobile) await page.getByRole("button", { name: "Inspector", exact: true }).click();
  await page.getByLabel("Select by").selectOption("structure");
  await page.getByLabel("Value", { exact: true }).fill(project.entries[0].id);
  await page.getByRole("button", { name: "Apply query", exact: true }).click();
  if (mobile) await page.getByRole("button", { name: "Close panel", exact: true }).click({ position: { x: 2, y: 100 } });
  await page.getByRole("button", { name: "Transform selection", exact: true }).click();
  await expect(launcher.locator('[data-interaction-status="paused"]')).toBeVisible();
  await launcher.click(); await expect(panel.getByRole("status")).toHaveText("Paused during preview");
  await panel.getByRole("button", { name: "Close interactions" }).click();
  await page.getByRole("button", { name: "More movement tools" }).click();
  await page.getByRole("button", { name: "Translate", exact: true }).click();
  await page.getByRole("button", { name: "Step right", exact: true }).click();
  await expect.poll(async () => (await native(page)).records.length).toBe(0);
  expect(analyses).toBe(1);
  await page.getByRole("button", { name: "Cancel movement", exact: true }).click();
  await expect.poll(async () => (await native(page)).records[0]?.endpoints).toEqual(geometry.records[0].endpoints);
  await expect(launcher.locator('[data-interaction-status="paused"]')).toHaveCount(0);
  expect(analyses).toBe(1);
  await page.getByRole("button", { name: "Transform selection", exact: true }).click();
  await page.getByRole("button", { name: "More movement tools" }).click();
  await page.getByRole("button", { name: "Translate", exact: true }).click();
  await page.getByRole("button", { name: "Step right", exact: true }).click();
  await page.getByRole("button", { name: "Apply movement", exact: true }).click();
  await expect.poll(() => analyses, { timeout: 20_000 }).toBe(2);
  const changed: { structure: NormalizedStructure } = await (await request.get(`/api/v1/projects/${project.id}/entries/${project.entries[0].id}/structure`)).json();
  const movedEndpoints = [2, 3].map(id => changed.structure.atoms.find(atom => atom.id === id)!.coordinates);
  expect(movedEndpoints).not.toEqual(geometry.records[0].endpoints);
  await expect.poll(async () => (await native(page)).records[0]?.endpoints).toEqual(movedEndpoints);
  await expect.poll(async () => (await native(page)).objects[0]?.starts.slice(0, 3)).toEqual(movedEndpoints[0].map(Math.fround));
  await page.getByRole("button", { name: /^Undo:/ }).click();
  await expect.poll(() => analyses, { timeout: 20_000 }).toBe(3);
  await expect.poll(async () => (await native(page)).records[0]?.endpoints).toEqual(geometry.records[0].endpoints);
  await page.getByRole("button", { name: /^Redo:/ }).click();
  await expect.poll(() => analyses, { timeout: 20_000 }).toBe(4);
  await expect.poll(async () => (await native(page)).records[0]?.endpoints).toEqual(movedEndpoints);
  await expect.poll(async () => (await native(page)).objects[0]?.starts.slice(0, 3)).toEqual(movedEndpoints[0].map(Math.fround));
  writeFileSync(info.outputPath("interaction-lifecycle.json"), JSON.stringify({ project: info.project.name, pixels,
    shownBackground, hiddenBackground, geometry, analyses, structureGets }, null, 2));
});

test("shows busy failures, retries, and keeps the compact panel accessible in both themes", async ({ page, request }, info) => {
  test.setTimeout(90_000);
  await prepare(page, request, ["tests/fixtures/interactions/hydrogen_pair.mol"], "Interaction retry");
  let requests = 0;
  await page.route("**/interactions", async route => {
    requests++;
    if (requests === 1) await route.fulfill({ status: 429, contentType: "application/json", body: JSON.stringify({ detail: { code: "interactions_busy", message: "Another interaction analysis is running. Try again shortly." } }) });
    else await route.continue();
  });
  await page.getByRole("button", { name: "Interactions", exact: true }).click();
  const panel = page.getByRole("dialog", { name: "Interactions", exact: true });
  await panel.getByRole("button", { name: "H bonds", exact: true }).click();
  await expect(panel.getByRole("status")).toContainText("Try again shortly");
  await panel.getByRole("button", { name: "Retry interaction analysis" }).click();
  await expect(panel.getByRole("status")).toContainText("1 detected", { timeout: 20_000 });
  expect(requests).toBe(2);
  for (const theme of ["light", "dark"]) {
    const current = await page.locator("html").getAttribute("data-theme");
    if (current !== theme) await page.getByRole("button", { name: `Use ${theme} theme` }).click();
    await expect(panel).toBeVisible();
    await expect(panel).toHaveCSS("opacity", "1");
    expect((await new AxeBuilder({ page }).include(".interaction-panel").analyze()).violations).toEqual([]);
    await page.screenshot({ path: info.outputPath(`interaction-panel-${theme}.png`) });
  }
  await page.setViewportSize({ width: 320, height: 640 });
  // The desktop/mobile workspace boundary remounts the renderer, retaining session choices.
  if (info.project.name === "chromium") await page.getByRole("button", { name: "Interactions", exact: true }).click();
  await expect(panel.getByRole("status")).toContainText("1 detected");
  expect(requests).toBe(2);
  const box = (await panel.boundingBox())!;
  expect(box.x).toBeGreaterThanOrEqual(0); expect(box.x + box.width).toBeLessThanOrEqual(321);
  expect(box.y + box.height).toBeLessThanOrEqual(641);
  await panel.getByRole("button", { name: "H bonds", exact: true }).focus();
  await page.keyboard.press("Escape"); await expect(panel).toBeHidden();
  await expect(page.getByRole("button", { name: "Interactions", exact: true })).toBeFocused();
});

test("measures bounded analysis and cached toggles on pinned 1STP with aligned typed ligand", async ({ page, request }, info) => {
  test.setTimeout(90_000);
  const project = await prepare(page, request, ["tests/fixtures/complex/1stp.pdb", "tests/fixtures/interactions/aligned_ethanol.mol"], "Interaction performance");
  let analyses = 0, structureGets = 0, requestBytes = 0;
  page.on("request", outgoing => { if (outgoing.url().endsWith("/interactions")) { analyses++; requestBytes += Buffer.byteLength(outgoing.postData() ?? ""); } if (/\/entries\/[^/]+\/structure$/.test(new URL(outgoing.url()).pathname)) structureGets++; });
  await page.evaluate(() => {
    const tasks: number[] = [];
    const observer = new PerformanceObserver(list => list.getEntries().forEach(entry => tasks.push(entry.duration)));
    observer.observe({ type: "longtask", buffered: false });
    Object.assign(window, { interactionTiming: { tasks, observer } });
  });
  await page.getByRole("button", { name: "Interactions", exact: true }).click();
  const panel = page.getByRole("dialog", { name: "Interactions", exact: true });
  const start = Date.now();
  await panel.getByRole("button", { name: "Clashes", exact: true }).click();
  await expect(panel.getByRole("status")).toContainText(/\d+ detected/, { timeout: 20_000 });
  await expect.poll(async () => (await native(page)).records.length).toBeGreaterThan(0);
  const firstMs = Date.now() - start;
  performanceBudget(firstMs, 5_000, "firstMs");
  const records = await native(page);
  const cachedStart = Date.now();
  await panel.getByRole("button", { name: "Clashes", exact: true }).click();
  await expect.poll(async () => (await native(page)).records.length).toBe(0);
  await panel.getByRole("button", { name: "Clashes", exact: true }).click();
  await expect.poll(async () => (await native(page)).records.length).toBe(records.records.length);
  const cachedToggleMs = (Date.now() - cachedStart) / 2;
  performanceBudget(cachedToggleMs, 500, "cachedToggleMs");
  const longestTaskMs = await page.evaluate(() => {
    const timing = (window as unknown as { interactionTiming: { tasks: number[]; observer: PerformanceObserver } }).interactionTiming;
    timing.observer.disconnect(); return Math.max(0, ...timing.tasks);
  });
  performanceBudget(longestTaskMs, 750, "longestTaskMs");
  expect(analyses).toBe(1); expect(structureGets).toBe(0); expect(requestBytes).toBeLessThan(500);
  const evidence = { project: info.project.name, atoms: project.entries.reduce((count, entry) => count + entry.atom_count, 0), records: records.records.length, firstMs, cachedToggleMs, longestTaskMs, analyses, structureGets, requestBytes, fixture: "pinned 1STP + supplied typed ethanol aligned to BTN centroid; no binding claim" };
  writeFileSync(info.outputPath("interaction-performance.json"), JSON.stringify(evidence, null, 2));
  await page.screenshot({ path: info.outputPath("interaction-performance.png") });
});
