import base from "/datadisk/dev/neistra-worktrees/issue-11-ligand-information/apps/web/vite.config";
export default {...base, test: {...base.test, include: ["/tmp/neistra156-performance-review7-retention/corrected-retention-100k.test.ts"]}};
